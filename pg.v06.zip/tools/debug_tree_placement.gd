extends SceneTree
## Debug script to test tree placement in planet generation
## Run with: godot --headless -s tools/debug_tree_placement.gd

func _init():
	print("\n=== DEBUGGING TREE PLACEMENT ===\n")

	# Create a test planet
	var props = {
		"scale_range": Vector2(0.062, 0.074),
		"colors": [Color(0.3, 0.6, 0.7)]
	}
	var planet = Planet.new(null, 100.0, 0.02, PlanetEnums.PlanetType.SUPER_EARTH, props, true)
	planet.habitability_score = 0.8
	planet.surface_liquids = {"water": 0.6}
	planet.atmosphere_type = PlanetEnums.AtmosphereType.MODERATE
	planet.climate_type = PlanetEnums.ClimateType.TEMPERATE
	planet.geological_activity = PlanetEnums.GeologicalActivity.MODERATE

	var probe_data = {
		"habitability_score": 0.8,
		"atmosphere_type": "MODERATE",
		"surface_temperature": 288.0,
		"geological_activity": "MODERATE",
		"climate_type": "TEMPERATE",
		"surface_liquids": {"water": 0.6},
		"surface_composition": {"silicates": 0.5, "metals": 0.2}
	}

	# Generate map
	var generator = PlanetMapGenerator.new()
	var tiles_2d = generator.generate_map(planet, probe_data, 12345)

	print("Map generated: %dx%d" % [tiles_2d.size(), tiles_2d[0].size() if tiles_2d.size() > 0 else 0])

	# Check tree distribution
	var tree_positions = []
	var x_distribution = {}
	var y_distribution = {}

	for x in range(tiles_2d.size()):
		for y in range(tiles_2d[x].size()):
			var tile = tiles_2d[x][y]
			if tile and tile.surface_feature_type != null:
				tree_positions.append(Vector2i(x, y))
				x_distribution[x] = x_distribution.get(x, 0) + 1
				y_distribution[y] = y_distribution.get(y, 0) + 1

	print("\n=== TREE DISTRIBUTION ANALYSIS ===")
	print("Total trees: %d" % tree_positions.size())

	if tree_positions.size() > 0:
		print("\nFirst 20 tree positions:")
		for i in range(min(20, tree_positions.size())):
			print("  Tree %d: %s" % [i + 1, tree_positions[i]])

		print("\nX-axis distribution (trees per column):")
		var x_keys = x_distribution.keys()
		x_keys.sort()
		for x in x_keys:
			print("  x=%2d: %d trees" % [x, x_distribution[x]])

		print("\nY-axis distribution (trees per row):")
		var y_keys = y_distribution.keys()
		y_keys.sort()
		for y in y_keys:
			print("  y=%2d: %d trees" % [y, y_distribution[y]])

		# Check if trees are clustered at x=1
		var trees_at_x1 = x_distribution.get(1, 0)
		var total_trees = tree_positions.size()
		var percent_at_x1 = (float(trees_at_x1) / total_trees * 100.0) if total_trees > 0 else 0

		print("\nClustering analysis:")
		print("  Trees at x=1: %d (%.1f%% of total)" % [trees_at_x1, percent_at_x1])

		if percent_at_x1 > 50:
			print("  ⚠️  WARNING: More than 50%% of trees at x=1 - possible bug!")
		elif x_distribution.size() > 10:
			print("  ✓ Trees appear well-distributed across map")
	else:
		print("⚠️  NO TREES GENERATED!")

	print("\n=== DEBUG COMPLETE ===\n")
	quit()
