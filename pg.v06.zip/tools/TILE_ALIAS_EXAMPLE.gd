# Example: How to Create Tile Aliases
#
# This shows the pattern for creating semantic tile names
# that reference the auto-generated TILE_R{row}_C{col} coordinates

class_name TileAliasExample
extends RefCounted

# Import all 200 auto-generated tiles
const GenTiles = GeneratedTileTypes.TileType

# Method 1: Create constants (for direct use)
const MY_TREE_1 = GenTiles.TILE_R3_C13
const MY_TREE_2 = GenTiles.TILE_R3_C14
const MY_GRASS = GenTiles.TILE_R2_C7

# Method 2: Create an enum with explicit values
enum MyTiles {
	TREE_DORMANT_1 = GenTiles.TILE_R3_C13,
	TREE_DORMANT_2 = GenTiles.TILE_R3_C14,
	TREE_DORMANT_3 = GenTiles.TILE_R3_C15,
	TREE_DORMANT_4 = GenTiles.TILE_R3_C16,
	TREE_DORMANT_5 = GenTiles.TILE_R3_C17,
	TREE_DORMANT_6 = GenTiles.TILE_R3_C18,

	TREE_VEG_1 = GenTiles.TILE_R4_C13,
	TREE_VEG_2 = GenTiles.TILE_R4_C14,
	TREE_VEG_3 = GenTiles.TILE_R4_C15,
	TREE_VEG_4 = GenTiles.TILE_R4_C16,
	TREE_VEG_5 = GenTiles.TILE_R4_C17,
	TREE_VEG_6 = GenTiles.TILE_R4_C18,
}

# Then use in code:
func example_usage():
	# Direct constant access
	var tree = MY_TREE_1
	print("My tree tile: ", tree)

	# Enum access
	var dormant_tree = MyTiles.TREE_DORMANT_1
	print("Dormant tree: ", dormant_tree)

	# Get coordinates (works for both!)
	var coords1 = GeneratedTileTypes.get_atlas_coords(MY_TREE_1)
	var coords2 = GeneratedTileTypes.get_atlas_coords(MyTiles.TREE_DORMANT_1)
	print("Coords: ", coords1, " and ", coords2)

# Benefits:
# - Semantic names (TREE_DORMANT_1 vs TILE_R3_C13)
# - Auto-completion in editor
# - Easy to reorganize tiles later
# - All 200 tiles available when needed
