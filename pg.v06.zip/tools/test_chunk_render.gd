extends SceneTree

## Quick visual test for chunk rendering
## Run with: godot --path . -s tools/test_chunk_render.gd
##
## This creates a window showing a single chunk with a gradient pattern

func _initialize():
	print("=" .repeat(60))
	print("  Chunk Rendering Test")
	print("=" .repeat(60))

	# Create a simple scene
	var root_node = Node2D.new()
	root.add_child(root_node)

	# Create terrain source with gradient pattern
	print("\n1. Creating terrain source (gradient pattern)...")
	var terrain_source = ProceduralTerrainSource.new(
		Vector2i(4, 4),  # Small 4×4 chunk map for testing
		ProceduralTerrainSource.Pattern.GRADIENT_X  # East-west gradient
	)
	print("  ✓ Source created: %s" % terrain_source)

	# Load chunk data
	print("\n2. Loading chunk data for chunk (1, 1)...")
	var chunk_data = terrain_source.load_chunk(Vector2i(1, 1))
	if chunk_data:
		print("  ✓ Chunk loaded: %s" % chunk_data)
		print("  - Elevation at (0,0): %.3f" % chunk_data.get_elevation(Vector2i(0, 0)))
		print("  - Elevation at (31,31): %.3f" % chunk_data.get_elevation(Vector2i(31, 31)))
		print("  - Elevation at (63,63): %.3f" % chunk_data.get_elevation(Vector2i(63, 63)))
	else:
		print("  ✗ Failed to load chunk!")
		quit(1)
		return

	# Create chunk visual
	print("\n3. Creating chunk visual...")
	var chunk_visual = ChunkTileMapGroup.new()
	chunk_visual.initialize(Vector2i(1, 1), chunk_data)
	root_node.add_child(chunk_visual)
	print("  ✓ Chunk visual created: %s" % chunk_visual)
	print("  - Position: %s" % chunk_visual.position)
	print("  - Tile count: %d" % chunk_visual.get_tile_count())

	# Center camera on chunk
	print("\n4. Setting up camera...")
	var camera = Camera2D.new()
	camera.enabled = true
	camera.zoom = Vector2(1.0, 1.0)
	camera.position = chunk_visual.position + Vector2(64 * 80, 64 * 40) / 2.0  # Center of chunk
	root_node.add_child(camera)
	print("  ✓ Camera positioned at chunk center")

	print("\n" + "=" .repeat(60))
	print("  Rendering chunk...")
	print("  Press ESC or close window to exit")
	print("=" .repeat(60))

	# Wait for a few frames to ensure rendering
	await root.process_frame
	await root.process_frame

	print("\n✓ Chunk rendering test complete!")
	print("  If you see a gradient pattern, rendering works!")

func _process(_delta):
	# Exit on ESC key
	if Input.is_action_just_pressed("ui_cancel"):
		print("\nExiting...")
		quit(0)
