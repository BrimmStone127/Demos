@tool
extends EditorScript

# Generates a reference sheet showing all tiles with coordinate labels
# Run from Godot editor: File > Run

const TILESET_PATH = "res://assets/big_iso_tileset.png"
const OUTPUT_PATH = "user://tileset_reference.png"
const TILE_SIZE = Vector2i(160, 160)
const GRID_SIZE = Vector2i(20, 10)  # 20 columns, 10 rows
const LABEL_HEIGHT = 30  # Space for coordinate label

func _run():
	print("=== Tileset Reference Generator ===")

	# Load the tileset
	var tileset_texture = load(TILESET_PATH) as Texture2D
	if not tileset_texture:
		print("ERROR: Could not load tileset at: ", TILESET_PATH)
		return

	var tileset_image = tileset_texture.get_image()
	print("Loaded tileset: ", tileset_image.get_width(), "x", tileset_image.get_height())
	print("Creating reference sheet with coordinate labels...")

	# Create output image with extra space for labels
	var output_width = GRID_SIZE.x * TILE_SIZE.x
	var output_height = GRID_SIZE.y * (TILE_SIZE.y + LABEL_HEIGHT)
	var output_image = Image.create(output_width, output_height, false, Image.FORMAT_RGBA8)
	output_image.fill(Color(0.2, 0.2, 0.2, 1.0))  # Dark gray background

	# Copy tiles and add coordinate labels
	for row in range(GRID_SIZE.y):
		for col in range(GRID_SIZE.x):
			var source_rect = Rect2i(
				col * TILE_SIZE.x,
				row * TILE_SIZE.y,
				TILE_SIZE.x,
				TILE_SIZE.y
			)

			var dest_pos = Vector2i(
				col * TILE_SIZE.x,
				row * (TILE_SIZE.y + LABEL_HEIGHT) + LABEL_HEIGHT
			)

			# Blit the tile
			output_image.blit_rect(tileset_image, source_rect, dest_pos)

			# Add coordinate label background
			var label_rect = Rect2i(
				col * TILE_SIZE.x,
				row * (TILE_SIZE.y + LABEL_HEIGHT),
				TILE_SIZE.x,
				LABEL_HEIGHT
			)
			output_image.fill_rect(label_rect, Color(0.1, 0.1, 0.1, 1.0))

			# Add a border around each tile
			_draw_border(output_image,
				col * TILE_SIZE.x,
				row * (TILE_SIZE.y + LABEL_HEIGHT),
				TILE_SIZE.x,
				TILE_SIZE.y + LABEL_HEIGHT,
				Color(0.5, 0.5, 0.5, 0.5))

	# Save the reference sheet
	var err = output_image.save_png(OUTPUT_PATH)
	if err == OK:
		print("SUCCESS! Reference sheet saved to:")
		print(OUTPUT_PATH)
		print("")
		print("On Linux: ~/.local/share/godot/app_userdata/PlanetGame/tileset_reference.png")
		print("")
		print("Coordinates are shown as: (col, row)")
		print("Example: (15, 3) = column 15, row 3")
		print("         (0, 0) = top-left corner")
		print("         (19, 9) = bottom-right corner")
	else:
		print("ERROR: Could not save reference sheet (error code: ", err, ")")

	print("")
	print("=== Complete ===")

func _draw_border(image: Image, x: int, y: int, width: int, height: int, color: Color):
	# Draw a simple border rectangle
	for i in range(width):
		image.set_pixel(x + i, y, color)  # Top
		image.set_pixel(x + i, y + height - 1, color)  # Bottom
	for i in range(height):
		image.set_pixel(x, y + i, color)  # Left
		image.set_pixel(x + width - 1, y + i, color)  # Right
