extends SceneTree

## Tool script: generates a pre-baked overview PNG from terrain data.
## Run: $GODOT --path $(wslpath -w .) --headless -s tools/generate_overview.gd
##
## Loads all chunk data from PNGTerrainSource, populates forest features,
## generates per-chunk 64x64 thumbnails, composites into one overview image,
## and saves to assets/terrain/overview.png.

const CHUNK_SIZE := 64

func _init():
	var start_ms := Time.get_ticks_msec()

	# Load terrain source
	var png_path := "res://assets/terrain/reference/full_map_8bit.png"
	var water_mask_path := "res://assets/terrain/reference/water_mask.png"
	var flow_dir_path := "res://assets/terrain/reference/flow_direction.png"

	print("Loading terrain source...")
	var terrain := PNGTerrainSource.new(png_path, true, water_mask_path, flow_dir_path)
	var bounds: Rect2i = terrain.get_bounds()
	print("Terrain bounds: %s (%d x %d chunks)" % [bounds, bounds.size.x, bounds.size.y])

	var img_w: int = bounds.size.x * CHUNK_SIZE
	var img_h: int = bounds.size.y * CHUNK_SIZE
	print("Overview image size: %d x %d pixels" % [img_w, img_h])

	var overview := Image.create(img_w, img_h, false, Image.FORMAT_RGB8)
	var total_chunks: int = bounds.size.x * bounds.size.y
	var loaded := 0

	for cy in range(bounds.position.y, bounds.position.y + bounds.size.y):
		for cx in range(bounds.position.x, bounds.position.x + bounds.size.x):
			var chunk_pos := Vector2i(cx, cy)
			var chunk_data: ChunkTileData = terrain.load_chunk(chunk_pos)
			if chunk_data == null:
				loaded += 1
				continue

			# Populate forest features (same logic as PlanetMapSystem)
			_populate_forest(chunk_data)

			# Generate thumbnail image (64x64)
			var thumb := _generate_chunk_thumbnail(chunk_data)

			# Blit into overview at correct position
			var dest := Vector2i(
				(cx - bounds.position.x) * CHUNK_SIZE,
				(cy - bounds.position.y) * CHUNK_SIZE)
			overview.blit_rect(thumb, Rect2i(Vector2i.ZERO, Vector2i(CHUNK_SIZE, CHUNK_SIZE)), dest)

			loaded += 1
			if loaded % 100 == 0:
				print("  %d / %d chunks processed..." % [loaded, total_chunks])

	# Save overview
	var output_path := "res://assets/terrain/overview.png"
	var abs_path := ProjectSettings.globalize_path(output_path)
	var err := overview.save_png(abs_path)
	if err == OK:
		print("Overview saved to %s (%d x %d)" % [output_path, img_w, img_h])
	else:
		print("ERROR: Failed to save overview: %d" % err)

	# Generate heatmap overview (FLIR elevation colors)
	print("Generating heatmap overview...")
	var heatmap := Image.create(img_w, img_h, false, Image.FORMAT_RGB8)
	loaded = 0
	for cy in range(bounds.position.y, bounds.position.y + bounds.size.y):
		for cx in range(bounds.position.x, bounds.position.x + bounds.size.x):
			var chunk_pos := Vector2i(cx, cy)
			var chunk_data2: ChunkTileData = terrain.load_chunk(chunk_pos)
			if chunk_data2 == null:
				loaded += 1
				continue
			var thumb := _generate_heatmap_thumbnail(chunk_data2)
			var dest := Vector2i(
				(cx - bounds.position.x) * CHUNK_SIZE,
				(cy - bounds.position.y) * CHUNK_SIZE)
			heatmap.blit_rect(thumb, Rect2i(Vector2i.ZERO, Vector2i(CHUNK_SIZE, CHUNK_SIZE)), dest)
			loaded += 1
			if loaded % 100 == 0:
				print("  %d / %d chunks processed..." % [loaded, total_chunks])
	var heatmap_path := "res://assets/terrain/overview_heatmap.png"
	err = heatmap.save_png(ProjectSettings.globalize_path(heatmap_path))
	if err == OK:
		print("Heatmap overview saved to %s" % heatmap_path)
	else:
		print("ERROR: Failed to save heatmap overview: %d" % err)

	# Generate no-trees overview (terrain only, no forest canopy)
	print("Generating no-trees overview...")
	var no_trees := Image.create(img_w, img_h, false, Image.FORMAT_RGB8)
	loaded = 0
	for cy in range(bounds.position.y, bounds.position.y + bounds.size.y):
		for cx in range(bounds.position.x, bounds.position.x + bounds.size.x):
			var chunk_pos := Vector2i(cx, cy)
			var chunk_data3: ChunkTileData = terrain.load_chunk(chunk_pos)
			if chunk_data3 == null:
				loaded += 1
				continue
			var thumb := _generate_no_trees_thumbnail(chunk_data3)
			var dest := Vector2i(
				(cx - bounds.position.x) * CHUNK_SIZE,
				(cy - bounds.position.y) * CHUNK_SIZE)
			no_trees.blit_rect(thumb, Rect2i(Vector2i.ZERO, Vector2i(CHUNK_SIZE, CHUNK_SIZE)), dest)
			loaded += 1
			if loaded % 100 == 0:
				print("  %d / %d chunks processed..." % [loaded, total_chunks])
	var no_trees_path := "res://assets/terrain/overview_no_trees.png"
	err = no_trees.save_png(ProjectSettings.globalize_path(no_trees_path))
	if err == OK:
		print("No-trees overview saved to %s" % no_trees_path)
	else:
		print("ERROR: Failed to save no-trees overview: %d" % err)

	var elapsed := (Time.get_ticks_msec() - start_ms) / 1000.0
	print("Done in %.1f seconds." % elapsed)
	quit()


func _populate_forest(chunk_data: ChunkTileData) -> void:
	var chunk_origin := chunk_data.chunk_pos * CHUNK_SIZE
	for local_y in range(CHUNK_SIZE):
		for local_x in range(CHUNK_SIZE):
			var flat_idx: int = local_y * CHUNK_SIZE + local_x
			var tile_type: int = chunk_data.tile_types[flat_idx]

			if tile_type == PlanetMapTileConfig.TileType.FRESH_WATER:
				continue

			var local_pos := Vector2i(local_x, local_y)
			var world_pos := chunk_origin + local_pos

			var feature_id: int
			if ForestSpecies.is_dead_tree_position(world_pos):
				var dead_result := ForestSpecies.pick_dead_tile(world_pos)
				feature_id = dead_result[0]
			else:
				feature_id = ForestSpecies.pick_live_tile(world_pos)
			chunk_data.set_feature(local_pos, feature_id)

			var chance := ForestSpecies.RASPBERRY_CHANCE_DEAD if \
					ForestSpecies.is_dead_tree(feature_id) \
					else ForestSpecies.RASPBERRY_CHANCE_LIVE
			if ForestSpecies.is_raspberry_position(world_pos, chance):
				chunk_data.set_understory(local_pos, ForestSpecies.RASPBERRY_BUSH)


## Generate heatmap (FLIR) thumbnail — elevation mapped to dark blue-to-white gradient.
func _generate_heatmap_thumbnail(chunk_data: ChunkTileData) -> Image:
	var img := Image.create(CHUNK_SIZE, CHUNK_SIZE, false, Image.FORMAT_RGB8)
	for y in CHUNK_SIZE:
		var row_offset := y * CHUNK_SIZE
		for x in CHUNK_SIZE:
			var idx := row_offset + x
			var tt: int = chunk_data.tile_types[idx]
			var color: Color
			if tt == PlanetMapTileConfig.TileType.FRESH_WATER:
				color = ChunkTileData.FLIR_COLOR_LOW
			else:
				color = ChunkTileData.get_flir_color(chunk_data.elevations[idx])
			img.set_pixel(x, y, color)
	return img

## Generate no-trees thumbnail — terrain colors only, no forest canopy.
func _generate_no_trees_thumbnail(chunk_data: ChunkTileData) -> Image:
	var img := Image.create(CHUNK_SIZE, CHUNK_SIZE, false, Image.FORMAT_RGB8)
	var default_color := Color(0.5, 0.5, 0.5)
	for y in CHUNK_SIZE:
		var row_offset := y * CHUNK_SIZE
		for x in CHUNK_SIZE:
			var idx := row_offset + x
			var tt: int = chunk_data.tile_types[idx]
			var color: Color = ChunkTileData.THUMBNAIL_COLORS.get(tt, default_color)
			if tt == PlanetMapTileConfig.TileType.FRESH_WATER:
				img.set_pixel(x, y, color)
			else:
				var brightness: float = PlanetMapTileConfig.get_elevation_brightness(chunk_data.render_layers[idx])
				img.set_pixel(x, y, Color(color.r * brightness, color.g * brightness, color.b * brightness))
	return img

## Generate a 64x64 thumbnail Image for one chunk.
## Mirrors ChunkTileData._generate_thumbnail() but returns raw Image (no ImageTexture).
func _generate_chunk_thumbnail(chunk_data: ChunkTileData) -> Image:
	var forest_pattern: Image = null
	var tex := load("res://assets/terrain/forest_lod_pattern.png") as Texture2D
	if tex:
		forest_pattern = tex.get_image()

	var img := Image.create(CHUNK_SIZE, CHUNK_SIZE, false, Image.FORMAT_RGB8)
	var default_color := Color(0.5, 0.5, 0.5)
	var pat_w: int = forest_pattern.get_width() if forest_pattern else 1
	var pat_h: int = forest_pattern.get_height() if forest_pattern else 1

	for y in CHUNK_SIZE:
		var row_offset := y * CHUNK_SIZE
		var abs_y: int = chunk_data.chunk_pos.y * CHUNK_SIZE + y
		for x in CHUNK_SIZE:
			var idx := row_offset + x
			var tt: int = chunk_data.tile_types[idx]
			var color: Color

			if tt == PlanetMapTileConfig.TileType.FRESH_WATER:
				color = ChunkTileData.THUMBNAIL_COLORS.get(tt, default_color)
			elif forest_pattern != null and chunk_data.features.has(Vector2i(x, y)):
				var abs_x: int = chunk_data.chunk_pos.x * CHUNK_SIZE + x
				var px: int = abs_x % pat_w
				var py: int = abs_y % pat_h
				color = forest_pattern.get_pixel(px, py)
			else:
				color = ChunkTileData.THUMBNAIL_COLORS.get(tt, default_color)

			var is_water := (tt == PlanetMapTileConfig.TileType.FRESH_WATER)
			if is_water:
				img.set_pixel(x, y, color)
			else:
				var brightness: float = PlanetMapTileConfig.get_elevation_brightness(chunk_data.render_layers[idx])
				img.set_pixel(x, y, Color(color.r * brightness, color.g * brightness, color.b * brightness))
	return img
