@tool
extends EditorScript

# Tool to extract all tiles from the big_iso_tileset.png and save them with coordinate labels
# Run this from the Godot editor: File > Run

const TILESET_PATH = "res://assets/big_iso_tileset.png"
const OUTPUT_DIR = "res://tools/tileset_output/"
const TILE_SIZE = Vector2i(160, 160)
const GRID_SIZE = Vector2i(20, 10)  # 20 columns, 10 rows

func _run():
	print("=== Tileset Extractor ===")

	# Create output directory
	var dir = DirAccess.open("res://tools/")
	if not dir.dir_exists("tileset_output"):
		dir.make_dir("tileset_output")

	# Load the tileset image
	var tileset_texture = load(TILESET_PATH) as Texture2D
	if not tileset_texture:
		print("ERROR: Could not load tileset at: ", TILESET_PATH)
		return

	var tileset_image = tileset_texture.get_image()
	print("Loaded tileset: ", tileset_image.get_width(), "x", tileset_image.get_height())
	print("Grid: ", GRID_SIZE.x, " columns x ", GRID_SIZE.y, " rows")
	print("Tile size: ", TILE_SIZE.x, "x", TILE_SIZE.y)
	print("")

	# Extract each tile
	var tile_count = 0
	for row in range(GRID_SIZE.y):
		for col in range(GRID_SIZE.x):
			var source_rect = Rect2i(
				col * TILE_SIZE.x,
				row * TILE_SIZE.y,
				TILE_SIZE.x,
				TILE_SIZE.y
			)

			# Extract the tile
			var tile_image = Image.create(TILE_SIZE.x, TILE_SIZE.y, false, Image.FORMAT_RGBA8)
			tile_image.blit_rect(tileset_image, source_rect, Vector2i.ZERO)

			# Save with coordinates in filename
			var filename = "tile_%02d_%02d.png" % [col, row]
			var save_path = OUTPUT_DIR + filename
			var err = tile_image.save_png(save_path.replace("res://", "user://"))

			if err == OK:
				tile_count += 1
				# Print tiles that aren't completely transparent (likely have content)
				if not _is_transparent(tile_image):
					print("Saved: col=%d, row=%d -> %s" % [col, row, filename])
			else:
				print("ERROR saving: ", filename, " (error code: ", err, ")")

	print("")
	print("=== Complete ===")
	print("Extracted ", tile_count, " tiles to: ", OUTPUT_DIR)
	print("Files are named: tile_COL_ROW.png (e.g., tile_15_03.png = column 15, row 3)")
	print("")
	print("NOTE: Files saved to user:// directory")
	print("On Linux: ~/.local/share/godot/app_userdata/PlanetGame/tools/tileset_output/")

func _is_transparent(image: Image) -> bool:
	# Quick check if image is mostly/completely transparent
	var sample_points = [
		Vector2i(TILE_SIZE.x / 2, TILE_SIZE.y / 2),  # Center
		Vector2i(TILE_SIZE.x / 4, TILE_SIZE.y / 4),  # Top-left quarter
		Vector2i(3 * TILE_SIZE.x / 4, 3 * TILE_SIZE.y / 4),  # Bottom-right quarter
	]

	for point in sample_points:
		var pixel = image.get_pixelv(point)
		if pixel.a > 0.1:  # Has some opacity
			return false

	return true
