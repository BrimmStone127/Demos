# Example: How to Integrate Palette Swapping into PlanetGame
#
# This shows different ways to add palette swapping to the game.
# Choose the approach that best fits your needs.

extends RefCounted

## OPTION 1: Global Setting (Simple)
## Add to GameSettings or similar configuration system

# In your settings/config class:
class GameSettings:
	static var colorblind_mode: String = "none"  # "none", "deuteranopia", "protanopia", "tritanopia"

# In PlanetMapTileManager._create_tilemap():
func _create_tilemap() -> TileMap:
	var tilemap = TileMap.new()
	tilemap.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	tilemap.tile_set = _create_tileset()

	# Apply palette swap if enabled
	if GameSettings.colorblind_mode != "none":
		var swapper = _get_swapper_for_mode(GameSettings.colorblind_mode)
		if swapper:
			swapper.apply_to_tilemap(tilemap)

	return tilemap

func _get_swapper_for_mode(mode: String) -> PaletteSwapper:
	match mode:
		"deuteranopia":
			return PaletteSwapper.create_deuteranopia_friendly()
		"protanopia":
			return PaletteSwapper.create_protanopia_friendly()
		"tritanopia":
			return PaletteSwapper.create_tritanopia_friendly()
		_:
			return null


## OPTION 2: Options Menu Integration
## Add to OptionsMenu.gd

# In OptionsMenu.gd:
var _colorblind_options = ["None", "Deuteranopia", "Protanopia", "Tritanopia"]
var _colorblind_dropdown: OptionButton

func _setup_accessibility_section():
	var section = VBoxContainer.new()

	# Colorblind mode dropdown
	var label = Label.new()
	label.text = "Colorblind Mode:"
	section.add_child(label)

	_colorblind_dropdown = OptionButton.new()
	for option in _colorblind_options:
		_colorblind_dropdown.add_item(option)
	_colorblind_dropdown.item_selected.connect(_on_colorblind_mode_changed)
	section.add_child(_colorblind_dropdown)

	# Load saved setting
	var current_mode = GameSettings.colorblind_mode
	var index = _colorblind_options.find(current_mode.capitalize())
	if index >= 0:
		_colorblind_dropdown.selected = index

func _on_colorblind_mode_changed(index: int):
	var mode = _colorblind_options[index].to_lower()
	GameSettings.colorblind_mode = mode

	# Notify user that they need to revisit planet maps for changes to apply
	# (or implement hot-reloading if desired)
	print("Colorblind mode set to: ", mode)
	print("Changes will apply to newly loaded planet maps")


## OPTION 3: Per-Planet Customization
## Allow different palettes for different planets

# Add to PlanetMapView or similar:
var _custom_palette: String = "default"

func setup_planet_view(planet, probe_sys, ui_manager, star_provider, tm):
	# ... existing setup code ...

	# Check if this planet has a custom palette preference
	var planet_id = probe_sys._get_stable_planet_id(planet)
	var saved_palette = _load_planet_palette_preference(planet_id)
	if saved_palette:
		_custom_palette = saved_palette

	# Apply palette when creating map
	_setup_map_with_palette(planet, probe_sys, _custom_palette)

func _setup_map_with_palette(planet, probe_sys, palette_name: String):
	# During map creation, pass palette preference to PlanetMapSystem
	# This would require modifying PlanetMapTileManager to accept palette parameter
	pass

func _save_planet_palette_preference(planet_id: String, palette: String):
	# Save to discovered_planets data
	if probe_sys and probe_sys.discovered_planets.has(planet_id):
		probe_sys.discovered_planets[planet_id]["custom_palette"] = palette

func _load_planet_palette_preference(planet_id: String) -> String:
	if probe_sys and probe_sys.discovered_planets.has(planet_id):
		return probe_sys.discovered_planets[planet_id].get("custom_palette", "default")
	return "default"


## OPTION 4: Sandbox Testing
## Add palette selector to sandbox for quick testing

# In Sandbox.gd, add a dropdown:
var _palette_selector: OptionButton

func _setup_palette_controls():
	var container = HBoxContainer.new()

	var label = Label.new()
	label.text = "Palette:"
	container.add_child(label)

	_palette_selector = OptionButton.new()
	_palette_selector.add_item("Default")
	_palette_selector.add_item("Deuteranopia")
	_palette_selector.add_item("Protanopia")
	_palette_selector.add_item("Tritanopia")
	_palette_selector.add_item("High Contrast")
	_palette_selector.item_selected.connect(_on_palette_selected)
	container.add_child(_palette_selector)

	# Add to your UI somewhere
	# control_panel.add_child(container)

func _on_palette_selected(index: int):
	var swapper = null

	match index:
		1:  # Deuteranopia
			swapper = PaletteSwapper.create_deuteranopia_friendly()
		2:  # Protanopia
			swapper = PaletteSwapper.create_protanopia_friendly()
		3:  # Tritanopia
			swapper = PaletteSwapper.create_tritanopia_friendly()
		4:  # High Contrast
			swapper = PaletteSwapper.create_high_contrast()
		_:  # Default
			# Remove palette swapping
			_remove_palette_swap()
			return

	# Apply to all tilemaps in the map_viewport
	_apply_palette_to_maps(swapper)

func _apply_palette_to_maps(swapper: PaletteSwapper):
	# Get the PlanetMapSystem from MapViewport
	# and apply swapper to its tilemaps
	if map_viewport and map_viewport._planet_map_system:
		var tile_manager = map_viewport._planet_map_system.tile_manager
		if tile_manager:
			# Apply to terrain layer
			if tile_manager._terrain_tilemap:
				swapper.apply_to_tilemap(tile_manager._terrain_tilemap)

			# Apply to all elevation layers
			for layer in tile_manager._elevation_tilemaps.values():
				swapper.apply_to_tilemap(layer)

func _remove_palette_swap():
	# Remove material from tilemaps to restore default colors
	if map_viewport and map_viewport._planet_map_system:
		var tile_manager = map_viewport._planet_map_system.tile_manager
		if tile_manager:
			if tile_manager._terrain_tilemap:
				tile_manager._terrain_tilemap.material = null
			for layer in tile_manager._elevation_tilemaps.values():
				layer.material = null


## OPTION 5: Command-Line Testing
## Quick test for development

# Add to Main.gd or similar:
func _ready():
	# Check for command-line palette override
	var args = OS.get_cmdline_args()
	for arg in args:
		if arg.begins_with("--palette="):
			var palette = arg.split("=")[1]
			GameSettings.colorblind_mode = palette
			print("Palette override: ", palette)

# Usage:
# "$GODOT" --path "..." -- --palette=deuteranopia


## RECOMMENDED APPROACH

# Start with Option 1 (Global Setting) for simplicity:
# 1. Add GameSettings.colorblind_mode variable
# 2. Modify PlanetMapTileManager._create_tilemap() to check setting
# 3. Later, add Option 2 (Options Menu) for user control

# Benefits:
# - Simple implementation
# - Works immediately
# - Easy to test
# - Can be enhanced with UI later
