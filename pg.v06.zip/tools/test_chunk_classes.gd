extends SceneTree

func _initialize():
	print("Testing chunk system classes...")

	# Test ChunkTileData
	print("\n1. Testing ChunkTileData...")
	var chunk = ChunkTileData.new(Vector2i(5, 10))
	print("  - Created chunk at position:", chunk.chunk_pos)
	print("  - Absolute bounds:", chunk.get_absolute_bounds())
	print("  - Chunk elevation at (0,0):", chunk.get_elevation(Vector2i(0, 0)))

	# Test TerrainDataSource
	print("\n2. Testing ProceduralTerrainSource...")
	var source = ProceduralTerrainSource.new(Vector2i(10, 10), ProceduralTerrainSource.Pattern.GRADIENT_X)
	print("  - Created source:", source)
	print("  - Bounds:", source.get_bounds())
	var loaded_chunk = source.load_chunk(Vector2i(2, 3))
	print("  - Loaded chunk:", loaded_chunk)
	print("  - Chunk elevation at (10,10):", loaded_chunk.get_elevation(Vector2i(10, 10)))

	# Test PNGTerrainSource
	print("\n3. Testing PNGTerrainSource...")
	var png_source = PNGTerrainSource.new("res://assets/terrain/reference/full_map_8bit.png")
	if png_source.is_loaded():
		print("  - PNG loaded successfully!")
		print("  - PNG size:", png_source.get_png_size())
		print("  - Bounds:", png_source.get_bounds())
	else:
		print("  - PNG not found (this is OK for testing)")

	print("\n✓ All chunk classes instantiated successfully!")
	quit(0)
