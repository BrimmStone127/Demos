extends Node2D
## Simple planet map generation with screenshot export
## This bypasses the Sandbox UI entirely and works directly with the generator
##
## Usage:
##   # Visual mode with screenshot
##   "$GODOT" --path "$(wslpath -w /home/clay/projects/PlanetGame)" -s tools/generate_planet_test.gd -- tropical
##
##   # Will quit after 2 seconds and save screenshot

const TILE_SIZE = Vector2(160, 80)

# Scenario configurations
const SCENARIOS = {
	"tropical": {
		"planet_type": PlanetEnums.PlanetType.SUPER_EARTH,
		"climate": "HOT",
		"atmosphere": "THICK",
		"water": 0.65,
		"ice": 0.0,
		"seed": 12345
	},
	"frozen": {
		"planet_type": PlanetEnums.PlanetType.ROCKY_MEDIUM,
		"climate": "FROZEN",
		"atmosphere": "THIN",
		"water": 0.05,
		"ice": 0.80,
		"seed": 54321
	},
	"desert": {
		"planet_type": PlanetEnums.PlanetType.ROCKY_SMALL,
		"climate": "SCORCHING",
		"atmosphere": "THIN",
		"water": 0.02,
		"ice": 0.0,
		"seed": 99999
	},
	"earthlike": {
		"planet_type": PlanetEnums.PlanetType.ROCKY_MEDIUM,
		"climate": "TEMPERATE",
		"atmosphere": "MODERATE",
		"water": 0.71,
		"ice": 0.03,
		"seed": 11111
	}
}

var generator: PlanetMapGenerator
var tile_manager: PlanetMapTileManager
var scenario_name: String = "earthlike"
var output_file: String = ""

func _ready():
	print("\n=== Planet Map Generator Test ===\n")

	# Parse arguments
	var args = OS.get_cmdline_user_args()
	if args.size() > 0:
		scenario_name = args[0]
	if args.size() > 1:
		output_file = args[1]
	else:
		output_file = "user://test_planet_%s.png" % scenario_name

	# Validate scenario
	if not SCENARIOS.has(scenario_name):
		printerr("Unknown scenario: %s" % scenario_name)
		printerr("Available: %s" % ", ".join(SCENARIOS.keys()))
		get_tree().quit(1)
		return

	print("Scenario: %s" % scenario_name)
	print("Output: %s" % output_file)
	print("")

	# Create generator
	generator = PlanetMapGenerator.new()
	tile_manager = PlanetMapTileManager.new()
	add_child(tile_manager)

	# Generate planet
	_generate_planet()

	# Wait for rendering to settle
	await get_tree().create_timer(2.0).timeout

	# Capture screenshot
	_capture_screenshot()

	# Export state
	_export_state()

	print("\n✓ Test complete!")
	get_tree().quit()

func _generate_planet():
	var config = SCENARIOS[scenario_name]

	print("Creating planet...")

	# Create planet
	var props = {
		"scale_range": Vector2(0.062, 0.074),
		"colors": [Color(0.3, 0.6, 0.7)]
	}

	var planet = Planet.new(
		null,
		100.0,  # semi_major_axis
		0.02,   # eccentricity
		config.planet_type,
		props,
		true    # has_atmosphere
	)

	planet.climate_type = config.climate
	planet.atmosphere_type = config.atmosphere
	planet.surface_liquids = {
		"water": config.water,
		"ice": config.ice
	}

	# Create probe data
	var probe_data = {
		"habitability_score": 0.5,
		"atmosphere_type": config.atmosphere,
		"surface_temperature": 288.0,
		"geological_activity": "MODERATE",
		"climate_type": config.climate,
		"surface_liquids": planet.surface_liquids,
		"surface_composition": {"silicates": 0.5, "metals": 0.2}
	}

	print("Generating map (seed: %d)..." % config.seed)

	# Generate map
	var tiles = generator.generate_map(planet, probe_data, config.seed)

	print("  Map size: %d x %d" % [tiles.size(), tiles[0].size() if tiles.size() > 0 else 0])

	# Render tiles
	_render_tiles(tiles)

	print("✓ Generation complete")

func _render_tiles(tiles: Array):
	print("Rendering tiles...")

	# Initialize tile manager
	tile_manager.initialize()

	var tile_count = 0

	# Render all tiles
	for x in range(tiles.size()):
		for y in range(tiles[x].size()):
			var tile: MapTile = tiles[x][y]
			if tile and tile.type != null:
				var cell = Vector2i(x, y)
				var elevation = tile.elevation

				# Get or create tilemap for this elevation
				var tilemap = tile_manager.get_tilemap_for_elevation(elevation)
				if tilemap:
					# Get atlas coords for this tile type
					var atlas_coords = PlanetMapTileConfig.get_atlas_coords(tile.type)
					if atlas_coords != Vector2i(-1, -1):
						tilemap.set_cell(
							PlanetMapTileConfig.TILEMAP_LAYER_TERRAIN,
							cell,
							tile_manager.tile_map_source_id,
							atlas_coords,
							0
						)
						tile_count += 1

	print("  Rendered %d tiles" % tile_count)

func _capture_screenshot():
	print("\nCapturing screenshot...")

	var viewport = get_viewport()
	if not viewport:
		printerr("ERROR: No viewport available")
		return

	# Wait one more frame to ensure rendering is complete
	await get_tree().process_frame

	var img = viewport.get_texture().get_image()
	if not img:
		printerr("ERROR: Failed to get viewport image")
		return

	# Convert user:// path to absolute
	var save_path = ProjectSettings.globalize_path(output_file)
	print("  Saving to: %s" % save_path)

	var err = img.save_png(save_path)
	if err != OK:
		printerr("ERROR: Failed to save screenshot (error %d)" % err)
	else:
		print("✓ Screenshot saved")

func _export_state():
	print("\nExporting state...")

	var state = {
		"scenario": scenario_name,
		"config": SCENARIOS[scenario_name],
		"timestamp": Time.get_datetime_string_from_system(),
		"output_file": output_file
	}

	var state_file = output_file.replace(".png", "_state.json")
	var save_path = ProjectSettings.globalize_path(state_file)

	var file = FileAccess.open(save_path, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(state, "\t"))
		file.close()
		print("✓ State saved to: %s" % save_path)
	else:
		printerr("ERROR: Failed to save state file")
