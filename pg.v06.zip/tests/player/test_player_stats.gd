extends "res://tests/test_base.gd"

## Tests for CharacterStats resource
## Verifies stat management, modification, and signaling

var stats: CharacterStats

func before_each():
	stats = CharacterStats.new()

func test_set_and_get_stat():
	stats.set_stat("strength", 10)
	assert_eq(stats.get_stat("strength"), 10, "Should store and retrieve stat")

func test_get_stat_default():
	assert_eq(stats.get_stat("nonexistent", 5), 5, "Should return default if stat not found")
	assert_eq(stats.get_stat("nonexistent"), 0, "Should return 0 if no default provided")

func test_modify_stat():
	stats.set_stat("agility", 5)
	stats.modify_stat("agility", 3)
	assert_eq(stats.get_stat("agility"), 8, "Should add delta to stat")
	
	stats.modify_stat("agility", -2)
	assert_eq(stats.get_stat("agility"), 6, "Should subtract delta from stat")

func test_has_stat():
	assert_false(stats.has_stat("luck"), "Initially should not have luck")
	stats.set_stat("luck", 7)
	assert_true(stats.has_stat("luck"), "Should have luck after setting")

func test_get_all_stats():
	stats.set_stat("a", 1)
	stats.set_stat("b", 2)
	
	var all = stats.get_all_stats()
	assert_eq(all.size(), 2, "Should return all stats")
	assert_eq(all.a, 1)
	assert_eq(all.b, 2)

func test_get_stat_names():
	stats.set_stat("a", 1)
	stats.set_stat("b", 2)
	
	var names = stats.get_stat_names()
	assert_eq(names.size(), 2, "Should return all stat names")
	assert_true("a" in names)
	assert_true("b" in names)

func test_meets_requirement():
	stats.set_stat("intel", 10)
	
	assert_true(stats.meets_requirement("intel", 5), "Should meet lower requirement")
	assert_true(stats.meets_requirement("intel", 10), "Should meet exact requirement")
	assert_false(stats.meets_requirement("intel", 15), "Should not meet higher requirement")
	assert_false(stats.meets_requirement("nonexistent", 1), "Should not meet requirement for missing stat")

func test_define_stat():
	stats.define_stat("stamina", "Stamina Points", "Physical endurance", 0, 100)
	stats.set_stat("stamina", 150)
	
	# Current implementation doesn't clamp in set_stat yet, just stores meta
	# But we can verify it stores the meta
	assert_eq(stats.get_stat("stamina"), 150, "Should store stat value")

func test_stat_changed_signal():
	var signal_data = {"emitted": false, "name": "", "old": -1, "new": -1}
	stats.stat_changed.connect(func(n, o, v): 
		signal_data.emitted = true
		signal_data.name = n
		signal_data.old = o
		signal_data.new = v
	)
	
	stats.set_stat("luck", 7)
	
	assert_true(signal_data.emitted, "Should emit signal on stat change")
	assert_eq(signal_data.name, "luck", "Should pass stat name")
	assert_eq(signal_data.old, 0, "Should pass old value")
	assert_eq(signal_data.new, 7, "Should pass new value")

func test_serialization():
	stats.set_stat("luck", 7)
	stats.set_stat("wisdom", 12)
	
	var data = stats.to_dict()
	
	var new_stats = CharacterStats.new()
	new_stats.from_dict(data)
	assert_eq(new_stats.get_stat("luck"), 7, "Should restore luck")
	assert_eq(new_stats.get_stat("wisdom"), 12, "Should restore wisdom")

func test_create_factory():
	var initial = {"str": 10, "dex": 12}
	var new_stats = CharacterStats.create(initial)
	
	assert_eq(new_stats.get_stat("str"), 10)
	assert_eq(new_stats.get_stat("dex"), 12)
