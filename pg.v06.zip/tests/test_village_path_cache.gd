extends "res://tests/test_base.gd"

## Tests for VillagePathCache route caching and trail traversal tracking.
## Uses TerrainPathfinder with null planet_map_system for uniform-cost paths.


func _make_cache() -> VillagePathCache:
	var pf := TerrainPathfinder.new(null)
	return VillagePathCache.new(pf)


func test_get_path_computes_and_caches():
	var cache := _make_cache()
	var path := cache.get_path(Vector2i(0, 0), Vector2i(5, 0))
	assert_true(path.size() > 0, "Should compute a path")
	assert_eq(path[0], Vector2i(0, 0), "Path starts at start")
	assert_eq(path[path.size() - 1], Vector2i(5, 0), "Path ends at end")
	assert_eq(cache.get_route_count(), 1, "One route cached")


func test_get_path_cache_hit():
	var cache := _make_cache()
	var path1 := cache.get_path(Vector2i(0, 0), Vector2i(3, 3))
	var path2 := cache.get_path(Vector2i(0, 0), Vector2i(3, 3))
	assert_eq(path1.size(), path2.size(), "Cached path same size")
	assert_eq(cache.get_route_count(), 1, "Still one route after cache hit")


func test_different_routes_cached_separately():
	var cache := _make_cache()
	cache.get_path(Vector2i(0, 0), Vector2i(20, 0))
	cache.get_path(Vector2i(0, 0), Vector2i(0, 20))
	assert_eq(cache.get_route_count(), 2, "Two different routes cached")


func test_record_traversal():
	var cache := _make_cache()
	var pos := Vector2i(5, 5)
	cache.record_traversal(pos)
	cache.record_traversal(pos)
	cache.record_traversal(pos)
	assert_eq(cache.get_traversal_count(pos), 3, "Three traversals recorded")


func test_get_traversal_count_unvisited():
	var cache := _make_cache()
	assert_eq(cache.get_traversal_count(Vector2i(99, 99)), 0, "Unvisited tile has zero count")


func test_get_all_trail_tiles():
	var cache := _make_cache()
	cache.record_traversal(Vector2i(1, 1))
	cache.record_traversal(Vector2i(2, 2))
	cache.record_traversal(Vector2i(1, 1))
	var trails := cache.get_all_trail_tiles()
	assert_eq(trails.size(), 2, "Two tiles with trail data")
	assert_eq(trails[Vector2i(1, 1)], 2, "First tile traversed twice")
	assert_eq(trails[Vector2i(2, 2)], 1, "Second tile traversed once")


func test_invalidate_routes_to():
	var cache := _make_cache()
	cache.get_path(Vector2i(0, 0), Vector2i(20, 0))
	cache.get_path(Vector2i(0, 0), Vector2i(0, 20))
	assert_eq(cache.get_route_count(), 2, "Two routes before invalidation")
	cache.invalidate_routes_to(Vector2i(20, 0))
	assert_eq(cache.get_route_count(), 1, "One route after invalidating target")


func test_invalidate_routes_from():
	var cache := _make_cache()
	cache.get_path(Vector2i(0, 0), Vector2i(5, 0))
	cache.get_path(Vector2i(3, 3), Vector2i(5, 0))
	assert_eq(cache.get_route_count(), 2, "Two routes before invalidation")
	cache.invalidate_routes_from(Vector2i(0, 0))
	assert_eq(cache.get_route_count(), 1, "One route after invalidating source")


func test_clear_routes():
	var cache := _make_cache()
	cache.get_path(Vector2i(0, 0), Vector2i(5, 0))
	cache.get_path(Vector2i(0, 0), Vector2i(0, 5))
	cache.clear_routes()
	assert_eq(cache.get_route_count(), 0, "All routes cleared")


func test_lru_eviction():
	var cache := _make_cache()
	# Fill cache beyond MAX_ROUTES — use large spacing to avoid route sharing
	var count: int = VillagePathCache.MAX_ROUTES + 2
	for i in range(count):
		cache.get_path(Vector2i(0, 0), Vector2i((i + 1) * 20, 0), i)
	# Should have evicted oldest to stay at or below MAX_ROUTES
	assert_true(cache.get_route_count() <= VillagePathCache.MAX_ROUTES, "Cache should not exceed MAX_ROUTES")


func test_path_seeds_trail_tiles():
	var cache := _make_cache()
	cache.get_path(Vector2i(0, 0), Vector2i(5, 0))
	var trails := cache.get_all_trail_tiles()
	# The full path (unsimplified) should seed trail tiles with count 0
	assert_true(trails.size() > 0, "Path computation should seed trail tiles")
	# Start and end should be in trail data
	assert_true(trails.has(Vector2i(0, 0)), "Start tile should be in trail data")
	assert_true(trails.has(Vector2i(5, 0)), "End tile should be in trail data")
