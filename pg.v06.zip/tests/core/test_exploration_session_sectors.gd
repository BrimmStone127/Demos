extends "res://tests/test_base.gd"

## Tests for ExplorationSession sector calculation functions
## These test the pure deterministic math without needing full session setup

# We can't call private methods directly, so we test via the public sector_info
# after _init_sectors. But ExplorationSession needs full initialize().
# Instead, replicate the pure math and verify determinism.

func _calc_sector_seed(galaxy_seed: int, s_index: int) -> int:
	return hash(galaxy_seed ^ (s_index * 2654435761))

func _calc_sector_size(s_seed: int) -> int:
	var rng = RandomNumberGenerator.new()
	rng.seed = s_seed
	return rng.randi_range(200, 1024)

func _next_star_seed(sector_seed: int, star_index: int) -> int:
	return hash(sector_seed ^ (star_index * 2246822519))

func test_sector_seed_deterministic():
	var seed1 = _calc_sector_seed(12345, 100)
	var seed2 = _calc_sector_seed(12345, 100)
	assert_eq(seed1, seed2, "Same galaxy_seed + sector_index = same sector_seed")

func test_sector_seed_varies_by_sector():
	var seed1 = _calc_sector_seed(12345, 100)
	var seed2 = _calc_sector_seed(12345, 101)
	assert_ne(seed1, seed2, "Different sector indices should produce different seeds")

func test_sector_seed_varies_by_galaxy():
	var seed1 = _calc_sector_seed(12345, 100)
	var seed2 = _calc_sector_seed(54321, 100)
	assert_ne(seed1, seed2, "Different galaxy seeds should produce different sector seeds")

func test_sector_size_range():
	# All sector sizes should be in 200-1024 range
	for i in range(100):
		var s_seed = _calc_sector_seed(42, i)
		var size = _calc_sector_size(s_seed)
		assert_gte(size, 200, "Sector size should be >= 200")
		assert_lte(size, 1024, "Sector size should be <= 1024")

func test_sector_size_deterministic():
	var s_seed = _calc_sector_seed(42, 50)
	var size1 = _calc_sector_size(s_seed)
	var size2 = _calc_sector_size(s_seed)
	assert_eq(size1, size2, "Same sector_seed = same sector_size")

func test_sector_size_varies():
	# Not all sectors should be same size
	var sizes = {}
	for i in range(50):
		var s_seed = _calc_sector_seed(42, i)
		var size = _calc_sector_size(s_seed)
		sizes[size] = true
	assert_gt(sizes.size(), 1, "Sector sizes should vary across sectors")

func test_star_seed_deterministic():
	var sector_seed = _calc_sector_seed(42, 10)
	var star1 = _next_star_seed(sector_seed, 5)
	var star2 = _next_star_seed(sector_seed, 5)
	assert_eq(star1, star2, "Same sector_seed + star_index = same star_seed")

func test_star_seed_varies_by_index():
	var sector_seed = _calc_sector_seed(42, 10)
	var star1 = _next_star_seed(sector_seed, 0)
	var star2 = _next_star_seed(sector_seed, 1)
	assert_ne(star1, star2, "Different star indices should produce different seeds")

func test_starting_sector_range():
	# _init_sectors sets: sector_index = abs(galaxy_seed) % 899999 + 100000
	for seed_val in [0, 1, -42, 999999, 123456789]:
		var sector_index = abs(seed_val) % 899999 + 100000
		assert_gte(sector_index, 100000, "Starting sector should be >= 100000")
		assert_lt(sector_index, 1000000, "Starting sector should be < 1000000")
