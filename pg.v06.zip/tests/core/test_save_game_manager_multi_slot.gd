extends "res://tests/test_base.gd"

## Tests for SaveGameManager multi-slot system

func test_slot_path_format():
	var manager = SaveGameManager.new()
	autofree(manager)
	var path = manager._slot_path("save_001")
	assert_string_contains(path, "save_001.json", "Slot path should use slot_id with .json extension")

func test_thumbnail_path_format():
	var manager = SaveGameManager.new()
	autofree(manager)
	var path = manager._thumbnail_path("save_001")
	assert_string_contains(path, "save_001.png", "Thumbnail path should use slot_id with .png extension")

func test_slot_id_to_number():
	var manager = SaveGameManager.new()
	autofree(manager)
	assert_eq(manager._slot_id_to_number("save_001"), 1, "save_001 should be number 1")
	assert_eq(manager._slot_id_to_number("save_042"), 42, "save_042 should be number 42")
	assert_eq(manager._slot_id_to_number("save_100"), 100, "save_100 should be number 100")
	assert_eq(manager._slot_id_to_number("invalid"), 0, "Invalid slot ID should return 0")

func test_get_next_slot_id_format():
	var manager = SaveGameManager.new()
	autofree(manager)
	var next_id = manager.get_next_slot_id()
	assert_true(next_id.begins_with("save_"), "Next slot ID should start with save_")
	assert_true(next_id.length() == 8, "Next slot ID should be 8 chars (save_NNN)")
	var num_part = next_id.replace("save_", "")
	assert_true(num_part.is_valid_int(), "Number part should be valid int")

func test_generate_save_name():
	var manager = SaveGameManager.new()
	autofree(manager)
	var meta = {"game_days_elapsed": 45.0, "current_seed": 12345}
	var name = manager.generate_save_name(meta)
	assert_eq(name, "Day 45 - Seed 12345", "Save name should include day and seed")

func test_generate_save_name_defaults():
	var manager = SaveGameManager.new()
	autofree(manager)
	var name = manager.generate_save_name({})
	assert_eq(name, "Day 0 - Seed 0", "Empty meta should produce default name")

func test_save_to_slot_without_init_fails():
	var manager = SaveGameManager.new()
	autofree(manager)
	var result = manager.save_to_slot("save_001")
	assert_false(result.success, "Save to slot should fail without initialization")
	assert_string_contains(result.message, "not initialized", "Should report not initialized")

func test_load_from_slot_without_init_fails():
	var manager = SaveGameManager.new()
	autofree(manager)
	var result = manager.load_from_slot("save_001")
	assert_false(result.success, "Load from slot should fail without initialization")
	assert_string_contains(result.message, "not initialized", "Should report not initialized")

func test_load_from_nonexistent_slot_fails():
	var manager = SaveGameManager.new()
	autofree(manager)
	manager.services = GameServices.new()
	var result = manager.load_from_slot("save_999")
	assert_false(result.success, "Load from nonexistent slot should fail")
	assert_string_contains(result.message, "not found", "Should report not found")

func test_delete_nonexistent_slot_succeeds():
	var manager = SaveGameManager.new()
	autofree(manager)
	var result = manager.delete_slot("save_999")
	assert_true(result.success, "Deleting nonexistent slot should succeed")

func test_list_saves_empty():
	var manager = SaveGameManager.new()
	autofree(manager)
	var saves = manager.list_saves()
	# list_saves opens a directory that may or may not exist
	assert_true(saves is Array, "list_saves should return an array")

func test_has_saves_matches_list():
	var manager = SaveGameManager.new()
	autofree(manager)
	var has = manager.has_saves()
	var list = manager.list_saves()
	assert_eq(has, list.size() > 0, "has_saves should match list_saves size > 0")

func test_save_result_has_slot_id():
	var manager = SaveGameManager.new()
	autofree(manager)
	var result = manager.save_to_slot("save_001")
	assert_has(result, "slot_id", "Save result should have slot_id key")
	assert_eq(result.slot_id, "save_001", "slot_id should match requested slot")

func test_load_result_has_slot_id():
	var manager = SaveGameManager.new()
	autofree(manager)
	var result = manager.load_from_slot("save_001")
	assert_has(result, "slot_id", "Load result should have slot_id key")
	assert_eq(result.slot_id, "save_001", "slot_id should match requested slot")

func test_thumbnail_size_constant():
	assert_eq(SaveGameManager.THUMBNAIL_SIZE, Vector2i(320, 180), "Thumbnail size should be 320x180")

func test_legacy_slot_constant():
	assert_eq(SaveGameManager.LEGACY_SLOT, "slot1.json", "Legacy slot should be slot1.json")

func test_backward_compat_has_save():
	var manager = SaveGameManager.new()
	autofree(manager)
	# has_save delegates to has_saves
	var result = manager.has_save()
	assert_eq(typeof(result), TYPE_BOOL, "has_save should return bool")
