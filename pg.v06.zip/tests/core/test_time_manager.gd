extends "res://tests/test_base.gd"

func _make_tm() -> TimeManager:
	var tm = autofree(TimeManager.new())
	tm.current_time_scale = 1.0
	tm.scaled_delta = 0.0
	tm.game_time_elapsed = 0.0
	tm.real_time_elapsed = 0.0
	return tm

func test_initial_state():
	var tm = _make_tm()
	assert_almost_eq(tm.current_time_scale, 1.0, 0.001)
	assert_almost_eq(tm.game_time_elapsed, 0.0, 0.001)
	assert_false(tm.is_paused())

func test_set_time_scale():
	var tm = _make_tm()
	tm.set_time_scale(4.0)
	assert_almost_eq(tm.get_time_scale(), 4.0, 0.001)

func test_set_time_scale_clamping_max():
	var tm = _make_tm()
	tm.set_time_scale(100.0)
	assert_almost_eq(tm.get_time_scale(), TimeManager.MAX_TIME_SCALE, 0.001)

func test_set_time_scale_clamping_min():
	var tm = _make_tm()
	tm.set_time_scale(-5.0)
	assert_almost_eq(tm.get_time_scale(), TimeManager.MIN_TIME_SCALE, 0.001)

func test_is_paused():
	var tm = _make_tm()
	tm.set_time_scale(0.0)
	assert_true(tm.is_paused())

func test_is_not_paused():
	var tm = _make_tm()
	assert_false(tm.is_paused())

func test_formatted_time_minutes_seconds():
	var tm = _make_tm()
	tm.game_time_elapsed = 125.0
	assert_eq(tm.get_formatted_game_time(), "02:05")

func test_formatted_time_with_hours():
	var tm = _make_tm()
	tm.game_time_elapsed = 3661.0
	assert_eq(tm.get_formatted_game_time(), "01:01:01")

func test_formatted_time_zero():
	var tm = _make_tm()
	tm.game_time_elapsed = 0.0
	assert_eq(tm.get_formatted_game_time(), "00:00")

func test_register_orbit_completion():
	var tm = _make_tm()
	tm.register_orbit_completion("Earth")
	var stats = tm.get_orbit_stats()
	assert_has(stats, "Earth")
	assert_eq(stats["Earth"], 1)

func test_register_orbit_multiple():
	var tm = _make_tm()
	tm.register_orbit_completion("Mars")
	tm.register_orbit_completion("Mars")
	tm.register_orbit_completion("Mars")
	assert_eq(tm.get_orbit_stats().get("Mars", 0), 3)

func test_rename_planet_transfers_orbits():
	var tm = _make_tm()
	tm.register_orbit_completion("PlanetA")
	tm.register_orbit_completion("PlanetA")
	tm.rename_planet("PlanetA", "PlanetB")
	var stats = tm.get_orbit_stats()
	assert_does_not_have(stats, "PlanetA")
	assert_eq(stats.get("PlanetB", 0), 2)

func test_rename_planet_empty_names():
	var tm = _make_tm()
	tm.register_orbit_completion("Test")
	tm.rename_planet("", "New")
	tm.rename_planet("Test", "  ")
	tm.rename_planet("Test", "Test")
	assert_eq(tm.get_orbit_stats().get("Test", 0), 1)

func test_reset_game_time():
	var tm = _make_tm()
	tm.game_time_elapsed = 100.0
	tm.real_time_elapsed = 50.0
	tm.register_orbit_completion("X")
	tm.reset_game_time()
	assert_almost_eq(tm.game_time_elapsed, 0.0, 0.001)
	assert_almost_eq(tm.real_time_elapsed, 0.0, 0.001)
	assert_true(tm.get_orbit_stats().is_empty())

func test_time_stats_shape():
	var tm = _make_tm()
	var stats = tm.get_time_stats()
	assert_has(stats, "game_time")
	assert_has(stats, "real_time")
	assert_has(stats, "current_scale")
	assert_has(stats, "is_paused")

func test_time_acceleration_description_paused():
	var tm = _make_tm()
	tm.set_time_scale(0.0)
	assert_string_contains(tm.get_time_acceleration_description().to_lower(), "paused")

func test_time_acceleration_description_normal():
	var tm = _make_tm()
	assert_string_contains(tm.get_time_acceleration_description().to_lower(), "normal")

func test_time_acceleration_description_fast():
	var tm = _make_tm()
	tm.set_time_scale(4.0)
	assert_string_contains(tm.get_time_acceleration_description().to_lower(), "accelerated")

func test_time_acceleration_description_slow():
	var tm = _make_tm()
	tm.set_time_scale(0.5)
	assert_string_contains(tm.get_time_acceleration_description().to_lower(), "slowed")

func test_seconds_to_hours():
	var tm = _make_tm()
	assert_almost_eq(tm.seconds_to_hours(3600.0), 1.0, 0.001)

func test_hours_to_seconds():
	var tm = _make_tm()
	assert_almost_eq(tm.hours_to_seconds(1.0), 3600.0, 0.001)

# --- Simulation tick tests ---

func test_game_days_initial_zero():
	var tm = _make_tm()
	assert_almost_eq(tm.game_days_elapsed, 0.0, 0.001)

func test_game_days_calculation():
	var tm = _make_tm()
	tm.game_time_elapsed = TimeManager.SECONDS_PER_GAME_DAY * 2.0
	# game_days_elapsed is computed in _process; simulate by direct assignment
	tm.game_days_elapsed = tm.game_time_elapsed / TimeManager.SECONDS_PER_GAME_DAY
	assert_almost_eq(tm.game_days_elapsed, 2.0, 0.001)

func test_simulation_tick_count_initial_zero():
	var tm = _make_tm()
	assert_eq(tm.simulation_tick_count, 0)

func test_reset_clears_tick_state():
	var tm = _make_tm()
	tm.game_days_elapsed = 5.0
	tm.simulation_tick_count = 20
	tm.reset_game_time()
	assert_almost_eq(tm.game_days_elapsed, 0.0, 0.001)
	assert_eq(tm.simulation_tick_count, 0)

func test_time_stats_includes_days_and_tick():
	var tm = _make_tm()
	var stats = tm.get_time_stats()
	assert_has(stats, "game_days")
	assert_has(stats, "simulation_tick")
