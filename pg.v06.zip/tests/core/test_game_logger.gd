extends "res://tests/test_base.gd"

func test_default_level_is_info():
	var logger = GameLogger.new()
	assert_eq(logger.level, GameLogger.Level.INFO, "Default level should be INFO")

func test_set_level_valid():
	var logger = GameLogger.new()
	logger.set_level(GameLogger.Level.DEBUG)
	assert_eq(logger.level, GameLogger.Level.DEBUG, "Level should be DEBUG after set_level")

func test_set_level_clamping_low():
	var logger = GameLogger.new()
	logger.set_level(-10)
	assert_eq(logger.level, GameLogger.Level.DEBUG, "Level should clamp to DEBUG")

func test_set_level_clamping_high():
	var logger = GameLogger.new()
	logger.set_level(100)
	assert_eq(logger.level, GameLogger.Level.ERROR, "Level should clamp to ERROR")

func test_format_message_info():
	var logger = GameLogger.new()
	var result = logger._format_message(GameLogger.Level.INFO, "TAG", "hello")
	assert_eq(result, "[INFO][TAG] hello")

func test_format_message_debug():
	var logger = GameLogger.new()
	var result = logger._format_message(GameLogger.Level.DEBUG, "TEST", "debug msg")
	assert_eq(result, "[DEBUG][TEST] debug msg")

func test_format_message_warn():
	var logger = GameLogger.new()
	var result = logger._format_message(GameLogger.Level.WARN, "W", "warning")
	assert_eq(result, "[WARN][W] warning")

func test_format_message_error():
	var logger = GameLogger.new()
	var result = logger._format_message(GameLogger.Level.ERROR, "E", "err")
	assert_eq(result, "[ERROR][E] err")

func test_timestamp_disabled_by_default():
	var logger = GameLogger.new()
	assert_false(logger.use_timestamp, "Timestamp should be disabled by default")
	var result = logger._format_message(GameLogger.Level.INFO, "T", "msg")
	assert_false(result.begins_with("[2"), "Output should not start with timestamp")

func test_format_with_timestamp_enabled():
	var logger = GameLogger.new()
	logger.enable_timestamp(true)
	var result = logger._format_message(GameLogger.Level.INFO, "T", "msg")
	assert_true(result.begins_with("["), "Output should start with timestamp bracket")
	assert_true("[INFO][T] msg" in result, "Output should contain level and message")

func test_level_filtering_suppresses_debug():
	var logger = GameLogger.new()
	assert_lt(GameLogger.Level.DEBUG, logger.level, "DEBUG should be less than default INFO level")
