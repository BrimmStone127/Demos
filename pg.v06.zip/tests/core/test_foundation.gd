extends "res://tests/test_base.gd"

func _make_foundation() -> Foundation:
	return autofree(Foundation.new())

# --- Credits ---

func test_initial_state():
	var f = _make_foundation()
	assert_eq(f.credits, 0)
	assert_eq(f.lifetime_credits, 0)
	assert_eq(f.rank, 0)

func test_award_credits():
	var f = _make_foundation()
	f.award_credits(50, "test")
	assert_eq(f.credits, 50)
	assert_eq(f.lifetime_credits, 50)

func test_award_zero_ignored():
	var f = _make_foundation()
	f.award_credits(0, "nope")
	assert_eq(f.credits, 0)

func test_award_negative_ignored():
	var f = _make_foundation()
	f.award_credits(-10, "nope")
	assert_eq(f.credits, 0)

func test_spend_credits():
	var f = _make_foundation()
	f.award_credits(100)
	var result = f.spend_credits(40)
	assert_true(result, "Spend should succeed")
	assert_eq(f.credits, 60)
	assert_eq(f.lifetime_credits, 100, "Lifetime should not decrease")

func test_spend_too_much():
	var f = _make_foundation()
	f.award_credits(20)
	var result = f.spend_credits(50)
	assert_false(result, "Spend should fail")
	assert_eq(f.credits, 20, "Credits unchanged")

func test_spend_zero():
	var f = _make_foundation()
	f.award_credits(10)
	var result = f.spend_credits(0)
	assert_false(result, "Spend zero should fail")

func test_can_afford():
	var f = _make_foundation()
	f.award_credits(100)
	assert_true(f.can_afford(100))
	assert_true(f.can_afford(50))
	assert_false(f.can_afford(101))

# --- Rank ---

func test_rank_progression():
	var f = _make_foundation()
	assert_eq(f.rank, 0)
	f.award_credits(100)
	assert_eq(f.rank, 1)
	f.award_credits(400)
	assert_eq(f.rank, 2)
	f.award_credits(1500)
	assert_eq(f.rank, 3)

func test_rank_does_not_decrease_on_spend():
	var f = _make_foundation()
	f.award_credits(500)
	assert_eq(f.rank, 2)
	f.spend_credits(450)
	assert_eq(f.rank, 2, "Rank based on lifetime, not balance")

# --- Observation State ---

func test_initial_observation_state():
	var f = _make_foundation()
	assert_eq(f.get_observation_state(12345), Foundation.ObservationState.UNOBSERVED)

func test_observe_system():
	var f = _make_foundation()
	f.on_system_observed(12345)
	assert_eq(f.get_observation_state(12345), Foundation.ObservationState.OBSERVED)

func test_is_new_system():
	var f = _make_foundation()
	assert_true(f.is_new_system(999))
	f.on_system_observed(999)
	assert_false(f.is_new_system(999))

func test_observation_never_downgrades():
	var f = _make_foundation()
	f.set_observation_state(100, Foundation.ObservationState.EXPLORED)
	f.set_observation_state(100, Foundation.ObservationState.OBSERVED)
	assert_eq(f.get_observation_state(100), Foundation.ObservationState.EXPLORED, "Should not downgrade")

func test_observation_upgrades():
	var f = _make_foundation()
	f.set_observation_state(100, Foundation.ObservationState.OBSERVED)
	f.set_observation_state(100, Foundation.ObservationState.EXPLORED)
	assert_eq(f.get_observation_state(100), Foundation.ObservationState.EXPLORED)

# --- Credit Rewards ---

func test_observe_new_system():
	var f = _make_foundation()
	f.on_system_observed(1)
	assert_eq(f.credits, Foundation.CREDITS_OBSERVE_SYSTEM)

func test_observe_same_system_no_double_reward():
	var f = _make_foundation()
	f.on_system_observed(1)
	var after_first = f.credits
	f.on_system_observed(1)
	assert_eq(f.credits, after_first, "No double reward for same system")

func test_analyze_planet_credits():
	var f = _make_foundation()
	f.on_planet_analyzed(1, "1:0")
	assert_eq(f.credits, Foundation.CREDITS_ANALYZE_PLANET)

func test_analyze_sets_explored():
	var f = _make_foundation()
	f.on_planet_analyzed(1)
	assert_eq(f.get_observation_state(1), Foundation.ObservationState.EXPLORED)

func test_analyze_same_planet_no_double_credits():
	var f = _make_foundation()
	f.on_planet_analyzed(1, "1:0")
	var after_first = f.credits
	f.on_planet_analyzed(1, "1:0")
	assert_eq(f.credits, after_first, "No double credits for same planet")

# --- Signals ---

func test_credits_changed_signal():
	var f = _make_foundation()
	var received := []
	f.credits_changed.connect(func(balance, delta, reason): received.append({"balance": balance, "delta": delta, "reason": reason}))
	f.award_credits(50)
	assert_eq(received.size(), 1)
	assert_eq(received[0].balance, 50)
	assert_eq(received[0].delta, 50)

func test_rank_changed_signal():
	var f = _make_foundation()
	var received := []
	f.rank_changed.connect(func(new_rank, old_rank): received.append({"new": new_rank, "old": old_rank}))
	f.award_credits(100)  # Crosses rank 1 threshold
	assert_eq(received.size(), 1)
	assert_eq(received[0].new, 1)
	assert_eq(received[0].old, 0)

func test_observation_changed_signal():
	var f = _make_foundation()
	var received := []
	f.system_observation_changed.connect(func(seed, state): received.append({"seed": seed, "state": state}))
	f.on_system_observed(42)
	assert_eq(received.size(), 1)
	assert_eq(received[0].seed, 42)
	assert_eq(received[0].state, Foundation.ObservationState.OBSERVED)

# --- Persistence ---

func test_export_data():
	var f = _make_foundation()
	f.award_credits(250)
	f.on_system_observed(1)
	var data = f.export_data()
	assert_has(data, "credits")
	assert_has(data, "lifetime_credits")
	assert_has(data, "rank")
	assert_has(data, "observed_systems")
	assert_eq(data.credits, 250 + Foundation.CREDITS_OBSERVE_SYSTEM)

func test_import_data():
	var f = _make_foundation()
	var data = {
		"credits": 500,
		"lifetime_credits": 2500,
		"observed_systems": {42: Foundation.ObservationState.EXPLORED}
	}
	f.import_data(data)
	assert_eq(f.credits, 500)
	assert_eq(f.lifetime_credits, 2500)
	assert_eq(f.rank, 3)  # 2500 >= 2000
	assert_eq(f.get_observation_state(42), Foundation.ObservationState.EXPLORED)

func test_export_import_roundtrip():
	var f = _make_foundation()
	f.award_credits(600)
	f.on_system_observed(10)
	f.on_planet_analyzed(10, "10:0")
	var exported = f.export_data()

	var f2 = _make_foundation()
	f2.import_data(exported)
	assert_eq(f2.credits, f.credits)
	assert_eq(f2.lifetime_credits, f.lifetime_credits)
	assert_eq(f2.rank, f.rank)
	assert_eq(f2.get_observation_state(10), f.get_observation_state(10))
