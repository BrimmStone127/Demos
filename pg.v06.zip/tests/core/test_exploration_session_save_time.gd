extends "res://tests/test_base.gd"

## Tests that ExplorationSession._loading_save flag prevents time reset during load
## The flag guards against _on_system_generation_complete resetting restored time state

func test_loading_save_default_false():
	var session = ExplorationSession.new()
	autofree(session)
	assert_false(session._loading_save, "Loading save flag should default to false")

func test_time_manager_reset_skipped_when_loading():
	# Simulate what _on_system_generation_complete does
	var session = ExplorationSession.new()
	autofree(session)
	var tm = TimeManager.new()
	autofree(tm)
	session.time_manager = tm

	# Set time values as if restored from save
	tm.game_time_elapsed = 500.0
	tm.game_days_elapsed = 8.0
	tm.simulation_tick_count = 16

	# Simulate loading flag set during load
	session._loading_save = true

	# Call what _on_system_generation_complete does
	# (we can't call it directly since it also sets star_system, but test the guard logic)
	if session.time_manager and not session._loading_save:
		session.time_manager.reset_game_time()
	session._loading_save = false

	# Time should be preserved
	assert_eq(tm.game_time_elapsed, 500.0, "Time elapsed should be preserved during load")
	assert_eq(tm.game_days_elapsed, 8.0, "Days elapsed should be preserved during load")
	assert_eq(tm.simulation_tick_count, 16, "Tick count should be preserved during load")

func test_time_manager_reset_when_not_loading():
	var session = ExplorationSession.new()
	autofree(session)
	var tm = TimeManager.new()
	autofree(tm)
	session.time_manager = tm

	# Set time values
	tm.game_time_elapsed = 500.0
	tm.game_days_elapsed = 8.0
	tm.simulation_tick_count = 16

	# Not loading — flag is false (default)
	if session.time_manager and not session._loading_save:
		session.time_manager.reset_game_time()
	session._loading_save = false

	# Time should be reset
	assert_eq(tm.game_time_elapsed, 0.0, "Time elapsed should reset for new game")
	assert_eq(tm.game_days_elapsed, 0.0, "Days elapsed should reset for new game")
	assert_eq(tm.simulation_tick_count, 0, "Tick count should reset for new game")
