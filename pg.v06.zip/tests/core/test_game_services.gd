extends "res://tests/test_base.gd"

func test_missing_required_all_null():
	var services = GameServices.new()
	var missing = services.missing_required()
	var expected = services.required_service_names()
	assert_eq(missing.size(), expected.size(), "All services should be missing")
	for svc_name in expected:
		assert_has(missing, svc_name, "Missing should include %s" % svc_name)

func test_missing_required_with_main_node():
	var services = GameServices.new()
	services.main_node = autofree(Node2D.new())
	var missing = services.missing_required()
	assert_does_not_have(missing, "main_node", "main_node should not be missing")
	assert_eq(missing.size(), services.required_service_names().size() - 1)

func test_missing_required_all_satisfied():
	var services = _build_full_services()
	var missing = services.missing_required()
	assert_eq(missing.size(), 0, "No services should be missing")

func test_update_from_copies_fields():
	var source = GameServices.new()
	source.logger = GameLogger.new()
	var target = GameServices.new()
	target.update_from(source)
	assert_eq(target.logger, source.logger, "Logger should be copied")

func test_update_from_null_is_safe():
	var services = GameServices.new()
	services.update_from(null)
	var missing = services.missing_required()
	assert_eq(missing.size(), services.required_service_names().size())

func _build_full_services() -> GameServices:
	var services = GameServices.new()
	services.main_node = autofree(Node2D.new())
	services.transition_manager = autofree(TransitionManager.new())
	services.ui_manager = autofree(UIManager.new())
	services.time_manager = autofree(TimeManager.new())
	services.camera_manager = autofree(CameraManager.new())
	services.scene_manager = autofree(SceneManager.new())
	return services
