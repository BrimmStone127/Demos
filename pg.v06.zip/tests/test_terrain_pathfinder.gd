extends "res://tests/test_base.gd"

## Tests for TerrainPathfinder A* pathfinding on tile grid.
## Uses null planet_map_system for basic pathfinding tests (uniform cost).
## Verifies path finding, simplification, and cost calculations.


func test_find_path_same_start_end():
	var pf := TerrainPathfinder.new(null)
	var path := pf.find_path(Vector2i(5, 5), Vector2i(5, 5))
	assert_eq(path.size(), 1, "Same start/end should return single-element path")
	assert_eq(path[0], Vector2i(5, 5), "Path should contain the start position")


func test_find_path_adjacent():
	var pf := TerrainPathfinder.new(null)
	var path := pf.find_path(Vector2i(0, 0), Vector2i(1, 0))
	assert_eq(path.size(), 2, "Adjacent tiles should have 2-element path")
	assert_eq(path[0], Vector2i(0, 0), "Path should start at start")
	assert_eq(path[1], Vector2i(1, 0), "Path should end at end")


func test_find_path_diagonal():
	var pf := TerrainPathfinder.new(null)
	var path := pf.find_path(Vector2i(0, 0), Vector2i(3, 3))
	assert_true(path.size() > 0, "Should find a diagonal path")
	assert_eq(path[0], Vector2i(0, 0), "Path should start at origin")
	assert_eq(path[path.size() - 1], Vector2i(3, 3), "Path should end at destination")
	# Diagonal path of 3 steps should be 4 points (including start)
	assert_eq(path.size(), 4, "Diagonal path should be 4 waypoints")


func test_find_path_longer():
	var pf := TerrainPathfinder.new(null)
	var path := pf.find_path(Vector2i(0, 0), Vector2i(10, 5))
	assert_true(path.size() > 0, "Should find path to (10,5)")
	assert_eq(path[0], Vector2i(0, 0), "Path starts at origin")
	assert_eq(path[path.size() - 1], Vector2i(10, 5), "Path ends at destination")


func test_step_cost_no_planet_map():
	var pf := TerrainPathfinder.new(null)
	# Grid cardinal (1,0) = iso diagonal, medium cost
	var cost := pf.step_cost(Vector2i(0, 0), Vector2i(1, 0))
	assert_almost_eq(cost, TerrainPathfinder.ISO_CARDINAL_COST, 0.01, "Grid cardinal = iso diagonal cost")
	# Grid diagonal (1,1) = iso vertical, cheapest
	var vert_cost := pf.step_cost(Vector2i(0, 0), Vector2i(1, 1))
	assert_almost_eq(vert_cost, TerrainPathfinder.ISO_VERTICAL_COST, 0.01, "Grid (1,1) = iso vertical cost")
	# Grid diagonal (1,-1) = iso horizontal, most expensive
	var horiz_cost := pf.step_cost(Vector2i(0, 0), Vector2i(1, -1))
	assert_almost_eq(horiz_cost, TerrainPathfinder.ISO_HORIZONTAL_COST, 0.01, "Grid (1,-1) = iso horizontal cost")


func test_simplify_path_empty():
	var path: Array[Vector2i] = []
	var simplified := TerrainPathfinder.simplify_path(path)
	assert_eq(simplified.size(), 0, "Empty path stays empty")


func test_simplify_path_two_points():
	var path: Array[Vector2i] = [Vector2i(0, 0), Vector2i(1, 1)]
	var simplified := TerrainPathfinder.simplify_path(path)
	assert_eq(simplified.size(), 2, "Two-point path unchanged")


func test_simplify_path_collinear():
	var path: Array[Vector2i] = [
		Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0), Vector2i(3, 0)
	]
	var simplified := TerrainPathfinder.simplify_path(path)
	assert_eq(simplified.size(), 2, "Collinear path reduces to start and end")
	assert_eq(simplified[0], Vector2i(0, 0), "Keeps start")
	assert_eq(simplified[1], Vector2i(3, 0), "Keeps end")


func test_simplify_path_with_turn():
	var path: Array[Vector2i] = [
		Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0), Vector2i(2, 1), Vector2i(2, 2)
	]
	var simplified := TerrainPathfinder.simplify_path(path)
	assert_eq(simplified.size(), 3, "Path with one turn keeps 3 points")
	assert_eq(simplified[0], Vector2i(0, 0), "Keeps start")
	assert_eq(simplified[1], Vector2i(2, 0), "Keeps turn point")
	assert_eq(simplified[2], Vector2i(2, 2), "Keeps end")


func test_simplify_path_zigzag():
	var path: Array[Vector2i] = [
		Vector2i(0, 0), Vector2i(1, 1), Vector2i(2, 0), Vector2i(3, 1)
	]
	var simplified := TerrainPathfinder.simplify_path(path)
	assert_eq(simplified.size(), 4, "Zigzag path keeps all points (every point is a turn)")


func test_heuristic_isometric():
	var vc := TerrainPathfinder.ISO_VERTICAL_COST
	var cc := TerrainPathfinder.ISO_CARDINAL_COST
	# (3,4): 3 diagonal (iso-vertical) + 1 cardinal (iso-diagonal)
	var h := TerrainPathfinder._heuristic(Vector2i(0, 0), Vector2i(3, 4))
	assert_almost_eq(h, 3.0 * vc + 1.0 * cc, 0.01, "Iso heuristic: 3 diag + 1 cardinal")
	# (5,2): 2 diagonal + 3 cardinal
	var h2 := TerrainPathfinder._heuristic(Vector2i(0, 0), Vector2i(5, 2))
	assert_almost_eq(h2, 2.0 * vc + 3.0 * cc, 0.01, "Iso heuristic: 2 diag + 3 cardinal")


func test_path_continuity():
	var pf := TerrainPathfinder.new(null)
	var path := pf.find_path(Vector2i(0, 0), Vector2i(8, 6))
	assert_true(path.size() > 0, "Should find path")
	for i in range(1, path.size()):
		var dx := absi(path[i].x - path[i - 1].x)
		var dy := absi(path[i].y - path[i - 1].y)
		assert_true(dx <= 1 and dy <= 1, "Each step should be to an adjacent tile (step %d)" % i)
		assert_true(dx + dy > 0, "Each step should actually move (step %d)" % i)
