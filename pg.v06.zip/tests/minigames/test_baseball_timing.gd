extends "res://tests/test_base.gd"

# Tests for BaseballGame timing-based hit system.
# Pure logic tests — no scene tree or rendering required.


func get_test_name() -> String:
	return "BaseballTiming"


## Returns the hit result for a given swing elapsed time.
func _result_at(elapsed: float) -> BaseballGame._HitResult:
	var offset := absf(elapsed - BaseballGame.HIT_WINDOW_CENTER)
	if offset <= BaseballGame.SWEET_SPOT_HALF:
		return BaseballGame._HitResult.HOME_RUN
	elif offset <= BaseballGame.GOOD_HIT_HALF:
		return BaseballGame._HitResult.HIT
	elif offset <= BaseballGame.FOUL_ZONE_HALF:
		return BaseballGame._HitResult.FOUL
	else:
		return BaseballGame._HitResult.STRIKE


# ── Sweet spot tests ─────────────────────────────────────────────────────────

func test_sweet_spot_at_center() -> void:
	assert_eq(
		_result_at(BaseballGame.HIT_WINDOW_CENTER),
		BaseballGame._HitResult.HOME_RUN,
		"Perfect timing should be a home run"
	)


func test_sweet_spot_edge_early() -> void:
	# Slightly inside to avoid float boundary
	var t := BaseballGame.HIT_WINDOW_CENTER - BaseballGame.SWEET_SPOT_HALF + 0.001
	assert_eq(_result_at(t), BaseballGame._HitResult.HOME_RUN, "Near edge of sweet spot (early) should be home run")


func test_sweet_spot_edge_late() -> void:
	var t := BaseballGame.HIT_WINDOW_CENTER + BaseballGame.SWEET_SPOT_HALF - 0.001
	assert_eq(_result_at(t), BaseballGame._HitResult.HOME_RUN, "Near edge of sweet spot (late) should be home run")


# ── Good hit zone tests ─────────────────────────────────────────────────────

func test_good_hit_early() -> void:
	var t := BaseballGame.HIT_WINDOW_CENTER - BaseballGame.SWEET_SPOT_HALF - 0.01
	assert_eq(_result_at(t), BaseballGame._HitResult.HIT, "Just outside sweet spot (early) should be a hit")


func test_good_hit_late() -> void:
	var t := BaseballGame.HIT_WINDOW_CENTER + BaseballGame.SWEET_SPOT_HALF + 0.01
	assert_eq(_result_at(t), BaseballGame._HitResult.HIT, "Just outside sweet spot (late) should be a hit")


func test_good_hit_edge() -> void:
	assert_eq(
		_result_at(BaseballGame.HIT_WINDOW_CENTER + BaseballGame.GOOD_HIT_HALF),
		BaseballGame._HitResult.HIT,
		"Edge of good-hit zone should still be a hit"
	)


# ── Foul zone tests ─────────────────────────────────────────────────────────

func test_foul_early() -> void:
	var t := BaseballGame.HIT_WINDOW_CENTER - BaseballGame.GOOD_HIT_HALF - 0.01
	assert_eq(_result_at(t), BaseballGame._HitResult.FOUL, "Just outside hit zone (early) should be foul")


func test_foul_late() -> void:
	var t := BaseballGame.HIT_WINDOW_CENTER + BaseballGame.GOOD_HIT_HALF + 0.01
	assert_eq(_result_at(t), BaseballGame._HitResult.FOUL, "Just outside hit zone (late) should be foul")


func test_foul_edge() -> void:
	var t := BaseballGame.HIT_WINDOW_CENTER + BaseballGame.FOUL_ZONE_HALF - 0.001
	assert_eq(_result_at(t), BaseballGame._HitResult.FOUL, "Near edge of foul zone should be foul")


# ── Strike (whiff) tests ────────────────────────────────────────────────────

func test_strike_early() -> void:
	var t := BaseballGame.HIT_WINDOW_CENTER - BaseballGame.FOUL_ZONE_HALF - 0.01
	assert_eq(_result_at(t), BaseballGame._HitResult.STRIKE, "Beyond foul zone (early) should be strike")


func test_strike_late() -> void:
	var t := BaseballGame.HIT_WINDOW_CENTER + BaseballGame.FOUL_ZONE_HALF + 0.01
	assert_eq(_result_at(t), BaseballGame._HitResult.STRIKE, "Beyond foul zone (late) should be strike")


func test_strike_at_pitch_start() -> void:
	assert_eq(_result_at(0.0), BaseballGame._HitResult.STRIKE, "Swing at pitch start should be strike")


# ── Direction tests ──────────────────────────────────────────────────────────

func test_early_swing_pulls() -> void:
	# Early swing: negative timing_offset → positive rotation angle → pull direction
	# In iso space, pull from home→second rotated right = toward third base side
	var timing_offset := -BaseballGame.GOOD_HIT_HALF * 0.5
	var angle_factor := clampf(timing_offset / BaseballGame.GOOD_HIT_HALF, -1.0, 1.0)
	assert_true(angle_factor < 0.0, "Early swing should produce negative angle factor (pull)")


func test_late_swing_goes_opposite() -> void:
	var timing_offset := BaseballGame.GOOD_HIT_HALF * 0.5
	var angle_factor := clampf(timing_offset / BaseballGame.GOOD_HIT_HALF, -1.0, 1.0)
	assert_true(angle_factor > 0.0, "Late swing should produce positive angle factor (opposite field)")


func test_center_timing_goes_straight() -> void:
	var timing_offset := 0.0
	var angle_factor := clampf(timing_offset / BaseballGame.GOOD_HIT_HALF, -1.0, 1.0)
	assert_eq(angle_factor, 0.0, "Perfect timing should go straight to center field")


# ── Invariant tests ──────────────────────────────────────────────────────────

func test_zones_are_ordered() -> void:
	assert_true(
		BaseballGame.SWEET_SPOT_HALF < BaseballGame.GOOD_HIT_HALF,
		"Sweet spot must be smaller than good-hit zone"
	)
	assert_true(
		BaseballGame.GOOD_HIT_HALF < BaseballGame.FOUL_ZONE_HALF,
		"Good-hit zone must be smaller than foul zone"
	)


func test_foul_zone_within_pitch_duration() -> void:
	assert_true(
		BaseballGame.HIT_WINDOW_CENTER + BaseballGame.FOUL_ZONE_HALF <= BaseballGame.PITCH_DURATION,
		"Foul zone must fall within pitch duration"
	)


func test_inversf_utility() -> void:
	assert_eq(BaseballGame.inversf(5.0, 0.0, 10.0), 0.5, "inversf midpoint")
	assert_eq(BaseballGame.inversf(0.0, 0.0, 10.0), 0.0, "inversf at start")
	assert_eq(BaseballGame.inversf(10.0, 0.0, 10.0), 1.0, "inversf at end")
	assert_eq(BaseballGame.inversf(-5.0, 0.0, 10.0), 0.0, "inversf below range clamps to 0")
	assert_eq(BaseballGame.inversf(15.0, 0.0, 10.0), 1.0, "inversf above range clamps to 1")
