extends "res://tests/test_base.gd"

# Tests for MatchingBoard pure logic.
# No rendering, no scene tree needed.

const SEEDED_SEED := 12345


func get_test_name() -> String:
	return "MatchingBoard"


# ===== HELPERS =====

func _make_board(seed: int = SEEDED_SEED) -> MatchingBoard:
	var b := MatchingBoard.new()
	b.initialize(8, 8, 6, seed)
	return b


func _make_small(w: int, h: int, types: int, seed: int = SEEDED_SEED) -> MatchingBoard:
	var b := MatchingBoard.new()
	b.initialize(w, h, types, seed)
	return b


# Forces a row of identical tiles at y=0 for testing match detection.
func _force_row(board: MatchingBoard, y: int, tile_type: int) -> void:
	for x in range(board.width):
		board._grid[y][x] = tile_type


# Forces a column of identical tiles at x=0.
func _force_col(board: MatchingBoard, x: int, tile_type: int) -> void:
	for y in range(board.height):
		board._grid[y][x] = tile_type


# ===== TESTS =====

func test_initialize_produces_correct_dimensions() -> void:
	var b := _make_board()
	assert_eq(b.width, 8, "width should be 8")
	assert_eq(b.height, 8, "height should be 8")


func test_initialize_no_starting_matches() -> void:
	# Try several different seeds to confirm initialization avoids matches.
	for seed in [1, 42, 999, 7654, 11111]:
		var b := _make_board(seed)
		assert_eq(b.find_matches().size(), 0,
			"seed %d: board should have no starting matches" % seed)


func test_get_tile_valid_range() -> void:
	var b := _make_board()
	for y in range(8):
		for x in range(8):
			var t := b.get_tile(x, y)
			assert_true(t >= 0 and t < 6,
				"tile (%d,%d) should be in range [0,5], got %d" % [x, y, t])


func test_get_tile_out_of_bounds_returns_empty() -> void:
	var b := _make_board()
	assert_eq(b.get_tile(-1, 0), MatchingBoard.EMPTY, "x=-1 should return EMPTY")
	assert_eq(b.get_tile(0, -1), MatchingBoard.EMPTY, "y=-1 should return EMPTY")
	assert_eq(b.get_tile(8, 0), MatchingBoard.EMPTY, "x=8 should return EMPTY")
	assert_eq(b.get_tile(0, 8), MatchingBoard.EMPTY, "y=8 should return EMPTY")


func test_can_swap_orthogonally_adjacent() -> void:
	var b := _make_board()
	assert_true(b.can_swap(Vector2i(0, 0), Vector2i(1, 0)), "horizontal adjacent")
	assert_true(b.can_swap(Vector2i(0, 0), Vector2i(0, 1)), "vertical adjacent")
	assert_true(b.can_swap(Vector2i(3, 3), Vector2i(3, 4)), "middle vertical")


func test_can_swap_rejects_diagonal() -> void:
	var b := _make_board()
	assert_false(b.can_swap(Vector2i(0, 0), Vector2i(1, 1)), "diagonal should be rejected")


func test_can_swap_rejects_distant() -> void:
	var b := _make_board()
	assert_false(b.can_swap(Vector2i(0, 0), Vector2i(2, 0)), "two apart should be rejected")
	assert_false(b.can_swap(Vector2i(0, 0), Vector2i(0, 3)), "three apart should be rejected")


func test_find_matches_detects_horizontal_run() -> void:
	var b := _make_small(5, 1, 2)
	# Force a row of all type-0
	_force_row(b, 0, 0)
	var matches := b.find_matches()
	assert_eq(matches.size(), 5, "all 5 tiles in a single-row board should match")


func test_find_matches_detects_vertical_run() -> void:
	var b := _make_small(1, 5, 2)
	_force_col(b, 0, 1)
	var matches := b.find_matches()
	assert_eq(matches.size(), 5, "all 5 tiles in a single-column board should match")


func test_find_matches_ignores_runs_of_two() -> void:
	var b := _make_small(4, 1, 3)
	# [0, 0, 1, 1] - two pairs, no runs of 3+
	b._grid[0][0] = 0
	b._grid[0][1] = 0
	b._grid[0][2] = 1
	b._grid[0][3] = 1
	assert_eq(b.find_matches().size(), 0, "pairs should not match")


func test_find_matches_returns_empty_when_no_match() -> void:
	var b := _make_board()
	# Board was initialized without matches, so this should be empty.
	assert_eq(b.find_matches().size(), 0, "freshly initialized board should have no matches")


func test_try_swap_valid_swap_returns_true() -> void:
	var b := _make_small(4, 1, 3)
	# Set up: [0, 1, 0, 0] -> swap positions 0 and 1 -> [1, 0, 0, 0] = match
	b._grid[0][0] = 0
	b._grid[0][1] = 1
	b._grid[0][2] = 0
	b._grid[0][3] = 0
	var swapped := b.try_swap(Vector2i(0, 0), Vector2i(1, 0))
	assert_true(swapped, "swapping 1 into row of 0s should succeed")


func test_try_swap_no_match_reverts_and_returns_false() -> void:
	var b := _make_small(3, 1, 3)
	# [0, 1, 2] - no swap can create a match
	b._grid[0][0] = 0
	b._grid[0][1] = 1
	b._grid[0][2] = 2
	var original_0 := b.get_tile(0, 0)
	var original_1 := b.get_tile(1, 0)
	var swapped := b.try_swap(Vector2i(0, 0), Vector2i(1, 0))
	assert_false(swapped, "swap with no resulting match should return false")
	assert_eq(b.get_tile(0, 0), original_0, "tile at (0,0) should be restored")
	assert_eq(b.get_tile(1, 0), original_1, "tile at (1,0) should be restored")


func test_apply_gravity_drops_tiles() -> void:
	var b := _make_small(1, 4, 2)
	# Column: [EMPTY, EMPTY, 1, 0] from top (y=0) to bottom (y=3)
	b._grid[0][0] = MatchingBoard.EMPTY
	b._grid[1][0] = MatchingBoard.EMPTY
	b._grid[2][0] = 1
	b._grid[3][0] = 0
	b.apply_gravity()
	# After gravity: [EMPTY, EMPTY, 1, 0] -> [EMPTY, EMPTY, 1, 0] (already settled)
	# Actually: tiles fall DOWN (higher y = lower on screen)
	# Tiles should remain at 2 and 3 since they're already at the bottom.
	assert_eq(b.get_tile(0, 2), 1, "tile at y=2 stays")
	assert_eq(b.get_tile(0, 3), 0, "tile at y=3 stays")


func test_apply_gravity_fills_gaps() -> void:
	var b := _make_small(1, 4, 2)
	# [1, EMPTY, 0, EMPTY] top to bottom
	b._grid[0][0] = 1
	b._grid[1][0] = MatchingBoard.EMPTY
	b._grid[2][0] = 0
	b._grid[3][0] = MatchingBoard.EMPTY
	b.apply_gravity()
	# Tiles fall down: y=3 gets one tile, y=2 gets the other
	assert_eq(b.get_tile(0, 3), 0, "tile 0 should fall to bottom (y=3)")
	assert_eq(b.get_tile(0, 2), 1, "tile 1 should settle above (y=2)")
	assert_eq(b.get_tile(0, 0), MatchingBoard.EMPTY, "y=0 should be empty")
	assert_eq(b.get_tile(0, 1), MatchingBoard.EMPTY, "y=1 should be empty")


func test_fill_empty_leaves_no_empty_cells() -> void:
	var b := _make_board()
	# Clear the entire board then fill
	for y in range(b.height):
		for x in range(b.width):
			b._grid[y][x] = MatchingBoard.EMPTY
	b.fill_empty()
	for y in range(b.height):
		for x in range(b.width):
			assert_ne(b.get_tile(x, y), MatchingBoard.EMPTY,
				"cell (%d,%d) should not be EMPTY after fill" % [x, y])


func test_resolve_step_returns_empty_when_no_matches() -> void:
	var b := _make_board()
	var result := b.resolve_step()
	assert_true(result.is_empty(), "resolve_step on board with no matches should return empty dict")


func test_resolve_step_clears_matches_and_refills() -> void:
	var b := _make_small(4, 1, 2)
	# Force a 3-in-a-row match: [0, 0, 0, 1]
	b._grid[0][0] = 0
	b._grid[0][1] = 0
	b._grid[0][2] = 0
	b._grid[0][3] = 1
	var result := b.resolve_step()
	assert_false(result.is_empty(), "resolve_step should detect the match")
	assert_eq(result.match_count, 3, "3 tiles should be cleared")
	# After resolve, board should have no empty cells
	for x in range(4):
		assert_ne(b.get_tile(x, 0), MatchingBoard.EMPTY,
			"cell x=%d should be filled after resolve" % x)
