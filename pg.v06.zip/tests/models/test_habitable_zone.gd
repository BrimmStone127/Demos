extends "res://tests/test_base.gd"

func before_each():
	seed(12345)

func test_g_star_has_habitable_zone():
	var hz = HabitableZone.new(StarSystem.StarType.G, 1.0)
	assert_true(hz.has_habitable_zone, "G star with luminosity 1.0 should have habitable zone")

func test_zone_boundaries_ordered():
	var hz = HabitableZone.new(StarSystem.StarType.G, 1.0)
	assert_lt(hz.optimistic_inner, hz.conservative_inner, "optimistic_inner < conservative_inner")
	assert_lt(hz.conservative_inner, hz.conservative_outer, "conservative_inner < conservative_outer")
	assert_lt(hz.conservative_outer, hz.optimistic_outer, "conservative_outer < optimistic_outer")

func test_zone_type_too_hot():
	var hz = HabitableZone.new(StarSystem.StarType.G, 1.0)
	var zone = hz.get_zone_type(1.0, 0.0)
	assert_eq(zone, HabitableZone.ZoneType.TOO_HOT)

func test_zone_type_conservative():
	var hz = HabitableZone.new(StarSystem.StarType.G, 1.0)
	var mid = (hz.conservative_inner + hz.conservative_outer) / 2.0
	var zone = hz.get_zone_type(mid, 0.0)
	assert_eq(zone, HabitableZone.ZoneType.CONSERVATIVE)

func test_zone_type_too_cold():
	var hz = HabitableZone.new(StarSystem.StarType.G, 1.0)
	var distance = hz.optimistic_outer + 10.0
	var zone = hz.get_zone_type(distance, 0.0)
	assert_true(zone == HabitableZone.ZoneType.TOO_COLD or zone == HabitableZone.ZoneType.FROZEN)

func test_zone_type_frozen():
	var hz = HabitableZone.new(StarSystem.StarType.G, 1.0)
	var zone = hz.get_zone_type(10000.0, 0.0)
	assert_eq(zone, HabitableZone.ZoneType.FROZEN)

func test_o_star_short_lifetime_no_zone():
	var hz = HabitableZone.new(StarSystem.StarType.O, 50000.0)
	assert_false(hz.has_habitable_zone, "O star should not have habitable zone due to short lifetime")

func test_habitability_score_rocky_in_zone():
	var hz = HabitableZone.new(StarSystem.StarType.G, 1.0)
	assert_true(hz.has_habitable_zone)
	var mid = (hz.conservative_inner + hz.conservative_outer) / 2.0
	var score = hz.calculate_habitability_score(mid, PlanetEnums.PlanetType.ROCKY_MEDIUM, 1.0, 0.0)
	assert_gt(score, 0.0, "Rocky planet in zone should have positive score")
	assert_lte(score, 1.0, "Score should be <= 1.0")

func test_habitability_score_outside_zone():
	var hz = HabitableZone.new(StarSystem.StarType.G, 1.0)
	var score = hz.calculate_habitability_score(10000.0, PlanetEnums.PlanetType.ROCKY_MEDIUM, 1.0, 0.0)
	assert_eq(score, 0.0, "Planet far outside zone should have score 0")

func test_habitable_orbit_fraction_circular():
	var hz = HabitableZone.new(StarSystem.StarType.G, 1.0)
	var mid = (hz.conservative_inner + hz.conservative_outer) / 2.0
	var fraction = hz.calculate_habitable_orbit_fraction(mid, 0.0, PlanetEnums.PlanetType.ROCKY_MEDIUM)
	assert_gte(fraction, 0.5, "Circular orbit in zone should have fraction >= 0.5")

func test_zone_info_structure():
	var hz = HabitableZone.new(StarSystem.StarType.G, 1.0)
	var info = hz.get_zone_info()
	for key in ["has_zone", "conservative_inner", "conservative_outer", "optimistic_inner", "optimistic_outer", "frost_line", "luminosity", "star_type", "width", "zone_eccentricity", "zone_angle_offset"]:
		assert_has(info, key, "Zone info should have key: %s" % key)
