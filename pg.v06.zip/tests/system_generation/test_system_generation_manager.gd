extends "res://tests/test_base.gd"

class DummyMain extends Node2D:
	var game_started := false
	var star_system: StarSystem

class DummyTransitionManager extends Node:
	func fade_to_black(_duration): return
	func fade_from_black(_duration): return

class DummyUIManager extends Node:
	var was_showing_info_panel := false
	func show_loading(): return
	func hide_loading(): return
	func save_ui_state(): return
	func close_info_panel(): return
	func restore_ui_state(): return
	func update_options_seed_info(_seed, _type): return
	func show_celestial_info(): return null

class DummyCameraManager extends Node:
	func stop_tracking(): return
	func reset_camera(): return
	func make_camera_current(): return

class DummySceneManager extends Node:
	func get_current_scene_type(): return 0
	func get_current_scene_node(): return null
	func change_scene(_node, _scene_type, _data): return

class DummySystemStateManager extends Node:
	func has_system_state(_seed): return false
	func save_system_state(_system, _probe): return

class DummyProbeSystem extends Node:
	pass

class DummyStarBackground extends Node:
	var is_generated := true
	var current_seed := 0
	func generate(_seed_val):
		is_generated = true
		current_seed = _seed_val

func test_context_without_existing_system():
	var harness = _build_harness()
	harness.manager.initialize(harness.services, harness.assets)
	harness.services.main_node.game_started = true
	harness.services.main_node.star_system = null
	var context = harness.manager._build_context(42)
	assert_false(context.should_show_transition, "Transition flag should be false with no existing system")

func test_context_with_existing_system():
	var harness = _build_harness()
	harness.manager.initialize(harness.services, harness.assets)
	harness.services.main_node.game_started = true
	var dummy_system = autofree(StarSystem.new())
	harness.services.main_node.star_system = dummy_system
	var context = harness.manager._build_context(84)
	assert_true(context.should_show_transition, "Transition flag should be true when existing system present")

func test_game_services_missing_required():
	var services = GameServices.new()
	services.main_node = autofree(DummyMain.new())
	var missing = services.missing_required()
	var expected = PackedStringArray(["transition_manager", "ui_manager", "time_manager", "camera_manager", "scene_manager"])
	for svc_name in expected:
		assert_has(missing, svc_name, "Expected missing list to include %s" % svc_name)

func _build_harness() -> Dictionary:
	var services = GameServices.new()
	services.main_node = autofree(DummyMain.new())
	services.transition_manager = autofree(DummyTransitionManager.new())
	services.ui_manager = autofree(DummyUIManager.new())
	services.camera_manager = autofree(DummyCameraManager.new())
	services.scene_manager = autofree(DummySceneManager.new())
	services.system_state_manager = autofree(DummySystemStateManager.new())
	services.network_manager = autofree(Node.new())
	services.star_background = autofree(DummyStarBackground.new())
	services.probe_system = autofree(DummyProbeSystem.new())
	services.dialogue_manager = autofree(Node.new())
	services.logger = GameLogger.new()

	var assets = GameAssets.new()
	assets.sun_texture = _create_placeholder_texture()
	assets.planet_texture = _create_placeholder_texture()

	return {
		"services": services,
		"assets": assets,
		"manager": autofree(SystemGenerationManager.new())
	}

func _create_placeholder_texture() -> Texture2D:
	var image := Image.create(1, 1, false, Image.FORMAT_RGBA8)
	image.fill(Color.WHITE)
	return ImageTexture.create_from_image(image)
