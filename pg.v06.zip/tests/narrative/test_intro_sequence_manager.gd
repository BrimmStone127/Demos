extends "res://tests/test_node_base.gd"

# Tests for IntroSequenceManager

var manager: IntroSequenceManager

func before_each():
	manager = IntroSequenceManager.new()
	add_child(manager)
	autofree(manager)

func test_manager_loads_intro_data():
	assert_true(manager.intro_data.has("intro_sequences"))
	assert_true(manager.intro_data.intro_sequences.size() > 0)

func test_select_intro_for_seed_in_range():
	var intro = manager.select_intro_for_seed(500000)
	assert_eq(intro.id, "intro_01")
	assert_true(intro.has("conversation"))

func test_select_intro_for_second_range():
	var intro = manager.select_intro_for_seed(1500000)
	assert_eq(intro.id, "intro_02")

func test_select_intro_fallback_for_out_of_range():
	var intro = manager.select_intro_for_seed(99999999)
	assert_true(not intro.is_empty())
	assert_eq(intro.id, "intro_01")

func test_start_sequence_returns_sequence():
	var result = manager.start_sequence(500000)
	assert_false(result.is_empty(), "start_sequence should return non-empty dict")
	assert_eq(result.id, "intro_01")

func test_start_sequence_sets_current():
	manager.start_sequence(500000)
	assert_false(manager.current_sequence.is_empty())
	assert_eq(manager.current_sequence.id, "intro_01")

func test_get_conversation_returns_conversation():
	manager.start_sequence(500000)
	var conversation = manager.get_conversation()
	assert_not_null(conversation)

func test_has_conversation():
	manager.start_sequence(500000)
	assert_true(manager.has_conversation())

func test_convert_to_dialogue_data():
	var test_dict = {
		"speaker": "Test Speaker",
		"text": "Test text",
		"typing_speed": 0.1,
		"auto_close_time": 2.0,
		"choices": ["Option 1", "Option 2"]
	}
	var data = manager.convert_to_dialogue_data(test_dict)
	assert_eq(data.speaker, "Test Speaker")
	assert_eq(data.text, "Test text")
	assert_almost_eq(data.typing_speed, 0.1, 0.01)
	assert_almost_eq(data.auto_close_time, 2.0, 0.01)
	assert_eq(data.choices.size(), 2)

func test_complete_sequence_clears_current():
	manager.start_sequence(500000)
	assert_false(manager.current_sequence.is_empty())
	manager.complete_sequence()
	assert_true(manager.current_sequence.is_empty())

func test_game_seed_stored():
	manager.start_sequence(500000)
	assert_eq(manager.game_seed, 500000)
