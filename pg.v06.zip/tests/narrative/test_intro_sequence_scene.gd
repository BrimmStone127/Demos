extends "res://tests/test_node_base.gd"

# Tests for IntroSequenceScene

var scene: IntroSequenceScene
var manager: IntroSequenceManager

func before_each():
	manager = IntroSequenceManager.new()
	add_child(manager)
	autofree(manager)

	scene = IntroSequenceScene.new()
	add_child(scene)
	autofree(scene)
	await wait_frames(1)

func test_scene_creates_black_background():
	assert_not_null(scene.black_background)
	assert_eq(scene.black_background.color, Color(0, 0, 0, 1))

func test_scene_creates_ui_container():
	assert_not_null(scene.ui_container)

func test_start_sequence_sets_playing():
	scene.start_sequence(manager, 500000)
	await wait_frames(2)
	assert_true(scene.is_playing)

func test_start_sequence_loads_conversation():
	scene.start_sequence(manager, 500000)
	await wait_frames(2)
	assert_not_null(scene.conversation)

func test_skip_sequence_stops_playback():
	scene.start_sequence(manager, 500000)
	await wait_frames(2)
	assert_true(scene.is_playing)

	scene.skip_sequence()
	await wait_frames(1)

	assert_false(scene.is_playing)

func test_escape_key_skips_sequence():
	scene.start_sequence(manager, 500000)
	await wait_frames(2)
	assert_true(scene.is_playing)

	var event = InputEventKey.new()
	event.keycode = KEY_ESCAPE
	event.pressed = true
	scene._input(event)
	await wait_frames(1)

	assert_false(scene.is_playing)
