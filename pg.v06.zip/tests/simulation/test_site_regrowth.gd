extends "res://tests/test_base.gd"

## Tests for abandoned site regrowth and village return cycling.


func _create_village_manager() -> VillageManager:
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()
	return manager


# --- Abandoned site ticking ---

func test_abandoned_site_transitions_to_regrown():
	var manager = _create_village_manager()
	var village = manager.register_village("planet_1", "test_v", "mississippi_early", [], false)
	village.camp_position = Vector2i(100, 100)

	# Create an abandoned past site
	var old_site = SettlementSite.new()
	old_site.initialize("test_v_site_old", Vector2i(50, 50), 0)
	old_site.status = SettlementSite.Status.ABANDONED
	old_site.abandoned_year = 0
	village.past_sites.append(old_site)

	# Simulate enough years
	village.age_in_years = VillageManager.REGROWTH_YEARS
	manager._tick_abandoned_sites(village)
	assert_eq(old_site.status, SettlementSite.Status.REGROWN, "Site should be REGROWN after REGROWTH_YEARS")


func test_abandoned_site_not_regrown_too_early():
	var manager = _create_village_manager()
	var village = manager.register_village("planet_1", "test_v", "mississippi_early", [], false)
	village.camp_position = Vector2i(100, 100)

	var old_site = SettlementSite.new()
	old_site.initialize("test_v_site_old", Vector2i(50, 50), 0)
	old_site.status = SettlementSite.Status.ABANDONED
	old_site.abandoned_year = 5
	village.past_sites.append(old_site)

	village.age_in_years = 10
	manager._tick_abandoned_sites(village)
	assert_eq(old_site.status, SettlementSite.Status.ABANDONED, "Should still be ABANDONED (only 5 years)")


func test_regrown_site_not_reticked():
	var manager = _create_village_manager()
	var village = manager.register_village("planet_1", "test_v", "mississippi_early", [], false)
	village.camp_position = Vector2i(100, 100)

	var old_site = SettlementSite.new()
	old_site.initialize("test_v_site_old", Vector2i(50, 50), 0)
	old_site.status = SettlementSite.Status.REGROWN
	village.past_sites.append(old_site)

	village.age_in_years = 100
	manager._tick_abandoned_sites(village)
	assert_eq(old_site.status, SettlementSite.Status.REGROWN, "Already REGROWN, unchanged")


# --- Return to regrown site ---

func test_consider_relocation_prefers_regrown_site():
	var manager = _create_village_manager()
	var village = manager.register_village("planet_1", "test_v", "mississippi_early", [], false)
	village.camp_position = Vector2i(100, 100)

	var regrown_site = SettlementSite.new()
	regrown_site.initialize("test_v_site_0", Vector2i(200, 200), 0)
	regrown_site.status = SettlementSite.Status.REGROWN
	regrown_site.abandoned_year = 0
	village.past_sites.append(regrown_site)

	manager._consider_relocation(village)
	assert_eq(village.camp_position, Vector2i(200, 200), "Returned to regrown site")
	assert_eq(village.active_site.status, SettlementSite.Status.ACTIVE, "Site reactivated")


func test_return_clears_regrown_from_past_sites():
	var manager = _create_village_manager()
	var village = manager.register_village("planet_1", "test_v", "mississippi_early", [], false)
	village.camp_position = Vector2i(100, 100)

	var regrown_site = SettlementSite.new()
	regrown_site.initialize("test_v_site_0", Vector2i(200, 200), 0)
	regrown_site.status = SettlementSite.Status.REGROWN
	village.past_sites.append(regrown_site)

	manager._consider_relocation(village)
	# past_sites should have old 100,100 site (just abandoned) but not the returned-to site
	var has_returned_site := false
	for site in village.past_sites:
		if site.center == Vector2i(200, 200):
			has_returned_site = true
	assert_false(has_returned_site, "Returned-to site not in past_sites")


func test_village_area_only_checks_active_sites():
	var manager = _create_village_manager()
	var village = manager.register_village("planet_1", "test_v", "mississippi_early", [], false)
	village.camp_position = Vector2i(100, 100)

	# Relocate so old site is abandoned
	manager._relocate_village(village, Vector2i(300, 300), null)

	# Old site area should NOT be protected
	assert_false(manager.is_in_village_area("planet_1", Vector2i(100, 100)),
		"Abandoned site area not protected")
	# New site area should be protected
	assert_true(manager.is_in_village_area("planet_1", Vector2i(300, 300)),
		"Active site area protected")


# --- Multiple past sites ---

func test_multiple_abandoned_sites_tick_independently():
	var manager = _create_village_manager()
	var village = manager.register_village("planet_1", "test_v", "mississippi_early", [], false)
	village.camp_position = Vector2i(100, 100)

	var site_a = SettlementSite.new()
	site_a.initialize("site_a", Vector2i(50, 50), 0)
	site_a.status = SettlementSite.Status.ABANDONED
	site_a.abandoned_year = 0
	village.past_sites.append(site_a)

	var site_b = SettlementSite.new()
	site_b.initialize("site_b", Vector2i(200, 200), 0)
	site_b.status = SettlementSite.Status.ABANDONED
	site_b.abandoned_year = 10
	village.past_sites.append(site_b)

	village.age_in_years = 15
	manager._tick_abandoned_sites(village)
	assert_eq(site_a.status, SettlementSite.Status.REGROWN, "Site A regrown (15 years)")
	assert_eq(site_b.status, SettlementSite.Status.ABANDONED, "Site B still abandoned (5 years)")


func test_full_cycle_abandon_regrow_return():
	var manager = _create_village_manager()
	var village = manager.register_village("planet_1", "test_v", "mississippi_early", [], false)
	village.camp_position = Vector2i(100, 100)
	village.age_in_years = 0

	# Step 1: Relocate to new site
	manager._relocate_village(village, Vector2i(300, 300), null)
	assert_eq(village.camp_position, Vector2i(300, 300), "Moved to new site")
	assert_eq(village.past_sites.size(), 1, "One past site")
	assert_eq(village.past_sites[0].status, SettlementSite.Status.ABANDONED, "Old site abandoned")

	# Step 2: Advance time past regrowth period
	village.age_in_years = VillageManager.REGROWTH_YEARS + 1
	manager._tick_abandoned_sites(village)
	assert_eq(village.past_sites[0].status, SettlementSite.Status.REGROWN, "Old site regrown")

	# Step 3: Consider relocation — should return to regrown site
	manager._consider_relocation(village)
	assert_eq(village.camp_position, Vector2i(100, 100), "Returned to original site")
	assert_eq(village.active_site.status, SettlementSite.Status.ACTIVE, "Returned site active")
	# Now past_sites has the 300,300 site
	assert_eq(village.past_sites.size(), 1, "One past site (the 300,300 one)")
	assert_eq(village.past_sites[0].center, Vector2i(300, 300), "300,300 is now the past site")
