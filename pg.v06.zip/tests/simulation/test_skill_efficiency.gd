extends "res://tests/test_base.gd"

## Tests for skill-based foraging efficiency in VillagerSystem.
## Verifies that skill level affects gather time and food yield.

const LOG_TAG := "TEST_SKILL_EFFICIENCY"


func _make_person(foraging_level: int) -> PersonInstance:
	var person = PersonInstance.new()
	var skills: Array[String] = ["foraging", "hunting", "shelter_building"]
	person.initialize("test_001", "Tester", PersonInstance.Sex.MALE, 25, skills)
	person.skills["foraging"] = foraging_level
	return person


func _make_villager(foraging_level: int) -> VillagerSystem.VillagerData:
	var v = VillagerSystem.VillagerData.new()
	v.person = _make_person(foraging_level)
	v.village_id = "test_village"
	return v


func _make_system() -> VillagerSystem:
	return VillagerSystem.new()


# --- _get_skill_modifier ---

func test_skill_modifier_zero_at_level_zero():
	var sys = _make_system()
	var v = _make_villager(0)
	var mod := sys._get_skill_modifier(v, "foraging")
	assert_almost_eq(mod, 0.0, 0.01, "Modifier should be 0.0 at skill level 0")


func test_skill_modifier_one_at_level_100():
	var sys = _make_system()
	var v = _make_villager(100)
	var mod := sys._get_skill_modifier(v, "foraging")
	assert_almost_eq(mod, 1.0, 0.01, "Modifier should be 1.0 at skill level 100")


func test_skill_modifier_half_at_level_50():
	var sys = _make_system()
	var v = _make_villager(50)
	var mod := sys._get_skill_modifier(v, "foraging")
	assert_almost_eq(mod, 0.5, 0.01, "Modifier should be 0.5 at skill level 50")


func test_skill_modifier_zero_for_unknown_skill():
	var sys = _make_system()
	var v = _make_villager(50)
	var mod := sys._get_skill_modifier(v, "nonexistent_skill")
	assert_almost_eq(mod, 0.0, 0.01, "Modifier should be 0.0 for unknown skill")


func test_skill_modifier_zero_when_no_person():
	var sys = _make_system()
	var v = VillagerSystem.VillagerData.new()
	v.person = null
	var mod := sys._get_skill_modifier(v, "foraging")
	assert_almost_eq(mod, 0.0, 0.01, "Modifier should be 0.0 when person is null")


# --- _skill_for_carrying ---

func test_skill_for_food_is_foraging():
	var sys = _make_system()
	assert_eq(sys._skill_for_carrying("food"), "foraging", "food should map to foraging")


func test_skill_for_water_is_foraging():
	var sys = _make_system()
	assert_eq(sys._skill_for_carrying("water"), "foraging", "water should map to foraging")


func test_skill_for_firewood_is_shelter_building():
	var sys = _make_system()
	assert_eq(sys._skill_for_carrying("firewood"), "shelter_building", "firewood should map to shelter_building")


func test_skill_for_empty_returns_empty():
	var sys = _make_system()
	assert_eq(sys._skill_for_carrying(""), "", "empty carrying should return empty string")


# --- Gather time scaling ---

func test_gather_time_max_at_skill_zero():
	# At skill 0: GATHER_TIME * (1.0 - 0.5 * 0.0) = GATHER_TIME
	var expected := VillagerSystem.GATHER_TIME
	var skill_mod := 0.0
	var actual := VillagerSystem.GATHER_TIME * (1.0 - 0.5 * skill_mod)
	assert_almost_eq(actual, expected, 0.01, "Gather time should be full at skill 0")


func test_gather_time_halved_at_skill_100():
	# At skill 100: GATHER_TIME * (1.0 - 0.5 * 1.0) = GATHER_TIME * 0.5
	var expected := VillagerSystem.GATHER_TIME * 0.5
	var skill_mod := 1.0
	var actual := VillagerSystem.GATHER_TIME * (1.0 - 0.5 * skill_mod)
	assert_almost_eq(actual, expected, 0.01, "Gather time should be halved at skill 100")


# --- Food yield scaling ---

func test_food_yield_low_at_skill_zero():
	# At skill 0: FOOD_STORE_AMOUNT * (0.7 + 0.6 * 0.0) = FOOD_STORE_AMOUNT * 0.7
	var expected := VillagerSystem.FOOD_STORE_AMOUNT * 0.7
	var skill_mod := 0.0
	var actual := VillagerSystem.FOOD_STORE_AMOUNT * (0.7 + 0.6 * skill_mod)
	assert_almost_eq(actual, expected, 0.01, "Food yield should be 70% at skill 0")


func test_food_yield_high_at_skill_100():
	# At skill 100: FOOD_STORE_AMOUNT * (0.7 + 0.6 * 1.0) = FOOD_STORE_AMOUNT * 1.3
	var expected := VillagerSystem.FOOD_STORE_AMOUNT * 1.3
	var skill_mod := 1.0
	var actual := VillagerSystem.FOOD_STORE_AMOUNT * (0.7 + 0.6 * skill_mod)
	assert_almost_eq(actual, expected, 0.01, "Food yield should be 130% at skill 100")


func test_high_skill_yields_more_than_low_skill():
	var low := VillagerSystem.FOOD_STORE_AMOUNT * (0.7 + 0.6 * 0.1)
	var high := VillagerSystem.FOOD_STORE_AMOUNT * (0.7 + 0.6 * 0.9)
	assert_gt(high, low, "High skill should yield more food than low skill")
