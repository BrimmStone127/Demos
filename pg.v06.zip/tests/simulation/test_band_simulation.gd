extends "res://tests/test_base.gd"

## Tests for the village simulation framework.
## Covers PersonInstance, VillageInstance, VillageRelationship, and ScenarioLoader.

const LOG_TAG := "TEST_VILLAGE"


# --- ScenarioLoader ---

func test_scenario_loader_returns_mississippi_early():
	var loader = ScenarioLoader.new()
	var data = loader.load_scenario("mississippi_early")
	assert_true(not data.is_empty(), "mississippi_early scenario should load")
	assert_eq(data.get("id", ""), "mississippi_early", "Scenario id should match")


func test_scenario_loader_returns_empty_for_unknown():
	var loader = ScenarioLoader.new()
	var data = loader.load_scenario("nonexistent_scenario")
	assert_true(data.is_empty(), "Unknown scenario should return empty dict")


func test_scenario_has_required_keys():
	var loader = ScenarioLoader.new()
	var data = loader.load_scenario("mississippi_early")
	assert_true(data.has("starting_era"), "Should have starting_era")
	assert_true(data.has("starting_skills"), "Should have starting_skills")
	assert_true(data.has("starting_political_traits"), "Should have starting_political_traits")
	assert_true(data.has("skills"), "Should have skills dict")
	assert_true(data.has("eras"), "Should have eras dict")


# --- PersonInstance ---

func test_person_initializes_correctly():
	var loader = ScenarioLoader.new()
	var scenario = loader.load_scenario("mississippi_early")
	var skills: Array[String] = []
	for s in scenario.get("starting_skills", []):
		skills.append(s)

	var person = PersonInstance.new()
	person.initialize("test_001", "Hawk", PersonInstance.Sex.MALE, 25, skills)

	assert_eq(person.person_id, "test_001", "Person id should match")
	assert_eq(person.name, "Hawk", "Name should match")
	assert_eq(person.age, 25, "Age should match")
	assert_eq(person.sex, PersonInstance.Sex.MALE, "Sex should match")
	assert_true(person.health > 0.0, "Health should be positive")
	assert_true(person.skills.size() > 0, "Should have skills")


func test_person_is_alive_at_young_age():
	var person = PersonInstance.new()
	person.initialize("test_002", "River", PersonInstance.Sex.FEMALE, 20, ["hunting"])
	assert_true(person.is_alive(), "Young healthy person should be alive")


func test_person_dies_at_max_age():
	var person = PersonInstance.new()
	person.initialize("test_003", "Stone", PersonInstance.Sex.MALE, 80, [])
	assert_false(person.is_alive(), "Person at age 80 should not be alive")


func test_person_can_conceive_conditions():
	var person = PersonInstance.new()
	person.initialize("test_004", "Moon", PersonInstance.Sex.FEMALE, 25, [])
	person.health = 0.8
	person.months_since_child = 999
	assert_true(person.can_conceive(), "Healthy adult female should be able to conceive")


func test_male_cannot_conceive():
	var person = PersonInstance.new()
	person.initialize("test_005", "Cedar", PersonInstance.Sex.MALE, 25, [])
	assert_false(person.can_conceive(), "Male should not be able to conceive")


func test_person_too_old_cannot_conceive():
	var person = PersonInstance.new()
	person.initialize("test_006", "Fern", PersonInstance.Sex.FEMALE, 50, [])
	assert_false(person.can_conceive(), "Female over 45 should not be able to conceive")


func test_pregnant_woman_cannot_conceive():
	var person = PersonInstance.new()
	person.initialize("test_preg", "Willow", PersonInstance.Sex.FEMALE, 25, [])
	person.months_since_child = 999
	person.conceive()
	assert_false(person.can_conceive(), "Pregnant woman should not be able to conceive again")


func test_pregnancy_produces_birth():
	var person = PersonInstance.new()
	person.initialize("test_birth", "River", PersonInstance.Sex.FEMALE, 25, [])
	person.conceive()
	# Advance through 8 months — no birth yet
	for i in range(8):
		assert_false(person.tick_pregnancy(), "No birth before 9 months")
	# Month 9 — birth
	assert_true(person.tick_pregnancy(), "Birth should happen at 9 months")
	assert_false(person.is_pregnant, "Should no longer be pregnant after birth")


func test_postpartum_prevents_conception():
	var person = PersonInstance.new()
	person.initialize("test_pp", "Dawn", PersonInstance.Sex.FEMALE, 25, [])
	person.months_since_child = 0
	assert_false(person.can_conceive(), "Postpartum woman should not conceive")


func test_person_tick_increases_age():
	var person = PersonInstance.new()
	person.initialize("test_007", "Crane", PersonInstance.Sex.MALE, 20, ["tracking"])
	var rng = RandomNumberGenerator.new()
	rng.seed = 42
	person.tick_year(rng)
	assert_eq(person.age, 21, "Age should increase by 1 per year tick")


# --- VillageInstance ---

func test_village_initializes_from_scenario():
	var loader = ScenarioLoader.new()
	var scenario = loader.load_scenario("mississippi_early")

	var village = VillageInstance.new()
	village.initialize("village_001", "planet_test", "mississippi_early", scenario)

	assert_eq(village.village_id, "village_001", "Village id should match")
	assert_eq(village.planet_id, "planet_test", "Planet id should match")
	assert_eq(village.era, "nomadic", "Starting era should be nomadic")
	assert_true(village.group_knowledge.size() > 0, "Village should have starting skills")
	assert_true(village.political_traits.size() > 0, "Village should have political traits")


func test_village_populates_with_individuals():
	var loader = ScenarioLoader.new()
	var scenario = loader.load_scenario("mississippi_early")

	var village = VillageInstance.new()
	village.initialize("village_002", "planet_test", "mississippi_early", scenario)
	village.populate(25)

	assert_true(village.get_population() > 0, "Village should have people after populate")
	assert_true(village.get_population() <= 30, "Village should not exceed reasonable size")


func test_village_is_viable_with_enough_people():
	var loader = ScenarioLoader.new()
	var scenario = loader.load_scenario("mississippi_early")

	var village = VillageInstance.new()
	village.initialize("village_003", "planet_test", "mississippi_early", scenario)
	village.populate(25)

	assert_true(village.is_viable(), "Village of 25 should be viable")


func test_village_not_viable_when_empty():
	var loader = ScenarioLoader.new()
	var scenario = loader.load_scenario("mississippi_early")

	var village = VillageInstance.new()
	village.initialize("village_004", "planet_test", "mississippi_early", scenario)
	# Don't populate

	assert_false(village.is_viable(), "Empty village should not be viable")


func test_village_tick_year_returns_events():
	var loader = ScenarioLoader.new()
	var scenario = loader.load_scenario("mississippi_early")

	var village = VillageInstance.new()
	village.initialize("village_005", "planet_test", "mississippi_early", scenario)
	village.populate(25)

	var events = village.tick_year(0)
	assert_true(events.has("died"), "Events should have died key")
	# Births now happen via tick_month(), not tick_year()
	var born := village.tick_month()
	assert_true(born is Array, "tick_month should return array of born names")


func test_village_population_changes_over_time():
	var loader = ScenarioLoader.new()
	var scenario = loader.load_scenario("mississippi_early")

	var village = VillageInstance.new()
	village.initialize("village_006", "planet_test", "mississippi_early", scenario)
	village.populate(25)
	var initial_pop = village.get_population()

	# Simulate 10 years
	for i in range(10):
		village.tick_year(i)

	# Population should have changed (births and deaths)
	# We can't assert exact value but village should still exist
	assert_true(village.get_population() >= 0, "Population should be non-negative after 10 years")
	assert_true(initial_pop > 0, "Initial population was valid")


# --- VillageRelationship ---

func test_village_relationship_initializes_unknown():
	var rel = VillageRelationship.new()
	rel.initialize("other_village")
	assert_eq(rel.stance, VillageRelationship.Stance.UNKNOWN, "New relationship should be UNKNOWN")
	assert_eq(rel.other_village_id, "other_village", "Other village id should match")


func test_village_relationship_records_contact():
	var rel = VillageRelationship.new()
	rel.initialize("other_village")
	rel.record_contact(100, "trade", "success")
	assert_eq(rel.get_contact_count(), 1, "Should have one contact record")


func test_village_sets_relationship_with_other():
	var loader = ScenarioLoader.new()
	var scenario = loader.load_scenario("mississippi_early")

	var village = VillageInstance.new()
	village.initialize("village_a", "planet_test", "mississippi_early", scenario)

	var rel = village.set_village_relationship("village_b")
	assert_true(rel != null, "Relationship should be created")
	assert_eq(rel.stance, VillageRelationship.Stance.UNKNOWN, "New inter-village relationship should be UNKNOWN")
	assert_true(village.village_relationships.has("village_b"), "Village should have relationship entry")
