extends "res://tests/test_base.gd"

## Tests for population equilibrium systems: birth suppression, child mortality,
## density disease, deflated resource pressure, seasons, inter-village competition.


func _create_demographics(pop: int, children: int = 0, adults: int = 0, elders: int = 0) -> VillageDemographics:
	var demo = VillageDemographics.new()
	demo.population = pop
	if children == 0 and adults == 0 and elders == 0:
		# Default age distribution
		demo.age_buckets[0] = int(pop * 0.3)
		demo.age_buckets[1] = int(pop * 0.5)
		demo.age_buckets[2] = pop - int(pop * 0.3) - int(pop * 0.5)
	else:
		demo.age_buckets[0] = children
		demo.age_buckets[1] = adults
		demo.age_buckets[2] = elders
	demo.male_count = pop / 2
	demo.female_count = pop - demo.male_count
	demo.avg_health = 0.8
	demo.avg_age = 25.0
	demo.avg_hunger = 0.7
	demo.avg_thirst = 0.7
	demo.avg_rest = 0.8
	demo.avg_skills = {"foraging": 20.0}
	demo.max_skill_levels = {"foraging": 30}
	return demo


func _create_rng(seed_val: int = 42) -> RandomNumberGenerator:
	var rng = RandomNumberGenerator.new()
	rng.seed = seed_val
	return rng


# --- Phase 2A: Birth Suppression ---

func test_birth_suppression_high_nutrition():
	var demo = _create_demographics(50, 5, 35, 10)
	demo.avg_hunger = 0.8
	demo.avg_thirst = 0.8
	var rng = _create_rng()
	var total_births := 0
	for _i in range(100):
		total_births += demo.tick_month(rng, 0.5)
	# With good nutrition, births should be healthy
	assert_true(total_births > 0, "Should have births at high nutrition")


func test_birth_suppression_low_nutrition():
	var demo_good = _create_demographics(50, 5, 35, 10)
	demo_good.avg_hunger = 0.8
	demo_good.avg_thirst = 0.8
	var rng1 = _create_rng(42)

	var demo_bad = _create_demographics(50, 5, 35, 10)
	demo_bad.avg_hunger = 0.2
	demo_bad.avg_thirst = 0.3
	var rng2 = _create_rng(42)

	var births_good := 0
	var births_bad := 0
	for _i in range(200):
		births_good += demo_good.tick_month(rng1, 0.5)
		births_bad += demo_bad.tick_month(rng2, 0.5)

	# Low nutrition should significantly reduce births
	assert_true(births_bad < births_good, "Low nutrition should produce fewer births (good: %d, bad: %d)" % [births_good, births_bad])
	# Should be substantially fewer, not just marginally
	if births_good > 0:
		var ratio := float(births_bad) / float(births_good)
		assert_true(ratio < 0.7, "Birth ratio should be below 0.7 (got: %.2f)" % ratio)


func test_nutrition_factor_never_zero():
	var demo = _create_demographics(50, 5, 35, 10)
	demo.avg_hunger = 0.0
	demo.avg_thirst = 0.0
	var rng = _create_rng()
	# Even at zero nutrition, MIN_NUTRITION_FERTILITY (0.1) should allow rare births
	var total_births := 0
	for _i in range(500):
		total_births += demo.tick_month(rng, 1.0)
	# With 500 months and minimum fertility, we should still see some births
	assert_true(total_births >= 0, "Births should be non-negative even at zero nutrition")


# --- Phase 2B: Child Mortality ---

func test_child_mortality_demographics():
	var demo = _create_demographics(100, 100, 0, 0)
	var rng = _create_rng()
	var total_child_deaths := 0
	var initial_children := 100
	# Run 20 years — children should die
	for _i in range(20):
		var deaths = demo.tick_year(rng)
		total_child_deaths += deaths
	# At 3% per year over 20 years on 100 starting children, expect ~30-60 deaths
	# (including illness deaths and age-out transitions)
	assert_true(demo.age_buckets[0] < initial_children, "Children should decrease over time (remaining: %d)" % demo.age_buckets[0])


func test_child_mortality_person_instance():
	var rng = _create_rng()
	var deaths := 0
	var trials := 200
	for _i in range(trials):
		var person = PersonInstance.new()
		person.initialize("p", "Person", PersonInstance.Sex.MALE, 2, ["foraging"])
		person.health = 1.0
		if not person.tick_year(rng, 25):
			deaths += 1
	# At 5% per year for age <= 5, expect ~10 deaths out of 200
	assert_true(deaths > 0, "Some children should die (deaths: %d / %d)" % [deaths, trials])
	assert_true(deaths < trials / 2, "Not too many children should die (deaths: %d / %d)" % [deaths, trials])


# --- Phase 2C: Density Disease ---

func test_density_disease_scales_with_population():
	var rng1 = _create_rng(100)
	var rng2 = _create_rng(100)

	# Small village
	var demo_small = _create_demographics(25, 3, 17, 5)
	var deaths_small := 0
	for _i in range(50):
		deaths_small += demo_small.tick_year(rng1)

	# Large village
	var demo_large = _create_demographics(100, 15, 65, 20)
	var deaths_large := 0
	for _i in range(50):
		deaths_large += demo_large.tick_year(rng2)

	# Normalize by population — large village should have higher per-capita death rate
	var rate_small := float(deaths_small) / 25.0
	var rate_large := float(deaths_large) / 100.0
	assert_true(rate_large > rate_small, "Large village should have higher per-capita death rate (small: %.3f, large: %.3f)" % [rate_small, rate_large])


func test_density_disease_person_instance():
	var rng = _create_rng()
	var illness_small := 0
	var illness_large := 0
	var trials := 500

	for _i in range(trials):
		var p1 = PersonInstance.new()
		p1.initialize("p", "P", PersonInstance.Sex.MALE, 25, [])
		p1.health = 1.0
		p1.tick_year(rng, 25)
		if p1.health < 1.0:
			illness_small += 1

		var p2 = PersonInstance.new()
		p2.initialize("p", "P", PersonInstance.Sex.MALE, 25, [])
		p2.health = 1.0
		p2.tick_year(rng, 100)
		if p2.health < 1.0:
			illness_large += 1

	assert_true(illness_large > illness_small, "Larger village should have more illness events (small: %d, large: %d)" % [illness_small, illness_large])


# --- Phase 3A: Deflated Resource Pressure ---

func test_resource_pressure_stable_below_capacity():
	var demo = _create_demographics(40, 6, 28, 6)
	demo.avg_hunger = 0.7
	demo.avg_thirst = 0.7
	var rng = _create_rng()

	var starvation := demo.tick_resource_pressure(80.0, 1.0, 1.0, rng)
	assert_eq(starvation, 0, "No starvation when pop (40) below capacity (80)")
	assert_true(demo.avg_hunger > 0.5, "Hunger should stay healthy when below capacity (got: %.2f)" % demo.avg_hunger)


func test_resource_pressure_causes_starvation_above_capacity():
	# Pop 120, capacity 20 -> food_ratio = 0.167, below starvation threshold 0.2
	var demo = _create_demographics(120, 18, 80, 22)
	demo.avg_hunger = 0.3
	var rng = _create_rng()

	var total_starvation := 0
	# Run multiple ticks to let hunger drift down below 0.2
	for _i in range(20):
		total_starvation += demo.tick_resource_pressure(20.0, 1.0, 1.0, rng)

	assert_true(total_starvation > 0, "Starvation should occur when pop far exceeds capacity")
	assert_true(demo.avg_hunger < 0.25, "Hunger should decrease when over capacity (got: %.2f)" % demo.avg_hunger)


func test_resource_pressure_competition_reduces_food():
	var demo = _create_demographics(80, 12, 55, 13)
	demo.avg_hunger = 0.7
	var rng = _create_rng()

	# With competition factor 0.5, effective capacity is 40 (below pop 80)
	var total_starvation := 0
	for _i in range(10):
		total_starvation += demo.tick_resource_pressure(80.0, 0.5, 1.0, rng)

	assert_true(demo.avg_hunger < 0.7, "Hunger should drop with competition (got: %.2f)" % demo.avg_hunger)


func test_resource_pressure_winter_stress():
	var demo = _create_demographics(60, 9, 40, 11)
	demo.avg_hunger = 0.7
	var rng = _create_rng()

	# Winter modifier (0.3) on capacity 80 = effective 24, pop 60 > 24
	demo.tick_resource_pressure(80.0, 1.0, 0.3, rng)
	assert_true(demo.avg_hunger < 0.7, "Winter should reduce hunger (got: %.2f)" % demo.avg_hunger)


func test_resource_pressure_starvation_capped():
	var demo = _create_demographics(200, 30, 130, 40)
	demo.avg_hunger = 0.05
	var rng = _create_rng()

	var starvation := demo.tick_resource_pressure(20.0, 1.0, 1.0, rng)
	# Should be capped at 25% of population (50)
	assert_true(starvation <= 50, "Starvation should be capped at 25%% of pop (got: %d)" % starvation)


func test_resource_pressure_drifts_water():
	var demo = _create_demographics(100, 15, 65, 20)
	demo.avg_thirst = 0.9
	var rng = _create_rng()

	for _i in range(5):
		demo.tick_resource_pressure(80.0, 1.0, 1.0, rng)

	# Water should drift toward 1.2 - 100/200 = 0.7
	assert_true(demo.avg_thirst < 0.9, "Thirst should drift toward water ratio (got: %.2f)" % demo.avg_thirst)


# --- Phase 1 & 3B: Season Tracking ---

func test_season_cycles():
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()

	# Season should cycle: spring(0), summer(1), fall(2), winter(3)
	assert_eq(manager.get_season_index(), 0, "Should start at spring")

	# After 2 monthly ticks, should be summer
	manager._monthly_tick_total = 2
	assert_eq(manager.get_season_index(), 1, "Tick 2 should be summer")

	# After 4 ticks, should be fall
	manager._monthly_tick_total = 4
	assert_eq(manager.get_season_index(), 2, "Tick 4 should be fall")

	# After 6 ticks, should be winter
	manager._monthly_tick_total = 6
	assert_eq(manager.get_season_index(), 3, "Tick 6 should be winter")

	# After 8 ticks (1 year), back to spring
	manager._monthly_tick_total = 8
	assert_eq(manager.get_season_index(), 0, "Tick 8 should cycle back to spring")

	autofree(manager)


func test_season_food_modifiers():
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()

	manager._monthly_tick_total = 0  # spring
	assert_eq(manager._get_season_food_modifier(), 0.6, "Spring modifier should be 0.6")

	manager._monthly_tick_total = 2  # summer
	assert_eq(manager._get_season_food_modifier(), 1.2, "Summer modifier should be 1.2")

	manager._monthly_tick_total = 4  # fall
	assert_eq(manager._get_season_food_modifier(), 1.0, "Fall modifier should be 1.0")

	manager._monthly_tick_total = 6  # winter
	assert_eq(manager._get_season_food_modifier(), 0.3, "Winter modifier should be 0.3")

	autofree(manager)


# --- Phase 4: Inter-Village Competition ---

func test_competition_no_neighbors():
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()

	var v1 = manager.register_village("planet_1", "v1", "mississippi_early", [], false)
	v1.camp_position = Vector2i(500, 500)

	manager._update_competition_factors("planet_1")
	assert_eq(v1.competition_factor, 1.0, "No neighbors should give competition factor 1.0")
	autofree(manager)


func test_competition_with_neighbors():
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()

	# Place 3 villages within FORAGING_RADIUS * 2 (400 tiles) of each other
	var v1 = manager.register_village("planet_1", "v1", "mississippi_early", [], false)
	v1.camp_position = Vector2i(100, 100)
	var v2 = manager.register_village("planet_1", "v2", "mississippi_early", [], false)
	v2.camp_position = Vector2i(200, 100)  # 100 tiles apart < 400
	var v3 = manager.register_village("planet_1", "v3", "mississippi_early", [], false)
	v3.camp_position = Vector2i(100, 200)  # 100 tiles apart < 400

	manager._update_competition_factors("planet_1")

	# v1 has 2 neighbors, expected: 1.0 / (1.0 + 2 * 0.25) = 0.667
	assert_true(v1.competition_factor < 1.0, "Should have reduced competition factor with neighbors")
	# 2 neighbors at 0.4 penalty each: 1.0 / (1.0 + 2 * 0.4) = 0.556
	assert_true(abs(v1.competition_factor - (1.0 / 1.8)) < 0.01, "v1 factor should be ~0.556 (got: %.3f)" % v1.competition_factor)
	autofree(manager)


func test_competition_distant_villages():
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()

	var v1 = manager.register_village("planet_1", "v1", "mississippi_early", [], false)
	v1.camp_position = Vector2i(100, 100)
	var v2 = manager.register_village("planet_1", "v2", "mississippi_early", [], false)
	v2.camp_position = Vector2i(1000, 1000)  # ~1272 tiles apart, well beyond overlap

	manager._update_competition_factors("planet_1")
	assert_eq(v1.competition_factor, 1.0, "Distant villages should not compete")
	assert_eq(v2.competition_factor, 1.0, "Distant villages should not compete")
	autofree(manager)


# --- Carrying Capacity & Save/Load ---

func test_carrying_capacity_defaults():
	var village = VillageInstance.new()
	assert_eq(village.carrying_capacity, 50.0, "Default carrying capacity should be 50")
	assert_eq(village.competition_factor, 1.0, "Default competition factor should be 1.0")


func test_carrying_capacity_save_load():
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()
	var village = manager.register_village("planet_1", "v_save", "mississippi_early", [], false)
	village.carrying_capacity = 95.0
	village.competition_factor = 0.75

	var data = village.to_dict()
	var loaded = VillageInstance.from_dict(data)

	assert_eq(loaded.carrying_capacity, 95.0, "Carrying capacity should survive save/load")
	assert_eq(loaded.competition_factor, 0.75, "Competition factor should survive save/load")
	autofree(manager)


func test_season_save_load():
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()
	manager._monthly_tick_total = 42

	var data = manager.export_villages("planet_1")
	assert_eq(data.get("monthly_tick_total"), 42, "monthly_tick_total should be exported")

	manager._monthly_tick_total = 0
	manager.import_villages("planet_1", data)
	assert_eq(manager._monthly_tick_total, 42, "monthly_tick_total should be restored on import")
	autofree(manager)


# --- Integration: Population Convergence ---

func test_population_converges_with_resource_pressure():
	# Start with a village well above carrying capacity
	var demo = _create_demographics(150, 22, 100, 28)
	demo.avg_hunger = 0.7
	demo.avg_thirst = 0.7
	var rng = _create_rng()
	var carrying_capacity := 60.0

	# Run 50 yearly ticks with resource pressure + demographic ticks
	for _i in range(50):
		demo.tick_resource_pressure(carrying_capacity, 1.0, 0.8, rng)
		demo.tick_year(rng)
		demo.tick_month(rng, 0.5)

	# Population should converge toward carrying capacity
	assert_true(demo.population < 150, "Population should decrease from 150 (now: %d)" % demo.population)
	assert_true(demo.population > 0, "Population should not collapse to zero")


# --- Small Population Survival ---

func test_small_village_survives_50_years():
	# A small village (starting size 6) should not collapse over 50 years
	var demo = _create_demographics(6, 2, 3, 1)
	demo.avg_hunger = 0.7
	demo.avg_thirst = 0.7
	var rng = _create_rng(123)
	var carrying_capacity := 50.0

	for _i in range(50):
		demo.tick_resource_pressure(carrying_capacity, 0.5, 0.6, rng)
		demo.tick_year(rng)
		for _m in range(8):
			demo.tick_month(rng, 0.5)

	assert_true(demo.population >= 3, "Small village should survive 50 years (pop: %d)" % demo.population)


func test_graduation_works_for_small_populations():
	# With 5 children, probabilistic graduation should produce adults over time
	var demo = _create_demographics(8, 5, 2, 1)
	var rng = _create_rng(42)

	var total_graduated := 0
	for _i in range(30):
		var before: int = demo.age_buckets[1]
		demo.tick_year(rng)
		var after: int = demo.age_buckets[1]
		if after > before:
			total_graduated += after - before

	# Over 30 years, at least some children should have graduated
	assert_true(total_graduated > 0, "Children should graduate to adults over 30 years")


func test_fertile_women_nonzero_with_females():
	# Even a tiny village with 1 adult female should have fertile women
	var demo = _create_demographics(4, 1, 2, 1)
	demo.male_count = 3
	demo.female_count = 1
	demo.avg_health = 0.8

	var fertile := demo._get_fertile_women_count()
	assert_true(fertile >= 1, "Village with adult females should have at least 1 fertile woman (got: %d)" % fertile)


func test_fertile_women_zero_without_females():
	# All-male village should have no fertile women
	var demo = _create_demographics(6, 2, 3, 1)
	demo.male_count = 6
	demo.female_count = 0

	var fertile := demo._get_fertile_women_count()
	assert_eq(fertile, 0, "All-male village should have 0 fertile women")


func test_competition_factor_has_floor():
	# Even with many neighbors, competition should not drop below 0.5
	var manager = VillageManager.new()
	# The formula 1.0 / (1.0 + neighbors * 0.4) with 8 neighbors = 0.238
	# But we cap at 0.5
	# Testing the cap via village directly
	var village = VillageInstance.new()
	village.competition_factor = maxf(0.5, 1.0 / (1.0 + 8.0 * 0.4))
	assert_true(village.competition_factor >= 0.5, "Competition factor should have 0.5 floor (got: %.2f)" % village.competition_factor)
	autofree(manager)


func test_prob_round_produces_results_over_many_trials():
	# _prob_round(0.5) should produce 1 roughly half the time
	var rng = _create_rng(42)
	var ones := 0
	for _i in range(100):
		ones += VillageDemographics._prob_round(0.5, rng)
	assert_true(ones > 20 and ones < 80, "prob_round(0.5) should be ~50 over 100 trials (got: %d)" % ones)


func test_small_village_with_competition_survives():
	# Simulate what happens to an NPC village with heavy competition
	var demo = _create_demographics(6, 2, 3, 1)
	demo.avg_hunger = 0.7
	demo.avg_thirst = 0.7
	var rng = _create_rng(999)
	var carrying_capacity := 50.0
	var competition := 0.5  # floor-capped value

	for _year in range(30):
		demo.tick_resource_pressure(carrying_capacity, competition, 0.6, rng)
		demo.tick_year(rng)
		for _m in range(8):
			demo.tick_month(rng, 0.5)

	assert_true(demo.population >= 3, "Village with competition should survive 30 years (pop: %d)" % demo.population)
