extends "res://tests/test_base.gd"

## Tests for dynamic longhouse growth/shrink based on population changes.


func _create_village_manager() -> VillageManager:
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()
	return manager


func _create_village_with_pop(manager: VillageManager, pop: int) -> VillageInstance:
	var village = manager.register_village("planet_1", "test_v", "mississippi_early", [], false)
	village.camp_position = Vector2i(50, 50)
	# Clear default population and set exact count
	village.individuals.clear()
	for i in range(pop):
		var person = PersonInstance.new()
		var sex = PersonInstance.Sex.MALE if i % 2 == 0 else PersonInstance.Sex.FEMALE
		person.initialize("p_%d" % i, "Person%d" % i, sex, 25, [])
		village.individuals.append(person)
	return village


func test_update_longhouse_adds_when_population_grows():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 25)
	# 25 people / 20 capacity = 2 longhouses needed, but site has 1
	assert_eq(village.active_site.longhouse_positions.size(), 1, "Starts with 1 longhouse")
	manager._update_longhouse_count(village)
	assert_eq(village.active_site.longhouse_positions.size(), 2, "Grew to 2 longhouses")


func test_update_longhouse_adds_multiple():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 65)
	# 65 / 20 = 4 longhouses needed
	manager._update_longhouse_count(village)
	assert_eq(village.active_site.longhouse_positions.size(), 4, "Grew to 4 longhouses")
	assert_eq(village.active_site.clearing_radius, 6, "Radius = max_dist(3) + 3")


func test_update_longhouse_removes_on_population_decline():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 45)
	village.active_site.layout_longhouses(45, VillageInstance.LONGHOUSE_CAPACITY)
	assert_eq(village.active_site.longhouse_positions.size(), 3, "Starts with 3 longhouses")
	# Kill off people to drop below 2 longhouses
	while village.individuals.size() > 15:
		village.individuals.pop_back()
	manager._update_longhouse_count(village)
	assert_eq(village.active_site.longhouse_positions.size(), 1, "Shrunk to 1 longhouse")


func test_update_longhouse_never_removes_last():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 5)
	manager._update_longhouse_count(village)
	assert_eq(village.active_site.longhouse_positions.size(), 1, "Always at least 1 longhouse")


func test_update_longhouse_no_change_when_matching():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 20)
	manager._update_longhouse_count(village)
	assert_eq(village.active_site.longhouse_positions.size(), 1, "20 people = 1 longhouse, no change")


func test_longhouse_positions_are_spaced():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 80)
	manager._update_longhouse_count(village)
	var positions = village.active_site.longhouse_positions
	assert_eq(positions.size(), 4, "4 longhouses for 80 people")
	# Check cluster layout: all positions unique and within compact area
	for i in range(positions.size()):
		for j in range(i + 1, positions.size()):
			assert_ne(positions[i], positions[j], "Positions %d and %d are unique" % [i, j])
	# All within LONGHOUSE_SPACING of center (ring 1)
	var c = positions[0]
	for i in range(1, positions.size()):
		var dist = maxi(abs(positions[i].x - c.x), abs(positions[i].y - c.y))
		assert_true(dist <= SettlementSite.LONGHOUSE_SPACING, "Longhouse %d within spacing of center" % i)


func test_longhouse_added_signal_emitted():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 25)
	var signal_received := []
	manager.longhouse_added.connect(func(vid, pos, radius): signal_received.append({"vid": vid, "pos": pos, "radius": radius}))
	manager._update_longhouse_count(village)
	assert_eq(signal_received.size(), 1, "One longhouse_added signal")
	assert_eq(signal_received[0]["vid"], "test_v", "Signal has correct village_id")
	assert_eq(signal_received[0]["pos"], Vector2i(53, 50), "Signal has correct position")
	assert_eq(signal_received[0]["radius"], 6, "Signal has correct clearing radius")


func test_longhouse_removed_signal_emitted():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 45)
	village.active_site.layout_longhouses(45, VillageInstance.LONGHOUSE_CAPACITY)
	# Now reduce population
	while village.individuals.size() > 18:
		village.individuals.pop_back()
	var signal_received := []
	manager.longhouse_removed.connect(func(vid, pos): signal_received.append({"vid": vid, "pos": pos}))
	manager._update_longhouse_count(village)
	assert_eq(signal_received.size(), 2, "Two longhouse_removed signals (3 -> 1)")


func test_no_site_does_not_crash():
	var manager = _create_village_manager()
	var village = VillageInstance.new()
	village.initialize("no_site_v", "planet_1", "mississippi_early", ScenarioLoader.new().load_scenario("mississippi_early"))
	# No camp_position set, no active_site
	manager._update_longhouse_count(village)
	# Should not crash — early return when active_site is null
	assert_true(true, "No crash with null active_site")
