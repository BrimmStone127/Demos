extends "res://tests/test_base.gd"

## Tests for firewood pressure tracking and village relocation.


func _create_village_manager() -> VillageManager:
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()
	return manager


func _create_village(manager: VillageManager, pop: int = 6) -> VillageInstance:
	var village = manager.register_village("planet_1", "test_v", "mississippi_early", [], false)
	village.camp_position = Vector2i(100, 100)
	village.active_site.layout_longhouses(pop, VillageInstance.LONGHOUSE_CAPACITY)
	return village


# --- Firewood pressure tracking ---

func test_firewood_pressure_accumulates():
	var manager = _create_village_manager()
	var village = _create_village(manager)
	village.active_site.firewood_distance_sum = 120.0
	village.active_site.firewood_trip_count = 3
	assert_almost_eq(village.active_site.get_average_firewood_distance(), 40.0, 0.01, "Average = 120/3")


func test_firewood_pressure_below_threshold_no_relocation():
	var manager = _create_village_manager()
	var village = _create_village(manager)
	village.active_site.firewood_distance_sum = 50.0
	village.active_site.firewood_trip_count = 5
	# Average = 10.0, well below threshold
	var relocated := false
	manager.village_relocated.connect(func(_vid, _old, _new): relocated = true)
	manager._check_firewood_pressure(village)
	assert_false(relocated, "Should not relocate with low pressure")


func test_firewood_pressure_resets_after_check():
	var manager = _create_village_manager()
	var village = _create_village(manager)
	village.active_site.firewood_distance_sum = 50.0
	village.active_site.firewood_trip_count = 5
	manager._check_firewood_pressure(village)
	assert_eq(village.active_site.firewood_distance_sum, 0.0, "Sum reset after check")
	assert_eq(village.active_site.firewood_trip_count, 0, "Count reset after check")


# --- Relocation site finding ---

func test_too_close_to_other_villages():
	var manager = _create_village_manager()
	var v1 = _create_village(manager)
	var v2 = manager.register_village("planet_1", "test_v2", "mississippi_early", [], false)
	v2.camp_position = Vector2i(150, 100)
	manager.rebuild_village_area_cache("planet_1")
	# 50 tiles apart, threshold is 350 (MIN_CAMP_SPACING)
	assert_true(manager._too_close_to_other_villages(Vector2i(150, 100), v1), "150,100 too close to v1 at 100,100")
	assert_true(manager._too_close_to_other_villages(Vector2i(400, 100), v1), "400,100 still too close (300 < 350)")
	assert_false(manager._too_close_to_other_villages(Vector2i(500, 100), v1), "500,100 is far enough (400 > 350)")


func test_is_valid_camp_position_with_map_data():
	var manager = _create_village_manager()
	manager.map_data = PlanetMapData.new(Vector2i(500, 500), "test")
	assert_true(manager._is_valid_camp_position(Vector2i(100, 100), "test"), "Interior position valid")
	assert_false(manager._is_valid_camp_position(Vector2i(0, 0), "test"), "Edge position invalid")
	assert_false(manager._is_valid_camp_position(Vector2i(500, 100), "test"), "Outside bounds invalid")


func test_is_valid_camp_position_without_map_data():
	var manager = _create_village_manager()
	assert_true(manager._is_valid_camp_position(Vector2i(100, 100), "test"), "No map_data = always valid")


# --- Relocation execution ---

func test_relocate_village_abandons_old_site():
	var manager = _create_village_manager()
	var village = _create_village(manager)
	var old_center: Vector2i = village.camp_position
	manager._relocate_village(village, Vector2i(300, 300), null)
	assert_eq(village.past_sites.size(), 1, "Old site moved to past_sites")
	assert_eq(village.past_sites[0].status, SettlementSite.Status.ABANDONED, "Old site is ABANDONED")
	assert_eq(village.past_sites[0].center, old_center, "Old site center preserved")


func test_relocate_village_creates_new_site():
	var manager = _create_village_manager()
	var village = _create_village(manager)
	manager._relocate_village(village, Vector2i(300, 300), null)
	assert_eq(village.camp_position, Vector2i(300, 300), "Camp position updated")
	assert_eq(village.active_site.status, SettlementSite.Status.ACTIVE, "New site is ACTIVE")
	assert_true(village.active_site.longhouse_positions.size() >= 1, "New site has longhouses")


func test_relocate_village_emits_signal():
	var manager = _create_village_manager()
	var village = _create_village(manager)
	var signal_data := []
	manager.village_relocated.connect(func(vid, old_c, new_c): signal_data.append({"vid": vid, "old": old_c, "new": new_c}))
	manager._relocate_village(village, Vector2i(300, 300), null)
	assert_eq(signal_data.size(), 1, "Relocation signal emitted")
	assert_eq(signal_data[0]["old"], Vector2i(100, 100), "Old center correct")
	assert_eq(signal_data[0]["new"], Vector2i(300, 300), "New center correct")


func test_relocate_to_regrown_site():
	var manager = _create_village_manager()
	var village = _create_village(manager)

	# Create a past regrown site
	var old_site = SettlementSite.new()
	old_site.initialize("test_v_site_old", Vector2i(200, 200), 0)
	old_site.status = SettlementSite.Status.REGROWN
	old_site.abandoned_year = 0
	village.past_sites.append(old_site)

	manager._consider_relocation(village)
	assert_eq(village.camp_position, Vector2i(200, 200), "Returned to regrown site")
	assert_eq(village.active_site.status, SettlementSite.Status.ACTIVE, "Reactivated site is ACTIVE")
	assert_false(village.past_sites.has(old_site), "Returned site removed from past_sites")


func test_relocate_abandoned_year_set():
	var manager = _create_village_manager()
	var village = _create_village(manager)
	village.age_in_years = 15
	manager._relocate_village(village, Vector2i(300, 300), null)
	assert_eq(village.past_sites[0].abandoned_year, 15, "Abandoned year matches village age")


func test_relocate_preserves_population():
	var manager = _create_village_manager()
	var village = _create_village(manager, 20)
	var pop_before := village.get_population()
	manager._relocate_village(village, Vector2i(300, 300), null)
	assert_eq(village.get_population(), pop_before, "Population unchanged after relocation")


# --- EcosystemManager tree density query ---

func test_ecosystem_get_tree_count_near():
	var eco = EcosystemManager.new()
	eco._trees_by_position["planet_1"] = {}
	# Place some trees
	for i in range(10):
		eco._trees_by_position["planet_1"][Vector2i(50 + i, 50)] = true
	var count = eco.get_tree_count_near("planet_1", Vector2i(55, 50), 5)
	assert_eq(count, 10, "All 10 trees within radius 5 of center (55,50)")


func test_ecosystem_get_tree_count_near_empty():
	var eco = EcosystemManager.new()
	eco._trees_by_position["planet_1"] = {}
	var count = eco.get_tree_count_near("planet_1", Vector2i(50, 50), 10)
	assert_eq(count, 0, "No trees = count 0")


func test_ecosystem_get_tree_count_near_partial():
	var eco = EcosystemManager.new()
	eco._trees_by_position["planet_1"] = {}
	# Place trees in a cluster at (100, 100)
	for dx in range(-2, 3):
		for dy in range(-2, 3):
			eco._trees_by_position["planet_1"][Vector2i(100 + dx, 100 + dy)] = true
	# Count from center: all 25 within radius 2
	var count = eco.get_tree_count_near("planet_1", Vector2i(100, 100), 2)
	assert_eq(count, 25, "25 trees in 5x5 area within radius 2")
	# Count from offset: fewer in range
	var count_offset = eco.get_tree_count_near("planet_1", Vector2i(105, 100), 2)
	assert_eq(count_offset, 0, "No trees near (105, 100) within radius 2")
