extends "res://tests/test_base.gd"

## Tests for VillageDemographics: deflate, inflate, demographic ticks, splits, serialization.


func _create_village_with_pop(pop: int, village_id: String = "test_v") -> VillageInstance:
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()
	var village = manager.register_village("planet_1", village_id, "mississippi_early", [], false)
	village.camp_position = Vector2i(100, 100)
	village.individuals.clear()
	for i in range(pop):
		var sex = PersonInstance.Sex.MALE if i % 2 == 0 else PersonInstance.Sex.FEMALE
		var age = 20 + (i % 15)
		var person = PersonInstance.new()
		person.initialize("p_%d" % i, "Person%d" % i, sex, age, ["foraging", "fishing"])
		person.hunger = randf_range(0.3, 1.0)
		person.thirst = randf_range(0.3, 1.0)
		person.rest = randf_range(0.5, 1.0)
		village.individuals.append(person)
	return village


# --- from_individuals ---

func test_from_individuals_population():
	var village = _create_village_with_pop(30)
	var demo = VillageDemographics.from_individuals(village.individuals, village.political_traits)
	assert_eq(demo.population, 30, "Population should match individuals count")
	assert_eq(demo.male_count + demo.female_count, 30, "Male + female should equal population")


func test_from_individuals_age_buckets():
	var village = _create_village_with_pop(30)
	var demo = VillageDemographics.from_individuals(village.individuals, village.political_traits)
	var bucket_total = demo.age_buckets[0] + demo.age_buckets[1] + demo.age_buckets[2]
	assert_eq(bucket_total, 30, "Age bucket total should equal population")


func test_from_individuals_skills():
	var village = _create_village_with_pop(10)
	var demo = VillageDemographics.from_individuals(village.individuals, village.political_traits)
	assert_true(demo.avg_skills.has("foraging"), "Should have foraging skill average")
	assert_true(demo.max_skill_levels.has("foraging"), "Should have foraging max skill")
	assert_true(demo.avg_skills["foraging"] >= 0.0, "Avg foraging should be non-negative")
	assert_true(demo.max_skill_levels["foraging"] >= 0, "Max foraging should be non-negative")


func test_from_individuals_with_pregnant():
	var village = _create_village_with_pop(10)
	# Make a woman pregnant
	for person in village.individuals:
		if person.sex == PersonInstance.Sex.FEMALE and person.age >= 15:
			person.is_pregnant = true
			person.pregnancy_months = 4
			break
	var demo = VillageDemographics.from_individuals(village.individuals, village.political_traits)
	assert_eq(demo.pregnant_count, 1, "Should capture pregnant count")
	assert_eq(demo.avg_pregnancy_months, 4.0, "Should capture pregnancy months")


# --- Deflate/Inflate ---

func test_deflate_preserves_population():
	var village = _create_village_with_pop(25)
	var original_pop = village.get_population()
	village.deflate()
	assert_true(village.is_deflated, "Village should be deflated")
	assert_eq(village.get_population(), original_pop, "Population should be preserved after deflate")
	assert_true(village.individuals.is_empty(), "Individuals array should be empty after deflate")


func test_inflate_generates_correct_count():
	var village = _create_village_with_pop(25)
	var original_pop = village.get_population()
	village.deflate()
	village.inflate()
	assert_false(village.is_deflated, "Village should be inflated")
	assert_eq(village.individuals.size(), original_pop, "Should generate same number of individuals")
	assert_null(village.demographics, "Demographics should be cleared after inflate")


func test_deflate_inflate_roundtrip_population():
	var village = _create_village_with_pop(40)
	var original_pop = village.get_population()
	var original_adults = village.get_adult_count()
	village.deflate()
	village.inflate()
	# Population should match exactly
	assert_eq(village.get_population(), original_pop, "Population roundtrip should be exact")
	# Adults should be close (not exact due to age sampling)
	var diff = abs(village.get_adult_count() - original_adults)
	assert_true(diff <= 5, "Adult count should be within 5 of original (got diff: %d)" % diff)


func test_double_deflate_is_noop():
	var village = _create_village_with_pop(10)
	village.deflate()
	var pop_after_first = village.get_population()
	village.deflate()
	assert_eq(village.get_population(), pop_after_first, "Double deflate should not change population")


func test_double_inflate_is_noop():
	var village = _create_village_with_pop(10)
	assert_false(village.is_deflated, "Should start inflated")
	village.inflate()
	assert_false(village.is_deflated, "Inflate on inflated village should be noop")


# --- Getters work in both modes ---

func test_getters_work_deflated():
	var village = _create_village_with_pop(20)
	var pop = village.get_population()
	var adults = village.get_adult_count()
	var avg_age = village.get_average_age()
	var avg_health = village.get_average_health()
	village.deflate()
	assert_eq(village.get_population(), pop, "get_population should work deflated")
	# Adults should be same (exact snapshot)
	assert_eq(village.get_adult_count(), adults, "get_adult_count should work deflated")
	# Average age should be close
	assert_true(abs(village.get_average_age() - avg_age) < 2.0, "get_average_age should be close")
	assert_true(abs(village.get_average_health() - avg_health) < 0.05, "get_average_health should be close")


func test_longhouse_count_deflated():
	var village = _create_village_with_pop(45)
	var lh_inflated = village.longhouse_count()
	village.deflate()
	assert_eq(village.longhouse_count(), lh_inflated, "Longhouse count should match after deflate")


func test_is_viable_deflated():
	var village = _create_village_with_pop(20)
	village.deflate()
	assert_true(village.is_viable(), "20-person village should be viable when deflated")


func test_is_viable_deflated_too_small():
	var village = _create_village_with_pop(2)
	village.deflate()
	assert_false(village.is_viable(), "2-person village should not be viable")


# --- Demographic tick_year ---

func test_demographic_tick_year_reduces_or_maintains_pop():
	var village = _create_village_with_pop(50)
	village.deflate()
	var rng = RandomNumberGenerator.new()
	rng.seed = 12345
	var original_pop = village.demographics.population
	# Run 5 years — population should change but not crash
	for _y in range(5):
		village.demographics.tick_year(rng)
	assert_true(village.demographics.population > 0, "Village should survive 5 years")
	assert_true(village.demographics.population <= original_pop + 5, "Population shouldn't grow from tick_year alone")


func test_demographic_tick_year_updates_age_buckets():
	var village = _create_village_with_pop(30)
	village.deflate()
	var rng = RandomNumberGenerator.new()
	rng.seed = 42
	village.demographics.tick_year(rng)
	var bucket_sum = village.demographics.age_buckets[0] + village.demographics.age_buckets[1] + village.demographics.age_buckets[2]
	assert_eq(bucket_sum, village.demographics.population, "Age buckets should sum to population after tick")


# --- Demographic tick_month ---

func test_demographic_tick_month_can_produce_births():
	var village = _create_village_with_pop(30)
	village.deflate()
	var rng = RandomNumberGenerator.new()
	rng.seed = 100
	# Set up pregnancies
	village.demographics.pregnant_count = 5
	village.demographics.avg_pregnancy_months = 8.0  # about to deliver
	var pop_before = village.demographics.population
	var births = village.demographics.tick_month(rng)
	assert_true(births > 0, "Should produce births when pregnancies are at term")
	assert_true(village.demographics.population > pop_before, "Population should increase after births")


func test_demographic_tick_month_conception():
	var village = _create_village_with_pop(30)
	village.deflate()
	var rng = RandomNumberGenerator.new()
	rng.seed = 200
	# No pregnancies initially
	village.demographics.pregnant_count = 0
	# Run several months — should get some conceptions
	var any_pregnant := false
	for _m in range(24):
		village.demographics.tick_month(rng)
		if village.demographics.pregnant_count > 0:
			any_pregnant = true
			break
	assert_true(any_pregnant, "Should get conceptions within 24 months")


# --- Split ---

func test_demographic_split_preserves_total():
	var village = _create_village_with_pop(50)
	village.deflate()
	var original_pop = village.demographics.population
	var rng = RandomNumberGenerator.new()
	rng.seed = 42
	var child = village.demographics.split(0.4, rng)
	var total = village.demographics.population + child.population
	assert_eq(total, original_pop, "Parent + child population should equal original")


func test_demographic_split_child_has_young_bias():
	var village = _create_village_with_pop(60)
	# Add some elders and children
	for i in range(10):
		village.individuals[i].age = 50  # elders
	for i in range(10, 20):
		village.individuals[i].age = 5  # children
	village.deflate()
	var rng = RandomNumberGenerator.new()
	rng.seed = 42
	var child = village.demographics.split(0.4, rng)
	# Child should have more adults than elders (biased toward young)
	assert_true(child.age_buckets[1] >= child.age_buckets[2], "Child should have more adults than elders")


func test_demographic_split_copies_skills():
	var village = _create_village_with_pop(30)
	village.deflate()
	var rng = RandomNumberGenerator.new()
	rng.seed = 42
	var child = village.demographics.split(0.4, rng)
	assert_true(child.avg_skills.has("foraging"), "Child should inherit skill averages")
	assert_true(child.max_skill_levels.has("foraging"), "Child should inherit max skill levels")


# --- Serialization ---

func test_demographics_to_dict_from_dict():
	var village = _create_village_with_pop(25)
	var demo = VillageDemographics.from_individuals(village.individuals, village.political_traits)
	var data = demo.to_dict()
	var restored = VillageDemographics.from_dict(data)
	assert_eq(restored.population, demo.population, "Population should roundtrip")
	assert_eq(restored.male_count, demo.male_count, "Male count should roundtrip")
	assert_eq(restored.female_count, demo.female_count, "Female count should roundtrip")
	assert_eq(restored.age_buckets[0], demo.age_buckets[0], "Child bucket should roundtrip")
	assert_eq(restored.age_buckets[1], demo.age_buckets[1], "Adult bucket should roundtrip")
	assert_eq(restored.age_buckets[2], demo.age_buckets[2], "Elder bucket should roundtrip")
	assert_true(abs(restored.avg_health - demo.avg_health) < 0.01, "Avg health should roundtrip")


func test_deflated_village_serialization():
	var village = _create_village_with_pop(20)
	village.deflate()
	var data = village.to_dict()
	assert_true(data.get("is_deflated", false), "Serialized data should have is_deflated=true")
	assert_true(data.has("demographics"), "Serialized data should have demographics")
	var restored = VillageInstance.from_dict(data)
	assert_true(restored.is_deflated, "Restored village should be deflated")
	assert_not_null(restored.demographics, "Restored village should have demographics")
	assert_eq(restored.get_population(), 20, "Restored population should be 20")


func test_inflated_village_serialization_unchanged():
	var village = _create_village_with_pop(15)
	var data = village.to_dict()
	assert_false(data.get("is_deflated", false), "Inflated village should have is_deflated=false")
	var restored = VillageInstance.from_dict(data)
	assert_false(restored.is_deflated, "Restored inflated village should not be deflated")
	assert_eq(restored.individuals.size(), 15, "Restored individuals should be 15")


# --- Edge cases ---

func test_empty_village_deflate():
	var village = _create_village_with_pop(0)
	village.deflate()
	assert_true(village.is_deflated, "Empty village should deflate")
	assert_eq(village.get_population(), 0, "Empty village should have 0 pop")


func test_small_village_deflate_inflate():
	var village = _create_village_with_pop(3)
	village.deflate()
	village.inflate()
	assert_eq(village.individuals.size(), 3, "3-person village should roundtrip")


func test_demographic_tick_empty_village():
	var demo = VillageDemographics.new()
	var rng = RandomNumberGenerator.new()
	rng.seed = 42
	var deaths = demo.tick_year(rng)
	assert_eq(deaths, 0, "Empty demographics should have 0 deaths")
	var births = demo.tick_month(rng)
	assert_eq(births, 0, "Empty demographics should have 0 births")


# --- Cached individuals (lossless deflate/inflate) ---

func test_deflate_caches_individuals():
	var village = _create_village_with_pop(15)
	var original_names: Array[String] = []
	for p in village.individuals:
		original_names.append(p.name)
	village.deflate()
	# After deflate, cached individuals should exist
	assert_eq(village._cached_individuals.size(), 15, "Should cache all individuals on deflate")


func test_inflate_restores_cached_individuals():
	var village = _create_village_with_pop(15)
	var original_names: Array[String] = []
	for p in village.individuals:
		original_names.append(p.name)
	village.deflate()
	village.inflate()
	# Same people should come back
	var restored_names: Array[String] = []
	for p in village.individuals:
		restored_names.append(p.name)
	assert_eq(restored_names.size(), original_names.size(), "Should restore same count")
	for name in original_names:
		assert_true(restored_names.has(name), "Should restore person: %s" % name)


func test_inflate_cache_survives_demographic_births():
	var village = _create_village_with_pop(20)
	var original_count = village.individuals.size()
	village.deflate()
	# Simulate births while deflated
	village.demographics.population += 3
	village.demographics.age_buckets[0] += 3
	village.inflate()
	# Should have original people + 3 new babies
	assert_eq(village.individuals.size(), original_count + 3, "Should add babies to cached individuals")


func test_inflate_cache_survives_demographic_deaths():
	var village = _create_village_with_pop(20)
	village.deflate()
	# Simulate deaths while deflated
	village.demographics.population -= 2
	village.demographics.age_buckets[2] = maxi(0, village.demographics.age_buckets[2] - 2)
	village.inflate()
	assert_eq(village.individuals.size(), 18, "Should remove 2 people from cached individuals")


func test_cached_individuals_serialization():
	var village = _create_village_with_pop(10)
	var original_names: Array[String] = []
	for p in village.individuals:
		original_names.append(p.name)
	village.deflate()
	# Serialize and restore
	var data = village.to_dict()
	assert_true(data.has("cached_individuals"), "Serialized data should have cached_individuals")
	var restored = VillageInstance.from_dict(data)
	assert_eq(restored._cached_individuals.size(), 10, "Restored should have cached individuals")
	# Inflate and check names match
	restored.inflate()
	for name in original_names:
		var found := false
		for p in restored.individuals:
			if p.name == name:
				found = true
				break
		assert_true(found, "Restored village should have person: %s" % name)


# --- Pinning ---

func test_pin_prevents_deflation_flag():
	var village = _create_village_with_pop(10)
	village.pin()
	assert_true(village.is_pinned, "Village should be pinned")
	village.unpin()
	assert_false(village.is_pinned, "Village should be unpinned")


func test_pinned_serialization():
	var village = _create_village_with_pop(5)
	village.pin()
	var data = village.to_dict()
	assert_true(data.get("is_pinned", false), "Serialized data should have is_pinned=true")
	var restored = VillageInstance.from_dict(data)
	assert_true(restored.is_pinned, "Restored village should be pinned")


func test_player_village_never_has_cached_individuals():
	var village = _create_village_with_pop(10)
	village.is_player_village = true
	# Player village should never be deflated, so no cache
	assert_false(village.is_deflated, "Player village starts inflated")
	assert_true(village._cached_individuals.is_empty(), "Player village has no cache")


func test_save_individuals_explicit():
	var village = _create_village_with_pop(12)
	var saved = village.save_individuals()
	assert_eq(saved.size(), 12, "save_individuals should cache all people")
	assert_eq(village._cached_individuals.size(), 12, "Cache should be populated")


func test_clear_individual_cache():
	var village = _create_village_with_pop(10)
	village.deflate()
	assert_eq(village._cached_individuals.size(), 10, "Should have cache after deflate")
	village.clear_individual_cache()
	assert_eq(village._cached_individuals.size(), 0, "Cache should be cleared")
