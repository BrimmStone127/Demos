extends "res://tests/test_base.gd"

## Tests for SettlementSite data model and VillageInstance integration.


# --- SettlementSite basics ---

func test_site_initializes_with_center():
	var site = SettlementSite.new()
	site.initialize("test_site_0", Vector2i(50, 50), 0)
	assert_eq(site.center, Vector2i(50, 50), "Center should match")
	assert_eq(site.status, SettlementSite.Status.ACTIVE, "New site should be ACTIVE")
	assert_eq(site.longhouse_positions.size(), 1, "Should start with one longhouse")
	assert_eq(site.longhouse_positions[0], Vector2i(50, 50), "First longhouse at center")
	assert_eq(site.clearing_radius, 4, "Initial radius should be 4")


func test_site_add_longhouse():
	var site = SettlementSite.new()
	site.initialize("test_site_0", Vector2i(50, 50), 0)
	var new_pos = site.add_longhouse()
	assert_eq(new_pos, Vector2i(53, 50), "Second longhouse at ring1 slot 0 (east)")
	assert_eq(site.longhouse_positions.size(), 2, "Should have 2 longhouses")
	assert_eq(site.clearing_radius, 6, "Radius = max_dist(3) + 3")


func test_site_add_multiple_longhouses():
	var site = SettlementSite.new()
	site.initialize("test_site_0", Vector2i(10, 10), 0)
	site.add_longhouse()
	site.add_longhouse()
	site.add_longhouse()
	assert_eq(site.longhouse_positions.size(), 4, "Should have 4 longhouses")
	# Cluster layout: E, W, S positions around center
	assert_eq(site.longhouse_positions[1], Vector2i(13, 10), "Ring1 slot 0: east")
	assert_eq(site.longhouse_positions[2], Vector2i(7, 10), "Ring1 slot 1: west")
	assert_eq(site.longhouse_positions[3], Vector2i(10, 13), "Ring1 slot 2: south")
	assert_eq(site.clearing_radius, 6, "Radius = max_dist(3) + 3")


func test_site_remove_last_longhouse():
	var site = SettlementSite.new()
	site.initialize("test_site_0", Vector2i(50, 50), 0)
	site.add_longhouse()
	var removed = site.remove_last_longhouse()
	assert_eq(removed, Vector2i(53, 50), "Should remove last added longhouse")
	assert_eq(site.longhouse_positions.size(), 1, "Back to one longhouse")
	assert_eq(site.clearing_radius, 4, "Radius back to 4")


func test_site_cannot_remove_only_longhouse():
	var site = SettlementSite.new()
	site.initialize("test_site_0", Vector2i(50, 50), 0)
	var removed = site.remove_last_longhouse()
	assert_eq(removed, Vector2i(-1, -1), "Cannot remove the only longhouse")
	assert_eq(site.longhouse_positions.size(), 1, "Still has one longhouse")


func test_site_has_longhouse_at():
	var site = SettlementSite.new()
	site.initialize("test_site_0", Vector2i(50, 50), 0)
	site.add_longhouse()
	assert_true(site.has_longhouse_at(Vector2i(50, 50)), "Center has longhouse")
	assert_true(site.has_longhouse_at(Vector2i(53, 50)), "Second position has longhouse")
	assert_false(site.has_longhouse_at(Vector2i(51, 50)), "Empty position has no longhouse")


func test_site_is_in_clearing():
	var site = SettlementSite.new()
	site.initialize("test_site_0", Vector2i(50, 50), 0)
	assert_true(site.is_in_clearing(Vector2i(50, 50)), "Center is in clearing")
	assert_true(site.is_in_clearing(Vector2i(54, 54)), "Edge is in clearing (radius 4)")
	assert_false(site.is_in_clearing(Vector2i(55, 50)), "Outside clearing")


func test_site_clearing_grows_with_longhouses():
	var site = SettlementSite.new()
	site.initialize("test_site_0", Vector2i(50, 50), 0)
	assert_false(site.is_in_clearing(Vector2i(55, 50)), "Not in clearing at radius 4")
	site.add_longhouse()
	assert_true(site.is_in_clearing(Vector2i(55, 50)), "In clearing at radius 6")


func test_site_layout_longhouses():
	var site = SettlementSite.new()
	site.initialize("test_site_0", Vector2i(20, 20), 0)
	site.layout_longhouses(45, 20)
	assert_eq(site.longhouse_positions.size(), 3, "45 people / 20 capacity = 3 longhouses")
	assert_eq(site.longhouse_positions[0], Vector2i(20, 20), "First at center")
	assert_eq(site.longhouse_positions[1], Vector2i(23, 20), "Ring1 slot 0: east")
	assert_eq(site.longhouse_positions[2], Vector2i(17, 20), "Ring1 slot 1: west")
	assert_eq(site.clearing_radius, 6, "Radius = max_dist(3) + 3")


func test_site_layout_minimum_one_longhouse():
	var site = SettlementSite.new()
	site.initialize("test_site_0", Vector2i(20, 20), 0)
	site.layout_longhouses(0, 20)
	assert_eq(site.longhouse_positions.size(), 1, "At least one longhouse even with 0 pop")


# --- Firewood pressure tracking ---

func test_firewood_distance_tracking():
	var site = SettlementSite.new()
	site.initialize("test_site_0", Vector2i(50, 50), 0)
	site.firewood_distance_sum = 30.0
	site.firewood_trip_count = 3
	assert_almost_eq(site.get_average_firewood_distance(), 10.0, 0.01, "Average distance = 30/3")


func test_firewood_distance_zero_trips():
	var site = SettlementSite.new()
	site.initialize("test_site_0", Vector2i(50, 50), 0)
	assert_eq(site.get_average_firewood_distance(), 0.0, "Zero trips = zero average")


func test_firewood_tracking_reset():
	var site = SettlementSite.new()
	site.initialize("test_site_0", Vector2i(50, 50), 0)
	site.firewood_distance_sum = 100.0
	site.firewood_trip_count = 5
	site.reset_firewood_tracking()
	assert_eq(site.firewood_distance_sum, 0.0, "Sum reset")
	assert_eq(site.firewood_trip_count, 0, "Count reset")


# --- Serialization ---

func test_site_serialization_roundtrip():
	var site = SettlementSite.new()
	site.initialize("village_player_site_0", Vector2i(100, 200), 5)
	site.add_longhouse()
	site.status = SettlementSite.Status.ABANDONED
	site.abandoned_year = 20

	var data = site.to_dict()
	var restored = SettlementSite.from_dict(data)

	assert_eq(restored.site_id, "village_player_site_0", "site_id roundtrip")
	assert_eq(restored.center, Vector2i(100, 200), "center roundtrip")
	assert_eq(restored.status, SettlementSite.Status.ABANDONED, "status roundtrip")
	assert_eq(restored.abandoned_year, 20, "abandoned_year roundtrip")
	assert_eq(restored.longhouse_positions.size(), 2, "longhouse count roundtrip")
	assert_eq(restored.longhouse_positions[1], Vector2i(103, 200), "longhouse pos roundtrip")
	assert_eq(restored.clearing_radius, 6, "clearing_radius roundtrip")


# --- VillageInstance integration ---

func test_village_camp_position_creates_site():
	var loader = ScenarioLoader.new()
	var scenario = loader.load_scenario("mississippi_early")
	var village = VillageInstance.new()
	village.initialize("test_v", "planet_1", "mississippi_early", scenario)
	village.camp_position = Vector2i(50, 50)
	assert_not_null(village.active_site, "Setting camp_position creates a site")
	assert_eq(village.active_site.center, Vector2i(50, 50), "Site center matches")
	assert_eq(village.camp_position, Vector2i(50, 50), "Getter returns site center")


func test_village_camp_position_backward_compat():
	var loader = ScenarioLoader.new()
	var scenario = loader.load_scenario("mississippi_early")
	var village = VillageInstance.new()
	village.initialize("test_v", "planet_1", "mississippi_early", scenario)
	# Setting camp_position twice updates the same site
	village.camp_position = Vector2i(50, 50)
	village.camp_position = Vector2i(60, 60)
	assert_eq(village.active_site.center, Vector2i(60, 60), "Site center updated")
	assert_eq(village.active_site.longhouse_positions[0], Vector2i(60, 60), "First longhouse updated")


func test_village_longhouse_count():
	var loader = ScenarioLoader.new()
	var scenario = loader.load_scenario("mississippi_early")
	var village = VillageInstance.new()
	village.initialize("test_v", "planet_1", "mississippi_early", scenario)
	village.populate(6)
	assert_eq(village.longhouse_count(), 1, "6 people = 1 longhouse")


func test_village_longhouse_count_grows():
	var loader = ScenarioLoader.new()
	var scenario = loader.load_scenario("mississippi_early")
	var village = VillageInstance.new()
	village.initialize("test_v", "planet_1", "mississippi_early", scenario)
	# Manually add people to test capacity boundary
	for i in range(21):
		var person = PersonInstance.new()
		person.initialize("p_%d" % i, "Person%d" % i, PersonInstance.Sex.MALE, 25, [])
		village.individuals.append(person)
	assert_eq(village.longhouse_count(), 2, "21 people = 2 longhouses (capacity 20)")


func test_village_no_site_returns_empty_positions():
	var village = VillageInstance.new()
	assert_eq(village.get_all_longhouse_positions().size(), 0, "No site = no positions")
	assert_eq(village.camp_position, Vector2i(-1, -1), "No site = default camp_position")


func test_village_get_all_longhouse_positions():
	var loader = ScenarioLoader.new()
	var scenario = loader.load_scenario("mississippi_early")
	var village = VillageInstance.new()
	village.initialize("test_v", "planet_1", "mississippi_early", scenario)
	village.camp_position = Vector2i(50, 50)
	village.active_site.add_longhouse()
	var positions = village.get_all_longhouse_positions()
	assert_eq(positions.size(), 2, "Two longhouse positions")
	assert_eq(positions[0], Vector2i(50, 50), "First at center")
	assert_eq(positions[1], Vector2i(53, 50), "Second at +3")


# --- VillageManager multi-longhouse queries ---

func test_manager_has_village_at_multiple_longhouses():
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()
	var village = manager.register_village("planet_1", "test_v", "mississippi_early", [], false)
	village.camp_position = Vector2i(50, 50)
	village.active_site.add_longhouse()
	assert_true(manager.has_village_at("planet_1", Vector2i(50, 50)), "Center longhouse found")
	assert_true(manager.has_village_at("planet_1", Vector2i(53, 50)), "Second longhouse found")
	assert_false(manager.has_village_at("planet_1", Vector2i(51, 50)), "Empty tile not found")


func test_manager_is_in_village_area_dynamic_radius():
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()
	var village = manager.register_village("planet_1", "test_v", "mississippi_early", [], false)
	village.camp_position = Vector2i(50, 50)
	village.active_site.center = Vector2i(50, 50)
	manager.rebuild_village_area_cache("planet_1")
	# With 1 longhouse, radius = 4
	assert_true(manager.is_in_village_area("planet_1", Vector2i(54, 54)), "Within radius 4")
	assert_false(manager.is_in_village_area("planet_1", Vector2i(55, 50)), "Outside radius 4")
	# Add longhouse, radius grows to 5
	village.active_site.add_longhouse()
	manager.rebuild_village_area_cache("planet_1")
	assert_true(manager.is_in_village_area("planet_1", Vector2i(55, 50)), "Within radius 6 after growth")


func test_manager_get_village_at_camp_multi_longhouse():
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()
	var village = manager.register_village("planet_1", "test_v", "mississippi_early", [], false)
	village.camp_position = Vector2i(50, 50)
	village.active_site.add_longhouse()
	var found = manager.get_village_at_camp("planet_1", Vector2i(53, 50))
	assert_not_null(found, "Found village at second longhouse position")
	assert_eq(found.village_id, "test_v", "Correct village returned")


func test_manager_get_all_longhouse_positions():
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()
	var v1 = manager.register_village("planet_1", "v1", "mississippi_early", [], false)
	v1.camp_position = Vector2i(10, 10)
	var v2 = manager.register_village("planet_1", "v2", "mississippi_early", [], false)
	v2.camp_position = Vector2i(80, 80)
	v2.active_site.add_longhouse()
	var all_pos = manager.get_all_longhouse_positions_on_planet("planet_1")
	assert_eq(all_pos.size(), 3, "1 from v1 + 2 from v2 = 3 total positions")
