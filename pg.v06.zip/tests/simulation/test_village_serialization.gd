extends "res://tests/test_base.gd"

## Tests for village save/load serialization.
## Covers PersonInstance, VillageResourceMemory, VillageRelationship,
## SettlementSite, and VillageInstance to_dict/from_dict round-trips.

const LOG_TAG := "TEST_SERIALIZATION"


# --- PersonInstance ---

func test_person_round_trip():
	var group_knowledge: Array[String] = ["foraging", "fishing"]
	var person := PersonInstance.new()
	person.initialize("p_001", "Bear", PersonInstance.Sex.MALE, 25, group_knowledge)
	person.health = 0.85
	person.beliefs = 0.7
	person.is_hero = true
	person.hero_influence = 0.3
	person.is_pregnant = false
	person.traits.append("strong")

	var data := person.to_dict()
	var restored := PersonInstance.from_dict(data)

	assert_eq(restored.person_id, "p_001", "person_id preserved")
	assert_eq(restored.name, "Bear", "name preserved")
	assert_eq(restored.sex, PersonInstance.Sex.MALE, "sex preserved")
	assert_eq(restored.age, 25, "age preserved")
	assert_almost_eq(restored.health, 0.85, 0.001, "health preserved")
	assert_almost_eq(restored.beliefs, 0.7, 0.001, "beliefs preserved")
	assert_true(restored.is_hero, "is_hero preserved")
	assert_almost_eq(restored.hero_influence, 0.3, 0.001, "hero_influence preserved")
	assert_true(restored.traits.has("strong"), "traits preserved")
	assert_true(restored.skills.has("foraging"), "skills preserved")
	assert_true(restored.skills.has("fishing"), "skills preserved")


func test_person_pregnant_round_trip():
	var group_knowledge: Array[String] = ["foraging"]
	var person := PersonInstance.new()
	person.initialize("p_002", "Dove", PersonInstance.Sex.FEMALE, 22, group_knowledge)
	person.is_pregnant = true
	person.pregnancy_months = 5
	person.months_since_child = 3

	var data := person.to_dict()
	var restored := PersonInstance.from_dict(data)

	assert_true(restored.is_pregnant, "pregnancy preserved")
	assert_eq(restored.pregnancy_months, 5, "pregnancy months preserved")
	assert_eq(restored.months_since_child, 3, "months_since_child preserved")


# --- VillageResourceMemory ---

func test_resource_memory_round_trip():
	var mem := VillageResourceMemory.new()
	mem.camp_position = Vector2i(50, 60)
	mem.add_known(VillageResourceMemory.BERRY, Vector2i(10, 20))
	mem.add_known(VillageResourceMemory.BERRY, Vector2i(15, 25))
	mem.add_known(VillageResourceMemory.FIREWOOD, Vector2i(30, 40))
	mem.set_target(VillageResourceMemory.BERRY, Vector2i(10, 20))
	mem.set_target(VillageResourceMemory.WATER, Vector2i(5, 5))

	var data := mem.to_dict()
	var restored := VillageResourceMemory.from_dict(data)

	assert_eq(restored.camp_position, Vector2i(50, 60), "camp_position preserved")
	assert_eq(restored.get_target(VillageResourceMemory.BERRY), Vector2i(10, 20), "berry target preserved")
	assert_eq(restored.get_target(VillageResourceMemory.WATER), Vector2i(5, 5), "water target preserved")
	assert_true(restored.has_known(VillageResourceMemory.BERRY, Vector2i(10, 20)), "known berry 1")
	assert_true(restored.has_known(VillageResourceMemory.BERRY, Vector2i(15, 25)), "known berry 2")
	assert_true(restored.has_known(VillageResourceMemory.FIREWOOD, Vector2i(30, 40)), "known firewood")
	assert_eq(restored.get_known_count(VillageResourceMemory.BERRY), 2, "berry known count")


# --- VillageRelationship ---

func test_relationship_round_trip():
	var rel := VillageRelationship.new()
	rel.initialize("village_npc_01")
	rel.stance = VillageRelationship.Stance.TRADING
	rel.record_contact(100, "trade", "success")
	rel.exchanged_skills.append("fishing")

	var data := rel.to_dict()
	var restored := VillageRelationship.from_dict(data)

	assert_eq(restored.other_village_id, "village_npc_01", "other_village_id preserved")
	assert_eq(restored.stance, VillageRelationship.Stance.TRADING, "stance preserved")
	assert_eq(restored.get_contact_count(), 1, "contact history preserved")
	assert_true(restored.exchanged_skills.has("fishing"), "exchanged skills preserved")


# --- SettlementSite ---

func test_settlement_site_round_trip():
	var site := SettlementSite.new()
	site.initialize("village_player_site_0", Vector2i(100, 200), 5)
	site.longhouse_positions.append(Vector2i(103, 200))
	site.clearing_radius = 7
	site.status = SettlementSite.Status.ABANDONED
	site.abandoned_year = 10

	var data := site.to_dict()
	var restored := SettlementSite.from_dict(data)

	assert_eq(restored.site_id, "village_player_site_0", "site_id preserved")
	assert_eq(restored.center, Vector2i(100, 200), "center preserved")
	assert_eq(restored.established_year, 5, "established_year preserved")
	assert_eq(restored.status, SettlementSite.Status.ABANDONED, "status preserved")
	assert_eq(restored.abandoned_year, 10, "abandoned_year preserved")
	assert_eq(restored.longhouse_positions.size(), 2, "longhouse count preserved")
	assert_eq(restored.clearing_radius, 7, "clearing_radius preserved")


# --- VillageInstance ---

func _create_test_village() -> VillageInstance:
	var village := VillageInstance.new()
	var loader := ScenarioLoader.new()
	var scenario := loader.load_scenario("mississippi_early")
	village.initialize("village_test", "planet_1", "mississippi_early", scenario)
	village.is_player_village = true
	village.populate(10)
	village.camp_position = Vector2i(100, 100)
	village.age_in_years = 42
	village.last_split_year = 30
	village.firewood_stored = 0.75
	village.food_stored = 0.6
	village.water_stored = 0.9
	village.log_event("founded", "Village founded")
	village.log_event("birth", "Someone was born")
	if village.resource_memory:
		village.resource_memory.set_target(VillageResourceMemory.BERRY, Vector2i(110, 105))
		village.resource_memory.set_target(VillageResourceMemory.WATER, Vector2i(95, 100))
		village.resource_memory.set_target(VillageResourceMemory.FIREWOOD, Vector2i(120, 100))
	return village


func test_village_round_trip():
	var village := _create_test_village()
	var pop_before := village.get_population()

	var data := village.to_dict()
	var restored := VillageInstance.from_dict(data)

	assert_eq(restored.village_id, "village_test", "village_id preserved")
	assert_eq(restored.planet_id, "planet_1", "planet_id preserved")
	assert_eq(restored.scenario_id, "mississippi_early", "scenario_id preserved")
	assert_true(restored.is_player_village, "is_player_village preserved")
	assert_eq(restored.get_population(), pop_before, "population preserved")
	assert_eq(restored.age_in_years, 42, "age_in_years preserved")
	assert_eq(restored.last_split_year, 30, "last_split_year preserved")
	assert_almost_eq(restored.firewood_stored, 0.75, 0.001, "firewood_stored preserved")
	assert_almost_eq(restored.food_stored, 0.6, 0.001, "food_stored preserved")
	assert_almost_eq(restored.water_stored, 0.9, 0.001, "water_stored preserved")
	assert_eq(restored.era, village.era, "era preserved")
	assert_eq(restored.camp_position, Vector2i(100, 100), "camp_position preserved")


func test_village_individuals_preserved():
	var village := _create_test_village()
	var first_person := village.individuals[0]
	var data := village.to_dict()
	var restored := VillageInstance.from_dict(data)

	assert_eq(restored.individuals.size(), village.individuals.size(), "individual count matches")
	var restored_first := restored.individuals[0]
	assert_eq(restored_first.person_id, first_person.person_id, "first person id matches")
	assert_eq(restored_first.name, first_person.name, "first person name matches")
	assert_eq(restored_first.age, first_person.age, "first person age matches")


func test_village_event_log_preserved():
	var village := _create_test_village()
	var data := village.to_dict()
	var restored := VillageInstance.from_dict(data)

	assert_eq(restored.event_log.size(), 2, "event log size preserved")
	assert_eq(restored.event_log[0].get("type", ""), "founded", "first event type")
	assert_eq(restored.event_log[1].get("type", ""), "birth", "second event type")


func test_village_resource_memory_preserved():
	var village := _create_test_village()
	var data := village.to_dict()
	var restored := VillageInstance.from_dict(data)

	assert_true(restored.resource_memory != null, "resource_memory exists")
	assert_eq(restored.berry_pos, Vector2i(110, 105), "berry target preserved")
	assert_eq(restored.water_pos, Vector2i(95, 100), "water target preserved")
	assert_eq(restored.firewood_pos, Vector2i(120, 100), "firewood target preserved")


func test_village_active_site_preserved():
	var village := _create_test_village()
	var data := village.to_dict()
	var restored := VillageInstance.from_dict(data)

	assert_true(restored.active_site != null, "active_site exists")
	assert_eq(restored.active_site.center, Vector2i(100, 100), "site center preserved")
	assert_eq(restored.active_site.longhouse_positions.size(),
		village.active_site.longhouse_positions.size(), "longhouse count matches")


func test_village_group_knowledge_preserved():
	var village := _create_test_village()
	var data := village.to_dict()
	var restored := VillageInstance.from_dict(data)

	assert_eq(restored.group_knowledge.size(), village.group_knowledge.size(), "knowledge count")
	for skill in village.group_knowledge:
		assert_true(restored.group_knowledge.has(skill), "skill %s preserved" % skill)


func test_village_past_sites_preserved():
	var village := _create_test_village()
	# Add a past site
	var old_site := SettlementSite.new()
	old_site.initialize("village_test_site_old", Vector2i(50, 50), 0)
	old_site.status = SettlementSite.Status.ABANDONED
	old_site.abandoned_year = 20
	village.past_sites.append(old_site)

	var data := village.to_dict()
	var restored := VillageInstance.from_dict(data)

	assert_eq(restored.past_sites.size(), 1, "past sites count")
	assert_eq(restored.past_sites[0].center, Vector2i(50, 50), "past site center")
	assert_eq(restored.past_sites[0].status, SettlementSite.Status.ABANDONED, "past site status")


# --- VillageManager export/import ---

func test_village_manager_export_import():
	var manager := VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()

	var village := manager.register_village("planet_x", "vm_test_village", "mississippi_early", [], true)
	assert_true(village != null, "village registered")
	village.camp_position = Vector2i(200, 200)
	village.age_in_years = 15
	village.log_event("founded", "Test village founded")

	var exported := manager.export_villages("planet_x")
	assert_eq(exported.get("villages", []).size(), 1, "exported 1 village")

	# Import into fresh manager
	var manager2 := VillageManager.new()
	manager2._scenario_loader = ScenarioLoader.new()
	var imported := manager2.import_villages("planet_x", exported)

	assert_eq(imported.size(), 1, "imported 1 village")
	assert_eq(imported[0].village_id, "vm_test_village", "village_id matches")
	assert_eq(imported[0].camp_position, Vector2i(200, 200), "camp_position matches")
	assert_eq(imported[0].age_in_years, 15, "age_in_years matches")
	assert_eq(imported[0].event_log.size(), 1, "event log matches")

	# Check lookup works
	var found := manager2.get_village("vm_test_village")
	assert_true(found != null, "village findable by id")

	manager.queue_free()
	manager2.queue_free()


func test_village_manager_collapsed_export():
	var manager := VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()

	var village := manager.register_village("planet_y", "vm_collapse_test", "mississippi_early", [], false)
	assert_true(village != null, "village registered")
	village.log_event("collapse", "Village collapsed")

	# Simulate collapse by archiving
	manager._collapsed_villages.append(village)

	var exported := manager.export_villages("planet_y")
	assert_eq(exported.get("collapsed", []).size(), 1, "exported 1 collapsed village")

	var manager2 := VillageManager.new()
	manager2._scenario_loader = ScenarioLoader.new()
	manager2.import_villages("planet_y", exported)

	var collapsed := manager2.get_collapsed_villages()
	assert_eq(collapsed.size(), 1, "imported 1 collapsed village")
	assert_eq(collapsed[0].village_id, "vm_collapse_test", "collapsed village_id matches")

	manager.queue_free()
	manager2.queue_free()
