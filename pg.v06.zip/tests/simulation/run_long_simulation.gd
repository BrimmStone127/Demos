extends SceneTree

## Long-running ecosystem simulation for detecting issues over time
##
## Usage:
##   godot --headless -s tests/simulation/run_long_simulation.gd
##   godot --headless -s tests/simulation/run_long_simulation.gd -- --ticks=1000 --planets=3
##
## Output is written to both console and /tmp/ecosystem_simulation.log
##
## This script simulates ecosystem dynamics over many game days to catch:
## - Population explosions (unbounded growth)
## - Extinctions (all trees die)
## - Performance degradation over time
## - Memory issues (tree count anomalies)
## - Edge cases that only appear after long runs

const DEFAULT_TICKS := 500          # Default simulation length
const DEFAULT_PLANETS := 2          # Number of planets to simulate
const LOG_INTERVAL := 50            # Log stats every N ticks
const WARN_TREE_MIN := 5            # Warn if trees drop below this
const WARN_TREE_MAX := 2000         # Warn if trees exceed this
const WARN_TICK_MS := 100           # Warn if tick takes longer than this

var _ecosystem_manager: EcosystemManager
var _log_file: FileAccess
var _start_time: int
var _tick_count := 0
var _total_ticks := DEFAULT_TICKS
var _planet_count := DEFAULT_PLANETS

# Statistics tracking
var _stats := {
	"total_births": 0,
	"total_deaths": 0,
	"peak_population": 0,
	"min_population": 999999,
	"slow_ticks": 0,
	"warnings": [],
	"tick_times": [],
}

# Per-planet tracking
var _planet_stats := {}

func _initialize():
	_parse_args()
	_setup_logging()
	_log("=" .repeat(70))
	_log("  ECOSYSTEM LONG-RUNNING SIMULATION")
	_log("=" .repeat(70))
	_log("Configuration:")
	_log("  - Total ticks: %d (%.1f game days)" % [_total_ticks, _total_ticks / 4.0])
	_log("  - Planets: %d" % _planet_count)
	_log("  - Log interval: every %d ticks" % LOG_INTERVAL)
	_log("")

	_start_time = Time.get_ticks_msec()

	_setup_ecosystem()
	await _run_simulation()
	_print_final_report()

	if _log_file:
		_log_file.close()

	quit(0 if _stats.warnings.size() == 0 else 1)

func _parse_args():
	# In Godot 4, args after '--' are accessed via get_cmdline_user_args()
	var args = OS.get_cmdline_user_args()
	for arg in args:
		if arg.begins_with("--ticks="):
			_total_ticks = int(arg.substr(8))
		elif arg.begins_with("--planets="):
			_planet_count = int(arg.substr(10))

func _setup_logging():
	_log_file = FileAccess.open("/tmp/ecosystem_simulation.log", FileAccess.WRITE)
	if _log_file == null:
		push_error("Could not open log file")

func _log(message: String):
	var timestamp = Time.get_datetime_string_from_system()
	var line = "[%s] %s" % [timestamp, message]
	print(line)
	if _log_file:
		_log_file.store_line(line)
		_log_file.flush()

func _warn(message: String):
	_stats.warnings.append(message)
	_log("[WARN] " + message)

func _setup_ecosystem():
	_ecosystem_manager = EcosystemManager.new()

	# Connect signals for tracking
	_ecosystem_manager.tree_planted.connect(_on_tree_planted)
	_ecosystem_manager.tree_died.connect(_on_tree_died)

	# Create test planets with different climates
	var climates = ["TEMPERATE", "TROPICAL", "COLD", "HOT", "FROZEN"]

	for i in range(_planet_count):
		var planet_id = "planet_%d" % i
		var climate = climates[i % climates.size()]
		var tiles = _make_test_map(64)
		var initial_trees = _make_initial_trees(tiles, 50 + i * 20)  # Varying initial populations

		var probe_data = {
			"climate_type": climate,
			"atmosphere_type": "MODERATE",
		}

		_ecosystem_manager.register_planet(planet_id, initial_trees, tiles, probe_data)

		_planet_stats[planet_id] = {
			"climate": climate,
			"initial_trees": initial_trees.size(),
			"births": 0,
			"deaths": 0,
			"peak": initial_trees.size(),
			"min": initial_trees.size(),
		}

		_log("Registered %s: %d trees, climate=%s" % [planet_id, initial_trees.size(), climate])

	_log("")

func _make_test_map(size: int) -> Array:
	var tiles = []
	tiles.resize(size)
	for x in range(size):
		tiles[x] = []
		tiles[x].resize(size)
		for y in range(size):
			var tile = MapTile.new(Vector2i(x, y), PlanetMapTileConfig.TileType.GRASS_0)
			tile.moisture_level = 0.5
			tiles[x][y] = tile
	return tiles

func _make_initial_trees(tiles: Array, count: int) -> Array:
	var trees: Array[TreeInstance] = []
	var registry = PlantSpeciesRegistry.get_instance()
	var config = registry.get_species_config(MapleTreeTypes.TR_MAPL_VG_1)

	var map_size = tiles.size()
	var rng = RandomNumberGenerator.new()
	rng.seed = Time.get_ticks_msec()

	var placed := {}
	var attempts := 0
	var max_attempts := count * 10

	while trees.size() < count and attempts < max_attempts:
		attempts += 1
		var x = rng.randi_range(3, map_size - 4)
		var y = rng.randi_range(3, map_size - 4)
		var pos = Vector2i(x, y)

		if placed.has(pos):
			continue

		var tree = TreeInstance.new()
		tree.position = pos
		tree.species = MapleTreeTypes.TR_MAPL_VG_1
		tree.growth_stage = TreeInstance.GrowthStage.MATURE
		tree.health = 1.0

		if config:
			tree.initialize_with_config(config, 1.0)
			tree.age_in_ticks = tree._thresholds[3]  # Start at MATURE

		trees.append(tree)
		placed[pos] = true

	return trees

func _run_simulation():
	_log("Starting simulation...")
	_log("-" .repeat(70))

	for tick in range(_total_ticks):
		_tick_count = tick + 1
		var tick_start = Time.get_ticks_msec()

		# Run simulation tick
		_ecosystem_manager.on_simulation_tick(tick + 1, (tick + 1) * 0.25)

		var tick_time = Time.get_ticks_msec() - tick_start
		_stats.tick_times.append(tick_time)

		# Check for slow ticks
		if tick_time > WARN_TICK_MS:
			_stats.slow_ticks += 1
			if _stats.slow_ticks <= 5:  # Only log first 5
				_warn("Slow tick %d: %dms" % [tick + 1, tick_time])

		# Update statistics
		_update_stats()

		# Periodic logging
		if (tick + 1) % LOG_INTERVAL == 0:
			_log_periodic_stats()

		# Check for anomalies
		_check_anomalies()

		# Yield occasionally to prevent blocking (SceneTree already IS the tree)
		if tick % 100 == 0:
			await process_frame

func _update_stats():
	var total_trees := 0

	for planet_id in _planet_stats.keys():
		var trees = _ecosystem_manager.get_trees_for_planet(planet_id)
		var count = trees.size()
		total_trees += count

		var ps = _planet_stats[planet_id]
		ps.peak = max(ps.peak, count)
		ps.min = min(ps.min, count)

	_stats.peak_population = max(_stats.peak_population, total_trees)
	_stats.min_population = min(_stats.min_population, total_trees)

func _check_anomalies():
	for planet_id in _planet_stats.keys():
		var trees = _ecosystem_manager.get_trees_for_planet(planet_id)
		var count = trees.size()
		var ps = _planet_stats[planet_id]

		# Check for extinction
		if count == 0 and ps.min > 0:
			_warn("EXTINCTION on %s at tick %d (started with %d trees)" % [
				planet_id, _tick_count, ps.initial_trees
			])
			ps.min = 0

		# Check for population explosion (use tracked flag to warn once per planet)
		if count > WARN_TREE_MAX:
			if not ps.get("explosion_warned", false):
				_warn("POPULATION EXPLOSION on %s: %d trees at tick %d (limit: %d)" % [
					planet_id, count, _tick_count, WARN_TREE_MAX
				])
				ps["explosion_warned"] = true

		# Check for near-extinction
		if count < WARN_TREE_MIN and count > 0 and ps.min >= WARN_TREE_MIN:
			_warn("NEAR EXTINCTION on %s: only %d trees at tick %d" % [
				planet_id, count, _tick_count
			])

func _log_periodic_stats():
	var lines := []
	lines.append("--- Tick %d (day %.1f) ---" % [_tick_count, _tick_count / 4.0])

	for planet_id in _planet_stats.keys():
		var trees = _ecosystem_manager.get_trees_for_planet(planet_id)
		var ps = _planet_stats[planet_id]

		# Count stages
		var stages := {}
		for tree in trees:
			var stage_name = TreeInstance.GrowthStage.keys()[tree.growth_stage]
			stages[stage_name] = stages.get(stage_name, 0) + 1

		lines.append("  %s (%s): %d trees [B:%d D:%d] %s" % [
			planet_id, ps.climate, trees.size(),
			ps.births, ps.deaths, stages
		])

	# Performance stats
	var recent_ticks = _stats.tick_times.slice(-LOG_INTERVAL)
	var avg_tick = 0.0
	for t in recent_ticks:
		avg_tick += t
	avg_tick /= recent_ticks.size() if recent_ticks.size() > 0 else 1

	lines.append("  Perf: avg %.1fms/tick, slow_ticks=%d" % [avg_tick, _stats.slow_ticks])

	for line in lines:
		_log(line)

func _on_tree_planted(position: Vector2i, _species: int):
	_stats.total_births += 1
	# Find which planet this belongs to (approximate - we don't have planet_id in signal)
	for planet_id in _planet_stats.keys():
		var tree = _ecosystem_manager.get_tree_at(planet_id, position)
		if tree != null:
			_planet_stats[planet_id].births += 1
			break

func _on_tree_died(position: Vector2i):
	_stats.total_deaths += 1
	# Find which planet this death occurred on by checking tree positions
	# Note: Tree is already removed, so we check all planets' current tree lists
	# to find one that previously had a tree at this position
	var found_planet := false
	for planet_id in _planet_stats.keys():
		# Since we can't determine which planet (tree already removed),
		# we track deaths proportionally based on each planet's relative population
		# This gives more accurate per-planet stats than attributing all to first planet
		pass

	# Distribute deaths proportionally to all planets by population share
	# This is still imprecise but more balanced than before
	var total_trees := 0
	for planet_id in _planet_stats.keys():
		total_trees += _ecosystem_manager.get_trees_for_planet(planet_id).size()

	if total_trees > 0:
		# Attribute to planet with most trees (more likely to have death)
		var max_planet := ""
		var max_trees := 0
		for planet_id in _planet_stats.keys():
			var count = _ecosystem_manager.get_trees_for_planet(planet_id).size()
			if count > max_trees:
				max_trees = count
				max_planet = planet_id
		if max_planet != "":
			_planet_stats[max_planet].deaths += 1
	elif _planet_stats.size() > 0:
		# Fallback if no trees exist
		var first_planet = _planet_stats.keys()[0]
		_planet_stats[first_planet].deaths += 1

func _print_final_report():
	var elapsed = Time.get_ticks_msec() - _start_time

	_log("")
	_log("=" .repeat(70))
	_log("  SIMULATION COMPLETE")
	_log("=" .repeat(70))
	_log("")
	_log("Duration: %.1f seconds (%d ticks)" % [elapsed / 1000.0, _total_ticks])
	_log("")
	_log("Overall Statistics:")
	_log("  - Total births: %d" % _stats.total_births)
	_log("  - Total deaths: %d" % _stats.total_deaths)
	_log("  - Net change: %+d" % [_stats.total_births - _stats.total_deaths])
	_log("  - Peak population: %d" % _stats.peak_population)
	_log("  - Min population: %d" % _stats.min_population)
	_log("")

	# Calculate tick time stats
	var min_tick := 999999
	var max_tick := 0
	var sum_tick := 0
	for t in _stats.tick_times:
		min_tick = min(min_tick, t)
		max_tick = max(max_tick, t)
		sum_tick += t
	var avg_tick = sum_tick / _stats.tick_times.size() if _stats.tick_times.size() > 0 else 0

	_log("Performance:")
	_log("  - Avg tick time: %.1fms" % avg_tick)
	_log("  - Min tick time: %dms" % min_tick)
	_log("  - Max tick time: %dms" % max_tick)
	_log("  - Slow ticks (>%dms): %d" % [WARN_TICK_MS, _stats.slow_ticks])
	_log("")

	_log("Per-Planet Results:")
	for planet_id in _planet_stats.keys():
		var trees = _ecosystem_manager.get_trees_for_planet(planet_id)
		var ps = _planet_stats[planet_id]
		_log("  %s (%s):" % [planet_id, ps.climate])
		_log("    Initial: %d, Final: %d, Peak: %d, Min: %d" % [
			ps.initial_trees, trees.size(), ps.peak, ps.min
		])
		_log("    Births: %d, Deaths: %d" % [ps.births, ps.deaths])

	_log("")

	if _stats.warnings.size() > 0:
		_log("WARNINGS (%d):" % _stats.warnings.size())
		for w in _stats.warnings:
			_log("  - %s" % w)
		_log("")
		_log("RESULT: ISSUES DETECTED")
	else:
		_log("RESULT: ALL CLEAR - No anomalies detected")

	_log("")
	_log("Log saved to: /tmp/ecosystem_simulation.log")
