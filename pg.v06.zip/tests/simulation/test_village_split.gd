extends "res://tests/test_base.gd"

## Tests for village splitting when population exceeds site capacity.


func _create_village_manager() -> VillageManager:
	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()
	return manager


func _create_village_with_pop(manager: VillageManager, pop: int, village_id: String = "test_v") -> VillageInstance:
	var village = manager.register_village("planet_1", village_id, "mississippi_early", [], false)
	village.camp_position = Vector2i(100, 100)
	# Replace auto-populated individuals with exact count
	village.individuals.clear()
	for i in range(pop):
		var person = PersonInstance.new()
		var sex = PersonInstance.Sex.MALE if i % 2 == 0 else PersonInstance.Sex.FEMALE
		var age = 20 + (i % 15)
		person.initialize("p_%d" % i, "Person%d" % i, sex, age, ["foraging"])
		village.individuals.append(person)
	return village


# --- Split threshold checks ---

func test_no_split_below_threshold():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 50)
	var split_received := false
	manager.village_split.connect(func(_p, _c): split_received = true)
	manager._check_village_split(village)
	assert_false(split_received, "50 people should not trigger split (threshold ~96)")


func test_no_split_without_enough_adults():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 100)
	# Make most people children
	for person in village.individuals:
		person.age = 5
	# Only a few adults
	for i in range(5):
		village.individuals[i].age = 25
	manager._check_village_split(village)
	# adult_count = 5 < 10, should not split
	assert_eq(manager.get_villages_on_planet("planet_1").size(), 1, "Not enough adults to split")


func test_split_at_threshold():
	var manager = _create_village_manager()
	var max_pop = VillageManager.MAX_LONGHOUSES_PER_SITE * VillageInstance.LONGHOUSE_CAPACITY
	var threshold = int(max_pop * VillageManager.SPLIT_THRESHOLD_RATIO)
	var village = _create_village_with_pop(manager, threshold)
	manager._check_village_split(village)
	# Should have split — now 2 villages
	assert_eq(manager.get_villages_on_planet("planet_1").size(), 2, "Village should have split")


# --- Split mechanics ---

func test_split_removes_people_from_parent():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 100)
	var pop_before = village.get_population()
	manager._split_village(village)
	assert_true(village.get_population() < pop_before, "Parent should have fewer people after split")
	assert_true(village.get_population() > 0, "Parent should still have people")


func test_split_creates_viable_child():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 100)
	manager._split_village(village)
	var villages = manager.get_villages_on_planet("planet_1")
	assert_eq(villages.size(), 2, "Two villages after split")
	var child = villages[1]
	assert_true(child.get_population() >= 5, "Child should be viable")
	assert_true(child.is_viable(), "Child village should pass viability check")


func test_split_child_inherits_knowledge():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 100)
	village.group_knowledge.clear()
	village.group_knowledge.append("foraging")
	village.group_knowledge.append("fishing")
	village.group_knowledge.append("hunting")
	village.era = "semi_settled"
	manager._split_village(village)
	var villages = manager.get_villages_on_planet("planet_1")
	var child = villages[1]
	assert_true(child.group_knowledge.has("foraging") and child.group_knowledge.has("fishing") and child.group_knowledge.has("hunting"), "Child inherits knowledge")
	assert_eq(child.era, "semi_settled", "Child inherits era")


func test_split_takes_about_40_percent():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 100)
	manager._split_village(village)
	var villages = manager.get_villages_on_planet("planet_1")
	var child = villages[1]
	# 40% of 100 = 40, parent should have ~60
	assert_true(child.get_population() >= 35 and child.get_population() <= 45,
		"Child should have ~40%% of original population (got %d)" % child.get_population())


func test_split_prefers_young_adults():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 100)
	# Make half old, half young
	for i in range(50):
		village.individuals[i].age = 50
	for i in range(50, 100):
		village.individuals[i].age = 25
	manager._split_village(village)
	var villages = manager.get_villages_on_planet("planet_1")
	var child = villages[1]
	# Count young adults in child
	var young_count := 0
	for person in child.individuals:
		if person.age >= 15 and person.age <= 35:
			young_count += 1
	assert_true(young_count > child.get_population() / 2,
		"Majority of child village should be young adults")


func test_split_signal_emitted():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 100)
	var signal_data := []
	manager.village_split.connect(func(pid, cid): signal_data.append({"parent": pid, "child": cid}))
	manager._split_village(village)
	assert_eq(signal_data.size(), 1, "Split signal emitted")
	assert_eq(signal_data[0]["parent"], "test_v", "Parent ID correct")
	assert_true(signal_data[0]["child"].begins_with("test_v_split_"), "Child ID follows naming convention")


func test_split_child_has_settlement_site():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 100)
	manager._split_village(village)
	var villages = manager.get_villages_on_planet("planet_1")
	var child = villages[1]
	assert_not_null(child.active_site, "Child has active settlement site")
	assert_eq(child.active_site.status, SettlementSite.Status.ACTIVE, "Child site is active")
	assert_true(child.active_site.longhouse_positions.size() >= 1, "Child has at least one longhouse")


func test_total_population_preserved():
	var manager = _create_village_manager()
	var village = _create_village_with_pop(manager, 100)
	manager._split_village(village)
	var total := 0
	for v in manager.get_villages_on_planet("planet_1"):
		total += v.get_population()
	# Total should be 100 (original) + 6 (auto-populated child from register) - 6 (cleared) + split = 100
	# Actually register_village creates a new village with starting_pop then we clear and replace
	assert_eq(total, 100, "Total population preserved across split")
