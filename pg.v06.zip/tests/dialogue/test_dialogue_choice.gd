extends "res://tests/test_base.gd"

# Tests for DialogueChoice

var choice: DialogueChoice
var player_stats: CharacterStats

func before_each():
	choice = DialogueChoice.new()
	player_stats = CharacterStats.new()

func test_simple_choice():
	choice.text = "Tell me more."
	assert_eq(choice.text, "Tell me more.", "Should store choice text")
	assert_false(choice.has_requirement(), "Simple choice should have no requirement")

func test_choice_with_requirement():
	choice.text = "I can fix that."
	choice.stat_name = "technical"
	choice.stat_minimum = 5

	assert_true(choice.has_requirement(), "Should have requirement")
	assert_eq(choice.stat_name, "technical", "Should store stat name")
	assert_eq(choice.stat_minimum, 5, "Should store minimum value")

func test_can_select_no_requirement():
	choice.text = "Simple choice"
	assert_true(choice.can_select(player_stats), "Should be selectable without requirement")
	assert_true(choice.can_select(null), "Should be selectable even without stats")

func test_can_select_with_requirement():
	choice.text = "Technical choice"
	choice.stat_name = "technical"
	choice.stat_minimum = 5

	player_stats.set_stat("technical", 3)
	assert_false(choice.can_select(player_stats), "Should not be selectable below requirement")

	player_stats.set_stat("technical", 5)
	assert_true(choice.can_select(player_stats), "Should be selectable at exact requirement")

	player_stats.set_stat("technical", 8)
	assert_true(choice.can_select(player_stats), "Should be selectable above requirement")

func test_success_chance():
	choice.text = "Risky choice"
	choice.success_chance = 0.5

	assert_true(choice.has_success_chance(), "Should have success chance")

	# Test roll_success (probabilistic, just verify it returns bool)
	var result = choice.roll_success()
	assert_true(result is bool, "roll_success should return bool")

func test_success_chance_guaranteed():
	choice.text = "Safe choice"
	choice.success_chance = 1.0

	assert_false(choice.has_success_chance(), "1.0 chance should not count as having chance")
	assert_true(choice.roll_success(), "1.0 chance should always succeed")

func test_failure_branch():
	choice.text = "Persuade them"
	choice.next_dialogue_id = "success_dialogue"
	choice.failure_dialogue_id = "failure_dialogue"

	assert_true(choice.has_failure_branch(), "Should have failure branch")
	assert_eq(choice.get_result_dialogue_id(true), "success_dialogue", "Success should go to next_dialogue_id")
	assert_eq(choice.get_result_dialogue_id(false), "failure_dialogue", "Failure should go to failure_dialogue_id")

func test_no_failure_branch():
	choice.text = "Simple choice"
	choice.next_dialogue_id = "next"

	assert_false(choice.has_failure_branch(), "Should not have failure branch")
	assert_eq(choice.get_result_dialogue_id(false), "next", "Failure without branch should use next_dialogue_id")

func test_locked_text():
	choice.text = "Hack the terminal"
	choice.locked_text = "[Requires Technical 5]"
	choice.stat_name = "technical"
	choice.stat_minimum = 5

	player_stats.set_stat("technical", 3)
	assert_eq(choice.get_display_text(player_stats), "[Requires Technical 5]", "Should show locked text when requirement not met")

	player_stats.set_stat("technical", 5)
	assert_eq(choice.get_display_text(player_stats), "Hack the terminal", "Should show normal text when requirement met")

func test_formatted_text_with_requirement():
	choice.text = "Convince them"
	choice.stat_name = "charisma"
	choice.stat_minimum = 5

	player_stats.set_stat("charisma", 3)
	var formatted = choice.get_formatted_text(player_stats)
	assert_true("Charisma" in formatted, "Should include stat name")
	assert_true("3/5" in formatted, "Should show current/required")
	assert_true("Convince them" in formatted, "Should include original text")

func test_tags():
	choice.text = "Threaten them"
	choice.tags = ["aggressive", "intimidate"]

	assert_true("aggressive" in choice.tags, "Should store tags")
	assert_eq(choice.tags.size(), 2, "Should have correct number of tags")

func test_serialization():
	choice.text = "Test choice"
	choice.next_dialogue_id = "next"
	choice.stat_name = "charisma"
	choice.stat_minimum = 5
	choice.success_chance = 0.75
	choice.tags = ["test"]

	var data = choice.to_dict()
	var restored = DialogueChoice.from_dict(data)

	assert_eq(restored.text, "Test choice", "Should restore text")
	assert_eq(restored.next_dialogue_id, "next", "Should restore next_dialogue_id")
	assert_eq(restored.stat_name, "charisma", "Should restore stat_name")
	assert_eq(restored.stat_minimum, 5, "Should restore stat_minimum")
	assert_eq(restored.success_chance, 0.75, "Should restore success_chance")
	assert_true("test" in restored.tags, "Should restore tags")

func test_factory_create():
	var simple = DialogueChoice.create("Hello", "next_id")
	assert_eq(simple.text, "Hello", "Should create with text")
	assert_eq(simple.next_dialogue_id, "next_id", "Should create with next_id")
	assert_false(simple.has_requirement(), "Should not have requirement")

func test_factory_create_with_requirement():
	var req_choice = DialogueChoice.create_with_requirement("Fix it", "technical", 5, "fixed")
	assert_eq(req_choice.text, "Fix it", "Should create with text")
	assert_eq(req_choice.stat_name, "technical", "Should create with stat requirement")
	assert_eq(req_choice.stat_minimum, 5, "Should create with minimum")
	assert_eq(req_choice.next_dialogue_id, "fixed", "Should create with next_id")
