extends "res://tests/test_node_base.gd"

## Tests for SaveListDialog UI component

func test_dialog_creation_save_mode():
	var manager = SaveGameManager.new()
	autofree(manager)
	var dialog = SaveListDialog.new(SaveListDialog.Mode.SAVE, manager)
	autofree(dialog)
	add_child(dialog)
	await wait_frames(2)
	assert_true(dialog != null, "Dialog should be created in save mode")
	assert_eq(dialog.name, "SaveListDialog", "Dialog should have correct name")

func test_dialog_creation_load_mode():
	var manager = SaveGameManager.new()
	autofree(manager)
	var dialog = SaveListDialog.new(SaveListDialog.Mode.LOAD, manager)
	autofree(dialog)
	add_child(dialog)
	await wait_frames(2)
	assert_true(dialog != null, "Dialog should be created in load mode")

func test_mode_enum_values():
	assert_eq(SaveListDialog.Mode.SAVE, 0, "SAVE mode should be 0")
	assert_eq(SaveListDialog.Mode.LOAD, 1, "LOAD mode should be 1")

func test_save_slot_panel_creation():
	var save_data = {
		"slot_id": "save_001",
		"save_name": "Test Save",
		"game_days_elapsed": 10.0,
		"current_seed": 42,
		"timestamp": 1720000000.0
	}
	var panel = SaveSlotPanel.new(save_data)
	autofree(panel)
	add_child(panel)
	await wait_frames(2)
	assert_eq(panel.get_slot_id(), "save_001", "Panel should have correct slot_id")

func test_save_slot_panel_has_signals():
	var save_data = {"slot_id": "save_002", "save_name": "Test", "timestamp": 0.0}
	var panel = SaveSlotPanel.new(save_data)
	autofree(panel)
	add_child(panel)
	await wait_frames(2)
	assert_true(panel.has_signal("slot_selected"), "Panel should have slot_selected signal")
	assert_true(panel.has_signal("slot_deleted"), "Panel should have slot_deleted signal")
	assert_true(panel.has_signal("slot_renamed"), "Panel should have slot_renamed signal")
