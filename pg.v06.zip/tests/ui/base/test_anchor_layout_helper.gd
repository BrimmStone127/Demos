extends "res://tests/test_base.gd"

# Tests for AnchorLayoutHelper utility functions

func get_test_name() -> String:
	return "anchor_layout_helper"


func test_setup_top_margin_container():
	var container = Control.new()
	autofree(container)

	AnchorLayoutHelper.setup_top_margin_container(container, 96.0, 10.0, 10.0)

	# Both anchors should be at top (0.0)
	assert_eq(container.anchor_left, 0.0, "anchor_left should be 0")
	assert_eq(container.anchor_right, 1.0, "anchor_right should be 1")
	assert_eq(container.anchor_top, 0.0, "anchor_top should be 0")
	assert_eq(container.anchor_bottom, 0.0, "anchor_bottom should also be 0 for fixed height")

	# Offsets
	assert_eq(container.offset_left, 10.0, "offset_left should match margin")
	assert_eq(container.offset_right, -10.0, "offset_right should be negative margin")
	assert_eq(container.offset_top, 0.0, "offset_top should be 0")
	assert_eq(container.offset_bottom, 96.0, "offset_bottom should be the height")


func test_setup_bottom_margin_container():
	var container = Control.new()
	autofree(container)

	AnchorLayoutHelper.setup_bottom_margin_container(container, 96.0, 10.0, 10.0)

	# Both anchors should be at bottom (1.0)
	assert_eq(container.anchor_left, 0.0, "anchor_left should be 0")
	assert_eq(container.anchor_right, 1.0, "anchor_right should be 1")
	assert_eq(container.anchor_top, 1.0, "anchor_top should be 1 for bottom-anchored")
	assert_eq(container.anchor_bottom, 1.0, "anchor_bottom should be 1")

	# Offsets
	assert_eq(container.offset_left, 10.0, "offset_left should match margin")
	assert_eq(container.offset_right, -10.0, "offset_right should be negative margin")
	assert_eq(container.offset_top, -96.0, "offset_top should be negative height")
	assert_eq(container.offset_bottom, 0.0, "offset_bottom should be 0")


func test_setup_full_rect_with_margins():
	var control = Control.new()
	autofree(control)

	AnchorLayoutHelper.setup_full_rect_with_margins(control, 20.0)

	# Should have full rect anchors
	assert_eq(control.anchor_left, 0.0, "anchor_left should be 0")
	assert_eq(control.anchor_right, 1.0, "anchor_right should be 1")
	assert_eq(control.anchor_top, 0.0, "anchor_top should be 0")
	assert_eq(control.anchor_bottom, 1.0, "anchor_bottom should be 1")

	# Margins as offsets
	assert_eq(control.offset_left, 20.0, "offset_left should be margin")
	assert_eq(control.offset_right, -20.0, "offset_right should be negative margin")
	assert_eq(control.offset_top, 20.0, "offset_top should be margin")
	assert_eq(control.offset_bottom, -20.0, "offset_bottom should be negative margin")


func test_create_right_aligned_container():
	var parent = Panel.new()
	autofree(parent)

	var align_container = AnchorLayoutHelper.create_right_aligned_container(parent, 5.0)

	# Should have created and added a MarginContainer
	assert_eq(parent.get_child_count(), 1, "Parent should have one child")
	var margin_container = parent.get_child(0)
	assert_true(margin_container is MarginContainer, "Child should be MarginContainer")

	# MarginContainer should have the HBoxContainer
	assert_eq(margin_container.get_child_count(), 1, "MarginContainer should have one child")
	assert_true(align_container is HBoxContainer, "Returned container should be HBoxContainer")

	# HBoxContainer should be right-aligned
	assert_eq(align_container.alignment, BoxContainer.ALIGNMENT_END, "Should be right-aligned")
	assert_eq(align_container.size_flags_horizontal, Control.SIZE_EXPAND_FILL, "Should expand to fill")


func test_create_center_aligned_container():
	var parent = Panel.new()
	autofree(parent)

	var align_container = AnchorLayoutHelper.create_center_aligned_container(parent, 5.0)

	# Should have created and added a MarginContainer
	assert_eq(parent.get_child_count(), 1, "Parent should have one child")
	var margin_container = parent.get_child(0)
	assert_true(margin_container is MarginContainer, "Child should be MarginContainer")

	# HBoxContainer should be center-aligned
	assert_true(align_container is HBoxContainer, "Returned container should be HBoxContainer")
	assert_eq(align_container.alignment, BoxContainer.ALIGNMENT_CENTER, "Should be center-aligned")


func test_top_margin_container_default_margins():
	var container = Control.new()
	autofree(container)

	# Test with default (0) left/right margins
	AnchorLayoutHelper.setup_top_margin_container(container, 50.0)

	assert_eq(container.offset_left, 0.0, "Default left margin should be 0")
	assert_eq(container.offset_right, 0.0, "Default right margin should be 0")
