extends "res://tests/test_base.gd"

# Tests for ZIndexLayers standardized z-index constants

func get_test_name() -> String:
	return "z_index_layers"


# Test that layer values are properly ordered
func test_background_layers_are_negative():
	assert_lt(ZIndexLayers.BACKGROUND_FAR, 0, "BACKGROUND_FAR should be negative")
	assert_lt(ZIndexLayers.BACKGROUND_NEAR, 0, "BACKGROUND_NEAR should be negative")
	assert_lt(ZIndexLayers.BACKGROUND, 0, "BACKGROUND should be negative")


func test_content_layers_are_non_negative():
	assert_gte(ZIndexLayers.CONTENT_BACK, 0, "CONTENT_BACK should be >= 0")
	assert_gte(ZIndexLayers.CONTENT_MIDDLE, 0, "CONTENT_MIDDLE should be >= 0")
	assert_gte(ZIndexLayers.CONTENT_FRONT, 0, "CONTENT_FRONT should be >= 0")


func test_layer_ordering():
	# Background < Content < Overlay < UI < Modal < Debug
	assert_lt(ZIndexLayers.BACKGROUND, ZIndexLayers.CONTENT_BACK, "Background should be below content")
	assert_lt(ZIndexLayers.CONTENT_FRONT, ZIndexLayers.OVERLAY_BACK, "Content should be below overlay")
	assert_lt(ZIndexLayers.OVERLAY_FRONT, ZIndexLayers.UI_PANELS, "Overlay should be below UI panels")
	assert_lt(ZIndexLayers.UI_PANELS_TOP, ZIndexLayers.MODAL_BACKDROP, "UI should be below modal")
	assert_lt(ZIndexLayers.MODAL_TOP, ZIndexLayers.DEBUG, "Modal should be below debug")


func test_get_layer_name_returns_correct_names():
	assert_eq(ZIndexLayers.get_layer_name(ZIndexLayers.BACKGROUND_FAR), "BACKGROUND_FAR", "Should return correct name")
	assert_eq(ZIndexLayers.get_layer_name(ZIndexLayers.CONTENT_BACK), "CONTENT_BACK", "Should return correct name")
	assert_eq(ZIndexLayers.get_layer_name(ZIndexLayers.UI_PANELS), "UI_PANELS", "Should return correct name")
	assert_eq(ZIndexLayers.get_layer_name(ZIndexLayers.MODAL_CONTENT), "MODAL_CONTENT", "Should return correct name")
	assert_eq(ZIndexLayers.get_layer_name(ZIndexLayers.DEBUG_OVERLAY), "DEBUG_OVERLAY", "Should return correct name")


func test_get_layer_name_handles_intermediate_values():
	# Values between defined constants return the highest threshold they meet
	# (99 + 100) / 2 = 99 (integer division), which is >= CONTENT_FRONT (99)
	var between_content_and_overlay = (ZIndexLayers.CONTENT_FRONT + ZIndexLayers.OVERLAY_BACK) / 2
	var layer_name = ZIndexLayers.get_layer_name(between_content_and_overlay)
	# Should return CONTENT_FRONT since 99 >= 99 but 99 < 100
	assert_eq(layer_name, "CONTENT_FRONT", "Intermediate value should return correct layer name")
