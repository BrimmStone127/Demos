extends "res://tests/test_base.gd"

## Tests for Conversation component
## Verifies dialogue tree navigation and signaling

var convo: Conversation

func before_each():
	convo = Conversation.new()

func test_add_dialogue():
	convo.add_dialogue("start", "AI", "Hello.")
	assert_true(convo.has_dialogue("start"), "Should have dialogue node")
	assert_eq(convo.get_dialogue_ids().size(), 1, "Should have 1 node")

func test_dialogue_with_choices():
	convo.add_dialogue("start", "AI", "Choose.", ["A", "B"])
	assert_eq(convo.get_choice_count(), 0, "Not started yet")
	
	convo.start()
	assert_eq(convo.get_choice_count(), 2, "Should have 2 choices")
	var choices = convo.get_choices()
	assert_eq(choices[0], "A")
	assert_eq(choices[1], "B")

func test_link_choices():
	convo.add_dialogue("start", "AI", "Start", ["Go"])
	convo.add_dialogue("end", "AI", "End")
	convo.link_choice("start", 0, "end")
	
	convo.start()
	convo.select_choice(0)
	assert_eq(convo.get_current_text(), "End", "Should advance to linked dialogue")

func test_conversation_flow():
	convo.add_dialogue("1", "AI", "One", ["Next"])
	convo.add_dialogue("2", "AI", "Two")
	convo.link_choice("1", 0, "2")
	
	convo.start("1")
	assert_eq(convo.get_current_text(), "One")
	
	convo.select_choice(0)
	assert_eq(convo.get_current_text(), "Two")

func test_conversation_end():
	var signal_data = {"ended": false}
	convo.conversation_ended.connect(func(): signal_data.ended = true)
	
	convo.add_dialogue("1", "AI", "Bye", ["End"]) # Add a choice
	convo.start()
	convo.select_choice(0) # Select the choice that leads nowhere
	
	assert_true(signal_data.ended, "Should emit ended signal")
	assert_false(convo.is_active, "Should not be active")

func test_dialogue_changed_signal():
	var signal_data = {"ids": []}
	convo.dialogue_changed.connect(func(id): signal_data.ids.append(id))
	
	convo.add_dialogue("start", "AI", "S", ["Next"])
	convo.add_dialogue("next", "AI", "N")
	convo.link_choice("start", 0, "next")
	
	convo.start()
	assert_eq(signal_data.ids.size(), 1)
	assert_eq(signal_data.ids[0], "start")
	
	convo.select_choice(0)
	assert_eq(signal_data.ids.size(), 2)
	assert_eq(signal_data.ids[1], "next")

func test_go_to():
	convo.add_dialogue("a", "AI", "A")
	convo.add_dialogue("b", "AI", "B")
	
	convo.start("a")
	convo.go_to("b")
	assert_eq(convo.get_current_text(), "B")

func test_set_start():
	convo.add_dialogue("a", "AI", "A")
	convo.add_dialogue("b", "AI", "B")
	convo.set_start("b")
	
	convo.start()
	assert_eq(convo.get_current_text(), "B")

func test_choice_with_no_link_ends_conversation():
	var signal_data = {"ended": false}
	convo.conversation_ended.connect(func(): signal_data.ended = true)
	
	convo.add_dialogue("1", "AI", "One", ["End"])
	convo.start()
	convo.select_choice(0)
	
	assert_true(signal_data.ended, "Choice with no next should end conversation")

func test_conversation_with_dialogue_choice_objects():
	var choice = DialogueChoice.new()
	choice.text = "Obj Choice"
	choice.next_dialogue_id = "next"
	
	convo.add_dialogue("start", "AI", "Start", [choice])
	convo.add_dialogue("next", "AI", "Next")
	
	convo.start()
	convo.select_choice(0)
	assert_eq(convo.get_current_text(), "Next")
