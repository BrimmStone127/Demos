extends "res://tests/test_base.gd"

# Tests for DialogueData

func test_default_values():
	var data = DialogueData.new()
	assert_eq(data.speaker, "")
	assert_eq(data.text, "")
	assert_eq(data.choices.size(), 0)
	assert_eq(data.auto_close_time, 0.0)
	assert_almost_eq(data.typing_speed, 0.05, 0.001)
	assert_true(data.allow_skip)

func test_default_metadata():
	var data = DialogueData.new()
	assert_has(data.metadata, "origin")
	assert_has(data.metadata, "priority")
	assert_has(data.metadata, "encrypted")
	assert_has(data.metadata, "ai_personality")
	assert_eq(data.metadata["ai_personality"], "neutral")

func test_has_choices_false_when_empty():
	var data = DialogueData.new()
	assert_false(data.has_choices())

func test_has_choices_true_when_populated():
	var data = DialogueData.new()
	data.choices = ["Option 1", "Option 2"]
	assert_true(data.has_choices())

func test_get_choice_count():
	var data = DialogueData.new()
	assert_eq(data.get_choice_count(), 0)
	data.choices = ["A", "B", "C"]
	assert_eq(data.get_choice_count(), 3)

func test_get_choice_valid_index():
	var data = DialogueData.new()
	data.choices = ["First", "Second", "Third"]
	assert_eq(data.get_choice(0), "First")
	assert_eq(data.get_choice(1), "Second")
	assert_eq(data.get_choice(2), "Third")

func test_get_choice_invalid_index():
	var data = DialogueData.new()
	data.choices = ["Only one"]
	assert_eq(data.get_choice(-1), "")
	assert_eq(data.get_choice(5), "")

func test_add_choice():
	var data = DialogueData.new()
	data.add_choice("New choice")
	assert_eq(data.get_choice_count(), 1)
	assert_eq(data.get_choice(0), "New choice")

func test_set_choices():
	var data = DialogueData.new()
	data.set_choices(["A", "B"])
	assert_eq(data.get_choice_count(), 2)

func test_set_origin():
	var data = DialogueData.new()
	data.set_origin("Deep Space Relay")
	assert_eq(data.metadata["origin"], "Deep Space Relay")

func test_set_ai_personality():
	var data = DialogueData.new()
	data.set_ai_personality("concerned")
	assert_eq(data.metadata["ai_personality"], "concerned")

func test_set_priority():
	var data = DialogueData.new()
	data.set_priority(5)
	assert_eq(data.metadata["priority"], 5)

func test_set_encrypted():
	var data = DialogueData.new()
	assert_false(data.metadata["encrypted"])
	data.set_encrypted(true)
	assert_true(data.metadata["encrypted"])

func test_create_text_factory():
	var data = DialogueData.create_text("Captain", "Hello there!")
	assert_eq(data.speaker, "Captain")
	assert_eq(data.text, "Hello there!")
	assert_false(data.has_choices())

func test_create_choice_factory():
	var data = DialogueData.create_choice("NPC", "What do you want?", ["Trade", "Talk", "Leave"])
	assert_eq(data.speaker, "NPC")
	assert_eq(data.text, "What do you want?")
	assert_eq(data.get_choice_count(), 3)
	assert_eq(data.get_choice(0), "Trade")

func test_create_transmission_factory():
	var data = DialogueData.create_transmission("Unknown Ship", "Mayday!", "Sector 7")
	assert_eq(data.speaker, "Unknown Ship")
	assert_eq(data.text, "Mayday!")
	assert_eq(data.metadata["origin"], "Sector 7")

func test_create_ai_message_factory():
	var data = DialogueData.create_ai_message("Systems nominal", "ARIA", "friendly")
	assert_eq(data.speaker, "ARIA")
	assert_eq(data.text, "Systems nominal")
	assert_eq(data.metadata["ai_personality"], "friendly")

func test_create_ai_message_defaults():
	var data = DialogueData.create_ai_message("Alert!")
	assert_eq(data.speaker, "Ship AI")
	assert_eq(data.metadata["ai_personality"], "neutral")
