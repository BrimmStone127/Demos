extends "res://tests/test_node_base.gd"

## Tests for PlanetMapInfoPanels component
## Verifies ecosystem and tile info panel management

const GRASS_TYPE = PlanetMapTileConfig.TileType.GRASS_0

func _make_mock_planet_map_system() -> PlanetMapSystem:
	var pms = PlanetMapSystem.new()
	autofree(pms)
	return pms

func _make_mock_planet() -> Planet:
	var props = {
		"scale_range": Vector2(0.062, 0.074),
		"colors": [Color(0.3, 0.6, 0.7)]
	}
	var planet = Planet.new(null, 100.0, 0.02, PlanetEnums.PlanetType.SUPER_EARTH, props, true)
	autofree(planet)
	planet.planet_name = "Test Planet"
	planet.habitability_score = 0.8
	return planet

func test_refresh_ecosystem_panel():
	var ecosystem_section = VBoxContainer.new()
	autofree(ecosystem_section)
	add_child(ecosystem_section)

	var tile_info_section = VBoxContainer.new()
	autofree(tile_info_section)

	var ui_builder = PlanetMapUIBuilder.new()
	var info_panels = PlanetMapInfoPanels.new()
	info_panels.initialize(ecosystem_section, tile_info_section, ui_builder)

	var pms = _make_mock_planet_map_system()
	var planet = _make_mock_planet()

	info_panels.refresh_ecosystem_panel(pms, planet)

	assert_gt(float(ecosystem_section.get_child_count()), 0.0, "Should add labels to ecosystem section")

func test_clear_tile_panel():
	var ecosystem_section = VBoxContainer.new()
	autofree(ecosystem_section)

	var tile_info_section = VBoxContainer.new()
	autofree(tile_info_section)
	add_child(tile_info_section)

	# Add some existing children
	var label = Label.new()
	tile_info_section.add_child(label)

	var ui_builder = PlanetMapUIBuilder.new()
	var info_panels = PlanetMapInfoPanels.new()
	info_panels.initialize(ecosystem_section, tile_info_section, ui_builder)

	info_panels.clear_tile_panel()
	await wait_frames(1)  # Wait for queue_free

	assert_eq(tile_info_section.get_child_count(), 0, "Should clear all children")
