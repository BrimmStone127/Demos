extends "res://tests/test_base.gd"

## Tests for PlanetMapDayNight smoothing behavior
## Verifies lerp eliminates per-frame flicker and first-frame snap works
## Now tests CanvasModulate color (multiplicative) instead of ColorRect alpha (additive)

var _day_night: PlanetMapDayNight
var _modulate: CanvasModulate

func before_each():
	_day_night = PlanetMapDayNight.new()
	_modulate = CanvasModulate.new()
	_day_night.day_night_modulate = _modulate
	_day_night.enabled = true

func after_each():
	if is_instance_valid(_modulate):
		_modulate.free()

## Compute target darkness for a given time_of_day (mirrors the real math)
func _target_darkness_for(time_of_day: float) -> float:
	var t = clampf(abs(time_of_day - 0.5) * 2.0, 0.0, 1.0)
	t = pow(t, 0.8)
	t = t * t * t * (t * (t * 6.0 - 15.0) + 10.0)
	t = t * t * (3.0 - 2.0 * t)
	return t

## Helper: simulate one frame of lighting with a given time_of_day
## Reproduces the math from update_day_night_lighting without needing a Planet
func _simulate_lighting_frame(time_of_day: float, delta: float) -> void:
	var target_darkness = _target_darkness_for(time_of_day)
	if not _day_night._initialized_darkness:
		_day_night._current_darkness = target_darkness
		_day_night._initialized_darkness = true
	else:
		_day_night._current_darkness = lerpf(
			_day_night._current_darkness,
			target_darkness,
			clampf(delta * PlanetMapDayNight.DARKNESS_LERP_SPEED, 0.0, 1.0)
		)
	var modulate_color = Color.WHITE.lerp(PlanetMapDayNight.NIGHT_COLOR, _day_night._current_darkness)
	_day_night.day_night_modulate.color = modulate_color

func test_darkness_starts_at_zero():
	assert_eq(_day_night._current_darkness, 0.0, "Darkness should start at 0")

func test_first_frame_snaps_to_target():
	# First frame at midnight should snap, not lerp from 0
	_simulate_lighting_frame(0.0, 0.016)
	var expected = _target_darkness_for(0.0)
	assert_almost_eq(_day_night._current_darkness, expected, 0.001, "First frame should snap to target")

func test_first_frame_snaps_at_noon():
	_simulate_lighting_frame(0.5, 0.016)
	assert_lt(_day_night._current_darkness, 0.001, "First frame at noon should snap to ~0")

func test_midnight_converges_to_max_darkness():
	for i in range(120):
		_simulate_lighting_frame(0.0, 0.016)
	assert_gt(_day_night._current_darkness, 0.9, "Midnight should converge to high darkness")

func test_noon_converges_to_zero_darkness():
	# Start at midnight (first frame snap)
	_simulate_lighting_frame(0.0, 0.016)
	for i in range(120):
		_simulate_lighting_frame(0.5, 0.016)
	assert_lt(_day_night._current_darkness, 0.01, "Noon should converge to near-zero darkness")

func test_smooth_transition_no_jumps():
	# First frame at noon (snap)
	_simulate_lighting_frame(0.5, 0.016)

	var prev = _day_night._current_darkness
	var max_jump = 0.0

	# Slowly advance time from noon toward dusk
	for i in range(120):
		var time_of_day = 0.5 + (float(i) / 120.0) * 0.25
		_simulate_lighting_frame(time_of_day, 0.016)
		var jump = abs(_day_night._current_darkness - prev)
		if jump > max_jump:
			max_jump = jump
		prev = _day_night._current_darkness

	assert_lt(max_jump, 0.05, "Per-frame darkness change should be smooth")

func test_lerp_smooths_instant_jump():
	# First frame at noon (snap)
	_simulate_lighting_frame(0.5, 0.016)
	assert_lt(_day_night._current_darkness, 0.01, "Should be near zero at noon")

	# Instantly jump to midnight — one frame (lerp, not snap)
	_simulate_lighting_frame(0.0, 0.016)

	assert_lt(_day_night._current_darkness, 0.15, "Lerp should prevent instant jump to max")
	assert_gt(_day_night._current_darkness, 0.0, "Should have moved toward target")

func test_modulate_color_at_noon():
	_simulate_lighting_frame(0.5, 0.016)
	# At noon, darkness ~0, so modulate should be near white
	assert_almost_eq(_modulate.color.r, 1.0, 0.01, "Noon red should be near 1.0")
	assert_almost_eq(_modulate.color.g, 1.0, 0.01, "Noon green should be near 1.0")
	assert_almost_eq(_modulate.color.b, 1.0, 0.01, "Noon blue should be near 1.0")

func test_modulate_color_at_midnight():
	for i in range(120):
		_simulate_lighting_frame(0.0, 0.016)
	# At midnight, should converge toward NIGHT_COLOR
	assert_lt(_modulate.color.r, 0.4, "Midnight red should be dark")
	assert_lt(_modulate.color.g, 0.4, "Midnight green should be dark")
	assert_lt(_modulate.color.b, 0.5, "Midnight blue should be dark but bluer")
	assert_gt(_modulate.color.b, _modulate.color.r, "Night should have blue tint")

func test_planet_change_resets_snap():
	# First planet: snap at noon
	_simulate_lighting_frame(0.5, 0.016)
	assert_true(_day_night._initialized_darkness, "Should be initialized after first frame")

	# Simulate planet change
	_day_night._initialized_darkness = false

	# Next frame at midnight should snap (not lerp from noon)
	_simulate_lighting_frame(0.0, 0.016)
	var expected = _target_darkness_for(0.0)
	assert_almost_eq(_day_night._current_darkness, expected, 0.001, "Should snap after planet change")

func test_disabled_skips_update():
	_day_night.set_enabled(false)
	assert_eq(_day_night._current_darkness, 0.0, "Disabled should not change darkness")

func test_disabled_resets_to_white():
	# Run a few frames at midnight
	for i in range(30):
		_simulate_lighting_frame(0.0, 0.016)
	assert_gt(_day_night._current_darkness, 0.5, "Should be dark after midnight frames")

	# Disable — modulate should reset to white
	_day_night.set_enabled(false)
	assert_eq(_modulate.color, Color.WHITE, "Disabling should reset modulate to white")
