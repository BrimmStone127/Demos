extends "res://tests/test_base.gd"

## Tests for VillageListPanel and VillagerSystem visited tile tracking.


# --- VillageListPanel ---

func test_village_list_panel_starts_hidden():
	var panel = VillageListPanel.new()
	autofree(panel)
	# _ready() not called without scene tree, but visible defaults
	assert_not_null(panel, "Panel created")


func test_village_list_refresh_empty():
	var panel = VillageListPanel.new()
	autofree(panel)
	panel._build_ui()
	panel.refresh([], 0)
	assert_not_null(panel._content, "Content container exists")


func test_village_list_refresh_with_villages():
	var panel = VillageListPanel.new()
	autofree(panel)
	panel._build_ui()

	var manager = VillageManager.new()
	manager._scenario_loader = ScenarioLoader.new()
	var village = manager.register_village("planet_1", "test_v1", "mississippi_early", [], false)
	village.camp_position = Vector2i(50, 50)

	var villages = manager.get_villages_on_planet("planet_1")
	panel.refresh(villages, 10)
	assert_true(panel._content.get_child_count() > 0, "Village cards rendered")


func test_village_list_signal_emitted():
	var panel = VillageListPanel.new()
	autofree(panel)
	panel._build_ui()

	var received := []
	panel.village_selected.connect(func(vid): received.append(vid))

	# Signal should be connectable
	assert_eq(received.size(), 0, "No signal yet")


# --- VillagerSystem visited tiles ---

func test_visited_tiles_initially_empty():
	var vs = VillagerSystem.new()
	autofree(vs)
	var tiles = vs.get_visited_tiles("nonexistent")
	assert_eq(tiles.size(), 0, "No visited tiles for unknown village")


func test_visited_tiles_accessor():
	var vs = VillagerSystem.new()
	autofree(vs)
	vs._visited_tiles["v1"] = {Vector2i(10, 10): true, Vector2i(11, 11): true}
	var tiles = vs.get_visited_tiles("v1")
	assert_eq(tiles.size(), 2, "Two visited tiles")
	assert_true(tiles.has(Vector2i(10, 10)), "Tile recorded")


func test_clear_visited_tiles():
	var vs = VillagerSystem.new()
	autofree(vs)
	vs._visited_tiles["v1"] = {Vector2i(5, 5): true}
	vs.clear_visited_tiles("v1")
	assert_eq(vs.get_visited_tiles("v1").size(), 0, "Tiles cleared")


func test_get_all_visited_tiles():
	var vs = VillagerSystem.new()
	autofree(vs)
	vs._visited_tiles["v1"] = {Vector2i(1, 1): true}
	vs._visited_tiles["v2"] = {Vector2i(2, 2): true}
	var all_tiles = vs.get_all_visited_tiles()
	assert_eq(all_tiles.size(), 2, "Two villages tracked")


func test_remove_village_clears_visited():
	var vs = VillagerSystem.new()
	autofree(vs)
	vs._visited_tiles["v1"] = {Vector2i(1, 1): true}
	vs._villages_by_id["v1"] = null
	vs.remove_village("v1")
	assert_false(vs._visited_tiles.has("v1"), "Visited tiles removed with village")


# --- VillageTerritoryOverlay ---

func test_territory_overlay_created():
	var overlay = VillageTerritoryOverlay.new()
	autofree(overlay)
	assert_not_null(overlay, "Overlay created")
	assert_eq(overlay.VILLAGE_COLORS.size(), 8, "8 village colors defined")


func test_territory_overlay_color_palette():
	var overlay = VillageTerritoryOverlay.new()
	autofree(overlay)
	# All colors should have alpha for semi-transparency
	for color in overlay.VILLAGE_COLORS:
		assert_true(color.a < 1.0, "Colors are semi-transparent")
		assert_true(color.a > 0.0, "Colors are visible")
