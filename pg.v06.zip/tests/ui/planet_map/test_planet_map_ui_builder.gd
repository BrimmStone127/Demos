extends "res://tests/test_node_base.gd"

## Tests for PlanetMapUIBuilder component
## Verifies UI widget creation and layout

func test_builds_viewport_container():
	var builder = PlanetMapUIBuilder.new()
	var control = Control.new()
	autofree(control)
	add_child(control)

	var ui_refs = builder.build_ui(control)

	assert_not_null(ui_refs["viewport_container"], "Should create viewport_container")
	assert_not_null(ui_refs["map_viewport"], "Should create map_viewport")
	assert_eq(ui_refs["viewport_container"].offset_top, 96, "Should have UI_MARGIN top offset")
	assert_eq(ui_refs["viewport_container"].offset_bottom, -96, "Should have UI_MARGIN bottom offset")

func test_creates_ui_elements():
	var builder = PlanetMapUIBuilder.new()
	var control = Control.new()
	autofree(control)
	add_child(control)

	var ui_refs = builder.build_ui(control)

	assert_not_null(ui_refs["back_button"], "Should create back button")
	assert_not_null(ui_refs["day_label"], "Should create day label")
	assert_not_null(ui_refs["planet_name_label"], "Should create planet name label")
	assert_not_null(ui_refs["ecosystem_section"], "Should create ecosystem section")
	assert_not_null(ui_refs["tile_info_section"], "Should create tile info section")
	assert_not_null(ui_refs["time_control_panel"], "Should create time control panel")

func test_creates_day_night_modulate():
	var builder = PlanetMapUIBuilder.new()
	var control = Control.new()
	autofree(control)
	add_child(control)

	var ui_refs = builder.build_ui(control)

	assert_not_null(ui_refs["day_night_modulate"], "Should create day/night CanvasModulate")
	assert_eq(ui_refs["day_night_modulate"].color, Color.WHITE, "Should start at full brightness")

func test_viewport_clear_mode_always():
	var builder = PlanetMapUIBuilder.new()
	var control = Control.new()
	autofree(control)
	add_child(control)

	var ui_refs = builder.build_ui(control)
	var viewport: SubViewport = ui_refs["map_viewport"]

	assert_eq(viewport.render_target_clear_mode, SubViewport.CLEAR_MODE_ALWAYS,
		"Viewport must use CLEAR_MODE_ALWAYS to prevent black flash on heavy frames")

func test_viewport_size_calculation():
	var builder = PlanetMapUIBuilder.new()
	var container = SubViewportContainer.new()
	autofree(container)
	container.size = Vector2(800, 600)

	var viewport_size = builder.calculate_viewport_size(container)

	assert_eq(viewport_size, Vector2i(800, 600), "Should match container size")

func test_create_card():
	var builder = PlanetMapUIBuilder.new()
	var card = builder.create_card()
	autofree(card)

	assert_not_null(card, "Should create card")
	assert_true(card is Panel, "Should be a Panel")
	assert_eq(card.size_flags_horizontal, Control.SIZE_EXPAND_FILL, "Should expand fill")

func test_make_panel_label():
	var builder = PlanetMapUIBuilder.new()
	var label = builder.make_panel_label("Test Label", 14, Color.RED)
	autofree(label)

	assert_not_null(label, "Should create label")
	assert_eq(label.text, "Test Label", "Should have correct text")
