extends "res://tests/test_node_base.gd"
## Tests for Sandbox CLI API and programmatic scenario loading

var sandbox: Sandbox = null

func before_each():
	# Create sandbox instance
	var sandbox_scene = load("res://scenes/Sandbox.tscn")
	sandbox = sandbox_scene.instantiate()
	add_child(sandbox)
	autofree(sandbox)

	# Wait for sandbox to be ready
	await wait_frames(5)

func test_get_available_scenarios():
	var scenarios = Sandbox.get_available_scenarios()

	assert_not_null(scenarios, "Should return scenario list")
	assert_gt(scenarios.size(), 0, "Should have at least one scenario")

	# Check expected scenarios are present
	assert_true(scenarios.has("tropical"), "Should include tropical scenario")
	assert_true(scenarios.has("earthlike"), "Should include earthlike scenario")
	assert_true(scenarios.has("frozen"), "Should include frozen scenario")

func test_get_scenario_config():
	var config = sandbox.get_scenario_config()

	assert_not_null(config, "Should return config dictionary")
	assert_has(config, "planet_type", "Should have planet_type")
	assert_has(config, "water", "Should have water")
	assert_has(config, "seed", "Should have seed")

func test_set_scenario_config():
	var test_config = {
		"planet_type": 2,
		"geological_activity": 1,
		"climate": 2,
		"atmosphere": 2,
		"water": 50,
		"ice": 10,
		"lava": 5,
		"seed": 12345
	}

	sandbox.set_scenario_config(test_config)
	await wait_frames(5)  # Wait for generation

	var current_config = sandbox.get_scenario_config()
	assert_eq(current_config.planet_type, 2, "Planet type should be set")
	assert_eq(current_config.water, 50, "Water should be set")
	assert_eq(current_config.seed, 12345, "Seed should be set")

func test_load_scenario_tropical():
	var success = sandbox.load_scenario("tropical")
	assert_true(success, "Should successfully load tropical scenario")

	await wait_frames(5)  # Wait for generation

	var config = sandbox.get_scenario_config()
	assert_eq(config.water, 65, "Tropical should have 65% water")
	assert_eq(config.climate, 3, "Tropical should have hot climate (3)")

func test_load_scenario_frozen():
	var success = sandbox.load_scenario("frozen")
	assert_true(success, "Should successfully load frozen scenario")

	await wait_frames(5)

	var config = sandbox.get_scenario_config()
	assert_eq(config.ice, 80, "Frozen should have 80% ice")
	assert_eq(config.climate, 0, "Frozen should have frozen climate (0)")

func test_load_scenario_invalid():
	var success = sandbox.load_scenario("nonexistent_scenario")
	assert_false(success, "Should fail for invalid scenario")

func test_export_state():
	sandbox.load_scenario("earthlike")
	await wait_frames(5)

	var state = sandbox.export_state()

	assert_not_null(state, "Should return state dictionary")
	assert_has(state, "config", "Should have config")
	assert_has(state, "timestamp", "Should have timestamp")
	assert_has(state, "statistics", "Should have statistics")
	assert_has(state, "map_size", "Should have map_size")

func test_export_state_statistics():
	sandbox.load_scenario("ocean")
	await wait_frames(5)

	var state = sandbox.export_state()
	var stats = state.statistics

	assert_has(stats, "total_tiles", "Should have total_tiles")
	assert_has(stats, "tiles_by_type", "Should have tiles_by_type")
	assert_has(stats, "unique_types", "Should have unique_types")
	assert_gt(stats.total_tiles, 0, "Should have generated tiles")

func test_scenario_consistency():
	# Load same scenario twice with same seed - should get same results
	sandbox.load_scenario("desert")
	await wait_frames(5)

	var state1 = sandbox.export_state()
	var stats1 = state1.statistics

	# Load again
	sandbox.load_scenario("desert")
	await wait_frames(5)

	var state2 = sandbox.export_state()
	var stats2 = state2.statistics

	# Same seed should produce same tile count
	assert_eq(stats1.total_tiles, stats2.total_tiles, "Same scenario should produce consistent tile count")
	assert_eq(stats1.unique_types, stats2.unique_types, "Same scenario should produce consistent type variety")
