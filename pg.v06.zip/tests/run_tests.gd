extends SceneTree
## Lightweight test runner that leverages GUT's assertion infrastructure
## Run with: godot --headless -s tests/run_tests.gd

const TEST_SCRIPTS = [
	"res://tests/core/test_game_logger.gd",
	"res://tests/core/test_game_services.gd",
	"res://tests/core/test_time_manager.gd",
	"res://tests/core/test_foundation.gd",
	"res://tests/models/test_habitable_zone.gd",
	"res://tests/systems/test_map_tile.gd",
	"res://tests/systems/test_probe_system.gd",
	"res://tests/systems/test_planet_rotation.gd",
	"res://tests/systems/planet_map/test_planet_map_coordinates.gd",
	"res://tests/systems/planet_map/test_planet_map_tile_config.gd",
	"res://tests/systems/planet_map/test_planet_map_generator.gd",
	"res://tests/systems/planet_map/test_terrain_region_selector.gd",
	"res://tests/systems/planet_map/test_planet_map_cache.gd",
	"res://tests/systems/planet_map/test_habitable_planet_maps.gd",
	"res://tests/systems/planet_map/test_planet_map_system_ecosystem.gd",
	"res://tests/systems/planet_map/test_coordinate_system.gd",
	"res://tests/systems/planet_map/test_planet_map_data.gd",
	"res://tests/systems/planet_map/test_chunk_tile_data.gd",
	"res://tests/systems/planet_map/test_procedural_terrain_source.gd",
	"res://tests/systems/planet_map/test_png_terrain_source.gd",
	"res://tests/systems/planet_map/test_chunk_tilemap_group.gd",
	"res://tests/systems/planet_map/test_chunk_visibility_manager.gd",
	"res://tests/systems/life/test_chunk_manager.gd",
	"res://tests/systems/planet_map/test_variant_manager.gd",
	"res://tests/ui/test_dialogue_data.gd",
	"res://tests/narrative/test_intro_sequence_manager.gd",
	"res://tests/narrative/test_intro_sequence_scene.gd",
	"res://tests/ui/base/test_anchor_layout_helper.gd",
	"res://tests/ui/base/test_z_index_layers.gd",
	"res://tests/ui/planet_map/test_planet_map_ui_builder.gd",
	"res://tests/ui/planet_map/test_planet_map_info_panels.gd",
	"res://tests/ui/planet_map/test_planet_map_day_night.gd",
	"res://tests/ui/test_sandbox_cli_api.gd",
	"res://tests/system_generation/test_system_generation_manager.gd",
	"res://tests/systems/life/test_tree_instance.gd",
	"res://tests/systems/life/test_ecosystem_manager.gd",
	"res://tests/systems/life/test_full_lifecycle.gd",
	"res://tests/systems/life/test_plant_species.gd",
	"res://tests/systems/life/test_tree_removal.gd",
	"res://tests/sandbox/test_sandbox_foundation.gd",
	"res://tests/sandbox/test_sandbox_scenario_manager.gd",
	"res://tests/sandbox/test_sandbox_planet_generator.gd",
	"res://tests/sandbox/test_sandbox_visual_feedback.gd",
	"res://tests/player/test_player_stats.gd",
	"res://tests/dialogue/test_dialogue_choice.gd",
	"res://tests/ui/dialogue/test_conversation.gd",
	"res://tests/minigames/test_matching_board.gd",
	"res://tests/minigames/test_baseball_timing.gd",
	"res://tests/simulation/test_settlement_site.gd",
	"res://tests/simulation/test_dynamic_longhouses.gd",
	"res://tests/simulation/test_village_relocation.gd",
	"res://tests/simulation/test_site_regrowth.gd",
	"res://tests/simulation/test_village_split.gd",
	"res://tests/simulation/test_band_simulation.gd",
	"res://tests/systems/planet_map/test_berry_regrowth.gd",
	"res://tests/simulation/test_skill_efficiency.gd",
	"res://tests/systems/test_resource_gathering.gd",
	"res://tests/systems/test_world_scenario_manager.gd",
	"res://tests/core/test_exploration_session_sectors.gd",
	"res://tests/core/test_save_game_manager.gd",
	"res://tests/core/test_exploration_session_save_time.gd",
	"res://tests/core/test_save_game_manager_multi_slot.gd",
	"res://tests/ui/test_save_list_dialog.gd",
	"res://tests/ui/planet_map/test_village_overview_ui.gd",
	"res://tests/systems/test_village_resource_memory.gd",
	"res://tests/test_terrain_pathfinder.gd",
	"res://tests/test_village_path_cache.gd",
	"res://tests/simulation/test_village_serialization.gd",
	"res://tests/simulation/test_village_demographics.gd",
	"res://tests/simulation/test_population_equilibrium.gd",
	"res://tests/simulation/test_village_migration.gd",
	"res://tests/systems/test_harvester_persistence.gd",
]

var _passed := 0
var _failed := 0
var _total_start: int

func _initialize():
	print("")
	print("=" .repeat(60))
	print("  GUT Test Runner - PlanetGame")
	print("=" .repeat(60))
	_total_start = Time.get_ticks_msec()

	for script_path in TEST_SCRIPTS:
		await _run_test_script(script_path)

	# Wait for all final cleanup to complete
	await process_frame

	_print_summary()
	quit(0 if _failed == 0 else 1)

func _run_test_script(script_path: String):
	var script = load(script_path)
	if script == null or not (script is GDScript):
		print("  [ERROR] Failed to load or not a GDScript: %s" % script_path)
		_failed += 1
		return

	var suite = script.new()

	# Add Node-based tests to scene tree
	if suite is Node:
		root.add_child(suite)
		await process_frame  # Wait one frame for _ready() to complete

	var suite_name = script_path.get_file().replace("test_", "").replace(".gd", "")
	print("")
	print("  %s" % suite_name)
	print("  " + "-".repeat(40))

	# Get all test methods
	var methods = []
	for method in suite.get_method_list():
		if method.name.begins_with("test_"):
			methods.append(method.name)

	for method_name in methods:
		var test_start = Time.get_ticks_msec()

		# Reset state before each test
		if suite.has_method("before_each"):
			# Call and await - if it's async, this will wait; if not, it returns immediately
			@warning_ignore("redundant_await")
			await suite.before_each()

		# Run the test
		var error_text = ""
		var success = true
		# Call and await - if it's async, this will wait; if not, it returns immediately
		@warning_ignore("redundant_await")
		await suite.call(method_name)

		# Check GUT assertion state
		if suite.has_method("get_fail_count"):
			if suite.get_fail_count() > 0:
				success = false
				error_text = "Assertion failed"
			suite._fail_count = 0  # Reset for next test

		# Clean up after each test (prevents test pollution)
		if suite.has_method("after_each"):
			# Call and await - if it's async, this will wait; if not, it returns immediately
			@warning_ignore("redundant_await")
			await suite.after_each()
			# Wait one frame for queue_free() to actually free nodes
			await process_frame

		var elapsed = Time.get_ticks_msec() - test_start
		if success:
			_passed += 1
			print("    [PASS] %s (%dms)" % [method_name, elapsed])
		else:
			_failed += 1
			print("    [FAIL] %s - %s (%dms)" % [method_name, error_text, elapsed])

	# Cleanup
	if suite.has_method("after_all"):
		suite.after_all()
	if suite is Node:
		suite.queue_free()
		# Wait for nodes to actually be freed
		await process_frame

func _print_summary():
	var total_elapsed = Time.get_ticks_msec() - _total_start
	var total = _passed + _failed
	print("")
	print("=" .repeat(60))
	if _failed == 0:
		print("  All %d tests passed (%dms)" % [total, total_elapsed])
	else:
		print("  %d of %d tests failed (%dms)" % [_failed, total, total_elapsed])
	print("=" .repeat(60))
	print("")
