extends "res://tests/test_base.gd"

## Tests for SandboxPlanetGenerator component
## Verifies planet generation orchestration and elevation map generation

var generator: SandboxPlanetGenerator

func before_each():
	generator = SandboxPlanetGenerator.new()

func test_generate_elevation_map_flat():
	var elevation_map = generator.generate_elevation_map(
		10, 10,
		SandboxPlanetGenerator.ElevationPattern.FLAT,
		7,
		12345
	)

	assert_eq(elevation_map.size(), 100, "Should generate 10x10 = 100 cells")

	# All should be elevation 0 for FLAT pattern
	for cell in elevation_map.keys():
		assert_eq(elevation_map[cell], 0, "FLAT pattern should have elevation 0")

func test_generate_elevation_map_random():
	var elevation_map = generator.generate_elevation_map(
		5, 5,
		SandboxPlanetGenerator.ElevationPattern.RANDOM,
		7,
		12345
	)

	assert_eq(elevation_map.size(), 25, "Should generate 5x5 = 25 cells")

	# Should have varied elevations
	var found_different = false
	var first_elevation = elevation_map[Vector2i(0, 0)]
	for cell in elevation_map.keys():
		if elevation_map[cell] != first_elevation:
			found_different = true
			break

	assert_true(found_different, "RANDOM pattern should have varied elevations")

func test_generate_elevation_map_respects_max_height():
	var elevation_map = generator.generate_elevation_map(
		20, 20,
		SandboxPlanetGenerator.ElevationPattern.RANDOM,
		5,  # max_height = 5
		12345
	)

	# All elevations should be <= 5
	for cell in elevation_map.keys():
		assert_lte(float(elevation_map[cell]), 5.0, "Elevation should not exceed max_height")
		assert_gte(float(elevation_map[cell]), 0.0, "Elevation should not be negative")

func test_create_mock_planet():
	var planet = generator.create_mock_planet(
		PlanetEnums.PlanetType.ROCKY_MEDIUM,
		PlanetEnums.AtmosphereType.MODERATE
	)

	assert_not_null(planet, "Should create a planet")
	assert_eq(planet.planet_type, PlanetEnums.PlanetType.ROCKY_MEDIUM, "Should have correct type")
	assert_eq(planet.habitability_score, 0.8, "Earth-like planet should have high habitability")

func test_create_mock_planet_low_habitability():
	var planet = generator.create_mock_planet(
		PlanetEnums.PlanetType.GAS_GIANT,
		PlanetEnums.AtmosphereType.NONE
	)

	assert_not_null(planet, "Should create a planet")
	assert_eq(planet.habitability_score, 0.5, "Non-Earth-like should have default habitability")

func test_generate_surface_composition_rocky():
	var composition = generator.generate_surface_composition(
		PlanetEnums.PlanetType.ROCKY_MEDIUM,
		0.3,  # water_pct
		0.1   # ice_pct
	)

	assert_true(composition.has("rock"), "Should have rock")
	assert_true(composition.has("water"), "Should have water")
	assert_true(composition.has("ice"), "Should have ice")
	assert_eq(composition.water, 0.3, "Should have correct water percentage")
	assert_eq(composition.ice, 0.1, "Should have correct ice percentage")
	assert_eq(composition.rock, 0.6, "Should calculate rock as remainder")

func test_generate_surface_composition_gas_giant():
	var composition = generator.generate_surface_composition(
		PlanetEnums.PlanetType.GAS_GIANT,
		0.0,  # water_pct (ignored for gas giants)
		0.0   # ice_pct (ignored for gas giants)
	)

	assert_true(composition.has("gas"), "Should have gas")
	assert_eq(composition.gas, 1.0, "Gas giants should be 100% gas")

func test_calculate_temperature_from_climate():
	assert_eq(generator.calculate_temperature_from_climate("FROZEN"), 150.0, "Frozen should be 150K")
	assert_eq(generator.calculate_temperature_from_climate("COLD"), 240.0, "Cold should be 240K")
	assert_eq(generator.calculate_temperature_from_climate("TEMPERATE"), 288.0, "Temperate should be 288K")
	assert_eq(generator.calculate_temperature_from_climate("HOT"), 350.0, "Hot should be 350K")
	assert_eq(generator.calculate_temperature_from_climate("SCORCHING"), 500.0, "Scorching should be 500K")

func test_calculate_tectonic_plates():
	assert_eq(generator.calculate_tectonic_plates("DEAD"), 0, "Dead should have 0 plates")

	var low_plates = generator.calculate_tectonic_plates("LOW")
	assert_gte(float(low_plates), 0.0, "Low activity should have >= 0 plates")
	assert_lte(float(low_plates), 3.0, "Low activity should have <= 3 plates")

	var moderate_plates = generator.calculate_tectonic_plates("MODERATE")
	assert_gte(float(moderate_plates), 3.0, "Moderate should have >= 3 plates")
	assert_lte(float(moderate_plates), 12.0, "Moderate should have <= 12 plates")

func test_get_atmosphere_composition():
	var comp = generator.get_atmosphere_composition(PlanetEnums.AtmosphereType.MODERATE)

	assert_not_null(comp, "Should return composition")
	# Should be a dictionary with gas percentages
	assert_true(comp is Dictionary, "Should be a dictionary")

func test_generate_planet_map():
	var tiles = generator.generate_planet_map(
		PlanetEnums.PlanetType.ROCKY_MEDIUM,  # planet_type
		PlanetEnums.AtmosphereType.MODERATE,      # atmosphere_type
		0.5,   # water_pct
		0.1,   # ice_pct
		0.0,   # lava_pct
		2,     # geological_activity_idx (MODERATE)
		2,     # climate_idx (TEMPERATE)
		12345  # seed
	)

	assert_not_null(tiles, "Should return tiles array")
	assert_gt(float(tiles.size()), 0.0, "Should generate tiles")

	# Verify it's a 2D array
	if tiles.size() > 0:
		assert_true(tiles[0] is Array, "Should be 2D array")

func test_generate_planet_map_different_seeds():
	# Same parameters but different seeds should produce different maps
	var tiles1 = generator.generate_planet_map(
		PlanetEnums.PlanetType.ROCKY_MEDIUM,
		PlanetEnums.AtmosphereType.MODERATE,
		0.5, 0.1, 0.0, 2, 2, 11111
	)

	var tiles2 = generator.generate_planet_map(
		PlanetEnums.PlanetType.ROCKY_MEDIUM,
		PlanetEnums.AtmosphereType.MODERATE,
		0.5, 0.1, 0.0, 2, 2, 99999
	)

	# Both should generate successfully
	assert_gt(float(tiles1.size()), 0.0, "First generation should succeed")
	assert_gt(float(tiles2.size()), 0.0, "Second generation should succeed")

	# Maps should be same size
	assert_eq(tiles1.size(), tiles2.size(), "Maps should be same size")
