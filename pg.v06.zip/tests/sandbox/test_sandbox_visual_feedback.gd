extends "res://tests/test_node_base.gd"

## Tests for SandboxVisualFeedback component
## Verifies creation of visual feedback elements (indicators, sprites, overlays)

var feedback: SandboxVisualFeedback

func before_each():
	feedback = SandboxVisualFeedback.new()

func test_create_layer_indicator():
	var parent = Control.new()
	autofree(parent)
	add_child(parent)

	var indicator = feedback.create_layer_indicator(parent)

	assert_not_null(indicator, "Should create indicator")
	assert_true(indicator is Label, "Should be a Label")
	assert_eq(indicator.get_parent(), parent, "Should be added to parent")
	assert_eq(indicator.z_index, 2000, "Should have high z-index")

func test_create_preview_sprite():
	var parent = Node2D.new()
	autofree(parent)
	add_child(parent)

	var sprite = feedback.create_preview_sprite(parent)

	assert_not_null(sprite, "Should create sprite")
	assert_true(sprite is Sprite2D, "Should be a Sprite2D")
	assert_eq(sprite.get_parent(), parent, "Should be added to parent")
	assert_false(sprite.visible, "Should start invisible")
	assert_eq(sprite.modulate.a, 0.5, "Should be semi-transparent")

func test_create_tile_inspector():
	var parent = Control.new()
	autofree(parent)
	add_child(parent)

	var inspector = feedback.create_tile_inspector(parent)

	assert_not_null(inspector, "Should create inspector")
	assert_true(inspector is PanelContainer, "Should be a PanelContainer")
	assert_eq(inspector.get_parent(), parent, "Should be added to parent")
	assert_false(inspector.visible, "Should start invisible")
	assert_eq(inspector.z_index, 3000, "Should have high z-index")

func test_create_hover_highlight():
	var parent = Node2D.new()
	autofree(parent)
	add_child(parent)

	var highlight = feedback.create_hover_highlight(parent)

	assert_not_null(highlight, "Should create highlight")
	assert_true(highlight is Polygon2D, "Should be a Polygon2D")
	assert_eq(highlight.get_parent(), parent, "Should be added to parent")
	assert_false(highlight.visible, "Should start invisible")
	assert_eq(highlight.z_index, 4000, "Should have very high z-index")

func test_update_layer_indicator():
	var parent = Control.new()
	autofree(parent)
	add_child(parent)

	var indicator = feedback.create_layer_indicator(parent)

	var tile_types = {
		Vector3i(0, 0, 0): 10,
		Vector3i(1, 0, 0): 10,
		Vector3i(2, 0, 0): 10
	}

	feedback.update_layer_indicator(
		0,  # current_layer
		tile_types,
		10, # map_columns
		10, # map_rows
		SandboxVisualFeedback.ToolMode.PLACE
	)

	assert_true(indicator.text.contains("Layer 0"), "Should show layer number")
	assert_true(indicator.text.contains("3 tiles"), "Should show tile count")
	assert_true(indicator.text.contains("PLACE"), "Should show tool mode")

func test_update_layer_indicator_different_tool():
	var parent = Control.new()
	autofree(parent)
	add_child(parent)

	var indicator = feedback.create_layer_indicator(parent)

	feedback.update_layer_indicator(
		2,  # current_layer
		{},
		10, 10,
		SandboxVisualFeedback.ToolMode.BRUSH
	)

	assert_true(indicator.text.contains("Layer 2"), "Should show correct layer")
	assert_true(indicator.text.contains("BRUSH"), "Should show BRUSH tool")

func test_cleanup():
	var parent_ctrl = Control.new()
	var parent_2d = Node2D.new()
	autofree(parent_ctrl)
	autofree(parent_2d)
	add_child(parent_ctrl)
	add_child(parent_2d)

	var indicator = feedback.create_layer_indicator(parent_ctrl)
	var sprite = feedback.create_preview_sprite(parent_2d)

	await wait_frames(1)

	# Elements should exist
	assert_not_null(feedback.layer_indicator_label, "Should have indicator reference")
	assert_not_null(feedback.preview_sprite, "Should have sprite reference")

	# Cleanup
	feedback.cleanup()

	await wait_frames(1)

	# References should be cleared
	assert_null(feedback.layer_indicator_label, "Should clear indicator reference")
	assert_null(feedback.preview_sprite, "Should clear sprite reference")

func test_clear_debug_overlay():
	# Create a mock debug overlay
	var parent = Node2D.new()
	autofree(parent)
	add_child(parent)

	feedback.debug_overlay = Node2D.new()
	parent.add_child(feedback.debug_overlay)

	await wait_frames(1)

	assert_not_null(feedback.debug_overlay, "Should have debug overlay")

	feedback.clear_debug_overlay()

	await wait_frames(1)

	assert_null(feedback.debug_overlay, "Should clear debug overlay")
