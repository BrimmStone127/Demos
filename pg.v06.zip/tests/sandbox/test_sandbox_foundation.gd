extends "res://tests/test_base.gd"

# Tests for sandbox foundation classes

var sandbox_core: SandboxCore

func before_each():
	sandbox_core = SandboxCore.new()

func test_sandbox_config_tile_categories():
	"""Test that tile categories are correctly mapped."""
	const TT = PlanetMapTileConfig.TileType

	# Test FLIR category
	assert_eq(
		SandboxConfig.get_tile_category(TT.FLIR_0),
		SandboxConfig.TileCategory.FLIR,
		"FLIR_0 should be in FLIR category"
	)

	# Test Water category
	assert_eq(
		SandboxConfig.get_tile_category(TT.FRESH_WATER),
		SandboxConfig.TileCategory.WATER,
		"FRESH_WATER should be in WATER category"
	)

	# Test Vegetation category
	assert_eq(
		SandboxConfig.get_tile_category(TT.GRASS_0),
		SandboxConfig.TileCategory.VEGETATION,
		"GRASS_0 should be in VEGETATION category"
	)

	# Test Surface Features category
	assert_eq(
		SandboxConfig.get_tile_category(TT.SF_TREE_1),
		SandboxConfig.TileCategory.SURFACE_FEATURES,
		"SF_TREE_1 should be in SURFACE_FEATURES category"
	)

	# Test Slopes category
	assert_eq(
		SandboxConfig.get_tile_category(TT.SLOPE_2TILE_LEFT_LOWER),
		SandboxConfig.TileCategory.SLOPES,
		"SLOPE_2TILE_LEFT_LOWER should be in SLOPES category"
	)

func test_sandbox_config_get_tile_name():
	"""Test that tile names are correctly retrieved."""
	const TT = PlanetMapTileConfig.TileType

	assert_eq(
		SandboxConfig.get_tile_name(TT.GRASS_0),
		"GRASS_0",
		"Should return correct enum name for GRASS_0"
	)

	assert_eq(
		SandboxConfig.get_tile_name(TT.SF_TREE_1),
		"SF_TREE_1",
		"Should return correct enum name for SF_TREE_1"
	)

func test_sandbox_core_tile_selection():
	"""Test tile selection in SandboxCore."""
	const TT = PlanetMapTileConfig.TileType

	# Initially empty
	assert_eq(sandbox_core.selected_tile_types.size(), 0, "Should start with no selections")

	# Add a tile
	sandbox_core.add_selected_tile(TT.GRASS_0)
	assert_eq(sandbox_core.selected_tile_types.size(), 1, "Should have 1 selection")
	assert_true(TT.GRASS_0 in sandbox_core.selected_tile_types, "GRASS_0 should be selected")

	# Add another tile
	sandbox_core.add_selected_tile(TT.SF_TREE_1)
	assert_eq(sandbox_core.selected_tile_types.size(), 2, "Should have 2 selections")

	# Remove a tile
	sandbox_core.remove_selected_tile(TT.GRASS_0)
	assert_eq(sandbox_core.selected_tile_types.size(), 1, "Should have 1 selection after removal")
	assert_false(TT.GRASS_0 in sandbox_core.selected_tile_types, "GRASS_0 should be removed")

	# Clear all
	sandbox_core.clear_selected_tiles()
	assert_eq(sandbox_core.selected_tile_types.size(), 0, "Should have no selections after clear")

func test_sandbox_core_tool_mode():
	"""Test tool mode in SandboxCore."""
	# Default should be PLACE
	assert_eq(
		sandbox_core.current_tool_mode,
		SandboxConfig.ToolMode.PLACE,
		"Should default to PLACE mode"
	)

	# Change mode
	sandbox_core.set_tool_mode(SandboxConfig.ToolMode.ERASE)
	assert_eq(
		sandbox_core.current_tool_mode,
		SandboxConfig.ToolMode.ERASE,
		"Should change to ERASE mode"
	)

func test_sandbox_core_layer_management():
	"""Test elevation layer management."""
	# Default layer is 0
	assert_eq(sandbox_core.current_layer, 0, "Should start at layer 0")

	# Increment layer
	sandbox_core.increment_layer()
	assert_eq(sandbox_core.current_layer, 1, "Should increment to layer 1")

	# Decrement layer
	sandbox_core.decrement_layer()
	assert_eq(sandbox_core.current_layer, 0, "Should decrement back to layer 0")

	# Can't go below 0
	sandbox_core.decrement_layer()
	assert_eq(sandbox_core.current_layer, 0, "Should clamp at layer 0")

	# Can't go above MAX_LAYERS - 1
	sandbox_core.set_current_layer(10)
	assert_eq(sandbox_core.current_layer, 7, "Should clamp at layer 7 (MAX_LAYERS - 1)")

func test_sandbox_core_random_tile_selection():
	"""Test getting a random selected tile."""
	const TT = PlanetMapTileConfig.TileType

	# When nothing is selected, should return GRASS_0 as default
	var tile = sandbox_core.get_random_selected_tile()
	assert_eq(tile, TT.GRASS_0, "Should return GRASS_0 when no tiles selected")

	# When tiles are selected, should return one of them
	sandbox_core.add_selected_tile(TT.SF_TREE_1)
	sandbox_core.add_selected_tile(TT.SF_TREE_2)
	tile = sandbox_core.get_random_selected_tile()
	assert_true(
		tile in [TT.SF_TREE_1, TT.SF_TREE_2],
		"Should return one of the selected tiles"
	)

func test_sandbox_core_map_initialization():
	"""Test empty map initialization."""
	sandbox_core.initialize_empty_map()

	# Should create tiles for the default map size
	var expected_tile_count = SandboxConfig.DEFAULT_MAP_COLUMNS * SandboxConfig.DEFAULT_MAP_ROWS
	assert_eq(
		sandbox_core.current_map_tiles.size(),
		expected_tile_count,
		"Should create correct number of tiles"
	)

	# Check a few tiles
	var tile = sandbox_core.get_tile_at(Vector2i(0, 0))
	assert_not_null(tile, "Tile at (0,0) should exist")
	assert_eq(tile.type, PlanetMapTileConfig.TileType.GRASS_0, "Tiles should be GRASS_0")
	assert_eq(tile.elevation, 0, "Tiles should have elevation 0")
