extends "res://tests/test_base.gd"

## Tests for SandboxScenarioManager component
## Verifies scenario loading, config management, and state export

var manager: SandboxScenarioManager

func before_each():
	manager = SandboxScenarioManager.new()

func test_get_available_scenarios():
	var scenarios = SandboxScenarioManager.get_available_scenarios()

	assert_gt(float(scenarios.size()), 0.0, "Should have available scenarios")
	assert_true("tropical" in scenarios, "Should include 'tropical' scenario")
	assert_true("frozen" in scenarios, "Should include 'frozen' scenario")
	assert_true("earthlike" in scenarios, "Should include 'earthlike' scenario")

func test_load_scenario_success():
	var config = manager.load_scenario("tropical")

	assert_false(config.is_empty(), "Should return non-empty config")
	assert_true(config.has("planet_type"), "Should have planet_type")
	assert_true(config.has("water"), "Should have water percentage")
	assert_true(config.has("seed"), "Should have seed")

func test_load_scenario_unknown():
	var config = manager.load_scenario("nonexistent")

	assert_true(config.is_empty(), "Should return empty config for unknown scenario")

func test_tropical_scenario_values():
	var config = manager.load_scenario("tropical")

	assert_eq(config.planet_type, 2, "Tropical should be Super Earth")
	assert_eq(config.water, 65, "Tropical should have 65% water")
	assert_eq(config.ice, 0, "Tropical should have 0% ice")
	assert_eq(config.climate, 3, "Tropical should have hot climate")

func test_frozen_scenario_values():
	var config = manager.load_scenario("frozen")

	assert_eq(config.ice, 80, "Frozen should have 80% ice")
	assert_eq(config.climate, 0, "Frozen should have frozen climate")
	assert_eq(config.water, 5, "Frozen should have minimal water")

func test_earthlike_scenario_values():
	var config = manager.load_scenario("earthlike")

	assert_eq(config.water, 71, "Earth-like should have 71% water")
	assert_eq(config.climate, 2, "Earth-like should have temperate climate")
	assert_eq(config.geological_activity, 2, "Earth-like should have moderate activity")

func test_apply_scenario_config():
	# Create mock UI refs
	var planet_type_opt = OptionButton.new()
	planet_type_opt.add_item("Type 0")
	planet_type_opt.add_item("Type 1")
	planet_type_opt.add_item("Type 2")
	
	var geological_activity_opt = OptionButton.new()
	geological_activity_opt.add_item("Act 0")
	geological_activity_opt.add_item("Act 1")
	geological_activity_opt.add_item("Act 2")
	
	var climate_type_opt = OptionButton.new()
	climate_type_opt.add_item("Cli 0")
	
	var atmosphere_type_opt = OptionButton.new()
	atmosphere_type_opt.add_item("Atmo 0")

	var water_slider = HSlider.new()
	water_slider.max_value = 100

	var ui_refs = {
		"planet_type_option": planet_type_opt,
		"geological_activity_option": geological_activity_opt,
		"climate_type_option": climate_type_opt,
		"atmosphere_type_option": atmosphere_type_opt,
		"water_slider": water_slider,
		"ice_slider": HSlider.new(),
		"lava_slider": HSlider.new(),
		"planet_seed_spin": SpinBox.new()
	}

	var config = {"planet_type": 2, "water": 65}
	var success = manager.apply_scenario_config(config, ui_refs)

	assert_true(success, "Should successfully apply config")
	assert_eq(planet_type_opt.selected, 2, "Should set planet type")
	assert_eq(water_slider.value, 65.0, "Should set water value")

func test_get_scenario_config():
	# Create mock UI refs with values
	var planet_type_opt = OptionButton.new()
	planet_type_opt.add_item("Type 1")
	planet_type_opt.add_item("Type 2")
	planet_type_opt.selected = 1

	var ui_refs = {
		"planet_type_option": planet_type_opt,
		"geological_activity_option": OptionButton.new(),
		"climate_type_option": OptionButton.new(),
		"atmosphere_type_option": OptionButton.new(),
		"water_slider": HSlider.new(),
		"ice_slider": HSlider.new(),
		"lava_slider": HSlider.new(),
		"planet_seed_spin": SpinBox.new()
	}
	ui_refs.water_slider.value = 50

	var config = manager.get_scenario_config(ui_refs)

	assert_eq(config.planet_type, 1, "Should get planet type from UI")
	assert_eq(config.water, 50, "Should get water value from UI")

func test_collect_tile_statistics_empty():
	var stats = manager.collect_tile_statistics({})

	assert_eq(stats.total_tiles, 0, "Should have 0 tiles")
	assert_eq(stats.unique_types, 0, "Should have 0 unique types")
	assert_eq(stats.layers_used, 0, "Should have 0 layers used")

func test_collect_tile_statistics():
	var tile_types = {
		Vector3i(0, 0, 0): 10,  # GRASS_0 at layer 0
		Vector3i(1, 0, 0): 10,  # GRASS_0 at layer 0
		Vector3i(0, 1, 0): 20,  # Different type at layer 0
		Vector3i(0, 0, 1): 10,  # GRASS_0 at layer 1
	}

	var stats = manager.collect_tile_statistics(tile_types)

	assert_eq(stats.total_tiles, 4, "Should count all tiles")
	assert_eq(stats.unique_types, 2, "Should find 2 unique types")
	assert_eq(stats.layers_used, 2, "Should find 2 layers used")
	assert_eq(stats.tiles_by_type[10], 3, "Should count 3 tiles of type 10")
	assert_eq(stats.tiles_by_type[20], 1, "Should count 1 tile of type 20")
	assert_eq(stats.tiles_by_layer[0], 3, "Should count 3 tiles on layer 0")
	assert_eq(stats.tiles_by_layer[1], 1, "Should count 1 tile on layer 1")

func test_export_state():
	var ui_refs = {
		"planet_type_option": OptionButton.new(),
		"geological_activity_option": OptionButton.new(),
		"climate_type_option": OptionButton.new(),
		"atmosphere_type_option": OptionButton.new(),
		"water_slider": HSlider.new(),
		"ice_slider": HSlider.new(),
		"lava_slider": HSlider.new(),
		"planet_seed_spin": SpinBox.new()
	}

	var tile_types = {Vector3i(0, 0, 0): 10}

	var state = manager.export_state(ui_refs, tile_types, 64, 64)

	assert_true(state.has("config"), "Should have config")
	assert_true(state.has("timestamp"), "Should have timestamp")
	assert_true(state.has("statistics"), "Should have statistics")
	assert_true(state.has("map_size"), "Should have map size")
	assert_eq(state.map_size.columns, 64, "Should export correct map columns")
	assert_eq(state.map_size.rows, 64, "Should export correct map rows")
