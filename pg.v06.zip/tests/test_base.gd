class_name TestBase
extends RefCounted
## Simple test base class providing assertion methods
## Tests should extend this class and implement test_* methods
##
## For UI tests that need to add_child() or access the scene tree,
## use TestNodeBase instead (res://tests/test_node_base.gd)

var _fail_count := 0
var _current_test := ""
var _autofree_nodes: Array[Node] = []

func get_fail_count() -> int:
	return _fail_count

# --- Lifecycle hooks ---

func before_each():
	pass

func after_each():
	# Clean up autofree nodes
	for node in _autofree_nodes:
		if is_instance_valid(node):
			node.queue_free()
	_autofree_nodes.clear()

func after_all():
	after_each()

# --- Utility ---

func autofree(node: Node) -> Node:
	_autofree_nodes.append(node)
	return node

## Wait for specified number of frames (for async tests)
## Note: Requires test to be added to scene tree
func wait_frames(count: int) -> void:
	# Find a node in the tree to await on
	var tree_node: Node = null
	for node in _autofree_nodes:
		if is_instance_valid(node) and node.is_inside_tree():
			tree_node = node
			break

	if tree_node == null:
		push_error("wait_frames() requires at least one node added via autofree() and add_child()")
		return

	for i in range(count):
		await tree_node.get_tree().process_frame

# --- Assertions ---

func assert_true(value: bool, msg: String = "") -> void:
	if not value:
		_fail("Expected true, got false", msg)

func assert_false(value: bool, msg: String = "") -> void:
	if value:
		_fail("Expected false, got true", msg)

func assert_eq(actual, expected, msg: String = "") -> void:
	if actual != expected:
		_fail("Expected '%s' but got '%s'" % [expected, actual], msg)

func assert_ne(actual, not_expected, msg: String = "") -> void:
	if actual == not_expected:
		_fail("Expected value to not equal '%s'" % [not_expected], msg)

func assert_null(value, msg: String = "") -> void:
	if value != null:
		_fail("Expected null, got '%s'" % [value], msg)

func assert_not_null(value, msg: String = "") -> void:
	if value == null:
		_fail("Expected non-null value", msg)

func assert_gt(actual: float, expected: float, msg: String = "") -> void:
	if actual <= expected:
		_fail("Expected %s > %s" % [actual, expected], msg)

func assert_gte(actual: float, expected: float, msg: String = "") -> void:
	if actual < expected:
		_fail("Expected %s >= %s" % [actual, expected], msg)

func assert_lt(actual: float, expected: float, msg: String = "") -> void:
	if actual >= expected:
		_fail("Expected %s < %s" % [actual, expected], msg)

func assert_lte(actual: float, expected: float, msg: String = "") -> void:
	if actual > expected:
		_fail("Expected %s <= %s" % [actual, expected], msg)

func assert_almost_eq(actual: float, expected: float, tolerance: float, msg: String = "") -> void:
	if abs(actual - expected) > tolerance:
		_fail("Expected %s ≈ %s (±%s)" % [actual, expected, tolerance], msg)

func assert_has(collection, key, msg: String = "") -> void:
	var has_key = false
	if collection is Dictionary:
		has_key = collection.has(key)
	elif collection is Array or collection is PackedStringArray:
		has_key = collection.has(key)
	if not has_key:
		_fail("Expected collection to contain '%s'" % [key], msg)

func assert_does_not_have(collection, key, msg: String = "") -> void:
	var has_key = false
	if collection is Dictionary:
		has_key = collection.has(key)
	elif collection is Array or collection is PackedStringArray:
		has_key = collection.has(key)
	if has_key:
		_fail("Expected collection to NOT contain '%s'" % [key], msg)

func assert_string_contains(text: String, substring: String, msg: String = "") -> void:
	if not text.contains(substring):
		_fail("Expected '%s' to contain '%s'" % [text, substring], msg)

func assert_string_starts_with(text: String, prefix: String, msg: String = "") -> void:
	if not text.begins_with(prefix):
		_fail("Expected '%s' to start with '%s'" % [text, prefix], msg)

func _fail(reason: String, msg: String) -> void:
	_fail_count += 1
	var full_msg = reason
	if msg != "":
		full_msg = "%s: %s" % [msg, reason]
	push_error("      ASSERTION: %s" % full_msg)
