extends "res://tests/test_base.gd"

func _make_probe_system() -> ProbeSystem:
	return autofree(ProbeSystem.new())

func test_initial_resources():
	var ps = _make_probe_system()
	assert_eq(ps.player_resources, 1000)

func test_export_empty_data():
	var ps = _make_probe_system()
	var data = ps.export_data()
	assert_has(data, "discovered_systems")
	assert_has(data, "discovered_planets")
	assert_has(data, "player_resources")
	assert_eq(data.discovered_systems.size(), 0)
	assert_eq(data.discovered_planets.size(), 0)

func test_import_export_roundtrip():
	var ps = _make_probe_system()
	ps.discovered_planets["42:0"] = {
		"discovery_level": ProbeSystem.DiscoveryLevel.SURVEYED,
		"probes_completed": [ProbeSystem.ProbeType.PRIMITIVE_ORBITAL],
		"revealed_data": {"atmosphere_type": "THIN"},
		"planet_name": "TestPlanet"
	}
	ps.player_resources = 500
	var exported = ps.export_data()

	var ps2 = _make_probe_system()
	ps2.import_data(exported)
	assert_eq(ps2.player_resources, 500)
	assert_has(ps2.discovered_planets, "42:0")

func test_calculate_discovery_level_none():
	var ps = _make_probe_system()
	var level = ps._calculate_discovery_level([])
	assert_eq(level, ProbeSystem.DiscoveryLevel.BASIC)

func test_calculate_discovery_level_one():
	var ps = _make_probe_system()
	var level = ps._calculate_discovery_level([ProbeSystem.ProbeType.PRIMITIVE_ORBITAL])
	assert_eq(level, ProbeSystem.DiscoveryLevel.SURVEYED)

func test_calculate_discovery_level_multiple():
	var ps = _make_probe_system()
	var level = ps._calculate_discovery_level([0, 0])
	assert_eq(level, ProbeSystem.DiscoveryLevel.COMPREHENSIVE)

func test_has_discovery_data():
	var ps = _make_probe_system()
	ps.discovered_planets["100:2"] = {"discovery_level": 0}
	assert_true(ps.has_discovery_data(100, 2))
	assert_false(ps.has_discovery_data(100, 5))

func test_apply_saved_discovery_empty_id():
	var ps = _make_probe_system()
	var result = ps.apply_saved_discovery("", {"discovery_level": 1})
	assert_eq(result.size(), 0)

func test_apply_saved_discovery_normalizes():
	var ps = _make_probe_system()
	ps.discovered_planets["42:0"] = {"discovery_level": 1}
	ps.apply_saved_discovery("42:0", {})
	assert_has(ps.discovered_planets, "42:0")

func test_normalize_discovery_record():
	var ps = _make_probe_system()
	var raw = {
		"discovery_level": 99,
		"probes_completed": [0, 0, 0],
		"revealed_data": {"key": "value"}
	}
	var normalized = ps._normalize_discovery_record(raw)
	assert_eq(normalized.discovery_level, ProbeSystem.DiscoveryLevel.COMPREHENSIVE)
	assert_eq(normalized.probes_completed.size(), 1, "Probes should be deduplicated")

func test_get_system_discovery_data_filtering():
	var ps = _make_probe_system()
	ps.discovered_planets["100:0"] = {"discovery_level": 1, "planet_name": "A"}
	ps.discovered_planets["100:1"] = {"discovery_level": 2, "planet_name": "B"}
	ps.discovered_planets["200:0"] = {"discovery_level": 1, "planet_name": "C"}
	var data = ps.get_system_discovery_data(100)
	assert_eq(data.size(), 2)
	assert_does_not_have(data, "200:0")

func test_surface_map_cache_operations():
	var ps = _make_probe_system()
	ps.set_surface_map_cache("42:0", {"seed": 12345, "version": 3})
	var cache = ps.get_surface_map_cache("42:0")
	assert_eq(cache.get("seed"), 12345)
	ps.clear_surface_map_cache("42:0")
	cache = ps.get_surface_map_cache("42:0")
	assert_eq(cache.size(), 0)

func test_compute_surface_map_seed_deterministic():
	var ps = _make_probe_system()
	var seed1 = ps.compute_surface_map_seed("42:0")
	var seed2 = ps.compute_surface_map_seed("42:0")
	assert_eq(seed1, seed2)
	var seed3 = ps.compute_surface_map_seed("42:1")
	assert_ne(seed1, seed3)
