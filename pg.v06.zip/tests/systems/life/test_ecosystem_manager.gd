extends "res://tests/test_base.gd"

# Tests for EcosystemManager tree simulation and spreading

const GRASS_TYPE = PlanetMapTileConfig.TileType.GRASS_0
const TREE_SPECIES = MapleTreeTypes.TR_MAPL_VG_1  # Maple tree ID from MapleTreeTypes

func _make_manager() -> EcosystemManager:
	var mgr = EcosystemManager.new()
	# Disable random spawning for predictable test behavior
	mgr.enable_random_tree_spawning = false
	_autofree_nodes.append(mgr)
	return mgr

func _make_tile(type: PlanetMapTileConfig.TileType, pos: Vector2i = Vector2i(0, 0)) -> MapTile:
	var t = MapTile.new(pos, type)
	t.moisture_level = 0.5
	return t

func _make_simple_map(size: int = 10) -> Array:
	# Build a size x size map of GRASS_0 tiles
	var tiles = []
	tiles.resize(size)
	for x in range(size):
		tiles[x] = []
		tiles[x].resize(size)
		for y in range(size):
			tiles[x][y] = _make_tile(GRASS_TYPE, Vector2i(x, y))
	return tiles

func _make_mature_tree(pos: Vector2i) -> TreeInstance:
	var t = TreeInstance.new()
	t.position = pos
	t.species = TREE_SPECIES
	t.growth_stage = TreeInstance.GrowthStage.MATURE
	t.health = 1.0

	# Initialize with species config
	var registry = PlantSpeciesRegistry.get_instance()
	var config = registry.get_species_config(TREE_SPECIES)
	if config:
		t.initialize_with_config(config, 1.0)  # Temperate baseline
		# Set age to mature threshold
		if t._thresholds.size() >= 4:
			t.age_in_ticks = t._thresholds[3]

	return t

func test_register_planet_stores_trees():
	var mgr = _make_manager()
	var tree = _make_mature_tree(Vector2i(5, 5))
	var tiles = _make_simple_map()
	mgr.register_planet("planet_a", [tree], tiles, {})
	var stored = mgr.get_trees_for_planet("planet_a")
	assert_eq(stored.size(), 1)

func test_unregister_planet_removes_trees():
	var mgr = _make_manager()
	var tree = _make_mature_tree(Vector2i(5, 5))
	var tiles = _make_simple_map()
	mgr.register_planet("planet_b", [tree], tiles, {})
	mgr.unregister_planet("planet_b")
	var stored = mgr.get_trees_for_planet("planet_b")
	assert_eq(stored.size(), 0)

func test_simulation_tick_ages_trees():
	var mgr = _make_manager()
	var tree = _make_mature_tree(Vector2i(5, 5))
	var tiles = _make_simple_map()
	mgr.register_planet("planet_c", [tree], tiles, {"climate_type": "TEMPERATE"})
	var initial_age = mgr.get_trees_for_planet("planet_c")[0].age_in_ticks
	mgr.on_simulation_tick(1, 0.25)
	var new_age = mgr.get_trees_for_planet("planet_c")[0].age_in_ticks
	assert_gt(float(new_age), float(initial_age))

func test_mature_tree_can_spread():
	var mgr = _make_manager()
	var tiles = _make_simple_map()
	var tree = _make_mature_tree(Vector2i(5, 5))
	# Give very high seed production for guaranteed spread in many ticks
	tree.seed_production = 1.0
	mgr.register_planet("planet_d", [tree], tiles, {"climate_type": "TEMPERATE"})

	# Run many ticks to allow spreading
	var initial_count = mgr.get_trees_for_planet("planet_d").size()
	for i in range(50):
		mgr.on_simulation_tick(i + 1, float(i + 1) * 0.25)

	var final_count = mgr.get_trees_for_planet("planet_d").size()
	assert_gte(float(final_count), float(initial_count))  # At least same or grown

func test_seedling_does_not_spread():
	var mgr = _make_manager()
	var tiles = _make_simple_map()
	var tree = TreeInstance.new()
	tree.position = Vector2i(5, 5)
	tree.species = TREE_SPECIES
	tree.growth_stage = TreeInstance.GrowthStage.SEEDLING
	tree.age_in_ticks = 0
	tree.health = 1.0
	mgr.register_planet("planet_e", [tree], tiles, {"climate_type": "TEMPERATE"})

	# Seed production is 0 for seedlings so spread can't happen
	mgr.on_simulation_tick(1, 0.25)
	var trees = mgr.get_trees_for_planet("planet_e")
	# Count should stay at 1 (no spreading while seedling)
	assert_lte(float(trees.size()), 1.0)

func test_tree_survives_in_hostile_climate():
	# Design decision: Trees only die from old age, not climate/environment
	# This ensures all trees show all 6 visual growth stages
	# NOTE: With fast thresholds [1,2,3,5,7,9,11], a MATURE tree (age=5) dies at age=11 (6 ticks)
	# We run only 3 ticks to verify climate doesn't kill tree before old age does
	var mgr = _make_manager()
	var tiles = _make_simple_map(1)
	var tree = _make_mature_tree(Vector2i(0, 0))
	tree.health = 1.0
	mgr.register_planet("planet_f", [tree], tiles, {"climate_type": "SCORCHING"})

	# Run a few ticks (less than tree's remaining lifespan) - tree should survive climate
	for i in range(3):
		mgr.on_simulation_tick(i + 1, float(i + 1) * 0.25)

	var final_trees = mgr.get_trees_for_planet("planet_f")
	# Tree should still be alive (climate doesn't kill trees)
	assert_eq(final_trees.size(), 1, "Tree should survive hostile climate - only old age kills trees")

func test_get_tree_at_returns_correct_tree():
	var mgr = _make_manager()
	var tree = _make_mature_tree(Vector2i(3, 7))
	var tiles = _make_simple_map()
	mgr.register_planet("planet_h", [tree], tiles, {})
	var found = mgr.get_tree_at("planet_h", Vector2i(3, 7))
	assert_not_null(found)
	assert_eq(found.position, Vector2i(3, 7))

func test_get_tree_at_returns_null_for_empty_tile():
	var mgr = _make_manager()
	var tree = _make_mature_tree(Vector2i(3, 7))
	var tiles = _make_simple_map()
	mgr.register_planet("planet_i", [tree], tiles, {})
	var found = mgr.get_tree_at("planet_i", Vector2i(0, 0))
	assert_null(found)

func test_get_tree_at_returns_null_for_unknown_planet():
	var mgr = _make_manager()
	var found = mgr.get_tree_at("nonexistent_planet", Vector2i(5, 5))
	assert_null(found)

func test_tree_stage_changed_signal_emitted_on_growth():
	var mgr = _make_manager()
	var tiles = _make_simple_map()
	# Seedling one tick away from becoming a sapling
	var tree = TreeInstance.new()
	tree.position = Vector2i(5, 5)
	tree.species = TREE_SPECIES
	tree.growth_stage = TreeInstance.GrowthStage.SEEDLING
	tree.health = 1.0

	# Initialize with config first
	var registry = PlantSpeciesRegistry.get_instance()
	var config = registry.get_species_config(TREE_SPECIES)
	if config:
		tree.initialize_with_config(config, 1.0)
		# Set age to one tick before sapling threshold
		if tree._thresholds.size() >= 2:
			tree.age_in_ticks = tree._thresholds[1] - 1

	mgr.register_planet("planet_stage", [tree], tiles, {"climate_type": "TEMPERATE"})

	# Use array (reference type) so lambda can mutate it
	var changed_positions := []
	mgr.tree_stage_changed.connect(func(pos): changed_positions.append(pos))

	mgr.on_simulation_tick(1, 0.25)  # This tick pushes age to sapling threshold

	assert_true(changed_positions.size() > 0, "tree_stage_changed should fire when seedling becomes sapling")

func test_tree_health_unchanged_by_moisture():
	# Design decision: Trees only die from old age, not drought
	# Health penalties are disabled to ensure trees show all visual stages
	var mgr = _make_manager()
	var tiles = _make_simple_map(5)
	tiles[2][2].moisture_level = 0.1  # Very dry tile
	var tree = _make_mature_tree(Vector2i(2, 2))
	tree.health = 0.5
	mgr.register_planet("planet_g", [tree], tiles, {"climate_type": "TEMPERATE"})

	var health_before = mgr.get_trees_for_planet("planet_g")[0].health
	mgr.on_simulation_tick(1, 0.25)
	var health_after = mgr.get_trees_for_planet("planet_g")[0].health

	# Health should be unchanged - no penalties in current design
	assert_eq(health_after, health_before, "Health unchanged - penalties disabled to show all visual stages")
