extends "res://tests/test_base.gd"

## Tests for ChunkManager - chunk visibility management

var chunk_mgr: ChunkManager
var coord_sys: CoordinateSystem
var planet_id: String = "test_planet"

func before_each():
	chunk_mgr = ChunkManager.new()
	coord_sys = CoordinateSystem.new(Vector2i(256, 256), Vector2i(160, 80), 64)
	chunk_mgr.initialize_planet(planet_id, Vector2i(256, 256), coord_sys)

# --- Initialization ---

func test_initialize_planet():
	var cm = ChunkManager.new()
	cm.initialize_planet("planet_1", Vector2i(128, 128), coord_sys)

	# Should be able to access active chunks after init
	var active = cm.get_active_chunks("planet_1")
	assert_not_null(active, "Active chunks array exists")
	assert_true(active is Array, "Active chunks is an array")

func test_unregister_planet():
	chunk_mgr.unregister_planet(planet_id)

	# After unregister, get_active_chunks returns empty
	var active = chunk_mgr.get_active_chunks(planet_id)
	assert_eq(active.size(), 0, "No active chunks after unregister")

# --- Active chunks ---

func test_update_active_chunks_center():
	# Update active chunks around center tile
	chunk_mgr.update_active_chunks(planet_id, Vector2i(128, 128))

	var active = chunk_mgr.get_active_chunks(planet_id)
	assert_gt(active.size(), 0, "Has active chunks")

func test_update_active_chunks_radius():
	# Default radius is 3, so 7x7 = 49 chunks
	chunk_mgr.update_active_chunks(planet_id, Vector2i(128, 128))

	var active = chunk_mgr.get_active_chunks(planet_id)
	# (2*3+1)^2 = 49 chunks
	assert_eq(active.size(), 49, "49 chunks with radius 3")

func test_update_active_chunks_custom_radius():
	chunk_mgr.set_chunk_radius(planet_id, 1)
	chunk_mgr.update_active_chunks(planet_id, Vector2i(64, 64))

	var active = chunk_mgr.get_active_chunks(planet_id)
	# (2*1+1)^2 = 9 chunks
	assert_eq(active.size(), 9, "9 chunks with radius 1")

func test_is_chunk_active():
	chunk_mgr.update_active_chunks(planet_id, Vector2i(64, 64))

	# Chunk (1, 1) should be active (contains tile 64, 64)
	assert_true(chunk_mgr.is_chunk_active(planet_id, Vector2i(1, 1)), "Center chunk active")

	# Very distant chunk should not be active
	assert_false(chunk_mgr.is_chunk_active(planet_id, Vector2i(100, 100)), "Distant chunk inactive")

func test_is_chunk_active_when_disabled():
	chunk_mgr.set_chunking_disabled(planet_id, true)

	# All chunks should be considered active when chunking disabled
	assert_true(chunk_mgr.is_chunk_active(planet_id, Vector2i(100, 100)), "All chunks active when disabled")

# --- Camera sync ---

func test_update_chunk_center_from_camera():
	# First call should always update
	var world_pos = coord_sys.tile_to_world(Vector2i(128, 128))
	var changed = chunk_mgr.update_chunk_center_from_camera(planet_id, world_pos)

	assert_true(changed, "First camera update triggers change")
	var active = chunk_mgr.get_active_chunks(planet_id)
	assert_gt(active.size(), 0, "Has active chunks after camera update")

func test_update_chunk_center_hysteresis():
	# Initial position
	var world_pos = coord_sys.tile_to_world(Vector2i(64, 64))
	chunk_mgr.update_chunk_center_from_camera(planet_id, world_pos)

	# Small movement should not trigger update (hysteresis)
	var small_move = world_pos + Vector2(10, 10)
	var changed = chunk_mgr.update_chunk_center_from_camera(planet_id, small_move)

	assert_false(changed, "Small move doesn't trigger update")

func test_update_chunk_center_large_movement():
	# Initial position
	var world_pos = coord_sys.tile_to_world(Vector2i(64, 64))
	chunk_mgr.update_chunk_center_from_camera(planet_id, world_pos)

	# Large movement should trigger update
	var large_move = coord_sys.tile_to_world(Vector2i(128, 128))
	var changed = chunk_mgr.update_chunk_center_from_camera(planet_id, large_move)

	assert_true(changed, "Large move triggers update")

func test_update_chunk_center_disabled():
	chunk_mgr.set_chunking_disabled(planet_id, true)

	var world_pos = coord_sys.tile_to_world(Vector2i(128, 128))
	var changed = chunk_mgr.update_chunk_center_from_camera(planet_id, world_pos)

	assert_false(changed, "No change when chunking disabled")

# --- Spawn bounds ---

func test_get_spawn_bounds_full_map():
	chunk_mgr.set_chunking_disabled(planet_id, true)

	var bounds = chunk_mgr.get_spawn_bounds(planet_id, Vector2i(256, 256))

	assert_eq(bounds.position, Vector2i(0, 0), "Full map starts at origin")
	assert_eq(bounds.size, Vector2i(256, 256), "Full map size")

func test_get_spawn_bounds_with_margin():
	chunk_mgr.set_chunking_disabled(planet_id, true)

	var bounds = chunk_mgr.get_spawn_bounds(planet_id, Vector2i(256, 256), 10)

	assert_eq(bounds.position, Vector2i(10, 10), "Margin applied to start")
	assert_eq(bounds.size, Vector2i(236, 236), "Margin applied to size")

func test_get_spawn_bounds_chunked():
	chunk_mgr.set_chunk_radius(planet_id, 1)
	chunk_mgr.update_active_chunks(planet_id, Vector2i(128, 128))

	var bounds = chunk_mgr.get_spawn_bounds(planet_id, Vector2i(256, 256))

	# Should be limited to active chunk area
	assert_lt(bounds.size.x, 256, "Bounds smaller than full map")
	assert_lt(bounds.size.y, 256, "Bounds smaller than full map")

# --- Configuration ---

func test_set_chunk_radius():
	chunk_mgr.set_chunk_radius(planet_id, 5)
	assert_eq(chunk_mgr.get_chunk_radius(planet_id), 5, "Radius updated")

func test_get_chunk_radius_default():
	var cm = ChunkManager.new()
	cm.initialize_planet("new", Vector2i(64, 64), coord_sys)

	assert_eq(cm.get_chunk_radius("new"), 3, "Default radius is 3")

func test_set_chunking_disabled():
	chunk_mgr.set_chunking_disabled(planet_id, true)
	assert_true(chunk_mgr.is_chunking_disabled(planet_id), "Chunking disabled")

	chunk_mgr.set_chunking_disabled(planet_id, false)
	assert_false(chunk_mgr.is_chunking_disabled(planet_id), "Chunking enabled")

func test_chunking_disabled_skips_update():
	chunk_mgr.set_chunking_disabled(planet_id, true)
	chunk_mgr.update_active_chunks(planet_id, Vector2i(128, 128))

	# Active chunks list should be empty when chunking disabled
	var active = chunk_mgr.get_active_chunks(planet_id)
	assert_eq(active.size(), 0, "No active chunks tracked when disabled")

# --- Coordinate conversion ---

func test_world_pos_to_chunk():
	var chunk = chunk_mgr.world_pos_to_chunk(Vector2i(64, 64))
	assert_eq(chunk, Vector2i(1, 1), "Tile 64,64 is chunk 1,1")

func test_world_pos_to_chunk_origin():
	var chunk = chunk_mgr.world_pos_to_chunk(Vector2i(0, 0))
	assert_eq(chunk, Vector2i(0, 0), "Origin is chunk 0,0")

func test_world_to_tile_with_planet():
	var world = coord_sys.tile_to_world(Vector2i(32, 32))
	var tile = chunk_mgr.world_to_tile(world, planet_id)

	assert_eq(tile, Vector2i(32, 32), "Converts world to tile")

func test_world_to_tile_missing_planet():
	# Should log error and return zero
	var tile = chunk_mgr.world_to_tile(Vector2.ZERO, "nonexistent_planet")
	assert_eq(tile, Vector2i(0, 0), "Returns zero for missing planet")

# --- Multiple planets ---

func test_multiple_planets_independent():
	# Initialize second planet
	var coord_sys2 = CoordinateSystem.new(Vector2i(128, 128), Vector2i(160, 80), 64)
	chunk_mgr.initialize_planet("planet_2", Vector2i(128, 128), coord_sys2)

	# Update chunks on both
	chunk_mgr.set_chunk_radius(planet_id, 2)
	chunk_mgr.set_chunk_radius("planet_2", 1)

	chunk_mgr.update_active_chunks(planet_id, Vector2i(64, 64))
	chunk_mgr.update_active_chunks("planet_2", Vector2i(32, 32))

	# Should have different chunk counts
	var active1 = chunk_mgr.get_active_chunks(planet_id)
	var active2 = chunk_mgr.get_active_chunks("planet_2")

	assert_eq(active1.size(), 25, "Planet 1 has 25 chunks (radius 2)")
	assert_eq(active2.size(), 9, "Planet 2 has 9 chunks (radius 1)")

func test_unregister_one_planet_keeps_other():
	chunk_mgr.initialize_planet("planet_2", Vector2i(64, 64), coord_sys)
	chunk_mgr.update_active_chunks(planet_id, Vector2i(64, 64))
	chunk_mgr.update_active_chunks("planet_2", Vector2i(32, 32))

	chunk_mgr.unregister_planet(planet_id)

	# planet_2 should still work
	var active2 = chunk_mgr.get_active_chunks("planet_2")
	assert_gt(active2.size(), 0, "Planet 2 still has chunks")

	# planet_id should be empty
	var active1 = chunk_mgr.get_active_chunks(planet_id)
	assert_eq(active1.size(), 0, "Planet 1 cleaned up")
