extends "res://tests/test_base.gd"

## Tests for plant species configuration system

func before_each():
	super.before_each()

func after_each():
	super.after_each()

# PlantSpeciesConfig tests

func test_maple_tree_config_has_correct_defaults():
	var config = PlantSpeciesConfig.create_maple_tree()
	assert_eq(config.species_name, "Maple Tree", "Maple tree should have correct name")
	assert_eq(config.species_type, PlantSpeciesConfig.SpeciesType.TREE, "Maple should be TREE type")
	assert_eq(config.growth_rate_multiplier, 1.0, "Maple should have baseline growth rate")
	assert_eq(config.base_tick_thresholds.size(), 7, "Trees should have 7 growth thresholds")

func test_grass_config_has_faster_growth():
	var grass = PlantSpeciesConfig.create_grass()
	var maple = PlantSpeciesConfig.create_maple_tree()
	assert_gt(grass.growth_rate_multiplier, maple.growth_rate_multiplier, "Grass should grow faster than trees")
	assert_eq(grass.species_type, PlantSpeciesConfig.SpeciesType.GROUND_COVER, "Grass should be GROUND_COVER type")
	assert_eq(grass.base_tick_thresholds.size(), 4, "Ground cover should have 4 growth thresholds")

func test_goldenrod_config_slower_than_grass():
	var grass = PlantSpeciesConfig.create_grass()
	var goldenrod = PlantSpeciesConfig.create_goldenrod()
	assert_gt(grass.growth_rate_multiplier, goldenrod.growth_rate_multiplier, "Grass should grow faster than goldenrod")

# PlantSpeciesRegistry tests

func test_registry_singleton_returns_same_instance():
	var reg1 = PlantSpeciesRegistry.get_instance()
	var reg2 = PlantSpeciesRegistry.get_instance()
	assert_true(reg1 == reg2, "Registry should return same singleton instance")

func test_registry_has_default_species():
	var registry = PlantSpeciesRegistry.get_instance()
	assert_gt(registry.get_species_count(), 0, "Registry should have default species registered")

	# Check for maple trees using MapleTreeTypes constants (not hardcoded values)
	var maple_id = MapleTreeTypes.TR_MAPL_VG_1
	var maple = registry.get_species_config(maple_id)
	assert_not_null(maple, "Registry should have maple tree ID %d" % maple_id)
	assert_eq(maple.species_name, "Maple Tree", "Maple config should have correct name")

func test_registry_has_ground_cover_species():
	var registry = PlantSpeciesRegistry.get_instance()

	var grass = registry.get_species_config(40)
	assert_not_null(grass, "Registry should have grass (ID 40)")
	assert_eq(grass.species_name, "Grass", "Grass config should have correct name")

	var goldenrod = registry.get_species_config(45)
	assert_not_null(goldenrod, "Registry should have goldenrod (ID 45)")
	assert_eq(goldenrod.species_name, "Goldenrod", "Goldenrod config should have correct name")

func test_registry_returns_null_for_unknown_species():
	var registry = PlantSpeciesRegistry.get_instance()
	var unknown = registry.get_species_config(9999)
	assert_null(unknown, "Registry should return null for unknown species ID")

func test_registry_can_register_custom_species():
	var registry = PlantSpeciesRegistry.get_instance()
	var initial_count = registry.get_species_count()

	var custom = PlantSpeciesConfig.new()
	custom.species_id = 5000
	custom.species_name = "Test Species"
	custom.growth_rate_multiplier = 2.5
	registry.register_species(custom)

	var retrieved = registry.get_species_config(5000)
	assert_not_null(retrieved, "Registry should have custom species")
	assert_eq(retrieved.species_name, "Test Species", "Custom species should have correct name")

# TreeInstance initialization tests

func test_tree_instance_thresholds_initialized_from_config():
	var tree = TreeInstance.new()
	var config = PlantSpeciesConfig.create_maple_tree()
	tree.initialize_with_config(config, 1.0)

	assert_eq(tree._thresholds.size(), 7, "Tree should have 7 thresholds after initialization")
	assert_gt(tree._thresholds[0], 0, "First threshold should be positive")

func test_tree_instance_growth_rate_scales_with_environment():
	var tree_temperate = TreeInstance.new()
	var tree_tropical = TreeInstance.new()
	var config = PlantSpeciesConfig.create_maple_tree()

	tree_temperate.initialize_with_config(config, 1.0)  # Baseline
	tree_tropical.initialize_with_config(config, 1.5)   # 50% faster

	# Tropical tree should have lower thresholds (reaches stages faster)
	# NOTE: With fast thresholds, early thresholds may both floor to 1 (minimum)
	# Use the removal threshold (index 6) which has enough room for scaling:
	# temperate: 11, tropical: 11/1.5 = 7
	assert_lt(tree_tropical._thresholds[6], tree_temperate._thresholds[6], "Tropical tree should have lower removal threshold")

func test_tree_instance_thresholds_prevent_division_by_zero():
	var tree = TreeInstance.new()
	var config = PlantSpeciesConfig.create_maple_tree()

	# Test with invalid modifier (should default to 1.0)
	tree.initialize_with_config(config, 0.0)
	assert_eq(tree._thresholds.size(), 7, "Tree should handle zero modifier gracefully")

# EcosystemManager environment modifier tests

func test_ecosystem_environment_modifier_tropical():
	var em = EcosystemManager.new()
	autofree(em)

	var tropical_data = {"climate_type": "TROPICAL", "atmosphere_type": "MODERATE"}
	var modifier = em._calculate_environment_modifier(tropical_data)

	assert_eq(modifier, 1.5, "Tropical climate should give 1.5x growth rate")

func test_ecosystem_environment_modifier_frozen():
	var em = EcosystemManager.new()
	autofree(em)

	var frozen_data = {"climate_type": "FROZEN", "atmosphere_type": "MODERATE"}
	var modifier = em._calculate_environment_modifier(frozen_data)

	assert_eq(modifier, 0.3, "Frozen climate should give 0.3x growth rate")

func test_ecosystem_environment_modifier_temperate_baseline():
	var em = EcosystemManager.new()
	autofree(em)

	var temperate_data = {"climate_type": "TEMPERATE", "atmosphere_type": "MODERATE"}
	var modifier = em._calculate_environment_modifier(temperate_data)

	assert_eq(modifier, 1.0, "Temperate climate should give baseline 1.0x growth rate")

func test_ecosystem_environment_modifier_with_atmosphere():
	var em = EcosystemManager.new()
	autofree(em)

	var thick_atmo = {"climate_type": "TEMPERATE", "atmosphere_type": "THICK"}
	var thin_atmo = {"climate_type": "TEMPERATE", "atmosphere_type": "THIN"}

	var thick_modifier = em._calculate_environment_modifier(thick_atmo)
	var thin_modifier = em._calculate_environment_modifier(thin_atmo)

	assert_eq(thick_modifier, 1.1, "Thick atmosphere should give 1.1x modifier")
	assert_eq(thin_modifier, 0.9, "Thin atmosphere should give 0.9x modifier")

# GroundCoverInstance tests

func test_ground_cover_instance_initializes_with_config():
	var plant = GroundCoverInstance.new()
	var config = PlantSpeciesConfig.create_grass()

	plant.position = Vector2i(10, 10)
	plant.species = 40
	plant.initialize_with_config(config, 1.0)

	assert_eq(plant._thresholds.size(), 4, "Ground cover should have 4 thresholds")
	assert_gt(plant._thresholds[0], 0, "First threshold should be positive")

func test_ground_cover_grows_through_stages():
	var plant = GroundCoverInstance.new()
	var config = PlantSpeciesConfig.create_grass()
	plant.initialize_with_config(config, 1.0)

	assert_eq(plant.growth_stage, GroundCoverInstance.GrowthStage.SPROUT, "Should start as sprout")

	# Tick until growing stage
	for i in range(plant._thresholds[0] + 1):
		plant.tick(0.0)

	assert_eq(plant.growth_stage, GroundCoverInstance.GrowthStage.GROWING, "Should progress to growing")

func test_ground_cover_serialization():
	var plant = GroundCoverInstance.new()
	var config = PlantSpeciesConfig.create_grass()
	plant.position = Vector2i(5, 7)
	plant.species = 40
	plant.initialize_with_config(config, 1.0)
	plant.age_in_ticks = 10
	plant.health = 0.8

	var serialized = plant.serialize()
	var restored = GroundCoverInstance.deserialize(serialized)

	assert_eq(restored.position, Vector2i(5, 7), "Position should match")
	assert_eq(restored.species, 40, "Species should match")
	assert_eq(restored.age_in_ticks, 10, "Age should match")
	assert_eq(restored.health, 0.8, "Health should match")
	assert_eq(restored._thresholds.size(), 4, "Thresholds should be restored")
