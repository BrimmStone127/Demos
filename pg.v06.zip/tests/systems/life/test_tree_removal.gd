extends "res://tests/test_base.gd"

## Tests for tree death, removal, and edge cases in EcosystemManager
##
## These tests verify the full removal flow that was previously untested,
## including signal emission, array cleanup, and performance limits.
##
## NOTE: These tests create trees that are manually set to specific states
## AFTER registration to bypass VARIED_INITIAL_AGES randomization.

const GRASS_TYPE = PlanetMapTileConfig.TileType.GRASS_0
const TREE_SPECIES = MapleTreeTypes.TR_MAPL_VG_1

func _make_manager() -> EcosystemManager:
	var mgr = EcosystemManager.new()
	# Disable random spawning for predictable test behavior
	mgr.enable_random_tree_spawning = false
	_autofree_nodes.append(mgr)
	return mgr

func _make_tile(type: PlanetMapTileConfig.TileType, pos: Vector2i = Vector2i(0, 0)) -> MapTile:
	var t = MapTile.new(pos, type)
	t.moisture_level = 0.5
	return t

func _make_simple_map(size: int = 10) -> Array:
	var tiles = []
	tiles.resize(size)
	for x in range(size):
		tiles[x] = []
		tiles[x].resize(size)
		for y in range(size):
			tiles[x][y] = _make_tile(GRASS_TYPE, Vector2i(x, y))
	return tiles

func _make_uninitialized_tree(pos: Vector2i) -> TreeInstance:
	"""Create a tree without thresholds - EcosystemManager will initialize it"""
	var t = TreeInstance.new()
	t.position = pos
	t.species = TREE_SPECIES
	t.health = 1.0  # Healthy - death comes from age, not health loss
	return t

func _set_tree_at_removal_threshold(tree: TreeInstance) -> void:
	"""Set a tree to be at the removal threshold (call AFTER registration)"""
	if tree._thresholds.size() >= 7:
		tree.growth_stage = TreeInstance.GrowthStage.DORMANT
		tree.age_in_ticks = tree._thresholds[6]  # At removal threshold

func _set_tree_dormant_not_ready(tree: TreeInstance) -> void:
	"""Set a tree to DORMANT but not ready for removal (call AFTER registration)"""
	if tree._thresholds.size() >= 6:
		tree.growth_stage = TreeInstance.GrowthStage.DORMANT
		tree.age_in_ticks = tree._thresholds[5]  # Just became dormant

# ========== Core Removal Tests ==========

func test_dead_tree_removed_from_array():
	"""Verify trees at removal threshold are actually removed from the array"""
	var mgr = _make_manager()
	var tree = _make_uninitialized_tree(Vector2i(5, 5))
	var tiles = _make_simple_map()

	mgr.register_planet("test_removal", [tree], tiles, {"climate_type": "TEMPERATE"})

	# Set tree state AFTER registration to bypass VARIED_INITIAL_AGES
	var registered_tree = mgr.get_tree_at("test_removal", Vector2i(5, 5))
	_set_tree_at_removal_threshold(registered_tree)

	# Verify tree is registered and at removal threshold
	assert_eq(mgr.get_trees_for_planet("test_removal").size(), 1, "Tree should be registered")
	assert_true(registered_tree.should_be_removed(), "Tree should be marked for removal")

	# Tick should process removal
	mgr.on_simulation_tick(1, 0.25)

	# Tree should be gone
	assert_eq(mgr.get_trees_for_planet("test_removal").size(), 0, "Dead tree should be removed from array")

func test_tree_died_signal_emitted_on_removal():
	"""Verify tree_died signal is emitted when a tree is removed"""
	var mgr = _make_manager()
	var tree = _make_uninitialized_tree(Vector2i(5, 5))
	var tiles = _make_simple_map()

	mgr.register_planet("test_signal", [tree], tiles, {"climate_type": "TEMPERATE"})

	# Set tree state AFTER registration
	var registered_tree = mgr.get_tree_at("test_signal", Vector2i(5, 5))
	_set_tree_at_removal_threshold(registered_tree)

	var died_positions := []
	mgr.tree_died.connect(func(pos): died_positions.append(pos))

	mgr.on_simulation_tick(1, 0.25)

	assert_eq(died_positions.size(), 1, "tree_died signal should be emitted once")
	assert_eq(died_positions[0], Vector2i(5, 5), "Signal should include correct position")

func test_dormant_tree_not_removed_before_threshold():
	"""Verify DORMANT trees stay visible until they reach removal threshold"""
	var mgr = _make_manager()
	var tree = _make_uninitialized_tree(Vector2i(5, 5))
	var tiles = _make_simple_map()

	mgr.register_planet("test_dormant_visible", [tree], tiles, {"climate_type": "TEMPERATE"})

	# Set tree state AFTER registration - dormant but not at removal threshold
	var registered_tree = mgr.get_tree_at("test_dormant_visible", Vector2i(5, 5))
	_set_tree_dormant_not_ready(registered_tree)

	# Tick once - tree should still be there
	mgr.on_simulation_tick(1, 0.25)

	var trees = mgr.get_trees_for_planet("test_dormant_visible")
	assert_eq(trees.size(), 1, "Dormant tree should remain until removal threshold")
	assert_eq(int(trees[0].growth_stage), int(TreeInstance.GrowthStage.DORMANT), "Tree should be DORMANT")

func test_multiple_trees_removed_in_same_tick():
	"""Verify multiple trees can be removed in a single tick"""
	var mgr = _make_manager()
	var tiles = _make_simple_map()
	var trees := [
		_make_uninitialized_tree(Vector2i(3, 3)),
		_make_uninitialized_tree(Vector2i(4, 4)),
		_make_uninitialized_tree(Vector2i(5, 5)),
	]

	mgr.register_planet("test_multi", trees, tiles, {"climate_type": "TEMPERATE"})

	# Verify trees were registered
	assert_eq(mgr.get_trees_for_planet("test_multi").size(), 3, "Should have 3 trees after registration")

	# Set all trees to removal threshold AFTER registration
	var ready_count := 0
	for pos in [Vector2i(3, 3), Vector2i(4, 4), Vector2i(5, 5)]:
		var t = mgr.get_tree_at("test_multi", pos)
		assert_not_null(t, "Tree at %s should exist" % pos)
		_set_tree_at_removal_threshold(t)
		if t.should_be_removed():
			ready_count += 1

	assert_eq(ready_count, 3, "All 3 trees should be marked for removal")

	# Use array for signal counting (arrays are reference types, primitives are not)
	var died_positions := []
	mgr.tree_died.connect(func(pos): died_positions.append(pos))

	mgr.on_simulation_tick(1, 0.25)

	assert_eq(mgr.get_trees_for_planet("test_multi").size(), 0, "All dead trees should be removed")
	assert_eq(died_positions.size(), 3, "tree_died should be emitted for each removal")

# ========== Performance Limit Tests ==========

func test_max_deaths_per_tick_limit():
	"""Verify BASE_MAX_DEATHS_PER_TICK limits removals in one tick"""
	var mgr = _make_manager()
	# Use 64x64 map so death limit doesn't scale down (base area = 64*64)
	var tiles = _make_simple_map(64)
	var trees := []

	# Create 600 trees (more than BASE_MAX_DEATHS_PER_TICK = 512)
	for i in range(600):
		var pos = Vector2i(3 + (i % 55), 3 + int(i / 55))
		trees.append(_make_uninitialized_tree(pos))

	mgr.register_planet("test_death_limit", trees, tiles, {"climate_type": "TEMPERATE"})

	# Set all trees to removal threshold AFTER registration
	for i in range(600):
		var pos = Vector2i(3 + (i % 55), 3 + int(i / 55))
		var t = mgr.get_tree_at("test_death_limit", pos)
		if t:
			_set_tree_at_removal_threshold(t)

	# One tick should only remove BASE_MAX_DEATHS_PER_TICK trees
	mgr.on_simulation_tick(1, 0.25)

	var remaining = mgr.get_trees_for_planet("test_death_limit").size()
	# BASE_MAX_DEATHS_PER_TICK is 512 (scaled 1x on 64x64), so ~88 should remain (600 - 512)
	assert_gte(remaining, 80, "Should hit death limit and leave some trees for next tick")
	assert_lte(remaining, 100, "Should remove close to BASE_MAX_DEATHS_PER_TICK trees")

func test_remaining_deaths_processed_next_tick():
	"""Verify trees that couldn't be removed are processed in subsequent ticks"""
	var mgr = _make_manager()
	# Use 64x64 map so death limit doesn't scale down
	var tiles = _make_simple_map(64)
	var trees := []

	# Create 600 trees (more than BASE_MAX_DEATHS_PER_TICK = 512)
	for i in range(600):
		var pos = Vector2i(3 + (i % 55), 3 + int(i / 55))
		trees.append(_make_uninitialized_tree(pos))

	mgr.register_planet("test_death_continue", trees, tiles, {"climate_type": "TEMPERATE"})

	# Set all trees to removal threshold AFTER registration
	for i in range(600):
		var pos = Vector2i(3 + (i % 55), 3 + int(i / 55))
		var t = mgr.get_tree_at("test_death_continue", pos)
		if t:
			_set_tree_at_removal_threshold(t)

	# First tick removes up to 512
	mgr.on_simulation_tick(1, 0.25)
	var after_first = mgr.get_trees_for_planet("test_death_continue").size()

	# Second tick should finish the rest
	mgr.on_simulation_tick(2, 0.5)
	var after_second = mgr.get_trees_for_planet("test_death_continue").size()

	assert_lt(after_second, after_first, "Second tick should remove more trees")
	assert_eq(after_second, 0, "All trees should eventually be removed")

# ========== Edge Case Tests ==========

func test_empty_planet_simulation():
	"""Verify simulation handles planet with no trees gracefully"""
	var mgr = _make_manager()
	var tiles = _make_simple_map()

	mgr.register_planet("test_empty", [], tiles, {"climate_type": "TEMPERATE"})

	# Should not crash
	mgr.on_simulation_tick(1, 0.25)
	mgr.on_simulation_tick(2, 0.5)

	assert_eq(mgr.get_trees_for_planet("test_empty").size(), 0, "Empty planet should stay empty")

func test_unregistered_planet_simulation():
	"""Verify simulation handles unregistered planet gracefully"""
	var mgr = _make_manager()

	# Don't register any planet, just call simulation
	mgr.on_simulation_tick(1, 0.25)

	# Should not crash, should return empty array
	var trees = mgr.get_trees_for_planet("nonexistent")
	assert_eq(trees.size(), 0, "Unregistered planet should return empty array")

func test_tree_at_map_edge():
	"""Verify trees at map edges are handled correctly"""
	var mgr = _make_manager()
	var tiles = _make_simple_map(10)

	# Place tree at edge (within SPREAD_EDGE_MARGIN)
	var edge_tree = _make_uninitialized_tree(Vector2i(1, 1))

	mgr.register_planet("test_edge", [edge_tree], tiles, {"climate_type": "TEMPERATE"})

	# Set to dormant but not ready for removal
	var registered_tree = mgr.get_tree_at("test_edge", Vector2i(1, 1))
	_set_tree_dormant_not_ready(registered_tree)

	# Should process without crashing
	mgr.on_simulation_tick(1, 0.25)

	assert_eq(mgr.get_trees_for_planet("test_edge").size(), 1, "Edge tree should be processed normally")

func test_get_tree_at_after_removal():
	"""Verify get_tree_at returns null after tree is removed"""
	var mgr = _make_manager()
	var tree = _make_uninitialized_tree(Vector2i(5, 5))
	var tiles = _make_simple_map()

	mgr.register_planet("test_get_after", [tree], tiles, {"climate_type": "TEMPERATE"})

	# Set tree state AFTER registration
	var registered_tree = mgr.get_tree_at("test_get_after", Vector2i(5, 5))
	_set_tree_at_removal_threshold(registered_tree)

	# Before removal - tree exists and should be removed
	var found_before = mgr.get_tree_at("test_get_after", Vector2i(5, 5))
	assert_not_null(found_before, "Tree should be found before removal")
	assert_true(found_before.should_be_removed(), "Tree should be marked for removal")

	# Process removal
	mgr.on_simulation_tick(1, 0.25)

	# After removal
	var found_after = mgr.get_tree_at("test_get_after", Vector2i(5, 5))
	assert_null(found_after, "Tree should not be found after removal")
