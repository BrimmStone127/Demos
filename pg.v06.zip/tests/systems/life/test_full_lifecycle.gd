extends "res://tests/test_base.gd"

# Comprehensive tests for tree lifecycle progression
# Tests that trees actually reach all stages including VERY_MATURE

func _make_tree() -> TreeInstance:
	var tree = TreeInstance.new()
	tree.position = Vector2i(10, 10)
	# Use actual maple tree ID from MapleTreeTypes, not hardcoded value
	tree.species = MapleTreeTypes.TR_MAPL_VG_1

	# Initialize with species config
	var registry = PlantSpeciesRegistry.get_instance()
	var config = registry.get_species_config(tree.species)
	if config:
		tree.initialize_with_config(config, 1.0)  # Temperate baseline
	else:
		push_error("No species config found for maple tree ID %d" % tree.species)

	return tree

func test_tree_reaches_very_mature():
	"""CRITICAL: Verify trees actually reach VERY_MATURE stage"""
	var tree = _make_tree()
	var threshold = tree._thresholds[4]  # VERY_MATURE threshold

	# Tick to VERY_MATURE threshold
	for i in range(threshold):
		tree.tick(0.0)  # No health delta
		if i < threshold:
			assert_true(tree.is_alive(), "Tree died at tick %d before reaching VERY_MATURE" % i)

	# Should be VERY_MATURE now
	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.VERY_MATURE),
		"Tree should be VERY_MATURE at tick %d, but is stage %d" % [tree.age_in_ticks, tree.growth_stage])

func test_tree_stays_very_mature_for_correct_duration():
	"""Verify VERY_MATURE lasts from threshold[4] to threshold[5]"""
	var tree = _make_tree()
	var very_mature_threshold = tree._thresholds[4]
	var dormant_threshold = tree._thresholds[5]

	# Advance to start of VERY_MATURE
	for _i in range(very_mature_threshold):
		tree.tick(0.0)

	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.VERY_MATURE))

	# Should stay VERY_MATURE until DORMANT threshold
	var very_mature_duration = dormant_threshold - very_mature_threshold
	for i in range(very_mature_duration - 1):  # -1 because we don't want to reach DORMANT
		tree.tick(0.0)
		assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.VERY_MATURE),
			"Tree left VERY_MATURE early at tick %d" % tree.age_in_ticks)

	# One more tick should make it DORMANT
	tree.tick(0.0)
	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.DORMANT))

func test_full_lifecycle_progression():
	"""Test complete progression through all stages"""
	var tree = _make_tree()

	# Use dynamic thresholds
	var expected_stages = [
		[0, TreeInstance.GrowthStage.SEEDLING],
		[tree._thresholds[0], TreeInstance.GrowthStage.YOUNG_SAPLING],
		[tree._thresholds[1], TreeInstance.GrowthStage.SAPLING],
		[tree._thresholds[2], TreeInstance.GrowthStage.YOUNG_MATURE],
		[tree._thresholds[3], TreeInstance.GrowthStage.MATURE],
		[tree._thresholds[4], TreeInstance.GrowthStage.VERY_MATURE],
		[tree._thresholds[5], TreeInstance.GrowthStage.DORMANT]
	]

	for stage_data in expected_stages:
		var target_tick = stage_data[0]
		var expected_stage = stage_data[1]

		# Tick to target
		while tree.age_in_ticks < target_tick:
			tree.tick(0.0)

		assert_eq(int(tree.growth_stage), int(expected_stage),
			"At tick %d, expected stage %d but got %d" % [target_tick, expected_stage, tree.growth_stage])

func test_tree_survives_without_health_delta():
	"""Trees should never die from health loss if health_delta is 0 - only from old age"""
	var tree = _make_tree()
	var dormant_threshold = tree._thresholds[5]

	# Tick through lifecycle until just before DORMANT
	# Tree should remain alive until it becomes DORMANT
	for i in range(dormant_threshold - 1):
		tree.tick(0.0)
		assert_true(tree.is_alive(), "Tree died prematurely at tick %d with 0 health delta" % (i + 1))

	# Tree should still be VERY_MATURE and alive
	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.VERY_MATURE))
	assert_true(tree.is_alive())

	# One more tick should transition to DORMANT
	tree.tick(0.0)
	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.DORMANT))
	assert_false(tree.is_alive())

func test_health_never_drops_with_zero_delta():
	"""Verify health stays at 1.0 with 0 delta"""
	var tree = _make_tree()
	var dormant_threshold = tree._thresholds[5]

	for _i in range(dormant_threshold):
		tree.tick(0.0)
		if tree.is_alive():
			assert_almost_eq(tree.health, 1.0, 0.001,
				"Health dropped to %.3f at tick %d" % [tree.health, tree.age_in_ticks])

func test_seed_production_at_very_mature():
	"""VERY_MATURE trees should produce seeds"""
	var tree = _make_tree()
	var very_mature_threshold = tree._thresholds[4]

	# Advance to VERY_MATURE
	for _i in range(very_mature_threshold):
		tree.tick(0.0)

	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.VERY_MATURE))
	assert_gt(tree.seed_production, 1.0,
		"VERY_MATURE should have seed production > 1.0, got %.2f" % tree.seed_production)

func test_visual_asset_for_very_mature():
	"""Verify VERY_MATURE maps to VG_6 visual"""
	var tree = _make_tree()
	var very_mature_threshold = tree._thresholds[4]

	# Advance to VERY_MATURE
	for _i in range(very_mature_threshold):
		tree.tick(0.0)

	var tile_id = MapleTreeTypes.get_tile_for_growth(tree.growth_stage, tree.age_in_ticks)
	assert_eq(tile_id, MapleTreeTypes.TR_MAPL_VG_6,
		"VERY_MATURE should map to VG_6 (tile %d), got tile %d" % [MapleTreeTypes.TR_MAPL_VG_6, tile_id])

func test_dormant_stays_visible_before_removal():
	"""DORMANT trees should remain visible for a period before removal"""
	var tree = _make_tree()
	var dormant_threshold = tree._thresholds[5]
	var removal_threshold = tree._thresholds[6]
	var dormant_duration = removal_threshold - dormant_threshold

	# Advance to DORMANT
	for _i in range(dormant_threshold):
		tree.tick(0.0)

	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.DORMANT))
	assert_false(tree.should_be_removed(), "Tree should NOT be removed immediately at DORMANT")

	# Tick through dormant visibility period
	for i in range(dormant_duration - 1):
		tree.tick(0.0)
		assert_false(tree.should_be_removed(),
			"Tree should NOT be removed at tick %d (dormant tick %d)" % [tree.age_in_ticks, i + 1])

	# Final tick should mark for removal
	tree.tick(0.0)
	assert_eq(tree.age_in_ticks, removal_threshold)
	assert_true(tree.should_be_removed(), "Tree should be removed at removal threshold")

func test_all_stages_have_visuals():
	"""Every stage should map to a valid tile ID"""
	var tree = _make_tree()
	var all_stages = [
		TreeInstance.GrowthStage.SEEDLING,
		TreeInstance.GrowthStage.YOUNG_SAPLING,
		TreeInstance.GrowthStage.SAPLING,
		TreeInstance.GrowthStage.YOUNG_MATURE,
		TreeInstance.GrowthStage.MATURE,
		TreeInstance.GrowthStage.VERY_MATURE,
		TreeInstance.GrowthStage.DORMANT
	]

	for stage in all_stages:
		tree.growth_stage = stage
		var tile_id = MapleTreeTypes.get_tile_for_growth(stage, 0)
		assert_ne(tile_id, -1, "Stage %d has no valid tile mapping" % stage)
		assert_gt(tile_id, 0, "Stage %d maps to invalid tile %d" % [stage, tile_id])
