extends "res://tests/test_base.gd"

# Tests for TreeInstance growth, aging, and seed production

func _make_tree(species: int = MapleTreeTypes.TR_MAPL_VG_1) -> TreeInstance:
	var t = TreeInstance.new()
	t.position = Vector2i(10, 10)
	t.species = species

	# Initialize with species config and baseline environment (temperate)
	var registry = PlantSpeciesRegistry.get_instance()
	var config = registry.get_species_config(species)
	if config:
		t.initialize_with_config(config, 1.0)  # 1.0 = temperate baseline
	else:
		push_error("Failed to get species config for species %d" % species)

	return t

func test_initial_state():
	var tree = _make_tree()
	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.SEEDLING))
	assert_eq(tree.age_in_ticks, 0)
	assert_almost_eq(tree.health, 1.0, 0.001)
	assert_almost_eq(tree.seed_production, 0.0, 0.001)

func test_is_alive_initially():
	var tree = _make_tree()
	assert_true(tree.is_alive())

func test_seedling_stage_before_threshold():
	var tree = _make_tree()
	# tick up to just before young sapling threshold
	var threshold = tree._thresholds[0]
	for _i in range(threshold - 1):
		tree.tick()
	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.SEEDLING))

func test_young_sapling_stage():
	var tree = _make_tree()
	var threshold = tree._thresholds[0]
	for _i in range(threshold):
		tree.tick()
	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.YOUNG_SAPLING))

func test_sapling_stage():
	var tree = _make_tree()
	var threshold = tree._thresholds[1]
	for _i in range(threshold):
		tree.tick()
	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.SAPLING))

func test_young_mature_stage():
	var tree = _make_tree()
	var threshold = tree._thresholds[2]
	for _i in range(threshold):
		tree.tick()
	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.YOUNG_MATURE))

func test_mature_stage():
	var tree = _make_tree()
	var threshold = tree._thresholds[3]
	for _i in range(threshold):
		tree.tick()
	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.MATURE))

func test_very_mature_stage():
	var tree = _make_tree()
	var threshold = tree._thresholds[4]
	for _i in range(threshold):
		tree.tick()
	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.VERY_MATURE))

func test_dormant_stage_by_age():
	var tree = _make_tree()
	var threshold = tree._thresholds[5]
	for _i in range(threshold):
		tree.tick()
	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.DORMANT))
	assert_false(tree.is_alive())

func test_dormant_by_zero_health():
	var tree = _make_tree()
	# Apply large negative health delta
	tree.tick(-2.0)
	assert_eq(int(tree.growth_stage), int(TreeInstance.GrowthStage.DORMANT))
	assert_false(tree.is_alive())

func test_health_clamped_above_one():
	var tree = _make_tree()
	tree.tick(5.0)
	assert_lte(tree.health, 1.0)

func test_health_clamped_below_zero():
	var tree = _make_tree()
	tree.tick(-5.0)
	assert_gte(tree.health, 0.0)

func test_seed_production_zero_when_young():
	var tree = _make_tree()
	tree.tick()  # Still seedling
	assert_almost_eq(tree.seed_production, 0.0, 0.001)

func test_seed_production_at_young_mature():
	var tree = _make_tree()
	var threshold = tree._thresholds[2]
	for _i in range(threshold):
		tree.tick()
	# Young mature trees start producing seeds
	assert_gt(tree.seed_production, 0.0)

func test_seed_production_at_mature():
	var tree = _make_tree()
	var threshold = tree._thresholds[3]
	for _i in range(threshold):
		tree.tick()
	# Full mature trees have peak production
	assert_gt(tree.seed_production, 0.0)

func test_seed_production_at_very_mature():
	var tree = _make_tree()
	var threshold = tree._thresholds[4]
	for _i in range(threshold):
		tree.tick()
	# Very mature trees have highest production
	assert_gt(tree.seed_production, 0.0)

func test_seed_production_zero_at_dormant():
	var tree = _make_tree()
	var threshold = tree._thresholds[5]
	for _i in range(threshold):
		tree.tick()
	# Dormant trees don't produce seeds
	assert_almost_eq(tree.seed_production, 0.0, 0.001)

func test_age_increments_each_tick():
	var tree = _make_tree()
	tree.tick()
	tree.tick()
	tree.tick()
	assert_eq(tree.age_in_ticks, 3)
