extends "res://tests/test_base.gd"
## Tests for HarvesterManager export/import (save/load persistence)

var manager: HarvesterManager

func before_each():
	manager = HarvesterManager.new()

func after_each():
	if manager:
		manager.free()
	super.after_each()

# --- export_harvesters ---

func test_export_empty_planet_returns_empty_array():
	var result := manager.export_harvesters("planet_1")
	assert_eq(result.size(), 0, "Should return empty array for unknown planet")

func test_export_single_harvester():
	var mold := manager.place_harvester(Vector2i(10, 20), "planet_1")
	mold.inventory_logs = 5

	var result := manager.export_harvesters("planet_1")
	assert_eq(result.size(), 1, "Should export one harvester")
	assert_eq(result[0]["origin_x"], 10, "origin_x should match")
	assert_eq(result[0]["origin_y"], 20, "origin_y should match")
	assert_eq(result[0]["inventory_logs"], 5, "inventory_logs should match")

func test_export_multiple_harvesters():
	var m1 := manager.place_harvester(Vector2i(5, 5), "planet_1")
	m1.inventory_logs = 3
	var m2 := manager.place_harvester(Vector2i(30, 40), "planet_1")
	m2.inventory_logs = 12

	var result := manager.export_harvesters("planet_1")
	assert_eq(result.size(), 2, "Should export two harvesters")
	assert_eq(result[0]["origin_x"], 5, "First harvester origin_x")
	assert_eq(result[1]["origin_x"], 30, "Second harvester origin_x")
	assert_eq(result[1]["inventory_logs"], 12, "Second harvester inventory_logs")

func test_export_only_specified_planet():
	manager.place_harvester(Vector2i(1, 1), "planet_1")
	manager.place_harvester(Vector2i(2, 2), "planet_2")

	var result := manager.export_harvesters("planet_1")
	assert_eq(result.size(), 1, "Should only export harvesters for specified planet")

# --- import_harvesters ---

func test_import_restores_harvesters():
	var data: Array = [
		{"origin_x": 15, "origin_y": 25, "inventory_logs": 7},
		{"origin_x": 50, "origin_y": 60, "inventory_logs": 0},
	]

	manager.import_harvesters("planet_1", data)

	var harvesters: Array = manager.harvesters_by_planet.get("planet_1", [])
	assert_eq(harvesters.size(), 2, "Should create two harvesters")

	var first: HarvesterInstance = harvesters[0] as HarvesterInstance
	assert_eq(first.origin, Vector2i(15, 25), "First harvester origin")
	assert_eq(first.inventory_logs, 7, "First harvester inventory_logs")

	var second: HarvesterInstance = harvesters[1] as HarvesterInstance
	assert_eq(second.origin, Vector2i(50, 60), "Second harvester origin")
	assert_eq(second.inventory_logs, 0, "Second harvester inventory_logs")

func test_import_empty_array_does_nothing():
	manager.import_harvesters("planet_1", [])
	var harvesters: Array = manager.harvesters_by_planet.get("planet_1", [])
	assert_eq(harvesters.size(), 0, "No harvesters should be created from empty data")

func test_roundtrip_export_import():
	var m1 := manager.place_harvester(Vector2i(8, 12), "p1")
	m1.inventory_logs = 99

	var exported := manager.export_harvesters("p1")

	# Create a new manager and import
	var manager2 := HarvesterManager.new()
	manager2.import_harvesters("p1", exported)

	var harvesters: Array = manager2.harvesters_by_planet.get("p1", [])
	assert_eq(harvesters.size(), 1, "Roundtrip should produce one harvester")
	var restored: HarvesterInstance = harvesters[0] as HarvesterInstance
	assert_eq(restored.origin, Vector2i(8, 12), "Roundtrip origin preserved")
	assert_eq(restored.inventory_logs, 99, "Roundtrip inventory_logs preserved")
	manager2.free()
