extends "res://tests/test_base.gd"

## Tests for village resource gathering improvements:
## - Dynamic gatherer cap scaling with population
## - Scouting state and resource discovery
## - PlanetMapSystem berry/dead tree detection helpers


const LOG_TAG := "TEST_RESOURCE_GATHERING"


# --- Helpers ---

func _make_villager_system() -> VillagerSystem:
	return VillagerSystem.new()


func _make_village(pop: int, adult_count: int = -1) -> VillageInstance:
	var village = VillageInstance.new()
	village.initialize("test_v", "planet_1", "mississippi_early", {
		"starting_era": "nomadic",
		"starting_skills": ["foraging"],
		"starting_political_traits": {"cohesion": 0.5},
		"names_male": ["Man"],
		"names_female": ["Woman"],
	})
	village.individuals.clear()
	var adults_to_make := adult_count if adult_count >= 0 else pop
	for i in range(pop):
		var person = PersonInstance.new()
		var sex = PersonInstance.Sex.MALE if i % 2 == 0 else PersonInstance.Sex.FEMALE
		var age = 25 if i < adults_to_make else 5
		person.initialize("p_%d" % i, "Person%d" % i, sex, age, ["foraging"])
		village.individuals.append(person)
	return village


func _make_person() -> PersonInstance:
	var person = PersonInstance.new()
	var skills: Array[String] = ["foraging", "hunting", "shelter_building"]
	person.initialize("test_001", "Tester", PersonInstance.Sex.MALE, 25, skills)
	return person


func _make_villager(sys: VillagerSystem, village_id: String = "v1") -> VillagerSystem.VillagerData:
	var v = VillagerSystem.VillagerData.new()
	v.person = _make_person()
	v.village_id = village_id
	v.container_pos = Vector2(100, 100)
	return v


# ==========================================================================
# Dynamic Gatherer Cap
# ==========================================================================

func test_base_gatherer_cap_small_village():
	var sys = _make_villager_system()
	var village = _make_village(4, 4)
	sys._villages_by_id["v1"] = village
	var cap := sys._max_gatherers_for("v1")
	assert_eq(cap, VillagerSystem.BASE_GATHERERS_PER_RESOURCE,
		"Village with 4 adults should get base cap")


func test_gatherer_cap_scales_with_adults():
	var sys = _make_villager_system()
	var village = _make_village(12, 12)
	sys._villages_by_id["v1"] = village
	var cap := sys._max_gatherers_for("v1")
	# 12 adults: base 2 + (12-4)/4 = 2 + 2 = 4
	assert_eq(cap, 4, "Village with 12 adults should get cap of 4")


func test_gatherer_cap_large_village():
	var sys = _make_villager_system()
	var village = _make_village(24, 24)
	sys._villages_by_id["v1"] = village
	var cap := sys._max_gatherers_for("v1")
	# 24 adults: base 2 + (24-4)/4 = 2 + 5 = 7
	assert_eq(cap, 7, "Village with 24 adults should get cap of 7")


func test_gatherer_cap_unknown_village():
	var sys = _make_villager_system()
	var cap := sys._max_gatherers_for("nonexistent")
	assert_eq(cap, VillagerSystem.BASE_GATHERERS_PER_RESOURCE,
		"Unknown village should get base cap")


func test_gatherer_cap_with_children():
	var sys = _make_villager_system()
	# 16 total, only 8 adults
	var village = _make_village(16, 8)
	sys._villages_by_id["v1"] = village
	var cap := sys._max_gatherers_for("v1")
	# 8 adults: base 2 + (8-4)/4 = 2 + 1 = 3
	assert_eq(cap, 3, "Gatherer cap should scale with adults, not total pop")


# ==========================================================================
# Scouting State
# ==========================================================================

func test_scouting_state_exists():
	assert_eq(VillagerSystem.STATE_SCOUTING, 6, "STATE_SCOUTING should be 6")


func test_scout_state_name():
	var sys = _make_villager_system()
	var v = _make_villager(sys)
	v.state = VillagerSystem.STATE_SCOUTING
	var name := sys._state_name(v)
	assert_eq(name, "Scouting", "Scouting state should display as 'Scouting'")


func test_scout_constants():
	assert_true(VillagerSystem.SCOUT_RADIUS > VillagerSystem.WANDER_RADIUS,
		"Scout radius should be larger than wander radius")
	assert_true(VillagerSystem.SCOUT_CHANCE > 0.0 and VillagerSystem.SCOUT_CHANCE < 1.0,
		"Scout chance should be a probability")
	assert_true(VillagerSystem.SCOUT_DISCOVERY_RADIUS > 0,
		"Scout discovery radius should be positive")


func test_check_scout_discoveries_no_crash_without_planet_map():
	var sys = _make_villager_system()
	sys._visited_tiles["v1"] = {}
	sys._berry_grid_positions["v1"] = Vector2i(50, 50)
	sys._berry_positions["v1"] = Vector2(400, 400)
	sys._firewood_grid_positions["v1"] = Vector2i(60, 60)
	sys._firewood_positions["v1"] = Vector2(480, 480)
	sys._camp_grid_positions["v1"] = Vector2i(40, 40)
	var v = _make_villager(sys)
	# No planet_map_system — should return early without crash
	sys._check_scout_discoveries(v, null)
	assert_true(true, "_check_scout_discoveries handles null planet_map_system")


func test_seed_path_to_adds_tiles():
	var sys = _make_villager_system()
	# Set up pathfinder and cache (no planet_map_system = uniform cost)
	var pf := TerrainPathfinder.new(null)
	sys._pathfinder = pf
	sys._path_caches["v1"] = VillagePathCache.new(pf)
	sys._seed_path_to("v1", Vector2i(0, 0), Vector2i(5, 0))
	var tiles: Dictionary = sys._path_caches["v1"].get_all_trail_tiles()
	assert_true(tiles.size() > 0, "Should add tiles along path")
	assert_true(tiles.has(Vector2i(0, 0)), "Path should include start")
	assert_true(tiles.has(Vector2i(5, 0)), "Path should include end")


# ==========================================================================
# Forageable Plant Detection (ForestSpecies)
# ==========================================================================

func test_raspberry_detection_deterministic():
	var pos := Vector2i(50, 50)
	var result1 := ForestSpecies.is_raspberry_position(pos)
	var result2 := ForestSpecies.is_raspberry_position(pos)
	assert_eq(result1, result2, "Raspberry detection should be deterministic")


func test_raspberry_exists_somewhere():
	var count := 0
	for x in range(200):
		for y in range(5):
			if ForestSpecies.is_raspberry_position(Vector2i(x, y)):
				count += 1
	assert_true(count > 0, "Should find at least some raspberry bushes in a large area")


func test_raspberry_higher_chance_near_dead_trees():
	assert_true(ForestSpecies.RASPBERRY_CHANCE_DEAD > ForestSpecies.RASPBERRY_CHANCE_LIVE,
		"Raspberry chance near dead trees should be higher than under live canopy")


func test_skill_for_carrying_food():
	var sys = _make_villager_system()
	var skill := sys._skill_for_carrying("food")
	assert_eq(skill, "foraging", "Food should use foraging skill")


func test_skill_for_carrying_firewood():
	var sys = _make_villager_system()
	var skill := sys._skill_for_carrying("firewood")
	assert_eq(skill, "shelter_building", "Firewood should use shelter_building skill")
