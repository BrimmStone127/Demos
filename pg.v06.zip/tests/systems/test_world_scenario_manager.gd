extends "res://tests/test_base.gd"

## Tests for WorldScenarioManager
## Verifies deterministic scenario selection and mapping

func test_initialization():
	var manager = WorldScenarioManager.new()
	manager.initialize(12345)
	# Should not crash
	assert_true(true)

func test_sector_scenario_deterministic():
	var manager = WorldScenarioManager.new()
	manager.initialize(12345)

	# Same galaxy_seed + sector_index = same result
	var result1 = manager.get_sector_scenario(100)
	var result2 = manager.get_sector_scenario(100)
	assert_eq(result1, result2, "Same inputs should produce same scenario")

func test_sector_scenario_different_seeds():
	var manager1 = WorldScenarioManager.new()
	manager1.initialize(11111)
	var manager2 = WorldScenarioManager.new()
	manager2.initialize(22222)

	# Different galaxy seeds should not always produce same result
	var same_count = 0
	for i in range(100):
		if manager1.get_sector_scenario(i) == manager2.get_sector_scenario(i):
			same_count += 1
	# They shouldn't ALL be the same (statistically impossible)
	assert_lt(same_count, 100, "Different galaxy seeds should produce different scenarios")

func test_opossum_sector_frequency():
	var manager = WorldScenarioManager.new()
	manager.initialize(42)

	var opossum_count = 0
	var total = 1000
	for i in range(total):
		if manager.get_sector_scenario(i) == WorldScenarioManager.SCENARIO_OPOSSUM_SECTOR:
			opossum_count += 1

	# ~1 in 8 sectors should be opossum (12.5%). Allow wide tolerance for randomness.
	assert_gt(opossum_count, 50, "Should have >50 opossum sectors in 1000 (expected ~125)")
	assert_lt(opossum_count, 250, "Should have <250 opossum sectors in 1000 (expected ~125)")

func test_non_opossum_returns_empty():
	var manager = WorldScenarioManager.new()
	manager.initialize(42)

	# Find a non-opossum sector
	for i in range(100):
		var scenario = manager.get_sector_scenario(i)
		if scenario != WorldScenarioManager.SCENARIO_OPOSSUM_SECTOR:
			assert_eq(scenario, "", "Non-opossum sector should return empty string")
			return
	# If all 100 are opossum, that's a failure in itself
	assert_true(false, "Should find at least one non-opossum sector in 100")

func test_village_scenario_id_opossum():
	var village_id = WorldScenarioManager.get_village_scenario_id(WorldScenarioManager.SCENARIO_OPOSSUM_SECTOR)
	assert_eq(village_id, "opossum", "Opossum sector should map to 'opossum' village scenario")

func test_village_scenario_id_default():
	var village_id = WorldScenarioManager.get_village_scenario_id("")
	assert_eq(village_id, "mississippi_early", "Empty scenario should map to mississippi_early")

func test_village_scenario_id_unknown():
	var village_id = WorldScenarioManager.get_village_scenario_id("nonexistent")
	assert_eq(village_id, "mississippi_early", "Unknown scenario should default to mississippi_early")
