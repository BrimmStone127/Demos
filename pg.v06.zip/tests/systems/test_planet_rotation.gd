# test_planet_rotation.gd
# Tests for planet axial rotation and day/night cycles
extends "res://tests/test_base.gd"

const LOG_TAG := "TEST_PLANET_ROTATION"

var test_planet: Planet
var test_texture: Texture2D

func before_each():
	super.before_each()
	# Create a simple test texture
	test_texture = PlaceholderTexture2D.new()
	test_texture.size = Vector2(32, 32)

func after_each():
	if test_planet:
		if is_instance_valid(test_planet):
			autofree(test_planet)
		test_planet = null
	super.after_each()

func test_rotation_period_calculation():
	"""Test that rotation period is calculated correctly for different planet types."""
	var props = {
		"scale_range": Vector2(0.05, 0.1),
		"colors": [Color.WHITE]
	}

	# Test rocky small planet (0.5-1.0 days)
	var rocky_small = Planet.new(test_texture, 100.0, 0.02, PlanetEnums.PlanetType.ROCKY_SMALL, props, false)
	autofree(rocky_small)
	assert_gte(rocky_small.rotation_period, 0.5, "Rocky small rotation period should be >= 0.5")
	assert_lte(rocky_small.rotation_period, 1.0, "Rocky small rotation period should be <= 1.0")

	# Test gas giant (0.3-0.6 days)
	var gas_giant = Planet.new(test_texture, 150.0, 0.02, PlanetEnums.PlanetType.GAS_GIANT, props, true)
	autofree(gas_giant)
	assert_gte(gas_giant.rotation_period, 0.3, "Gas giant rotation period should be >= 0.3")
	assert_lte(gas_giant.rotation_period, 0.6, "Gas giant rotation period should be <= 0.6")

	# Test super earth (0.8-1.5 days)
	var super_earth = Planet.new(test_texture, 125.0, 0.02, PlanetEnums.PlanetType.SUPER_EARTH, props, true)
	autofree(super_earth)
	assert_gte(super_earth.rotation_period, 0.8, "Super earth rotation period should be >= 0.8")
	assert_lte(super_earth.rotation_period, 1.5, "Super earth rotation period should be <= 1.5")

func test_rotation_speed_calculation():
	"""Test that rotation speed (deg/sec) is calculated correctly from period."""
	var props = {
		"scale_range": Vector2(0.05, 0.1),
		"colors": [Color.WHITE]
	}

	var planet = Planet.new(test_texture, 100.0, 0.02, PlanetEnums.PlanetType.ROCKY_MEDIUM, props, false)
	autofree(planet)

	# rotation_speed should be 360 / (rotation_period * 60)
	const SECONDS_PER_GAME_DAY = 60.0
	var expected_speed = 360.0 / (planet.rotation_period * SECONDS_PER_GAME_DAY)
	assert_eq(planet.rotation_speed, expected_speed, "Rotation speed should match expected calculation")

func test_rotation_angle_advances():
	"""Test that rotation angle increases over time."""
	var props = {
		"scale_range": Vector2(0.05, 0.1),
		"colors": [Color.WHITE]
	}

	test_planet = Planet.new(test_texture, 100.0, 0.02, PlanetEnums.PlanetType.ROCKY_MEDIUM, props, false)
	autofree(test_planet)

	var initial_angle = test_planet.rotation_angle
	var delta = 1.0  # 1 second

	# Manually advance rotation (simulating _process)
	test_planet.rotation_angle += test_planet.rotation_speed * delta

	assert_gt(test_planet.rotation_angle, initial_angle, "Rotation angle should increase")

func test_rotation_wraps_at_360():
	"""Test that rotation angle wraps from 360 back to 0."""
	var props = {
		"scale_range": Vector2(0.05, 0.1),
		"colors": [Color.WHITE]
	}

	test_planet = Planet.new(test_texture, 100.0, 0.02, PlanetEnums.PlanetType.ROCKY_MEDIUM, props, false)
	autofree(test_planet)

	# Set angle near 360
	test_planet.rotation_angle = 359.5

	# Advance enough to wrap
	test_planet.rotation_angle += 1.0

	# Simulate wrap logic from _process
	if test_planet.rotation_angle >= 360.0:
		test_planet.rotation_angle -= 360.0

	assert_lt(test_planet.rotation_angle, 360.0, "Rotation angle should wrap below 360")
	assert_gte(test_planet.rotation_angle, 0.0, "Rotation angle should be >= 0")

func test_get_local_time_of_day():
	"""Test local time of day calculation."""
	var props = {
		"scale_range": Vector2(0.05, 0.1),
		"colors": [Color.WHITE]
	}

	test_planet = Planet.new(test_texture, 100.0, 0.02, PlanetEnums.PlanetType.ROCKY_MEDIUM, props, false)
	autofree(test_planet)

	# Midnight (0 degrees)
	test_planet.rotation_angle = 0.0
	assert_eq(test_planet.get_local_time_of_day(), 0.0, "0 degrees should be midnight (0.0)")

	# Noon (180 degrees)
	test_planet.rotation_angle = 180.0
	var noon_time = test_planet.get_local_time_of_day()
	assert_eq(noon_time, 0.5, "180 degrees should be noon (0.5)")

	# Full rotation (360 degrees = back to midnight)
	test_planet.rotation_angle = 360.0
	var wrapped_time = fmod(test_planet.rotation_angle / 360.0, 1.0)
	assert_eq(wrapped_time, 0.0, "360 degrees should wrap to midnight (0.0)")

func test_is_daytime():
	"""Test daytime detection (6am-6pm = 0.25-0.75)."""
	var props = {
		"scale_range": Vector2(0.05, 0.1),
		"colors": [Color.WHITE]
	}

	test_planet = Planet.new(test_texture, 100.0, 0.02, PlanetEnums.PlanetType.ROCKY_MEDIUM, props, false)
	autofree(test_planet)

	# Midnight (0 degrees) - nighttime
	test_planet.rotation_angle = 0.0
	assert_false(test_planet.is_daytime(), "Midnight should be nighttime")

	# 6am (90 degrees) - start of day
	test_planet.rotation_angle = 90.0
	assert_true(test_planet.is_daytime(), "6am should be daytime")

	# Noon (180 degrees) - daytime
	test_planet.rotation_angle = 180.0
	assert_true(test_planet.is_daytime(), "Noon should be daytime")

	# 6pm (270 degrees) - end of day
	test_planet.rotation_angle = 270.0
	assert_false(test_planet.is_daytime(), "6pm should be nighttime")

func test_deterministic_rotation_period():
	"""Test that planets with same semi_major_axis get same rotation period."""
	var props = {
		"scale_range": Vector2(0.05, 0.1),
		"colors": [Color.WHITE]
	}

	var planet1 = Planet.new(test_texture, 100.0, 0.02, PlanetEnums.PlanetType.ROCKY_MEDIUM, props, false)
	autofree(planet1)

	var planet2 = Planet.new(test_texture, 100.0, 0.02, PlanetEnums.PlanetType.ROCKY_MEDIUM, props, false)
	autofree(planet2)

	# Same semi_major_axis should produce same rotation period (deterministic)
	assert_eq(planet1.rotation_period, planet2.rotation_period, "Same distance should produce same rotation period")

func test_different_planets_different_rotation():
	"""Test that planets at different distances get different rotation periods."""
	var props = {
		"scale_range": Vector2(0.05, 0.1),
		"colors": [Color.WHITE]
	}

	var planet1 = Planet.new(test_texture, 100.0, 0.02, PlanetEnums.PlanetType.ROCKY_MEDIUM, props, false)
	autofree(planet1)

	var planet2 = Planet.new(test_texture, 200.0, 0.02, PlanetEnums.PlanetType.ROCKY_MEDIUM, props, false)
	autofree(planet2)

	# Different semi_major_axis should produce different rotation periods
	assert_ne(planet1.rotation_period, planet2.rotation_period, "Different distances should produce different rotation periods")
