extends "res://tests/test_base.gd"

## Unit tests for ProceduralTerrainSource class
## Tests procedural terrain generation patterns

func test_initialization():
	var source = ProceduralTerrainSource.new(Vector2i(10, 10), ProceduralTerrainSource.Pattern.GRADIENT_X)
	assert_not_null(source, "Source should initialize")

func test_get_bounds():
	var source = ProceduralTerrainSource.new(Vector2i(20, 30), ProceduralTerrainSource.Pattern.GRADIENT_X)
	var bounds = source.get_bounds()

	assert_eq(bounds.position, Vector2i.ZERO, "Bounds should start at origin")
	assert_eq(bounds.size, Vector2i(20, 30), "Bounds should match map size")

func test_get_tile_size():
	var source = ProceduralTerrainSource.new(Vector2i(10, 10), ProceduralTerrainSource.Pattern.GRADIENT_X)
	var tile_size = source.get_tile_size()

	# 10x10 chunks * 64 tiles/chunk = 640x640 tiles
	assert_eq(tile_size, Vector2i(640, 640), "Tile size should be chunks * 64")

func test_is_valid_chunk():
	var source = ProceduralTerrainSource.new(Vector2i(5, 5), ProceduralTerrainSource.Pattern.GRADIENT_X)

	assert_true(source.is_valid_chunk(Vector2i(0, 0)), "Origin chunk is valid")
	assert_true(source.is_valid_chunk(Vector2i(4, 4)), "Max chunk is valid")
	assert_true(source.is_valid_chunk(Vector2i(2, 3)), "Middle chunk is valid")

	assert_false(source.is_valid_chunk(Vector2i(-1, 0)), "Negative chunk invalid")
	assert_false(source.is_valid_chunk(Vector2i(5, 0)), "Out of bounds X invalid")
	assert_false(source.is_valid_chunk(Vector2i(0, 5)), "Out of bounds Y invalid")

func test_load_chunk_returns_correct_chunk():
	var source = ProceduralTerrainSource.new(Vector2i(10, 10), ProceduralTerrainSource.Pattern.GRADIENT_X)
	var chunk = source.load_chunk(Vector2i(3, 4))

	assert_not_null(chunk, "Chunk should load")
	assert_eq(chunk.chunk_pos, Vector2i(3, 4), "Chunk position should match requested")

func test_load_chunk_out_of_bounds():
	var source = ProceduralTerrainSource.new(Vector2i(5, 5), ProceduralTerrainSource.Pattern.GRADIENT_X)
	var chunk = source.load_chunk(Vector2i(10, 10))

	assert_null(chunk, "Out of bounds chunk should return null")

func test_gradient_x_pattern():
	# Small 2x2 chunk map for testing (128x128 tiles total)
	var source = ProceduralTerrainSource.new(Vector2i(2, 2), ProceduralTerrainSource.Pattern.GRADIENT_X)

	# Load chunks and verify gradient
	var chunk_left = source.load_chunk(Vector2i(0, 0))  # West side
	var chunk_right = source.load_chunk(Vector2i(1, 0))  # East side

	# Left chunk should have lower elevations (western side)
	var left_elev = chunk_left.get_elevation(Vector2i(0, 0))

	# Right chunk should have higher elevations (eastern side)
	var right_elev = chunk_right.get_elevation(Vector2i(63, 0))

	assert_true(left_elev < right_elev, "East-west gradient: left < right (%.3f < %.3f)" % [left_elev, right_elev])

func test_gradient_y_pattern():
	# Small 2x2 chunk map for testing (128x128 tiles total)
	var source = ProceduralTerrainSource.new(Vector2i(2, 2), ProceduralTerrainSource.Pattern.GRADIENT_Y)

	# Load chunks and verify gradient
	var chunk_north = source.load_chunk(Vector2i(0, 0))  # North side
	var chunk_south = source.load_chunk(Vector2i(0, 1))  # South side

	# North chunk should have lower elevations
	var north_elev = chunk_north.get_elevation(Vector2i(0, 0))

	# South chunk should have higher elevations
	var south_elev = chunk_south.get_elevation(Vector2i(0, 63))

	assert_true(north_elev < south_elev, "North-south gradient: north < south (%.3f < %.3f)" % [north_elev, south_elev])

func test_gradient_radial_pattern():
	# 4x4 chunk map, center should be low elevation, edges high
	var source = ProceduralTerrainSource.new(Vector2i(4, 4), ProceduralTerrainSource.Pattern.GRADIENT_RADIAL)

	# Center chunk
	var chunk_center = source.load_chunk(Vector2i(2, 2))
	var center_elev = chunk_center.get_elevation(Vector2i(32, 32))

	# Corner chunk
	var chunk_corner = source.load_chunk(Vector2i(0, 0))
	var corner_elev = chunk_corner.get_elevation(Vector2i(0, 0))

	assert_true(center_elev < corner_elev, "Radial gradient: center < corner (%.3f < %.3f)" % [center_elev, corner_elev])

func test_checkerboard_pattern():
	var source = ProceduralTerrainSource.new(Vector2i(4, 4), ProceduralTerrainSource.Pattern.CHECKERBOARD)

	# Checkerboard: (x+y) % 2 determines high/low
	var chunk_00 = source.load_chunk(Vector2i(0, 0))  # Even sum = high
	var chunk_01 = source.load_chunk(Vector2i(0, 1))  # Odd sum = low
	var chunk_10 = source.load_chunk(Vector2i(1, 0))  # Odd sum = low
	var chunk_11 = source.load_chunk(Vector2i(1, 1))  # Even sum = high

	var elev_00 = chunk_00.get_elevation(Vector2i(0, 0))
	var elev_01 = chunk_01.get_elevation(Vector2i(0, 0))
	var elev_10 = chunk_10.get_elevation(Vector2i(0, 0))
	var elev_11 = chunk_11.get_elevation(Vector2i(0, 0))

	# High elevation chunks
	assert_eq(elev_00, 0.8, "Chunk (0,0) should be high")
	assert_eq(elev_11, 0.8, "Chunk (1,1) should be high")

	# Low elevation chunks
	assert_eq(elev_01, 0.2, "Chunk (0,1) should be low")
	assert_eq(elev_10, 0.2, "Chunk (1,0) should be low")

func test_entire_chunk_populated():
	var source = ProceduralTerrainSource.new(Vector2i(5, 5), ProceduralTerrainSource.Pattern.GRADIENT_X)
	var chunk = source.load_chunk(Vector2i(2, 2))

	# Check all corners are populated
	assert_not_null(chunk.get_elevation(Vector2i(0, 0)), "Top-left populated")
	assert_not_null(chunk.get_elevation(Vector2i(63, 0)), "Top-right populated")
	assert_not_null(chunk.get_elevation(Vector2i(0, 63)), "Bottom-left populated")
	assert_not_null(chunk.get_elevation(Vector2i(63, 63)), "Bottom-right populated")

	# Check middle
	assert_not_null(chunk.get_elevation(Vector2i(32, 32)), "Center populated")

func test_tile_types_assigned():
	var source = ProceduralTerrainSource.new(Vector2i(5, 5), ProceduralTerrainSource.Pattern.GRADIENT_X)
	var chunk = source.load_chunk(Vector2i(0, 0))

	# Low elevation should be water/sand
	var low_type = chunk.get_tile_type(Vector2i(0, 0))
	assert_true(
		low_type == PlanetMapTileConfig.TileType.WATER or low_type == PlanetMapTileConfig.TileType.SAND,
		"Low elevation should be water or sand"
	)

	# Check type is valid enum
	assert_true(low_type >= 0, "Tile type should be valid enum")

func test_static_helper_tile_to_chunk():
	assert_eq(TerrainDataSource.tile_to_chunk(Vector2i(0, 0)), Vector2i(0, 0), "Tile (0,0) = Chunk (0,0)")
	assert_eq(TerrainDataSource.tile_to_chunk(Vector2i(63, 63)), Vector2i(0, 0), "Tile (63,63) = Chunk (0,0)")
	assert_eq(TerrainDataSource.tile_to_chunk(Vector2i(64, 64)), Vector2i(1, 1), "Tile (64,64) = Chunk (1,1)")
	assert_eq(TerrainDataSource.tile_to_chunk(Vector2i(320, 640)), Vector2i(5, 10), "Tile (320,640) = Chunk (5,10)")

func test_static_helper_chunk_to_tile():
	assert_eq(TerrainDataSource.chunk_to_tile(Vector2i(0, 0)), Vector2i(0, 0), "Chunk (0,0) = Tile (0,0)")
	assert_eq(TerrainDataSource.chunk_to_tile(Vector2i(1, 1)), Vector2i(64, 64), "Chunk (1,1) = Tile (64,64)")
	assert_eq(TerrainDataSource.chunk_to_tile(Vector2i(5, 10)), Vector2i(320, 640), "Chunk (5,10) = Tile (320,640)")

func test_consistent_chunk_generation():
	var source = ProceduralTerrainSource.new(Vector2i(10, 10), ProceduralTerrainSource.Pattern.GRADIENT_X)

	# Load same chunk twice
	var chunk1 = source.load_chunk(Vector2i(3, 4))
	var chunk2 = source.load_chunk(Vector2i(3, 4))

	# Should generate identical data
	assert_eq(chunk1.get_elevation(Vector2i(10, 20)), chunk2.get_elevation(Vector2i(10, 20)), "Same chunk generates identical data")
