extends "res://tests/test_base.gd"

## Unit tests for ChunkTileData class
## Tests coordinate conversion, bounds checking, and data storage

func test_initialization():
	var chunk = ChunkTileData.new(Vector2i(5, 10))
	assert_eq(chunk.chunk_pos, Vector2i(5, 10), "Chunk position should be set")
	# Flat packed arrays: 64*64 = 4096 elements
	assert_eq(chunk.elevations.size(), 4096, "Should have 4096 elevation entries")
	assert_eq(chunk.tile_types.size(), 4096, "Should have 4096 tile type entries")

func test_default_values():
	var chunk = ChunkTileData.new(Vector2i(0, 0))
	assert_eq(chunk.get_elevation(Vector2i(0, 0)), 0.5, "Default elevation should be 0.5")
	assert_eq(chunk.get_tile_type(Vector2i(0, 0)), PlanetMapTileConfig.TileType.ROCK, "Default type should be ROCK")

func test_coordinate_conversion_origin():
	var chunk = ChunkTileData.new(Vector2i(0, 0))

	# Local (0,0) = Absolute (0,0)
	assert_eq(chunk.get_absolute_tile_pos(Vector2i(0, 0)), Vector2i(0, 0), "Origin local to absolute")

	# Local (63,63) = Absolute (63,63)
	assert_eq(chunk.get_absolute_tile_pos(Vector2i(63, 63)), Vector2i(63, 63), "Max local to absolute")

func test_coordinate_conversion_offset_chunk():
	var chunk = ChunkTileData.new(Vector2i(5, 10))

	# Chunk at (5, 10) means tiles start at (320, 640)
	assert_eq(chunk.get_absolute_tile_pos(Vector2i(0, 0)), Vector2i(320, 640), "Offset chunk origin")
	assert_eq(chunk.get_absolute_tile_pos(Vector2i(10, 20)), Vector2i(330, 660), "Offset chunk middle")
	assert_eq(chunk.get_absolute_tile_pos(Vector2i(63, 63)), Vector2i(383, 703), "Offset chunk max")

func test_absolute_to_local_conversion():
	var chunk = ChunkTileData.new(Vector2i(5, 10))

	# Absolute (320, 640) = Local (0, 0)
	assert_eq(chunk.get_local_tile_pos(Vector2i(320, 640)), Vector2i(0, 0), "Absolute to local origin")

	# Absolute (350, 670) = Local (30, 30)
	assert_eq(chunk.get_local_tile_pos(Vector2i(350, 670)), Vector2i(30, 30), "Absolute to local middle")

	# Out of chunk bounds returns (-1, -1)
	assert_eq(chunk.get_local_tile_pos(Vector2i(100, 100)), Vector2i(-1, -1), "Out of chunk bounds")

func test_is_valid_local_pos():
	var chunk = ChunkTileData.new(Vector2i(0, 0))

	assert_true(chunk.is_valid_local_pos(Vector2i(0, 0)), "Origin is valid")
	assert_true(chunk.is_valid_local_pos(Vector2i(63, 63)), "Max corner is valid")
	assert_true(chunk.is_valid_local_pos(Vector2i(32, 32)), "Middle is valid")

	assert_false(chunk.is_valid_local_pos(Vector2i(-1, 0)), "Negative X invalid")
	assert_false(chunk.is_valid_local_pos(Vector2i(0, -1)), "Negative Y invalid")
	assert_false(chunk.is_valid_local_pos(Vector2i(64, 0)), "X=64 invalid (max is 63)")
	assert_false(chunk.is_valid_local_pos(Vector2i(0, 64)), "Y=64 invalid (max is 63)")

func test_elevation_get_set():
	var chunk = ChunkTileData.new(Vector2i(0, 0))

	chunk.set_elevation(Vector2i(10, 20), 0.75)
	assert_almost_eq(chunk.get_elevation(Vector2i(10, 20)), 0.75, 0.001, "Get/set elevation")

	# Clamping
	chunk.set_elevation(Vector2i(5, 5), 1.5)  # Over 1.0
	assert_almost_eq(chunk.get_elevation(Vector2i(5, 5)), 1.0, 0.001, "Elevation clamped to 1.0")

	chunk.set_elevation(Vector2i(6, 6), -0.5)  # Under 0.0
	assert_almost_eq(chunk.get_elevation(Vector2i(6, 6)), 0.0, 0.001, "Elevation clamped to 0.0")

func test_tile_type_get_set():
	var chunk = ChunkTileData.new(Vector2i(0, 0))

	chunk.set_tile_type(Vector2i(15, 25), PlanetMapTileConfig.TileType.GRASS_0)
	assert_eq(chunk.get_tile_type(Vector2i(15, 25)), PlanetMapTileConfig.TileType.GRASS_0, "Get/set tile type")

func test_features_sparse_storage():
	var chunk = ChunkTileData.new(Vector2i(0, 0))

	# Initially no features
	assert_eq(chunk.get_feature_count(), 0, "No features initially")
	assert_null(chunk.get_feature(Vector2i(10, 10)), "No feature at position")

	# Add feature
	chunk.set_feature(Vector2i(10, 10), "TREE")
	assert_eq(chunk.get_feature_count(), 1, "One feature added")
	assert_eq(chunk.get_feature(Vector2i(10, 10)), "TREE", "Feature retrieved")

	# Remove feature
	chunk.set_feature(Vector2i(10, 10), null)
	assert_eq(chunk.get_feature_count(), 0, "Feature removed")
	assert_null(chunk.get_feature(Vector2i(10, 10)), "Feature is null after removal")

func test_get_absolute_bounds():
	var chunk1 = ChunkTileData.new(Vector2i(0, 0))
	var bounds1 = chunk1.get_absolute_bounds()
	assert_eq(bounds1.position, Vector2i(0, 0), "Origin chunk starts at (0,0)")
	assert_eq(bounds1.size, Vector2i(64, 64), "Chunk size is 64x64")

	var chunk2 = ChunkTileData.new(Vector2i(5, 10))
	var bounds2 = chunk2.get_absolute_bounds()
	assert_eq(bounds2.position, Vector2i(320, 640), "Offset chunk starts at (320, 640)")
	assert_eq(bounds2.size, Vector2i(64, 64), "Chunk size is 64x64")

func test_invalid_position_handling():
	var chunk = ChunkTileData.new(Vector2i(0, 0))

	# Setting invalid position should log warning but not crash
	chunk.set_elevation(Vector2i(-1, 0), 0.5)
	chunk.set_tile_type(Vector2i(64, 0), PlanetMapTileConfig.TileType.ROCK)
	chunk.set_feature(Vector2i(0, -1), "TEST")

	# Getting invalid position returns defaults
	assert_eq(chunk.get_elevation(Vector2i(-1, 0)), 0.5, "Invalid get_elevation returns default")
	assert_eq(chunk.get_tile_type(Vector2i(64, 0)), PlanetMapTileConfig.TileType.ROCK, "Invalid get_tile_type returns ROCK")

func test_chunk_data_independence():
	var chunk1 = ChunkTileData.new(Vector2i(0, 0))
	var chunk2 = ChunkTileData.new(Vector2i(1, 0))

	chunk1.set_elevation(Vector2i(10, 10), 0.3)
	chunk2.set_elevation(Vector2i(10, 10), 0.9)

	# PackedFloat32Array uses 32-bit floats, so values have limited precision
	assert_almost_eq(chunk1.get_elevation(Vector2i(10, 10)), 0.3, 0.001, "Chunk 1 elevation independent")
	assert_almost_eq(chunk2.get_elevation(Vector2i(10, 10)), 0.9, 0.001, "Chunk 2 elevation independent")
