extends "res://tests/test_base.gd"

# Tests for PlanetMapCoordinates utility class

func test_round_vec2():
	var result = PlanetMapCoordinates.round_vec2(Vector2(1.4, 2.6))
	assert_eq(result, Vector2(1, 3))

func test_round_vec2_negative():
	var result = PlanetMapCoordinates.round_vec2(Vector2(-1.7, -0.3))
	assert_eq(result, Vector2(-2, 0))

func test_grid_to_world_origin():
	var result = PlanetMapCoordinates.grid_to_world(Vector2i(0, 0))
	assert_eq(result, Vector2(0, 0))

func test_grid_to_world_positive():
	# cell (1, 0) should be offset right and down
	var result = PlanetMapCoordinates.grid_to_world(Vector2i(1, 0))
	assert_eq(result.x, PlanetMapTileConfig.TILE_OFFSET.x)
	assert_eq(result.y, PlanetMapTileConfig.TILE_OFFSET.y)

func test_grid_to_world_isometric_pattern():
	# In isometric: moving +x goes right-down, moving +y goes left-down
	var cell_x = PlanetMapCoordinates.grid_to_world(Vector2i(1, 0))
	var cell_y = PlanetMapCoordinates.grid_to_world(Vector2i(0, 1))
	# x direction should have positive x component
	assert_gt(cell_x.x, 0.0, "Moving +x should increase world x")
	# y direction should have negative x component
	assert_lt(cell_y.x, 0.0, "Moving +y should decrease world x")
	# Both should increase world y
	assert_gt(cell_x.y, 0.0, "Moving +x should increase world y")
	assert_gt(cell_y.y, 0.0, "Moving +y should increase world y")

func test_world_to_grid_origin():
	var result = PlanetMapCoordinates.world_to_grid(Vector2(0, 0))
	assert_eq(result, Vector2i(0, 0))

func test_world_to_grid_roundtrip():
	# Converting grid->world->grid should return the original
	var original = Vector2i(5, 3)
	var world = PlanetMapCoordinates.grid_to_world(original)
	var back = PlanetMapCoordinates.world_to_grid(world)
	assert_eq(back, original)

func test_world_to_grid_roundtrip_various():
	var test_cells = [Vector2i(0, 0), Vector2i(10, 10), Vector2i(3, 7), Vector2i(63, 63)]
	for cell in test_cells:
		var world = PlanetMapCoordinates.grid_to_world(cell)
		var back = PlanetMapCoordinates.world_to_grid(world)
		assert_eq(back, cell, "Roundtrip failed for cell %s" % cell)

func test_is_valid_grid_position_valid():
	assert_true(PlanetMapCoordinates.is_valid_grid_position(Vector2i(0, 0)))
	assert_true(PlanetMapCoordinates.is_valid_grid_position(Vector2i(32, 32)))
	assert_true(PlanetMapCoordinates.is_valid_grid_position(Vector2i(63, 63)))

func test_is_valid_grid_position_invalid():
	assert_false(PlanetMapCoordinates.is_valid_grid_position(Vector2i(-1, 0)))
	assert_false(PlanetMapCoordinates.is_valid_grid_position(Vector2i(0, -1)))
	assert_false(PlanetMapCoordinates.is_valid_grid_position(Vector2i(64, 0)))
	assert_false(PlanetMapCoordinates.is_valid_grid_position(Vector2i(0, 64)))

func test_get_map_center_world_position():
	var center = PlanetMapCoordinates.get_map_center_world_position()
	# Center should be non-zero for a 64x64 map
	assert_ne(center, Vector2(0, 0), "Center should not be at origin")

func test_get_map_center_custom_size():
	var small_center = PlanetMapCoordinates.get_map_center_world_position(Vector2i(10, 10))
	var large_center = PlanetMapCoordinates.get_map_center_world_position(Vector2i(100, 100))
	# Larger map should have center further from origin
	assert_gt(large_center.y, small_center.y, "Larger map should have larger center y")

func test_get_tile_visual_position_elevation_offset():
	var pos_0 = PlanetMapCoordinates.get_tile_visual_position(Vector2i(5, 5), 0)
	var pos_1 = PlanetMapCoordinates.get_tile_visual_position(Vector2i(5, 5), 1)
	var pos_7 = PlanetMapCoordinates.get_tile_visual_position(Vector2i(5, 5), 7)
	# Higher elevation should have lower Y (visually higher on screen)
	assert_lt(pos_1.y, pos_0.y, "Elevation 1 should be visually higher than 0")
	assert_lt(pos_7.y, pos_1.y, "Elevation 7 should be visually higher than 1")
	# X should be unchanged
	assert_eq(pos_0.x, pos_1.x, "Elevation should not affect X")

func test_get_y_sort_value_ordering():
	# Tiles further down the screen should have higher y-sort values
	var sort_top = PlanetMapCoordinates.get_y_sort_value(Vector2i(0, 0), 0)
	var sort_bottom = PlanetMapCoordinates.get_y_sort_value(Vector2i(10, 10), 0)
	assert_gt(sort_bottom, sort_top, "Tiles lower on screen should sort higher")

func test_tilemap_position_offset_by_elevation():
	# Verify that TileMaps at different elevations are positioned correctly
	# Higher elevation tilemaps should have more negative Y (visually higher on screen)
	var offset_1 = -1 * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET
	var offset_7 = -7 * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET
	# Higher elevation should have more negative offset (visually higher/further back)
	assert_eq(offset_1, -20.0, "Elevation 1 TileMap offset should be -20")
	assert_eq(offset_7, -140.0, "Elevation 7 TileMap offset should be -140")
	assert_lt(offset_7, offset_1, "Higher elevation TileMap should have more negative offset")

func test_cross_elevation_depth_sorting_concept():
	# Verify that y-sort works correctly when tilemaps have SAME z-index
	# Trees at visually lower Y positions should render in front, regardless of elevation layer

	# Imagine two trees at different elevations but close in screen space:
	# Tree A: elevation 3, grid (10, 10) -> visual Y = base_y - 240
	# Tree B: elevation 0, grid (15, 15) -> visual Y = base_y + 0

	var base_y = 400.0
	var tree_a_visual_y = base_y - (3 * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET)
	var tree_b_visual_y = base_y - (0 * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET)

	# Tree A is at higher elevation (visually UP on screen = lower Y value)
	# Tree B is at lower elevation (visually DOWN on screen = higher Y value)
	assert_lt(tree_a_visual_y, tree_b_visual_y, "Higher elevation = lower visual Y")

	# With y-sort enabled and SAME z-index, Tree B renders in FRONT (correct!)
