extends "res://tests/test_node_base.gd"

## Unit tests for ChunkTileMapGroup class
## Tests chunk visual rendering setup
## Note: ChunkTileMapGroup uses incremental rendering via _process(),
## so tile counts require waiting frames after initialization.

func _make_chunk(chunk_pos: Vector2i = Vector2i(0, 0)) -> ChunkTileMapGroup:
	var chunk_data = ChunkTileData.new(chunk_pos)
	var chunk_visual = autofree(ChunkTileMapGroup.new())
	add_child(chunk_visual)
	chunk_visual.initialize(chunk_pos, chunk_data)
	return chunk_visual

func _make_chunk_with_data(chunk_pos: Vector2i, chunk_data: ChunkTileData) -> ChunkTileMapGroup:
	var chunk_visual = autofree(ChunkTileMapGroup.new())
	add_child(chunk_visual)
	chunk_visual.initialize(chunk_pos, chunk_data)
	return chunk_visual

func test_initialization():
	var chunk_visual = _make_chunk(Vector2i(2, 3))
	assert_eq(chunk_visual.chunk_pos, Vector2i(2, 3), "Chunk position should match")
	assert_true(chunk_visual.is_loaded, "Chunk should be marked as loaded")

func test_creates_elevation_tilemap_slots():
	var chunk_visual = _make_chunk()
	assert_eq(chunk_visual.elevation_tilemaps.size(), PlanetMapTileConfig.NUM_RENDER_LAYERS, "Should have NUM_RENDER_LAYERS tilemap slots")

func test_tilemaps_created_lazily():
	var chunk_visual = _make_chunk()
	# Before rendering completes, some tilemaps may still be null (lazy creation)
	# But at least one should exist after initialize starts
	var non_null_count = 0
	for tm in chunk_visual.elevation_tilemaps:
		if tm != null:
			non_null_count += 1
	# After first frame of rendering, at least some tilemaps should exist
	await wait_frames(1)
	var after_frame_count = 0
	for tm in chunk_visual.elevation_tilemaps:
		if tm != null:
			after_frame_count += 1
	assert_true(after_frame_count >= non_null_count, "More tilemaps should exist after rendering frames")

func test_tilemap_properties():
	var chunk_visual = _make_chunk()
	# Wait for rendering to create tilemaps
	await wait_frames(20)

	# Find first non-null tilemap
	for tilemap in chunk_visual.elevation_tilemaps:
		if tilemap != null and is_instance_valid(tilemap):
			assert_eq(tilemap.texture_filter, CanvasItem.TEXTURE_FILTER_NEAREST, "Texture filter should be NEAREST")
			assert_true(tilemap.y_sort_enabled, "Y-sort should be enabled")
			break

func test_chunk_position_offset():
	var chunk_visual = _make_chunk(Vector2i(0, 0))
	assert_eq(chunk_visual.position, Vector2.ZERO, "Chunk (0,0) should be at origin")

func test_renders_tiles_after_frames():
	var chunk_visual = _make_chunk()
	# Incremental rendering: need to wait enough frames for 4096 tiles
	# tiles_per_frame defaults to 256, so 4096/256 = 16 frames minimum
	await wait_frames(20)

	var tile_count = chunk_visual.get_tile_count()
	assert_gt(tile_count, 0, "Should have rendered tiles after waiting")

func test_clear_tiles():
	var chunk_visual = _make_chunk()
	await wait_frames(20)

	assert_true(chunk_visual.get_tile_count() > 0, "Should have tiles before clear")
	chunk_visual.clear_tiles()
	assert_eq(chunk_visual.get_tile_count(), 0, "Should have no tiles after clear")

func test_z_index_ordering():
	var chunk_visual = _make_chunk()
	await wait_frames(20)

	# Check that z-index increases with layer for non-null tilemaps
	var prev_z = -999
	for i in range(chunk_visual.elevation_tilemaps.size()):
		var tm = chunk_visual.elevation_tilemaps[i]
		if tm != null and is_instance_valid(tm):
			assert_true(tm.z_index > prev_z, "Layer %d z-index (%d) should be > previous (%d)" % [i, tm.z_index, prev_z])
			prev_z = tm.z_index
