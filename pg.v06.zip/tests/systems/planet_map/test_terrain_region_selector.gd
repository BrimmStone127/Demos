extends "res://tests/test_base.gd"

# Tests for TerrainRegionSelector - seed-based PNG region selection

func test_selector_constants():
	# Verify dimensions match St. Louis heightmap
	assert_eq(TerrainRegionSelector.FULL_MAP_SIZE, Vector2i(3612, 3612), "Full PNG size")
	assert_eq(TerrainRegionSelector.REGION_SIZE, Vector2i(64, 64), "Standard map size")
	assert_eq(TerrainRegionSelector.REGIONS_PER_AXIS, Vector2i(56, 56), "Regions per axis")
	assert_eq(TerrainRegionSelector.TOTAL_REGIONS, 3136, "Total unique regions (56×56)")

func test_region_selection_deterministic():
	# Same seed should always return same region
	var seed1 = 12345
	var region1 = TerrainRegionSelector.get_region_for_seed(seed1)
	var region2 = TerrainRegionSelector.get_region_for_seed(seed1)

	assert_eq(region1["region_index"], region2["region_index"], "Same seed = same region")
	assert_eq(region1["pixel_offset"], region2["pixel_offset"], "Same seed = same offset")

func test_region_within_bounds():
	# Test multiple seeds to ensure regions are always valid
	for test_seed in [0, 1, 100, 999, 12345, 999999]:
		var region = TerrainRegionSelector.get_region_for_seed(test_seed)
		var idx = region["region_index"]
		var offset = region["pixel_offset"]

		# Region indices should be 0-55
		assert_true(idx.x >= 0, "Region X >= 0 (seed %d)" % test_seed)
		assert_true(idx.x < 56, "Region X < 56 (seed %d)" % test_seed)
		assert_true(idx.y >= 0, "Region Y >= 0 (seed %d)" % test_seed)
		assert_true(idx.y < 56, "Region Y < 56 (seed %d)" % test_seed)

		# Pixel offsets should be valid
		assert_true(offset.x >= 0, "Offset X >= 0 (seed %d)" % test_seed)
		assert_true(offset.x <= 3612 - 64, "Offset X within bounds (seed %d)" % test_seed)
		assert_true(offset.y >= 0, "Offset Y >= 0 (seed %d)" % test_seed)
		assert_true(offset.y <= 3612 - 64, "Offset Y within bounds (seed %d)" % test_seed)

func test_region_bounds_format():
	# Verify bounds dictionary has correct format for PNGTerrainLoader
	var region = TerrainRegionSelector.get_region_for_seed(42)
	var bounds = region["bounds"]

	assert_true(bounds.has("x"), "Bounds has x")
	assert_true(bounds.has("y"), "Bounds has y")
	assert_true(bounds.has("width"), "Bounds has width")
	assert_true(bounds.has("height"), "Bounds has height")
	assert_eq(bounds["width"], 64, "Bounds width = 64")
	assert_eq(bounds["height"], 64, "Bounds height = 64")

func test_region_pixel_offset_matches_index():
	# Pixel offset should equal region_index × 64
	var region = TerrainRegionSelector.get_region_for_seed(777)
	var idx = region["region_index"]
	var offset = region["pixel_offset"]

	assert_eq(offset.x, idx.x * 64, "Offset X matches index")
	assert_eq(offset.y, idx.y * 64, "Offset Y matches index")

func test_get_region_index_matches_full_data():
	# Convenience function should match full data
	var seed = 555
	var full_data = TerrainRegionSelector.get_region_for_seed(seed)
	var index_only = TerrainRegionSelector.get_region_index(seed)

	assert_eq(index_only, full_data["region_index"], "Index function matches full data")

func test_png_path_correct():
	var path = TerrainRegionSelector.get_png_path()
	assert_eq(path, "res://assets/terrain/reference/full_map_8bit.png", "PNG path")

func test_region_info_string():
	# Should produce human-readable region info
	var info = TerrainRegionSelector.get_region_info(12345)
	assert_true(info.length() > 0, "Info string not empty")
	assert_true(info.contains("Region"), "Contains 'Region'")
	assert_true(info.contains("pixels"), "Contains 'pixels'")

func test_different_seeds_give_different_regions():
	# With 3136 regions, different seeds should usually give different regions
	var region1 = TerrainRegionSelector.get_region_index(1)
	var region2 = TerrainRegionSelector.get_region_index(2)
	var region3 = TerrainRegionSelector.get_region_index(3)

	# At least one should be different (very high probability with 3136 options)
	var all_same = (region1 == region2 and region2 == region3)
	assert_false(all_same, "Different seeds should usually give different regions")

func test_negative_seeds_handled():
	# Negative seeds should be handled gracefully (abs() is used)
	var region_neg = TerrainRegionSelector.get_region_for_seed(-12345)
	var region_pos = TerrainRegionSelector.get_region_for_seed(12345)

	# Should get valid regions (may or may not be same due to abs())
	assert_true(region_neg["region_index"].x >= 0, "Negative seed handled")
	assert_true(region_pos["region_index"].x >= 0, "Positive seed handled")

func test_large_seeds_handled():
	# Very large seeds should work
	var large_seed = 2147483647  # Max int32
	var region = TerrainRegionSelector.get_region_for_seed(large_seed)

	assert_true(region["region_index"].x >= 0, "Large seed X valid")
	assert_true(region["region_index"].x < 56, "Large seed X in bounds")
	assert_true(region["region_index"].y >= 0, "Large seed Y valid")
	assert_true(region["region_index"].y < 56, "Large seed Y in bounds")

func test_zero_seed_handled():
	# Zero seed should work
	var region = TerrainRegionSelector.get_region_for_seed(0)

	assert_true(region["region_index"].x >= 0, "Zero seed X valid")
	assert_true(region["region_index"].x < 56, "Zero seed X in bounds")
