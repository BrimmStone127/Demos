extends "res://tests/test_base.gd"

## Tests for CoordinateSystem - central tile/world/chunk coordinate conversions

var coord_sys: CoordinateSystem

func before_each():
	# Standard 64x64 map with 160x80 isometric tiles
	coord_sys = CoordinateSystem.new(Vector2i(64, 64), Vector2i(160, 80), 64)

# --- Initialization ---

func test_default_initialization():
	var cs = CoordinateSystem.new()
	assert_eq(cs.map_size, Vector2i(64, 64), "Default map size")
	assert_eq(cs.tile_size, Vector2i(160, 80), "Default tile size")
	assert_eq(cs.chunk_size, 64, "Default chunk size")

func test_custom_initialization():
	var cs = CoordinateSystem.new(Vector2i(128, 128), Vector2i(32, 16), 16)
	assert_eq(cs.map_size, Vector2i(128, 128), "Custom map size")
	assert_eq(cs.tile_size, Vector2i(32, 16), "Custom tile size")
	assert_eq(cs.chunk_size, 16, "Custom chunk size")

# --- Tile validation ---

func test_is_valid_tile_origin():
	assert_true(coord_sys.is_valid_tile(Vector2i(0, 0)), "Origin is valid")

func test_is_valid_tile_max_bounds():
	assert_true(coord_sys.is_valid_tile(Vector2i(63, 63)), "Max valid tile")

func test_is_valid_tile_out_of_bounds_negative():
	assert_false(coord_sys.is_valid_tile(Vector2i(-1, 0)), "Negative X invalid")
	assert_false(coord_sys.is_valid_tile(Vector2i(0, -1)), "Negative Y invalid")

func test_is_valid_tile_out_of_bounds_positive():
	assert_false(coord_sys.is_valid_tile(Vector2i(64, 0)), "X at map_size invalid")
	assert_false(coord_sys.is_valid_tile(Vector2i(0, 64)), "Y at map_size invalid")

func test_clamp_tile_within_bounds():
	assert_eq(coord_sys.clamp_tile(Vector2i(32, 32)), Vector2i(32, 32), "Already in bounds")

func test_clamp_tile_negative():
	assert_eq(coord_sys.clamp_tile(Vector2i(-5, -10)), Vector2i(0, 0), "Clamps negatives")

func test_clamp_tile_exceeds_bounds():
	assert_eq(coord_sys.clamp_tile(Vector2i(100, 200)), Vector2i(63, 63), "Clamps to max")

# --- Tile to World conversion ---

func test_tile_to_world_origin():
	var world = coord_sys.tile_to_world(Vector2i(0, 0))
	assert_eq(world, Vector2.ZERO, "Origin tile at world origin")

func test_tile_to_world_positive_x():
	# Moving +X in tile space goes right and down in world space
	var world = coord_sys.tile_to_world(Vector2i(1, 0))
	assert_eq(world.x, 80.0, "Tile (1,0) world X")  # half tile width
	assert_eq(world.y, 40.0, "Tile (1,0) world Y")  # half tile height

func test_tile_to_world_positive_y():
	# Moving +Y in tile space goes left and down in world space
	var world = coord_sys.tile_to_world(Vector2i(0, 1))
	assert_eq(world.x, -80.0, "Tile (0,1) world X")  # negative half tile width
	assert_eq(world.y, 40.0, "Tile (0,1) world Y")  # half tile height

func test_tile_to_world_diagonal():
	# Diagonal in tile space goes purely down in world space
	var world = coord_sys.tile_to_world(Vector2i(1, 1))
	assert_eq(world.x, 0.0, "Tile (1,1) world X is centered")
	assert_eq(world.y, 80.0, "Tile (1,1) world Y is full tile height")

# --- World to Tile conversion ---

func test_world_to_tile_origin():
	var tile = coord_sys.world_to_tile(Vector2.ZERO)
	assert_eq(tile, Vector2i(0, 0), "World origin is tile origin")

func test_world_to_tile_positive():
	# World position (80, 40) should be tile (1, 0)
	var tile = coord_sys.world_to_tile(Vector2(80, 40))
	assert_eq(tile, Vector2i(1, 0), "World (80,40) is tile (1,0)")

func test_world_to_tile_roundtrip():
	# Converting back and forth should preserve position
	var original = Vector2i(10, 15)
	var world = coord_sys.tile_to_world(original)
	var back = coord_sys.world_to_tile(world)
	assert_eq(back, original, "Round-trip preserves tile position")

# --- Chunk conversions ---

func test_tile_to_chunk_origin():
	assert_eq(coord_sys.tile_to_chunk(Vector2i(0, 0)), Vector2i(0, 0), "Origin in chunk 0,0")

func test_tile_to_chunk_within_first_chunk():
	assert_eq(coord_sys.tile_to_chunk(Vector2i(32, 32)), Vector2i(0, 0), "Mid-chunk is chunk 0,0")
	assert_eq(coord_sys.tile_to_chunk(Vector2i(63, 63)), Vector2i(0, 0), "Max first chunk")

func test_tile_to_chunk_second_chunk():
	# With chunk_size=64, tile 64 is in chunk 1
	var cs = CoordinateSystem.new(Vector2i(128, 128), Vector2i(160, 80), 64)
	assert_eq(cs.tile_to_chunk(Vector2i(64, 0)), Vector2i(1, 0), "Tile 64 in chunk 1")
	assert_eq(cs.tile_to_chunk(Vector2i(0, 64)), Vector2i(0, 1), "Tile Y64 in chunk 0,1")

func test_chunk_to_tile_bounds():
	var bounds = coord_sys.chunk_to_tile_bounds(Vector2i(0, 0))
	assert_eq(bounds.position, Vector2i(0, 0), "Chunk 0 starts at origin")
	assert_eq(bounds.size, Vector2i(64, 64), "Chunk 0 size matches map")

func test_chunk_to_tile_bounds_partial_chunk():
	# On a 64x64 map, chunk (1,1) would be out of bounds mostly
	# but chunk_to_tile_bounds should clamp to map size
	var cs = CoordinateSystem.new(Vector2i(100, 100), Vector2i(160, 80), 64)
	var bounds = cs.chunk_to_tile_bounds(Vector2i(1, 1))
	assert_eq(bounds.position, Vector2i(64, 64), "Chunk 1,1 starts at 64,64")
	assert_eq(bounds.size, Vector2i(36, 36), "Chunk 1,1 clamped to remaining tiles")

func test_world_to_chunk():
	# World origin is chunk 0,0
	assert_eq(coord_sys.world_to_chunk(Vector2.ZERO), Vector2i(0, 0), "World origin is chunk 0,0")

# --- Map center ---

func test_get_map_center_tile():
	assert_eq(coord_sys.get_map_center_tile(), Vector2i(32, 32), "Center of 64x64 map")

func test_get_map_center_world():
	var center = coord_sys.get_map_center_world()
	# Center tile (32, 32) in isometric: x = (32-32)*80 = 0, y = (32+32)*40 = 2560
	assert_eq(center.x, 0.0, "Map center world X")
	assert_eq(center.y, 2560.0, "Map center world Y")

# --- Bounds ---

func test_get_tile_bounds():
	var bounds = coord_sys.get_tile_bounds()
	assert_eq(bounds.position, Vector2i(0, 0), "Tile bounds start at origin")
	assert_eq(bounds.size, Vector2i(64, 64), "Tile bounds match map size")

func test_get_chunk_bounds():
	var bounds = coord_sys.get_chunk_bounds()
	assert_eq(bounds.position, Vector2i(0, 0), "Chunk bounds start at origin")
	assert_eq(bounds.size, Vector2i(1, 1), "64x64 map with chunk_size=64 is 1 chunk")

func test_get_chunk_bounds_larger_map():
	var cs = CoordinateSystem.new(Vector2i(128, 128), Vector2i(160, 80), 64)
	var bounds = cs.get_chunk_bounds()
	assert_eq(bounds.size, Vector2i(2, 2), "128x128 map with chunk_size=64 is 2x2 chunks")

# --- String representation ---

func test_to_string():
	var s = str(coord_sys)
	assert_string_contains(s, "64", "Contains map size")
	assert_string_contains(s, "160", "Contains tile width")
