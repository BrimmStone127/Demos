extends "res://tests/test_base.gd"

# Tests for PlanetMapSystem ecosystem extraction and visual mappings
# Updated to use MapleTreeTypes visual system (VG_1-6 + DORM_6)

func _make_map_tile(pos: Vector2i, type: PlanetMapTileConfig.TileType, surface_feature = null) -> MapTile:
	var t = MapTile.new(pos, type)
	t.surface_feature_type = surface_feature
	return t

func _make_small_tiles(size: int = 5) -> Array:
	var tiles = []
	tiles.resize(size)
	for x in range(size):
		tiles[x] = []
		tiles[x].resize(size)
		for y in range(size):
			tiles[x][y] = _make_map_tile(Vector2i(x, y), PlanetMapTileConfig.TileType.GRASS_0)
	return tiles

func test_extract_trees_finds_surface_features():
	# Tiles with surface_feature_type should produce TreeInstances
	var tiles = _make_small_tiles(5)
	# Place maple trees using current visual tiles
	tiles[2][3].surface_feature_type = MapleTreeTypes.TR_MAPL_VG_5  # Mature tree
	tiles[0][0].surface_feature_type = MapleTreeTypes.TR_MAPL_VG_4  # Young mature tree

	# Use PlanetMapGenerator.extract_initial_trees
	var gen = PlanetMapGenerator.new()
	var trees = gen.extract_initial_trees(tiles)

	assert_eq(trees.size(), 2, "Should extract 2 trees from tiles with surface features")

func test_extract_trees_skips_non_tree_tiles():
	var tiles = _make_small_tiles(5)
	# No surface features - all null

	var gen = PlanetMapGenerator.new()
	var trees = gen.extract_initial_trees(tiles)

	assert_eq(trees.size(), 0, "Should find no trees when no surface features present")

func test_extract_trees_records_correct_position():
	var tiles = _make_small_tiles(5)
	tiles[1][4].surface_feature_type = MapleTreeTypes.TR_MAPL_VG_6  # Very mature tree

	var gen = PlanetMapGenerator.new()
	var trees = gen.extract_initial_trees(tiles)

	assert_eq(trees.size(), 1)
	assert_eq(trees[0].position, Vector2i(1, 4), "Tree position should match tile position")

func test_extract_trees_sets_mature_stage():
	var tiles = _make_small_tiles(3)
	tiles[0][0].surface_feature_type = MapleTreeTypes.TR_MAPL_VG_5  # Mature tree visual

	var gen = PlanetMapGenerator.new()
	var trees = gen.extract_initial_trees(tiles)

	assert_eq(trees.size(), 1)
	assert_eq(int(trees[0].growth_stage), int(TreeInstance.GrowthStage.MATURE), "Initial trees should be MATURE")
	assert_eq(trees[0].health, 1.0, "Initial trees should have full health")

# ============== MapleTreeTypes Visual Mapping Tests ==============
# Tests that MapleTreeTypes.get_tile_for_growth returns correct tiles

func test_maple_seedling_visual():
	var tile_id = MapleTreeTypes.get_tile_for_growth(TreeInstance.GrowthStage.SEEDLING, 0)
	assert_eq(tile_id, MapleTreeTypes.TR_MAPL_VG_1, "SEEDLING should show VG_1 (smallest tree)")

func test_maple_young_sapling_visual():
	var tile_id = MapleTreeTypes.get_tile_for_growth(TreeInstance.GrowthStage.YOUNG_SAPLING, 4)
	assert_eq(tile_id, MapleTreeTypes.TR_MAPL_VG_2, "YOUNG_SAPLING should show VG_2")

func test_maple_sapling_visual():
	var tile_id = MapleTreeTypes.get_tile_for_growth(TreeInstance.GrowthStage.SAPLING, 8)
	assert_eq(tile_id, MapleTreeTypes.TR_MAPL_VG_3, "SAPLING should show VG_3")

func test_maple_young_mature_visual():
	var tile_id = MapleTreeTypes.get_tile_for_growth(TreeInstance.GrowthStage.YOUNG_MATURE, 12)
	assert_eq(tile_id, MapleTreeTypes.TR_MAPL_VG_4, "YOUNG_MATURE should show VG_4")

func test_maple_mature_visual():
	var tile_id = MapleTreeTypes.get_tile_for_growth(TreeInstance.GrowthStage.MATURE, 16)
	assert_eq(tile_id, MapleTreeTypes.TR_MAPL_VG_5, "MATURE should show VG_5")

func test_maple_very_mature_visual():
	var tile_id = MapleTreeTypes.get_tile_for_growth(TreeInstance.GrowthStage.VERY_MATURE, 24)
	assert_eq(tile_id, MapleTreeTypes.TR_MAPL_VG_6, "VERY_MATURE should show VG_6 (largest tree)")

func test_maple_dormant_visual():
	var tile_id = MapleTreeTypes.get_tile_for_growth(TreeInstance.GrowthStage.DORMANT, 40)
	assert_eq(tile_id, MapleTreeTypes.TR_MAPL_DORM_6, "DORMANT should show DORM_6 (dead tree)")

func test_all_stages_have_distinct_visuals():
	# Verify each growth stage maps to a unique tile
	var all_tiles = []
	var stages = [
		TreeInstance.GrowthStage.SEEDLING,
		TreeInstance.GrowthStage.YOUNG_SAPLING,
		TreeInstance.GrowthStage.SAPLING,
		TreeInstance.GrowthStage.YOUNG_MATURE,
		TreeInstance.GrowthStage.MATURE,
		TreeInstance.GrowthStage.VERY_MATURE,
	]

	for stage in stages:
		var tile = MapleTreeTypes.get_tile_for_growth(stage, 0)
		assert_false(all_tiles.has(tile), "Each growth stage should have a distinct tile")
		all_tiles.append(tile)

func test_dormant_uses_different_tile_type():
	# DORMANT should use a DORM tile, not a VG tile
	var dormant_tile = MapleTreeTypes.get_tile_for_growth(TreeInstance.GrowthStage.DORMANT, 40)

	# Verify it's in the DORM range
	var is_dorm = dormant_tile in MapleTreeTypes.ALL_DORMANT
	assert_true(is_dorm, "DORMANT stage should use a tile from ALL_DORMANT")

	# Verify it's NOT in VG range
	var is_vg = dormant_tile in MapleTreeTypes.ALL_VEGETATIVE
	assert_false(is_vg, "DORMANT stage should NOT use a vegetative tile")
