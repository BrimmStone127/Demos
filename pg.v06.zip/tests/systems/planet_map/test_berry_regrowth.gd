extends "res://tests/test_base.gd"

## Tests for berry bush regrowth system in PlanetMapSystem.
## Verifies that depleted bushes regrow after BERRY_REGROWTH_TICKS simulation ticks.

const LOG_TAG := "TEST_BERRY_REGROWTH"


# --- Helper to create a minimal PlanetMapSystem for berry logic testing ---

func _make_system() -> PlanetMapSystem:
	var sys = PlanetMapSystem.new()
	# We only test the berry supply/depletion/regrowth dicts directly.
	# No chunk manager or ecosystem needed for these unit tests.
	return sys


# --- Berry depletion ---

func test_berry_depletes_after_max_picks():
	var sys = _make_system()
	var pos := Vector2i(10, 20)
	# Manually seed the supply so we don't need ForestSpecies determinism
	sys._berry_supply[pos] = PlanetMapSystem.BERRY_MAX_PICKS

	for i in range(PlanetMapSystem.BERRY_MAX_PICKS):
		var result := sys.collect_berry_at(pos)
		assert_true(result, "Pick %d should succeed" % (i + 1))

	assert_true(sys._depleted_positions.has(pos), "Position should be depleted after max picks")
	assert_false(sys._berry_supply.has(pos), "Berry supply should be erased after depletion")


func test_depleted_bush_returns_false():
	var sys = _make_system()
	var pos := Vector2i(5, 5)
	sys._depleted_positions[pos] = true

	var result := sys.collect_berry_at(pos)
	assert_false(result, "Collecting from depleted position should return false")


# --- Regrowth timer ---

func test_depletion_starts_regrowth_timer():
	var sys = _make_system()
	var pos := Vector2i(10, 20)
	sys._berry_supply[pos] = 1  # one pick left

	sys.collect_berry_at(pos)  # strips the bush

	assert_true(sys._berry_regrowth_timers.has(pos), "Regrowth timer should start on depletion")
	assert_eq(sys._berry_regrowth_timers[pos], PlanetMapSystem.BERRY_REGROWTH_TICKS, "Timer should equal BERRY_REGROWTH_TICKS")


func test_berry_regrows_after_enough_ticks():
	var sys = _make_system()
	var pos := Vector2i(10, 20)

	# Simulate depletion
	sys._depleted_positions[pos] = true
	sys._berry_regrowth_timers[pos] = PlanetMapSystem.BERRY_REGROWTH_TICKS

	# Tick until just before regrowth
	for i in range(PlanetMapSystem.BERRY_REGROWTH_TICKS - 1):
		sys.on_simulation_tick(i, 0.0)

	assert_true(sys._depleted_positions.has(pos), "Bush should still be depleted one tick before regrowth")

	# Final tick triggers regrowth
	sys.on_simulation_tick(PlanetMapSystem.BERRY_REGROWTH_TICKS, 0.0)

	assert_false(sys._depleted_positions.has(pos), "Bush should no longer be depleted after regrowth")
	assert_false(sys._berry_regrowth_timers.has(pos), "Regrowth timer should be removed")
	assert_eq(sys._berry_supply.get(pos, 0), PlanetMapSystem.BERRY_MAX_PICKS, "Berry supply should be restored to max")


func test_regrown_bush_can_be_collected_again():
	var sys = _make_system()
	var pos := Vector2i(10, 20)

	# Deplete and regrow
	sys._depleted_positions[pos] = true
	sys._berry_regrowth_timers[pos] = 1  # regrows next tick

	sys.on_simulation_tick(0, 0.0)

	# Should be collectible again
	var result := sys.collect_berry_at(pos)
	assert_true(result, "Regrown bush should yield berries")


# --- Firewood isolation ---

func test_depleted_firewood_does_not_regrow():
	var sys = _make_system()
	var wood_pos := Vector2i(30, 40)

	# Firewood depletion only sets _depleted_positions, never _berry_regrowth_timers
	sys._depleted_positions[wood_pos] = true

	# Tick many times
	for i in range(PlanetMapSystem.BERRY_REGROWTH_TICKS + 100):
		sys.on_simulation_tick(i, 0.0)

	assert_true(sys._depleted_positions.has(wood_pos), "Firewood depletion should not be affected by berry regrowth")


# --- Multiple bushes ---

func test_multiple_bushes_regrow_independently():
	var sys = _make_system()
	var pos_a := Vector2i(10, 10)
	var pos_b := Vector2i(20, 20)

	sys._depleted_positions[pos_a] = true
	sys._berry_regrowth_timers[pos_a] = 5

	sys._depleted_positions[pos_b] = true
	sys._berry_regrowth_timers[pos_b] = 10

	# Tick 5 times — pos_a should regrow, pos_b should not
	for i in range(5):
		sys.on_simulation_tick(i, 0.0)

	assert_false(sys._depleted_positions.has(pos_a), "Bush A should have regrown")
	assert_true(sys._depleted_positions.has(pos_b), "Bush B should still be depleted")

	# Tick 5 more — pos_b should regrow
	for i in range(5):
		sys.on_simulation_tick(i + 5, 0.0)

	assert_false(sys._depleted_positions.has(pos_b), "Bush B should have regrown")
