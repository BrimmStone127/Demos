extends "res://tests/test_node_base.gd"

## Unit tests for ChunkVisibilityManager class
## Tests chunk loading/unloading based on camera position
## Note: Chunk loading is async (data + visual queues drained in _process).
## Tests need to wait enough frames for chunks to appear.

var manager: ChunkVisibilityManager = null
var terrain_source: ProceduralTerrainSource = null

func before_each():
	# Create terrain source with small test map
	terrain_source = ProceduralTerrainSource.new(
		Vector2i(10, 10),  # 10x10 chunks
		ProceduralTerrainSource.Pattern.GRADIENT_X
	)

	# Create manager (Node2D, needs scene tree for _process and _ready)
	manager = autofree(ChunkVisibilityManager.new())
	add_child(manager)
	manager.set_terrain_source(terrain_source)

func test_initialization():
	assert_not_null(manager, "Manager should be created")
	assert_eq(manager.get_loaded_chunk_count(), 0, "Should start with no chunks loaded")

func test_y_sort_disabled():
	assert_false(manager.y_sort_enabled,
		"y_sort must be disabled — causes one-frame black flash in SubViewport on child visibility change")

func test_set_terrain_source():
	assert_not_null(manager.terrain_source, "Terrain source should be set")
	assert_eq(manager.terrain_source, terrain_source, "Should be the same source")

func test_update_camera_position_loads_chunks():
	# Move camera to chunk (5, 5) center
	var camera_pos = PlanetMapCoordinates.grid_to_world(Vector2i(5 * 64 + 32, 5 * 64 + 32))
	manager.update_camera_position(camera_pos)

	# Async loading needs frames to drain queues
	await wait_frames(30)

	assert_true(manager.get_loaded_chunk_count() > 0, "Should have loaded chunks after frames")

func test_moving_camera_updates_chunks():
	# Start at chunk (5, 5)
	var pos1 = PlanetMapCoordinates.grid_to_world(Vector2i(5 * 64 + 32, 5 * 64 + 32))
	manager.update_camera_position(pos1)
	await wait_frames(30)

	# Move to chunk (7, 7)
	var pos2 = PlanetMapCoordinates.grid_to_world(Vector2i(7 * 64 + 32, 7 * 64 + 32))
	manager.update_camera_position(pos2)
	await wait_frames(30)

	assert_true(manager.get_loaded_chunk_count() > 0, "Should have chunks after move")

func test_is_chunk_loaded():
	assert_false(manager.is_chunk_loaded(Vector2i(5, 5)), "Chunk should not be loaded initially")

	var camera_pos = PlanetMapCoordinates.grid_to_world(Vector2i(5 * 64 + 32, 5 * 64 + 32))
	manager.update_camera_position(camera_pos)
	await wait_frames(30)

	# Camera chunk or nearby chunks should be loaded
	var any_loaded = manager.get_loaded_chunk_count() > 0
	assert_true(any_loaded, "Some chunks should be loaded after camera update")

func test_get_loaded_chunk_positions():
	var camera_pos = PlanetMapCoordinates.grid_to_world(Vector2i(5 * 64 + 32, 5 * 64 + 32))
	manager.update_camera_position(camera_pos)
	await wait_frames(30)

	var positions = manager.get_loaded_chunk_positions()
	assert_true(positions.size() > 0, "Should return loaded chunk positions")

func test_clear_all_chunks():
	var camera_pos = PlanetMapCoordinates.grid_to_world(Vector2i(5 * 64 + 32, 5 * 64 + 32))
	manager.update_camera_position(camera_pos)
	await wait_frames(30)

	assert_true(manager.get_loaded_chunk_count() > 0, "Should have chunks before clear")
	manager.clear_all_chunks()
	assert_eq(manager.get_loaded_chunk_count(), 0, "Should have no chunks after clear")

func test_get_stats():
	var camera_pos = PlanetMapCoordinates.grid_to_world(Vector2i(5 * 64 + 32, 5 * 64 + 32))
	manager.update_camera_position(camera_pos)
	await wait_frames(30)

	var stats = manager.get_stats()
	assert_true(stats.has("visual_chunks"), "Stats should include visual_chunks")
	assert_true(stats.has("camera_chunk"), "Stats should include camera_chunk")
	assert_eq(stats["camera_chunk"], Vector2i(5, 5), "Camera chunk should be (5,5)")

func test_out_of_bounds_camera():
	# Camera way outside terrain bounds
	var far_pos = PlanetMapCoordinates.grid_to_world(Vector2i(20 * 64, 20 * 64))
	manager.update_camera_position(far_pos)
	await wait_frames(10)

	# Should not crash
	var stats = manager.get_stats()
	assert_true(stats["visual_chunks"] >= 0, "Should handle out of bounds gracefully")

func test_lod_hysteresis_no_rapid_cycling():
	# Zoom below ENTER threshold -> LOD mode on
	manager.update_zoom(PlanetMapTileConfig.LOD_ZOOM_ENTER - 0.001)
	assert_true(manager.get_stats()["lod_mode"], "Should enter LOD below ENTER threshold")

	# Zoom between ENTER and EXIT -> should STAY in LOD (hysteresis)
	manager.update_zoom(PlanetMapTileConfig.LOD_ZOOM_ENTER + 0.005)
	assert_true(manager.get_stats()["lod_mode"], "Should stay in LOD between thresholds")

	# Zoom above EXIT threshold -> LOD mode off
	manager.update_zoom(PlanetMapTileConfig.LOD_ZOOM_EXIT + 0.001)
	assert_false(manager.get_stats()["lod_mode"], "Should exit LOD above EXIT threshold")

func test_lod_enter_threshold():
	# Just above ENTER -> no LOD
	manager.update_zoom(PlanetMapTileConfig.LOD_ZOOM_ENTER + 0.001)
	assert_false(manager.get_stats()["lod_mode"], "Should not enter LOD just above ENTER")

	# Just below ENTER -> LOD
	manager.update_zoom(PlanetMapTileConfig.LOD_ZOOM_ENTER - 0.001)
	assert_true(manager.get_stats()["lod_mode"], "Should enter LOD just below ENTER")

func test_lod_exit_keeps_sprite_as_backdrop():
	# Enter LOD
	manager.update_zoom(PlanetMapTileConfig.LOD_ZOOM_ENTER - 0.001)
	assert_true(manager.get_stats()["lod_mode"], "Should be in LOD")

	# Exit LOD — fade should be pending
	manager.update_zoom(PlanetMapTileConfig.LOD_ZOOM_EXIT + 0.001)
	assert_false(manager.get_stats()["lod_mode"], "Should have exited LOD")
	assert_true(manager._lod_fade_pending, "LOD fade should be pending while chunks render")

func test_lod_reenter_kills_fade_tween():
	# Enter LOD
	manager.update_zoom(PlanetMapTileConfig.LOD_ZOOM_ENTER - 0.001)
	assert_true(manager.get_stats()["lod_mode"], "Should be in LOD")

	# Exit LOD — start fade process
	manager.update_zoom(PlanetMapTileConfig.LOD_ZOOM_EXIT + 0.001)
	assert_true(manager._lod_fade_pending, "Fade should be pending")

	# Re-enter LOD — should cancel fade
	manager.update_zoom(PlanetMapTileConfig.LOD_ZOOM_ENTER - 0.001)
	assert_false(manager._lod_fade_pending, "Fade should be cancelled on re-enter")
	assert_true(manager._lod_fade_tween == null or not manager._lod_fade_tween.is_valid(),
		"Fade tween should be killed on re-enter")
