extends "res://tests/test_base.gd"

# Tests for PlanetMapCache serialization/deserialization

func test_serialize_empty_returns_empty():
	var result = PlanetMapCache.serialize_map_tiles([])
	assert_eq(result.size(), 0)

func test_deserialize_empty_returns_empty():
	var result = PlanetMapCache.deserialize_map_tiles([])
	assert_eq(result.size(), 0)

func test_serialize_single_tile():
	var tile = MapTile.new(Vector2i(0, 0), PlanetMapTileConfig.TileType.GRASS_0)
	tile.elevation = 3
	tile.temperature = 295.0
	tile.discovered = true

	var tiles = [[tile]]
	var serialized = PlanetMapCache.serialize_map_tiles(tiles)

	assert_eq(serialized.size(), 1)
	assert_eq(serialized[0].size(), 1)
	assert_eq(serialized[0][0]["type"], PlanetMapTileConfig.TileType.GRASS_0)
	assert_eq(serialized[0][0]["elevation"], 3)
	assert_eq(serialized[0][0]["temperature"], 295.0)

func test_deserialize_single_tile():
	var serialized = [[{
		"type": PlanetMapTileConfig.TileType.FRESH_WATER,
		"position": Vector2i(0, 0),
		"elevation": 2,
		"temperature": 280.0,
		"composition": {},
		"special_features": [],
		"discovered": true,
		"surface_feature_type": null
	}]]

	var tiles = PlanetMapCache.deserialize_map_tiles(serialized)

	assert_eq(tiles.size(), 1)
	assert_eq(tiles[0].size(), 1)
	assert_eq(tiles[0][0].type, PlanetMapTileConfig.TileType.FRESH_WATER)
	assert_eq(tiles[0][0].elevation, 2)
	assert_almost_eq(tiles[0][0].temperature, 280.0, 0.01)

func test_roundtrip_preserves_data():
	# Create a small test map
	var original = []
	for x in range(3):
		var row = []
		for y in range(3):
			var tile = MapTile.new(Vector2i(x, y), PlanetMapTileConfig.TileType.ROCK)
			tile.elevation = (x + y) % 8
			tile.temperature = 200.0 + x * 10 + y
			tile.discovered = (x + y) % 2 == 0
			row.append(tile)
		original.append(row)

	var serialized = PlanetMapCache.serialize_map_tiles(original)
	var restored = PlanetMapCache.deserialize_map_tiles(serialized)

	assert_eq(restored.size(), 3)
	for x in range(3):
		assert_eq(restored[x].size(), 3)
		for y in range(3):
			assert_eq(restored[x][y].type, original[x][y].type)
			assert_eq(restored[x][y].elevation, original[x][y].elevation)
			assert_almost_eq(restored[x][y].temperature, original[x][y].temperature, 0.01)
			assert_eq(restored[x][y].discovered, original[x][y].discovered)

func test_roundtrip_preserves_surface_features():
	var tile = MapTile.new(Vector2i(5, 5), PlanetMapTileConfig.TileType.GRASS_0)
	tile.surface_feature_type = PlanetMapTileConfig.TileType.SF_TREE_1

	var serialized = PlanetMapCache.serialize_map_tiles([[tile]])
	var restored = PlanetMapCache.deserialize_map_tiles(serialized)

	assert_eq(restored[0][0].surface_feature_type, PlanetMapTileConfig.TileType.SF_TREE_1)

func test_roundtrip_preserves_composition():
	var tile = MapTile.new(Vector2i(0, 0), PlanetMapTileConfig.TileType.ROCK)
	tile.composition = {"iron": 0.3, "silicon": 0.5, "carbon": 0.2}

	var serialized = PlanetMapCache.serialize_map_tiles([[tile]])
	var restored = PlanetMapCache.deserialize_map_tiles(serialized)

	assert_has(restored[0][0].composition, "iron")
	assert_has(restored[0][0].composition, "silicon")
	assert_has(restored[0][0].composition, "carbon")
	assert_almost_eq(restored[0][0].composition["iron"], 0.3, 0.01)

func test_deserialize_handles_empty_tile_data():
	# Empty dict should create default tile
	var serialized = [[{}]]
	var tiles = PlanetMapCache.deserialize_map_tiles(serialized)

	assert_eq(tiles.size(), 1)
	assert_eq(tiles[0][0].type, PlanetMapTileConfig.TileType.ROCK)  # Default type

func test_deserialize_position_uses_array_index():
	# Position should come from array index, not stored data
	var serialized = [[{
		"type": PlanetMapTileConfig.TileType.GRASS_0,
		"position": Vector2i(99, 99),  # Wrong position in data
		"elevation": 0,
		"temperature": 0.0,
		"composition": {},
		"special_features": [],
		"discovered": true,
		"surface_feature_type": null
	}]]

	var tiles = PlanetMapCache.deserialize_map_tiles(serialized)

	# Should use array indices (0, 0), not stored position
	assert_eq(tiles[0][0].position, Vector2i(0, 0))
