extends "res://tests/test_base.gd"

## Unit tests for PNGTerrainSource class
## Tests PNG heightmap loading and chunk extraction

const PNG_PATH = "res://assets/terrain/reference/full_map_8bit.png"

func test_initialization():
	if not FileAccess.file_exists(PNG_PATH):
		# Skip test if PNG not available
		return

	var source = PNGTerrainSource.new(PNG_PATH)
	assert_true(source.is_loaded(), "PNG should load successfully")

func test_missing_png_handling():
	var source = PNGTerrainSource.new("res://nonexistent.png")
	assert_false(source.is_loaded(), "Missing PNG should fail gracefully")

	var chunk = source.load_chunk(Vector2i(0, 0))
	assert_null(chunk, "Load chunk should return null if PNG not loaded")

func test_get_bounds():
	if not FileAccess.file_exists(PNG_PATH):
		return

	var source = PNGTerrainSource.new(PNG_PATH)
	var bounds = source.get_bounds()

	# 3612×3612 PNG = 57×57 chunks (ceil(3612/64) = 57)
	assert_eq(bounds.position, Vector2i.ZERO, "Bounds start at origin")
	assert_true(bounds.size.x > 0, "Bounds width should be positive")
	assert_true(bounds.size.y > 0, "Bounds height should be positive")

func test_get_png_size():
	if not FileAccess.file_exists(PNG_PATH):
		return

	var source = PNGTerrainSource.new(PNG_PATH)
	var png_size = source.get_png_size()

	# Should be 3612×3612 for St. Louis terrain
	assert_eq(png_size, Vector2i(3612, 3612), "PNG size should be 3612×3612")

func test_get_tile_size():
	if not FileAccess.file_exists(PNG_PATH):
		return

	var source = PNGTerrainSource.new(PNG_PATH)
	var tile_size = source.get_tile_size()

	# Tile count equals PNG pixel count for heightmaps
	assert_true(tile_size.x >= 3612, "Tile width should be at least 3612")
	assert_true(tile_size.y >= 3612, "Tile height should be at least 3612")

func test_load_chunk_origin():
	if not FileAccess.file_exists(PNG_PATH):
		return

	var source = PNGTerrainSource.new(PNG_PATH)
	var chunk = source.load_chunk(Vector2i(0, 0))

	assert_not_null(chunk, "Chunk should load")
	assert_eq(chunk.chunk_pos, Vector2i(0, 0), "Chunk position should match")

	# Check all tiles populated (64×64)
	for y in range(64):
		for x in range(64):
			var elev = chunk.get_elevation(Vector2i(x, y))
			assert_true(elev >= 0.0 and elev <= 1.0, "Elevation should be 0.0-1.0 range at (%d,%d): %.3f" % [x, y, elev])

func test_load_chunk_offset():
	if not FileAccess.file_exists(PNG_PATH):
		return

	var source = PNGTerrainSource.new(PNG_PATH)
	var chunk = source.load_chunk(Vector2i(10, 20))

	assert_not_null(chunk, "Offset chunk should load")
	assert_eq(chunk.chunk_pos, Vector2i(10, 20), "Chunk position should match")

func test_load_chunk_out_of_bounds():
	if not FileAccess.file_exists(PNG_PATH):
		return

	var source = PNGTerrainSource.new(PNG_PATH)
	var bounds = source.get_bounds()

	# Try to load chunk beyond bounds
	var chunk = source.load_chunk(bounds.size + Vector2i(10, 10))

	assert_null(chunk, "Out of bounds chunk should return null")

func test_elevation_values_valid():
	if not FileAccess.file_exists(PNG_PATH):
		return

	var source = PNGTerrainSource.new(PNG_PATH)
	var chunk = source.load_chunk(Vector2i(5, 5))

	# Sample some positions
	var positions = [
		Vector2i(0, 0),
		Vector2i(31, 31),
		Vector2i(63, 63),
		Vector2i(10, 50),
	]

	for pos in positions:
		var elev = chunk.get_elevation(pos)
		assert_true(elev >= 0.0, "Elevation should be >= 0.0 at %s: %.3f" % [pos, elev])
		assert_true(elev <= 1.0, "Elevation should be <= 1.0 at %s: %.3f" % [pos, elev])

func test_tile_types_assigned():
	if not FileAccess.file_exists(PNG_PATH):
		return

	var source = PNGTerrainSource.new(PNG_PATH)
	var chunk = source.load_chunk(Vector2i(5, 5))

	# Check that tile types are assigned
	var tile_type = chunk.get_tile_type(Vector2i(10, 10))
	assert_true(tile_type >= 0, "Tile type should be valid enum")

func test_consistent_chunk_loading():
	if not FileAccess.file_exists(PNG_PATH):
		return

	var source = PNGTerrainSource.new(PNG_PATH)

	# Load same chunk twice
	var chunk1 = source.load_chunk(Vector2i(5, 10))
	var chunk2 = source.load_chunk(Vector2i(5, 10))

	# Should load identical data
	var pos = Vector2i(32, 32)
	assert_eq(chunk1.get_elevation(pos), chunk2.get_elevation(pos), "Same chunk loads identical data")

func test_adjacent_chunks_different():
	if not FileAccess.file_exists(PNG_PATH):
		return

	var source = PNGTerrainSource.new(PNG_PATH)

	var chunk1 = source.load_chunk(Vector2i(10, 10))
	var chunk2 = source.load_chunk(Vector2i(11, 10))

	# Adjacent chunks should have different data (unless terrain is perfectly uniform)
	var elev1 = chunk1.get_elevation(Vector2i(32, 32))
	var elev2 = chunk2.get_elevation(Vector2i(32, 32))

	# Allow small tolerance for uniform terrain, but expect some variation
	var has_variation = abs(elev1 - elev2) > 0.01

	# If no variation, check another position
	if not has_variation:
		elev1 = chunk1.get_elevation(Vector2i(0, 0))
		elev2 = chunk2.get_elevation(Vector2i(0, 0))
		has_variation = abs(elev1 - elev2) > 0.01

	assert_true(has_variation, "Adjacent chunks should have some variation (unless perfectly uniform terrain)")

func test_absolute_tile_coordinates_stable():
	if not FileAccess.file_exists(PNG_PATH):
		return

	var source = PNGTerrainSource.new(PNG_PATH)

	# Chunk (5, 10) contains tiles (320-383, 640-703)
	var chunk = source.load_chunk(Vector2i(5, 10))

	# Local (0, 0) = Absolute (320, 640)
	var abs_pos = chunk.get_absolute_tile_pos(Vector2i(0, 0))
	assert_eq(abs_pos, Vector2i(320, 640), "Absolute coordinates stable")

	# Local (32, 32) = Absolute (352, 672)
	abs_pos = chunk.get_absolute_tile_pos(Vector2i(32, 32))
	assert_eq(abs_pos, Vector2i(352, 672), "Absolute coordinates stable (middle)")

func test_percentile_remapping():
	if not FileAccess.file_exists(PNG_PATH):
		return

	# Load with percentile remapping enabled
	var source = PNGTerrainSource.new(PNG_PATH, true)
	assert_true(source.is_loaded(), "PNG should load with remapping")

	var chunk = source.load_chunk(Vector2i(10, 10))
	assert_not_null(chunk, "Chunk should load with remapping")

	# Elevations should still be 0.0-1.0 range
	var elev = chunk.get_elevation(Vector2i(32, 32))
	assert_true(elev >= 0.0 and elev <= 1.0, "Remapped elevation in valid range")

func test_no_percentile_remapping():
	if not FileAccess.file_exists(PNG_PATH):
		return

	# Load without percentile remapping (default)
	var source = PNGTerrainSource.new(PNG_PATH, false)
	var chunk = source.load_chunk(Vector2i(10, 10))

	assert_not_null(chunk, "Chunk should load without remapping")

	# Elevations should be raw PNG values
	var elev = chunk.get_elevation(Vector2i(32, 32))
	assert_true(elev >= 0.0 and elev <= 1.0, "Raw elevation in valid range")
