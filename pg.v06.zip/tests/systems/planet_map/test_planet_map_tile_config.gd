extends "res://tests/test_base.gd"

# Tests for PlanetMapTileConfig constants and helpers

func test_map_size_is_square():
	assert_eq(PlanetMapTileConfig.MAP_SIZE.x, PlanetMapTileConfig.MAP_SIZE.y)

func test_map_size_is_64():
	assert_eq(PlanetMapTileConfig.MAP_SIZE.x, 64)

func test_tile_size_dimensions():
	# Isometric tiles are wider than tall (2:1 ratio)
	assert_eq(PlanetMapTileConfig.TILE_SIZE.x, 160)
	assert_eq(PlanetMapTileConfig.TILE_SIZE.y, 80)

func test_tile_offset_is_half_tile():
	assert_eq(PlanetMapTileConfig.TILE_OFFSET.x, PlanetMapTileConfig.TILE_SIZE.x / 2)
	assert_eq(PlanetMapTileConfig.TILE_OFFSET.y, PlanetMapTileConfig.TILE_SIZE.y / 2)

func test_max_layers():
	assert_eq(PlanetMapTileConfig.MAX_LAYERS, 8)

func test_layer_darkening_range():
	assert_gte(PlanetMapTileConfig.LAYER_DARKENING_MIN, 0.0, "Min darkening should be >= 0")
	assert_lte(PlanetMapTileConfig.LAYER_DARKENING_MAX, 1.0, "Max darkening should be <= 1")
	assert_lt(PlanetMapTileConfig.LAYER_DARKENING_MIN, PlanetMapTileConfig.LAYER_DARKENING_MAX)

func test_tileset_texture_loaded():
	assert_not_null(PlanetMapTileConfig.TILESET_TEXTURE)

func test_get_atlas_coords_valid_tile():
	var coords = PlanetMapTileConfig.get_atlas_coords(PlanetMapTileConfig.TileType.GRASS_0)
	assert_ne(coords, Vector2i(-1, -1), "GRASS_0 should have valid atlas coords")

func test_get_atlas_coords_all_tiles_mapped():
	# All defined tile types should have atlas mappings
	for tile_type in PlanetMapTileConfig.TILESET_REGION_MAP.keys():
		var coords = PlanetMapTileConfig.get_atlas_coords(tile_type)
		assert_ne(coords, Vector2i(-1, -1), "Tile type %d should be mapped" % tile_type)

func test_get_tileset_region_returns_rect():
	var region = PlanetMapTileConfig.get_tileset_region(PlanetMapTileConfig.TileType.ROCK)
	assert_gt(region.size.x, 0, "Region width should be positive")
	assert_gt(region.size.y, 0, "Region height should be positive")

func test_tileset_region_size_accounts_for_inset():
	# Region size is SOURCE_TILE_SIZE - (INSET * 2) due to 1-pixel inset on each edge
	var region = PlanetMapTileConfig.get_tileset_region(PlanetMapTileConfig.TileType.FRESH_WATER)
	var inset = PlanetMapTileConfig.TILESET_REGION_INSET
	var expected_size = PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE - inset * 2
	assert_eq(region.size.x, expected_size.x)
	assert_eq(region.size.y, expected_size.y)

func test_surface_feature_tiles_exist():
	# Verify surface feature tile types are defined
	var sf_tiles = [
		PlanetMapTileConfig.TileType.SF_GRASS,
		PlanetMapTileConfig.TileType.SF_TREE_1,
		PlanetMapTileConfig.TileType.SF_TREE_2,
		PlanetMapTileConfig.TileType.SF_TREE_3,
		PlanetMapTileConfig.TileType.SF_LONG_HOUSE
	]
	for tile in sf_tiles:
		var coords = PlanetMapTileConfig.get_atlas_coords(tile)
		assert_ne(coords, Vector2i(-1, -1), "Surface feature should have atlas coords")

func test_terrain_tiles_exist():
	var terrain_tiles = [
		PlanetMapTileConfig.TileType.GRASS_0,
		PlanetMapTileConfig.TileType.ROCK,
		PlanetMapTileConfig.TileType.FRESH_WATER,
		PlanetMapTileConfig.TileType.ICE,
		PlanetMapTileConfig.TileType.VOLCANIC,
		PlanetMapTileConfig.TileType.DESERT
	]
	for tile in terrain_tiles:
		var coords = PlanetMapTileConfig.get_atlas_coords(tile)
		assert_ne(coords, Vector2i(-1, -1), "Terrain tile should have atlas coords")

func test_camera_zoom_range():
	assert_lt(PlanetMapTileConfig.CAMERA_ZOOM_MIN.x, PlanetMapTileConfig.CAMERA_ZOOM_MAX.x)
	assert_gt(PlanetMapTileConfig.CAMERA_ZOOM_MIN.x, 0.0, "Min zoom should be positive")

func test_get_elevation_brightness_range():
	# Verify that brightness values are within valid range
	# get_elevation_brightness uses NUM_RENDER_LAYERS (16), not MAX_LAYERS (8)
	var brightness_min = PlanetMapTileConfig.get_elevation_brightness(0)
	var brightness_max = PlanetMapTileConfig.get_elevation_brightness(PlanetMapTileConfig.NUM_RENDER_LAYERS - 1)
	assert_eq(brightness_min, PlanetMapTileConfig.LAYER_DARKENING_MIN, "Elevation 0 should have minimum brightness")
	assert_eq(brightness_max, PlanetMapTileConfig.LAYER_DARKENING_MAX, "Max elevation should have maximum brightness")

func test_get_elevation_brightness_progression():
	# Verify that brightness increases monotonically with elevation
	# Uses NUM_RENDER_LAYERS (16) not MAX_LAYERS (8)
	var prev_brightness = PlanetMapTileConfig.get_elevation_brightness(0)
	for elev in range(1, PlanetMapTileConfig.NUM_RENDER_LAYERS):
		var curr_brightness = PlanetMapTileConfig.get_elevation_brightness(elev)
		assert_gt(curr_brightness, prev_brightness, "Brightness should increase with elevation %d" % elev)
		prev_brightness = curr_brightness

func test_get_elevation_brightness_within_bounds():
	# Verify that all brightness values are between 0.0 and 1.0
	for elev in range(PlanetMapTileConfig.NUM_RENDER_LAYERS):
		var brightness = PlanetMapTileConfig.get_elevation_brightness(elev)
		assert_gte(brightness, 0.0, "Brightness at elevation %d should be >= 0.0" % elev)
		assert_lte(brightness, 1.0, "Brightness at elevation %d should be <= 1.0" % elev)

func test_get_elevation_brightness_linear_interpolation():
	# Verify that brightness follows linear interpolation formula
	var min_val = PlanetMapTileConfig.LAYER_DARKENING_MIN
	var max_val = PlanetMapTileConfig.LAYER_DARKENING_MAX
	var num_layers = PlanetMapTileConfig.NUM_RENDER_LAYERS

	for elev in range(num_layers):
		var expected = min_val + (float(elev) / float(num_layers - 1)) * (max_val - min_val)
		var actual = PlanetMapTileConfig.get_elevation_brightness(elev)
		# Allow small floating point differences
		assert_gte(actual, expected - 0.001, "Brightness at elevation %d should match formula" % elev)
		assert_lte(actual, expected + 0.001, "Brightness at elevation %d should match formula" % elev)
