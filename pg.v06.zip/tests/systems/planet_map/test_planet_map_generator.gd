extends "res://tests/test_base.gd"

# Tests for PlanetMapGenerator

var generator: PlanetMapGenerator

func before_each():
	generator = PlanetMapGenerator.new()

func test_generator_creates():
	assert_not_null(generator)

func test_map_size_constant():
	assert_eq(generator.MAP_SIZE, Vector2i(64, 64))

func test_max_elevation_constant():
	assert_eq(generator.MAX_ELEVATION, 7)

func test_elevation_patterns_defined():
	# Verify all expected patterns exist
	assert_eq(generator.ElevationPattern.FLAT, 0)
	assert_eq(generator.ElevationPattern.RANDOM, 1)
	assert_eq(generator.ElevationPattern.NOISE, 2)
	assert_eq(generator.ElevationPattern.HILLS, 3)
	assert_eq(generator.ElevationPattern.MOUNTAIN, 4)
	assert_eq(generator.ElevationPattern.CRATER, 5)
	assert_eq(generator.ElevationPattern.ISLAND, 6)
	assert_eq(generator.ElevationPattern.RIDGES, 7)

func test_noise_generators_initialized():
	assert_not_null(generator.heightmap_noise)
	assert_not_null(generator.temperature_noise)
	assert_not_null(generator.moisture_noise)
	assert_not_null(generator.geological_noise)

func test_calculate_elevation_flat_pattern():
	var elevation = generator._calculate_elevation_for_cell(
		Vector2i(10, 10),
		generator.ElevationPattern.FLAT,
		7
	)
	assert_eq(elevation, 0, "Flat pattern should always return 0")

func test_calculate_elevation_flat_all_cells():
	# All cells should be 0 for flat pattern
	for x in range(10):
		for y in range(10):
			var elevation = generator._calculate_elevation_for_cell(
				Vector2i(x, y),
				generator.ElevationPattern.FLAT,
				7
			)
			assert_eq(elevation, 0)

func test_calculate_elevation_clamped_to_max():
	# Test that elevation is always within bounds
	var patterns = [
		generator.ElevationPattern.RANDOM,
		generator.ElevationPattern.NOISE,
		generator.ElevationPattern.HILLS,
		generator.ElevationPattern.MOUNTAIN,
		generator.ElevationPattern.CRATER,
		generator.ElevationPattern.ISLAND,
		generator.ElevationPattern.RIDGES
	]
	for pattern in patterns:
		for i in range(20):
			var cell = Vector2i(randi() % 64, randi() % 64)
			var elevation = generator._calculate_elevation_for_cell(cell, pattern, 7)
			assert_gte(elevation, 0, "Elevation should be >= 0")
			assert_lte(elevation, 7, "Elevation should be <= MAX_ELEVATION")

func test_calculate_elevation_mountain_center_higher():
	# Mountain pattern should have higher elevation at center
	var center_elev = generator._calculate_elevation_for_cell(
		Vector2i(32, 32),
		generator.ElevationPattern.MOUNTAIN,
		7
	)
	var edge_elev = generator._calculate_elevation_for_cell(
		Vector2i(0, 0),
		generator.ElevationPattern.MOUNTAIN,
		7
	)
	assert_gte(center_elev, edge_elev, "Mountain center should be >= edges")

func test_calculate_elevation_crater_center_lower():
	# Crater pattern should have lower elevation at center
	var center_elev = generator._calculate_elevation_for_cell(
		Vector2i(32, 32),
		generator.ElevationPattern.CRATER,
		7
	)
	var edge_elev = generator._calculate_elevation_for_cell(
		Vector2i(0, 0),
		generator.ElevationPattern.CRATER,
		7
	)
	assert_lte(center_elev, edge_elev, "Crater center should be <= edges")

func test_initialize_tile_array_creates_correct_size():
	var tiles = generator._initialize_tile_array()
	assert_eq(tiles.size(), 64, "Should have 64 columns")
	assert_eq(tiles[0].size(), 64, "Should have 64 rows")

func test_initialize_tile_array_all_tiles_exist():
	var tiles = generator._initialize_tile_array()
	for x in range(64):
		for y in range(64):
			assert_not_null(tiles[x][y], "Tile at [%d][%d] should exist" % [x, y])

func test_initialize_tile_array_positions_correct():
	var tiles = generator._initialize_tile_array()
	# Check a few positions
	assert_eq(tiles[0][0].position, Vector2i(0, 0))
	assert_eq(tiles[10][20].position, Vector2i(10, 20))
	assert_eq(tiles[63][63].position, Vector2i(63, 63))

func test_seed_produces_deterministic_results():
	# Same seed should produce same elevation map
	generator._map_seed = 12345
	generator.planet_data = {"planet_type": -1}
	generator.geological_activity = "MODERATE"
	generator._configure_noise_for_planet()

	var map1 = generator._generate_elevation_map()

	# Reset and generate again with same seed
	generator._map_seed = 12345
	generator._configure_noise_for_planet()

	var map2 = generator._generate_elevation_map()

	# Compare a sample of cells
	var test_cells = [Vector2i(0,0), Vector2i(10,10), Vector2i(32,32), Vector2i(50,50)]
	for cell in test_cells:
		assert_eq(map1[cell], map2[cell], "Same seed should produce same elevation at %s" % cell)

func test_different_seeds_produce_different_results():
	generator.planet_data = {"planet_type": -1}
	generator.geological_activity = "MODERATE"

	generator._map_seed = 11111
	generator._configure_noise_for_planet()
	var map1 = generator._generate_elevation_map()

	generator._map_seed = 99999
	generator._configure_noise_for_planet()
	var map2 = generator._generate_elevation_map()

	# At least some cells should differ
	var differences = 0
	for x in range(0, 64, 8):
		for y in range(0, 64, 8):
			var cell = Vector2i(x, y)
			if map1[cell] != map2[cell]:
				differences += 1

	assert_gt(differences, 0, "Different seeds should produce different maps")
