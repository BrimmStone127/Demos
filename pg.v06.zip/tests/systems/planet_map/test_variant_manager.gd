extends "res://tests/test_base.gd"

## Tests for VariantTheme and VariantManager classes
##
## Tests cover:
## - VariantTheme creation and serialization
## - Category vs tile-specific priority
## - VariantManager singleton behavior
## - Theme switching and application

func before_each():
	# Reset singleton between tests
	VariantManager.reset_instance()

func after_each():
	VariantManager.reset_instance()
	super.after_each()


# === VariantTheme Tests ===

func test_theme_creation():
	var theme = VariantTheme.new()
	theme.name = "test_theme"
	theme.description = "A test theme"

	assert_eq(theme.name, "test_theme", "Theme name should be set")
	assert_eq(theme.description, "A test theme", "Theme description should be set")
	assert_false(theme.has_variants(), "New theme should have no variants")


func test_theme_tile_variant():
	var theme = VariantTheme.new()
	theme.name = "tile_test"

	theme.set_tile_variant(93, "custom_variant")
	assert_eq(theme.get_variant_for_tile(93, "Trees"), "custom_variant", "Should return tile-specific variant")
	assert_true(theme.has_variants(), "Theme should have variants after adding one")


func test_theme_category_variant():
	var theme = VariantTheme.new()
	theme.name = "category_test"

	theme.set_category_variant("Trees", "forest_variant")
	assert_eq(theme.get_variant_for_tile(93, "Trees"), "forest_variant", "Should return category variant")
	assert_eq(theme.get_variant_for_tile(94, "Trees"), "forest_variant", "Should return category variant for any tile in category")


func test_theme_tile_priority_over_category():
	var theme = VariantTheme.new()
	theme.name = "priority_test"

	# Set both category and tile-specific
	theme.set_category_variant("Trees", "category_var")
	theme.set_tile_variant(93, "tile_var")

	assert_eq(theme.get_variant_for_tile(93, "Trees"), "tile_var", "Tile-specific should override category")
	assert_eq(theme.get_variant_for_tile(94, "Trees"), "category_var", "Other tiles should use category")


func test_theme_clear_tile_variant():
	var theme = VariantTheme.new()
	theme.name = "clear_test"

	theme.set_category_variant("Trees", "category_var")
	theme.set_tile_variant(93, "tile_var")

	# Clear tile-specific, should fall back to category
	theme.clear_tile_variant(93)
	assert_eq(theme.get_variant_for_tile(93, "Trees"), "category_var", "Should fall back to category after clearing tile variant")


func test_theme_no_variant():
	var theme = VariantTheme.new()
	theme.name = "empty_test"

	assert_eq(theme.get_variant_for_tile(93, "Trees"), "", "Should return empty string when no variant defined")
	assert_eq(theme.get_variant_for_tile(93, "Other"), "", "Should return empty string for unknown category")


func test_theme_serialization():
	var theme = VariantTheme.new()
	theme.name = "serialize_test"
	theme.description = "Test serialization"
	theme.set_tile_variant(93, "tile_var")
	theme.set_category_variant("Trees", "cat_var")

	# Serialize
	var data = theme.to_dict()

	# Deserialize
	var restored = VariantTheme.from_dict(data)

	assert_eq(restored.name, "serialize_test", "Name should be preserved")
	assert_eq(restored.description, "Test serialization", "Description should be preserved")
	assert_eq(restored.get_variant_for_tile(93, "Trees"), "tile_var", "Tile variant should be preserved")
	assert_eq(restored.get_variant_for_tile(94, "Trees"), "cat_var", "Category variant should be preserved")


func test_theme_duplicate():
	var theme = VariantTheme.new()
	theme.name = "original"
	theme.set_tile_variant(93, "var1")

	var copy = theme.duplicate_theme()
	copy.name = "copy"
	copy.set_tile_variant(93, "var2")

	assert_eq(theme.get_variant_for_tile(93, ""), "var1", "Original should be unchanged")
	assert_eq(copy.get_variant_for_tile(93, ""), "var2", "Copy should have new value")


# === VariantManager Tests ===

func test_manager_singleton():
	var vm1 = VariantManager.get_instance()
	var vm2 = VariantManager.get_instance()

	assert_eq(vm1, vm2, "Should return same instance")
	assert_not_null(vm1, "Instance should not be null")


func test_manager_builtin_themes():
	var vm = VariantManager.get_instance()
	var names = vm.get_all_theme_names()

	assert_has(names, "default", "Should have default theme")
	assert_has(names, "verdant", "Should have verdant theme")
	assert_gte(names.size(), 2, "Should have at least 2 themes")


func test_manager_default_theme():
	var vm = VariantManager.get_instance()
	var theme = vm.get_current_theme()

	assert_not_null(theme, "Should have a current theme")
	assert_eq(theme.name, "verdant", "Default theme should be 'verdant' (matches old behavior)")


func test_manager_set_theme():
	var vm = VariantManager.get_instance()

	var result = vm.set_theme("verdant")
	assert_true(result, "Setting verdant theme should succeed")
	assert_eq(vm.get_current_theme_name(), "verdant", "Current theme should be verdant")


func test_manager_set_invalid_theme():
	var vm = VariantManager.get_instance()

	var result = vm.set_theme("nonexistent_theme")
	assert_false(result, "Setting invalid theme should fail")
	assert_eq(vm.get_current_theme_name(), "verdant", "Should remain on verdant theme")


func test_manager_add_custom_theme():
	var vm = VariantManager.get_instance()

	var custom = VariantTheme.new()
	custom.name = "custom_test"
	custom.description = "Custom test theme"
	custom.set_category_variant("Trees", "custom_var")

	vm.add_theme(custom)

	var names = vm.get_all_theme_names()
	assert_has(names, "custom_test", "Custom theme should be added")

	var result = vm.set_theme("custom_test")
	assert_true(result, "Should be able to set custom theme")
	assert_eq(vm.get_current_theme_name(), "custom_test", "Current theme should be custom_test")


func test_manager_remove_custom_theme():
	var vm = VariantManager.get_instance()

	# Add then remove
	var custom = VariantTheme.new()
	custom.name = "to_remove"
	vm.add_theme(custom)
	vm.set_theme("to_remove")

	var result = vm.remove_theme("to_remove")
	assert_true(result, "Should succeed in removing custom theme")
	assert_does_not_have(vm.get_all_theme_names(), "to_remove", "Theme should be removed")
	assert_eq(vm.get_current_theme_name(), "verdant", "Should fall back to verdant after removal")


func test_manager_cannot_remove_builtin_themes():
	var vm = VariantManager.get_instance()

	var result1 = vm.remove_theme("default")
	assert_false(result1, "Should not be able to remove default theme")

	var result2 = vm.remove_theme("verdant")
	assert_false(result2, "Should not be able to remove verdant theme")


func test_manager_theme_changed_signal():
	var vm = VariantManager.get_instance()

	# Use a callable array to capture signal data (lambdas with closures can be tricky)
	var signal_data := []

	var callback = func(name: String):
		signal_data.append(name)

	vm.theme_changed.connect(callback)

	# Change to default first (since we start at verdant now)
	vm.set_theme("default")

	assert_eq(signal_data.size(), 1, "theme_changed signal should be emitted once")
	if signal_data.size() > 0:
		assert_eq(signal_data[0], "default", "Signal should include new theme name")


func test_manager_vegetative_tile_ids():
	var ids = VariantManager.get_vegetative_tree_tile_ids()

	assert_eq(ids.size(), 9, "Should return 9 vegetative tree tile IDs (6 maple + beech + oak + birch)")
	# Row 4, Cols 14-19: IDs are 4*20+14=94 through 4*20+19=99 (Maple VG)
	assert_has(ids, 94, "Should include Maple VG_1 tile (ID 94)")
	assert_has(ids, 99, "Should include Maple VG_6 tile (ID 99)")
	# Beech VG: Row 7, Col 0 (ID 140)
	assert_has(ids, 140, "Should include Beech VG tile (ID 140)")
	# Oak VG: Row 7, Col 3 (ID 143)
	assert_has(ids, 143, "Should include Oak VG tile (ID 143)")
	# Birch VG: Row 7, Col 5 (ID 145)
	assert_has(ids, 145, "Should include Birch VG tile (ID 145)")


func test_manager_verdant_theme_maps_trees():
	var vm = VariantManager.get_instance()
	vm.set_theme("verdant")

	var theme = vm.get_current_theme()
	assert_not_null(theme, "Verdant theme should exist")

	# Verdant theme should map Trees category to "vrdant" variant
	var variant_name = theme.get_variant_for_tile(93, "Trees")
	assert_eq(variant_name, "vrdant", "Verdant theme should map Trees to 'vrdant'")


func test_manager_reset():
	var vm1 = VariantManager.get_instance()
	vm1.set_theme("default")  # Change to something other than verdant

	VariantManager.reset_instance()

	var vm2 = VariantManager.get_instance()
	assert_ne(vm1, vm2, "After reset, should get new instance")
	assert_eq(vm2.get_current_theme_name(), "verdant", "New instance should start with verdant theme")
