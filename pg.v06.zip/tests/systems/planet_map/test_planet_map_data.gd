extends "res://tests/test_base.gd"

## Tests for PlanetMapData - central data store for planet map information

var map_data: PlanetMapData

func before_each():
	map_data = PlanetMapData.new(Vector2i(64, 64), "test_planet")

# --- Initialization ---

func test_default_initialization():
	var md = PlanetMapData.new()
	assert_eq(md.map_size, Vector2i(64, 64), "Default map size")
	assert_eq(md.planet_id, "", "Default planet_id is empty")
	assert_not_null(md.coordinate_system, "CoordinateSystem created")

func test_custom_initialization():
	assert_eq(map_data.map_size, Vector2i(64, 64), "Custom map size")
	assert_eq(map_data.planet_id, "test_planet", "Custom planet_id")

func test_coordinate_system_created():
	assert_not_null(map_data.coordinate_system, "Has coordinate system")
	assert_eq(map_data.coordinate_system.map_size, Vector2i(64, 64), "Coord sys has correct size")

func test_tiles_initialized():
	assert_eq(map_data.tiles.size(), 64, "64 rows created")
	assert_eq(map_data.tiles[0].size(), 64, "64 columns per row")

# --- Tile access ---

func test_get_tile_null_by_default():
	var tile = map_data.get_tile(Vector2i(10, 10))
	assert_null(tile, "Tiles are null by default")

func test_set_and_get_tile():
	var tile = MapTile.new(Vector2i(10, 10))
	tile.type = PlanetMapTileConfig.TileType.GRASS_0

	map_data.set_tile(Vector2i(10, 10), tile)
	var retrieved = map_data.get_tile(Vector2i(10, 10))

	assert_not_null(retrieved, "Tile retrieved")
	assert_eq(retrieved.type, PlanetMapTileConfig.TileType.GRASS_0, "Correct type")

func test_get_tile_out_of_bounds():
	var tile = map_data.get_tile(Vector2i(-1, 0))
	assert_null(tile, "Negative X returns null")

	tile = map_data.get_tile(Vector2i(0, -1))
	assert_null(tile, "Negative Y returns null")

	tile = map_data.get_tile(Vector2i(64, 0))
	assert_null(tile, "X at bounds returns null")

	tile = map_data.get_tile(Vector2i(0, 64))
	assert_null(tile, "Y at bounds returns null")

func test_set_tile_out_of_bounds_no_error():
	# Should not crash, just silently fail
	var tile = MapTile.new(Vector2i(-1, -1))
	map_data.set_tile(Vector2i(-1, -1), tile)
	map_data.set_tile(Vector2i(100, 100), tile)
	# No assertion - just verifying no crash

# --- Bulk operations ---

func test_set_all_tiles():
	# Create a 4x4 tile array
	var new_tiles: Array = []
	for x in range(4):
		var row: Array = []
		for y in range(4):
			var tile = MapTile.new(Vector2i(x, y))
			tile.type = PlanetMapTileConfig.TileType.ROCK
			row.append(tile)
		new_tiles.append(row)

	map_data.set_all_tiles(new_tiles)

	assert_eq(map_data.map_size, Vector2i(4, 4), "Map size updated")
	assert_eq(map_data.tiles.size(), 4, "Tiles array updated")

func test_set_all_tiles_updates_coordinate_system():
	var new_tiles: Array = []
	for x in range(128):
		var row: Array = []
		row.resize(128)
		new_tiles.append(row)

	map_data.set_all_tiles(new_tiles)

	assert_eq(map_data.coordinate_system.map_size, Vector2i(128, 128), "Coord sys updated")

func test_get_all_tiles():
	var tiles = map_data.get_all_tiles()
	assert_eq(tiles.size(), 64, "Returns reference to tiles array")

func test_is_empty():
	var md = PlanetMapData.new()
	assert_false(md.is_empty(), "Not empty after initialization (has null slots)")

	md.tiles.clear()
	assert_true(md.is_empty(), "Empty after clear")

func test_get_tile_count():
	# 64x64 = 4096 slots (even if null)
	assert_eq(map_data.get_tile_count(), 4096, "Count includes all slots")

# --- Serialization ---

func test_to_dict_basic_structure():
	var dict = map_data.to_dict()

	assert_has(dict, "map_size", "Has map_size")
	assert_has(dict, "planet_id", "Has planet_id")
	assert_has(dict, "tiles", "Has tiles")

	assert_eq(dict["planet_id"], "test_planet", "Correct planet_id")
	assert_eq(dict["map_size"]["x"], 64, "Correct map width")
	assert_eq(dict["map_size"]["y"], 64, "Correct map height")

func test_from_dict():
	var dict = {
		"map_size": {"x": 32, "y": 32},
		"planet_id": "restored_planet",
		"tiles": []
	}

	var restored = PlanetMapData.from_dict(dict)

	assert_eq(restored.map_size, Vector2i(32, 32), "Size restored")
	assert_eq(restored.planet_id, "restored_planet", "Planet ID restored")

# --- String representation ---

func test_to_string():
	var s = str(map_data)
	assert_string_contains(s, "test_planet", "Contains planet_id")
	assert_string_contains(s, "64", "Contains size")

# --- Planet metadata ---

func test_planet_reference():
	assert_null(map_data.planet, "Planet null by default")

	# Create mock planet - not testing full Planet class here
	map_data.planet_id = "new_planet"
	assert_eq(map_data.planet_id, "new_planet", "Can set planet_id")

func test_probe_data():
	assert_eq(map_data.probe_data.size(), 0, "Probe data empty by default")

	map_data.probe_data = {"habitability_score": 0.75}
	assert_eq(map_data.probe_data["habitability_score"], 0.75, "Can set probe data")

# --- Coordinate system delegation ---

func test_coordinate_system_tile_validation():
	# Verify the coordinate system is properly connected
	assert_true(map_data.coordinate_system.is_valid_tile(Vector2i(32, 32)), "Valid tile")
	assert_false(map_data.coordinate_system.is_valid_tile(Vector2i(64, 64)), "Invalid tile")

func test_coordinate_system_conversion():
	var world = map_data.coordinate_system.tile_to_world(Vector2i(1, 0))
	assert_eq(world.x, 80.0, "World X from coord sys")
	assert_eq(world.y, 40.0, "World Y from coord sys")
