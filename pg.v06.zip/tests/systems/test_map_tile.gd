extends "res://tests/test_base.gd"

func test_default_construction():
	var tile = MapTile.new(Vector2i(0, 0))
	assert_eq(tile.type, PlanetMapTileConfig.TileType.ROCK)
	assert_eq(tile.position, Vector2i(0, 0))

func test_custom_tile_type():
	var tile = MapTile.new(Vector2i(1, 2), PlanetMapTileConfig.TileType.FRESH_WATER)
	assert_eq(tile.type, PlanetMapTileConfig.TileType.FRESH_WATER)

func test_position_stored():
	var tile = MapTile.new(Vector2i(15, 23))
	assert_eq(tile.position.x, 15)
	assert_eq(tile.position.y, 23)

func test_default_elevation():
	var tile = MapTile.new(Vector2i(0, 0))
	assert_eq(tile.elevation, 0)

func test_surface_feature_default_null():
	var tile = MapTile.new(Vector2i(0, 0))
	assert_null(tile.surface_feature_type)
