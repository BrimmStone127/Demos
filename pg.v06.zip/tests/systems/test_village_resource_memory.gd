extends "res://tests/test_base.gd"

var mem: VillageResourceMemory


func before_each():
	mem = VillageResourceMemory.new()


func test_initial_state_empty():
	assert_eq(mem.get_known_count(VillageResourceMemory.BERRY), 0, "Berry known count starts at 0")
	assert_eq(mem.get_known_count(VillageResourceMemory.FIREWOOD), 0, "Firewood known count starts at 0")
	assert_eq(mem.get_known_count(VillageResourceMemory.WATER), 0, "Water known count starts at 0")
	assert_eq(mem.camp_position, Vector2i(-1, -1), "Camp starts invalid")


func test_add_known():
	mem.add_known(VillageResourceMemory.BERRY, Vector2i(10, 20))
	assert_true(mem.has_known(VillageResourceMemory.BERRY, Vector2i(10, 20)), "Berry should be known")
	assert_eq(mem.get_known_count(VillageResourceMemory.BERRY), 1, "Berry count should be 1")


func test_add_known_ignores_invalid():
	mem.add_known(VillageResourceMemory.BERRY, Vector2i(-1, -1))
	assert_eq(mem.get_known_count(VillageResourceMemory.BERRY), 0, "Invalid position should not be added")


func test_add_known_deduplicates():
	mem.add_known(VillageResourceMemory.BERRY, Vector2i(5, 5))
	mem.add_known(VillageResourceMemory.BERRY, Vector2i(5, 5))
	assert_eq(mem.get_known_count(VillageResourceMemory.BERRY), 1, "Duplicate should not increase count")


func test_remove_known():
	mem.add_known(VillageResourceMemory.FIREWOOD, Vector2i(10, 10))
	mem.remove_known(VillageResourceMemory.FIREWOOD, Vector2i(10, 10))
	assert_false(mem.has_known(VillageResourceMemory.FIREWOOD, Vector2i(10, 10)), "Should be removed")
	assert_eq(mem.get_known_count(VillageResourceMemory.FIREWOOD), 0, "Count should be 0 after removal")


func test_remove_nonexistent_no_error():
	mem.remove_known(VillageResourceMemory.BERRY, Vector2i(99, 99))
	assert_eq(mem.get_known_count(VillageResourceMemory.BERRY), 0, "Removing nonexistent should not error")


func test_get_all_known():
	mem.add_known(VillageResourceMemory.BERRY, Vector2i(1, 1))
	mem.add_known(VillageResourceMemory.BERRY, Vector2i(2, 2))
	mem.add_known(VillageResourceMemory.BERRY, Vector2i(3, 3))
	var all := mem.get_all_known(VillageResourceMemory.BERRY)
	assert_eq(all.size(), 3, "Should return all 3 known positions")
	assert_true(Vector2i(1, 1) in all, "Should contain (1,1)")
	assert_true(Vector2i(2, 2) in all, "Should contain (2,2)")
	assert_true(Vector2i(3, 3) in all, "Should contain (3,3)")


func test_get_all_known_empty_type():
	var all := mem.get_all_known("nonexistent")
	assert_eq(all.size(), 0, "Unknown type should return empty array")


func test_has_known_false_for_unknown():
	assert_false(mem.has_known(VillageResourceMemory.BERRY, Vector2i(1, 1)), "Should be false when not added")


func test_set_target():
	mem.set_target(VillageResourceMemory.BERRY, Vector2i(15, 25))
	assert_eq(mem.get_target(VillageResourceMemory.BERRY), Vector2i(15, 25), "Target should match set value")


func test_set_target_also_adds_to_known():
	mem.set_target(VillageResourceMemory.FIREWOOD, Vector2i(8, 12))
	assert_true(mem.has_known(VillageResourceMemory.FIREWOOD, Vector2i(8, 12)), "Setting target should add to known")


func test_get_target_default():
	assert_eq(mem.get_target(VillageResourceMemory.BERRY), Vector2i(-1, -1), "Default target should be (-1,-1)")


func test_multiple_types_independent():
	mem.add_known(VillageResourceMemory.BERRY, Vector2i(1, 1))
	mem.add_known(VillageResourceMemory.FIREWOOD, Vector2i(2, 2))
	assert_eq(mem.get_known_count(VillageResourceMemory.BERRY), 1, "Berry count independent")
	assert_eq(mem.get_known_count(VillageResourceMemory.FIREWOOD), 1, "Firewood count independent")
	assert_false(mem.has_known(VillageResourceMemory.BERRY, Vector2i(2, 2)), "Berry should not have firewood position")


func test_clear():
	mem.add_known(VillageResourceMemory.BERRY, Vector2i(1, 1))
	mem.add_known(VillageResourceMemory.FIREWOOD, Vector2i(2, 2))
	mem.set_target(VillageResourceMemory.BERRY, Vector2i(1, 1))
	mem.camp_position = Vector2i(50, 50)
	mem.clear()
	assert_eq(mem.get_known_count(VillageResourceMemory.BERRY), 0, "Berry cleared")
	assert_eq(mem.get_known_count(VillageResourceMemory.FIREWOOD), 0, "Firewood cleared")
	assert_eq(mem.get_target(VillageResourceMemory.BERRY), Vector2i(-1, -1), "Target cleared")
	assert_eq(mem.camp_position, Vector2i(-1, -1), "Camp cleared")


func test_village_instance_creates_resource_memory():
	var village = VillageInstance.new()
	village.initialize("test_v", "planet_1", "mississippi_early", {
		"starting_era": "nomadic",
		"starting_skills": [],
		"starting_political_traits": {},
		"names_male": ["Man"],
		"names_female": ["Woman"],
	})
	assert_not_null(village.resource_memory, "VillageInstance should create resource_memory on initialize")


func test_village_instance_pos_delegates_to_memory():
	var village = VillageInstance.new()
	village.initialize("test_v", "planet_1", "mississippi_early", {
		"starting_era": "nomadic",
		"starting_skills": [],
		"starting_political_traits": {},
		"names_male": ["Man"],
		"names_female": ["Woman"],
	})
	village.berry_pos = Vector2i(10, 20)
	assert_eq(village.berry_pos, Vector2i(10, 20), "berry_pos getter should delegate to resource_memory")
	assert_eq(village.resource_memory.get_target(VillageResourceMemory.BERRY), Vector2i(10, 20), "Target should match")
	assert_true(village.resource_memory.has_known(VillageResourceMemory.BERRY, Vector2i(10, 20)), "Should be in known set")


func test_village_instance_firewood_pos_delegates():
	var village = VillageInstance.new()
	village.initialize("test_v", "planet_1", "mississippi_early", {
		"starting_era": "nomadic",
		"starting_skills": [],
		"starting_political_traits": {},
		"names_male": ["Man"],
		"names_female": ["Woman"],
	})
	village.firewood_pos = Vector2i(30, 40)
	assert_eq(village.firewood_pos, Vector2i(30, 40), "firewood_pos should delegate")
	assert_true(village.resource_memory.has_known(VillageResourceMemory.FIREWOOD, Vector2i(30, 40)), "Should be in known set")


func test_village_instance_no_init_returns_default():
	var village = VillageInstance.new()
	assert_eq(village.berry_pos, Vector2i(-1, -1), "berry_pos should return default without init")
	assert_eq(village.firewood_pos, Vector2i(-1, -1), "firewood_pos should return default without init")
	assert_eq(village.water_pos, Vector2i(-1, -1), "water_pos should return default without init")
