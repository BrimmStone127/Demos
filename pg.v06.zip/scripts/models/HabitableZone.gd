class_name HabitableZone
extends RefCounted

const LOG_TAG := "HABITABLE_ZONE"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


# Fixed habitable zone calculation with proper scaling and detection

enum ZoneType {
	TOO_HOT,           # Inside habitable zone - too close to star
	CONSERVATIVE,      # Conservative habitable zone (Earth-like conditions)
	OPTIMISTIC,        # Optimistic habitable zone (broader conditions)
	TOO_COLD,          # Outside habitable zone - too far from star
	FROZEN             # Extremely cold, beyond any reasonable habitability
}

# Stellar data for habitable zone calculations
const STELLAR_DATA = {
	StarSystem.StarType.M: {
		"luminosity_range": Vector2(0.0001, 0.08),
		"lifetime": 1000.0,
		"flare_frequency": 0.8,
		"tidal_locking_distance": 0.3,
		"zone_eccentricity": 0.15
	},
	StarSystem.StarType.K: {
		"luminosity_range": Vector2(0.08, 0.4),
		"lifetime": 45.0,
		"flare_frequency": 0.3,
		"tidal_locking_distance": 0.15,
		"zone_eccentricity": 0.08
	},
	StarSystem.StarType.G: {
		"luminosity_range": Vector2(0.4, 1.5),
		"lifetime": 10.0,
		"flare_frequency": 0.1,
		"tidal_locking_distance": 0.1,
		"zone_eccentricity": 0.05
	},
	StarSystem.StarType.F: {
		"luminosity_range": Vector2(1.5, 5.0),
		"lifetime": 4.0,
		"flare_frequency": 0.05,
		"tidal_locking_distance": 0.05,
		"zone_eccentricity": 0.1
	},
	StarSystem.StarType.A: {
		"luminosity_range": Vector2(5.0, 25.0),
		"lifetime": 2.0,
		"flare_frequency": 0.02,
		"tidal_locking_distance": 0.03,
		"zone_eccentricity": 0.2
	},
	StarSystem.StarType.B: {
		"luminosity_range": Vector2(25.0, 30000.0),
		"lifetime": 0.4,
		"flare_frequency": 0.01,
		"tidal_locking_distance": 0.02,
		"zone_eccentricity": 0.3
	},
	StarSystem.StarType.O: {
		"luminosity_range": Vector2(30000.0, 100000.0),
		"lifetime": 0.01,
		"flare_frequency": 0.005,
		"tidal_locking_distance": 0.01,
		"zone_eccentricity": 0.4
	}
}

var star_type: StarSystem.StarType
var luminosity: float
var conservative_inner: float  # Now in pixels
var conservative_outer: float  # Now in pixels
var optimistic_inner: float    # Now in pixels
var optimistic_outer: float    # Now in pixels
var frost_line: float          # Now in pixels
var has_habitable_zone: bool = false

# Elliptical zone properties
var zone_eccentricity: float = 0.0
var zone_angle_offset: float = 0.0

# FIXED: Scaling factor for conversion from AU to pixels
const PIXELS_PER_AU: float = 100.0

func _init(p_star_type: StarSystem.StarType, p_luminosity: float = -1.0):
	star_type = p_star_type
	
	# Calculate or use provided luminosity
	if p_luminosity < 0:
		var lum_range = STELLAR_DATA[star_type].luminosity_range
		luminosity = randf_range(lum_range.x, lum_range.y)
	else:
		luminosity = p_luminosity
	
	# Set zone eccentricity based on star type
	zone_eccentricity = STELLAR_DATA[star_type].zone_eccentricity
	zone_eccentricity += randf_range(-0.02, 0.02)
	zone_eccentricity = clamp(zone_eccentricity, 0.0, 0.5)
	
	# Random rotation for the elliptical zone
	zone_angle_offset = randf() * 2.0 * PI
	
	_calculate_zones()

func _calculate_zones():
	# FIXED: Calculate habitable zone boundaries in AU first, then convert to pixels
	# Using more realistic scaling factors for the game
	
	# Base calculations in AU - adjusted for better game scale
	var conservative_inner_au = sqrt(luminosity / 1.5)    # Slightly smaller inner edge
	var conservative_outer_au = sqrt(luminosity / 0.8)    # Slightly smaller outer edge
	var optimistic_inner_au = sqrt(luminosity / 2.5)      # Broader inner range
	var optimistic_outer_au = sqrt(luminosity / 0.4)      # Broader outer range
	var frost_line_au = sqrt(luminosity) * 2.0            # Adjusted frost line
	
	# FIXED: Apply reasonable limits to prevent zones from being too large
	conservative_inner_au = clamp(conservative_inner_au, 0.1, 5.0)
	conservative_outer_au = clamp(conservative_outer_au, 0.2, 8.0)
	optimistic_inner_au = clamp(optimistic_inner_au, 0.05, 4.0)
	optimistic_outer_au = clamp(optimistic_outer_au, 0.3, 12.0)
	frost_line_au = clamp(frost_line_au, 1.0, 15.0)
	
	# Ensure proper ordering
	if conservative_inner_au >= conservative_outer_au:
		conservative_outer_au = conservative_inner_au + 0.5
	if optimistic_inner_au >= optimistic_outer_au:
		optimistic_outer_au = optimistic_inner_au + 0.8
	if optimistic_inner_au >= conservative_inner_au:
		optimistic_inner_au = conservative_inner_au * 0.7
	if conservative_outer_au >= optimistic_outer_au:
		optimistic_outer_au = conservative_outer_au * 1.3
	
	# FIXED: Convert to pixels ONCE
	conservative_inner = conservative_inner_au * PIXELS_PER_AU
	conservative_outer = conservative_outer_au * PIXELS_PER_AU
	optimistic_inner = optimistic_inner_au * PIXELS_PER_AU
	optimistic_outer = optimistic_outer_au * PIXELS_PER_AU
	frost_line = frost_line_au * PIXELS_PER_AU
	
	# Evaluate habitability
	has_habitable_zone = _evaluate_habitability()
	
	# Debug output
	_log_info('Habitable zone calculated:')
	_log_info('  Luminosity: %s', [snapped(luminosity, 0.01)])
	_log_info('  Conservative: %s - %s pixels', [snapped(conservative_inner, 0), snapped(conservative_outer, 0)])
	_log_info('  Optimistic: %s - %s pixels', [snapped(optimistic_inner, 0), snapped(optimistic_outer, 0)])
	_log_info('  Zone width: %s pixels', [snapped(conservative_outer - conservative_inner, 0)])

func _evaluate_habitability() -> bool:
	# Consider stellar lifetime and stability
	var stellar_data = STELLAR_DATA[star_type]
	var lifetime = stellar_data.lifetime
	
	# Very short-lived stars are uninhabitable
	if lifetime < 0.1:
		return false
	
	# Check if habitable zone is reasonable size
	var zone_width = conservative_outer - conservative_inner
	if zone_width < 10.0:  # Minimum 10 pixels wide
		return false
	
	# Most stars can have habitable zones
	return true

# FIXED: Get distance to zone center at a given angle (for elliptical zones)
func get_zone_distance_at_angle(zone_center: float, angle: float) -> float:
	# Calculate the distance from star to zone center at this angle
	var adjusted_angle = angle - zone_angle_offset
	var eccentricity_factor = 1.0 - zone_eccentricity * cos(adjusted_angle)
	return zone_center * eccentricity_factor

# FIXED: Get the zone type for a given orbital position
func get_zone_type(orbital_distance: float, orbital_angle: float = 0.0) -> ZoneType:
	if not has_habitable_zone:
		# Determine zone based on distance even without formal habitable zone
		if orbital_distance < 80:  # Very close
			return ZoneType.TOO_HOT
		elif orbital_distance < 300:  # Medium distance
			return ZoneType.TOO_COLD
		else:  # Far distance
			return ZoneType.FROZEN
	
	# Calculate actual zone boundaries at this angle
	var opt_inner_at_angle = get_zone_distance_at_angle(optimistic_inner, orbital_angle)
	var cons_inner_at_angle = get_zone_distance_at_angle(conservative_inner, orbital_angle)
	var cons_outer_at_angle = get_zone_distance_at_angle(conservative_outer, orbital_angle)
	var opt_outer_at_angle = get_zone_distance_at_angle(optimistic_outer, orbital_angle)
	var frost_at_angle = get_zone_distance_at_angle(frost_line, orbital_angle)
	
	if orbital_distance < opt_inner_at_angle:
		return ZoneType.TOO_HOT
	elif orbital_distance < cons_inner_at_angle:
		return ZoneType.OPTIMISTIC
	elif orbital_distance <= cons_outer_at_angle:
		return ZoneType.CONSERVATIVE
	elif orbital_distance <= opt_outer_at_angle:
		return ZoneType.OPTIMISTIC
	elif orbital_distance < frost_at_angle * 2:
		return ZoneType.TOO_COLD
	else:
		return ZoneType.FROZEN

# FIXED: Check habitability considering orbital path
func is_potentially_habitable(orbital_distance: float, eccentricity: float, planet_type: int) -> bool:
	if not has_habitable_zone:
		return false
	
	# Check habitability at multiple points in the orbit
	var habitable_fraction = calculate_habitable_orbit_fraction(orbital_distance, eccentricity, planet_type)
	
	# Planet needs to spend at least 20% of its orbit in habitable conditions (reduced threshold)
	return habitable_fraction > 0.2

# FIXED: Calculate what fraction of the orbit is in habitable zones
func calculate_habitable_orbit_fraction(semi_major_axis: float, eccentricity: float, planet_type: int) -> float:
	var habitable_points = 0
	var total_points = 36  # Check every 10 degrees
	
	for i in range(total_points):
		var angle = (i * 2.0 * PI) / total_points
		var distance = semi_major_axis * (1 - eccentricity * eccentricity) / (1 + eccentricity * cos(angle))
		
		var zone = get_zone_type(distance, angle)
		
		# Check if this planet type can be habitable in this zone
		if _can_planet_type_be_habitable(planet_type, zone):
			habitable_points += 1
	
	return float(habitable_points) / float(total_points)

func _can_planet_type_be_habitable(planet_type: int, zone: ZoneType) -> bool:
	match planet_type:
		PlanetEnums.PlanetType.ROCKY_MEDIUM:
			return zone in [ZoneType.CONSERVATIVE, ZoneType.OPTIMISTIC]
		PlanetEnums.PlanetType.SUPER_EARTH:
			return zone in [ZoneType.CONSERVATIVE, ZoneType.OPTIMISTIC]
		PlanetEnums.PlanetType.ROCKY_SMALL:
			# Small planets need conservative zone
			return zone == ZoneType.CONSERVATIVE
		_:
			return false

func calculate_habitability_score(orbital_distance: float, planet_type: int, planet_mass: float = 1.0, eccentricity: float = 0.0) -> float:
	if not has_habitable_zone:
		return 0.0
	
	# Calculate what fraction of orbit is habitable
	var habitable_fraction = calculate_habitable_orbit_fraction(orbital_distance, eccentricity, planet_type)
	
	if habitable_fraction == 0.0:
		return 0.0
	
	# FIXED: Start with a more generous base score
	var score = habitable_fraction * 0.7  # Base score from habitable fraction
	
	# MAJOR FIX: Add significant bonus for being in any habitable zone
	var current_zone = get_zone_type(orbital_distance, 0.0)  # Check at aphelion
	match current_zone:
		ZoneType.CONSERVATIVE:
			score += 0.5  # Big bonus for conservative zone
		ZoneType.OPTIMISTIC:
			score += 0.3  # Good bonus for optimistic zone
	
	# Bonus for staying entirely in conservative zone
	var conservative_fraction = 0.0
	var total_points = 36
	
	for i in range(total_points):
		var angle = (i * 2.0 * PI) / total_points
		var distance = orbital_distance * (1 - eccentricity * eccentricity) / (1 + eccentricity * cos(angle))
		var zone = get_zone_type(distance, angle)
		
		if zone == ZoneType.CONSERVATIVE:
			conservative_fraction += 1.0 / total_points
	
	# Additional bonus for time in conservative zone
	score += conservative_fraction * 0.4
	
	# FIXED: More generous planet type adjustments
	match planet_type:
		PlanetEnums.PlanetType.ROCKY_MEDIUM:
			score *= 1.2  # Bonus for ideal planet type
		PlanetEnums.PlanetType.SUPER_EARTH:
			score *= 1.0  # No penalty, just different
		PlanetEnums.PlanetType.ROCKY_SMALL:
			score *= 0.8  # Small penalty for atmosphere retention
		_:
			score *= 0.2  # Gas giants still get some score
	
	# FIXED: More forgiving mass adjustments
	if planet_mass < 0.3:
		score *= 0.5  # Reduced penalty for small planets
	elif planet_mass > 5.0:
		score *= 0.6  # Reduced penalty for large planets
	else:
		score *= 1.0  # No penalty for reasonable masses
	
	# FIXED: Less harsh stellar type penalties
	var stellar_data = STELLAR_DATA[star_type]
	
	# Flare activity reduces habitability (reduced impact)
	score *= (1.0 - stellar_data.flare_frequency * 0.2)  # Reduced from 0.4
	
	# FIXED: More forgiving stellar lifetime effects
	if stellar_data.lifetime < 0.5:
		score *= 0.6  # Reduced penalty
	elif stellar_data.lifetime < 2.0:
		score *= 0.8  # Reduced penalty
	else:
		score *= 1.0  # No penalty for longer-lived stars
	
	# FIXED: Less harsh eccentricity penalty
	if eccentricity > 0.4:
		score *= (1.0 - (eccentricity - 0.4) * 0.3)  # Reduced penalty
	elif eccentricity > 0.2:
		score *= (1.0 - (eccentricity - 0.2) * 0.1)  # Very small penalty
	
	# BONUS: Extra points for ideal conditions
	if habitable_fraction > 0.8 and planet_type in [PlanetEnums.PlanetType.ROCKY_MEDIUM, PlanetEnums.PlanetType.SUPER_EARTH]:
		score += 0.2
	
	return clamp(score, 0.0, 1.0)

# Get current habitability for a planet at its current position
func get_current_habitability(planet_distance: float, planet_angle: float, _planet_type: int, base_score: float) -> float:
	var zone = get_zone_type(planet_distance, planet_angle)
	
	var zone_multiplier = 1.0
	match zone:
		ZoneType.CONSERVATIVE:
			zone_multiplier = 1.0
		ZoneType.OPTIMISTIC:
			zone_multiplier = 0.7
		ZoneType.TOO_HOT:
			zone_multiplier = 0.1
		ZoneType.TOO_COLD:
			zone_multiplier = 0.2
		ZoneType.FROZEN:
			zone_multiplier = 0.05
	
	return base_score * zone_multiplier

# Get zone information for display
func get_zone_info() -> Dictionary:
	return {
		"has_zone": has_habitable_zone,
		"conservative_inner": conservative_inner,
		"conservative_outer": conservative_outer,
		"optimistic_inner": optimistic_inner,
		"optimistic_outer": optimistic_outer,
		"frost_line": frost_line,
		"luminosity": luminosity,
		"star_type": StarSystem.StarType.keys()[star_type],
		"width": conservative_outer - conservative_inner if has_habitable_zone else 0.0,
		"zone_eccentricity": zone_eccentricity,
		"zone_angle_offset": zone_angle_offset
	}

# FIXED: Draw elliptical habitable zone visualization with proper scaling
func draw_zone_visualization(canvas: CanvasItem, alpha: float = 0.3):
	if not has_habitable_zone:
		return
	
	var conservative_color = Color(0.0, 1.0, 0.0, alpha)  # Green
	var optimistic_color = Color(0.0, 0.5, 1.0, alpha)   # Blue
	
	# Draw elliptical zones - no additional scaling needed, already in pixels
	_draw_elliptical_zone_ring(canvas, optimistic_inner, optimistic_outer, optimistic_color)
	_draw_elliptical_zone_ring(canvas, conservative_inner, conservative_outer, conservative_color)

func _draw_elliptical_zone_ring(canvas: CanvasItem, inner_radius: float, outer_radius: float, color: Color):
	var points = 128
	
	var inner_points = PackedVector2Array()
	var outer_points = PackedVector2Array()
	
	for i in range(points + 1):
		var angle = i * 2.0 * PI / points
		
		# Calculate elliptical distances - no additional scaling
		var inner_dist = get_zone_distance_at_angle(inner_radius, angle)
		var outer_dist = get_zone_distance_at_angle(outer_radius, angle)
		
		inner_points.append(Vector2(cos(angle) * inner_dist, sin(angle) * inner_dist))
		outer_points.append(Vector2(cos(angle) * outer_dist, sin(angle) * outer_dist))
	
	# Draw the elliptical ring as triangles
	for i in range(points):
		var next_i = (i + 1) % points
		
		# Create triangles to form the ring
		var triangle1 = PackedVector2Array([
			inner_points[i], outer_points[i], outer_points[next_i]
		])
		canvas.draw_colored_polygon(triangle1, color)
		
		var triangle2 = PackedVector2Array([
			inner_points[i], outer_points[next_i], inner_points[next_i]
		])
		canvas.draw_colored_polygon(triangle2, color)
