class_name PlanetEnums
extends Object

## Centralized enums for planetary systems to avoid circular dependencies.

enum PlanetType {
	ROCKY_SMALL,     # Mercury-like
	ROCKY_MEDIUM,    # Earth-like
	SUPER_EARTH,     # Larger rocky planet
	ICE_GIANT,       # Neptune-like
	GAS_GIANT,       # Jupiter-like
	SUPER_JUPITER    # Larger gas giant
}

enum AtmosphereType {
	NONE,              # No atmosphere (like Mercury)
	THIN,              # Thin atmosphere (like Mars)
	MODERATE,          # Earth-like atmosphere
	THICK,             # Thick atmosphere (like Venus)
	DENSE,             # Very dense (Super-Earth)
	GAS_GIANT          # Gas giant atmosphere
}

enum MagnetosphereStrength {
	NONE,              # No magnetic field
	WEAK,              # Weak field, some protection
	MODERATE,          # Earth-like protection
	STRONG,            # Strong protection
	EXTREME            # Extreme field (like Jupiter)
}

enum GeologicalActivity {
	DEAD,              # No geological activity
	LOW,               # Some activity, few volcanoes
	MODERATE,          # Earth-like activity
	HIGH,              # Very active, many volcanoes
	EXTREME            # Io-like extreme volcanism
}

enum ClimateType {
	FROZEN,            # Permanently frozen
	COLD,              # Cold but with some liquid areas
	TEMPERATE,         # Earth-like varied climate
	HOT,               # Hot but habitable
	SCORCHING,         # Too hot for most life
	VARIABLE           # Extreme variations (tidally locked, etc.)
}
