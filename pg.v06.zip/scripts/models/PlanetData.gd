class_name PlanetData
extends Resource

## Data container for all planetary properties and generation logic.
## This decouples the simulation/data from the visual representation.

# Basic Orbital Properties
@export var planet_name: String
@export var planet_type: int # PlanetEnums.PlanetType
@export var semi_major_axis: float
@export var eccentricity: float
@export var orbit_angle: float
@export var orbit_speed: float

# Physical Properties
@export var size: float                 # Visual scale factor
@export var mass: float                 # Normalized to Earth (1.0)
@export var radius: float               # Normalized to Earth (1.0)
@export var surface_gravity: float      # Normalized to Earth (1.0)
@export var axial_tilt: float           # Degrees (0-180)

# Rotational Properties
@export var rotation_period: float = 1.0      # Game days per full rotation
@export var rotation_angle: float = 0.0       # Current rotation in degrees
@export var is_tidally_locked: bool = false

# Atmospheric Properties
@export var atmosphere_type: int # PlanetEnums.AtmosphereType
@export var atmosphere_pressure: float = 0.0
@export var atmosphere_composition: Dictionary = {}

# Magnetic Properties
@export var magnetosphere_strength: int # PlanetEnums.MagnetosphereStrength
@export var magnetic_field_strength: float = 0.0

# Geological Properties
@export var geological_activity: int # PlanetEnums.GeologicalActivity
@export var tectonic_plates: int = 0
@export var volcanic_activity: float = 0.0

# Climate Properties
@export var climate_type: int # PlanetEnums.ClimateType
@export var surface_temperature: float = 0.0  # Kelvin
@export var temperature_variation: float = 0.0

# Surface Properties
@export var surface_liquids: Dictionary = {}
@export var surface_composition: Dictionary = {}

# Habitability
@export var habitability_score: float = 0.0
@export var habitable_zone_type: int = -1

# Metadata
@export var enhanced_properties_generated: bool = false
@export var color_index: int = 0
@export var base_color: Color = Color.WHITE

func generate_enhanced(rng: RandomNumberGenerator):
	if enhanced_properties_generated:
		return
	
	enhanced_properties_generated = true
	
	# Initial Physical calculations
	_calculate_physical_stats(rng)
	_calculate_rotation_period(rng)
	
	# Sequential generation
	_generate_atmosphere(rng)
	_generate_magnetosphere(rng)
	_generate_geology(rng)
	_generate_climate(rng)
	_generate_surface_conditions(rng)

func _calculate_rotation_period(rng: RandomNumberGenerator):
	if is_tidally_locked:
		rotation_period = 0.0 
		return

	var base_period: float
	var variation_range: float

	match planet_type:
		0: # ROCKY_SMALL
			base_period = 0.75
			variation_range = 0.5
		1: # ROCKY_MEDIUM
			base_period = 1.25
			variation_range = 0.75
		2: # SUPER_EARTH
			base_period = 1.15
			variation_range = 0.35
		3: # ICE_GIANT
			base_period = 0.8
			variation_range = 0.2
		4: # GAS_GIANT
			base_period = 0.45
			variation_range = 0.15
		5: # SUPER_JUPITER
			base_period = 0.4
			variation_range = 0.2
		_:
			base_period = 1.0
			variation_range = 0.5

	rotation_period = base_period + rng.randf() * variation_range

func _calculate_physical_stats(rng: RandomNumberGenerator):
	radius = size / 0.05
	var density_factor = rng.randf_range(0.8, 1.2)
	match planet_type:
		0: density_factor *= 0.9 # ROCKY_SMALL
		1: density_factor *= 1.0 # ROCKY_MEDIUM
		2: density_factor *= 1.1 # SUPER_EARTH
		3: density_factor *= 0.3 # ICE_GIANT
		4: density_factor *= 0.25 # GAS_GIANT
		5: density_factor *= 0.2 # SUPER_JUPITER
		
	mass = (radius * radius * radius) * density_factor
	surface_gravity = mass / (radius * radius)
	
	if rng.randf() < 0.1: 
		axial_tilt = rng.randf_range(70.0, 110.0)
	else:
		axial_tilt = rng.randf_range(0.0, 30.0)
		
	if semi_major_axis < 40.0:
		var lock_chance = (40.0 - semi_major_axis) / 40.0
		if rng.randf() < lock_chance:
			is_tidally_locked = true
			rotation_period = 0.0

func _generate_atmosphere(rng: RandomNumberGenerator):
	match planet_type:
		0: # ROCKY_SMALL
			if rng.randf() < 0.8:
				atmosphere_type = 0 # NONE
				atmosphere_pressure = 0.0
			else:
				atmosphere_type = 1 # THIN
				atmosphere_pressure = rng.randf_range(0.001, 0.1)
		
		1: # ROCKY_MEDIUM
			var r = rng.randf()
			if r < 0.3:
				atmosphere_type = 1 # THIN
				atmosphere_pressure = rng.randf_range(0.01, 0.5)
			elif r < 0.8:
				atmosphere_type = 2 # MODERATE
				atmosphere_pressure = rng.randf_range(0.3, 3.0)
			else:
				atmosphere_type = 3 # THICK
				atmosphere_pressure = rng.randf_range(2.0, 10.0)
		
		2: # SUPER_EARTH
			atmosphere_type = 4 # DENSE
			atmosphere_pressure = rng.randf_range(3.0, 20.0)
		
		3, 4, 5: # GIANTS
			atmosphere_type = 5 # GAS_GIANT
			atmosphere_pressure = rng.randf_range(100.0, 10000.0)

func _generate_magnetosphere(rng: RandomNumberGenerator):
	match planet_type:
		0: # ROCKY_SMALL
			magnetosphere_strength = 0 if rng.randf() < 0.9 else 1
			magnetic_field_strength = rng.randf_range(0.0, 0.1)
		
		1: # ROCKY_MEDIUM
			var r = rng.randf()
			if r < 0.3:
				magnetosphere_strength = 1 # WEAK
				magnetic_field_strength = rng.randf_range(0.1, 0.5)
			elif r < 0.8:
				magnetosphere_strength = 2 # MODERATE
				magnetic_field_strength = rng.randf_range(0.5, 1.5)
			else:
				magnetosphere_strength = 3 # STRONG
				magnetic_field_strength = rng.randf_range(1.5, 3.0)
		
		2: # SUPER_EARTH
			magnetosphere_strength = 3 # STRONG
			magnetic_field_strength = rng.randf_range(2.0, 5.0)
		
		3, 4, 5: # GIANTS
			magnetosphere_strength = 4 # EXTREME
			magnetic_field_strength = rng.randf_range(10.0, 50.0)

func _generate_geology(rng: RandomNumberGenerator):
	var distance_factor = 1.0 / (semi_major_axis * semi_major_axis)
	var eccentricity_factor = eccentricity * eccentricity
	var tidal_heating = distance_factor * eccentricity_factor * 1000.0
	var radioactive_heating = (size * size * size) * rng.randf_range(500.0, 1500.0)
	
	var total_heating = (tidal_heating + radioactive_heating) / 1000.0
	
	if total_heating < 0.1:
		geological_activity = 0 # DEAD
		tectonic_plates = 0
		volcanic_activity = 0.0
	elif total_heating < 0.5:
		geological_activity = 1 # LOW
		tectonic_plates = rng.randi_range(0, 3)
		volcanic_activity = rng.randf_range(0.0, 0.3)
	elif total_heating < 1.0:
		geological_activity = 2 # MODERATE
		tectonic_plates = rng.randi_range(3, 12)
		volcanic_activity = rng.randf_range(0.2, 0.7)
	elif total_heating < 2.0:
		geological_activity = 3 # HIGH
		tectonic_plates = rng.randi_range(8, 20)
		volcanic_activity = rng.randf_range(0.6, 0.9)
	else:
		geological_activity = 4 # EXTREME
		tectonic_plates = rng.randi_range(15, 50)
		volcanic_activity = rng.randf_range(0.8, 1.0)

func _generate_climate(_rng: RandomNumberGenerator):
	var stellar_flux = 1361.0 / ((semi_major_axis/100.0) * (semi_major_axis/100.0))
	var base_temp = pow(stellar_flux / (4 * 5.67e-8), 0.25)
	
	var greenhouse = 0.0
	match atmosphere_type:
		1: greenhouse = 5.0 # THIN
		2: greenhouse = 25.0 # MODERATE
		3: greenhouse = 250.0 # THICK
		4: greenhouse = 150.0 # DENSE
		
	surface_temperature = base_temp + greenhouse
	
	var var_factor = 1.0
	match atmosphere_type:
		0: var_factor = 10.0 # NONE
		1: var_factor = 3.0 # THIN
		3: var_factor = 0.3 # THICK
		4: var_factor = 0.1 # DENSE
	temperature_variation = 10.0 * var_factor * (1.0 + eccentricity)

	if surface_temperature < 200: climate_type = 0 # FROZEN
	elif surface_temperature < 250: climate_type = 1 # COLD
	elif surface_temperature < 320: climate_type = 2 # TEMPERATE
	elif surface_temperature < 400: climate_type = 3 # HOT
	else: climate_type = 4 # SCORCHING

func _generate_surface_conditions(rng: RandomNumberGenerator):
	surface_liquids = {}
	if surface_temperature > 273 and surface_temperature < 373 and atmosphere_pressure > 0.01:
		surface_liquids["water"] = rng.randf_range(0.0, 0.7)
	if surface_temperature < 273:
		surface_liquids["ice"] = rng.randf_range(0.1, 1.0)
	if surface_temperature > 600:
		surface_liquids["lava"] = volcanic_activity * rng.randf_range(0.0, 0.1)
	
	surface_composition = {}
	match planet_type:
		0, 1:
			surface_composition["rock"] = rng.randf_range(0.6, 0.9)
			surface_composition["ice"] = rng.randf_range(0.0, 0.3)
			surface_composition["metal"] = rng.randf_range(0.0, 0.1)
		2:
			surface_composition["rock"] = rng.randf_range(0.7, 0.95)
			surface_composition["metal"] = rng.randf_range(0.05, 0.15)
		_:
			surface_composition["gas"] = 1.0
