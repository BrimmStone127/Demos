class_name CharacterStats
extends Resource

## Flexible player statistics system.
## Stats are stored as a dictionary - add any stats your game needs.
##
## Example usage:
##   var stats = CharacterStats.new()
##   stats.set_stat("charisma", 5)
##   stats.set_stat("technical", 3)
##   print(stats.get_stat("charisma"))  # 5

signal stat_changed(stat_name: String, old_value: int, new_value: int)

# Core stats storage - keys are stat names, values are integers
var _stats: Dictionary = {}

# Optional: stat metadata (display names, descriptions, min/max values)
var _stat_definitions: Dictionary = {}


func get_stat(stat_name: String, default: int = 0) -> int:
	return _stats.get(stat_name, default)


func set_stat(stat_name: String, value: int):
	var old_value = _stats.get(stat_name, 0)
	_stats[stat_name] = value
	if old_value != value:
		emit_signal("stat_changed", stat_name, old_value, value)


func modify_stat(stat_name: String, delta: int):
	var current = get_stat(stat_name)
	set_stat(stat_name, current + delta)


func has_stat(stat_name: String) -> bool:
	return _stats.has(stat_name)


func get_all_stats() -> Dictionary:
	return _stats.duplicate()


func get_stat_names() -> Array[String]:
	var names: Array[String] = []
	names.assign(_stats.keys())
	return names


# Define a stat with metadata (optional, for UI/validation)
func define_stat(stat_name: String, display_name: String = "", description: String = "", min_value: int = 0, max_value: int = 100):
	_stat_definitions[stat_name] = {
		"display_name": display_name if display_name else stat_name.capitalize(),
		"description": description,
		"min": min_value,
		"max": max_value
	}
	# Initialize stat if not already set
	if not _stats.has(stat_name):
		_stats[stat_name] = min_value


func get_stat_definition(stat_name: String) -> Dictionary:
	return _stat_definitions.get(stat_name, {})


# Check if player meets a stat requirement
func meets_requirement(stat_name: String, min_value: int) -> bool:
	return get_stat(stat_name) >= min_value


# Serialization for save/load
func to_dict() -> Dictionary:
	return {
		"stats": _stats.duplicate(),
		"definitions": _stat_definitions.duplicate()
	}


func from_dict(data: Dictionary):
	_stats = data.get("stats", {}).duplicate()
	_stat_definitions = data.get("definitions", {}).duplicate()


# Create with initial stats
static func create(initial_stats: Dictionary = {}) -> CharacterStats:
	var ps = CharacterStats.new()
	for stat_name in initial_stats:
		ps.set_stat(stat_name, initial_stats[stat_name])
	return ps
