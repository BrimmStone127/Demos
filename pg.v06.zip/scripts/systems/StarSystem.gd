class_name StarSystem
extends Node2D

const LOG_TAG := "STAR_SYSTEM"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


enum StarType {
	M,  # Red dwarf (most common)
	K,  # Orange dwarf
	G,  # Yellow (Sun-like)
	F,  # Yellow-white
	A,  # White
	B,  # Blue-white
	O   # Blue (rare)
}

const STAR_PROPERTIES = {
	StarType.M: {"color": Color(1.0, 0.5, 0.5), "scale_range": Vector2(0.08, 0.12), "planet_chance": 0.95, "max_planets": 6},  # Reduced from 0.15-0.20
	StarType.K: {"color": Color(1.0, 0.7, 0.3), "scale_range": Vector2(0.10, 0.15), "planet_chance": 0.9, "max_planets": 7},   # Reduced from 0.18-0.24  
	StarType.G: {"color": Color(1.0, 1.0, 0.3), "scale_range": Vector2(0.12, 0.18), "planet_chance": 0.9, "max_planets": 8},   # Reduced from 0.20-0.28
	StarType.F: {"color": Color(1.0, 1.0, 0.8), "scale_range": Vector2(0.15, 0.22), "planet_chance": 0.85, "max_planets": 7},  # Reduced from 0.24-0.32
	StarType.A: {"color": Color(1.0, 1.0, 1.0), "scale_range": Vector2(0.18, 0.26), "planet_chance": 0.7, "max_planets": 5},   # Reduced from 0.30-0.38
	StarType.B: {"color": Color(0.8, 0.8, 1.0), "scale_range": Vector2(0.22, 0.30), "planet_chance": 0.6, "max_planets": 4},   # Reduced from 0.36-0.44
	StarType.O: {"color": Color(0.6, 0.6, 1.0), "scale_range": Vector2(0.26, 0.35), "planet_chance": 0.4, "max_planets": 3}    # Reduced from 0.44-0.52
}

const PIXELS_PER_AU: float = 100.0

var star_type: StarType
var current_seed: int
var star_name: String
var show_orbits: bool = false
var force_habitable: bool = false  # When true, guarantees a habitable planet

# ADDED: Habitable zone properties
var habitable_zone: HabitableZone
var show_habitable_zone: bool = true

@export var sun_texture: Texture2D
@export var planet_texture: Texture2D

const PLANET_PROPERTIES = {
	# Original: "scale_range": Vector2(0.2, 0.3)
	PlanetEnums.PlanetType.ROCKY_SMALL: {
		"scale_range": Vector2(0.025, 0.037),  # Divided by 8.125
		"colors": [
			Color(0.8, 0.7, 0.6),  # Mercury-like
			Color(0.7, 0.6, 0.5),  # Rocky grey
			Color(0.9, 0.8, 0.7)   # Light rocky
		]
	},
	# Original: "scale_range": Vector2(0.35, 0.45)
	PlanetEnums.PlanetType.ROCKY_MEDIUM: {
		"scale_range": Vector2(0.043, 0.055),  # Divided by 8.125
		"colors": [
			Color(0.2, 0.5, 0.8),  # Earth-like blue
			Color(0.6, 0.3, 0.2),  # Mars-like red
			Color(0.7, 0.7, 0.6)   # Rocky with atmosphere
		]
	},
	# Original: "scale_range": Vector2(0.5, 0.6)
	PlanetEnums.PlanetType.SUPER_EARTH: {
		"scale_range": Vector2(0.062, 0.074),  # Divided by 8.125
		"colors": [
			Color(0.3, 0.6, 0.7),  # Blue-green
			Color(0.5, 0.5, 0.7),  # Purple-tinted
			Color(0.7, 0.5, 0.3)   # Orange-tinted
		]
	},
	# Original: "scale_range": Vector2(0.65, 0.75)
	PlanetEnums.PlanetType.ICE_GIANT: {
		"scale_range": Vector2(0.08, 0.092),  # Divided by 8.125
		"colors": [
			Color(0.4, 0.7, 0.8),  # Uranus-like
			Color(0.3, 0.4, 0.7),  # Neptune-like
			Color(0.5, 0.6, 0.8)   # Pale blue
		]
	},
	# Original: "scale_range": Vector2(0.8, 0.9)
	PlanetEnums.PlanetType.GAS_GIANT: {
		"scale_range": Vector2(0.098, 0.111),  # Divided by 8.125
		"colors": [
			Color(0.8, 0.7, 0.5),  # Jupiter-like
			Color(0.7, 0.6, 0.4),  # Saturn-like
			Color(0.9, 0.8, 0.6)   # Pale yellow
		]
	},
	# Original: "scale_range": Vector2(0.95, 1.1)
	PlanetEnums.PlanetType.SUPER_JUPITER: {
		"scale_range": Vector2(0.117, 0.135),  # Divided by 8.125
		"colors": [
			Color(0.7, 0.5, 0.3),  # Brown
			Color(0.8, 0.6, 0.4),  # Orange-brown
			Color(0.6, 0.4, 0.3)   # Dark brown
		]
	}
}

func _init():
	add_to_group("star_system")

func _draw():
	if show_orbits:
		for child in get_children():
			if child is Planet:
				var semi_major = child.semi_major_axis
				var eccent = child.eccentricity
				var color = PLANET_PROPERTIES[child.planet_type].colors[child.color_index]
			
				draw_orbit(semi_major, eccent, Color(color.r, color.g, color.b, 0.4))
	
	# Draw elliptical habitable zone with better visibility
	if show_habitable_zone and habitable_zone and habitable_zone.has_habitable_zone:
		habitable_zone.draw_zone_visualization(self, 0.25)  # Slightly more visible

func debug_planet_habitability():
	if not habitable_zone:
		_log_info('No habitable zone in this system')
		return
	
	_log_debug('\n=== REAL-TIME HABITABILITY DEBUG ===')
	_log_info('Habitable zone info:')
	_log_info('  Conservative: %s - %s pixels', [snapped(habitable_zone.conservative_inner, 0), snapped(habitable_zone.conservative_outer, 0)])
	_log_info('  Optimistic: %s - %s pixels', [snapped(habitable_zone.optimistic_inner, 0), snapped(habitable_zone.optimistic_outer, 0)])
	_log_info('  Zone eccentricity: %s', [snapped(habitable_zone.zone_eccentricity, 0.01)])
	_log_info('  Zone width: %s pixels', [snapped(habitable_zone.conservative_outer - habitable_zone.conservative_inner, 0)])
	_log_debug('')
	
	var planets_in_zones = 0
	var habitable_planets = 0
	
	for child in get_children():
		if child is Planet and child.enhanced_properties_generated:
			# Current distance calculation
			var current_distance = child.semi_major_axis * (1 - child.eccentricity * child.eccentricity) / (1 + child.eccentricity * cos(child.orbit_angle))
			
			var zone = habitable_zone.get_zone_type(current_distance, child.orbit_angle)
			var current_hab = child.get_current_habitability(habitable_zone)
			var avg_hab = child.habitability_score
			var habitable_fraction = child.get_habitable_orbit_fraction(habitable_zone)
			
			# Count planets that spend time in habitable zones
			if habitable_fraction > 0:
				planets_in_zones += 1
			if avg_hab > 0.2:
				habitable_planets += 1
			
			_log_info('%s (%s):', [child.planet_name, child.get_planet_type_name()])
			_log_info('  Semi-major axis: %s pixels', [snapped(child.semi_major_axis, 0)])
			_log_info('  Current distance: %s pixels', [snapped(current_distance, 0)])
			_log_info('  Eccentricity: %s', [snapped(child.eccentricity, 0.01)])
			_log_info('  Current zone: %s', [HabitableZone.ZoneType.keys()[zone]])
			_log_info('  Habitable orbit fraction: %s', [snapped(habitable_fraction, 0.01)])
			_log_info('  Current habitability: %s', [snapped(current_hab, 0.01)])
			_log_info('  Average habitability: %s', [snapped(avg_hab, 0.01)])
			_log_info('  Orbit angle: %s radians', [snapped(child.orbit_angle, 0.01)])
			
			# Show distance to zone boundaries
			_log_info('  Distance to conservative inner: %s pixels', [snapped(abs(current_distance - habitable_zone.conservative_inner), 0)])
			_log_info('  Distance to conservative outer: %s pixels', [snapped(abs(current_distance - habitable_zone.conservative_outer), 0)])
			_log_debug('')
	
	_log_info('SUMMARY:')
	_log_info('  Planets intersecting habitable zones: %s', [planets_in_zones])
	_log_info('  Potentially habitable planets: %s', [habitable_planets])
	_log_debug('====================================\n')

func draw_orbit(semi_major: float, eccentricity: float, color: Color):
	var num_points = 100
	var prev_point = Vector2.ZERO
	
	var line_width = 1.5
	var orbit_color = Color(color.r, color.g, color.b, 0.8)  # Increased opacity to 0.8
	
	for i in range(num_points + 1):
		var angle = 2 * PI * i / num_points
		var dist = semi_major * (1 - eccentricity * eccentricity) / (1 + eccentricity * cos(angle))
		var point = Vector2(cos(angle), sin(angle)) * dist
		
		if i > 0:
			draw_line(prev_point, point, orbit_color, line_width, true)
		
		prev_point = point

func set_orbit_visibility(p_visible: bool):
	show_orbits = p_visible
	queue_redraw()  # Force redraw to update orbits

# ADDED: Add method to toggle habitable zone visibility
func set_habitable_zone_visibility(p_visible: bool):
	show_habitable_zone = p_visible
	queue_redraw()
	
func generate_enhanced(seed_value: int = randi()) -> void:
	_log_info('Generating enhanced star system with seed: %s', [seed_value])
	current_seed = seed_value
	seed(current_seed)
	
	# Clear existing children
	for child in get_children():
		child.queue_free()
	
	# Generate basic system first
	star_type = generate_random_star_type()
	# Opossum sector override: force G-type for reliable habitable zone
	if force_habitable and star_type in [StarType.M, StarType.A, StarType.B, StarType.O]:
		star_type = StarType.G
	var star_props = STAR_PROPERTIES[star_type]
	
	star_name = generate_star_name()
	
	# Create star
	var star = Sprite2D.new()
	star.texture = sun_texture
	var star_scale = randf_range(star_props.scale_range.x, star_props.scale_range.y)
	star.scale = Vector2.ONE * star_scale
	star.modulate = star_props.color
	add_child(star)

	# Generate habitable zone (now in pixels)
	_generate_habitable_zone(star_scale)

	var num_planets = randi_range(1, star_props.max_planets)
	_log_info('Creating %s planets', [num_planets])
	
	# Calculate minimum distance based on smaller star size
	var sun_radius = (sun_texture.get_width() / 2.0) * star_scale
	var min_distance = sun_radius * 2.8  # Restored original spacing baseline
	var last_planet_extent = 0.0
	var created_planets = []
	
	# Adjust base distance increment for smaller stars
	var base_distance_increment = 35.0 + (100.0 / max(1, num_planets))
	var spacing_multiplier := 1.25
	
	# Create planets (everything in pixels, no conversions!)
	for i in range(num_planets):
		var normalized_distance = float(i) / float(num_planets)
		var planet_type = _determine_planet_type_by_position(normalized_distance)
		var props = PLANET_PROPERTIES[planet_type]
		
		var planet_scale = randf_range(props.scale_range.x, props.scale_range.y)
		var planet_radius = (planet_texture.get_width() / 2.0) * planet_scale
		
		var distance = min_distance
		if last_planet_extent > 0.0:
			var size_factor = 0.7 + (0.3 * planet_scale)
			# Slightly reduced spacing since stars are smaller
			distance += (last_planet_extent + planet_radius) * spacing_multiplier + (base_distance_increment * size_factor)
		
		var eccentricity = generate_realistic_eccentricity(normalized_distance, planet_type, star_type)
		var has_atmosphere = planet_type in [
			PlanetEnums.PlanetType.ROCKY_MEDIUM, 
			PlanetEnums.PlanetType.SUPER_EARTH,
			PlanetEnums.PlanetType.ICE_GIANT,
			PlanetEnums.PlanetType.GAS_GIANT
		]
		
		var current_planet = Planet.new(planet_texture, distance, eccentricity, planet_type, props, has_atmosphere)
		add_child(current_planet)
		created_planets.append(current_planet)
		
		min_distance = distance
		
		var letter = char(98 + i)
		current_planet.planet_name = star_name + " " + letter
		
		# Generate enhanced properties and calculate habitability (all in pixels now)
		current_planet.generate_enhanced_properties()
		if habitable_zone:
			current_planet.calculate_habitability_score(habitable_zone)
		var current_extent = max(planet_radius, current_planet.get_visual_extent())
		last_planet_extent = current_extent
	
	# UPDATED: Increase buffer for overlap fixing
	fix_orbit_overlaps_optimized(created_planets, 8)  # Increased from 5 to 8
	
	# Print habitability summary
	_print_habitability_summary()
	
	queue_redraw()
	
func _generate_habitable_zone(star_scale: float):
	# Estimate luminosity from star scale and type
	var base_luminosity = _get_base_luminosity_for_star_type()
	var scale_factor = star_scale / 0.15  # Normalize to typical G-star scale
	var luminosity = base_luminosity * (scale_factor * scale_factor)  # Luminosity scales with radius squared
	
	# FIXED: Create habitable zone - NO manual conversion needed!
	# The HabitableZone class now handles the conversion internally
	habitable_zone = HabitableZone.new(star_type, luminosity)
	
	_log_info('Generated habitable zone for %s star (L=%s)', [StarType.keys()[star_type], snapped(luminosity, 0.01)])
	_log_info('  Zone eccentricity: %s', [snapped(habitable_zone.zone_eccentricity, 0.01)])
	_log_info('  Zone angle offset: %s radians', [snapped(habitable_zone.zone_angle_offset, 0.01)])
	
	if habitable_zone.has_habitable_zone:
		_log_info('  Conservative zone: %s - %s pixels', [snapped(habitable_zone.conservative_inner, 0), snapped(habitable_zone.conservative_outer, 0)])
		_log_info('  Optimistic zone: %s - %s pixels', [snapped(habitable_zone.optimistic_inner, 0), snapped(habitable_zone.optimistic_outer, 0)])
		_log_info('  Zone width: %s pixels', [snapped(habitable_zone.conservative_outer - habitable_zone.conservative_inner, 0)])
	else:
		_log_info('  Habitable zone exists but quality is very poor')


func _get_base_luminosity_for_star_type() -> float:
	# Rough luminosity estimates for star types
	match star_type:
		StarType.M:
			return randf_range(0.0001, 0.08)
		StarType.K:
			return randf_range(0.08, 0.4)
		StarType.G:
			return randf_range(0.4, 1.5)
		StarType.F:
			return randf_range(1.5, 5.0)
		StarType.A:
			return randf_range(5.0, 25.0)
		StarType.B:
			return randf_range(25.0, 30000.0)
		StarType.O:
			return randf_range(30000.0, 100000.0)
		_:
			return 1.0

func _determine_planet_type_by_position(normalized_distance: float) -> PlanetEnums.PlanetType:
	# Scenario override: force habitable planet in middle zone
	if force_habitable and normalized_distance >= 0.3 and normalized_distance < 0.7:
		return PlanetEnums.PlanetType.SUPER_EARTH
	if normalized_distance < 0.3:
		var inner_rand = randf()
		if inner_rand < 0.7: return PlanetEnums.PlanetType.ROCKY_SMALL
		elif inner_rand < 0.9: return PlanetEnums.PlanetType.ROCKY_MEDIUM 
		else: return PlanetEnums.PlanetType.SUPER_EARTH
	elif normalized_distance < 0.7:
		var middle_rand = randf()
		if middle_rand < 0.3: return PlanetEnums.PlanetType.ROCKY_MEDIUM
		elif middle_rand < 0.7: return PlanetEnums.PlanetType.SUPER_EARTH
		else: return PlanetEnums.PlanetType.ICE_GIANT
	else:
		var outer_rand = randf()
		if outer_rand < 0.3: return PlanetEnums.PlanetType.ICE_GIANT
		elif outer_rand < 0.8: return PlanetEnums.PlanetType.GAS_GIANT
		else: return PlanetEnums.PlanetType.SUPER_JUPITER

func _print_habitability_summary():
	if not habitable_zone:
		return
	
	var all_planets = []
	var habitable_planets = []
	var potentially_habitable = []
	var zone_crossers = []
	
	for child in get_children():
		if child is Planet and child.enhanced_properties_generated:
			all_planets.append(child)
			
			if child.habitability_score > 0.6:
				habitable_planets.append(child)
			elif child.habitability_score > 0.2:
				potentially_habitable.append(child)
			
			# Check if planet crosses zones
			if child.crosses_habitable_zones(habitable_zone):
				zone_crossers.append(child)
	
	_log_debug('\n=== SYSTEM HABITABILITY ANALYSIS ===')
	_log_info('Star: %s (%s)', [star_name, StarType.keys()[star_type]])
	_log_info('Total planets: %s', [all_planets.size()])
	_log_info('Zone quality: %s', ["Good" if habitable_zone.has_habitable_zone else "Poor"])
	
	if habitable_zone.has_habitable_zone:
		_log_info('Zone eccentricity: %s', [snapped(habitable_zone.zone_eccentricity, 0.01)])
		_log_info('Highly habitable planets: %s', [habitable_planets.size()])
		_log_info('Potentially habitable planets: %s', [potentially_habitable.size()])
		_log_info('Planets crossing zones: %s', [zone_crossers.size()])
		
		# Detail the best candidates
		if habitable_planets.size() > 0:
			var best = habitable_planets[0]
			for planet in habitable_planets:
				if planet.habitability_score > best.habitability_score:
					best = planet
			
			_log_info('BEST CANDIDATE: %s', [best.planet_name])
			_log_info('  Habitability score: %s', [snapped(best.habitability_score, 0.01)])
			_log_info('  Orbit fraction habitable: %s', [snapped(best.get_habitable_orbit_fraction(habitable_zone), 0.01)])
			_log_info('  Crosses zones: %s', ["Yes" if best.crosses_habitable_zones(habitable_zone) else "No"])
			_log_info('  Atmosphere: %s', [PlanetEnums.AtmosphereType.keys()[best.atmosphere_type]])
			_log_info('  Surface liquids: %s', [best.surface_liquids])
		
		# List zone crossers
		if zone_crossers.size() > 0:
			_log_info('ZONE-CROSSING PLANETS:')
			for planet in zone_crossers:
				_log_info("  %s (score: %s, eccentricity: %s)", [planet.planet_name, snapped(planet.habitability_score, 0.01), snapped(planet.eccentricity, 0.01)])
	
	_log_debug('=====================================\n')

func get_habitability_summary() -> Dictionary:
	if not habitable_zone:
		return {"has_zone": false}
	
	var summary = habitable_zone.get_zone_info()
	summary["planets_in_zone"] = 0
	summary["habitable_planets"] = []
	summary["zone_crossers"] = []
	summary["best_score"] = 0.0
	summary["best_planet"] = ""
	summary["potentially_habitable_count"] = 0
	
	for child in get_children():
		if child is Planet and child.enhanced_properties_generated:
			# Check if planet spends time in habitable zones
			var habitable_fraction = child.get_habitable_orbit_fraction(habitable_zone)
			
			if habitable_fraction > 0:
				summary["planets_in_zone"] += 1
				
				if child.habitability_score > 0.2:
					summary["potentially_habitable_count"] += 1
					
					summary["habitable_planets"].append({
						"name": child.planet_name,
						"score": child.habitability_score,
						"habitable_fraction": habitable_fraction,
						"crosses_zones": child.crosses_habitable_zones(habitable_zone),
						"current_habitability": child.get_current_habitability(habitable_zone)
					})
					
					if child.habitability_score > summary["best_score"]:
						summary["best_score"] = child.habitability_score
						summary["best_planet"] = child.planet_name
				
				# Track zone crossers separately
				if child.crosses_habitable_zones(habitable_zone):
					summary["zone_crossers"].append({
						"name": child.planet_name,
						"score": child.habitability_score,
						"eccentricity": child.eccentricity
					})
	
	return summary

func fix_orbit_overlaps_optimized(planet_list: Array, buffer: float = 15.0) -> void:  # Increased from 12.0 to 15.0
	# Sort once by distance from star
	planet_list.sort_custom(func(a, b): return a.semi_major_axis < b.semi_major_axis)
	
	# Process each pair of adjacent planets
	for i in range(1, planet_list.size()):
		var inner_planet = planet_list[i-1]
		var outer_planet = planet_list[i]
		
		var inner_max_dist = inner_planet.semi_major_axis * (1 + inner_planet.eccentricity)
		var outer_min_dist = outer_planet.semi_major_axis * (1 - outer_planet.eccentricity)
		
		var inner_extent = inner_planet.get_visual_extent()
		var outer_extent = outer_planet.get_visual_extent()
		
		# UPDATED: Increase safety margin
		var inner_outer_edge = inner_max_dist + inner_extent + 8  # Increased from +5 to +8
		var outer_inner_edge = outer_min_dist - outer_extent
		if inner_outer_edge > outer_inner_edge:
			var min_safe_distance = inner_max_dist + inner_extent + outer_extent + buffer
			var denominator = outer_min_dist - outer_extent
			if denominator <= 0:
				denominator = outer_min_dist if outer_min_dist > 0 else 1.0
			var adjustment_factor = min_safe_distance / denominator
			outer_planet.semi_major_axis *= adjustment_factor
			
			# Update position after adjusting orbit
			outer_planet.update_position()

func generate_realistic_eccentricity(normalized_distance: float, planet_type: int, p_star_type: int) -> float:
	var eccentricity: float
	
	if normalized_distance < 0.3:
		if planet_type == PlanetEnums.PlanetType.ROCKY_SMALL and randf() < 0.4:
			eccentricity = randf_range(0.15, 0.3)
		else:
			eccentricity = randf_range(0.05, 0.2)
	elif normalized_distance < 0.7:
		eccentricity = randf_range(0.1, 0.25)
	else:
		eccentricity = randf_range(0.2, 0.4)
	
	match planet_type:
		PlanetEnums.PlanetType.GAS_GIANT, PlanetEnums.PlanetType.SUPER_JUPITER:
			if normalized_distance < 0.2:
				eccentricity = min(eccentricity, 0.08) 
			elif randf() < 0.6: 
				eccentricity = randf_range(0.25, 0.45)
		
		PlanetEnums.PlanetType.ICE_GIANT:
			if normalized_distance > 0.7 and randf() < 0.7:
				eccentricity = randf_range(0.2, 0.4)
			elif randf() < 0.2:
				eccentricity = randf_range(0.01, 0.05)
			
		PlanetEnums.PlanetType.SUPER_EARTH:
			if normalized_distance > 0.5: 
				eccentricity = max(eccentricity, 0.15)
	
	match p_star_type:
		StarType.M:
			eccentricity *= 0.7

		StarType.O, StarType.B:
			eccentricity *= 1.3
	
	if normalized_distance > 0.7 and eccentricity < 0.25:
		eccentricity = randf_range(0.25, 0.5) 
		
	return clamp(eccentricity, 0.01, 0.65) # Maximum increased to 0.65 for more dramatic orbits
	
func generate_random_star_type() -> StarType:
	var rand = randf()
	if rand < 0.76:  # M-type (red dwarf) - most common
		return StarType.M
	elif rand < 0.88:  # K-type
		return StarType.K
	elif rand < 0.956:  # G-type
		return StarType.G
	elif rand < 0.986:  # F-type
		return StarType.F
	elif rand < 0.992:  # A-type
		return StarType.A
	elif rand < 0.9933:  # B-type
		return StarType.B
	else:  # O-type - extremely rare
		return StarType.O

func determine_planet_type(_star_props: Dictionary) -> PlanetEnums.PlanetType:
	var rand = randf()
	
	match star_type:
		StarType.O, StarType.B:
			if rand < 0.4: return PlanetEnums.PlanetType.GAS_GIANT
			elif rand < 0.7: return PlanetEnums.PlanetType.ICE_GIANT
			elif rand < 0.85: return PlanetEnums.PlanetType.SUPER_JUPITER
			elif rand < 0.95: return PlanetEnums.PlanetType.SUPER_EARTH
			else: return PlanetEnums.PlanetType.ROCKY_MEDIUM
			
		StarType.A:
			if rand < 0.3: return PlanetEnums.PlanetType.GAS_GIANT
			elif rand < 0.6: return PlanetEnums.PlanetType.ICE_GIANT
			elif rand < 0.8: return PlanetEnums.PlanetType.SUPER_EARTH
			elif rand < 0.9: return PlanetEnums.PlanetType.ROCKY_MEDIUM
			else: return PlanetEnums.PlanetType.ROCKY_SMALL
			
		StarType.F, StarType.G:
			if rand < 0.15: return PlanetEnums.PlanetType.GAS_GIANT
			elif rand < 0.3: return PlanetEnums.PlanetType.ICE_GIANT
			elif rand < 0.5: return PlanetEnums.PlanetType.SUPER_EARTH
			elif rand < 0.8: return PlanetEnums.PlanetType.ROCKY_MEDIUM
			else: return PlanetEnums.PlanetType.ROCKY_SMALL
			
		StarType.K:
			if rand < 0.1: return PlanetEnums.PlanetType.GAS_GIANT
			elif rand < 0.25: return PlanetEnums.PlanetType.ICE_GIANT
			elif rand < 0.5: return PlanetEnums.PlanetType.SUPER_EARTH
			elif rand < 0.8: return PlanetEnums.PlanetType.ROCKY_MEDIUM
			else: return PlanetEnums.PlanetType.ROCKY_SMALL
			
		StarType.M:
			if rand < 0.05: return PlanetEnums.PlanetType.GAS_GIANT
			elif rand < 0.15: return PlanetEnums.PlanetType.ICE_GIANT
			elif rand < 0.4: return PlanetEnums.PlanetType.SUPER_EARTH
			elif rand < 0.7: return PlanetEnums.PlanetType.ROCKY_MEDIUM
			else: return PlanetEnums.PlanetType.ROCKY_SMALL
			
	return PlanetEnums.PlanetType.ROCKY_SMALL

func get_star_type_name() -> String:
	return StarType.keys()[star_type]

func generate_star_name() -> String:
	
	var name_type = randf()
	
	if name_type < 0.25:
		# PGC - Planet Game Catalog
		return "PGC-" + str(randi_range(1000, 9999))
	elif name_type < 0.5:
		# GSC - Galactic Survey Catalog
		return "GSC " + str(randi_range(100, 999)) + "-" + str(randi_range(1000, 9999))
	elif name_type < 0.7:
		# XSO - Exoplanet Survey Object
		return "XSO-" + str(randi_range(1, 2000))
	elif name_type < 0.85:
		# NGC - use high numbers to avoid real NGC objects
		return "NGC " + str(randi_range(8000, 19999))
	elif name_type < 0.95:
		# PGSS - Planet Game Star Survey
		return "PGSS J" + str(randi_range(0, 23)).pad_zeros(2) + str(randi_range(0, 59)).pad_zeros(2) + "+" + str(randi_range(0, 89)).pad_zeros(2)
	else:
		# SSC - Stellar Survey Catalog
		return "SSC-" + str(randi_range(10000, 99999))
		
func get_planet_index(target_planet: Planet) -> int:
	"""Get the index of a planet in the system (for stable identification)"""
	var planets = []
	for child in get_children():
		if child is Planet:
			planets.append(child)
	
	return planets.find(target_planet)

func get_planet_by_index(index: int) -> Planet:
	"""Get a planet by its index in the system"""
	var planets = []
	for child in get_children():
		if child is Planet:
			planets.append(child)
	
	if index >= 0 and index < planets.size():
		return planets[index]
	
	return null

func get_planets_array() -> Array[Planet]:
	"""Get all planets as an ordered array"""
	var planets: Array[Planet] = []
	for child in get_children():
		if child is Planet:
			planets.append(child)
	
	return planets
	
func ensure_all_planets_enhanced():
	var planets = get_planets_array()
	var generated_count = 0
	
	for planet in planets:
		if planet.needs_enhanced_properties():
			planet.generate_enhanced_properties()
			generated_count += 1
		
		# Recalculate habitability if we have a habitable zone
		if planet.enhanced_properties_generated and habitable_zone:
			planet.calculate_habitability_score(habitable_zone)
	
	if generated_count > 0:
		_log_info('Generated enhanced properties for %s planets', [generated_count])
	
func debug_planet_states():
	_log_debug('\n=== PLANET STATES DEBUG ===')
	_log_info('System seed: %s', [current_seed])
	_log_info('Star type: %s', [get_star_type_name()])
	
	var planets = get_planets_array()
	for i in range(planets.size()):
		var planet = planets[i]
		var summary = planet.get_enhanced_properties_summary()
		_log_info('Planet %s (%s): %s', [i, planet.planet_name, summary.status])
		
		if summary.status == "generated":
			_log_info('  Habitability: %s', [snapped(summary.habitability_score, 0.01)])
			_log_info('  Atmosphere: %s', [summary.atmosphere_type])
			_log_info('  Climate: %s', [summary.climate_type])
			_log_info('  Moons: %s', [summary.moons_count])
	
	_log_debug('===========================\n')
	
func _process(_delta):
	if show_orbits:
		queue_redraw()
