class_name MoldBodyRenderer
extends Node2D

## Renders all slime mold body connections in a single _draw() call.
## This replaces individual Line2D nodes — instead of N draw calls per frame
## for N edges, the entire body network is drawn in one pass.

# Each entry: {from: Vector2, to: Vector2, color: Color, width: float}
var _segments: Array = []

func _draw() -> void:
	for seg in _segments:
		draw_line(seg.from, seg.to, seg.color, seg.width, true)

## Add a segment and return its index (used to update it later)
func add_segment(p_from: Vector2, p_to: Vector2, color: Color, width: float) -> int:
	_segments.append({from = p_from, to = p_to, color = color, width = width})
	queue_redraw()
	return _segments.size() - 1

## Update color and width of an existing segment by index
func update_segment(idx: int, color: Color, width: float) -> void:
	if idx < 0 or idx >= _segments.size():
		return
	_segments[idx].color = color
	_segments[idx].width = width
	queue_redraw()

func clear() -> void:
	_segments.clear()
	queue_redraw()
