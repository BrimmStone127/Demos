class_name HarvesterInstance
extends RefCounted

## A slime mold organism placed on a planet surface.
## Represented visually as a growing network of Line2D arteries.
## Body connections age over time, shifting color from bright lime through green
## to teal and eventually gray-purple (bread-mold style aging).

const MAX_FEELERS := 3

var planet_id: String = ""
var origin: Vector2i = Vector2i.ZERO

# Set of all tiles that are part of the body (used for feeler pathfinding)
# Vector2i -> true
var body_tiles: Dictionary = {}

# Permanent body connections, keyed by a canonical edge string "x1,y1:x2,y2".
# Value: {idx: int, flow: int, age: int}
# idx is the segment index in renderer. flow drives line thickness.
var body_connections: Dictionary = {}

# Single renderer node — all body edges drawn in one _draw() call
var renderer: MoldBodyRenderer = null

# Small nucleus dot drawn at origin
var nucleus_visual: Node2D = null

# Active feelers growing from body tiles toward trees
var feelers: Array = []  # Array[FeelerInstance]

var inventory_logs: int = 0
