class_name FeelerInstance
extends RefCounted

## A tendril growing from the slime mold toward a target tree.
## Rendered as a single Line2D that gains points as it grows tile by tile.
## On digestion the manager converts this line into a permanent body connection.

enum FeelerState {
	GROWING,    # Advancing along remaining_path; adds one point per tick
	DIGESTING,  # Reached target — consumed next tick, line becomes body
}

# Body tile this feeler sprouted from (first point of line_visual)
var source: Vector2i = Vector2i.ZERO

# Target tree position
var target: Vector2i = Vector2i.ZERO

# Tiles grown through so far, NOT including source (parallel to line points 1..n)
var trail_tiles: Array[Vector2i] = []

# Remaining tiles to grow through before reaching target
var remaining_path: Array[Vector2i] = []

# The Line2D that visually represents this feeler
# Starts with one point (source) and gains one point per tick
var line_visual: Line2D = null

var state: FeelerState = FeelerState.GROWING
