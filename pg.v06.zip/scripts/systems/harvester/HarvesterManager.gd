class_name HarvesterManager
extends Node

## Manages slime mold organisms on a planet surface.
##
## Visual model:
##   - Nucleus: small bright dot at the placement tile
##   - Feelers: Line2D tendrils that grow one tile per tick toward trees
##   - Body: digested feeler lines become permanent arteries, colored by age
##
## Spreading model:
##   - Up to MAX_FEELERS grow simultaneously
##   - Angular-diversity scoring keeps feelers pointing in different directions
##   - When a feeler digests a tree its entire trail joins the body, so the next
##     feeler can start further out — the mold naturally radiates outward
##
## Aging:
##   - Every tick each body connection's age increments
##   - Color: lime (fresh) -> green -> teal -> gray-purple (old)
##   - Width: thin (new) -> thick (mature) -> slightly thinner (very old)

const LOG_TAG := "HARVESTER"

const STEP_INTERVAL   := 0.35   # seconds between ticks
const BOUNDARY_RADIUS := 30     # Chebyshev max spread from origin

var planet_map_system: PlanetMapSystem = null
var ecosystem_manager: EcosystemManager = null
var map_container: Node2D = null

var _planet_id: String = ""
var harvesters_by_planet: Dictionary = {}
var _step_accumulator: float = 0.0

# Cache of grid_pos -> container-space Vector2 (elevation is fixed so this is safe)
var _pos_cache: Dictionary = {}

# ── Visual constants ──────────────────────────────────────────────────────────

const NUCLEUS_COLOR         := Color(0.92, 1.00, 0.55, 0.98)  # Bright lime-white core
const FEELER_GROWING_COLOR  := Color(0.70, 0.98, 0.40, 0.80)  # Light lime tendril
const FEELER_DIGEST_COLOR   := Color(1.00, 0.68, 0.05, 0.95)  # Amber when digesting

# Body connection aging palette (index 0 = newest)
const BODY_COLORS: Array = [
	Color(0.82, 1.00, 0.30, 0.90),   # 0  fresh lime
	Color(0.55, 0.90, 0.18, 0.87),   # 1  yellow-green
	Color(0.30, 0.75, 0.14, 0.84),   # 2  medium green
	Color(0.15, 0.55, 0.22, 0.80),   # 3  dark green
	Color(0.10, 0.42, 0.30, 0.76),   # 4  deep teal
	Color(0.12, 0.30, 0.32, 0.72),   # 5  dark teal
	Color(0.22, 0.22, 0.35, 0.68),   # 6  blue-gray
	Color(0.38, 0.22, 0.42, 0.65),   # 7  gray-purple
	Color(0.42, 0.28, 0.38, 0.60),   # 8  muted mauve (very old)
]

# How many ticks before advancing to the next color stage
const TICKS_PER_AGE_STAGE := 6

const FEELER_WIDTH := 1.8
const NUCLEUS_Z    := 3200
const BODY_Z       := 2900
const FEELER_Z     := 3100

# ── Logging ───────────────────────────────────────────────────────────────────

func _log_debug(msg: String, values: Array = []) -> void:
	GameLog.debug(LOG_TAG, msg % values if values.size() > 0 else msg)

func _log_info(msg: String, values: Array = []) -> void:
	GameLog.info(LOG_TAG, msg % values if values.size() > 0 else msg)

# ── Public API ────────────────────────────────────────────────────────────────

func set_active_planet(pid: String) -> void:
	_planet_id = pid

func place_harvester(grid_pos: Vector2i, pid: String) -> HarvesterInstance:
	var mold := HarvesterInstance.new()
	mold.planet_id = pid
	mold.origin = grid_pos
	mold.body_tiles[grid_pos] = true
	mold.renderer = _create_renderer()
	mold.nucleus_visual = _create_nucleus(grid_pos)

	if not harvesters_by_planet.has(pid):
		harvesters_by_planet[pid] = []
	harvesters_by_planet[pid].append(mold)

	_planet_id = pid
	_log_info("Slime mold placed at %s", [grid_pos])
	return mold

## Returns the mold whose body contains grid_pos, or null
func get_harvester_at(grid_pos: Vector2i, pid: String) -> HarvesterInstance:
	var harvesters: Array = harvesters_by_planet.get(pid, [])
	for h in harvesters:
		var mold: HarvesterInstance = h as HarvesterInstance
		if mold and mold.body_tiles.has(grid_pos):
			return mold
	return null

func get_total_logs(pid: String) -> int:
	var total: int = 0
	for h in harvesters_by_planet.get(pid, []):
		var mold: HarvesterInstance = h as HarvesterInstance
		if mold:
			total += mold.inventory_logs
	return total

func cleanup_planet(pid: String) -> void:
	for h in harvesters_by_planet.get(pid, []):
		var mold: HarvesterInstance = h as HarvesterInstance
		if not mold:
			continue
		if mold.nucleus_visual and is_instance_valid(mold.nucleus_visual):
			mold.nucleus_visual.queue_free()
		if mold.renderer and is_instance_valid(mold.renderer):
			mold.renderer.queue_free()
		for f in mold.feelers:
			var feeler: FeelerInstance = f as FeelerInstance
			if feeler and feeler.line_visual and is_instance_valid(feeler.line_visual):
				feeler.line_visual.queue_free()

## Export harvester state for persistence
func export_harvesters(pid: String) -> Array:
	var result: Array = []
	for h in harvesters_by_planet.get(pid, []):
		var mold: HarvesterInstance = h as HarvesterInstance
		if mold:
			result.append({
				"origin_x": mold.origin.x,
				"origin_y": mold.origin.y,
				"inventory_logs": mold.inventory_logs,
			})
	return result

## Import harvesters from saved data — re-places them at saved origins
func import_harvesters(pid: String, data: Array) -> void:
	for entry in data:
		var origin := Vector2i(int(entry.get("origin_x", 0)), int(entry.get("origin_y", 0)))
		var mold := place_harvester(origin, pid)
		if mold:
			mold.inventory_logs = int(entry.get("inventory_logs", 0))

# ── Process ───────────────────────────────────────────────────────────────────

func _process(delta: float) -> void:
	_step_accumulator += delta
	if _step_accumulator >= STEP_INTERVAL:
		_step_accumulator = 0.0
		_tick_all_molds()

# ── Tick ──────────────────────────────────────────────────────────────────────

func _tick_all_molds() -> void:
	if _planet_id == "":
		return
	for h in harvesters_by_planet.get(_planet_id, []):
		var mold: HarvesterInstance = h as HarvesterInstance
		if mold:
			_tick_mold(mold)

func _tick_mold(mold: HarvesterInstance) -> void:
	# Process feelers
	var to_digest: Array = []
	for f in mold.feelers:
		var fobj: FeelerInstance = f as FeelerInstance
		if not fobj:
			continue
		match fobj.state:
			FeelerInstance.FeelerState.GROWING:
				_grow_feeler(mold, fobj)
			FeelerInstance.FeelerState.DIGESTING:
				to_digest.append(fobj)

	for feeler in to_digest:
		_digest_feeler(mold, feeler)
		mold.feelers.erase(feeler)

	# Sprout new feelers until at the limit (break if no tree found)
	while mold.feelers.size() < HarvesterInstance.MAX_FEELERS:
		var prev_size: int = mold.feelers.size()
		_spawn_feeler(mold)
		if mold.feelers.size() == prev_size:
			break

# ── Feeler growth ─────────────────────────────────────────────────────────────

func _grow_feeler(mold: HarvesterInstance, feeler: FeelerInstance) -> void:
	if feeler.remaining_path.is_empty():
		_mark_feeler_digesting(feeler)
		return

	var next_tile: Vector2i = feeler.remaining_path[0]
	feeler.remaining_path.remove_at(0)
	feeler.trail_tiles.append(next_tile)

	if feeler.line_visual and is_instance_valid(feeler.line_visual):
		feeler.line_visual.add_point(_grid_to_container(next_tile))

	# Harvest any tree the feeler crosses, not just the final target.
	# Paths can pass through tree tiles on the way to the destination.
	if planet_map_system and planet_map_system.has_tree_at(next_tile):
		planet_map_system.remove_tree_at(next_tile)
		mold.inventory_logs += 1

	if feeler.remaining_path.is_empty():
		_mark_feeler_digesting(feeler)

func _mark_feeler_digesting(feeler: FeelerInstance) -> void:
	feeler.state = FeelerInstance.FeelerState.DIGESTING
	if feeler.line_visual and is_instance_valid(feeler.line_visual):
		feeler.line_visual.default_color = FEELER_DIGEST_COLOR
		feeler.line_visual.width = FEELER_WIDTH + 1.2

func _digest_feeler(mold: HarvesterInstance, feeler: FeelerInstance) -> void:
	# Remove the tree
	if planet_map_system and planet_map_system.has_tree_at(feeler.target):
		planet_map_system.remove_tree_at(feeler.target)
		mold.inventory_logs += 1
	elif planet_map_system:
		_log_debug("Feeler arrived at %s but no tree found (already gone or static tile)", [feeler.target])

	# Free the growing polyline — it's replaced by per-edge body lines below
	if feeler.line_visual and is_instance_valid(feeler.line_visual):
		feeler.line_visual.queue_free()
	feeler.line_visual = null

	# Add trail tiles to body
	for tile in feeler.trail_tiles:
		mold.body_tiles[tile] = true

	# Create or reinforce one Line2D per edge in the path.
	# Width is based on geographic distance from the mold origin — edges near
	# the nucleus are thick trunk, edges far away are thin peripheral branches.
	# This is stable regardless of which feeler created the edge or in what order.
	# Shared edges add FLOW_BONUS per additional feeler, reinforcing main arteries.
	const TRUNK_WIDTH := 14.0
	const TIP_WIDTH   :=  1.8
	const FLOW_BONUS  :=  5.0

	var full_path: Array[Vector2i] = [feeler.source]
	full_path.append_array(feeler.trail_tiles)

	for i in range(full_path.size() - 1):
		var a: Vector2i = full_path[i]
		var b: Vector2i = full_path[i + 1]
		var key: String = _edge_key(a, b)

		# Width from geographic distance of edge midpoint from origin
		var mid_dist: float = (
			abs(a.x - mold.origin.x) + abs(a.y - mold.origin.y) +
			abs(b.x - mold.origin.x) + abs(b.y - mold.origin.y)
		) * 0.5
		var t: float = clamp(mid_dist / float(BOUNDARY_RADIUS), 0.0, 1.0)
		var taper_width: float = lerp(TRUNK_WIDTH, TIP_WIDTH, t)

		if mold.body_connections.has(key):
			var conn: Dictionary = mold.body_connections[key]
			conn.flow += 1
			var new_width: float = taper_width + float(conn.flow - 1) * FLOW_BONUS
			if mold.renderer and is_instance_valid(mold.renderer):
				mold.renderer.update_segment(conn.idx, BODY_COLORS[0], new_width)
		else:
			var pa: Vector2 = _grid_to_container(a)
			var pb: Vector2 = _grid_to_container(b)
			var idx: int = -1
			if mold.renderer and is_instance_valid(mold.renderer):
				idx = mold.renderer.add_segment(pa, pb, BODY_COLORS[0], taper_width)
			mold.body_connections[key] = {idx = idx, flow = 1, age = 0, taper_width = taper_width}

# ── Feeler spawning (angular-diversity selection) ─────────────────────────────

func _spawn_feeler(mold: HarvesterInstance) -> void:
	if mold.feelers.size() >= HarvesterInstance.MAX_FEELERS or not planet_map_system:
		return

	# Collect angles of current feeler targets from origin
	var existing_angles: Array = []
	for f in mold.feelers:
		var fobj: FeelerInstance = f as FeelerInstance
		if not fobj:
			continue
		var diff: Vector2i = fobj.target - mold.origin
		existing_angles.append(atan2(float(diff.y), float(diff.x)))

	var best_score: float = -1.0
	var best_tree: Vector2i = Vector2i(-1, -1)

	for dx in range(-BOUNDARY_RADIUS, BOUNDARY_RADIUS + 1):
		for dy in range(-BOUNDARY_RADIUS, BOUNDARY_RADIUS + 1):
			var candidate: Vector2i = mold.origin + Vector2i(dx, dy)
			if candidate.x < 0 or candidate.y < 0:
				continue
			if not planet_map_system.has_tree_at(candidate):
				continue
			if mold.body_tiles.has(candidate):
				continue
			if _is_tree_targeted(candidate, mold):
				continue

			# Use Chebyshev distance from origin for scoring — O(1), no body scan.
			# _find_nearest_body_tile is called only once for the winner below.
			var origin_dist: int = max(abs(dx), abs(dy))

			var angle: float = atan2(float(dy), float(dx))
			var angular_gap: float = TAU
			for ea in existing_angles:
				var diff_a: float = abs(angle - ea)
				if diff_a > PI:
					diff_a = TAU - diff_a
				angular_gap = min(angular_gap, diff_a)

			# Normalise gap to [0,1] so distance dominates and direction
			# acts as a soft tiebreaker rather than an extreme selector.
			var norm_gap: float = angular_gap / PI
			var score: float = (norm_gap * 0.4 + 0.1) / (float(origin_dist) + 1.0)
			if score > best_score:
				best_score = score
				best_tree = candidate

	if best_tree == Vector2i(-1, -1):
		return

	var best_body: Vector2i = _find_nearest_body_tile(mold, best_tree)
	if best_body == Vector2i(-1, -1) or best_body == best_tree:
		return

	var path: Array[Vector2i] = _find_path(best_body, best_tree, mold.origin, mold.body_tiles)
	if path.is_empty():
		_log_debug("No path from %s to tree at %s", [best_body, best_tree])
		return

	var feeler := FeelerInstance.new()
	feeler.source = best_body
	feeler.target = best_tree
	feeler.remaining_path = path
	feeler.line_visual = _create_feeler_line(best_body)
	mold.feelers.append(feeler)


func _find_nearest_body_tile(mold: HarvesterInstance, target: Vector2i) -> Vector2i:
	# Scan only the last 50 body tiles (insertion order = most recent = frontier)
	# plus origin, to keep the search bounded regardless of body size.
	# Only consider tiles that are no farther from origin than the target —
	# this prevents feelers from starting at a distant tip and growing backward.
	var target_cheb: int = max(abs(target.x - mold.origin.x), abs(target.y - mold.origin.y))
	var best: Vector2i = mold.origin
	var best_dist: int = abs(target.x - mold.origin.x) + abs(target.y - mold.origin.y)
	var keys: Array = mold.body_tiles.keys()
	var start: int = max(0, keys.size() - 50)
	for i in range(start, keys.size()):
		var pos: Vector2i = keys[i]
		var tile_cheb: int = max(abs(pos.x - mold.origin.x), abs(pos.y - mold.origin.y))
		if tile_cheb > target_cheb:
			continue  # Skip tiles farther out than the target — avoids backward paths
		var dist: int = abs(target.x - pos.x) + abs(target.y - pos.y)
		if dist < best_dist:
			best_dist = dist
			best = pos
	return best

func _is_tree_targeted(tree_pos: Vector2i, mold: HarvesterInstance) -> bool:
	for f in mold.feelers:
		var feeler: FeelerInstance = f as FeelerInstance
		if feeler and feeler.target == tree_pos:
			return true
	return false

# ── Body aging ────────────────────────────────────────────────────────────────

func _age_body_connections(mold: HarvesterInstance) -> void:
	if not mold.renderer or not is_instance_valid(mold.renderer):
		return
	for conn in mold.body_connections.values():
		conn.age += 1
		@warning_ignore("integer_division")
		var stage: int = min(conn.age / TICKS_PER_AGE_STAGE, BODY_COLORS.size() - 1)
		var width: float = _taper_width_for_conn(conn)
		mold.renderer.update_segment(conn.idx, BODY_COLORS[stage], width)
	mold.renderer.queue_redraw()

# ── Pathfinding ───────────────────────────────────────────────────────────────

# How much random noise is added to the distance score at each step.
# Higher = more wandering, lower = straighter paths.
const WANDER_NOISE := 1.5

# Max steps before the organic walk gives up and falls back to BFS.
const MAX_WALK_STEPS := 60

func _find_path(from: Vector2i, to: Vector2i, origin: Vector2i, body_tiles: Dictionary) -> Array[Vector2i]:
	if from == to:
		return []
	var path := _organic_walk(from, to, origin, body_tiles)
	if not path.is_empty():
		return path
	return _bfs_path(from, to, origin, body_tiles)

## Biased random walk: at each step scores each neighbor by
## (Chebyshev distance to target + random noise) and picks the lowest.
## Avoids body_tiles so feelers never route through existing arteries.
## Falls back to _bfs_path on failure.
func _organic_walk(from: Vector2i, to: Vector2i, origin: Vector2i, body_tiles: Dictionary) -> Array[Vector2i]:
	var dirs: Array[Vector2i] = [
		Vector2i(1, 0),  Vector2i(-1, 0), Vector2i(0, 1),  Vector2i(0, -1),
		Vector2i(1, 1),  Vector2i(1, -1), Vector2i(-1, 1), Vector2i(-1, -1),
	]

	var path: Array[Vector2i] = []
	var current: Vector2i = from
	var visited: Dictionary = {}
	visited[from] = true

	for _step in MAX_WALK_STEPS:
		if current == to:
			return path

		var best_next: Vector2i = Vector2i(-9999, -9999)
		var best_score: float = 1e9

		for d in dirs:
			var next: Vector2i = current + d
			if not _in_boundary(next, origin):
				continue
			if not _is_valid_position(next):
				continue
			if visited.has(next):
				continue
			# Don't route through existing body (except the destination itself)
			if next != to and body_tiles.has(next):
				continue
			var cheb: int = max(abs(next.x - to.x), abs(next.y - to.y))
			var score: float = float(cheb) + randf() * WANDER_NOISE
			if score < best_score:
				best_score = score
				best_next = next

		if best_next == Vector2i(-9999, -9999):
			return []  # stuck — caller falls back to BFS

		path.append(best_next)
		visited[best_next] = true
		current = best_next

	return []  # exceeded step limit

## Guaranteed shortest-path BFS — used as fallback when the organic walk fails.
## Also avoids body_tiles to keep feelers in fresh territory.
func _bfs_path(from: Vector2i, to: Vector2i, origin: Vector2i, body_tiles: Dictionary) -> Array[Vector2i]:
	var queue: Array[Vector2i] = [from]
	var came_from: Dictionary = {}
	came_from[from] = from

	var dirs: Array[Vector2i] = [
		Vector2i(1, 0),  Vector2i(-1, 0), Vector2i(0, 1),  Vector2i(0, -1),
		Vector2i(1, 1),  Vector2i(1, -1), Vector2i(-1, 1), Vector2i(-1, -1),
	]

	var found: bool = false
	while queue.size() > 0:
		var current: Vector2i = queue[0]
		queue.remove_at(0)
		if current == to:
			found = true
			break
		for d in dirs:
			var next: Vector2i = current + d
			if not _in_boundary(next, origin):
				continue
			if not _is_valid_position(next):
				continue
			if came_from.has(next):
				continue
			# Don't route through existing body (except the destination itself)
			if next != to and body_tiles.has(next):
				continue
			came_from[next] = current
			queue.append(next)

	if not found:
		return []

	var path: Array[Vector2i] = []
	var c: Vector2i = to
	while c != from:
		path.push_front(c)
		c = came_from[c]
	return path

func _in_boundary(pos: Vector2i, origin: Vector2i) -> bool:
	return (
		pos.x >= 0 and pos.y >= 0 and
		abs(pos.x - origin.x) <= BOUNDARY_RADIUS and
		abs(pos.y - origin.y) <= BOUNDARY_RADIUS
	)

func _is_valid_position(pos: Vector2i) -> bool:
	if pos.x < 0 or pos.y < 0:
		return false
	if not planet_map_system:
		return true
	if planet_map_system.using_chunks:
		return true
	return planet_map_system.get_tile_at(pos) != null

# ── Edge helpers ─────────────────────────────────────────────────────────────

## Canonical string key for an undirected edge between two tiles
func _edge_key(a: Vector2i, b: Vector2i) -> String:
	if a.x < b.x or (a.x == b.x and a.y < b.y):
		return "%d,%d:%d,%d" % [a.x, a.y, b.x, b.y]
	return "%d,%d:%d,%d" % [b.x, b.y, a.x, a.y]

func _taper_width_for_conn(conn: Dictionary) -> float:
	return conn.get("taper_width", 2.0) + float(conn.flow - 1) * 5.0

# ── Visuals ───────────────────────────────────────────────────────────────────

func _create_renderer() -> MoldBodyRenderer:
	if not map_container:
		return null
	var r := MoldBodyRenderer.new()
	r.z_index = BODY_Z
	map_container.add_child(r)
	return r

func _create_nucleus(grid_pos: Vector2i) -> Node2D:
	if not map_container or not planet_map_system:
		return null
	var poly := Polygon2D.new()
	# Isometric ellipse approximation (8-sided)
	var pts := PackedVector2Array()
	for i in 8:
		var angle: float = float(i) / 8.0 * TAU
		pts.append(Vector2(cos(angle) * 14.0, sin(angle) * 7.0))
	poly.polygon = pts
	poly.color = NUCLEUS_COLOR
	poly.position = _grid_to_container(grid_pos)
	poly.z_index = NUCLEUS_Z
	map_container.add_child(poly)
	return poly

func _create_feeler_line(source: Vector2i) -> Line2D:
	if not map_container or not planet_map_system:
		return null
	var line := Line2D.new()
	line.width = FEELER_WIDTH
	line.default_color = FEELER_GROWING_COLOR
	line.joint_mode = Line2D.LINE_JOINT_ROUND
	line.begin_cap_mode = Line2D.LINE_CAP_ROUND
	line.end_cap_mode = Line2D.LINE_CAP_ROUND
	line.add_point(_grid_to_container(source))
	line.z_index = FEELER_Z
	map_container.add_child(line)
	return line

## Convert grid position to map_container local position.
## Cached — elevation is fixed so the result never changes for a given tile.
func _grid_to_container(grid_pos: Vector2i) -> Vector2:
	if _pos_cache.has(grid_pos):
		return _pos_cache[grid_pos]
	var result := _compute_grid_to_container(grid_pos)
	_pos_cache[grid_pos] = result
	return result

func _compute_grid_to_container(grid_pos: Vector2i) -> Vector2:
	if not planet_map_system or not planet_map_system.tile_manager or not map_container:
		return Vector2.ZERO

	var elevation_raw: float = planet_map_system.get_elevation_at(grid_pos)
	var tile_layer: int = PlanetMapTileConfig.get_render_layer(elevation_raw)

	var local_pos: Vector2
	var sm: PlanetMapSelection = planet_map_system.selection_manager
	if sm and tile_layer < sm.layer_tilemaps.size():
		var tm: TileMap = sm.layer_tilemaps[tile_layer]
		if tm and is_instance_valid(tm):
			local_pos = tm.map_to_local(grid_pos) + tm.position
		else:
			local_pos = PlanetMapCoordinates.grid_to_world(grid_pos)
			local_pos.y -= float(tile_layer) * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET
	else:
		local_pos = PlanetMapCoordinates.grid_to_world(grid_pos)
		local_pos.y -= float(tile_layer) * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET

	var world_pos: Vector2 = planet_map_system.tile_manager.to_global(local_pos)
	return map_container.to_local(world_pos)
