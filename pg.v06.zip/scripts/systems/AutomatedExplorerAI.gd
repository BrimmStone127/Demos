class_name AutomatedExplorerAI
extends Node

# Visual automation system that explores star systems looking for habitable planets
# The AI's actions are fully visible to the player - camera movements, selections, etc.

signal ai_activated
signal ai_deactivated
signal planet_examined(planet: Planet)
signal probe_launched(planet: Planet)
signal habitable_planet_discovered(planet: Planet)

var main_node: Node2D
var is_active: bool = false
var habitability_threshold: float = 0.5
var discovery_pause_threshold: float = 0.7  # Pause AI when planet exceeds this
var current_planet_index: int = 0
var planets_to_examine: Array = []
var paused_for_planets: Array = []  # Track planets that already triggered a discovery pause

# Visual effects
var planet_highlight_shader: Shader = null
var current_highlight: Node2D = null
var current_highlight_tween: Tween = null

# Speed settings (seconds)
var camera_move_delay: float = 1.5
var selection_delay: float = 0.8
var decision_delay: float = 0.5
var post_probe_delay: float = 2.0
var system_jump_delay: float = 1.5

func initialize(p_main_node: Node2D):
	main_node = p_main_node
	name = "AutomatedExplorerAI"

func start_exploration():
	if is_active:
		return

	is_active = true
	emit_signal("ai_activated")
	explore_current_system()

func stop_exploration():
	if not is_active:
		return

	is_active = false
	emit_signal("ai_deactivated")
	_remove_planet_highlight()

func explore_current_system():
	if not is_active:
		return

	# Get all planets in current system
	planets_to_examine = _get_planets()
	current_planet_index = 0

	# Start examining planets one by one
	_examine_next_planet()

func _examine_next_planet():
	if not is_active:
		return

	# Check if we've examined all planets
	if current_planet_index >= planets_to_examine.size():
		# Done with this system, jump to next one
		await get_tree().create_timer(system_jump_delay).timeout
		if not is_active:
			return

		_jump_to_next_system()
		return

	var planet = planets_to_examine[current_planet_index]
	current_planet_index += 1

	# Move camera to planet
	await _move_camera_to_planet(planet)
	if not is_active:
		return

	# Add visual highlight to planet
	_add_planet_highlight(planet)

	# Brief pause to "examine" the planet visually
	await get_tree().create_timer(selection_delay).timeout
	if not is_active:
		return

	emit_signal("planet_examined", planet)

	# Check habitability and decide whether to probe
	await _evaluate_and_probe(planet)
	if not is_active:
		return

	# Remove highlight
	_remove_planet_highlight()

	# Move to next planet
	_examine_next_planet()

func _move_camera_to_planet(planet: Planet):
	if main_node.camera_manager:
		main_node.camera_manager.track_object(planet)
	if main_node.ui_manager:
		main_node.ui_manager.set_selected_celestial_body(planet)
	await get_tree().create_timer(camera_move_delay).timeout

func _evaluate_and_probe(planet: Planet):
	# Wait a moment to "think"
	await get_tree().create_timer(decision_delay).timeout

	if not is_active:
		return

	# Check if this is a highly habitable planet (worthy of pausing exploration)
	if planet.habitability_score >= discovery_pause_threshold:
		# Check if we've already paused for this planet
		var planet_id = planet.get_instance_id()
		if planet_id in paused_for_planets:
			# Already paused for this planet before, skip the pause but still probe if needed
			if planet.habitability_score > habitability_threshold:
				var can_launch_repeat = main_node.probe_system.can_launch_probe(
					ProbeSystem.ProbeType.PRIMITIVE_ORBITAL,
					planet
				)

				if can_launch_repeat.can_launch:
					main_node.probe_system.launch_probe(
						ProbeSystem.ProbeType.PRIMITIVE_ORBITAL,
						planet
					)
					emit_signal("probe_launched", planet)
					await get_tree().create_timer(post_probe_delay).timeout
			return

		# First time discovering this highly habitable planet
		# Launch probe first
		var can_launch_discovery = main_node.probe_system.can_launch_probe(
			ProbeSystem.ProbeType.PRIMITIVE_ORBITAL,
			planet
		)

		if can_launch_discovery.can_launch:
			main_node.probe_system.launch_probe(
				ProbeSystem.ProbeType.PRIMITIVE_ORBITAL,
				planet
			)
			emit_signal("probe_launched", planet)

		# Add to paused list so we don't pause again for this planet
		paused_for_planets.append(planet_id)

		# Pause the AI - habitable world discovered!
		emit_signal("habitable_planet_discovered", planet)
		stop_exploration()
		return

	# Check if planet is worth probing (access planet data directly, no UI needed)
	if planet.habitability_score > habitability_threshold:
		# Launch probe directly
		var can_launch_result = main_node.probe_system.can_launch_probe(
			ProbeSystem.ProbeType.PRIMITIVE_ORBITAL,
			planet
		)

		if can_launch_result.can_launch:
			main_node.probe_system.launch_probe(
				ProbeSystem.ProbeType.PRIMITIVE_ORBITAL,
				planet
			)

			emit_signal("probe_launched", planet)

			# Wait after probe launch
			await get_tree().create_timer(post_probe_delay).timeout

func _flash_button_red(button: Button):
	if not button:
		return

	# Store original styles
	var original_normal = button.get_theme_stylebox("normal")
	var original_hover = button.get_theme_stylebox("hover")
	var original_pressed = button.get_theme_stylebox("pressed")

	# Create red flash style
	var flash_style = StyleBoxFlat.new()
	flash_style.bg_color = Color(0.8, 0.0, 0.0, 0.9)  # Red
	flash_style.border_color = Color(1.0, 0.0, 0.0)   # Bright red border
	flash_style.border_width_top = 2
	flash_style.border_width_bottom = 2
	flash_style.border_width_left = 2
	flash_style.border_width_right = 2

	# Apply red style
	button.add_theme_stylebox_override("normal", flash_style)
	button.add_theme_stylebox_override("hover", flash_style)
	button.add_theme_stylebox_override("pressed", flash_style)

	# Wait 1.5 seconds
	await get_tree().create_timer(1.5).timeout

	# Restore original styles
	if original_normal:
		button.add_theme_stylebox_override("normal", original_normal)
	if original_hover:
		button.add_theme_stylebox_override("hover", original_hover)
	if original_pressed:
		button.add_theme_stylebox_override("pressed", original_pressed)

func _add_planet_highlight(planet: Planet):
	_remove_planet_highlight()  # Remove any existing highlight first

	# Create a circle outline around the planet
	var highlight = Node2D.new()
	highlight.name = "AIHighlight"
	planet.add_child(highlight)
	highlight.z_index = 10

	current_highlight = highlight

	# Start pulsing animation
	_pulse_highlight(highlight, planet.planet_size)

func _pulse_highlight(highlight: Node2D, planet_size: float):
	if not is_instance_valid(highlight):
		return

	# Create a drawing function that will be called every frame
	highlight.queue_redraw()

	# Kill any existing tween to avoid lambda capture issues
	if current_highlight_tween and current_highlight_tween.is_valid():
		current_highlight_tween.kill()
		current_highlight_tween = null

	# Use a timer to animate the pulse
	current_highlight_tween = create_tween()
	current_highlight_tween.set_loops()

	# Pulse between 1.0 and 1.3 scale
	var base_radius = planet_size * 600  # Approximate visual size
	var pulse_min = base_radius * 1.1
	var pulse_max = base_radius * 1.3

	# Store pulse values in metadata
	highlight.set_meta("pulse_min", pulse_min)
	highlight.set_meta("pulse_max", pulse_max)
	highlight.set_meta("pulse_value", pulse_min)

	# Animate pulse value using bound method instead of lambda to avoid capture issues
	current_highlight_tween.tween_method(_on_pulse_value_changed.bind(highlight), pulse_min, pulse_max, 0.8)
	current_highlight_tween.tween_method(_on_pulse_value_changed.bind(highlight), pulse_max, pulse_min, 0.8)

	# Connect draw signal
	if not highlight.draw.is_connected(_on_highlight_draw):
		highlight.draw.connect(_on_highlight_draw.bind(highlight))

func _on_pulse_value_changed(value: float, highlight: Node2D):
	if is_instance_valid(highlight):
		highlight.set_meta("pulse_value", value)
		highlight.queue_redraw()

func _on_highlight_draw(highlight: Node2D):
	if not is_instance_valid(highlight):
		return

	var pulse_value = highlight.get_meta("pulse_value", 50.0)

	# Draw a red circle outline
	highlight.draw_arc(
		Vector2.ZERO,
		pulse_value,
		0,
		TAU,
		64,
		Color(1.0, 0.0, 0.0, 0.8),  # Red with some transparency
		3.0,  # Line width
		true
	)

func _remove_planet_highlight():
	# Kill the tween first to avoid lambda capture errors
	if current_highlight_tween and current_highlight_tween.is_valid():
		current_highlight_tween.kill()
		current_highlight_tween = null

	if current_highlight and is_instance_valid(current_highlight):
		current_highlight.queue_free()
		current_highlight = null

func _jump_to_next_system():
	# Flash the New System button before jumping
	await _flash_new_system_button()

	if not is_active:
		return

	# Generate new system
	main_node.generate_star_system()

	# Wait for system generation to complete
	await main_node.system_generation_manager.system_generation_complete

	if not is_active:
		return

	# Clear the paused planets list for the new system
	paused_for_planets.clear()

	# Start exploring the new system
	explore_current_system()

func _flash_new_system_button():
	# Access the control panel directly from UIManager
	if not main_node.ui_manager:
		return

	var control_panel = main_node.ui_manager.control_panel
	if not control_panel or not is_instance_valid(control_panel):
		return

	var new_system_button = _find_new_system_button(control_panel)
	if new_system_button:
		await _flash_button_red(new_system_button)

func _find_new_system_button(node: Node) -> Button:
	if node is Button and "New Star System" in node.text:
		return node

	for child in node.get_children():
		var result = _find_new_system_button(child)
		if result:
			return result

	return null

func _get_planets() -> Array:
	var planets = []
	var star_system = main_node.get_current_star_system()
	if star_system:
		for child in star_system.get_children():
			if child is Planet:
				planets.append(child)
	return planets

# Utility function to flash any button red for a custom duration
func flash_button(button: Button, _duration: float = 1.5):
	await _flash_button_red(button)
