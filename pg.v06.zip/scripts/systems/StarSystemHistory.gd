﻿class_name StarSystemHistory
extends Node

const LOG_TAG := "STAR_SYSTEM_HISTORY"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


# Maximum number of systems to keep in history
const MAX_HISTORY_SIZE = 20000

# The array of historical systems (most recent first)
var history = []

# Signal emitted when history changes
signal history_updated
signal system_selected(seed_value: int)

#-------------------------------------------------------------------------------
# History Management Functions
#-------------------------------------------------------------------------------

# Add a system to history
func add_system(seed_value: int, star_type: String, planet_count: int):
	# Create system data dictionary
	var system_data = {
		"seed": seed_value,
		"star_type": star_type,
		"planet_count": planet_count,
		"timestamp": Time.get_unix_time_from_system()
	}
	
	# Check if this seed is already in history
	for i in range(history.size()):
		if history[i].seed == seed_value:
			# Remove the existing entry
			history.remove_at(i)
			break
	
	# Add to the front of the list (most recent first)
	history.push_front(system_data)
	
	# Trim history if it's too long
	if history.size() > MAX_HISTORY_SIZE:
		history.resize(MAX_HISTORY_SIZE)
	
	# Emit signal that history changed
	emit_signal("history_updated")
	_log_info('History updated, now contains %s items', [history.size()])

# Get the full history array
func get_history():
	return history

func export_history() -> Array:
	var data: Array = []
	for entry in history:
		if entry is Dictionary:
			data.append(entry.duplicate(true))
		else:
			data.append(entry)
	return data

func import_history(history_data: Array) -> void:
	history.clear()
	if history_data is Array:
		for entry in history_data:
			if entry is Dictionary:
				history.append(entry.duplicate(true))
			else:
				history.append(entry)
	emit_signal("history_updated")

# Clear history
func clear_history():
	history.clear()
	emit_signal("history_updated")

# Format a date from Unix timestamp
func format_timestamp(timestamp: float) -> String:
	var datetime = Time.get_datetime_dict_from_unix_time(int(timestamp))
	return "%04d-%02d-%02d %02d:%02d" % [
		datetime.year, 
		datetime.month, 
		datetime.day,
		datetime.hour,
		datetime.minute
	]

#-------------------------------------------------------------------------------
# History Panel UI
#-------------------------------------------------------------------------------

# Show the history panel
func show_history_panel(parent_node: Node):
	var panel = HistoryPanelControl.new(self)
	parent_node.add_child(panel)
	
	# Explicitly update after adding to scene
	panel.call_deferred("_update_history_display")
	panel.call_deferred("_adjust_position")
	
	return panel

# Class for the History Panel
class HistoryPanelControl extends Panel:
	var history_system: StarSystemHistory
	var history_container: VBoxContainer
	
	func _init(p_history_system: StarSystemHistory):
		history_system = p_history_system
		name = "HistoryPanel"
		custom_minimum_size = Vector2(320, 400)
		
		_build_ui()
		
	func _build_ui():
		# Main layout container
		var main_container = VBoxContainer.new()
		main_container.size_flags_horizontal = Control.SIZE_FILL
		main_container.size_flags_vertical = Control.SIZE_FILL
		main_container.position = Vector2(10, 10)
		main_container.custom_minimum_size = Vector2(300, 380)
		add_child(main_container)
		
		# Header with title and close button
		var header = HBoxContainer.new()
		header.size_flags_horizontal = Control.SIZE_FILL
		main_container.add_child(header)
		
		var title_label = Label.new()
		title_label.text = "Exploration History"
		title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		title_label.size_flags_horizontal = Control.SIZE_FILL
		title_label.add_theme_font_size_override("font_size", 18)
		TerminalTheme.apply_to_label(title_label)
		header.add_child(title_label)
		
		var close_button = Button.new()
		close_button.text = "X"
		close_button.pressed.connect(func(): queue_free())
		header.add_child(close_button)
		
		# Separator
		var separator = HSeparator.new()
		main_container.add_child(separator)
		
		# Instructions label
		var instructions = Label.new()
		instructions.text = "Click on a system to revisit it"
		instructions.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		TerminalTheme.apply_to_label(instructions)
		main_container.add_child(instructions)
		
		# Scroll container for history items
		var scroll_container = ScrollContainer.new()
		scroll_container.size_flags_horizontal = Control.SIZE_FILL
		scroll_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
		scroll_container.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		main_container.add_child(scroll_container)
		
		# Container for history items
		history_container = VBoxContainer.new()
		history_container.name = "HistoryContainer"
		history_container.size_flags_horizontal = Control.SIZE_FILL
		history_container.size_flags_vertical = Control.SIZE_FILL
		scroll_container.add_child(history_container)
		
		# Clear History button at the bottom
		var clear_button = Button.new()
		clear_button.text = "Clear History"
		clear_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		clear_button.pressed.connect(_on_clear_button_pressed)
		main_container.add_child(clear_button)
		
		# Connect to history updates for live updates
		if not history_system.history_updated.is_connected(_update_history_display):
			history_system.history_updated.connect(_update_history_display)
			
		# Initial update
		_update_history_display()
	
	func _adjust_position():
		# Wait one frame to ensure we have the proper viewport size
		await get_tree().process_frame
		
		# Get viewport size
		var viewport_size = get_viewport_rect().size
		
		# Center the panel
		position = Vector2(
			(viewport_size.x - size.x) / 2.0,
			(viewport_size.y - size.y) / 2.0
		).floor()
	
	func _notification(what: int) -> void:
		if what == NOTIFICATION_PREDELETE:
			if history_system and history_system.history_updated.is_connected(_update_history_display):
				history_system.history_updated.disconnect(_update_history_display)

	func _on_clear_button_pressed():
		# Confirmation dialog
		var dialog = ConfirmationDialog.new()
		dialog.title = "Clear History"
		dialog.dialog_text = "Are you sure you want to clear your exploration history?"
		dialog.confirmed.connect(func(): history_system.clear_history())
		add_child(dialog)
		dialog.popup_centered()
	
	func _on_system_selected(seed_value: int):
		history_system._log_info('System selected from history: %s', [seed_value])
		history_system.emit_signal("system_selected", seed_value)
		queue_free()
	
	func _update_history_display():
		history_system._log_info('Updating history display with %s items', [history_system.history.size()])
		
		# Clear existing history items
		for child in history_container.get_children():
			child.queue_free()
		
		var history_data = history_system.get_history()
		
		if history_data.size() == 0:
			var empty_label = Label.new()
			empty_label.text = "No history yet.\nExplore some star systems!"
			empty_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			empty_label.custom_minimum_size.y = 100
			empty_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			TerminalTheme.apply_to_label(empty_label)
			history_container.add_child(empty_label)
			return
		
		# Add each history item
		for system_data in history_data:
			var item = _create_history_item(system_data)
			history_container.add_child(item)
			
			# Add a small margin between items
			var margin = Control.new()
			margin.custom_minimum_size.y = 5
			history_container.add_child(margin)
	
	func _create_history_item(system_data: Dictionary) -> Control:
		# Container for the whole item
		var item = PanelContainer.new()
		item.size_flags_horizontal = Control.SIZE_FILL
		
		# Make the panel look like a button
		var stylebox = StyleBoxFlat.new()
		stylebox.bg_color = Color(0.25, 0.25, 0.25)
		stylebox.corner_radius_top_left = 4
		stylebox.corner_radius_top_right = 4
		stylebox.corner_radius_bottom_left = 4
		stylebox.corner_radius_bottom_right = 4
		item.add_theme_stylebox_override("panel", stylebox)
		
		# Use a standard button rather than a flat button inside a container
		var button = Button.new()
		button.flat = true
		button.size_flags_horizontal = Control.SIZE_FILL
		button.size_flags_vertical = Control.SIZE_FILL
		
		# Create a direct reference to the seed value for the closure
		var seed_value = system_data.seed
		button.pressed.connect(func(): _on_system_selected(seed_value))
		
		item.add_child(button)
		
		# Content layout
		var content = VBoxContainer.new()
		content.size_flags_horizontal = Control.SIZE_FILL
		content.custom_minimum_size.y = 60
		content.mouse_filter = Control.MOUSE_FILTER_IGNORE  # Pass events to parent
		item.add_child(content)
		
		# Top info row (star type and seed)
		var top_row = HBoxContainer.new()
		top_row.size_flags_horizontal = Control.SIZE_FILL
		top_row.mouse_filter = Control.MOUSE_FILTER_IGNORE  # Pass events to parent
		content.add_child(top_row)
		
		var star_type_label = Label.new()
		star_type_label.text = "Type: " + system_data.star_type
		star_type_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		star_type_label.mouse_filter = Control.MOUSE_FILTER_IGNORE  # Pass events to parent
		TerminalTheme.apply_to_label(star_type_label)
		top_row.add_child(star_type_label)

		var seed_label = Label.new()
		seed_label.text = "Seed: " + str(system_data.seed)
		seed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		seed_label.mouse_filter = Control.MOUSE_FILTER_IGNORE  # Pass events to parent
		TerminalTheme.apply_to_label(seed_label)
		top_row.add_child(seed_label)

		# Middle row (planets)
		var planets_label = Label.new()
		planets_label.text = "Planets: " + str(system_data.planet_count)
		planets_label.mouse_filter = Control.MOUSE_FILTER_IGNORE  # Pass events to parent
		TerminalTheme.apply_to_label(planets_label)
		content.add_child(planets_label)

		# Bottom row (date)
		var date_label = Label.new()
		date_label.text = "Explored: " + history_system.format_timestamp(system_data.timestamp)
		date_label.add_theme_font_size_override("font_size", 12)
		date_label.mouse_filter = Control.MOUSE_FILTER_IGNORE  # Pass events to parent
		TerminalTheme.apply_to_label(date_label)
		date_label.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
		content.add_child(date_label)
		
		# Add hover effect
		item.mouse_entered.connect(func():
			stylebox.bg_color = Color(0.35, 0.35, 0.35)
			item.add_theme_stylebox_override("panel", stylebox)
		)
		
		item.mouse_exited.connect(func():
			stylebox.bg_color = Color(0.25, 0.25, 0.25)
			item.add_theme_stylebox_override("panel", stylebox)
		)
		
		return item

