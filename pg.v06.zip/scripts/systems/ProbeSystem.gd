class_name ProbeSystem
extends Node

const LOG_TAG := "PROBE_SYSTEM"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


# Manages probe deployment and discovery of detailed planetary information
# Players start with basic observations and must send probes for detailed data

signal probe_launched(target, probe_type)
signal probe_arrived(target, probe_type, data)
signal discovery_made(discovery_type, target, data)

enum ProbeType {
	PRIMITIVE_ORBITAL
}

enum DiscoveryLevel {
	BASIC,           # Initial telescopic observations
	SURVEYED,        # Basic probe data
	ANALYZED,        # Multiple probe types
	COMPREHENSIVE    # All probe types completed
}

const PLANET_SURFACE_MAP_KEY := "surface_map_cache"
const PLANET_SURFACE_MAP_VERSION := 3  # Incremented for TileMap native layer system refactor

const PROBE_SPECS = {
	ProbeType.PRIMITIVE_ORBITAL: {
		"name": "Analyze Planet",
		"travel_time": 1.5,
		"cost": 2,
		"requires": [],
		"reveals": ["habitability_score", "atmosphere_type", "surface_temperature", 
				   "geological_activity", "moons", "surface_liquids", "basic_composition"],
		"description": "Basic orbital survey providing essential planetary data"
	}
}

var discovered_systems: Dictionary = {}
var discovered_planets: Dictionary = {}
var active_probes: Array[ProbeInstance] = []
var player_resources: int = 1000
var carbon: int = 0
var network_manager: NetworkManager = null

# ADD: Track current system for state management
var current_system_seed: int = -1

func _ready():
	# Process active probes
	set_process(true)

func _process(delta):
	# Update active probe travel times
	for i in range(active_probes.size() - 1, -1, -1):
		var probe = active_probes[i]
		
		# SAFETY CHECK: Clear invalid target references
		if probe.target and not is_instance_valid(probe.target):
			probe.target = null
		
		probe.remaining_time -= delta
		
		if probe.remaining_time <= 0:
			_complete_probe_mission(probe)
			active_probes.remove_at(i)

# Generate stable planet ID from system seed and planet index
func export_data() -> Dictionary:
	var data: Dictionary = {
		"discovered_systems": discovered_systems.duplicate(true),
		"discovered_planets": {},
		"player_resources": player_resources,
		"carbon": carbon,
		"current_system_seed": current_system_seed
	}
	for key in discovered_planets:
		var value = discovered_planets[key]
		data["discovered_planets"][key] = value.duplicate(true) if value is Dictionary else value
	return data

func import_data(data: Dictionary) -> void:
	discovered_systems = {}
	var systems_value = data.get("discovered_systems", {})
	if systems_value is Dictionary:
		discovered_systems = systems_value.duplicate(true)

	discovered_planets.clear()
	var planet_data = data.get("discovered_planets", {})
	if planet_data is Dictionary:
		for key in planet_data:
			var value = planet_data[key]
			if value is Dictionary:
				apply_saved_discovery(key, value)
			else:
				discovered_planets[key] = value

	player_resources = data.get("player_resources", player_resources)
	carbon = data.get("carbon", carbon)
	current_system_seed = data.get("current_system_seed", current_system_seed)

func apply_saved_discovery(planet_id: String, record: Dictionary) -> Dictionary:
	# Normalize saved probe data so enums match runtime expectations
	if planet_id == "":
		return {}
	if record == null or typeof(record) != TYPE_DICTIONARY:
		discovered_planets.erase(planet_id)
		return {}
	var normalized = _normalize_discovery_record(record)
	discovered_planets[planet_id] = normalized
	return normalized

func _normalize_discovery_record(record: Dictionary) -> Dictionary:
	var normalized = record.duplicate(true)
	var level = int(normalized.get("discovery_level", DiscoveryLevel.BASIC))
	level = clamp(level, DiscoveryLevel.BASIC, DiscoveryLevel.COMPREHENSIVE)
	normalized["discovery_level"] = level
	normalized["probes_completed"] = _normalize_completed_probes(normalized.get("probes_completed", []))
	var revealed = normalized.get("revealed_data")
	normalized["revealed_data"] = revealed.duplicate(true) if revealed is Dictionary else {}
	return normalized

func _normalize_completed_probes(raw) -> Array:
	var normalized: Array = []
	if raw is Array:
		for value in raw:
			var probe_value = int(value)
			if probe_value not in normalized:
				normalized.append(probe_value)
	elif raw is PackedInt32Array or raw is PackedInt64Array or raw is PackedByteArray:
		for value in raw:
			var probe_value = int(value)
			if probe_value not in normalized:
				normalized.append(probe_value)
	normalized.sort()
	return normalized

func _get_stable_planet_id(target) -> String:
	if target is Planet:
		var star_system = target.get_parent()
		if star_system and star_system.has_method("get_planet_index"):
			var system_seed = star_system.current_seed
			var planet_index = star_system.get_planet_index(target)
			return str(system_seed) + ":" + str(planet_index)
		elif star_system:
			# Fallback: find index manually
			var planet_index = -1
			var planets = []
			for child in star_system.get_children():
				if child is Planet:
					planets.append(child)
			planet_index = planets.find(target)
			if planet_index >= 0:
				return str(star_system.current_seed) + ":" + str(planet_index)
	
	# Fallback to instance ID if we can't generate stable ID
	return str(target.get_instance_id())

# Find planet by stable ID in current system
func _find_planet_by_stable_id(stable_id: String) -> Planet:
	var parts = stable_id.split(":")
	if parts.size() != 2:
		return null
	
	var system_seed = parts[0].to_int()
	var planet_index = parts[1].to_int()
	
	# Get current star system safely
	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if not main_node or not is_instance_valid(main_node):
		return null
	
	if not main_node.has_method("get_current_star_system"):
		return null
	
	var star_system = main_node.get_current_star_system()
	if not star_system or not is_instance_valid(star_system):
		return null
	
	if star_system.current_seed != system_seed:
		# We're in a different system, planet not available
		return null
	
	# Find planet by index
	if star_system.has_method("get_planet_by_index"):
		var planet = star_system.get_planet_by_index(planet_index)
		if planet and is_instance_valid(planet):
			return planet
	else:
		# Fallback: manual search
		var planets = []
		for child in star_system.get_children():
			if child is Planet and is_instance_valid(child):
				planets.append(child)
		
		if planet_index >= 0 and planet_index < planets.size():
			var planet = planets[planet_index]
			if is_instance_valid(planet):
				return planet
	
	return null

# Check if player can launch a specific probe type
func can_launch_probe(probe_type: ProbeType, target) -> Dictionary:
	var spec = PROBE_SPECS[probe_type]
	var result = {"can_launch": true, "reason": ""}
	
	# Check resources
	if player_resources < spec.cost:
		result.can_launch = false
		result.reason = "Insufficient resources (" + str(spec.cost) + " required, " + str(player_resources) + " available)"
		return result
	
	# Check if probe type already completed
	var target_id = _get_stable_planet_id(target)
	var discovery_data = discovered_planets.get(target_id, {})
	if discovery_data.has("probes_completed") and probe_type in discovery_data.probes_completed:
		result.can_launch = false
		result.reason = "This probe type has already been deployed to this target"
		return result
	
	return result

func launch_probe(probe_type: ProbeType, target) -> bool:
	var can_launch_result = can_launch_probe(probe_type, target)
	if not can_launch_result.can_launch:
		_log_info('Cannot launch probe: %s', [can_launch_result.reason])
		return false
	
	var spec = PROBE_SPECS[probe_type]
	player_resources -= spec.cost
	
	var probe = ProbeInstance.new()
	probe.probe_type = probe_type
	probe.target = target
	probe.target_id = _get_stable_planet_id(target)
	probe.remaining_time = spec.travel_time
	probe.launch_time = Time.get_unix_time_from_system()
	probe.original_planet_name = _get_target_name(target)
	
	if network_manager:
		probe.owner_id = network_manager.get_local_player_id()
		probe.owner_name = network_manager.get_player_name(probe.owner_id)
	else:
		probe.owner_id = 1
		probe.owner_name = "Player"
		
	if target is Planet:
		var star_system = target.get_parent()
		if star_system:
			probe.system_seed = star_system.current_seed
	
	active_probes.append(probe)
	
	if network_manager and network_manager.is_multiplayer:
		var probe_data = {
			"planet_name": probe.target_id,
			"probe_type": probe_type,
			"owner_id": probe.owner_id,
			"owner_name": probe.owner_name
		}
		rpc("receive_probe_launch", probe_data)
	
	_log_info('Launched %s to %s (ETA: %ss)', [spec.name, probe.original_planet_name, spec.travel_time])
	emit_signal("probe_launched", target, probe_type)
	
	return true

func _complete_probe_mission(probe: ProbeInstance):
	var spec = PROBE_SPECS[probe.probe_type]
	var target_id = probe.target_id
	
	# SAFETY CHECK: Clear target reference if it's been freed
	if probe.target and not is_instance_valid(probe.target):
		probe.target = null
	
	# Find the actual planet using stable ID (only if we're in the same system)
	var current_planet = null
	if probe.target and is_instance_valid(probe.target):
		current_planet = probe.target
	else:
		current_planet = _find_planet_by_stable_id(target_id)
	
	# Initialize discovery data if needed
	if not discovered_planets.has(target_id):
		discovered_planets[target_id] = {
			"discovery_level": DiscoveryLevel.BASIC,
			"probes_completed": [],
			"revealed_data": {},
			"discovery_time": Time.get_unix_time_from_system(),
			"planet_name": probe.original_planet_name,  # Store original name
			"system_seed": probe.system_seed
		}
	
	var discovery_data = discovered_planets[target_id]
	discovery_data.probes_completed.append(probe.probe_type)
	
	# Generate and store revealed data
	var revealed_info = {}
	if current_planet and is_instance_valid(current_planet):
		revealed_info = _generate_probe_data(current_planet, probe.probe_type)
		probe.target = current_planet  # Update target reference
		_log_info('Generated probe data using current planet: %s', [probe.original_planet_name])
	else:
		# Planet not currently loaded or target freed, generate deterministic data
		revealed_info = _generate_probe_data_from_stable_id(target_id, probe.probe_type)
		probe.target = null  # Clear invalid reference
		_log_info('Generated probe data deterministically for: %s', [probe.original_planet_name])
	
	for key in spec.reveals:
		discovery_data.revealed_data[key] = revealed_info.get(key, null)
	
	# Update discovery level
	discovery_data.discovery_level = _calculate_discovery_level(discovery_data.probes_completed)
	
	_log_info('Probe mission completed! %s has analyzed %s', [spec.name, probe.original_planet_name])
	
	if current_planet and is_instance_valid(current_planet):
		var player_name = probe.owner_name if probe.owner_name != "" else "Explorer"
		current_planet.set_probed_by(player_name)
		_log_debug('DEBUG: Called set_probed_by on planet %s with player: %s', [current_planet.planet_name, player_name])

	# SAFETY CHECK: Only pass valid target or use planet name string
	var signal_target = null
	if probe.target and is_instance_valid(probe.target):
		signal_target = probe.target
	else:
		signal_target = probe.original_planet_name  # Use string instead of freed object
	
	emit_signal("probe_arrived", signal_target, probe.probe_type, revealed_info)
	
	# Check for significant discoveries (only if target is valid)
	if probe.target and is_instance_valid(probe.target):
		_check_for_discoveries(probe.target, revealed_info)
	
	# MULTIPLAYER SYNC: Send discovery to other players
	if network_manager and network_manager.is_multiplayer:
		# Add ownership info to the discovery
		revealed_info["discovered_by_id"] = probe.owner_id
		revealed_info["discovered_by_name"] = probe.owner_name
		revealed_info["probe_type"] = probe.probe_type
		revealed_info["planet_name"] = probe.original_planet_name
		revealed_info["system_seed"] = probe.system_seed
		
		# Send discovery to other players
		rpc("receive_discovery", probe.target_id, revealed_info)

# Generate detailed data based on probe type (when planet is available)
func _generate_probe_data(target, probe_type: ProbeType) -> Dictionary:
	var data = {}
	
	# Work with enhanced Planet (not separate class)
	if not target is Planet:
		return data
	
	var planet = target as Planet
	
	# Make sure enhanced properties are generated
	if not planet.enhanced_properties_generated:
		planet.generate_enhanced_properties()
	
	# Calculate habitability if we have access to the star system
	var star_system = planet.get_parent()
	if star_system and star_system.has_method("get_habitability_summary") and star_system.habitable_zone:
		planet.calculate_habitability_score(star_system.habitable_zone)
	
	match probe_type:
		ProbeType.PRIMITIVE_ORBITAL:
			# Primary output: Habitability score
			data["habitability_score"] = planet.habitability_score
			
			# Physical stats
			data["mass"] = planet.data.mass
			data["radius"] = planet.data.radius
			data["surface_gravity"] = planet.data.surface_gravity
			data["axial_tilt"] = planet.data.axial_tilt
			data["is_tidally_locked"] = planet.data.is_tidally_locked

			# Basic atmospheric data
			data["atmosphere_type"] = PlanetEnums.AtmosphereType.keys()[planet.atmosphere_type]
			data["atmosphere_pressure"] = planet.atmosphere_pressure
			data["surface_temperature"] = planet.surface_temperature
			data["temperature_variation"] = planet.data.temperature_variation
			data["climate_type"] = PlanetEnums.ClimateType.keys()[planet.climate_type]
			
			# Basic geological data
			data["geological_activity"] = PlanetEnums.GeologicalActivity.keys()[planet.geological_activity]
			data["magnetosphere"] = PlanetEnums.MagnetosphereStrength.keys()[planet.magnetosphere_strength]
			data["magnetic_field_strength"] = planet.data.magnetic_field_strength
			data["tectonic_plates"] = planet.tectonic_plates
			
			# Moon data
			data["moons"] = []
			for moon in planet.moons:
				data["moons"].append({
					"name": moon.name,
					"distance": moon.distance,
					"size": moon.size,
					"orbital_period": moon.orbital_period,
					"tidally_locked": moon.is_tidally_locked
				})
			
			# Surface data
			data["surface_liquids"] = planet.surface_liquids.duplicate()
			data["surface_composition"] = planet.surface_composition.duplicate()

			# Rotation data (for day/night cycle continuity)
			data["rotation_angle"] = planet.rotation_angle
			data["rotation_period"] = planet.rotation_period

			# Survey metadata
			data["survey_type"] = "Basic orbital survey"
			data["detailed_mapping"] = "Complete orbital survey conducted"

	return data

# Generate probe data from stable ID when planet not available
func _generate_probe_data_from_stable_id(stable_id: String, probe_type: ProbeType) -> Dictionary:
	var data = {}

	# Parse stable ID for deterministic generation
	var parts = stable_id.split(":")
	if parts.size() != 2:
		return data

	var system_seed = parts[0].to_int()
	var planet_index = parts[1].to_int()

	# Create deterministic random generator for the planet characteristics
	var rng = RandomNumberGenerator.new()
	rng.seed = system_seed + planet_index * 12345
	
	# Create a temporary PlanetData to use its generation logic
	var p_data = PlanetData.new()
	p_data.semi_major_axis = rng.randf_range(100.0, 1000.0)
	p_data.eccentricity = rng.randf_range(0.0, 0.4)
	p_data.planet_type = rng.randi() % 6
	p_data.size = rng.randf_range(0.04, 0.12)
	p_data.generate_enhanced(rng)

	# Now overwrite the RNG with one specific to this probe task
	rng.seed = hash(stable_id + str(probe_type))

	match probe_type:
		ProbeType.PRIMITIVE_ORBITAL:
			data["habitability_score"] = p_data.habitability_score
			
			# Physical stats
			data["mass"] = p_data.mass
			data["radius"] = p_data.radius
			data["surface_gravity"] = p_data.surface_gravity
			data["axial_tilt"] = p_data.axial_tilt
			data["is_tidally_locked"] = p_data.is_tidally_locked

			# Atmospheric data
			data["atmosphere_type"] = PlanetEnums.AtmosphereType.keys()[p_data.atmosphere_type]
			data["atmosphere_pressure"] = p_data.atmosphere_pressure
			data["surface_temperature"] = p_data.surface_temperature
			data["temperature_variation"] = p_data.temperature_variation
			data["climate_type"] = PlanetEnums.ClimateType.keys()[p_data.climate_type]

			# Geological data
			data["geological_activity"] = PlanetEnums.GeologicalActivity.keys()[p_data.geological_activity]
			data["magnetosphere"] = PlanetEnums.MagnetosphereStrength.keys()[p_data.magnetosphere_strength]
			data["tectonic_plates"] = p_data.tectonic_plates

			# Moon data
			var moon_count = rng.randi_range(0, 5)
			data["moons"] = []
			for i in range(moon_count):
				data["moons"].append({
					"name": "Moon " + str(i + 1),
					"distance": rng.randf_range(2.0, 20.0),
					"size": rng.randf_range(0.1, 0.5),
					"orbital_period": rng.randf_range(1.0, 100.0),
					"tidally_locked": rng.randf() < 0.5
				})

			# Surface data
			data["surface_liquids"] = p_data.surface_liquids.duplicate()
			data["surface_composition"] = p_data.surface_composition.duplicate()

	return data

func _assess_life_potential_from_score(score: float) -> String:
	if score > 0.8:
		return "Excellent - Multiple favorable conditions"
	elif score > 0.6:
		return "Good - Some favorable conditions"
	elif score > 0.3:
		return "Marginal - Limited favorable conditions"
	else:
		return "Poor - Hostile environment"
		
# Check for significant discoveries
func _check_for_discoveries(target, probe_data: Dictionary):
	if probe_data.has("habitability_score") and probe_data.habitability_score > 0.7:
		emit_signal("discovery_made", "habitable_world", target, probe_data)
		
# Get discovery level for a target
func get_discovery_level(target) -> DiscoveryLevel:
	var target_id = _get_stable_planet_id(target)
	var discovery_data = discovered_planets.get(target_id, {})
	return discovery_data.get("discovery_level", DiscoveryLevel.BASIC)

# Get revealed data for a target
func get_revealed_data(target) -> Dictionary:
	var target_id = _get_stable_planet_id(target)
	var discovery_data = discovered_planets.get(target_id, {})
	return discovery_data.get("revealed_data", {})

# Check if specific data has been revealed
func is_data_revealed(target, data_key: String) -> bool:
	var revealed_data = get_revealed_data(target)
	return revealed_data.has(data_key)

# Get available probe types for a target
func get_available_probes(target) -> Array:
	var available = []
	for probe_type in ProbeType.values():
		var can_launch_result = can_launch_probe(probe_type, target)
		if can_launch_result.can_launch:
			available.append(probe_type)
	
	return available

# Get completed probes for a target
func get_completed_probes(target) -> Array:
	var target_id = _get_stable_planet_id(target)
	var discovery_data = discovered_planets.get(target_id, {})
	return discovery_data.get("probes_completed", [])

# Get all discovery data for a system
func get_system_discovery_data(system_seed: int) -> Dictionary:
	var system_data = {}
	var seed_prefix = str(system_seed) + ":"
	for planet_id in discovered_planets:
		if not planet_id.begins_with(seed_prefix):
			continue
		var record = discovered_planets[planet_id]
		if record is Dictionary:
			var trimmed = record.duplicate(true)
			if trimmed.has(PLANET_SURFACE_MAP_KEY):
				trimmed.erase(PLANET_SURFACE_MAP_KEY)
			system_data[planet_id] = trimmed
		else:
			system_data[planet_id] = record
	return system_data

# Check if we have discovery data for a planet (even if not currently loaded)
func has_discovery_data(system_seed: int, planet_index: int) -> bool:
	var stable_id = str(system_seed) + ":" + str(planet_index)
	return discovered_planets.has(stable_id)

# Utility functions
func _get_target_name(target) -> String:
	if target.has_method("get") and "planet_name" in target:
		return target.planet_name
	elif target.has_method("get") and "star_name" in target:
		return target.star_name
	else:
		return "Unknown Target"

func _calculate_discovery_level(completed_probes: Array) -> DiscoveryLevel:
	var count = completed_probes.size()
	if count == 0:
		return DiscoveryLevel.BASIC
	elif count <= 1:
		return DiscoveryLevel.SURVEYED
	else:
		return DiscoveryLevel.COMPREHENSIVE

# Generate biosignature data
func _generate_biosignature_data(planet: Planet) -> Dictionary:
	var biosigs = {"detected": false, "confidence": 0.0, "types": []}
	
	if planet.habitability_score > 0.5:
		var detection_chance = planet.habitability_score * 0.3  # 30% max chance
		if randf() < detection_chance:
			biosigs.detected = true
			biosigs.confidence = randf_range(0.6, 0.9)
			biosigs.types = ["oxygen", "methane", "water_vapor"]
		else:
			biosigs.confidence = randf_range(0.1, 0.4)
			biosigs.types = ["inconclusive"]
	
	return biosigs

func _assess_life_potential(planet: Planet) -> String:
	if planet.habitability_score > 0.8:
		return "Excellent - Multiple favorable conditions"
	elif planet.habitability_score > 0.6:
		return "Good - Some favorable conditions"
	elif planet.habitability_score > 0.3:
		return "Marginal - Limited favorable conditions"
	else:
		return "Poor - Hostile environment"

func _generate_chemical_markers(planet: Planet) -> Dictionary:
	var markers = {}
	
	# PLACEHOLDER: Generate some interesting chemical data based on planet properties
	if planet.has_atmosphere:
		markers["atmospheric_chemistry"] = "Complex atmospheric interactions detected"
	
	if planet.surface_liquids.has("water"):
		markers["water_chemistry"] = "Liquid water confirmed"
	
	if planet.geological_activity > PlanetEnums.GeologicalActivity.LOW:
		markers["geological_chemistry"] = "Active chemical processes from geological activity"
	
	return markers

func set_current_system(system_seed: int):
	current_system_seed = system_seed
	
func can_rename_planet(target: Planet) -> bool:
	if not target or not is_instance_valid(target):
		return false
	return get_discovery_level(target) > DiscoveryLevel.BASIC

func rename_planet(target: Planet, old_name: String, new_name: String) -> void:
	if not target or not is_instance_valid(target):
		return
	var planet_id = _get_stable_planet_id(target)
	if planet_id == "":
		return
	var record = discovered_planets.get(planet_id)
	if record is Dictionary:
		record["planet_name"] = new_name
		var revealed = record.get("revealed_data")
		if revealed is Dictionary:
			if old_name != "" and revealed.get("planet_name", old_name) == old_name:
				revealed["planet_name"] = new_name
		var cache = record.get(PLANET_SURFACE_MAP_KEY)
		if cache is Dictionary and old_name != "" and cache.get("planet_name", old_name) == old_name:
			cache["planet_name"] = new_name
	for probe in active_probes:
		if probe is ProbeInstance:
			if probe.target == target:
				probe.original_planet_name = new_name
			elif old_name != "" and probe.original_planet_name == old_name:
				probe.original_planet_name = new_name

func _find_planet_by_name(planet_name: String) -> Planet:
	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if not main_node or not is_instance_valid(main_node):
		return null
	
	if not main_node.has_method("get_current_star_system"):
		return null
	
	var star_system = main_node.get_current_star_system()
	if not star_system or not is_instance_valid(star_system):
		return null
	
	for child in star_system.get_children():
		if child is Planet and is_instance_valid(child):
			if child.planet_name == planet_name:
				return child
	
	return null
	
@rpc("any_peer", "call_remote", "reliable")
func receive_probe_launch(data: Dictionary):
	_log_info("%s launched probe to %s", [data["owner_name"], data["planet_name"]])
	
@rpc("any_peer", "call_remote", "reliable")
func receive_discovery(planet_id: String, discovery_data: Dictionary):
	clear_surface_map_cache(planet_id)
	if not discovered_planets.has(planet_id):
		discovered_planets[planet_id] = {
			"discovery_level": DiscoveryLevel.BASIC,
			"probes_completed": [],
			"revealed_data": {},
			"discovery_time": Time.get_unix_time_from_system(),
			"planet_name": discovery_data.get("planet_name", "Unknown"),
			"system_seed": discovery_data.get("system_seed", -1)
		}
	
	var planet_data = discovered_planets[planet_id]
	var probe_type = discovery_data.get("probe_type", ProbeType.PRIMITIVE_ORBITAL)
	
	if not probe_type in planet_data.probes_completed:
		planet_data.probes_completed.append(probe_type)
	
	for key in discovery_data:
		if key != "probe_type" and key != "planet_name" and key != "system_seed":
			planet_data.revealed_data[key] = discovery_data[key]
	
	var planet = _find_planet_by_stable_id(planet_id)
	if planet and is_instance_valid(planet):
		planet.set_probed_by(discovery_data.get("discovered_by_name", "Unknown"))
	
	_log_info("Received discovery for %s from %s", [discovery_data.get("planet_name", "Unknown"), discovery_data.get("discovered_by_name", "Unknown")])

func get_surface_map_cache(planet_id: String) -> Dictionary:
	var planet_record = discovered_planets.get(planet_id)
	if planet_record:
		return planet_record.get(PLANET_SURFACE_MAP_KEY, {})
	return {}

func set_surface_map_cache(planet_id: String, cache_payload: Dictionary) -> void:
	if not discovered_planets.has(planet_id):
		discovered_planets[planet_id] = {}
	discovered_planets[planet_id][PLANET_SURFACE_MAP_KEY] = cache_payload

func clear_surface_map_cache(planet_id: String) -> void:
	if discovered_planets.has(planet_id):
		discovered_planets[planet_id].erase(PLANET_SURFACE_MAP_KEY)

func compute_surface_map_seed(planet_id: String) -> int:
	return abs(hash(planet_id + ":" + str(PLANET_SURFACE_MAP_VERSION)))

func get_surface_map_seed(planet_id: String) -> int:
	var cache = get_surface_map_cache(planet_id)
	if cache.has("seed"):
		return int(cache["seed"])
	return compute_surface_map_seed(planet_id)

func get_planet_discoveries(planet: Planet) -> Array:
	var planet_id = _get_stable_planet_id(planet)
	if discovered_planets.has(planet_id):
		var data = discovered_planets[planet_id]
		var discoveries_array = []
		discoveries_array.append({
			"revealed_data": data.revealed_data,
			"probes_completed": data.probes_completed,
			"discovery_level": data.discovery_level,
			"discovered_by_name": data.revealed_data.get("discovered_by_name", "Unknown")
		})
		return discoveries_array
	return []

func get_planet_discoverer(planet: Planet) -> String:

	var planet_id = _get_stable_planet_id(planet)
	if discovered_planets.has(planet_id):
		var data = discovered_planets[planet_id]
		return data.revealed_data.get("discovered_by_name", "Unknown")
	return ""
	
class ProbeInstance:
	var owner_id: int = 1
	var owner_name: String = "Player"
	var probe_type: ProbeType
	var target: Planet  # May become null when system changes
	var target_id: String  # Stable ID
	var remaining_time: float
	var launch_time: float
	var original_planet_name: String  # Store name for reference
	var system_seed: int  # Store system seed

