# Fixed ProceduralStarBackground.gd - Add null checks and proper cleanup
class_name ProceduralStarBackground
extends ParallaxBackground

const LOG_TAG := "STAR_BACKGROUND"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


const STAR_TYPES = {
	"tiny": {
		"scale_range": Vector2(0.1, 0.3),
		"colors": [
			Color(1.0, 1.0, 1.0, 0.7),
			Color(0.9, 0.95, 1.0, 0.6),
			Color(1.0, 0.98, 0.9, 0.65)
		],
		"frequency": 0.7  # 70% of stars
	},
	"small": {
		"scale_range": Vector2(0.3, 0.5),
		"colors": [
			Color(1.0, 1.0, 1.0, 0.85),
			Color(0.9, 0.95, 1.0, 0.8),
			Color(1.0, 0.98, 0.9, 0.8),
			Color(1.0, 0.9, 0.8, 0.8)  # Slightly yellow/orange
		],
		"frequency": 0.2  # 20% of stars
	},
	"medium": {
		"scale_range": Vector2(0.5, 0.7),
		"colors": [
			Color(1.0, 1.0, 1.0, 0.9),
			Color(0.9, 0.95, 1.0, 0.9),
			Color(1.0, 0.96, 0.9, 0.9),
			Color(1.0, 0.85, 0.7, 0.9)  # Orange-ish
		],
		"frequency": 0.075  # 7.5% of stars
	},
	"large": {
		"scale_range": Vector2(0.7, 1.0),
		"colors": [
			Color(1.0, 1.0, 1.0, 1.0),
			Color(0.85, 0.9, 1.0, 1.0),  # Slightly blue
			Color(1.0, 0.9, 0.8, 1.0),   # Slightly orange
			Color(1.0, 0.8, 0.7, 1.0),   # Orange-red
			Color(0.8, 0.8, 1.0, 1.0)    # Blue-ish
		],
		"frequency": 0.02  # 2% of stars
	},
	"huge": {
		"scale_range": Vector2(1.0, 1.5),
		"colors": [
			Color(1.0, 1.0, 1.0, 1.0),
			Color(0.8, 0.9, 1.0, 1.0),   # Blue-white
			Color(1.0, 0.8, 0.6, 1.0),   # Orange
			Color(1.0, 0.7, 0.7, 1.0),   # Reddish
			Color(0.7, 0.8, 1.0, 1.0)    # Blueish
		],
		"frequency": 0.005  # 0.5% of stars
	}
}

# Constants for star distribution and density
const BASE_STAR_COUNT = 300  # Reduced base number of stars
const STAR_COUNT_VARIANCE = 100  # Random variance in star count
const DENSITY_FADE_EDGE = 0.2  # Fade stars near the edges (20% of screen)

# Configurable properties
@export var star_texture: Texture2D

# Fixed values
var base_parallax_strength: float = 0.05   #Reduced from 0.3 for better behavior
var star_density: float = 1.0      # Fixed value
var current_zoom: float = 1.0      # Track current zoom level

# Private variables
var current_seed: int = 0
var _star_layer: ParallaxLayer
var _stars_container: Node2D
var _viewport_size: Vector2
var is_generated: bool = false  # Track if background has been generated
var debug_logging: bool = false  # Enable debug output
var main_camera: Camera2D = null

func _init():
	scroll_ignore_camera_zoom = true  # Keep this true - we'll manually adjust parallax effect
	
func _ready():
	# Create layers
	_create_layers()
	
	# Connect to window resize signal - ADD NULL CHECK
	if get_tree() and get_tree().get_root():
		get_tree().get_root().size_changed.connect(_handle_resize)
	
	# Find main camera
	call_deferred("_find_camera")
	
	# Initial generation
	if current_seed == 0:
		generate(randi())
	
	_log_info('ProceduralStarBackground ready')

func _find_camera():
	# ADD NULL CHECKS AND BETTER CAMERA FINDING
	if not is_inside_tree():
		return
		
	await get_tree().process_frame
	
	# Try to find camera from CameraManager first
	var camera_manager = get_tree().get_first_node_in_group("camera_manager")
	if camera_manager and camera_manager.has_method("get") and "game_camera" in camera_manager:
		if camera_manager.game_camera and is_instance_valid(camera_manager.game_camera):
			main_camera = camera_manager.game_camera
			_log_info('Found camera via CameraManager')
			return
	
	# Fallback: find any active Camera2D
	var cameras = get_tree().get_nodes_in_group("cameras")
	for camera in cameras:
		if camera and is_instance_valid(camera) and camera is Camera2D:
			main_camera = camera
			_log_info('Found camera via cameras group')
			return
	
	# Last resort: get viewport camera
	if get_viewport():
		var viewport_camera = get_viewport().get_camera_2d()
		if viewport_camera and is_instance_valid(viewport_camera):
			main_camera = viewport_camera
			_log_info('Found camera via viewport')

func _create_layers():
	# Clear existing layers if any
	for child in get_children():
		child.queue_free()
	
	# Create a black background first
	var black_bg = ColorRect.new()
	black_bg.color = Color(0.0, 0.0, 0.0, 1.0)  # Pure black
	black_bg.size = Vector2(10000, 10000)  # Make it very large
	black_bg.position = Vector2(-5000, -5000)  # Center it
	black_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE  # Important! Don't capture clicks
	add_child(black_bg)
	
	# Create star layer (closer, moves more)
	_star_layer = ParallaxLayer.new()
	_star_layer.motion_scale = Vector2(base_parallax_strength, base_parallax_strength)
	add_child(_star_layer)
	
	_stars_container = Node2D.new()
	_star_layer.add_child(_stars_container)
	
	_log_info('Created background layers')

func _process(_delta):
	# ADD PROPER NULL CHECKS
	# Adjust parallax motion based on zoom if we have a camera
	if main_camera and is_instance_valid(main_camera) and main_camera is Camera2D:
		var zoom_value = main_camera.zoom.x
		if zoom_value != current_zoom:
			current_zoom = zoom_value
			
			# Adjust motion scale based on zoom
			# When zoomed out (small value), reduce parallax effect
			# When zoomed in (large value), increase parallax effect
			var adjusted_parallax = base_parallax_strength / current_zoom
			if _star_layer and is_instance_valid(_star_layer):
				_star_layer.motion_scale = Vector2(adjusted_parallax, adjusted_parallax)

func _handle_resize():
	# ADD NULL CHECKS
	# Get viewport size from the tree when available
	if not is_inside_tree():
		return
		
	if get_tree() and get_tree().get_root():
		_viewport_size = get_tree().get_root().get_visible_rect().size
		
		# Regenerate with the same seed to fit the new size
		generate(current_seed)

func generate(seed_value: int):
	current_seed = seed_value
	seed(seed_value)
	
	if debug_logging:
		_log_info('Generating background with seed: %s', [seed_value])
	
	# ADD NULL CHECK FOR TREE
	# Store viewport size (safely)
	if get_tree() and get_tree().get_root():
		_viewport_size = get_tree().get_root().get_visible_rect().size
	else:
		# Default size if we can't get the viewport yet
		_viewport_size = Vector2(1280, 720)
	
	# ADD NULL CHECK FOR STARS CONTAINER
	# Clear existing stars
	if _stars_container and is_instance_valid(_stars_container):
		for child in _stars_container.get_children():
			child.queue_free()
	
	# Extra safety margin (3x viewport size)
	var extended_size = _viewport_size * 3
	if _star_layer and is_instance_valid(_star_layer):
		_star_layer.motion_mirroring = extended_size
	
	# Center container
	if _stars_container and is_instance_valid(_stars_container):
		_stars_container.position = -extended_size / 2.0
	
	# Generate stars
	_generate_stars(extended_size)
	
	# Mark as generated
	is_generated = true

func _generate_stars(area_size: Vector2):
	# ADD NULL CHECK
	if not _stars_container or not is_instance_valid(_stars_container):
		_log_warn('Warning: Cannot generate stars, container is invalid')
		return
		
	# Calculate star count based on area and density
	var area_factor = area_size.x * area_size.y / (1920 * 1080)
	var star_count = int(BASE_STAR_COUNT * area_factor * star_density)
	star_count += randi_range(-STAR_COUNT_VARIANCE, STAR_COUNT_VARIANCE)
	
	if debug_logging:
		_log_info('Generating %s stars', [star_count])
	
	# Generate each star
	for i in range(star_count):
		var star_type = _pick_random_star_type()
		var _props = STAR_TYPES[star_type]
		
		# Random position within extended area
		var pos_x = randf_range(0, area_size.x)
		var pos_y = randf_range(0, area_size.y)
		var pos = Vector2(pos_x, pos_y)
		
		# Calculate distance from center (for density falloff)
		var center = area_size / 2.0
		var dist_factor = (pos - center).length() / (center.length())
		
		# Apply density falloff - fewer stars at the edges
		if dist_factor > (1.0 - DENSITY_FADE_EDGE):
			var fade = 1.0 - ((dist_factor - (1.0 - DENSITY_FADE_EDGE)) / DENSITY_FADE_EDGE)
			if randf() > fade:
				continue
		
		# Create star
		var star = _create_star(star_type, pos)
		if star and _stars_container and is_instance_valid(_stars_container):
			_stars_container.add_child(star)

func _pick_random_star_type() -> String:
	var rand = randf()
	var cumulative = 0.0
	
	for type in STAR_TYPES:
		cumulative += STAR_TYPES[type].frequency
		if rand <= cumulative:
			return type
	
	# Fallback
	return "tiny"

func _create_star(star_type: String, position: Vector2) -> Node2D:
	var star = Sprite2D.new()
	
	# Use provided texture or create a simple circle
	if star_texture:
		star.texture = star_texture
	else:
		# Create a simple circle texture if none provided
		var size = 4
		var image = Image.create(size, size, false, Image.FORMAT_RGBA8)
		image.fill(Color(1, 1, 1, 1))
		
		var texture = ImageTexture.create_from_image(image)
		star.texture = texture
	
	# Apply random properties based on star type
	var props = STAR_TYPES[star_type]
	
	# Scale
	var scale_value = randf_range(props.scale_range.x, props.scale_range.y)
	star.scale = Vector2(scale_value, scale_value)
	
	# Color
	var color_idx = randi() % props.colors.size()
	star.modulate = props.colors[color_idx]
	
	# Position
	star.position = position
	
	# Add subtle twinkling animation for larger stars
	if star_type in ["medium", "large", "huge"]:
		var twinkle_speed = randf_range(0.5, 2.0)
		var twinkle_amount = randf_range(0.1, 0.3)
		
		var animation_player = AnimationPlayer.new()
		star.add_child(animation_player)
		
		var animation = Animation.new()
		var track_idx = animation.add_track(Animation.TYPE_VALUE)
		animation.track_set_path(track_idx, ":modulate:a")
		animation.track_insert_key(track_idx, 0.0, star.modulate.a)
		animation.track_insert_key(track_idx, twinkle_speed, max(0.4, star.modulate.a - twinkle_amount))
		animation.track_insert_key(track_idx, twinkle_speed * 2, star.modulate.a)
		animation.loop_mode = Animation.LOOP_PINGPONG
		
		var animation_library = AnimationLibrary.new()
		animation_library.add_animation("twinkle", animation)
		animation_player.add_animation_library("", animation_library)
		
		# Start with random offset
		animation_player.play("twinkle")
		animation_player.seek(randf() * twinkle_speed * 2)
	
	return star

# ADD CLEANUP METHOD
func cleanup():
	"""Clean up references to prevent freed instance errors"""
	main_camera = null
	
	if _stars_container and is_instance_valid(_stars_container):
		for child in _stars_container.get_children():
			if child and is_instance_valid(child):
				child.queue_free()
	
	_log_info('ProceduralStarBackground cleaned up')

# ADD EXIT TREE HANDLER
func _exit_tree():
	cleanup()

# Override _input to ensure events pass through
func _input(event):
	if event is InputEventMouse:
		# Simply let events pass through
		pass
