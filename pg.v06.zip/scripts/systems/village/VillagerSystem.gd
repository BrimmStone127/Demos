class_name VillagerSystem
extends Node

## Renders village members as colored squares and runs their basic needs AI.
## Visual nodes are added directly to map_container (same approach as HarvesterManager).
## Coordinates are converted via tile_manager.to_global() -> map_container.to_local().

const LOG_TAG := "VILLAGER_SYSTEM"

const MOVE_SPEED := 90.0
const ELEVATION_SPEED_SCALE := 0.08  # speed fraction lost per elevation layer difference
const MAX_TRAVERSABLE_LAYERS := 2    # elevation layer difference above this blocks movement
const PATH_SPEED_BONUS := 0.50       # 50% speed boost on established paths
const PATH_SPEED_THRESHOLD := 5      # traversal count needed for speed bonus

const HUNGER_DECAY := 0.001   # ~1000s to deplete from full (was 0.002)
const THIRST_DECAY := 0.002   # ~500s to deplete from full (was 0.003)
const REST_DECAY := 0.002     # slightly slower tiredness (was 0.003)
const REST_RECOVERY := 0.012

const GATHER_TIME := 3.0
const SLEEP_THRESHOLD := 0.25
const NEED_THRESHOLD := 0.50
const RESOURCE_RESTORE := 0.30  # smaller meals to stretch storage with longer path trips (was 0.40)

const WANDER_RADIUS := 80.0    # pixels around camp to wander
const WANDER_CHANCE := 0.3     # probability per idle check of starting a wander
const WANDER_CHECK_INTERVAL := 2.0  # seconds between idle wander decisions

const FIREWOOD_DECAY := 0.005          # how fast the fire burns through wood
const FOOD_SPOIL_RATE := 0.001         # stored food spoils slowly
const WATER_USE_RATE := 0.004          # how fast stored water is consumed (was 0.008)
const FIREWOOD_STORE_AMOUNT := 0.25    # how much one firewood trip adds (was 0.15)
const FOOD_STORE_AMOUNT := 0.50        # food deposited per foraging trip (was 0.30)
const WATER_STORE_AMOUNT := 0.60       # water deposited per water trip (was 0.40)
const FIREWOOD_LOW := 0.30             # below this, villagers prioritize firewood
const FIREWOOD_CRITICAL := 0.10        # below this, rest recovery is halved
const FOOD_STORE_LOW := 0.35           # below this, send villagers to gather food (was 0.50)
const WATER_STORE_LOW := 0.30          # below this, send a villager to fetch water (was 0.40)
const REST_RECOVERY_COLD := 0.006      # rest recovery when fire is nearly out

const NEEDS_DELTA_CAP := 0.10              # cap effective delta for needs decay (~10fps equivalent)
const DEHYDRATION_DAMAGE_INTERVAL := 20.0  # seconds at zero thirst before damage tick
const STARVATION_DAMAGE_INTERVAL := 45.0   # seconds at zero hunger before damage tick
const DEHYDRATION_DAMAGE := 0.15           # health lost per dehydration tick (~140s to die)
const STARVATION_DAMAGE := 0.08            # health lost per starvation tick (~9-10 min to die)

const VILLAGER_SCALE := 0.45       # opossum sprite scale (160px tile → ~72px display)
const VILLAGER_SPRITE_OFFSET_Y := -60.0  # empirical Y offset to align sprite with path lines
const ANIM_FPS := 4.0              # animation frames per second
const ANIM_FRAME_COUNT := 4        # R1_C0 through R1_C3
const ANIM_ATLAS_ROW := 1          # row 1 in tileset

## Base max villagers per village assigned to the same resource task simultaneously.
## Scales with population: base + 1 per 4 adults beyond the first 4.
const BASE_GATHERERS_PER_RESOURCE := 2
const GATHERERS_SCALE_PER_ADULTS := 4  # +1 gatherer slot per this many additional adults

const VILLAGER_Z := 3150  # below tree sprites (3200) but above terrain
const RESOURCE_Z := 3250

## LOD culling — villages beyond this distance (in container coords) run headless
const VILLAGE_RENDER_DISTANCE := 8000.0  # ~50 tiles at 160px
## Max villagers to do full AI update per frame (rest get needs-only tick)
## How often to recheck which villages are near camera (in frames)
const LOD_CHECK_INTERVAL := 30

## Simulation LOD: villages beyond this distance use aggregate simulation
## (one calc per village per tick instead of per-villager AI).
## Matches render distance — off-screen villages don't benefit from individual AI.
const SIM_LOD_DISTANCE := 8200.0  # just beyond VILLAGE_RENDER_DISTANCE to avoid flicker
## How many frames between aggregate sim updates for distant villages
const AGGREGATE_SIM_INTERVAL := 10

const STATE_IDLE := 0
const STATE_MOVING := 1
const STATE_GATHERING := 2
const STATE_RETURNING := 3
const STATE_SLEEPING := 4
const STATE_WANDERING := 5
const STATE_SCOUTING := 6

## Exploration constants
const SCOUT_RADIUS := 1200.0      # pixels — how far scouts range from camp (~7.5 tiles)
const SCOUT_RADIUS_URGENT := 3200.0  # pixels — range when food is critical (~20 tiles)
const SCOUT_CHANCE := 0.25        # probability per idle check of starting a scout trip
const SCOUT_DISCOVERY_RADIUS := 5 # grid tiles — how close to a resource to "discover" it
const SCOUT_COOLDOWN := 5.0       # seconds between scout decisions

class VillagerData:
	var person
	var is_player: bool = false
	var village_id: String = ""
	var container_pos: Vector2 = Vector2.ZERO
	var target_pos: Vector2 = Vector2.ZERO
	var target_grid: Vector2i = Vector2i.ZERO
	var state: int = 0
	var hunger: float = 0.7
	var thirst: float = 0.7
	var rest: float = 1.0
	var gather_timer: float = 0.0
	var wander_timer: float = 0.0
	var metabolism: float = 1.0  # per-villager decay rate multiplier
	var carrying: String = ""
	var anim_time: float = 0.0
	var dehydration_timer: float = 0.0  # seconds at thirst == 0
	var starvation_timer: float = 0.0   # seconds at hunger == 0
	var scout_timer: float = 0.0        # cooldown between scout decisions
	var node: Sprite2D = null
	var current_path: Array[Vector2i] = []       # Waypoints from pathfinder
	var path_index: int = 0                       # Current waypoint index
	var path_target_container: Vector2 = Vector2.ZERO  # Container pos of current waypoint

signal villager_clicked(villager: VillagerData)
signal villager_died(village_id: String, person_name: String)

var planet_map_system = null  # PlanetMapSystem
var map_container: Node2D = null

var _camp_positions: Dictionary = {}
var _water_positions: Dictionary = {}
var _berry_positions: Dictionary = {}
var _firewood_positions: Dictionary = {}       # village_id -> container Vector2
var _firewood_grid_positions: Dictionary = {}  # village_id -> grid Vector2i
var _camp_grid_positions: Dictionary = {}      # village_id -> grid Vector2i
var _water_grid_positions: Dictionary = {}     # village_id -> grid Vector2i
var _berry_grid_positions: Dictionary = {}     # village_id -> grid Vector2i
var _villages_by_id: Dictionary = {}  # village_id -> VillageInstance
var _villagers: Array = []
var _gatherer_counts: Dictionary = {}  # village_id -> { resource -> count }
var _dead_this_frame: Dictionary = {}  # VillagerData -> true for O(1) lookup
var _visited_tiles: Dictionary = {}  # village_id -> Dictionary(Vector2i -> true)
var _visit_frame_counter: int = 0
const VISIT_SAMPLE_INTERVAL := 10  # Record position every N frames
const MAX_VISITED_TILES_PER_VILLAGE := 2000  # Cap to prevent unbounded memory growth

## LOD state
var _visible_villages: Dictionary = {}  # village_id -> true (villages with sprites)
var _lod_frame_counter: int = LOD_CHECK_INTERVAL  # trigger LOD check on first frame

## Current season food modifier (set by VillageManager each monthly tick)
var current_season_food_mod: float = 1.0
var _ai_batch_offset: int = 0  # round-robin offset for batched AI updates
var _villagers_by_village: Dictionary = {}  # village_id -> Array[VillagerData] for fast LOD lookups

## Per-resource-position gatherer tracking for distributed foraging.
## Key: Vector2i grid pos -> int count of villagers currently targeting it.
var _pos_gatherer_counts: Dictionary = {}

## Cached grid position per villager to avoid redundant _container_to_grid calls.
## Updated when villager moves significantly (> 1 tile).
var _cached_grid: Dictionary = {}  # VillagerData -> Vector2i
var _cached_grid_pos: Dictionary = {}  # VillagerData -> Vector2 (container pos at cache time)

## Berry search result cache: village_id -> {"pos": Vector2i, "time": float}
var _berry_search_cache: Dictionary = {}
const BERRY_CACHE_TTL := 15.0  # seconds before re-searching (spiral is O(R^2), don't repeat often)

## Villages using aggregate simulation (far from camera)
var _aggregate_villages: Dictionary = {}  # village_id -> true
var _aggregate_frame_counter: int = 0

## Cache: grid Vector2i -> container Vector2 to avoid repeated _grid_to_container calls
var _grid_to_container_cache: Dictionary = {}

## Terrain-aware pathfinding
var _pathfinder: TerrainPathfinder = null
var _path_caches: Dictionary = {}  # village_id -> VillagePathCache

## Cached max gatherer cap per village — invalidated on population change
var _max_gatherers_cache: Dictionary = {}  # village_id -> int


## Register a village and spawn its villagers + resource tiles.
## Deflated villages register positions only — no VillagerData created.
func setup_village(village: VillageInstance) -> void:
	if not map_container:
		GameLog.warn(LOG_TAG, "setup_village called before map_container set — skipping %s" % village.village_id)
		return

	GameLog.debug(LOG_TAG, "setup_village: %s (deflated: %s)" % [village.village_id, str(village.is_deflated)])
	var camp  := _grid_to_container(village.camp_position)
	var water := _grid_to_container(village.water_pos)
	var berry := _grid_to_container(village.berry_pos)
	var wood  := _grid_to_container(village.firewood_pos)

	GameLog.debug(LOG_TAG, "Container positions — camp: %s  water: %s  berry: %s  wood: %s" % [
		str(camp), str(water), str(berry), str(wood)
	])

	_camp_positions[village.village_id]          = camp
	_water_positions[village.village_id]         = water
	_berry_positions[village.village_id]         = berry
	_firewood_positions[village.village_id]      = wood
	_firewood_grid_positions[village.village_id] = village.firewood_pos
	_camp_grid_positions[village.village_id]     = village.camp_position
	_water_grid_positions[village.village_id]    = village.water_pos
	_berry_grid_positions[village.village_id]    = village.berry_pos
	_villages_by_id[village.village_id]          = village

	# Initialize pathfinder (shared across all villages)
	if not _pathfinder and planet_map_system:
		_pathfinder = TerrainPathfinder.new(planet_map_system)
	if _pathfinder and not _path_caches.has(village.village_id):
		_path_caches[village.village_id] = VillagePathCache.new(_pathfinder)

	# Seed resource memory with initial known positions
	if village.resource_memory:
		village.resource_memory.camp_position = village.camp_position
		village.resource_memory.set_target(VillageResourceMemory.WATER, village.water_pos)
		village.resource_memory.set_target(VillageResourceMemory.BERRY, village.berry_pos)
		village.resource_memory.set_target(VillageResourceMemory.FIREWOOD, village.firewood_pos)

	# Deflated villages: register positions only, no VillagerData
	if village.is_deflated:
		if not _villagers_by_village.has(village.village_id):
			_villagers_by_village[village.village_id] = []
		# Start as aggregate — no per-frame cost
		_aggregate_villages[village.village_id] = true
		# Seed territory so overlay draws camp + resource paths at low LOD
		_seed_visited_tiles(village)
		GameLog.debug(LOG_TAG, "Village %s: deflated, positions registered only (pop: %d)" % [village.village_id, village.get_population()])
		return

	# Mark visible initially — LOD check will despawn if off-screen
	_visible_villages[village.village_id] = true

	# Seed multiple nearby resources so forager distribution has targets to spread across
	_seed_nearby_resources(village)

	# Seed territory with known resource positions and path between them
	_seed_visited_tiles(village)

	for person in village.individuals:
		_create_villager(person, village.is_player_village, village.village_id, camp, village.camp_position)

	GameLog.debug(LOG_TAG, "Village %s: %d villagers spawned" % [village.village_id, village.individuals.size()])


## Sync villager runtime needs back to PersonInstance for persistence.
## Only syncs inflated villages (deflated have no VillagerData).
func sync_needs_to_persons() -> void:
	for v_data in _villagers:
		var vd: VillagerData = v_data as VillagerData
		if vd and vd.person:
			vd.person.hunger = vd.hunger
			vd.person.thirst = vd.thirst
			vd.person.rest = vd.rest
			vd.person.metabolism = vd.metabolism


## Convert grid position to map_container-local position.
## Mirrors HarvesterManager._compute_grid_to_container().
func _grid_to_container(grid_pos: Vector2i) -> Vector2:
	if not planet_map_system or not planet_map_system.tile_manager or not map_container:
		return Vector2.ZERO

	var elevation_raw: float = planet_map_system.get_elevation_at(grid_pos)
	var tile_layer: int = PlanetMapTileConfig.get_render_layer(elevation_raw)

	var local_pos: Vector2
	var sm = planet_map_system.selection_manager
	if sm and tile_layer < sm.layer_tilemaps.size():
		var tm: TileMap = sm.layer_tilemaps[tile_layer]
		if tm and is_instance_valid(tm):
			local_pos = tm.map_to_local(grid_pos) + tm.position
		else:
			# Fallback — WILL produce offset vs map_to_local (see gotcha in MEMORY.md)
			local_pos = PlanetMapCoordinates.grid_to_world(grid_pos)
			local_pos.y -= float(tile_layer) * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET
	else:
		# Fallback — selection_manager not ready, use tile_manager directly
		var tm: TileMap = planet_map_system.tile_manager.ensure_layer_tilemap(tile_layer)
		if tm and is_instance_valid(tm):
			local_pos = tm.map_to_local(grid_pos) + tm.position
		else:
			local_pos = PlanetMapCoordinates.grid_to_world(grid_pos)
			local_pos.y -= float(tile_layer) * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET

	var world_pos: Vector2 = planet_map_system.tile_manager.to_global(local_pos)
	return map_container.to_local(world_pos)


func _add_resource_diamond(pos: Vector2, color: Color) -> void:
	var poly := Polygon2D.new()
	poly.color = color
	var hw := PlanetMapTileConfig.TILE_SIZE.x / 2.0
	var hh := PlanetMapTileConfig.TILE_SIZE.y / 2.0
	poly.polygon = PackedVector2Array([
		Vector2(0.0, -hh), Vector2(hw, 0.0),
		Vector2(0.0,  hh), Vector2(-hw, 0.0),
	])
	poly.position = pos
	poly.z_index = RESOURCE_Z
	map_container.add_child(poly)


func _create_villager(person, is_player: bool, village_id: String, camp_pos: Vector2, camp_grid: Vector2i) -> void:
	var v := VillagerData.new()
	v.person = person
	v.is_player = is_player
	v.village_id = village_id
	v.container_pos = camp_pos
	v.target_pos    = camp_pos
	v.target_grid   = camp_grid
	# Use persisted needs if available (from save/load), otherwise randomize
	if person.metabolism != 1.0 or person.hunger != 0.7 or person.thirst != 0.7 or person.rest != 1.0:
		v.hunger = person.hunger
		v.thirst = person.thirst
		v.rest = person.rest
		v.metabolism = person.metabolism
	else:
		v.hunger = randf_range(0.3, 1.0)
		v.thirst = randf_range(0.3, 1.0)
		v.rest = randf_range(0.5, 1.0)
		v.metabolism = randf_range(0.75, 1.25)
	v.wander_timer = randf_range(0.0, WANDER_CHECK_INTERVAL)
	v.scout_timer = randf_range(0.0, SCOUT_COOLDOWN)

	# Create sprite — LOD will despawn if village is off-screen
	var sprite := Sprite2D.new()
	sprite.texture = PlanetMapTileConfig.TILESET_TEXTURE
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.region_enabled = true
	sprite.centered = true
	# Correct for tileset tile height (160) vs isometric diamond height (80).
	# centered=true puts sprite center at (80,80) in texture, but the diamond
	# center is at (80,40). Shift texture up by half the difference.
	sprite.offset.y = VILLAGER_SPRITE_OFFSET_Y
	sprite.scale = Vector2(VILLAGER_SCALE, VILLAGER_SCALE)
	sprite.position = camp_pos
	sprite.z_index = VILLAGER_Z
	var tile_size := PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	var inset := PlanetMapTileConfig.TILESET_REGION_INSET
	sprite.region_rect = Rect2i(Vector2i(0, ANIM_ATLAS_ROW) * tile_size + inset, tile_size - inset * 2)
	map_container.add_child(sprite)
	v.node = sprite
	_villagers.append(v)
	# Index for fast LOD lookup
	if not _villagers_by_village.has(village_id):
		_villagers_by_village[village_id] = []
	_villagers_by_village[village_id].append(v)


func _process(delta: float) -> void:
	if _villagers.is_empty():
		return

	# Periodically update which villages are near camera
	_lod_frame_counter += 1
	if _lod_frame_counter >= LOD_CHECK_INTERVAL:
		_lod_frame_counter = 0
		_update_village_lod()

	# Tick village-level storage decay (capped delta so stores survive high time scales)
	var storage_delta := minf(delta, NEEDS_DELTA_CAP)
	_aggregate_frame_counter += 1
	var do_aggregate := (_aggregate_frame_counter % AGGREGATE_SIM_INTERVAL == 0)

	for village_id in _villages_by_id:
		var village: VillageInstance = _villages_by_id[village_id]
		village.firewood_stored = maxf(0.0, village.firewood_stored - FIREWOOD_DECAY  * storage_delta)
		village.food_stored     = maxf(0.0, village.food_stored     - FOOD_SPOIL_RATE * storage_delta)
		village.water_stored    = maxf(0.0, village.water_stored    - WATER_USE_RATE  * storage_delta)
		# Only update smoke for visible villages, throttled to every 10 frames
		if _lod_frame_counter == 0 and _visible_villages.has(village_id) and planet_map_system and _camp_grid_positions.has(village_id):
			planet_map_system.update_longhouse_smoke(_camp_grid_positions[village_id], village.firewood_stored)
		# Aggregate sim for distant villages — skip individual AI entirely
		if do_aggregate and _aggregate_villages.has(village_id):
			_simulate_aggregate(village, storage_delta * AGGREGATE_SIM_INTERVAL)

	_visit_frame_counter += 1

	# Periodically clean up stale routes no longer used by foragers
	# Only clean visible villages — headless AI doesn't touch caches so routes
	# would wrongly appear stale while the village is still active off-screen
	if _visit_frame_counter % 50 == 0:
		for cache_id in _path_caches:
			if not _visible_villages.has(cache_id):
				continue
			var cache: VillagePathCache = _path_caches[cache_id]
			cache.cleanup_stale_routes(_visit_frame_counter)

	# Process villagers per-village — skip entire aggregate villages without iterating
	for village_id in _villagers_by_village:
		# Skip aggregate villages entirely — no per-villager iteration
		if _aggregate_villages.has(village_id):
			continue

		var village: VillageInstance = _villages_by_id.get(village_id, null)
		var is_visible: bool = _visible_villages.has(village_id)
		var villager_list: Array = _villagers_by_village[village_id]

		for v in villager_list:
			# Needs always update (capped delta keeps it cheap)
			_update_needs(v, delta, village)
			if _dead_this_frame.has(v):
				continue

			# Gathering state machine always ticks (deposits resources)
			_update_gathering(v, delta, village)

			# Full AI + movement only for visible villages
			if is_visible:
				_update_ai(v, delta, village)
				_update_movement(v, delta)
				_update_visual(v)
				_update_anim(v, delta)
			else:
				_update_ai_headless(v, delta, village)

	# Remove villagers who died this frame — batch filter
	if not _dead_this_frame.is_empty():
		var new_villagers: Array = []
		for v in _villagers:
			if not _dead_this_frame.has(v):
				new_villagers.append(v)
		_villagers = new_villagers
		_dead_this_frame.clear()


func _update_needs(v: VillagerData, delta: float, village) -> void:
	# Cap effective delta so needs don't drain faster than gatherers can resupply at high time scales
	var needs_delta := minf(delta, NEEDS_DELTA_CAP)

	if v.state == STATE_SLEEPING:
		var recovery := REST_RECOVERY
		if village and village.firewood_stored < FIREWOOD_CRITICAL:
			recovery = REST_RECOVERY_COLD  # cold longhouse — poor sleep
		v.rest = minf(1.0, v.rest + recovery * needs_delta)
		return
	v.hunger = maxf(0.0, v.hunger - HUNGER_DECAY * v.metabolism * needs_delta)
	v.thirst = maxf(0.0, v.thirst - THIRST_DECAY * v.metabolism * needs_delta)
	v.rest   = maxf(0.0, v.rest   - REST_DECAY   * v.metabolism * needs_delta)

	# Eat from longhouse storage when hungry — no travel needed
	if village and v.hunger < NEED_THRESHOLD and village.food_stored > 0.0:
		var eaten := minf(RESOURCE_RESTORE, village.food_stored)
		v.hunger = minf(1.0, v.hunger + eaten)
		village.food_stored -= eaten

	# Drink from longhouse water storage — no travel needed
	if village and v.thirst < NEED_THRESHOLD and village.water_stored > 0.0:
		var drunk := minf(RESOURCE_RESTORE, village.water_stored)
		v.thirst = minf(1.0, v.thirst + drunk)
		village.water_stored -= drunk

	# Dehydration damage
	if v.thirst <= 0.0:
		v.dehydration_timer += needs_delta
		if v.dehydration_timer >= DEHYDRATION_DAMAGE_INTERVAL:
			v.dehydration_timer = 0.0
			v.person.health = maxf(0.0, v.person.health - DEHYDRATION_DAMAGE)
			if not v.person.is_alive():
				_kill_villager(v, village, "dehydration")
				return
	else:
		v.dehydration_timer = 0.0

	# Starvation damage
	if v.hunger <= 0.0:
		v.starvation_timer += needs_delta
		if v.starvation_timer >= STARVATION_DAMAGE_INTERVAL:
			v.starvation_timer = 0.0
			v.person.health = maxf(0.0, v.person.health - STARVATION_DAMAGE)
			if not v.person.is_alive():
				_kill_villager(v, village, "starvation")
				return
	else:
		v.starvation_timer = 0.0


func _update_gathering(v: VillagerData, delta: float, village) -> void:
	if v.state != STATE_GATHERING:
		return
	v.gather_timer -= delta
	if v.gather_timer > 0.0:
		return
	match v.carrying:
		"food":
			# Notify PlanetMapSystem to decrement bush supply; only deposit if bush had berries
			var berry_yielded := true
			var valid_target := v.target_grid.x >= 0 and v.target_grid.y >= 0
			if planet_map_system and valid_target:
				berry_yielded = planet_map_system.collect_berry_at(v.target_grid)
				# Retarget whenever current bush is depleted — either already was, or just stripped
				if not berry_yielded or planet_map_system.is_berry_depleted(v.target_grid):
					if village and village.resource_memory:
						village.resource_memory.remove_known(VillageResourceMemory.BERRY, v.target_grid)
					var next_grid: Vector2i = _find_berry_cached(v.village_id, _get_camp_grid_for(v))
					if next_grid != Vector2i(-1, -1):
						_berry_grid_positions[v.village_id] = next_grid
						_berry_positions[v.village_id] = _get_resource_container_pos(next_grid)
						if village:
							village.berry_pos = next_grid
			if village and berry_yielded:
				var food_mod := _get_skill_modifier(v, "foraging")
				var food_yield := FOOD_STORE_AMOUNT * (0.7 + 0.6 * food_mod) * current_season_food_mod
				village.food_stored = minf(1.0, village.food_stored + food_yield)
		"water":
			if village:
				village.water_stored = minf(1.0, village.water_stored + WATER_STORE_AMOUNT)
		"firewood":
			if village:
				village.firewood_stored = minf(1.0, village.firewood_stored + FIREWOOD_STORE_AMOUNT)
				# Track firewood trip distance for relocation pressure
				if village.active_site and v.target_grid != Vector2i(-1, -1):
					var trip_dist := Vector2(v.target_grid).distance_to(Vector2(village.camp_position))
					village.active_site.firewood_distance_sum += trip_dist
					village.active_site.firewood_trip_count += 1
				# Notify PlanetMapSystem of the collection; update target if tree depleted
				if planet_map_system and _firewood_grid_positions.has(v.village_id):
					var fw_grid: Vector2i = _firewood_grid_positions[v.village_id]
					var next_grid: Vector2i = planet_map_system.collect_firewood_at(fw_grid, village.camp_position)
					if next_grid != fw_grid and next_grid != Vector2i(-1, -1):
						# Tree depleted — remove from known, add and target new one
						if village.resource_memory:
							village.resource_memory.remove_known(VillageResourceMemory.FIREWOOD, fw_grid)
						_firewood_grid_positions[v.village_id] = next_grid
						_firewood_positions[v.village_id] = _get_resource_container_pos(next_grid)
						village.firewood_pos = next_grid
	if v.carrying != "":
		_dec_gatherers(v.village_id, v.carrying)
		_dec_pos_gatherers(v.target_grid)
	var resource_grid := v.target_grid  # Save before overwriting
	v.carrying = ""
	v.target_grid = _get_camp_grid_for(v)
	v.state = STATE_RETURNING
	# Reuse outbound path reversed — same trail, no new A* computation
	_request_return_path(v, resource_grid)


## O(1) gatherer count lookup — maintained by _inc/_dec helpers.
func _count_gatherers(village_id: String, resource: String) -> int:
	return _gatherer_counts.get(village_id, {}).get(resource, 0)

func _inc_gatherers(village_id: String, resource: String) -> void:
	if not _gatherer_counts.has(village_id):
		_gatherer_counts[village_id] = {}
	_gatherer_counts[village_id][resource] = _gatherer_counts[village_id].get(resource, 0) + 1

func _dec_gatherers(village_id: String, resource: String) -> void:
	if not _gatherer_counts.has(village_id):
		return
	_gatherer_counts[village_id][resource] = maxi(0, _gatherer_counts[village_id].get(resource, 0) - 1)


## Dynamic gatherer cap — scales with village adult population.
## Result cached; invalidated on birth/death via _invalidate_gatherer_cache.
func _max_gatherers_for(village_id: String) -> int:
	if _max_gatherers_cache.has(village_id):
		return _max_gatherers_cache[village_id]
	var village: VillageInstance = _villages_by_id.get(village_id, null)
	if not village:
		return BASE_GATHERERS_PER_RESOURCE
	var adults := village.get_adult_count()
	var extra := maxi(0, adults - 4) / GATHERERS_SCALE_PER_ADULTS
	var result := BASE_GATHERERS_PER_RESOURCE + extra
	_max_gatherers_cache[village_id] = result
	return result


func _kill_villager(v: VillagerData, village, cause: String) -> void:
	GameLog.debug(LOG_TAG, "Villager %s of %s died of %s" % [v.person.name, v.village_id, cause])
	if village:
		village.log_event("death", "%s died of %s" % [v.person.name, cause])
	if v.node and is_instance_valid(v.node):
		v.node.queue_free()
	if v.carrying != "":
		_dec_gatherers(v.village_id, v.carrying)
		_dec_pos_gatherers(v.target_grid)
	if v.state == STATE_SCOUTING:
		_dec_gatherers(v.village_id, "scout")
	# Clean up cached grid data
	_cached_grid.erase(v)
	_cached_grid_pos.erase(v)
	if village:
		village.individuals.erase(v.person)
	villager_died.emit(v.village_id, v.person.name)
	_dead_this_frame[v] = true
	_max_gatherers_cache.erase(v.village_id)
	# Clean up village index
	if _villagers_by_village.has(v.village_id):
		_villagers_by_village[v.village_id].erase(v)


func _update_ai(v: VillagerData, delta: float, village) -> void:
	match v.state:
		STATE_MOVING, STATE_GATHERING:
			return
		STATE_SLEEPING:
			if v.rest >= 0.95:
				v.state = STATE_IDLE
			return
		STATE_RETURNING:
			if v.container_pos.distance_to(_get_camp_for(v)) < 3.0:
				v.state = STATE_IDLE
			return
		STATE_WANDERING:
			if v.container_pos.distance_to(v.target_pos) < 2.0:
				_check_scout_discoveries(v, village)
				v.state = STATE_IDLE
			return
		STATE_SCOUTING:
			if v.container_pos.distance_to(v.target_pos) < 2.0:
				_check_scout_discoveries(v, village)
				_dec_gatherers(v.village_id, "scout")
				v.state = STATE_IDLE
			return

	if v.rest < SLEEP_THRESHOLD:
		v.state = STATE_SLEEPING
		return

	# Fire emergency overrides personal needs — cold kills too
	# No gatherer cap for FIREWOOD_CRITICAL; everyone pitches in
	if village and village.firewood_stored < FIREWOOD_CRITICAL:
		var fw_target := _pick_distributed_resource(v, village, VillageResourceMemory.FIREWOOD)
		if fw_target == Vector2i(-1, -1):
			fw_target = _get_firewood_grid_for(v)
		v.target_grid = fw_target
		v.carrying = "firewood"
		v.state = STATE_MOVING
		_request_path(v, _get_camp_grid_for(v), fw_target)
		_inc_gatherers(v.village_id, "firewood")
		_inc_pos_gatherers(fw_target)
		return

	# Community tasks: limit concurrent gatherers (scales with village size)
	var max_gatherers := _max_gatherers_for(v.village_id)

	if village and village.water_stored < WATER_STORE_LOW:
		if _count_gatherers(v.village_id, "water") < max_gatherers:
			v.target_grid = _get_water_grid_for(v)
			v.carrying = "water"
			v.state = STATE_MOVING
			_request_path(v, _get_camp_grid_for(v), v.target_grid)
			_inc_gatherers(v.village_id, "water")
			return

	if village and village.food_stored < FOOD_STORE_LOW:
		if _count_gatherers(v.village_id, "food") < max_gatherers:
			var target := _pick_distributed_resource(v, village, VillageResourceMemory.BERRY)
			if target != Vector2i(-1, -1):
				v.target_grid = target
				v.carrying = "food"
				v.state = STATE_MOVING
				_request_path(v, _get_camp_grid_for(v), target)
				_inc_gatherers(v.village_id, "food")
				_inc_pos_gatherers(target)
				return
			else:
				# No berries available — send limited urgent scouts (max 3 per village)
				var scout_count := _count_gatherers(v.village_id, "scout")
				if scout_count < 3:
					# Try to scout along existing path first for better range
					if _try_scout_along_path(v):
						_inc_gatherers(v.village_id, "scout")
						return
					var angle := randf() * TAU
					var dist := randf_range(SCOUT_RADIUS, SCOUT_RADIUS_URGENT)
					var camp := _get_camp_for(v)
					v.target_pos = camp + Vector2(cos(angle), sin(angle)) * dist
					v.target_grid = _container_to_grid(v.target_pos)
					v.state = STATE_SCOUTING
					_inc_gatherers(v.village_id, "scout")
					return

	if village and village.firewood_stored < FIREWOOD_LOW:
		if _count_gatherers(v.village_id, "firewood") < max_gatherers:
			var target := _pick_distributed_resource(v, village, VillageResourceMemory.FIREWOOD)
			if target != Vector2i(-1, -1):
				v.target_grid = target
				v.carrying = "firewood"
				v.state = STATE_MOVING
				_request_path(v, _get_camp_grid_for(v), target)
				_inc_gatherers(v.village_id, "firewood")
				_inc_pos_gatherers(target)
				return

	# Idle — scout for new resources or wander
	v.scout_timer -= delta
	if v.scout_timer <= 0.0:
		v.scout_timer = SCOUT_COOLDOWN
		if randf() < SCOUT_CHANCE and _count_gatherers(v.village_id, "scout") < 3:
			# Try to scout along an existing path first — extends range along established corridors
			if _try_scout_along_path(v):
				_inc_gatherers(v.village_id, "scout")
				return
			# Fallback: random direction from camp
			var angle := randf() * TAU
			var scout_range := SCOUT_RADIUS
			if village and (village.food_stored < FOOD_STORE_LOW or village.firewood_stored < FIREWOOD_LOW):
				scout_range = SCOUT_RADIUS_URGENT
			var dist := randf_range(WANDER_RADIUS, scout_range)
			var camp := _get_camp_for(v)
			v.target_pos  = camp + Vector2(cos(angle), sin(angle)) * dist
			v.target_grid = _container_to_grid(v.target_pos)
			v.state = STATE_SCOUTING
			_inc_gatherers(v.village_id, "scout")
			return

	v.wander_timer -= delta
	if v.wander_timer <= 0.0:
		v.wander_timer = WANDER_CHECK_INTERVAL
		if randf() < WANDER_CHANCE:
			var angle := randf() * TAU
			var dist := randf() * WANDER_RADIUS
			var camp := _get_camp_for(v)
			v.target_pos  = camp + Vector2(cos(angle), sin(angle)) * dist
			v.target_grid = _container_to_grid(v.target_pos)
			v.state = STATE_WANDERING


## Check if a scouting villager has found a closer resource than the village currently uses.
## Updates village resource positions when a better source is discovered.
func _check_scout_discoveries(v: VillagerData, village) -> void:
	if not planet_map_system:
		return
	var scout_grid := _container_to_grid(v.container_pos)
	var camp_grid := _get_camp_grid_for(v)

	# Check nearby tiles for resources within discovery radius
	for dx in range(-SCOUT_DISCOVERY_RADIUS, SCOUT_DISCOVERY_RADIUS + 1):
		for dy in range(-SCOUT_DISCOVERY_RADIUS, SCOUT_DISCOVERY_RADIUS + 1):
			var check := scout_grid + Vector2i(dx, dy)

			# Discover berry bush — add to known set, update target if closer
			if planet_map_system.has_berry_at(check) and not planet_map_system.is_berry_depleted(check):
				if village and village.resource_memory:
					village.resource_memory.add_known(VillageResourceMemory.BERRY, check)
				var current_berry := _get_berry_grid_for(v)
				var old_dist := Vector2(camp_grid).distance_to(Vector2(current_berry))
				var new_dist := Vector2(camp_grid).distance_to(Vector2(check))
				if new_dist < old_dist:
					_berry_grid_positions[v.village_id] = check
					_berry_positions[v.village_id] = _get_resource_container_pos(check)
					if village:
						village.berry_pos = check
					GameLog.debug(LOG_TAG, "Village %s scout discovered closer berry bush at %s (was %s)" % [
						v.village_id, str(check), str(current_berry)])
					_seed_path_to(v.village_id, camp_grid, check)

			# Discover dead tree — add to known set, update target if closer
			if planet_map_system.has_dead_tree_at(check):
				if village and village.resource_memory:
					village.resource_memory.add_known(VillageResourceMemory.FIREWOOD, check)
				var current_fw := _get_firewood_grid_for(v)
				var old_dist := Vector2(camp_grid).distance_to(Vector2(current_fw))
				var new_dist := Vector2(camp_grid).distance_to(Vector2(check))
				if new_dist < old_dist:
					_firewood_grid_positions[v.village_id] = check
					_firewood_positions[v.village_id] = _get_resource_container_pos(check)
					if village:
						village.firewood_pos = check
					GameLog.debug(LOG_TAG, "Village %s scout discovered closer firewood at %s (was %s)" % [
						v.village_id, str(check), str(current_fw)])
					_seed_path_to(v.village_id, camp_grid, check)

	# Record scouted position in trail data
	var scout_cache: VillagePathCache = _path_caches.get(v.village_id)
	if scout_cache:
		scout_cache.record_traversal(scout_grid)


## Pre-compute and cache a path between two points (used when scout discovers resources).
func _seed_path_to(village_id: String, from: Vector2i, to: Vector2i) -> void:
	var cache: VillagePathCache = _path_caches.get(village_id)
	if cache:
		cache.get_path(from, to, _visit_frame_counter)


func _update_movement(v: VillagerData, delta: float) -> void:
	if v.state != STATE_MOVING and v.state != STATE_RETURNING and v.state != STATE_WANDERING and v.state != STATE_SCOUTING:
		return

	# Determine immediate movement target (next waypoint or final target)
	var move_target: Vector2
	var has_path := v.current_path.size() > 0 and v.path_index < v.current_path.size()
	if has_path:
		move_target = v.path_target_container
	else:
		move_target = v.target_pos

	var dist := v.container_pos.distance_to(move_target)

	# Reached current waypoint?
	if dist < 2.0:
		if has_path and v.path_index < v.current_path.size() - 1:
			# Record trail traversal
			var cache: VillagePathCache = _path_caches.get(v.village_id)
			if cache:
				cache.record_traversal(v.current_path[v.path_index])
			# Advance to next waypoint
			v.path_index += 1
			v.path_target_container = _get_resource_container_pos(v.current_path[v.path_index])
			return
		else:
			# Reached final waypoint or no path — check if at actual target
			v.container_pos = move_target
			v.current_path = []
			# If not at final target yet, keep moving straight (shared route may
			# end a few tiles from actual destination)
			if v.container_pos.distance_to(v.target_pos) > 2.0:
				return  # Continue straight-line to target_pos
			# At final target — complete movement
			if v.target_grid != Vector2i.ZERO:
				var cache: VillagePathCache = _path_caches.get(v.village_id)
				if cache:
					cache.record_traversal(v.target_grid)
			if v.state == STATE_MOVING:
				v.state = STATE_GATHERING
				var skill_mod := _get_skill_modifier(v, _skill_for_carrying(v.carrying))
				v.gather_timer = GATHER_TIME * (1.0 - 0.5 * skill_mod)
			elif v.state == STATE_SCOUTING:
				_dec_gatherers(v.village_id, "scout")
				v.state = STATE_IDLE
			elif v.state == STATE_RETURNING:
				v.state = STATE_IDLE
			else:
				v.state = STATE_IDLE
			return

	# Elevation-based speed adjustment
	var speed := MOVE_SPEED
	if planet_map_system:
		var current_grid := _get_cached_grid(v)

		# Only check elevation barriers for straight-line movement (no path).
		# Pathfound routes already validated every step in A* — the pixel-space
		# grid lookup here can hit neighboring cells and falsely block movement.
		# Elevation speed penalty — steeper = slower, no impassable barrier
		var next_grid: Vector2i
		if has_path:
			next_grid = v.current_path[v.path_index]
		else:
			var step_offset: Vector2 = (move_target - v.container_pos).normalized() * PlanetMapTileConfig.TILE_SIZE.x * 0.5
			next_grid = _container_to_grid(v.container_pos + step_offset)
		var current_layer: int = PlanetMapTileConfig.get_render_layer(planet_map_system.get_elevation_at(current_grid))
		var next_layer: int = PlanetMapTileConfig.get_render_layer(planet_map_system.get_elevation_at(next_grid))
		var layer_delta: int = abs(next_layer - current_layer)
		if layer_delta > 0:
			speed = MOVE_SPEED * maxf(0.1, 1.0 - float(layer_delta) * ELEVATION_SPEED_SCALE)

		# Speed boost on established paths
		var path_cache: VillagePathCache = _path_caches.get(v.village_id)
		if path_cache and path_cache.get_traversal_count(current_grid) >= PATH_SPEED_THRESHOLD:
			speed *= (1.0 + PATH_SPEED_BONUS)

	v.container_pos += (move_target - v.container_pos).normalized() * minf(speed * delta, dist)

	# Scouts check for resources while traveling (not just at destination)
	if v.state == STATE_SCOUTING:
		var village = _villages_by_id.get(v.village_id)
		if village:
			_check_scout_discoveries(v, village)


func _update_visual(v: VillagerData) -> void:
	if not v.node or not is_instance_valid(v.node):
		return
	v.node.visible = v.state != STATE_SLEEPING
	v.node.position = v.container_pos


func _update_anim(v: VillagerData, delta: float) -> void:
	if not v.node or not is_instance_valid(v.node):
		return
	# Flip sprite to face movement direction
	var dir := v.target_pos - v.container_pos
	if dir.x != 0.0:
		v.node.flip_h = dir.x < 0.0

	# Pause animation when sleeping or idle (not moving toward a target)
	var moving := v.container_pos.distance_squared_to(v.target_pos) > 4.0
	if not moving:
		return
	v.anim_time += delta
	var frame := int(v.anim_time * ANIM_FPS) % ANIM_FRAME_COUNT
	var tile_size := PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	var inset := PlanetMapTileConfig.TILESET_REGION_INSET
	v.node.region_rect = Rect2i(Vector2i(frame, ANIM_ATLAS_ROW) * tile_size + inset, tile_size - inset * 2)


## Aggregate simulation for distant villages — one calculation per village per interval.
## Approximates resource gathering without per-villager AI/movement.
## Also drains storage for per-person consumption so deflated villages mirror visible behavior.
func _simulate_aggregate(village: VillageInstance, effective_delta: float) -> void:
	var adults := village.get_adult_count()
	if adults <= 0:
		return

	# Per-person consumption — mirrors _update_needs eating from storage.
	# Each adult eats RESOURCE_RESTORE when hunger drops below NEED_THRESHOLD.
	# Average time between meals: (1.0 - NEED_THRESHOLD) / HUNGER_DECAY = 500s at 0.001/s
	# So each adult eats RESOURCE_RESTORE / 500 per second of food.
	var meal_interval := (1.0 - NEED_THRESHOLD) / HUNGER_DECAY  # ~500s
	var food_drain := float(adults) * RESOURCE_RESTORE / meal_interval * effective_delta
	var water_drain := float(adults) * RESOURCE_RESTORE / ((1.0 - NEED_THRESHOLD) / THIRST_DECAY) * effective_delta
	village.food_stored = maxf(0.0, village.food_stored - food_drain)
	village.water_stored = maxf(0.0, village.water_stored - water_drain)

	# Approximate: ~30% of adults gathering at any time, each producing at average rate
	var active_gatherers := maxi(1, int(adults * 0.3))

	# Food gathering — approximate yield per gatherer per interval
	if village.food_stored < FOOD_STORE_LOW:
		var food_gatherers := mini(active_gatherers, _max_gatherers_for(village.village_id))
		var avg_skill := 0.3  # approximate average skill modifier
		var food_per := FOOD_STORE_AMOUNT * (0.7 + 0.6 * avg_skill) * current_season_food_mod
		# Each gatherer completes ~1 trip per GATHER_TIME * 3 (travel + gather + return)
		var trips := effective_delta / (GATHER_TIME * 3.0)
		village.food_stored = minf(1.0, village.food_stored + food_per * food_gatherers * trips)

	# Water gathering
	if village.water_stored < WATER_STORE_LOW:
		var water_gatherers := mini(active_gatherers, _max_gatherers_for(village.village_id))
		var trips := effective_delta / (GATHER_TIME * 2.5)
		village.water_stored = minf(1.0, village.water_stored + WATER_STORE_AMOUNT * water_gatherers * trips)

	# Firewood gathering
	if village.firewood_stored < FIREWOOD_LOW:
		var fw_gatherers := mini(active_gatherers, _max_gatherers_for(village.village_id))
		var trips := effective_delta / (GATHER_TIME * 4.0)  # firewood trips are longer
		village.firewood_stored = minf(1.0, village.firewood_stored + FIREWOOD_STORE_AMOUNT * fw_gatherers * trips)


## Headless AI — advances timers and state transitions without movement calculations.
## Used for off-screen villagers beyond render distance.
func _update_ai_headless(v: VillagerData, delta: float, village) -> void:
	match v.state:
		STATE_SLEEPING:
			if v.rest >= 0.95:
				v.state = STATE_IDLE
		STATE_IDLE:
			# Simplified task assignment — no visual positioning needed
			if v.rest < SLEEP_THRESHOLD:
				v.state = STATE_SLEEPING
				return
			if village and village.firewood_stored < FIREWOOD_CRITICAL:
				v.target_grid = _get_firewood_grid_for(v)
				v.carrying = "firewood"
				v.state = STATE_GATHERING
				var skill_mod := _get_skill_modifier(v, "shelter_building")
				v.gather_timer = GATHER_TIME * (1.0 - 0.5 * skill_mod)
				_inc_gatherers(v.village_id, "firewood")
				return
			var max_g := _max_gatherers_for(v.village_id)
			if village and village.water_stored < WATER_STORE_LOW and _count_gatherers(v.village_id, "water") < max_g:
				v.target_grid = _get_water_grid_for(v)
				v.carrying = "water"
				v.state = STATE_GATHERING
				v.gather_timer = GATHER_TIME
				_inc_gatherers(v.village_id, "water")
				return
			if village and village.food_stored < FOOD_STORE_LOW and _count_gatherers(v.village_id, "food") < max_g:
				# Use distributed picker like visible AI — discovers new berries
				var target := _pick_distributed_resource(v, village, VillageResourceMemory.BERRY)
				if target != Vector2i(-1, -1):
					v.target_grid = target
				else:
					# Trigger cached search for new berry sources
					var camp_grid := _get_camp_grid_for(v)
					var found := _find_berry_cached(v.village_id, camp_grid)
					v.target_grid = found if found != Vector2i(-1, -1) else _get_berry_grid_for(v)
				v.carrying = "food"
				v.state = STATE_GATHERING
				var skill_mod := _get_skill_modifier(v, "foraging")
				v.gather_timer = GATHER_TIME * (1.0 - 0.5 * skill_mod)
				_inc_gatherers(v.village_id, "food")
				return
			if village and village.firewood_stored < FIREWOOD_LOW and _count_gatherers(v.village_id, "firewood") < max_g:
				v.target_grid = _get_firewood_grid_for(v)
				v.carrying = "firewood"
				v.state = STATE_GATHERING
				var skill_mod := _get_skill_modifier(v, "shelter_building")
				v.gather_timer = GATHER_TIME * (1.0 - 0.5 * skill_mod)
				_inc_gatherers(v.village_id, "firewood")
				return
		STATE_MOVING, STATE_RETURNING, STATE_WANDERING, STATE_SCOUTING:
			# Teleport to target instead of stepping — skip elevation/pathfinding
			var was_scouting := (v.state == STATE_SCOUTING)
			v.container_pos = v.target_pos
			if v.state == STATE_MOVING:
				v.state = STATE_GATHERING
				var skill_mod := _get_skill_modifier(v, _skill_for_carrying(v.carrying))
				v.gather_timer = GATHER_TIME * (1.0 - 0.5 * skill_mod)
			else:
				v.state = STATE_IDLE
			if was_scouting:
				_dec_gatherers(v.village_id, "scout")
		STATE_GATHERING:
			pass  # _update_gathering already handles this


## Update which villages have sprites based on camera distance.
func _update_village_lod() -> void:
	if not planet_map_system or not planet_map_system.camera_controller or not planet_map_system.camera_controller.camera:
		return  # Can't determine camera position — keep current LOD state
	if not map_container or not is_instance_valid(map_container):
		return
	var camera: Camera2D = planet_map_system.camera_controller.camera
	# Compare in map_container-local space (same as _camp_positions)
	var cam_pos: Vector2 = map_container.to_local(camera.global_position)

	var newly_visible: Dictionary = {}
	var newly_aggregate: Dictionary = {}
	# Scale render/LOD distance with zoom — zoomed-out means fewer visible villages
	var zoom_scale: float = clampf(camera.zoom.x, 0.01, 1.0)
	# At zoom 1.0: full render distance. At zoom 0.05: render_dist * 0.05
	# Use sqrt so the transition is gradual (not too aggressive at mid-zoom)
	var effective_render: float = VILLAGE_RENDER_DISTANCE * sqrt(zoom_scale)
	var effective_lod: float = SIM_LOD_DISTANCE * sqrt(zoom_scale)
	var render_sq: float = effective_render * effective_render
	var sim_lod_sq: float = effective_lod * effective_lod
	for village_id in _camp_positions:
		var camp: Vector2 = _camp_positions[village_id]
		var dist_sq := camp.distance_squared_to(cam_pos)
		if dist_sq < render_sq:
			newly_visible[village_id] = true
		elif dist_sq >= sim_lod_sq:
			newly_aggregate[village_id] = true

	# Remove sprites for villages that left render range
	for village_id in _visible_villages:
		if not newly_visible.has(village_id):
			_despawn_village_sprites(village_id)

	# Create sprites for villages that entered render range
	for village_id in newly_visible:
		if not _visible_villages.has(village_id):
			# Inflate deflated village when camera approaches
			var village: VillageInstance = _villages_by_id.get(village_id, null)
			if village and village.is_deflated:
				_inflate_village(village_id)
			_spawn_village_sprites(village_id)

	# Deflate inflated NPC villages that moved to aggregate distance
	for village_id in newly_aggregate:
		if not _aggregate_villages.has(village_id):
			var village: VillageInstance = _villages_by_id.get(village_id, null)
			if village and not village.is_deflated and not village.is_player_village:
				_deflate_village(village_id)

	_visible_villages = newly_visible
	_aggregate_villages = newly_aggregate


func _spawn_village_sprites(village_id: String) -> void:
	if not map_container:
		return
	var village_villagers: Array = _villagers_by_village.get(village_id, [])
	for v in village_villagers:
		if v.node and is_instance_valid(v.node):
			continue
		var sprite := Sprite2D.new()
		sprite.texture = PlanetMapTileConfig.TILESET_TEXTURE
		sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		sprite.region_enabled = true
		sprite.centered = true
		sprite.offset.y = VILLAGER_SPRITE_OFFSET_Y
		sprite.scale = Vector2(VILLAGER_SCALE, VILLAGER_SCALE)
		sprite.position = v.container_pos
		sprite.z_index = VILLAGER_Z
		var tile_size := PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
		var inset := PlanetMapTileConfig.TILESET_REGION_INSET
		sprite.region_rect = Rect2i(Vector2i(0, ANIM_ATLAS_ROW) * tile_size + inset, tile_size - inset * 2)
		map_container.add_child(sprite)
		v.node = sprite


func _despawn_village_sprites(village_id: String) -> void:
	var village_villagers: Array = _villagers_by_village.get(village_id, [])
	for v in village_villagers:
		if v.node and is_instance_valid(v.node):
			v.node.queue_free()
			v.node = null


## Inflate a deflated village: generate PersonInstances and create VillagerData for each.
func _inflate_village(village_id: String) -> void:
	var village: VillageInstance = _villages_by_id.get(village_id, null)
	if not village or not village.is_deflated:
		return

	village.inflate()

	# Seed resources and territory now that we have individuals
	_seed_nearby_resources(village)
	_seed_visited_tiles(village)

	# Create VillagerData for each person
	var camp_pos: Vector2 = _camp_positions.get(village_id, Vector2.ZERO)
	var camp_grid: Vector2i = _camp_grid_positions.get(village_id, Vector2i.ZERO)
	if not _villagers_by_village.has(village_id):
		_villagers_by_village[village_id] = []

	for person in village.individuals:
		_create_villager(person, village.is_player_village, village_id, camp_pos, camp_grid)

	# Remove from aggregate set
	_aggregate_villages.erase(village_id)
	_max_gatherers_cache.erase(village_id)

	GameLog.debug(LOG_TAG, "Village %s inflated: %d villagers created" % [village_id, village.individuals.size()])


## Deflate an inflated NPC village: sync needs, remove VillagerData, convert to demographics.
func _deflate_village(village_id: String) -> void:
	var village: VillageInstance = _villages_by_id.get(village_id, null)
	if not village or village.is_deflated or village.is_player_village or village.is_pinned:
		return

	# Sync runtime needs back to PersonInstances before snapshotting
	var villager_list: Array = _villagers_by_village.get(village_id, [])
	for v in villager_list:
		var vd: VillagerData = v as VillagerData
		if vd and vd.person:
			vd.person.hunger = vd.hunger
			vd.person.thirst = vd.thirst
			vd.person.rest = vd.rest
			vd.person.metabolism = vd.metabolism

	# Free sprites and remove VillagerData
	var remaining: Array = []
	for v in _villagers:
		if v.village_id == village_id:
			if v.node and is_instance_valid(v.node):
				v.node.queue_free()
			if v.carrying != "":
				_dec_gatherers(v.village_id, v.carrying)
				_dec_pos_gatherers(v.target_grid)
			if v.state == STATE_SCOUTING:
				_dec_gatherers(v.village_id, "scout")
			_cached_grid.erase(v)
			_cached_grid_pos.erase(v)
		else:
			remaining.append(v)
	_villagers = remaining
	_villagers_by_village[village_id] = []

	# Clean up caches
	_gatherer_counts.erase(village_id)
	_berry_search_cache.erase(village_id)
	_max_gatherers_cache.erase(village_id)
	_visible_villages.erase(village_id)

	# Deflate the village instance
	village.deflate()

	# Mark as aggregate
	_aggregate_villages[village_id] = true

	GameLog.debug(LOG_TAG, "Village %s deflated: pop %d, zero per-frame cost" % [village_id, village.get_population()])


func _get_camp_for(v: VillagerData) -> Vector2:
	if _camp_positions.has(v.village_id):
		return _camp_positions[v.village_id]
	return _camp_positions.values()[0] if not _camp_positions.is_empty() else Vector2.ZERO

func _get_water_for(v: VillagerData) -> Vector2:
	if _water_positions.has(v.village_id):
		return _water_positions[v.village_id]
	return _water_positions.values()[0] if not _water_positions.is_empty() else Vector2.ZERO

func _get_berry_for(v: VillagerData) -> Vector2:
	if _berry_positions.has(v.village_id):
		return _berry_positions[v.village_id]
	return _berry_positions.values()[0] if not _berry_positions.is_empty() else Vector2.ZERO

func _get_firewood_for(v: VillagerData) -> Vector2:
	if _firewood_positions.has(v.village_id):
		return _firewood_positions[v.village_id]
	return _firewood_positions.values()[0] if not _firewood_positions.is_empty() else Vector2.ZERO

func _get_camp_grid_for(v: VillagerData) -> Vector2i:
	return _camp_grid_positions.get(v.village_id, Vector2i.ZERO)

func _get_water_grid_for(v: VillagerData) -> Vector2i:
	return _water_grid_positions.get(v.village_id, Vector2i.ZERO)

func _get_berry_grid_for(v: VillagerData) -> Vector2i:
	return _berry_grid_positions.get(v.village_id, Vector2i.ZERO)

func _get_firewood_grid_for(v: VillagerData) -> Vector2i:
	return _firewood_grid_positions.get(v.village_id, Vector2i.ZERO)

## Convert a map_container-local position back to approximate grid coordinates.
func _container_to_grid(container_pos: Vector2) -> Vector2i:
	if not planet_map_system or not planet_map_system.tile_manager or not map_container:
		return Vector2i.ZERO
	var world_pos: Vector2 = map_container.to_global(container_pos)
	var local_pos: Vector2 = planet_map_system.tile_manager.to_local(world_pos)
	return PlanetMapCoordinates.world_to_grid(local_pos)


## Return true if container_pos is over any clickable thing (villager or camp tile).
func has_clickable_at(container_pos: Vector2) -> bool:
	if get_villager_at_pos(container_pos) != null:
		return true
	return get_camp_village_id_at_pos(container_pos) != ""


## Return the village_id of a camp whose sprite area contains container_pos, or "".
## Uses a generous hit radius so clicks on the tall longhouse sprite register.
func get_camp_village_id_at_pos(container_pos: Vector2) -> String:
	for village_id in _camp_positions:
		var camp_pos: Vector2 = _camp_positions[village_id]
		# Longhouse sprite extends upward; check a tall rectangle above the tile center
		var dx := absf(container_pos.x - camp_pos.x)
		var dy := container_pos.y - camp_pos.y  # negative = above
		if dx <= PlanetMapTileConfig.TILE_SIZE.x / 2.0 and dy >= -PlanetMapTileConfig.TILE_SIZE.y * 2.0 and dy <= PlanetMapTileConfig.TILE_SIZE.y / 2.0:
			return village_id
	return ""


func get_camp_container_pos(village_id: String) -> Vector2:
	return _camp_positions.get(village_id, Vector2.ZERO)


## Return the villager whose square contains container_pos, or null.
func get_villager_at_pos(container_pos: Vector2):
	for v in _villagers:
		if not v.node or not is_instance_valid(v.node) or not v.node.visible:
			continue
		if v.container_pos.distance_to(container_pos) <= 30.0:
			return v
	return null


func get_villager_screen_pos(v: VillagerData) -> Vector2:
	return v.container_pos


## Returns all VillagerData for a given village_id.
func get_villagers_for_village(village_id: String) -> Array:
	var result: Array = []
	for v in _villagers:
		if v.village_id == village_id:
			result.append(v)
	return result


## Returns resource role info for a tile: {"village_id": String, "role": String} or empty dict.
## Checks if any village uses this grid position as a camp, water, berry, or firewood source.
## Also checks if any villager is actively gathering at this position.
func get_resource_role_at(grid_pos: Vector2i) -> Dictionary:
	# Exact match on stored resource positions
	for vid in _camp_grid_positions:
		if _camp_grid_positions[vid] == grid_pos:
			return {"village_id": vid, "role": "camp"}
	for vid in _water_grid_positions:
		if _water_grid_positions[vid] == grid_pos:
			return {"village_id": vid, "role": "water"}
	for vid in _berry_grid_positions:
		if _berry_grid_positions[vid] == grid_pos:
			return {"village_id": vid, "role": "food"}
	for vid in _firewood_grid_positions:
		if _firewood_grid_positions[vid] == grid_pos:
			return {"village_id": vid, "role": "firewood"}
	# Check if any villager is currently gathering at this tile
	for v in _villagers:
		if (v.state == STATE_MOVING or v.state == STATE_GATHERING) and v.target_grid == grid_pos and v.carrying != "":
			return {"village_id": v.village_id, "role": v.carrying}
	return {}


## Returns all resource positions for a village (for overlay/debug).
func get_resource_positions(village_id: String) -> Dictionary:
	return {
		"camp": _camp_grid_positions.get(village_id, Vector2i(-1, -1)),
		"water": _water_grid_positions.get(village_id, Vector2i(-1, -1)),
		"berry": _berry_grid_positions.get(village_id, Vector2i(-1, -1)),
		"firewood": _firewood_grid_positions.get(village_id, Vector2i(-1, -1)),
	}


## Human-readable activity string for a VillagerData (public wrapper).
func get_activity(v: VillagerData) -> String:
	return _state_name(v)


func _state_name(v: VillagerData) -> String:
	match v.state:
		STATE_IDLE:      return "Idle"
		STATE_WANDERING: return "Wandering"
		STATE_SCOUTING:  return "Scouting"
		STATE_MOVING:    return "Going for " + v.carrying if v.carrying != "" else "Moving"
		STATE_GATHERING: return "Gathering " + v.carrying
		STATE_RETURNING: return "Returning with " + v.carrying if v.carrying != "" else "Returning"
		STATE_SLEEPING:  return "Sleeping"
	return "Unknown"


func get_villager_body_text(v: VillagerData) -> String:
	var sex := "Male" if v.person.sex == PersonInstance.Sex.MALE else "Female"
	var age: int = v.person.age if v.person.get("age") != null else 0
	var hunger_pct := int(v.hunger * 100)
	var thirst_pct := int(v.thirst * 100)
	var rest_pct   := int(v.rest   * 100)
	return "%s, age %d\n%s\nHunger: %d%%  Thirst: %d%%  Rest: %d%%" % [
		sex, age, _state_name(v), hunger_pct, thirst_pct, rest_pct
	]


## Remove all villagers and cached data for a single village (collapse or removal).
func remove_village(village_id: String) -> void:
	var remaining: Array = []
	for v in _villagers:
		if v.village_id == village_id:
			if v.node and is_instance_valid(v.node):
				v.node.queue_free()
			if v.carrying != "":
				_dec_gatherers(v.village_id, v.carrying)
				_dec_pos_gatherers(v.target_grid)
			_cached_grid.erase(v)
			_cached_grid_pos.erase(v)
		else:
			remaining.append(v)
	_villagers = remaining
	_camp_positions.erase(village_id)
	_water_positions.erase(village_id)
	_berry_positions.erase(village_id)
	_firewood_positions.erase(village_id)
	_firewood_grid_positions.erase(village_id)
	_camp_grid_positions.erase(village_id)
	_water_grid_positions.erase(village_id)
	_berry_grid_positions.erase(village_id)
	_villages_by_id.erase(village_id)
	_gatherer_counts.erase(village_id)
	_visited_tiles.erase(village_id)
	_villagers_by_village.erase(village_id)
	_visible_villages.erase(village_id)
	_berry_search_cache.erase(village_id)
	_max_gatherers_cache.erase(village_id)
	GameLog.debug(LOG_TAG, "Village %s removed from VillagerSystem" % village_id)


## Called by VillageManager when a person dies of old age/illness (yearly tick).
## Safe to call if villager already removed (starvation death already cleaned up).
func on_person_died(village_id: String, person_name: String) -> void:
	# Deflated villages have no VillagerData — nothing to remove
	var village: VillageInstance = _villages_by_id.get(village_id, null)
	if village and village.is_deflated:
		return
	for v in _villagers:
		if v.village_id == village_id and v.person and v.person.name == person_name:
			if v.node and is_instance_valid(v.node):
				v.node.queue_free()
			if v.carrying != "":
				_dec_gatherers(v.village_id, v.carrying)
				_dec_pos_gatherers(v.target_grid)
			if v.state == STATE_SCOUTING:
				_dec_gatherers(v.village_id, "scout")
			_cached_grid.erase(v)
			_cached_grid_pos.erase(v)
			# Remove from per-village index immediately (prevents ghost iteration)
			if _villagers_by_village.has(village_id):
				_villagers_by_village[village_id].erase(v)
			# Defer removal from _villagers to batch cleanup in _process
			_dead_this_frame[v] = true
			_max_gatherers_cache.erase(village_id)
			return


## Called by VillageManager when a baby is born (monthly tick).
## Creates sprite for the new person in the village.
func on_person_born(village_id: String, _person_name: String) -> void:
	_max_gatherers_cache.erase(village_id)
	var village: VillageInstance = _villages_by_id.get(village_id, null)
	if not village:
		return
	# Deflated villages handle births via demographics — no VillagerData to create
	if village.is_deflated:
		return
	if not _camp_positions.has(village_id):
		return
	# Find the new person (last added to individuals with this name)
	var person: PersonInstance = null
	for p in village.individuals:
		if p.name == _person_name:
			person = p
	if not person:
		return
	# Check not already spawned
	for v in _villagers:
		if v.village_id == village_id and v.person == person:
			return
	var camp_pos: Vector2 = _camp_positions[village_id]
	var camp_grid: Vector2i = _camp_grid_positions.get(village_id, Vector2i.ZERO)
	_create_villager(person, village.is_player_village, village_id, camp_pos, camp_grid)
	GameLog.debug(LOG_TAG, "Spawned newborn %s in village %s" % [_person_name, village_id])


## Returns 0.0-1.0 skill modifier for a villager based on their skill level.
func _get_skill_modifier(v: VillagerData, skill_key: String) -> float:
	var level: int = v.person.skills.get(skill_key, 0) if v.person else 0
	return clampf(float(level) / 100.0, 0.0, 1.0)


## Maps a carrying resource to the relevant skill key.
func _skill_for_carrying(carrying: String) -> String:
	match carrying:
		"food": return "foraging"
		"water": return "foraging"
		"firewood": return "shelter_building"
	return ""


## Max simultaneous gatherers per berry bush — matches BERRY_MAX_PICKS (4).
## No point sending more foragers than the bush has remaining picks.
const MAX_GATHERERS_PER_BERRY := 4
## Firewood trees have 60-125 supply — generous cap to avoid all on one tree
const MAX_GATHERERS_PER_FIREWOOD := 6


## Pick the best resource position from known set, distributing gatherers.
## Caps gatherers per position to resource supply. Searches for new positions when saturated.
func _pick_distributed_resource(v: VillagerData, village: VillageInstance, resource_type: String) -> Vector2i:
	if not village.resource_memory:
		if resource_type == VillageResourceMemory.BERRY:
			return _get_berry_grid_for(v)
		elif resource_type == VillageResourceMemory.FIREWOOD:
			return _get_firewood_grid_for(v)
		return Vector2i(-1, -1)

	var known: Array[Vector2i] = village.resource_memory.get_all_known(resource_type)
	if known.is_empty():
		if resource_type == VillageResourceMemory.BERRY:
			return _get_berry_grid_for(v)
		elif resource_type == VillageResourceMemory.FIREWOOD:
			return _get_firewood_grid_for(v)
		return Vector2i(-1, -1)

	var max_per_pos: int = MAX_GATHERERS_PER_FIREWOOD
	if resource_type == VillageResourceMemory.BERRY:
		max_per_pos = MAX_GATHERERS_PER_BERRY

	# Filter: not depleted AND has capacity for another gatherer
	var valid: Array[Vector2i] = []
	for pos in known:
		if resource_type == VillageResourceMemory.BERRY:
			if planet_map_system and planet_map_system.is_berry_depleted(pos):
				continue
		if _get_pos_gatherers(pos) >= max_per_pos:
			continue
		valid.append(pos)

	# All positions saturated or depleted — try to find new ones
	if valid.is_empty():
		if resource_type == VillageResourceMemory.BERRY:
			var new_pos := _find_berry_cached(v.village_id, _get_camp_grid_for(v))
			if new_pos != Vector2i(-1, -1) and _get_pos_gatherers(new_pos) < max_per_pos:
				return new_pos
			# Truly no available berry — skip this task
			return Vector2i(-1, -1)
		elif resource_type == VillageResourceMemory.FIREWOOD:
			var fallback := _get_firewood_grid_for(v)
			if _get_pos_gatherers(fallback) < max_per_pos:
				return fallback
			return Vector2i(-1, -1)
		return Vector2i(-1, -1)

	# Pick position with fewest active gatherers, break ties by distance
	var best_pos := valid[0]
	var best_count := _get_pos_gatherers(valid[0])
	var villager_grid := _get_cached_grid(v)
	var best_dist := Vector2(villager_grid).distance_squared_to(Vector2(valid[0]))
	for i in range(1, valid.size()):
		var count := _get_pos_gatherers(valid[i])
		var dist := Vector2(villager_grid).distance_squared_to(Vector2(valid[i]))
		if count < best_count or (count == best_count and dist < best_dist):
			best_pos = valid[i]
			best_count = count
			best_dist = dist

	return best_pos


## Cached berry search — avoids O(R^2) spiral every depletion.
## Respects TTL even for depleted results to prevent repeated spiral searches.
func _find_berry_cached(village_id: String, camp_grid: Vector2i) -> Vector2i:
	# Guard against invalid camp positions (0,0) — skip expensive spiral
	if camp_grid.x <= 0 and camp_grid.y <= 0:
		return _get_berry_grid_for_village(village_id)

	if _berry_search_cache.has(village_id):
		var cached: Dictionary = _berry_search_cache[village_id]
		var age: float = Time.get_ticks_msec() / 1000.0 - cached.get("time", 0.0)
		if age < BERRY_CACHE_TTL:
			# Return cached result even if depleted — TTL prevents re-searching
			return cached.get("pos", Vector2i(-1, -1))

	if not planet_map_system:
		return _get_berry_grid_for_village(village_id)

	var result: Vector2i = planet_map_system.find_next_berry(camp_grid)
	_berry_search_cache[village_id] = {
		"pos": result,
		"time": Time.get_ticks_msec() / 1000.0,
	}

	# Update village's known resources
	var village: VillageInstance = _villages_by_id.get(village_id, null)
	if village and village.resource_memory:
		village.resource_memory.add_known(VillageResourceMemory.BERRY, result)
	# Also update the shared fallback position
	_berry_grid_positions[village_id] = result
	_berry_positions[village_id] = _get_resource_container_pos(result)
	if village:
		village.berry_pos = result

	return result


func _get_berry_grid_for_village(village_id: String) -> Vector2i:
	return _berry_grid_positions.get(village_id, Vector2i(-1, -1))


## Cached grid-to-container conversion for resource positions.
## Resource positions rarely change, so cache is very effective.
func _get_resource_container_pos(grid_pos: Vector2i) -> Vector2:
	if _grid_to_container_cache.has(grid_pos):
		return _grid_to_container_cache[grid_pos]
	var result := _grid_to_container(grid_pos)
	# Don't cache zero results — setup may not be complete yet
	if result != Vector2.ZERO:
		_grid_to_container_cache[grid_pos] = result
	return result


## Request a terrain-aware path for a villager. Uses cached route if available.
## Falls back to straight-line movement if no path found.
func _request_path(v: VillagerData, start: Vector2i, end: Vector2i) -> void:
	var cache: VillagePathCache = _path_caches.get(v.village_id)
	if not cache:
		v.current_path = []
		v.path_index = 0
		v.target_pos = _get_resource_container_pos(end)
		return

	var path: Array[Vector2i] = cache.get_full_path(start, end, _visit_frame_counter)
	if path.is_empty():
		GameLog.debug(LOG_TAG, "Path failed %s -> %s for %s (A* exhausted or unreachable)" % [str(start), str(end), v.village_id])
		v.current_path = []
		v.path_index = 0
		v.target_pos = _get_resource_container_pos(end)
		return

	v.current_path = path
	v.path_index = 1  # Skip index 0 (current position)
	v.path_target_container = _get_resource_container_pos(path[1] if path.size() > 1 else path[0])
	v.target_pos = _get_resource_container_pos(end)
	GameLog.debug(LOG_TAG, "Path found %s -> %s (%d tiles) for %s" % [str(start), str(end), path.size(), v.village_id])


## Try to send a scout along an existing path, then explore beyond its endpoint.
## Returns true if a path-based scout was set up, false to fall back to random.
func _try_scout_along_path(v: VillagerData) -> bool:
	var cache: VillagePathCache = _path_caches.get(v.village_id)
	if not cache:
		return false
	var routes: Array = cache.get_all_routes()
	if routes.is_empty():
		return false

	# Pick a random route to scout beyond
	var route_data: Array = routes[randi() % routes.size()]
	var full_path: Array = route_data[0]
	if full_path.size() < 2:
		return false

	# The endpoint of the existing path — scout will explore beyond this
	var path_end: Vector2i = full_path[full_path.size() - 1]
	var path_end_container: Vector2 = _get_resource_container_pos(path_end)

	# Short exploration hop beyond the path endpoint (not full SCOUT_RADIUS —
	# the path already carried the scout far from camp)
	var angle := randf() * TAU
	var explore_dist := randf_range(WANDER_RADIUS, WANDER_RADIUS * 3.0)
	var explore_target: Vector2 = path_end_container + Vector2(cos(angle), sin(angle)) * explore_dist

	# Build path: follow existing route, then straight-line explore from endpoint
	var scout_path: Array[Vector2i] = []
	for pt in full_path:
		scout_path.append(pt as Vector2i)

	v.current_path = scout_path
	v.path_index = 1
	v.path_target_container = _get_resource_container_pos(scout_path[1])
	# Final target is the exploration point beyond the path
	v.target_pos = explore_target
	v.target_grid = _container_to_grid(explore_target)
	v.state = STATE_SCOUTING
	return true


## Look up the outbound route from cache and reverse it for the return trip.
## resource_grid is where the villager just gathered (before target_grid was set to camp).
func _request_return_path(v: VillagerData, resource_grid: Vector2i) -> void:
	var cache: VillagePathCache = _path_caches.get(v.village_id)
	var camp_grid := v.target_grid  # Already set to camp by caller
	if cache:
		var outbound: Array[Vector2i] = cache.get_full_path(camp_grid, resource_grid, _visit_frame_counter)
		if outbound.size() >= 2:
			var reversed_path: Array[Vector2i] = outbound.duplicate()
			reversed_path.reverse()
			v.current_path = reversed_path
			v.path_index = 1
			v.path_target_container = _get_resource_container_pos(reversed_path[1])
			v.target_pos = _get_resource_container_pos(camp_grid)
			return
	# Fallback: no cached outbound route, go straight
	v.current_path = []
	v.path_index = 0
	v.target_pos = _get_resource_container_pos(camp_grid)


## Get trail traversal data for all villages (for overlay rendering).
## Returns Dictionary(village_id -> Dictionary(Vector2i -> int count)).
func get_all_trail_data() -> Dictionary:
	var result: Dictionary = {}
	for village_id in _path_caches:
		result[village_id] = _path_caches[village_id].get_all_trail_tiles()
	return result


## Get all cached routes per village for path rendering.
## Returns Dictionary(village_id -> Array of [full_path: Array[Vector2i], usage_count: int]).
func get_all_route_data() -> Dictionary:
	var result: Dictionary = {}
	for village_id in _path_caches:
		var routes: Array = _path_caches[village_id].get_all_routes()
		if not routes.is_empty():
			result[village_id] = routes
	return result


## Invalidate cached paths ending at a position (resource depleted).
func invalidate_paths_to(grid_pos: Vector2i) -> void:
	for village_id in _path_caches:
		_path_caches[village_id].invalidate_routes_to(grid_pos)


func _inc_pos_gatherers(pos: Vector2i) -> void:
	_pos_gatherer_counts[pos] = _pos_gatherer_counts.get(pos, 0) + 1


func _dec_pos_gatherers(pos: Vector2i) -> void:
	var count: int = _pos_gatherer_counts.get(pos, 0) - 1
	if count <= 0:
		_pos_gatherer_counts.erase(pos)
	else:
		_pos_gatherer_counts[pos] = count


func _get_pos_gatherers(pos: Vector2i) -> int:
	return _pos_gatherer_counts.get(pos, 0)


## Get cached grid position for a villager, updating if moved significantly.
func _get_cached_grid(v: VillagerData) -> Vector2i:
	if _cached_grid.has(v):
		var old_pos: Vector2 = _cached_grid_pos.get(v, Vector2.ZERO)
		if v.container_pos.distance_squared_to(old_pos) < 6400.0:  # ~80px = half tile
			return _cached_grid[v]
	var grid := _container_to_grid(v.container_pos)
	_cached_grid[v] = grid
	_cached_grid_pos[v] = v.container_pos
	return grid


func cleanup() -> void:
	for v in _villagers:
		if v.node and is_instance_valid(v.node):
			v.node.queue_free()
	_villagers.clear()
	_camp_positions.clear()
	_water_positions.clear()
	_berry_positions.clear()
	_firewood_positions.clear()
	_firewood_grid_positions.clear()
	_villages_by_id.clear()
	_gatherer_counts.clear()
	_visited_tiles.clear()
	_pos_gatherer_counts.clear()
	_cached_grid.clear()
	_cached_grid_pos.clear()
	_berry_search_cache.clear()
	_grid_to_container_cache.clear()
	_path_caches.clear()
	_pathfinder = null


func get_visited_tiles(village_id: String) -> Dictionary:
	var cache: VillagePathCache = _path_caches.get(village_id)
	if cache:
		return cache.get_all_trail_tiles()
	return _visited_tiles.get(village_id, {})


func get_all_visited_tiles() -> Dictionary:
	# Return trail data from path caches; fall back to legacy visited tiles
	var result := get_all_trail_data()
	# Include any legacy visited tiles for villages without path caches
	for vid in _visited_tiles:
		if not result.has(vid):
			result[vid] = _visited_tiles[vid]
	return result


func clear_visited_tiles(village_id: String) -> void:
	_visited_tiles.erase(village_id)
	if _path_caches.has(village_id):
		_path_caches[village_id].clear_routes()


## Scan for nearby resources around camp and add to village's resource memory.
## Gives forager distribution multiple targets from the start.
const SEED_SCAN_RADIUS := 20  # tiles to scan for resources at village setup
const SEED_MAX_BERRIES := 6   # max berry positions to seed
const SEED_MAX_FIREWOOD := 6  # max firewood positions to seed

func _seed_nearby_resources(village: VillageInstance) -> void:
	if not planet_map_system or not village.resource_memory:
		return
	var camp := village.camp_position
	var berry_count := 0
	var fw_count := 0
	# Scan in expanding ring pattern for efficiency
	for radius in range(3, SEED_SCAN_RADIUS + 1):
		if berry_count >= SEED_MAX_BERRIES and fw_count >= SEED_MAX_FIREWOOD:
			break
		for dx in range(-radius, radius + 1):
			for dy in range(-radius, radius + 1):
				if abs(dx) != radius and abs(dy) != radius:
					continue  # Only check ring perimeter
				var check := camp + Vector2i(dx, dy)
				if berry_count < SEED_MAX_BERRIES:
					if planet_map_system.has_berry_at(check) and not planet_map_system.is_berry_depleted(check):
						village.resource_memory.add_known(VillageResourceMemory.BERRY, check)
						berry_count += 1
				if fw_count < SEED_MAX_FIREWOOD:
					if planet_map_system.has_dead_tree_at(check):
						village.resource_memory.add_known(VillageResourceMemory.FIREWOOD, check)
						fw_count += 1


## Pre-populate trail data with paths from camp to each known resource.
func _seed_visited_tiles(village: VillageInstance) -> void:
	var vid := village.village_id
	var cache: VillagePathCache = _path_caches.get(vid)

	var points: Array[Vector2i] = [
		village.water_pos,
		village.berry_pos,
		village.firewood_pos,
	]

	var camp := village.camp_position
	if camp.x < 0 or camp.y < 0:
		return

	# Pre-compute and cache paths from camp to each resource
	for pt in points:
		if pt.x < 0 or pt.y < 0 or pt == camp:
			continue
		if cache:
			cache.get_path(camp, pt, 0)
		else:
			# Fallback: legacy visited tiles for villages without pathfinder
			if not _visited_tiles.has(vid):
				_visited_tiles[vid] = {}
			_add_line_tiles(vid, camp, pt)


## Add grid tiles along a line between two points using Bresenham-style stepping.
func _add_line_tiles(village_id: String, from: Vector2i, to: Vector2i) -> void:
	var dx := absi(to.x - from.x)
	var dy := absi(to.y - from.y)
	var sx := 1 if from.x < to.x else -1
	var sy := 1 if from.y < to.y else -1
	var err := dx - dy
	var pos := from

	var tiles: Dictionary = _visited_tiles[village_id]
	while true:
		if tiles.size() >= MAX_VISITED_TILES_PER_VILLAGE:
			break
		tiles[pos] = true
		if pos == to:
			break
		var e2 := err * 2
		if e2 > -dy:
			err -= dy
			pos.x += sx
		if e2 < dx:
			err += dx
			pos.y += sy
