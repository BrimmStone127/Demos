class_name VillageRelationship
extends RefCounted

## Tracks the relationship between two villages.
## Both villages hold a reference to the same relationship data keyed by the other village's id.

enum Stance {
	UNKNOWN,    # No contact yet
	NEUTRAL,    # Aware of each other, no significant interaction
	TRADING,    # Active exchange of resources or knowledge
	ALLIED,     # Mutual support
	HOSTILE     # Raiding or conflict
}

var other_village_id: String = ""
var stance: Stance = Stance.UNKNOWN

## Record of contact events: Array of {tick, type, outcome}
var contact_history: Array[Dictionary] = []

## Skills transferred between villages through cultural exchange
var exchanged_skills: Array[String] = []


func initialize(p_other_village_id: String) -> void:
	other_village_id = p_other_village_id
	stance = Stance.UNKNOWN


func record_contact(tick: int, contact_type: String, outcome: String) -> void:
	contact_history.append({
		"tick": tick,
		"type": contact_type,
		"outcome": outcome
	})


func get_contact_count() -> int:
	return contact_history.size()


func get_stance_name() -> String:
	match stance:
		Stance.UNKNOWN: return "unknown"
		Stance.NEUTRAL: return "neutral"
		Stance.TRADING: return "trading"
		Stance.ALLIED: return "allied"
		Stance.HOSTILE: return "hostile"
		_: return "unknown"


func to_dict() -> Dictionary:
	var history: Array = []
	for entry in contact_history:
		history.append(entry.duplicate())
	return {
		"other_village_id": other_village_id,
		"stance": stance,
		"contact_history": history,
		"exchanged_skills": exchanged_skills.duplicate(),
	}


static func from_dict(data: Dictionary) -> VillageRelationship:
	var rel := VillageRelationship.new()
	rel.other_village_id = data.get("other_village_id", "")
	rel.stance = data.get("stance", Stance.UNKNOWN)
	var history = data.get("contact_history", [])
	rel.contact_history = []
	for entry in history:
		if entry is Dictionary:
			rel.contact_history.append(entry.duplicate())
	var skills = data.get("exchanged_skills", [])
	rel.exchanged_skills = []
	for s in skills:
		rel.exchanged_skills.append(str(s))
	return rel
