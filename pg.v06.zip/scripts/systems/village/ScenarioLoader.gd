class_name ScenarioLoader
extends RefCounted

## Loads scenario configuration data for village simulation.
## Scenarios define skills, eras, political traits, and starting conditions.
## Currently returns hardcoded data — JSON file loading to be added later.

const LOG_TAG := "SCENARIO"

## Loaded scenario cache: scenario_id -> data dictionary
var _cache: Dictionary = {}


## Returns full scenario data for the given id.
## Returns empty dict if scenario not found.
func load_scenario(scenario_id: String) -> Dictionary:
	if _cache.has(scenario_id):
		return _cache[scenario_id]

	var data = _build_scenario(scenario_id)
	if data.is_empty():
		GameLog.warn(LOG_TAG, "Unknown scenario: %s" % scenario_id)
		return {}

	_cache[scenario_id] = data
	GameLog.info(LOG_TAG, "Loaded scenario: %s (%d skills, %d eras)" % [
		scenario_id,
		data.get("skills", {}).size(),
		data.get("eras", {}).size()
	])
	return data


func _build_scenario(scenario_id: String) -> Dictionary:
	match scenario_id:
		"mississippi_early":
			return _mississippi_early()
		"opossum":
			return _opossum()
		_:
			return {}


func _mississippi_early() -> Dictionary:
	return {
		"id": "mississippi_early",
		"name": "Early Mississippian",
		"description": "Hunter-gatherer villages in the Mississippi flood plains, circa 800 CE.",

		# Starting conditions for a new village
		"starting_era": "nomadic",
		"starting_population": 6,

		"starting_skills": [
			"tracking",
			"foraging",
			"hunting",
			"fishing",
			"shelter_building",
			"healing",
			"ritual"
		],

		"starting_political_traits": {
			"hierarchy":       0.25,   # Mostly egalitarian
			"insularity":      0.50,   # Cautious of outsiders
			"ritual_intensity": 0.55,  # Ceremony is central
			"cohesion":        0.65    # Strong internal bonds
		},

		# Name pools — placeholder names, to be replaced with authentic Mississippian names
		"names_male": [
			"Hawk", "River", "Stone", "Cedar", "Crane",
			"Mound", "Ash", "Bison", "Reed", "Falcon"
		],
		"names_female": [
			"Dawn", "Lily", "Willow", "Moon", "Fern",
			"Sage", "Birch", "Cloud", "Mist", "Ember"
		],

		"skills": {
			"tracking": {
				"name": "Tracking",
				"description": "Following animals and reading terrain signs.",
				"era_available": "nomadic",
				"category": "subsistence"
			},
			"foraging": {
				"name": "Foraging",
				"description": "Gathering wild plants, roots, and berries.",
				"era_available": "nomadic",
				"category": "subsistence"
			},
			"hunting": {
				"name": "Hunting",
				"description": "Pursuing and taking large game.",
				"era_available": "nomadic",
				"category": "subsistence"
			},
			"fishing": {
				"name": "Fishing",
				"description": "Taking fish from the Mississippi and its tributaries.",
				"era_available": "nomadic",
				"category": "subsistence"
			},
			"shelter_building": {
				"name": "Shelter Building",
				"description": "Constructing temporary and semi-permanent shelters.",
				"era_available": "nomadic",
				"category": "craft"
			},
			"healing": {
				"name": "Healing",
				"description": "Treating wounds and illness with plant medicines.",
				"era_available": "nomadic",
				"category": "knowledge"
			},
			"ritual": {
				"name": "Ritual",
				"description": "Ceremony, cosmology, and spiritual practice.",
				"era_available": "nomadic",
				"category": "knowledge"
			},
			"flood_plain_farming": {
				"name": "Flood Plain Farming",
				"description": "Cultivating crops in seasonally flooded river soil.",
				"era_available": "semi_settled",
				"category": "subsistence"
			},
			"pottery": {
				"name": "Pottery",
				"description": "Firing clay vessels for storage and ceremony.",
				"era_available": "semi_settled",
				"category": "craft"
			},
			"trade": {
				"name": "Trade",
				"description": "Exchange of goods across village boundaries.",
				"era_available": "semi_settled",
				"category": "social"
			},
			"mound_building": {
				"name": "Mound Building",
				"description": "Construction of ceremonial earthworks.",
				"era_available": "mound_builder",
				"category": "craft"
			}
		},

		"eras": {
			"nomadic": {
				"name": "Nomadic Hunter-Gatherer",
				"unlocks": ["tracking", "foraging", "hunting", "fishing", "shelter_building", "healing", "ritual"],
				"next_era": "semi_settled",
				"transition_conditions": {
					"min_population": 30,
					"min_fishing_skill": 40
				}
			},
			"semi_settled": {
				"name": "Semi-Settled",
				"unlocks": ["flood_plain_farming", "pottery", "trade"],
				"next_era": "mound_builder",
				"transition_conditions": {
					"min_population": 60,
					"requires_skill": "flood_plain_farming",
					"min_skill_level": 50
				}
			},
			"mound_builder": {
				"name": "Mound Builder",
				"unlocks": ["mound_building"],
				"next_era": "",
				"transition_conditions": {}
			}
		},

		"political_traits": {
			"hierarchy": {
				"name": "Social Hierarchy",
				"description": "Degree of status stratification within the village.",
				"range": [0.0, 1.0],
				"default": 0.25
			},
			"insularity": {
				"name": "Insularity",
				"description": "Openness or resistance toward outsiders and other villages.",
				"range": [0.0, 1.0],
				"default": 0.5
			},
			"ritual_intensity": {
				"name": "Ritual Intensity",
				"description": "Centrality of ceremony and spiritual practice to group identity.",
				"range": [0.0, 1.0],
				"default": 0.55
			},
			"cohesion": {
				"name": "Cohesion",
				"description": "Internal solidarity and resistance to fracture under stress.",
				"range": [0.0, 1.0],
				"default": 0.65
			}
		},

		"trait_definitions": {
			"strong": {
				"name": "Strong",
				"description": "Physical strength above the norm. Boosts hunting and building.",
				"heritable": true,
				"skill_bonus": {"hunting": 10, "shelter_building": 5}
			},
			"perceptive": {
				"name": "Perceptive",
				"description": "Unusually sharp senses. Boosts tracking and fishing.",
				"heritable": true,
				"skill_bonus": {"tracking": 10, "fishing": 5}
			},
			"charismatic": {
				"name": "Charismatic",
				"description": "Natural social influence. Affects group cohesion and trade.",
				"heritable": false,
				"skill_bonus": {"trade": 15}
			},
			"spiritual": {
				"name": "Spiritual",
				"description": "Deep connection to ritual practice. Boosts healing and ritual.",
				"heritable": true,
				"skill_bonus": {"healing": 8, "ritual": 12}
			}
		}
	}


func _opossum() -> Dictionary:
	return {
		"id": "opossum",
		"name": "Opossum Colonists",
		"description": "A thriving opossum civilization that has claimed terraformed worlds throughout the sector.",

		"starting_era": "nomadic",
		"starting_population": 6,

		"starting_skills": [
			"foraging",
			"hunting",
			"shelter_building",
			"healing",
			"ritual",
			"playing_dead"
		],

		"starting_political_traits": {
			"hierarchy":        0.20,
			"insularity":       0.35,
			"ritual_intensity": 0.70,
			"cohesion":         0.80
		},

		"names_male": [
			"Grub", "Poss", "Snout", "Bristle", "Dusk",
			"Musk", "Marsh", "Hollow", "Burrow", "Fang"
		],
		"names_female": [
			"Pouch", "Thistle", "Wallow", "Dew", "Bramble",
			"Nuzzle", "Scruff", "Sprig", "Husk", "Murk"
		],

		"skills": {
			"foraging": {
				"name": "Foraging",
				"description": "Gathering whatever can be eaten, which is most things.",
				"era_available": "nomadic",
				"category": "subsistence"
			},
			"hunting": {
				"name": "Hunting",
				"description": "Pursuing prey. Mostly by waiting near it.",
				"era_available": "nomadic",
				"category": "subsistence"
			},
			"shelter_building": {
				"name": "Shelter Building",
				"description": "Constructing dens and burrows.",
				"era_available": "nomadic",
				"category": "craft"
			},
			"healing": {
				"name": "Healing",
				"description": "Treating wounds. Opossums have unusual resistance to toxins.",
				"era_available": "nomadic",
				"category": "knowledge"
			},
			"ritual": {
				"name": "Ritual",
				"description": "Ceremony and spiritual practice. The central mystery involves playing dead.",
				"era_available": "nomadic",
				"category": "knowledge"
			},
			"playing_dead": {
				"name": "Playing Dead",
				"description": "A refined art. Not merely feigned death — a philosophical stance.",
				"era_available": "nomadic",
				"category": "knowledge"
			}
		},

		"eras": {
			"nomadic": {
				"name": "Wandering Villages",
				"unlocks": ["foraging", "hunting", "shelter_building", "healing", "ritual", "playing_dead"],
				"next_era": "colony",
				"transition_conditions": {
					"min_population": 25
				}
			},
			"colony": {
				"name": "Established Colony",
				"unlocks": [],
				"next_era": "",
				"transition_conditions": {}
			}
		},

		"political_traits": {
			"hierarchy": {
				"name": "Social Hierarchy",
				"description": "Degree of status stratification within the village.",
				"range": [0.0, 1.0],
				"default": 0.20
			},
			"insularity": {
				"name": "Insularity",
				"description": "Openness or resistance toward outsiders.",
				"range": [0.0, 1.0],
				"default": 0.35
			},
			"ritual_intensity": {
				"name": "Ritual Intensity",
				"description": "Centrality of ceremony and the Great Playing Dead to group identity.",
				"range": [0.0, 1.0],
				"default": 0.70
			},
			"cohesion": {
				"name": "Cohesion",
				"description": "Internal solidarity. Opossums stick together.",
				"range": [0.0, 1.0],
				"default": 0.80
			}
		},

		"trait_definitions": {
			"resilient": {
				"name": "Resilient",
				"description": "Unusual resistance to injury and disease. Boosts healing.",
				"heritable": true,
				"skill_bonus": {"healing": 12}
			},
			"scavenger": {
				"name": "Scavenger",
				"description": "Finds food where others see nothing. Boosts foraging.",
				"heritable": true,
				"skill_bonus": {"foraging": 10, "hunting": 5}
			},
			"theatrical": {
				"name": "Theatrical",
				"description": "Exceptionally committed to playing dead. Boosts ritual.",
				"heritable": false,
				"skill_bonus": {"ritual": 10, "playing_dead": 15}
			}
		}
	}
