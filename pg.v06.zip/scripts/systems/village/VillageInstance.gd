class_name VillageInstance
extends RefCounted

## Represents a sovereign village of people on a planet surface.
## Runs its own simulation: aging, births, deaths, skill growth.
## NOT a colony — these people have their own internal logic and trajectory.

const LOG_TAG := "VILLAGE"

## People per longhouse before a new one is built
const LONGHOUSE_CAPACITY := 20

## Unique identifier
var village_id: String = ""

## Planet this village lives on
var planet_id: String = ""

## Scenario configuration id (e.g. "mississippi_early")
var scenario_id: String = ""

## Whether this village is the player's primary village
var is_player_village: bool = false

## All living members (empty when deflated — use demographics instead)
var individuals: Array[PersonInstance] = []

## Whether this village is running in demographic mode (no individual PersonInstances)
var is_deflated: bool = false

## Lightweight population stats (non-null only when is_deflated == true)
var demographics: VillageDemographics = null

## Cached individuals preserved during deflation for lossless restore.
## When non-empty, inflate() restores these exact people instead of generating new ones.
var _cached_individuals: Array[PersonInstance] = []

## Pinned villages never auto-deflate (player interaction, hero villagers, etc.)
var is_pinned: bool = false

## What this society knows how to do (keys into scenario skills)
var group_knowledge: Array[String] = []

## Group-level political traits: trait_key -> value (0.0-1.0)
var political_traits: Dictionary = {}

## Current era key (e.g. "nomadic", "semi_settled")
var era: String = ""

## Tiles this village ranges across or inhabits
var territory: Array[Vector2i] = []

## Relationships with other villages: village_id -> VillageRelationship
var village_relationships: Dictionary = {}

## Current settlement site (where longhouses are now)
var active_site: SettlementSite = null

## Previously occupied sites (for return cycling)
var past_sites: Array[SettlementSite] = []

## Counter for generating unique site IDs
var _site_counter: int = 0

## Backward-compatible camp_position — delegates to active_site.center.
## Setting this creates an initial SettlementSite if none exists.
var camp_position: Vector2i:
	get:
		return active_site.center if active_site else Vector2i(-1, -1)
	set(value):
		if active_site == null:
			_create_initial_site(value)
		else:
			active_site.center = value
			if active_site.longhouse_positions.is_empty():
				active_site.longhouse_positions = [value]
			else:
				active_site.longhouse_positions[0] = value

## Village's knowledge of discovered resource locations
var resource_memory: VillageResourceMemory = null

## Resource tile positions — delegate to resource_memory active targets
var water_pos: Vector2i:
	get:
		return resource_memory.get_target(VillageResourceMemory.WATER) if resource_memory else Vector2i(-1, -1)
	set(value):
		if resource_memory:
			resource_memory.set_target(VillageResourceMemory.WATER, value)
var berry_pos: Vector2i:
	get:
		return resource_memory.get_target(VillageResourceMemory.BERRY) if resource_memory else Vector2i(-1, -1)
	set(value):
		if resource_memory:
			resource_memory.set_target(VillageResourceMemory.BERRY, value)
var firewood_pos: Vector2i:
	get:
		return resource_memory.get_target(VillageResourceMemory.FIREWOOD) if resource_memory else Vector2i(-1, -1)
	set(value):
		if resource_memory:
			resource_memory.set_target(VillageResourceMemory.FIREWOOD, value)

## Longhouse storage levels (0.0 - 1.0)
var firewood_stored: float = 0.5
var food_stored: float = 0.5
var water_stored: float = 0.5

## Estimated carrying capacity based on local berry bushes and terrain
var carrying_capacity: float = 50.0

## Competition factor from nearby villages (1.0 = no competition, lower = more)
var competition_factor: float = 1.0

## Event log — timestamped entries for the village info panel
## Each entry: { "year": int, "type": String, "text": String }
const MAX_EVENT_LOG := 100
var event_log: Array[Dictionary] = []

## Internal year counter (incremented by VillageManager)
var age_in_years: int = 0

## Year of last split (for cooldown)
var last_split_year: int = -999

## Year of last migration event (for cooldown)
var last_migration_year: int = -999

## RNG seeded per village for deterministic simulation
var _rng: RandomNumberGenerator = null
var _next_person_id: int = 0

## Name pool loaded from scenario (VillageManager sets this)
var _name_pool_male: Array[String] = []
var _name_pool_female: Array[String] = []


func initialize(p_village_id: String, p_planet_id: String, p_scenario_id: String, scenario_data: Dictionary) -> void:
	village_id = p_village_id
	planet_id = p_planet_id
	scenario_id = p_scenario_id

	resource_memory = VillageResourceMemory.new()

	_rng = RandomNumberGenerator.new()
	_rng.seed = hash(p_village_id)

	# Load scenario configuration
	era = scenario_data.get("starting_era", "nomadic")
	for s in scenario_data.get("starting_skills", []):
		group_knowledge.append(str(s))
	political_traits = scenario_data.get("starting_political_traits", {}).duplicate()
	for n in scenario_data.get("names_male", ["Person"]):
		_name_pool_male.append(str(n))
	for n in scenario_data.get("names_female", ["Person"]):
		_name_pool_female.append(str(n))


func populate(starting_size: int) -> void:
	# Create an initial village with varied ages (families, elders, children)
	for i in range(starting_size):
		var sex = PersonInstance.Sex.MALE if _rng.randi() % 2 == 0 else PersonInstance.Sex.FEMALE
		# Distribute ages naturally: more young adults and children than elders
		var age = _generate_starting_age()
		var person = _create_person(sex, age)
		individuals.append(person)

	GameLog.debug(LOG_TAG, "Village %s populated with %d people (era: %s)" % [village_id, individuals.size(), era])


func _generate_starting_age() -> int:
	# Weight toward younger ages to reflect natural population pyramid
	var roll = _rng.randf()
	if roll < 0.30:
		return _rng.randi_range(0, 12)     # Children
	elif roll < 0.65:
		return _rng.randi_range(13, 30)    # Young adults (peak reproductive)
	elif roll < 0.88:
		return _rng.randi_range(31, 44)    # Mature adults
	else:
		return _rng.randi_range(45, 54)    # Elders (rare)


func _create_person(sex: PersonInstance.Sex, age: int) -> PersonInstance:
	var person = PersonInstance.new()
	var pid = "%s_%04d" % [village_id, _next_person_id]
	_next_person_id += 1

	var name_pool = _name_pool_female if sex == PersonInstance.Sex.FEMALE else _name_pool_male
	var pname = name_pool[_rng.randi() % name_pool.size()] if name_pool.size() > 0 else pid

	person.initialize(pid, pname, sex, age, group_knowledge)
	return person


## Create the initial SettlementSite when camp_position is first set
func _create_initial_site(center: Vector2i) -> void:
	active_site = SettlementSite.new()
	active_site.initialize("%s_site_%d" % [village_id, _site_counter], center, age_in_years)
	_site_counter += 1


## How many longhouses this village needs based on current population
func longhouse_count() -> int:
	var pop := get_population()
	if pop == 0:
		return 1
	return maxi(1, ceili(float(pop) / float(LONGHOUSE_CAPACITY)))


## All longhouse positions at the active site
func get_all_longhouse_positions() -> Array[Vector2i]:
	if active_site == null:
		return []
	return active_site.longhouse_positions


## Simulate one game year: aging, deaths, skill growth. No births here — see tick_month.
func tick_year(_tick_number: int) -> Dictionary:
	age_in_years += 1
	var died: Array[String] = []

	# Tick each individual (aging, health, skills)
	var still_alive: Array[PersonInstance] = []
	for person in individuals:
		var survived = person.tick_year(_rng, individuals.size())
		if survived:
			still_alive.append(person)
		else:
			died.append(person.name)
			GameLog.debug(LOG_TAG, "Village %s: %s died at age %d" % [village_id, person.name, person.age])

	individuals = still_alive

	return {"died": died}


## Simulate one game month: pregnancy advancement, conception, births.
## Returns array of born person names.
func tick_month() -> Array[String]:
	var born: Array[String] = []
	var new_people: Array[PersonInstance] = []
	var has_males := _has_reproductive_males()

	for person in individuals:
		# Advance postpartum counter
		person.tick_postpartum()

		# Advance existing pregnancies
		if person.is_pregnant:
			if person.tick_pregnancy():
				# Baby born!
				var baby_sex = PersonInstance.Sex.MALE if _rng.randi() % 2 == 0 else PersonInstance.Sex.FEMALE
				var baby = _create_person(baby_sex, 0)
				new_people.append(baby)
				born.append(baby.name)
				GameLog.debug(LOG_TAG, "Village %s: %s born to %s" % [village_id, baby.name, person.name])
			continue

		# Check for new conception
		if has_males and person.can_conceive():
			var chance := PersonInstance.MONTHLY_CONCEPTION_CHANCE
			# Cohesion bonus: well-organized village = slightly higher conception
			var cohesion: float = political_traits.get("cohesion", 0.5)
			chance *= (0.8 + cohesion * 0.4)
			# Nutrition suppression: low food/water reduces conception
			var nutrition_factor := clampf(food_stored * water_stored * 2.0, 0.1, 1.0)
			chance *= nutrition_factor
			if _rng.randf() < chance:
				person.conceive()
				GameLog.debug(LOG_TAG, "Village %s: %s is pregnant" % [village_id, person.name])

	for baby in new_people:
		individuals.append(baby)

	return born


## Check if village has at least one male of reproductive age
func _has_reproductive_males() -> bool:
	for person in individuals:
		if person.sex == PersonInstance.Sex.MALE and person.is_of_reproductive_age():
			return true
	return false


## Initialize or update relationship with another village
func set_village_relationship(other_village_id: String) -> VillageRelationship:
	if not village_relationships.has(other_village_id):
		var rel = VillageRelationship.new()
		rel.initialize(other_village_id)
		village_relationships[other_village_id] = rel
	return village_relationships[other_village_id]


func log_event(type: String, text: String) -> void:
	event_log.append({"year": age_in_years, "type": type, "text": text})
	if event_log.size() > MAX_EVENT_LOG:
		event_log.pop_front()


func get_population() -> int:
	if is_deflated and demographics:
		return demographics.population
	return individuals.size()


func get_adult_count() -> int:
	if is_deflated and demographics:
		return demographics.get_adult_count()
	var count = 0
	for person in individuals:
		if person.age >= 15:
			count += 1
	return count


func get_average_age() -> float:
	if is_deflated and demographics:
		return demographics.avg_age
	if individuals.is_empty():
		return 0.0
	var total = 0
	for person in individuals:
		total += person.age
	return float(total) / float(individuals.size())


func get_average_health() -> float:
	if is_deflated and demographics:
		return demographics.avg_health
	if individuals.is_empty():
		return 0.0
	var total = 0.0
	for person in individuals:
		total += person.health
	return total / float(individuals.size())


func is_viable() -> bool:
	# Village can survive with fewer people — small bands are resilient
	return get_population() >= 3 and get_adult_count() >= 2


## Convert from individual mode to demographic mode.
## Caches PersonInstances for lossless restore, then clears the active array.
func deflate() -> void:
	if is_deflated:
		return
	demographics = VillageDemographics.from_individuals(individuals, political_traits)
	# Cache individuals so inflate() restores the exact same people
	_cached_individuals = individuals.duplicate()
	individuals.clear()
	is_deflated = true
	GameLog.debug(LOG_TAG, "Village %s deflated (pop: %d, cached: %d)" % [village_id, demographics.population, _cached_individuals.size()])


## Convert from demographic mode back to individual mode.
## Restores cached individuals if available (lossless), otherwise generates from demographics.
func inflate() -> void:
	if not is_deflated or demographics == null:
		return

	# Restore from cache if available — exact same people come back
	if not _cached_individuals.is_empty():
		individuals = _cached_individuals.duplicate()
		_cached_individuals.clear()
		# Apply demographic tick changes: births/deaths that happened while deflated
		_sync_cached_to_demographics(demographics)
		is_deflated = false
		demographics = null
		GameLog.debug(LOG_TAG, "Village %s inflated from cache (pop: %d)" % [village_id, individuals.size()])
		return

	# No cache — generate new individuals from demographics (lossy fallback)
	individuals.clear()
	var pop := demographics.population
	var males_remaining := demographics.male_count
	var preg_remaining := demographics.pregnant_count

	for i in range(pop):
		var sex: PersonInstance.Sex
		if males_remaining > 0 and (float(males_remaining) / float(pop - i) > randf()):
			sex = PersonInstance.Sex.MALE
			males_remaining -= 1
		else:
			sex = PersonInstance.Sex.FEMALE

		var age := _sample_age_from_buckets(demographics, i, pop)
		var person := _create_person(sex, age)

		person.health = clampf(demographics.avg_health + randf_range(-0.15, 0.15), 0.1, 1.0)
		for skill_key in demographics.avg_skills:
			var avg_val: float = demographics.avg_skills[skill_key]
			person.skills[skill_key] = clampi(int(avg_val + randf_range(-10.0, 10.0)), 0, 100)
		person.hunger = clampf(demographics.avg_hunger + randf_range(-0.1, 0.1), 0.1, 1.0)
		person.thirst = clampf(demographics.avg_thirst + randf_range(-0.1, 0.1), 0.1, 1.0)
		person.rest = clampf(demographics.avg_rest + randf_range(-0.1, 0.1), 0.3, 1.0)

		if sex == PersonInstance.Sex.FEMALE and preg_remaining > 0 and person.is_of_reproductive_age():
			person.is_pregnant = true
			person.pregnancy_months = int(demographics.avg_pregnancy_months)
			preg_remaining -= 1

		individuals.append(person)

	is_deflated = false
	demographics = null
	GameLog.debug(LOG_TAG, "Village %s inflated from demographics (pop: %d)" % [village_id, individuals.size()])


## Sync cached individuals with demographic changes that occurred while deflated.
## Handles births (add new people) and deaths (remove oldest/sickest) to match demographic pop.
func _sync_cached_to_demographics(demo: VillageDemographics) -> void:
	var target_pop := demo.population

	# Deaths: remove people until we match target (remove oldest/sickest first)
	while individuals.size() > target_pop and not individuals.is_empty():
		var worst_idx := 0
		var worst_score := 999.0
		for i in range(individuals.size()):
			# Lower score = more likely to die (old age + poor health)
			var person := individuals[i]
			var score := person.health * 10.0 - float(person.age) * 0.2
			if score < worst_score:
				worst_score = score
				worst_idx = i
		individuals.remove_at(worst_idx)

	# Births: add new people to match target
	while individuals.size() < target_pop:
		var sex := PersonInstance.Sex.MALE if _rng.randi() % 2 == 0 else PersonInstance.Sex.FEMALE
		var baby := _create_person(sex, 0)
		individuals.append(baby)

	# Update needs from demographic averages (drift during deflation)
	for person in individuals:
		person.hunger = clampf(person.hunger + (demo.avg_hunger - person.hunger) * 0.3, 0.1, 1.0)
		person.thirst = clampf(person.thirst + (demo.avg_thirst - person.thirst) * 0.3, 0.1, 1.0)
		person.rest = clampf(person.rest + (demo.avg_rest - person.rest) * 0.3, 0.3, 1.0)


## Pin this village to prevent auto-deflation.
## Use when player interacts with villagers, has heroes here, etc.
func pin() -> void:
	is_pinned = true
	GameLog.debug(LOG_TAG, "Village %s pinned" % village_id)


## Unpin this village to allow auto-deflation again.
func unpin() -> void:
	is_pinned = false
	GameLog.debug(LOG_TAG, "Village %s unpinned" % village_id)


## Explicitly save current individuals for later restore.
## Use before operations that might lose individual data.
## Returns the saved array (also stored in _cached_individuals).
func save_individuals() -> Array[PersonInstance]:
	if not is_deflated and not individuals.is_empty():
		_cached_individuals = individuals.duplicate()
		GameLog.debug(LOG_TAG, "Village %s saved %d individuals" % [village_id, _cached_individuals.size()])
	return _cached_individuals


## Clear cached individuals to free memory (e.g., for villages never revisited).
func clear_individual_cache() -> void:
	_cached_individuals.clear()


## Sample an age from demographic buckets for inflate.
func _sample_age_from_buckets(demo: VillageDemographics, index: int, total: int) -> int:
	# Distribute across buckets proportionally
	var child_end := int(float(demo.age_buckets[0]) / float(total) * float(total))
	var adult_end := child_end + int(float(demo.age_buckets[1]) / float(total) * float(total))
	if index < child_end:
		return _rng.randi_range(0, VillageDemographics.CHILD_MAX_AGE) if _rng else randi_range(0, VillageDemographics.CHILD_MAX_AGE)
	elif index < adult_end:
		return _rng.randi_range(15, VillageDemographics.ADULT_MAX_AGE) if _rng else randi_range(15, VillageDemographics.ADULT_MAX_AGE)
	else:
		return _rng.randi_range(VillageDemographics.ELDER_MIN_AGE, 65) if _rng else randi_range(VillageDemographics.ELDER_MIN_AGE, 65)


func get_summary() -> String:
	var longhouses := active_site.longhouse_positions.size() if active_site else 0
	var preg_count := 0
	if is_deflated and demographics:
		preg_count = demographics.pregnant_count
	else:
		for person in individuals:
			if person.is_pregnant:
				preg_count += 1
	var preg_str := " | Pregnant: %d" % preg_count if preg_count > 0 else ""
	var mode_str := "DEFLATED" if is_deflated else ""
	if is_player_village:
		mode_str = "PLAYER"
	elif not is_deflated:
		mode_str = "NPC"
	return "Village %s [%s] | Pop: %d | Longhouses: %d | Avg age: %.1f | Avg health: %.2f%s | Era: %s" % [
		village_id,
		mode_str,
		get_population(),
		longhouses,
		get_average_age(),
		get_average_health(),
		preg_str,
		era
	]


func to_dict() -> Dictionary:
	var people: Array = []
	for person in individuals:
		people.append(person.to_dict())

	var territory_data: Array = []
	for pos in territory:
		territory_data.append({"x": pos.x, "y": pos.y})

	var relationships_data: Dictionary = {}
	for other_id in village_relationships:
		var rel: VillageRelationship = village_relationships[other_id]
		relationships_data[other_id] = rel.to_dict()

	var past_sites_data: Array = []
	for site in past_sites:
		past_sites_data.append(site.to_dict())

	var events: Array = []
	for entry in event_log:
		events.append(entry.duplicate())

	var result := {
		"village_id": village_id,
		"planet_id": planet_id,
		"scenario_id": scenario_id,
		"is_player_village": is_player_village,
		"is_deflated": is_deflated,
		"is_pinned": is_pinned,
		"individuals": people,
		"group_knowledge": group_knowledge.duplicate(),
		"political_traits": political_traits.duplicate(),
		"era": era,
		"territory": territory_data,
		"village_relationships": relationships_data,
		"active_site": active_site.to_dict() if active_site else {},
		"past_sites": past_sites_data,
		"_site_counter": _site_counter,
		"resource_memory": resource_memory.to_dict() if resource_memory else {},
		"firewood_stored": firewood_stored,
		"food_stored": food_stored,
		"water_stored": water_stored,
		"carrying_capacity": carrying_capacity,
		"competition_factor": competition_factor,
		"event_log": events,
		"age_in_years": age_in_years,
		"last_split_year": last_split_year,
		"last_migration_year": last_migration_year,
		"_next_person_id": _next_person_id,
	}
	if is_deflated and demographics:
		result["demographics"] = demographics.to_dict()
	# Save cached individuals so they survive save/load cycle
	if not _cached_individuals.is_empty():
		var cached_data: Array = []
		for person in _cached_individuals:
			cached_data.append(person.to_dict())
		result["cached_individuals"] = cached_data
	return result


static func from_dict(data: Dictionary) -> VillageInstance:
	var village := VillageInstance.new()
	village.village_id = data.get("village_id", "")
	village.planet_id = data.get("planet_id", "")
	village.scenario_id = data.get("scenario_id", "")
	village.is_player_village = data.get("is_player_village", false)
	village.is_deflated = data.get("is_deflated", false)
	village.is_pinned = data.get("is_pinned", false)
	village.era = data.get("era", "nomadic")

	# RNG seeded per village
	village._rng = RandomNumberGenerator.new()
	village._rng.seed = hash(village.village_id)

	# Group knowledge
	village.group_knowledge = []
	for s in data.get("group_knowledge", []):
		village.group_knowledge.append(str(s))

	village.political_traits = data.get("political_traits", {}).duplicate()

	# Name pools from scenario
	var scenario_loader := ScenarioLoader.new()
	var scenario := scenario_loader.load_scenario(village.scenario_id)
	for n in scenario.get("names_male", ["Person"]):
		village._name_pool_male.append(str(n))
	for n in scenario.get("names_female", ["Person"]):
		village._name_pool_female.append(str(n))

	# Individuals
	village.individuals = []
	for person_data in data.get("individuals", []):
		village.individuals.append(PersonInstance.from_dict(person_data))

	# Demographics (for deflated villages)
	var demo_data: Dictionary = data.get("demographics", {})
	if village.is_deflated and not demo_data.is_empty():
		village.demographics = VillageDemographics.from_dict(demo_data)

	# Cached individuals (preserved across save/load for lossless inflate)
	var cached_data: Array = data.get("cached_individuals", [])
	for person_data in cached_data:
		village._cached_individuals.append(PersonInstance.from_dict(person_data))

	# Territory
	village.territory = []
	for pos_data in data.get("territory", []):
		village.territory.append(Vector2i(pos_data.get("x", 0), pos_data.get("y", 0)))

	# Active site
	var site_data: Dictionary = data.get("active_site", {})
	if not site_data.is_empty():
		village.active_site = SettlementSite.from_dict(site_data)

	# Past sites
	village.past_sites = []
	for site_d in data.get("past_sites", []):
		village.past_sites.append(SettlementSite.from_dict(site_d))

	# Resource memory
	var mem_data: Dictionary = data.get("resource_memory", {})
	if not mem_data.is_empty():
		village.resource_memory = VillageResourceMemory.from_dict(mem_data)
	else:
		village.resource_memory = VillageResourceMemory.new()

	# Relationships
	village.village_relationships = {}
	var rel_data: Dictionary = data.get("village_relationships", {})
	for other_id in rel_data:
		village.village_relationships[other_id] = VillageRelationship.from_dict(rel_data[other_id])

	# Storage
	village.firewood_stored = data.get("firewood_stored", 0.5)
	village.food_stored = data.get("food_stored", 0.5)
	village.water_stored = data.get("water_stored", 0.5)
	village.carrying_capacity = data.get("carrying_capacity", 50.0)
	village.competition_factor = data.get("competition_factor", 1.0)

	# Event log
	village.event_log = []
	for entry in data.get("event_log", []):
		if entry is Dictionary:
			village.event_log.append(entry.duplicate())

	# Counters
	village.age_in_years = data.get("age_in_years", 0)
	village.last_split_year = data.get("last_split_year", -999)
	village.last_migration_year = data.get("last_migration_year", -999)
	village._next_person_id = data.get("_next_person_id", 0)
	village._site_counter = data.get("_site_counter", 0)

	return village
