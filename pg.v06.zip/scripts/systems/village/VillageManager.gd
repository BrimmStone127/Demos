class_name VillageManager
extends Node

## Manages all village simulations across planets.
## Receives simulation ticks from TimeManager and advances village state.
## Follows the same pattern as EcosystemManager.

const LOG_TAG := "VILLAGE_MANAGER"

## Game ticks per year. TimeManager.TICKS_PER_DAY = 2, so 2 * 4 = 8.
const TICKS_PER_YEAR := 8

## Monthly tick for pregnancy/birth — with compressed time, tick monthly each tick
const TICKS_PER_MONTH := 1

## Average firewood trip distance (tiles) that triggers relocation consideration
const FIREWOOD_PRESSURE_THRESHOLD := 40.0

## Minimum spacing between any two village camps (tiles)
const MIN_CAMP_SPACING := 350

## How many game years before an abandoned site regrows enough to return
const REGROWTH_YEARS := 15

## Maximum longhouses per settlement site
const MAX_LONGHOUSES_PER_SITE := 6

## Split when population exceeds this ratio of max capacity
const SPLIT_THRESHOLD_RATIO := 0.8

## Years a village must wait after splitting before it can split again
const SPLIT_COOLDOWN_YEARS := 10

## Resource-pressure split: hunger threshold below which a group emigrates
const RESOURCE_SPLIT_HUNGER_THRESHOLD := 0.4

## Resource-pressure split: shorter cooldown (desperate migration)
const RESOURCE_SPLIT_COOLDOWN_YEARS := 5

## Resource-pressure split: fraction of population that leaves
const RESOURCE_SPLIT_FRACTION := 0.3

## Minimum population for a resource-pressure split
const RESOURCE_SPLIT_MIN_POP := 50

## Migration: max distance (tiles) to search for a receiving village
const MIGRATION_RANGE := 500

## Migration: fraction of population that migrates per event
const MIGRATION_FRACTION := 0.15

## Migration: cooldown years between migration events
const MIGRATION_COOLDOWN_YEARS := 3

## Migration: receiving village must be below this ratio of its carrying capacity
const MIGRATION_CAPACITY_RATIO := 0.8

## Minimum population remaining after any split or migration
const MIN_REMNANT_POP := 15

## Seasonal food production modifiers: spring, summer, fall, winter
## 8 ticks/year = 4 seasons x 2 ticks each
const SEASON_FOOD_MODIFIERS := [0.6, 1.2, 1.0, 0.3]

## Scenario loader instance
var _scenario_loader: ScenarioLoader = null

## Reference to ecosystem manager for tree density queries during relocation
var ecosystem_manager: EcosystemManager = null

## Reference to map data for terrain queries during relocation
var map_data: PlanetMapData = null

## Reference to planet map system for terrain type and elevation queries
var planet_map_system: PlanetMapSystem = null

## Reference to villager system for season modifier updates
var villager_system: VillagerSystem = null

## All villages: planet_id -> Array[VillageInstance]
var _villages_by_planet: Dictionary = {}

## Quick lookup: village_id -> VillageInstance
var _villages_by_id: Dictionary = {}

## Accumulated ticks for year tracking
var _tick_accumulator: int = 0

## Accumulated ticks for monthly pregnancy/birth
var _monthly_accumulator: int = 0

## Total monthly ticks since simulation start (for season derivation)
var _monthly_tick_total: int = 0

## Collapsed villages — preserved for event log history
var _collapsed_villages: Array[VillageInstance] = []

## Spatial hash: planet_id -> Dictionary(Vector2i -> true) for all active village clearing tiles.
## Rebuilt on village creation, relocation, split, collapse, longhouse add/remove.
var _village_area_cache: Dictionary = {}

## Camp position spatial index: planet_id -> Array[Vector2i] for fast proximity checks.
var _camp_positions_by_planet: Dictionary = {}

## Signals
signal village_population_changed(village_id: String, population: int)
signal person_born(village_id: String, person_name: String)
signal person_died(village_id: String, person_name: String)
signal village_era_changed(village_id: String, old_era: String, new_era: String)
signal village_collapsed(village_id: String)
signal longhouse_added(village_id: String, position: Vector2i, clearing_radius: int)
signal longhouse_removed(village_id: String, position: Vector2i)
signal village_relocated(village_id: String, old_center: Vector2i, new_center: Vector2i)
signal site_regrown(village_id: String, site_center: Vector2i, longhouse_positions: Array)
signal village_split(parent_id: String, child_id: String)


func _ready() -> void:
	_scenario_loader = ScenarioLoader.new()
	GameLog.info(LOG_TAG, "VillageManager initialized")


## Called by TimeManager's simulation_tick signal.
func on_simulation_tick(tick_number: int, _game_days: float) -> void:
	_tick_accumulator += 1
	_monthly_accumulator += 1

	# Monthly: pregnancy advancement, conception, births
	if _monthly_accumulator >= TICKS_PER_MONTH:
		_monthly_accumulator = 0
		_monthly_tick_total += 1
		_simulate_month()

	# Yearly: aging, deaths, era transitions, relocation, splits
	if _tick_accumulator >= TICKS_PER_YEAR:
		_tick_accumulator = 0
		_simulate_year(tick_number)


## Advance pregnancy and births for all villages (called monthly).
func _simulate_month() -> void:
	# Update season food modifier for VillagerSystem
	if villager_system:
		villager_system.current_season_food_mod = _get_season_food_modifier()
	for planet_id in _villages_by_planet:
		var villages: Array = _villages_by_planet[planet_id]
		for village in villages:
			if village.is_deflated and village.demographics:
				var cohesion: float = village.political_traits.get("cohesion", 0.5)
				var births: int = village.demographics.tick_month(village._rng, cohesion)
				if births > 0:
					village.log_event("birth", "%d children born" % births)
					emit_signal("village_population_changed", village.village_id, village.get_population())
				continue
			var born: Array[String] = village.tick_month()
			for person_name in born:
				village.log_event("birth", "%s was born" % person_name)
				emit_signal("person_born", village.village_id, person_name)
			if not born.is_empty():
				emit_signal("village_population_changed", village.village_id, village.get_population())


func _simulate_year(tick_number: int) -> void:
	# Update inter-village competition factors before ticking individual villages
	for planet_id in _villages_by_planet:
		_update_competition_factors(planet_id)

	var collapsed: Array[String] = []
	for planet_id in _villages_by_planet:
		var villages: Array = _villages_by_planet[planet_id]
		for village in villages:
			if _tick_village(village, tick_number):
				collapsed.append(village.village_id)
			# Tick abandoned sites for regrowth
			_tick_abandoned_sites(village)
	for vid in collapsed:
		_remove_village(vid)


## Get the current season index (0=spring, 1=summer, 2=fall, 3=winter).
func get_season_index() -> int:
	return (_monthly_tick_total / 2) % 4


## Get the current season's food production modifier.
func _get_season_food_modifier() -> float:
	return SEASON_FOOD_MODIFIERS[get_season_index()]


## Returns true if village collapsed and should be removed.
func _tick_village(village: VillageInstance, tick_number: int) -> bool:
	if village.is_deflated and village.demographics:
		return _tick_village_demographics(village)

	var events = village.tick_year(tick_number)

	# Emit death signals (births now handled monthly)
	for person_name in events.get("died", []):
		village.log_event("death", "%s died of old age" % person_name)
		emit_signal("person_died", village.village_id, person_name)

	# Emit population change
	emit_signal("village_population_changed", village.village_id, village.get_population())

	# Update longhouse count based on population
	_update_longhouse_count(village)

	# Check migration first (prefer joining existing villages over splitting)
	_check_migration(village)

	# Check if village should split (population pressure or resource pressure)
	_check_village_split(village)
	_check_resource_split(village)

	# Check firewood pressure — may trigger relocation
	_check_firewood_pressure(village)

	# Check for era progression
	_check_era_transition(village)

	# Check village viability
	if not village.is_viable():
		village.log_event("collapse", "Village collapsed (pop: %d)" % village.get_population())
		GameLog.warn(LOG_TAG, "Village %s is no longer viable (pop: %d)" % [village.village_id, village.get_population()])
		emit_signal("village_collapsed", village.village_id)
		return true

	GameLog.debug(LOG_TAG, village.get_summary())
	return false


## Tick a deflated village using demographic formulas.
func _tick_village_demographics(village: VillageInstance) -> bool:
	village.age_in_years += 1

	# Resource pressure: drift hunger/thirst, starvation deaths
	var season_mod := _get_season_food_modifier()
	var starvation := village.demographics.tick_resource_pressure(
		village.carrying_capacity, village.competition_factor, season_mod, village._rng
	)
	if starvation > 0:
		village.log_event("famine", "%d people died of starvation" % starvation)

	var deaths: int = village.demographics.tick_year(village._rng)
	if deaths > 0:
		village.log_event("death", "%d people died" % deaths)

	emit_signal("village_population_changed", village.village_id, village.get_population())
	_update_longhouse_count(village)
	_check_migration(village)
	_check_village_split(village)
	_check_resource_split(village)
	_check_firewood_pressure(village)
	_check_era_transition(village)

	if not village.is_viable():
		village.log_event("collapse", "Village collapsed (pop: %d)" % village.get_population())
		GameLog.warn(LOG_TAG, "Village %s is no longer viable (pop: %d)" % [village.village_id, village.get_population()])
		emit_signal("village_collapsed", village.village_id)
		return true

	GameLog.debug(LOG_TAG, village.get_summary())
	return false


func _check_era_transition(village: VillageInstance) -> void:
	var scenario = _scenario_loader.load_scenario(village.scenario_id)
	if scenario.is_empty():
		return

	var eras: Dictionary = scenario.get("eras", {})
	var current_era_data: Dictionary = eras.get(village.era, {})
	var next_era: String = current_era_data.get("next_era", "")

	if next_era.is_empty() or not eras.has(next_era):
		return

	var conditions: Dictionary = current_era_data.get("transition_conditions", {})
	if _era_conditions_met(village, conditions, scenario):
		var old_era = village.era
		village.era = next_era

		# Unlock new skills for the era
		var new_skills: Array = eras[next_era].get("unlocks", [])
		for skill in new_skills:
			if not village.group_knowledge.has(skill):
				village.group_knowledge.append(skill)
				GameLog.debug(LOG_TAG, "Village %s unlocked skill: %s" % [village.village_id, skill])

		village.log_event("era", "Advanced to %s era" % next_era.replace("_", " "))
		emit_signal("village_era_changed", village.village_id, old_era, next_era)
		GameLog.debug(LOG_TAG, "Village %s advanced to era: %s" % [village.village_id, next_era])


func _era_conditions_met(village: VillageInstance, conditions: Dictionary, _scenario: Dictionary) -> bool:
	if conditions.is_empty():
		return false

	# Population check
	var min_pop: int = conditions.get("min_population", 0)
	if village.get_population() < min_pop:
		return false

	# Deflated villages: use max_skill_levels from demographics
	if village.is_deflated and village.demographics:
		var required_skill: String = conditions.get("requires_skill", "")
		if not required_skill.is_empty():
			var min_level: int = conditions.get("min_skill_level", 0)
			if village.demographics.max_skill_levels.get(required_skill, 0) < min_level:
				return false
		var min_fishing: int = conditions.get("min_fishing_skill", 0)
		if min_fishing > 0:
			if village.demographics.max_skill_levels.get("fishing", 0) < min_fishing:
				return false
		return true

	# Inflated: check individual skill levels
	var required_skill: String = conditions.get("requires_skill", "")
	if not required_skill.is_empty():
		var min_level: int = conditions.get("min_skill_level", 0)
		var skill_found = false
		for person in village.individuals:
			if person.skills.get(required_skill, 0) >= min_level:
				skill_found = true
				break
		if not skill_found:
			return false

	var min_fishing: int = conditions.get("min_fishing_skill", 0)
	if min_fishing > 0:
		var best_fishing = 0
		for person in village.individuals:
			best_fishing = maxi(best_fishing, person.skills.get("fishing", 0))
		if best_fishing < min_fishing:
			return false

	return true


## Register a new village on a planet. Creates village from scenario config.
func register_village(planet_id: String, village_id: String, scenario_id: String, starting_territory: Array[Vector2i], is_player_village: bool = false) -> VillageInstance:
	var scenario = _scenario_loader.load_scenario(scenario_id)
	if scenario.is_empty():
		GameLog.error(LOG_TAG, "Cannot register village: scenario not found: %s" % scenario_id)
		return null

	var village = VillageInstance.new()
	village.initialize(village_id, planet_id, scenario_id, scenario)
	village.territory = starting_territory.duplicate()
	village.is_player_village = is_player_village

	var starting_pop: int = scenario.get("starting_population", 25)
	village.populate(starting_pop)

	if not _villages_by_planet.has(planet_id):
		_villages_by_planet[planet_id] = []
	_villages_by_planet[planet_id].append(village)
	_villages_by_id[village_id] = village

	# Estimate carrying capacity from local resources
	if village.camp_position != Vector2i(-1, -1):
		village.carrying_capacity = _estimate_carrying_capacity(village.camp_position)

	# Initialize relationships between all existing villages on this planet
	_initialize_village_relationships(planet_id, village)

	rebuild_village_area_cache(planet_id)

	GameLog.debug(LOG_TAG, "Registered village %s on planet %s (player: %s, pop: %d)" % [
		village_id, planet_id, str(is_player_village), village.get_population()
	])
	return village


func _initialize_village_relationships(planet_id: String, new_village: VillageInstance) -> void:
	var villages: Array = _villages_by_planet.get(planet_id, [])
	for existing_village in villages:
		if existing_village.village_id == new_village.village_id:
			continue
		# Both villages get a relationship entry initialized to UNKNOWN
		new_village.set_village_relationship(existing_village.village_id)
		existing_village.set_village_relationship(new_village.village_id)


func _remove_village(village_id: String) -> void:
	var village = _villages_by_id.get(village_id)
	if not village:
		return
	var planet_id = village.planet_id
	_villages_by_id.erase(village_id)
	if _villages_by_planet.has(planet_id):
		_villages_by_planet[planet_id].erase(village)
	# Archive for event log history
	_collapsed_villages.append(village)
	rebuild_village_area_cache(planet_id)
	GameLog.debug(LOG_TAG, "Village %s collapsed and archived" % village_id)


## Get collapsed villages (for UI display of historical event logs)
func get_collapsed_villages() -> Array[VillageInstance]:
	return _collapsed_villages


## Tick abandoned sites — transition to REGROWN after enough years
func _tick_abandoned_sites(village: VillageInstance) -> void:
	for site in village.past_sites:
		if site.status != SettlementSite.Status.ABANDONED:
			continue
		var years_abandoned := village.age_in_years - site.abandoned_year
		if years_abandoned >= REGROWTH_YEARS:
			site.status = SettlementSite.Status.REGROWN
			var positions: Array = []
			for pos in site.longhouse_positions:
				positions.append(pos)
			emit_signal("site_regrown", village.village_id, site.center, positions)
			GameLog.debug(LOG_TAG, "Village %s past site %s has regrown (%d years)" % [
				village.village_id, site.site_id, years_abandoned
			])


## Check if village population warrants splitting
func _check_village_split(village: VillageInstance) -> void:
	# Cooldown — village must wait after previous split
	if village.age_in_years - village.last_split_year < SPLIT_COOLDOWN_YEARS:
		return
	var max_pop := MAX_LONGHOUSES_PER_SITE * VillageInstance.LONGHOUSE_CAPACITY
	var threshold := int(max_pop * SPLIT_THRESHOLD_RATIO)
	if village.get_population() < threshold:
		return
	if village.get_adult_count() < 16:
		return
	if village.is_deflated:
		_split_village_demographics(village)
	else:
		_split_village(village)


## Check if stressed villagers should migrate to a nearby village with room.
## Preferred over splitting — redistributes population without creating fragile new villages.
func _check_migration(village: VillageInstance) -> void:
	if village.age_in_years - village.last_migration_year < MIGRATION_COOLDOWN_YEARS:
		return
	if village.get_population() < MIN_REMNANT_POP + 5:
		return

	# Check resource stress
	var under_stress := false
	if village.is_deflated and village.demographics:
		under_stress = village.demographics.avg_hunger < RESOURCE_SPLIT_HUNGER_THRESHOLD
	else:
		under_stress = village.food_stored < 0.25

	# Also trigger migration for population pressure (over carrying capacity)
	var pop := village.get_population()
	var effective_capacity := village.carrying_capacity * village.competition_factor
	if pop > int(effective_capacity):
		under_stress = true

	if not under_stress:
		return

	# Find best receiving village: nearby, below capacity, has room
	var best_target: VillageInstance = null
	var best_score := -1.0
	var villages: Array = _villages_by_planet.get(village.planet_id, [])
	var camp: Vector2i = village.camp_position

	for other in villages:
		var o: VillageInstance = other as VillageInstance
		if o.village_id == village.village_id:
			continue
		var dx: int = camp.x - o.camp_position.x
		var dy: int = camp.y - o.camp_position.y
		var dist_sq := dx * dx + dy * dy
		if dist_sq > MIGRATION_RANGE * MIGRATION_RANGE:
			continue

		# Check if target has room
		var target_pop := o.get_population()
		var target_capacity := o.carrying_capacity * o.competition_factor
		if target_pop >= int(target_capacity * MIGRATION_CAPACITY_RATIO):
			continue

		# Score: prefer closer villages with more room
		var room := target_capacity - float(target_pop)
		var dist := sqrt(float(dist_sq))
		var score := room / maxf(dist, 1.0)
		if score > best_score:
			best_score = score
			best_target = o

	if best_target == null:
		return

	# Determine migrant count (don't leave source below MIN_REMNANT_POP)
	var migrant_count := int(pop * MIGRATION_FRACTION)
	migrant_count = mini(migrant_count, pop - MIN_REMNANT_POP)
	if migrant_count < 3:
		return

	# Cap to available room at target
	var target_room := int(best_target.carrying_capacity * best_target.competition_factor) - best_target.get_population()
	migrant_count = mini(migrant_count, target_room)
	if migrant_count < 3:
		return

	_transfer_population(village, best_target, migrant_count)
	village.last_migration_year = village.age_in_years

	village.log_event("migration", "%d people migrated to %s" % [migrant_count, best_target.village_id])
	best_target.log_event("immigration", "%d people arrived from %s" % [migrant_count, village.village_id])
	GameLog.debug(LOG_TAG, "Migration: %d people from %s (pop: %d) to %s (pop: %d)" % [
		migrant_count, village.village_id, village.get_population(),
		best_target.village_id, best_target.get_population()
	])

	emit_signal("village_population_changed", village.village_id, village.get_population())
	emit_signal("village_population_changed", best_target.village_id, best_target.get_population())


## Transfer population between villages. Handles both inflated and deflated modes.
func _transfer_population(source: VillageInstance, target: VillageInstance, count: int) -> void:
	if source.is_deflated and source.demographics:
		# Deflated source: subtract from demographics
		var demo := source.demographics
		# Remove proportionally from age buckets
		var remaining := count
		for bi in [1, 0, 2]:  # adults first, then children, then elders
			var remove := mini(remaining, demo.age_buckets[bi])
			demo.age_buckets[bi] -= remove
			remaining -= remove
			if remaining <= 0:
				break
		demo.population -= count
		var male_ratio := float(demo.male_count) / float(demo.male_count + demo.female_count) if (demo.male_count + demo.female_count) > 0 else 0.5
		demo.male_count = int(round(demo.population * male_ratio))
		demo.female_count = demo.population - demo.male_count
	else:
		# Inflated source: move PersonInstances
		# Prefer young adults (matching split logic)
		var candidates: Array[PersonInstance] = []
		var others: Array[PersonInstance] = []
		for person in source.individuals:
			if person.age >= 15 and person.age <= 35:
				candidates.append(person)
			else:
				others.append(person)
		candidates.shuffle()
		others.shuffle()
		var migrants: Array[PersonInstance] = []
		for person in candidates:
			if migrants.size() >= count:
				break
			migrants.append(person)
		for person in others:
			if migrants.size() >= count:
				break
			if person.age >= 10:
				migrants.append(person)
		for person in migrants:
			source.individuals.erase(person)

	if target.is_deflated and target.demographics:
		# Deflated target: add to demographics
		var demo := target.demographics
		var adults_added := int(count * 0.7)
		var children_added := count - adults_added
		demo.age_buckets[1] += adults_added
		demo.age_buckets[0] += children_added
		demo.population += count
		var male_added := count / 2
		demo.male_count += male_added
		demo.female_count += count - male_added
	else:
		# Inflated target: if source was inflated, we have PersonInstances to add
		if not source.is_deflated:
			# Migrants already removed from source.individuals above — no separate list kept
			# Generate new people for target instead (simpler, avoids cross-reference issues)
			pass
		# Generate migrants as new people at target
		for _i in range(count):
			var sex = PersonInstance.Sex.MALE if target._rng.randi() % 2 == 0 else PersonInstance.Sex.FEMALE
			var age := 15 + target._rng.randi_range(0, 20)
			var person := target._create_person(sex, age)
			target.individuals.append(person)


## Check if resource shortages warrant a group splitting off to find better land.
## Smaller emigration than population-pressure splits — desperate migration.
func _check_resource_split(village: VillageInstance) -> void:
	# Shorter cooldown than population splits, but still enforced
	if village.age_in_years - village.last_split_year < RESOURCE_SPLIT_COOLDOWN_YEARS:
		return
	if village.get_population() < RESOURCE_SPLIT_MIN_POP:
		return
	if village.get_adult_count() < 8:
		return

	# Check resource stress
	var under_stress := false
	if village.is_deflated and village.demographics:
		under_stress = village.demographics.avg_hunger < RESOURCE_SPLIT_HUNGER_THRESHOLD
	else:
		under_stress = village.food_stored < 0.2

	if not under_stress:
		return

	# Population must also exceed carrying capacity for split to make sense
	var pop := village.get_population()
	if pop <= int(village.carrying_capacity * village.competition_factor):
		return

	village.log_event("emigration", "A group left seeking better land (food shortage)")
	GameLog.debug(LOG_TAG, "Village %s resource-pressure split (hunger: %.2f, pop: %d, capacity: %.0f)" % [
		village.village_id,
		village.demographics.avg_hunger if village.is_deflated and village.demographics else village.food_stored,
		pop, village.carrying_capacity * village.competition_factor
	])

	if village.is_deflated:
		_split_village_demographics(village, RESOURCE_SPLIT_FRACTION)
	else:
		_split_village(village, RESOURCE_SPLIT_FRACTION)


## Split a village — take a fraction of population (prefer young adults) to found a new village.
func _split_village(village: VillageInstance, fraction: float = 0.4) -> void:
	var pop := village.get_population()
	var split_count := int(pop * fraction)
	if split_count < MIN_REMNANT_POP or (pop - split_count) < MIN_REMNANT_POP:
		return

	# Prefer younger adults (15-35) for the splinter group
	var candidates: Array[PersonInstance] = []
	var others: Array[PersonInstance] = []
	for person in village.individuals:
		if person.age >= 15 and person.age <= 35:
			candidates.append(person)
		else:
			others.append(person)

	var emigrants: Array[PersonInstance] = []
	# Shuffle candidates deterministically using village RNG
	var shuffled := candidates.duplicate()
	if village._rng:
		for i in range(shuffled.size() - 1, 0, -1):
			var j := village._rng.randi_range(0, i)
			var tmp = shuffled[i]
			shuffled[i] = shuffled[j]
			shuffled[j] = tmp

	# Take from young adults first, then others if needed
	for person in shuffled:
		if emigrants.size() >= split_count:
			break
		emigrants.append(person)
	if emigrants.size() < split_count:
		for person in others:
			if emigrants.size() >= split_count:
				break
			if person.age >= 10:
				emigrants.append(person)

	if emigrants.size() < MIN_REMNANT_POP:
		return
	if (village.get_population() - emigrants.size()) < MIN_REMNANT_POP:
		return

	# Remove emigrants from parent
	for person in emigrants:
		village.individuals.erase(person)

	# Find a site for the new village
	var new_center := _find_relocation_site(village)
	if new_center == Vector2i(-1, -1):
		# Can't find a site — return emigrants
		for person in emigrants:
			village.individuals.append(person)
		GameLog.debug(LOG_TAG, "Village %s split failed: no suitable site found" % village.village_id)
		return

	# Generate unique village ID
	var split_id := "%s_split_%d" % [village.village_id, _villages_by_id.size()]

	# Register new village (this calls populate(), but we'll replace the population)
	var child = register_village(village.planet_id, split_id, village.scenario_id, [], false)
	if child == null:
		# Registration failed — return emigrants
		for person in emigrants:
			village.individuals.append(person)
		return

	# Replace auto-populated individuals with actual emigrants
	child.individuals.clear()
	for person in emigrants:
		child.individuals.append(person)

	# Set up the new village's site
	child.camp_position = new_center
	child.active_site.layout_longhouses(child.get_population(), VillageInstance.LONGHOUSE_CAPACITY, _get_terrain_validator())
	child.carrying_capacity = _estimate_carrying_capacity(new_center)

	# Copy group knowledge and era from parent
	child.group_knowledge = village.group_knowledge.duplicate()
	child.era = village.era

	village.last_split_year = village.age_in_years
	village.log_event("split", "%d people departed to found %s" % [child.get_population(), split_id])
	child.log_event("founded", "Founded by settlers from %s" % village.village_id)
	emit_signal("village_split", village.village_id, split_id)
	GameLog.debug(LOG_TAG, "Village %s split: %d people left for new village %s at %s" % [
		village.village_id, emigrants.size(), split_id, str(new_center)
	])


## Split a deflated village using demographic math (no PersonInstance creation).
func _split_village_demographics(village: VillageInstance, fraction: float = 0.4) -> void:
	if not village.demographics:
		return
	var demo_pop := village.demographics.population
	var split_count := int(demo_pop * fraction)
	if split_count < MIN_REMNANT_POP or (demo_pop - split_count) < MIN_REMNANT_POP:
		return

	var new_center := _find_relocation_site(village)
	if new_center == Vector2i(-1, -1):
		GameLog.debug(LOG_TAG, "Village %s demographic split failed: no suitable site found" % village.village_id)
		return

	var split_id := "%s_split_%d" % [village.village_id, _villages_by_id.size()]

	# Create child demographics from parent
	var child_demo := village.demographics.split(fraction, village._rng)

	# Register new village — will auto-populate, but we override
	var child = register_village(village.planet_id, split_id, village.scenario_id, [], false)
	if child == null:
		# Undo split — add child demo back to parent
		village.demographics.population += child_demo.population
		village.demographics.male_count += child_demo.male_count
		village.demographics.female_count += child_demo.female_count
		for i in range(3):
			village.demographics.age_buckets[i] += child_demo.age_buckets[i]
		return

	# Override with demographic data
	child.individuals.clear()
	child.demographics = child_demo
	child.is_deflated = true

	child.camp_position = new_center
	child.active_site.layout_longhouses(child.get_population(), VillageInstance.LONGHOUSE_CAPACITY, _get_terrain_validator())
	child.carrying_capacity = _estimate_carrying_capacity(new_center)
	child.group_knowledge = village.group_knowledge.duplicate()
	child.era = village.era

	village.last_split_year = village.age_in_years
	village.log_event("split", "%d people departed to found %s" % [child.get_population(), split_id])
	child.log_event("founded", "Founded by settlers from %s" % village.village_id)
	emit_signal("village_split", village.village_id, split_id)
	GameLog.debug(LOG_TAG, "Village %s demographic split: %d people to %s at %s" % [
		village.village_id, child.get_population(), split_id, str(new_center)
	])


## Check if firewood pressure warrants relocation
func _check_firewood_pressure(village: VillageInstance) -> void:
	if village.active_site == null:
		return
	var avg_dist := village.active_site.get_average_firewood_distance()
	village.active_site.reset_firewood_tracking()
	if avg_dist > FIREWOOD_PRESSURE_THRESHOLD:
		GameLog.debug(LOG_TAG, "Village %s firewood pressure high (avg distance: %.1f tiles)" % [
			village.village_id, avg_dist
		])
		_consider_relocation(village)


## Attempt to relocate village to a better site
func _consider_relocation(village: VillageInstance) -> void:
	# First check if any past site has regrown
	for site in village.past_sites:
		if site.status == SettlementSite.Status.REGROWN:
			var old_center := village.active_site.center
			_relocate_village(village, site.center, site)
			GameLog.debug(LOG_TAG, "Village %s returning to regrown site %s" % [village.village_id, site.site_id])
			return

	# Otherwise find a new site by tree density
	var new_center := _find_relocation_site(village)
	if new_center == Vector2i(-1, -1):
		GameLog.debug(LOG_TAG, "Village %s cannot find relocation site" % village.village_id)
		return
	_relocate_village(village, new_center, null)


## Search for a new camp site with dense forest for firewood
func _find_relocation_site(village: VillageInstance) -> Vector2i:
	var current_center := village.camp_position
	var best_pos := Vector2i(-1, -1)
	var best_score := -1.0

	# Search in expanding rings, starting well away from parent
	for radius in range(150, 601, 20):
		# Sample 24 points around the ring for better coverage
		for angle_step in range(24):
			var angle := float(angle_step) / 24.0 * TAU
			var candidate := current_center + Vector2i(
				int(cos(angle) * radius),
				int(sin(angle) * radius)
			)

			# Bounds check
			if map_data:
				candidate = candidate.clamp(Vector2i(10, 10), map_data.map_size - Vector2i(10, 10))

			if not _is_valid_camp_position(candidate, village.planet_id):
				continue

			if _too_close_to_other_villages(candidate, village):
				continue

			# Score: tree density + distance bonus (prefer further away for spread)
			var score := 0.0
			if ecosystem_manager:
				score += float(ecosystem_manager.get_tree_count_near(village.planet_id, candidate, 15))
			else:
				score += 10.0
			# Strong distance bonus — encourages wider spread across the map
			score += float(radius) * 0.15

			if score > best_score:
				best_score = score
				best_pos = candidate

		# Accept once we have a decent site and searched enough
		if best_score > 15.0 and radius >= 250:
			break

	return best_pos


## Returns a Callable(Vector2i) -> bool for terrain validation (water/elevation check).
## Used by SettlementSite to filter longhouse positions.
func _get_terrain_validator() -> Callable:
	if planet_map_system and planet_map_system.chunk_manager and planet_map_system.chunk_manager.terrain_source:
		var source = planet_map_system.chunk_manager.terrain_source
		return func(pos: Vector2i) -> bool:
			var tile_type: int = source.get_tile_type_at_tile(pos)
			if tile_type == PlanetMapTileConfig.TileType.FRESH_WATER:
				return false
			var elevation: float = source.get_elevation_at_tile(pos)
			if elevation > 0.75:
				return false
			return true
	return Callable()


## Check if a position is valid for a village camp
func _is_valid_camp_position(pos: Vector2i, _planet_id: String) -> bool:
	if map_data == null:
		return true
	if pos.x < 1 or pos.y < 1 or pos.x >= map_data.map_size.x - 1 or pos.y >= map_data.map_size.y - 1:
		return false
	# Check terrain type — must not be water
	if planet_map_system and planet_map_system.chunk_manager and planet_map_system.chunk_manager.terrain_source:
		var tile_type: int = planet_map_system.chunk_manager.terrain_source.get_tile_type_at_tile(pos)
		if tile_type == PlanetMapTileConfig.TileType.FRESH_WATER:
			return false
		# Check elevation — avoid high ground
		var elevation: float = planet_map_system.chunk_manager.terrain_source.get_elevation_at_tile(pos)
		if elevation > 0.75:
			return false
	return true


## Check if candidate position is too close to any existing village.
## Uses cached camp positions for O(V) with no object overhead.
func _too_close_to_other_villages(candidate: Vector2i, excluding_village: VillageInstance) -> bool:
	var camps: Array = _camp_positions_by_planet.get(excluding_village.planet_id, [])
	var exclude_pos := excluding_village.camp_position
	var min_sq := MIN_CAMP_SPACING * MIN_CAMP_SPACING
	for camp_pos in camps:
		if camp_pos == exclude_pos:
			continue
		var dx: int = candidate.x - camp_pos.x
		var dy: int = candidate.y - camp_pos.y
		if dx * dx + dy * dy < min_sq:
			return true
	return false


## Execute village relocation to a new (or returning) site
func _relocate_village(village: VillageInstance, new_center: Vector2i, returning_site: SettlementSite) -> void:
	var old_center := village.camp_position

	# Abandon current site
	if village.active_site:
		village.active_site.status = SettlementSite.Status.ABANDONED
		village.active_site.abandoned_year = village.age_in_years
		village.past_sites.append(village.active_site)

	# Create or reactivate site
	if returning_site:
		# Returning to a regrown site
		village.past_sites.erase(returning_site)
		returning_site.status = SettlementSite.Status.ACTIVE
		returning_site.abandoned_year = -1
		returning_site.reset_firewood_tracking()
		returning_site.layout_longhouses(village.get_population(), VillageInstance.LONGHOUSE_CAPACITY, _get_terrain_validator())
		village.active_site = returning_site
	else:
		# New site
		village._create_initial_site(new_center)
		village.active_site.layout_longhouses(village.get_population(), VillageInstance.LONGHOUSE_CAPACITY, _get_terrain_validator())

	rebuild_village_area_cache(village.planet_id)
	village.carrying_capacity = _estimate_carrying_capacity(village.camp_position)
	village.log_event("relocate", "Relocated camp to %s" % str(village.camp_position))
	emit_signal("village_relocated", village.village_id, old_center, village.camp_position)
	GameLog.debug(LOG_TAG, "Village %s relocated from %s to %s (%d longhouses)" % [
		village.village_id, str(old_center), str(village.camp_position),
		village.active_site.longhouse_positions.size()
	])


## Add or remove longhouses to match population needs
func _update_longhouse_count(village: VillageInstance) -> void:
	if village.active_site == null:
		return
	var needed := village.longhouse_count()
	var current := village.active_site.longhouse_positions.size()
	var changed := false
	if needed > current:
		for i in range(current, needed):
			var new_pos := village.active_site.add_longhouse(_get_terrain_validator())
			village.log_event("build", "Built longhouse %d" % village.active_site.longhouse_positions.size())
			emit_signal("longhouse_added", village.village_id, new_pos, village.active_site.clearing_radius)
			GameLog.debug(LOG_TAG, "Village %s built longhouse %d at %s (clearing radius: %d)" % [
				village.village_id, village.active_site.longhouse_positions.size(), str(new_pos), village.active_site.clearing_radius
			])
		changed = true
	elif needed < current and current > 1:
		while village.active_site.longhouse_positions.size() > needed and village.active_site.longhouse_positions.size() > 1:
			var removed := village.active_site.remove_last_longhouse()
			if removed != Vector2i(-1, -1):
				emit_signal("longhouse_removed", village.village_id, removed)
				GameLog.debug(LOG_TAG, "Village %s abandoned longhouse at %s (pop declined)" % [
					village.village_id, str(removed)
				])
		changed = true
	if changed:
		rebuild_village_area_cache(village.planet_id)


## Update competition factors for all villages on a planet.
## Villages with overlapping foraging zones reduce each other's food efficiency.
func _update_competition_factors(planet_id: String) -> void:
	var villages: Array = _villages_by_planet.get(planet_id, [])
	const FORAGING_RADIUS := 200
	var overlap_dist_sq := (FORAGING_RADIUS * 2) * (FORAGING_RADIUS * 2)

	for village in villages:
		var neighbors := 0
		var v: VillageInstance = village as VillageInstance
		var camp: Vector2i = v.camp_position
		for other in villages:
			var o: VillageInstance = other as VillageInstance
			if o.village_id == v.village_id:
				continue
			var dx: int = camp.x - o.camp_position.x
			var dy: int = camp.y - o.camp_position.y
			if dx * dx + dy * dy < overlap_dist_sq:
				neighbors += 1
		# Floor at 0.5 — even crowded villages can sustain half their carrying capacity
		v.competition_factor = maxf(0.5, 1.0 / (1.0 + float(neighbors) * 0.4))


## Estimate carrying capacity for a village at given position based on nearby berry bushes.
## Samples every SAMPLE_STEP tiles in FORAGING_RADIUS — raw hit count used directly.
func _estimate_carrying_capacity(center: Vector2i) -> float:
	const BASE_CARRYING_CAPACITY := 50.0
	const CARRYING_CAPACITY_PER_BERRY := 0.3
	const FORAGING_RADIUS := 200
	const SAMPLE_STEP := 10

	if not planet_map_system:
		return BASE_CARRYING_CAPACITY

	var berry_count := 0
	for dx in range(-FORAGING_RADIUS, FORAGING_RADIUS + 1, SAMPLE_STEP):
		for dy in range(-FORAGING_RADIUS, FORAGING_RADIUS + 1, SAMPLE_STEP):
			var pos := center + Vector2i(dx, dy)
			if planet_map_system.has_berry_at(pos):
				berry_count += 1
	# Use raw sampled count directly — no upscaling
	return BASE_CARRYING_CAPACITY + float(berry_count) * CARRYING_CAPACITY_PER_BERRY


func get_village(village_id: String) -> VillageInstance:
	var v = _villages_by_id.get(village_id, null)
	if v:
		return v
	# Check collapsed villages
	for cv in _collapsed_villages:
		if cv.village_id == village_id:
			return cv
	return null


func get_villages_on_planet(planet_id: String) -> Array:
	return _villages_by_planet.get(planet_id, [])


func get_player_village(planet_id: String) -> VillageInstance:
	for village in get_villages_on_planet(planet_id):
		if village.is_player_village:
			return village
	return null


## Returns true if any village has a longhouse at this position on this planet
func has_village_at(p_planet_id: String, pos: Vector2i) -> bool:
	for village in get_villages_on_planet(p_planet_id):
		if village.active_site and village.active_site.has_longhouse_at(pos):
			return true
	return false


## Returns true if pos is within the clearing area around any active village site.
## Uses O(1) spatial hash lookup instead of iterating all villages.
func is_in_village_area(p_planet_id: String, pos: Vector2i) -> bool:
	if not _village_area_cache.has(p_planet_id):
		return false
	return _village_area_cache[p_planet_id].has(pos)


## Rebuild the spatial hash for all village clearing areas on a planet.
## Call after any mutation: village create, relocate, split, collapse, longhouse add/remove.
## Public so external code (e.g. tests) can trigger rebuild after direct site mutations.
func rebuild_village_area_cache(planet_id: String) -> void:
	var cache: Dictionary = {}
	var camps: Array = []
	for village in get_villages_on_planet(planet_id):
		if village.active_site == null or village.active_site.status != SettlementSite.Status.ACTIVE:
			continue
		var center: Vector2i = village.active_site.center
		var r: int = village.active_site.clearing_radius
		for dx in range(-r, r + 1):
			for dy in range(-r, r + 1):
				cache[center + Vector2i(dx, dy)] = true
		camps.append(village.camp_position)
	_village_area_cache[planet_id] = cache
	_camp_positions_by_planet[planet_id] = camps


## Returns the village that has a longhouse at this position, or null
func get_village_at_camp(p_planet_id: String, pos: Vector2i) -> VillageInstance:
	for village in get_villages_on_planet(p_planet_id):
		if village.active_site and village.active_site.has_longhouse_at(pos):
			return village
	return null


## Returns all longhouse positions across all villages on a planet
func get_all_longhouse_positions_on_planet(p_planet_id: String) -> Array[Vector2i]:
	var positions: Array[Vector2i] = []
	for village in get_villages_on_planet(p_planet_id):
		for pos in village.get_all_longhouse_positions():
			positions.append(pos)
	return positions


## Export all village data for a planet (for save/load)
func export_villages(planet_id: String) -> Dictionary:
	var villages_data: Array = []
	for village in get_villages_on_planet(planet_id):
		villages_data.append(village.to_dict())
	var collapsed_data: Array = []
	for village in _collapsed_villages:
		if village.planet_id == planet_id:
			collapsed_data.append(village.to_dict())
	return {
		"villages": villages_data,
		"collapsed": collapsed_data,
		"tick_accumulator": _tick_accumulator,
		"monthly_accumulator": _monthly_accumulator,
		"monthly_tick_total": _monthly_tick_total,
	}


## Import village data for a planet (from save/load).
## Returns the imported villages so the caller can set up villager sprites.
func import_villages(planet_id: String, data: Dictionary) -> Array[VillageInstance]:
	var imported: Array[VillageInstance] = []

	# Clear existing villages for this planet
	if _villages_by_planet.has(planet_id):
		for village in _villages_by_planet[planet_id]:
			_villages_by_id.erase(village.village_id)
		_villages_by_planet[planet_id] = []

	# Remove collapsed villages for this planet
	var kept_collapsed: Array[VillageInstance] = []
	for cv in _collapsed_villages:
		if cv.planet_id != planet_id:
			kept_collapsed.append(cv)
	_collapsed_villages = kept_collapsed

	# Restore active villages
	var villages_data: Array = data.get("villages", [])
	for village_data in villages_data:
		var village := VillageInstance.from_dict(village_data)
		if not _villages_by_planet.has(planet_id):
			_villages_by_planet[planet_id] = []
		_villages_by_planet[planet_id].append(village)
		_villages_by_id[village.village_id] = village
		imported.append(village)

	# Restore collapsed villages
	var collapsed_data: Array = data.get("collapsed", [])
	for village_data in collapsed_data:
		var village := VillageInstance.from_dict(village_data)
		_collapsed_villages.append(village)

	# Restore accumulators
	_tick_accumulator = data.get("tick_accumulator", 0)
	_monthly_accumulator = data.get("monthly_accumulator", 0)
	_monthly_tick_total = data.get("monthly_tick_total", 0)

	rebuild_village_area_cache(planet_id)

	GameLog.info(LOG_TAG, "Imported %d villages + %d collapsed for planet %s" % [
		imported.size(), collapsed_data.size(), planet_id
	])
	return imported
