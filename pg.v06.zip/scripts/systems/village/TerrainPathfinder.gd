class_name TerrainPathfinder
extends RefCounted

## A* pathfinder on the tile grid with terrain-aware movement costs.
## Elevation differences increase cost; water tiles are passable but heavily penalized.
## Used by VillagePathCache to compute and cache routes between villages and resources.

const MAX_OPEN_SET := 5000
const ELEVATION_COST_PER_LAYER := 3.0
const WATER_COST := 20.0
const MAX_TRAVERSABLE_LAYERS := 2

## Trail affinity — discount step cost for tiles on existing village paths.
## New routes naturally merge onto established trunks and branch near destinations.
const TRAIL_DISCOUNT_PER_TRAVERSAL := 0.15  # 15% cheaper per traversal on the tile
const TRAIL_DISCOUNT_MAX := 0.80             # cap at 80% cost reduction

## Isometric-aware movement costs based on actual screen-space distances.
## Grid transform: world = ((x-y)*80, (x+y)*40)
## (1,1)/(-1,-1) = 80px on screen (vertical iso movement) — cheapest
## (1,0)/(0,1) etc = ~89px on screen (diagonal iso movement) — medium
## (1,-1)/(-1,1) = 160px on screen (horizontal iso movement) — most expensive
const ISO_VERTICAL_COST := 1.0    # (1,1), (-1,-1) — along iso vertical axis (80px screen)
const ISO_CARDINAL_COST := 1.1    # (1,0), (-1,0), (0,1), (0,-1) — iso diagonals (89px screen)
const ISO_HORIZONTAL_COST := 2.0  # (1,-1), (-1,1) — along iso horizontal axis (160px screen)

## 8-connected neighbor offsets (cardinal + diagonal)
const NEIGHBORS := [
	Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1),
	Vector2i(1, 1), Vector2i(1, -1), Vector2i(-1, 1), Vector2i(-1, -1),
]

var _planet_map_system = null  # PlanetMapSystem — untyped to avoid circular deps


func _init(planet_map_system) -> void:
	_planet_map_system = planet_map_system


## Find a path from start to end using A*. Returns Array[Vector2i] (inclusive of both
## endpoints), or an empty array if no path exists or the search budget is exhausted.
## trail_tiles: optional Dictionary(Vector2i -> int) of existing traversal counts.
## Tiles on established trails get a cost discount, causing new paths to merge onto
## existing trunks and branch organically near their destinations.
func find_path(start: Vector2i, end: Vector2i, trail_tiles: Dictionary = {}) -> Array[Vector2i]:
	if start == end:
		return [start]

	var use_trails := not trail_tiles.is_empty()

	# open_set: sorted Array of [f_score, g_score, pos]
	var open_set: Array = [[_heuristic(start, end), 0.0, start]]
	var came_from: Dictionary = {}  # Vector2i -> Vector2i
	var g_scores: Dictionary = {start: 0.0}
	var closed: Dictionary = {}
	var nodes_visited: int = 0

	while not open_set.is_empty() and nodes_visited < MAX_OPEN_SET:
		var current_entry: Array = open_set.pop_front()
		var current_g: float = current_entry[1]
		var current: Vector2i = current_entry[2]

		if current == end:
			return _reconstruct_path(came_from, current)

		if closed.has(current):
			continue
		closed[current] = true
		nodes_visited += 1

		for offset in NEIGHBORS:
			var neighbor: Vector2i = current + offset
			if closed.has(neighbor):
				continue

			var cost := step_cost(current, neighbor)
			if cost == INF:
				continue

			# Discount for tiles on existing village trails — paths merge onto
			# established routes rather than running parallel
			if use_trails:
				var count: int = trail_tiles.get(neighbor, 0)
				if count > 0:
					var discount: float = minf(TRAIL_DISCOUNT_MAX, float(count) * TRAIL_DISCOUNT_PER_TRAVERSAL)
					cost *= (1.0 - discount)

			var tentative_g: float = current_g + cost
			var prev_g: float = g_scores.get(neighbor, INF)
			if tentative_g < prev_g:
				g_scores[neighbor] = tentative_g
				came_from[neighbor] = current
				var f: float = tentative_g + _heuristic(neighbor, end)
				_insert_sorted(open_set, [f, tentative_g, neighbor])

	return []  # No path found within budget


## Movement cost for a single step from one tile to an adjacent tile.
## Returns INF if the step is impassable.
func step_cost(from: Vector2i, to: Vector2i) -> float:
	var diff := to - from
	var base: float
	if diff.x == diff.y or diff.x == -diff.y:
		# Diagonal grid step
		if diff.x == diff.y:
			base = ISO_VERTICAL_COST    # (1,1) or (-1,-1) — short iso vertical
		else:
			base = ISO_HORIZONTAL_COST  # (1,-1) or (-1,1) — long iso horizontal
	else:
		base = ISO_CARDINAL_COST        # (1,0), (0,1), etc — medium iso diagonal

	if not _planet_map_system:
		return base

	var from_elevation: float = _planet_map_system.get_elevation_at(from)
	var to_elevation: float = _planet_map_system.get_elevation_at(to)
	var from_layer: int = PlanetMapTileConfig.get_render_layer(from_elevation)
	var to_layer: int = PlanetMapTileConfig.get_render_layer(to_elevation)
	var layer_delta: int = absi(to_layer - from_layer)

	if layer_delta > MAX_TRAVERSABLE_LAYERS:
		return INF

	# Elevation penalty
	var elevation_penalty: float = float(layer_delta) * ELEVATION_COST_PER_LAYER

	# Water penalty
	var water_penalty: float = 0.0
	if _planet_map_system.is_water_tile(to):
		water_penalty = WATER_COST

	return base + elevation_penalty + water_penalty


## Isometric-aware heuristic. Uses the cheapest possible combination of
## iso-vertical (cost 1.0) and iso-cardinal (cost 1.118) steps.
## Admissible: never overestimates actual path cost.
static func _heuristic(a: Vector2i, b: Vector2i) -> float:
	var dx: int = absi(a.x - b.x)
	var dy: int = absi(a.y - b.y)
	# Diagonal iso-vertical steps cover both dx and dy at cost 1.0 each
	var diag: int = mini(dx, dy)
	# Remaining cardinal steps at cost 1.118 each
	var straight: int = maxi(dx, dy) - diag
	return float(diag) * ISO_VERTICAL_COST + float(straight) * ISO_CARDINAL_COST


## Insert entry into sorted array by f_score (index 0). Binary search insertion.
static func _insert_sorted(arr: Array, entry: Array) -> void:
	var f: float = entry[0]
	var lo: int = 0
	var hi: int = arr.size()
	while lo < hi:
		var mid: int = (lo + hi) / 2
		if arr[mid][0] < f:
			lo = mid + 1
		else:
			hi = mid
	arr.insert(lo, entry)


## Reconstruct the path by walking came_from links backwards.
static func _reconstruct_path(came_from: Dictionary, current: Vector2i) -> Array[Vector2i]:
	var path: Array[Vector2i] = [current]
	while came_from.has(current):
		current = came_from[current]
		path.append(current)
	path.reverse()
	return path


## Remove collinear waypoints, keeping start, end, and direction changes.
static func simplify_path(path: Array[Vector2i]) -> Array[Vector2i]:
	if path.size() <= 2:
		return path
	var result: Array[Vector2i] = [path[0]]
	for i in range(1, path.size() - 1):
		var prev_dir := path[i] - path[i - 1]
		var next_dir := path[i + 1] - path[i]
		if prev_dir != next_dir:
			result.append(path[i])
	result.append(path[path.size() - 1])
	return result
