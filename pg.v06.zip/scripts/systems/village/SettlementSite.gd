class_name SettlementSite
extends RefCounted

## Represents a physical location where a village has built longhouses.
## Sites can be ACTIVE (currently occupied), ABANDONED (recently vacated),
## or REGROWN (forest has reclaimed the clearing).
## Villages cycle between sites based on firewood availability.

enum Status { ACTIVE, ABANDONED, REGROWN }

## Unique identifier for this site (e.g. "village_player_site_0")
var site_id: String = ""

## Grid position of the site center (first longhouse)
var center: Vector2i = Vector2i(-1, -1)

## Current status of this site
var status: int = Status.ACTIVE

## Grid positions of all longhouses at this site
var longhouse_positions: Array[Vector2i] = []

## Clearing radius grows with longhouse count: 4 + (longhouse_count - 1)
var clearing_radius: int = 4

## Game year this site was established
var established_year: int = 0

## Game year this site was abandoned (-1 if still active)
var abandoned_year: int = -1

## Firewood pressure tracking (reset each game year)
var firewood_distance_sum: float = 0.0
var firewood_trip_count: int = 0

## Spacing between longhouses in tiles
const LONGHOUSE_SPACING := 3


func initialize(p_site_id: String, p_center: Vector2i, p_year: int = 0) -> void:
	site_id = p_site_id
	center = p_center
	established_year = p_year
	status = Status.ACTIVE
	abandoned_year = -1
	longhouse_positions = [p_center]
	clearing_radius = 4


func get_average_firewood_distance() -> float:
	if firewood_trip_count == 0:
		return 0.0
	return firewood_distance_sum / float(firewood_trip_count)


func reset_firewood_tracking() -> void:
	firewood_distance_sum = 0.0
	firewood_trip_count = 0


## Add a new longhouse position. Returns the position chosen.
## Places longhouses in a compact cluster around center using ring layout.
## Optional validator callable(Vector2i) -> bool filters out invalid terrain (water, etc).
func add_longhouse(validator: Callable = Callable()) -> Vector2i:
	var new_pos := _find_next_valid_position(validator)
	longhouse_positions.append(new_pos)
	clearing_radius = _calc_clearing_radius()
	return new_pos


## Remove the last longhouse (population decline). Returns removed position.
## Never removes the first longhouse (site center).
func remove_last_longhouse() -> Vector2i:
	if longhouse_positions.size() <= 1:
		return Vector2i(-1, -1)
	var removed := longhouse_positions[-1]
	longhouse_positions.pop_back()
	clearing_radius = 4 + (longhouse_positions.size() - 1)
	return removed


## Check if a grid position has a longhouse on it
func has_longhouse_at(pos: Vector2i) -> bool:
	return pos in longhouse_positions


## Check if a grid position is within the clearing area of this site
func is_in_clearing(pos: Vector2i) -> bool:
	var diff := pos - center
	return abs(diff.x) <= clearing_radius and abs(diff.y) <= clearing_radius


## Layout longhouses for a given population and capacity.
## Called when creating or reactivating a site.
func layout_longhouses(population: int, capacity: int, validator: Callable = Callable()) -> void:
	var needed := ceili(float(population) / float(capacity)) if population > 0 else 1
	needed = maxi(needed, 1)
	longhouse_positions = [center]
	for i in range(1, needed):
		longhouse_positions.append(_find_next_valid_position(validator))
	clearing_radius = _calc_clearing_radius()


## Find next valid cluster position, skipping positions that fail validation or are already used.
## Tries up to MAX_SLOT_SEARCH slots to find a valid one.
const MAX_SLOT_SEARCH := 24
func _find_next_valid_position(validator: Callable) -> Vector2i:
	var start_index := longhouse_positions.size()
	for offset in range(MAX_SLOT_SEARCH):
		var candidate := _get_cluster_position(start_index + offset)
		if candidate in longhouse_positions:
			continue
		if validator.is_valid() and not validator.call(candidate):
			continue
		return candidate
	# Fallback: use the raw position if no valid slot found
	return _get_cluster_position(start_index)


## Compact cluster positions around center. Index 0 = center, then ring slots.
## Ring 1 (indices 1-6): 6 positions around center at LONGHOUSE_SPACING distance
## Ring 2 (indices 7-18): 12 positions at 2x spacing distance
func _get_cluster_position(index: int) -> Vector2i:
	if index == 0:
		return center
	# Ring 1: 6 positions in hex-like pattern
	var ring1 := [
		Vector2i(LONGHOUSE_SPACING, 0),                         # E
		Vector2i(-LONGHOUSE_SPACING, 0),                        # W
		Vector2i(0, LONGHOUSE_SPACING),                         # S
		Vector2i(0, -LONGHOUSE_SPACING),                        # N
		Vector2i(LONGHOUSE_SPACING, LONGHOUSE_SPACING),         # SE
		Vector2i(-LONGHOUSE_SPACING, -LONGHOUSE_SPACING),       # NW
	]
	if index <= ring1.size():
		return center + ring1[index - 1]
	# Ring 2: 12 positions at double spacing
	var r2 := LONGHOUSE_SPACING * 2
	var ring2 := [
		Vector2i(r2, 0), Vector2i(-r2, 0),
		Vector2i(0, r2), Vector2i(0, -r2),
		Vector2i(r2, LONGHOUSE_SPACING), Vector2i(-r2, LONGHOUSE_SPACING),
		Vector2i(r2, -LONGHOUSE_SPACING), Vector2i(-r2, -LONGHOUSE_SPACING),
		Vector2i(LONGHOUSE_SPACING, r2), Vector2i(-LONGHOUSE_SPACING, r2),
		Vector2i(LONGHOUSE_SPACING, -r2), Vector2i(-LONGHOUSE_SPACING, -r2),
	]
	var r2_idx := index - ring1.size() - 1
	if r2_idx < ring2.size():
		return center + ring2[r2_idx]
	# Overflow: extend further out in a grid pattern
	var overflow := index - ring1.size() - ring2.size()
	var row := overflow / 5
	var col := overflow % 5
	return center + Vector2i((col - 2) * LONGHOUSE_SPACING, (row + 3) * LONGHOUSE_SPACING)


func _calc_clearing_radius() -> int:
	if longhouse_positions.size() <= 1:
		return 4
	var max_dist := 0
	for pos in longhouse_positions:
		var diff := pos - center
		max_dist = maxi(max_dist, maxi(abs(diff.x), abs(diff.y)))
	return max_dist + 3


func to_dict() -> Dictionary:
	var positions: Array = []
	for pos in longhouse_positions:
		positions.append({"x": pos.x, "y": pos.y})
	return {
		"site_id": site_id,
		"center_x": center.x,
		"center_y": center.y,
		"status": status,
		"longhouse_positions": positions,
		"clearing_radius": clearing_radius,
		"established_year": established_year,
		"abandoned_year": abandoned_year,
	}


static func from_dict(data: Dictionary) -> SettlementSite:
	var site := SettlementSite.new()
	site.site_id = data.get("site_id", "")
	site.center = Vector2i(data.get("center_x", -1), data.get("center_y", -1))
	site.status = data.get("status", Status.ACTIVE)
	site.clearing_radius = data.get("clearing_radius", 4)
	site.established_year = data.get("established_year", 0)
	site.abandoned_year = data.get("abandoned_year", -1)
	var positions: Array = data.get("longhouse_positions", [])
	site.longhouse_positions = []
	for pos_data in positions:
		site.longhouse_positions.append(Vector2i(pos_data.get("x", -1), pos_data.get("y", -1)))
	if site.longhouse_positions.is_empty():
		site.longhouse_positions = [site.center]
	return site
