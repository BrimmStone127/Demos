class_name VillagePathCache
extends RefCounted

## Per-village cache of computed terrain-aware paths and trail traversal data.
## Routes are keyed by start->end grid positions. Trail tile counts drive
## the overlay intensity (more walks = brighter trail).
##
## Route sharing: when a new path is requested and no exact match exists,
## checks if any existing route ends within SHARE_RADIUS tiles of the target.
## If so, reuses that route instead of computing a new one. This consolidates
## paths to nearby resources into shared corridors.

const MAX_ROUTES := 30
const SHARE_RADIUS := 6   # tiles (Manhattan) — merge destinations within this distance
const STALE_FRAMES := 18000 # frames unused before route is removed (~5 minutes at 60fps)

var _pathfinder: TerrainPathfinder = null
var _routes: Dictionary = {}       # "x1,y1->x2,y2" -> CachedRoute
var _tile_counts: Dictionary = {}  # Vector2i -> int (village-wide traversal counts)


class CachedRoute:
	var path: Array[Vector2i] = []          # Simplified path (waypoints at turns)
	var full_path: Array[Vector2i] = []     # Full tile-by-tile path (for rendering)
	var usage_count: int = 0
	var last_used_frame: int = 0
	var avg_traversal: float = 0.0         # Cached average traversal count across tiles


var _traversal_dirty: bool = false  # Set true when any tile count changes


func _init(pathfinder: TerrainPathfinder) -> void:
	_pathfinder = pathfinder


## Get a cached path (simplified waypoints) or compute a new one. Returns empty array if unreachable.
func get_path(start: Vector2i, end: Vector2i, frame: int = 0) -> Array[Vector2i]:
	var key := _make_key(start, end)
	if _routes.has(key):
		var route: CachedRoute = _routes[key]
		route.usage_count += 1
		route.last_used_frame = frame
		return route.path

	# Check for a nearby route to share before computing a new one
	var shared := _find_shared_route(start, end, frame)
	if not shared.is_empty():
		return shared

	# Cache miss — compute (pass trail data so A* prefers existing paths)
	var raw_path := _pathfinder.find_path(start, end, _tile_counts)
	if raw_path.is_empty():
		return raw_path

	var simplified := TerrainPathfinder.simplify_path(raw_path)

	# Store in cache
	if _routes.size() >= MAX_ROUTES:
		_evict_lru()

	var route := CachedRoute.new()
	route.path = simplified
	route.full_path = raw_path
	route.usage_count = 1
	route.last_used_frame = frame
	_routes[key] = route

	# Seed trail counts for all tiles along the full path — start at 1 so
	# the route immediately has trail affinity for future A* queries
	for tile in raw_path:
		if not _tile_counts.has(tile):
			_tile_counts[tile] = 1
		else:
			_tile_counts[tile] += 1

	return simplified


## Get a cached full (tile-by-tile) path. Ensures the route is computed first.
func get_full_path(start: Vector2i, end: Vector2i, frame: int = 0) -> Array[Vector2i]:
	var key := _make_key(start, end)
	# Ensure route exists (triggers computation if needed)
	if not _routes.has(key):
		# Check for shared route first
		var shared_key := _find_shared_route_key(start, end)
		if shared_key != "":
			# Redirect to the shared route
			key = shared_key
		else:
			get_path(start, end, frame)
	if _routes.has(key):
		var route: CachedRoute = _routes[key]
		route.last_used_frame = frame
		return route.full_path
	return []


## Record that a villager walked through tile pos.
func record_traversal(pos: Vector2i) -> void:
	_tile_counts[pos] = _tile_counts.get(pos, 0) + 1
	_traversal_dirty = true


## Get traversal count for a specific tile.
func get_traversal_count(pos: Vector2i) -> int:
	return _tile_counts.get(pos, 0)


## Get all tiles with traversal data (Vector2i -> int count).
func get_all_trail_tiles() -> Dictionary:
	return _tile_counts


## Invalidate any cached routes that end at the given position (resource depleted).
func invalidate_routes_to(pos: Vector2i) -> void:
	var suffix := "->%d,%d" % [pos.x, pos.y]
	var to_remove: Array[String] = []
	for key: String in _routes:
		if key.ends_with(suffix):
			to_remove.append(key)
	for key in to_remove:
		_routes.erase(key)


## Invalidate any cached routes that start at the given position.
func invalidate_routes_from(pos: Vector2i) -> void:
	var prefix := "%d,%d->" % [pos.x, pos.y]
	var to_remove: Array[String] = []
	for key: String in _routes:
		if key.begins_with(prefix):
			to_remove.append(key)
	for key in to_remove:
		_routes.erase(key)


## Clear all cached routes (e.g., village relocated).
func clear_routes() -> void:
	_routes.clear()


## Get all cached routes as Array of [simplified_path, usage_count, avg_traversal].
## Traversal averages recomputed only when tile counts change.
func get_all_routes() -> Array:
	if _traversal_dirty:
		_recompute_avg_traversals()
		_traversal_dirty = false
	var result: Array = []
	for key: String in _routes:
		var route: CachedRoute = _routes[key]
		result.append([route.path, route.usage_count, route.avg_traversal])
	return result


## Remove routes not used within STALE_FRAMES. Call periodically.
func cleanup_stale_routes(current_frame: int) -> void:
	var to_remove: Array[String] = []
	for key: String in _routes:
		var route: CachedRoute = _routes[key]
		if current_frame - route.last_used_frame > STALE_FRAMES:
			to_remove.append(key)
	for key in to_remove:
		_routes.erase(key)


## Get the number of cached routes.
func get_route_count() -> int:
	return _routes.size()


static func _make_key(start: Vector2i, end: Vector2i) -> String:
	return "%d,%d->%d,%d" % [start.x, start.y, end.x, end.y]


## Find an existing route from the same start whose endpoint is within SHARE_RADIUS
## of the requested end. Returns the shared route's simplified path, or empty array.
func _find_shared_route(start: Vector2i, end: Vector2i, frame: int) -> Array[Vector2i]:
	var start_prefix := "%d,%d->" % [start.x, start.y]
	var best_key: String = ""
	var best_dist: int = SHARE_RADIUS + 1
	for key: String in _routes:
		if not key.begins_with(start_prefix):
			continue
		var route: CachedRoute = _routes[key]
		if route.full_path.is_empty():
			continue
		var route_end: Vector2i = route.full_path[route.full_path.size() - 1]
		var dist := absi(route_end.x - end.x) + absi(route_end.y - end.y)
		if dist <= SHARE_RADIUS and dist < best_dist:
			best_dist = dist
			best_key = key
	if best_key != "":
		var route: CachedRoute = _routes[best_key]
		route.usage_count += 1
		route.last_used_frame = frame
		return route.path
	return []


## Find the cache key of a shared route (for get_full_path lookups).
func _find_shared_route_key(start: Vector2i, end: Vector2i) -> String:
	var start_prefix := "%d,%d->" % [start.x, start.y]
	var best_key: String = ""
	var best_dist: int = SHARE_RADIUS + 1
	for key: String in _routes:
		if not key.begins_with(start_prefix):
			continue
		var route: CachedRoute = _routes[key]
		if route.full_path.is_empty():
			continue
		var route_end: Vector2i = route.full_path[route.full_path.size() - 1]
		var dist := absi(route_end.x - end.x) + absi(route_end.y - end.y)
		if dist <= SHARE_RADIUS and dist < best_dist:
			best_dist = dist
			best_key = key
	return best_key


## Recompute cached avg_traversal for all routes from tile counts.
func _recompute_avg_traversals() -> void:
	for key: String in _routes:
		var route: CachedRoute = _routes[key]
		if route.full_path.is_empty():
			route.avg_traversal = 0.0
			continue
		var total := 0
		for tile in route.full_path:
			total += _tile_counts.get(tile, 0)
		route.avg_traversal = float(total) / float(route.full_path.size())


## Evict least-recently-used route when cache is full.
func _evict_lru() -> void:
	var oldest_key: String = ""
	var oldest_frame: int = 2147483647
	for key: String in _routes:
		var route: CachedRoute = _routes[key]
		if route.last_used_frame < oldest_frame:
			oldest_frame = route.last_used_frame
			oldest_key = key
	if oldest_key != "":
		_routes.erase(oldest_key)
