class_name VillageDemographics
extends RefCounted

## Lightweight population representation for off-camera villages.
## Replaces Array[PersonInstance] with statistical buckets.
## One formula per tick instead of per-person iteration.

const LOG_TAG := "DEMOGRAPHICS"

## Age bucket boundaries (matching PersonInstance reproductive/mortality logic)
const CHILD_MAX_AGE := 14
const ADULT_MAX_AGE := 44
const ELDER_MIN_AGE := 45

## Reproduction constants (matching PersonInstance)
const MONTHLY_CONCEPTION_CHANCE := 0.03
const GESTATION_MONTHS := 9
const POSTPARTUM_MONTHS := 12

## Mortality constants (matching PersonInstance.tick_year)
const ILLNESS_CHANCE := 0.04
const ILLNESS_MORTALITY := 0.12  # fraction of illness cases that are fatal
const ELDER_BASE_MORTALITY := 0.025  # annual death rate for 45-54
const OLD_ELDER_EXTRA_MORTALITY := 0.06  # additional annual rate for 55+

## Population counts
var population: int = 0
var male_count: int = 0
var female_count: int = 0

## Age distribution: [children 0-14, adults 15-44, elders 45+]
var age_buckets: Array[int] = [0, 0, 0]

## Average stats
var avg_health: float = 1.0
var avg_age: float = 0.0

## Skill tracking
var avg_skills: Dictionary = {}       # skill_key -> float (0-100)
var max_skill_levels: Dictionary = {} # skill_key -> int (for era checks)

## Reproductive state
var pregnant_count: int = 0
var avg_pregnancy_months: float = 0.0  # average months pregnant across pregnant women

## Needs averages (for inflate reconstruction)
var avg_hunger: float = 0.7
var avg_thirst: float = 0.7
var avg_rest: float = 0.8


## Snapshot demographics from a full PersonInstance array.
static func from_individuals(individuals: Array[PersonInstance], political_traits: Dictionary) -> VillageDemographics:
	var demo := VillageDemographics.new()
	demo.population = individuals.size()
	if demo.population == 0:
		return demo

	var total_age := 0
	var total_health := 0.0
	var total_hunger := 0.0
	var total_thirst := 0.0
	var total_rest := 0.0
	var skill_totals: Dictionary = {}
	var skill_maxes: Dictionary = {}
	var preg_months_total := 0

	for person in individuals:
		# Sex counts
		if person.sex == PersonInstance.Sex.MALE:
			demo.male_count += 1
		else:
			demo.female_count += 1

		# Age buckets
		if person.age <= CHILD_MAX_AGE:
			demo.age_buckets[0] += 1
		elif person.age <= ADULT_MAX_AGE:
			demo.age_buckets[1] += 1
		else:
			demo.age_buckets[2] += 1

		total_age += person.age
		total_health += person.health
		total_hunger += person.hunger
		total_thirst += person.thirst
		total_rest += person.rest

		# Skills
		for skill_key in person.skills:
			skill_totals[skill_key] = skill_totals.get(skill_key, 0.0) + float(person.skills[skill_key])
			skill_maxes[skill_key] = maxi(skill_maxes.get(skill_key, 0), person.skills[skill_key])

		# Pregnancy
		if person.is_pregnant:
			demo.pregnant_count += 1
			preg_months_total += person.pregnancy_months

	var pop_f := float(demo.population)
	demo.avg_age = float(total_age) / pop_f
	demo.avg_health = total_health / pop_f
	demo.avg_hunger = total_hunger / pop_f
	demo.avg_thirst = total_thirst / pop_f
	demo.avg_rest = total_rest / pop_f

	for skill_key in skill_totals:
		demo.avg_skills[skill_key] = skill_totals[skill_key] / pop_f
		demo.max_skill_levels[skill_key] = skill_maxes[skill_key]

	if demo.pregnant_count > 0:
		demo.avg_pregnancy_months = float(preg_months_total) / float(demo.pregnant_count)

	return demo


## Simulate one game year: aging, deaths, skill growth, health drift.
## Returns number of deaths this year.
func tick_year(rng: RandomNumberGenerator) -> int:
	if population <= 0:
		return 0

	var deaths := 0

	# Age bucket transitions: children -> adults, adults -> elders
	# Approximate: 1/15 of children age out per year, 1/30 of adults age out
	# Use probabilistic rounding so small populations still graduate
	var children_graduating := _prob_round(float(age_buckets[0]) / 15.0, rng)
	children_graduating = clampi(children_graduating, 0, age_buckets[0])
	var adults_graduating := _prob_round(float(age_buckets[1]) / 30.0, rng)
	adults_graduating = clampi(adults_graduating, 0, age_buckets[1])
	age_buckets[0] -= children_graduating
	age_buckets[1] += children_graduating - adults_graduating
	age_buckets[2] += adults_graduating

	# Child mortality: disease, accident, malnutrition
	if age_buckets[0] > 0:
		var child_deaths := 0
		for _i in range(age_buckets[0]):
			if rng.randf() < 0.03:
				child_deaths += 1
		child_deaths = mini(child_deaths, age_buckets[0])
		age_buckets[0] -= child_deaths
		deaths += child_deaths

	# Elder deaths: natural aging
	if age_buckets[2] > 0:
		# Base elder mortality + extra for very old (approximate)
		var elder_death_rate := ELDER_BASE_MORTALITY + OLD_ELDER_EXTRA_MORTALITY * 0.3
		var elder_deaths := 0
		for _i in range(age_buckets[2]):
			if rng.randf() < elder_death_rate:
				elder_deaths += 1
		elder_deaths = mini(elder_deaths, age_buckets[2])
		age_buckets[2] -= elder_deaths
		deaths += elder_deaths

	# Illness deaths across all age groups (scales with population density)
	var density_modifier := 1.0 + float(population) / 80.0
	var effective_illness := ILLNESS_CHANCE * density_modifier
	var illness_deaths := 0
	for _i in range(population - deaths):
		if rng.randf() < effective_illness * ILLNESS_MORTALITY:
			illness_deaths += 1
	# Distribute illness deaths proportionally across buckets
	if illness_deaths > 0:
		illness_deaths = mini(illness_deaths, population - deaths)
		var remaining := illness_deaths
		# Remove from largest bucket first
		var bucket_order := [1, 0, 2]  # adults, children, elders
		for bi in bucket_order:
			var remove := mini(remaining, age_buckets[bi])
			age_buckets[bi] -= remove
			remaining -= remove
			if remaining <= 0:
				break
		deaths += illness_deaths

	# Update population and sex counts
	population = age_buckets[0] + age_buckets[1] + age_buckets[2]
	if population > 0:
		var male_ratio := float(male_count) / float(male_count + female_count) if (male_count + female_count) > 0 else 0.5
		male_count = int(round(population * male_ratio))
		female_count = population - male_count

	# Health drift: slight recovery for healthy populations, slight decay overall
	if population > 0:
		var health_event := rng.randf()
		if health_event < 0.10:
			avg_health = maxf(0.3, avg_health - rng.randf_range(0.01, 0.03))
		elif health_event > 0.85:
			avg_health = minf(1.0, avg_health + rng.randf_range(0.01, 0.03))

	# Skill growth (matching PersonInstance: 30% chance of +0-2 per year)
	for skill_key in avg_skills:
		if rng.randf() < 0.3:
			avg_skills[skill_key] = minf(100.0, avg_skills[skill_key] + rng.randf_range(0.0, 2.0))
			max_skill_levels[skill_key] = mini(100, max_skill_levels.get(skill_key, 0) + rng.randi_range(0, 2))

	# Update average age
	avg_age += 1.0
	# Clamp: can't exceed reasonable bounds given bucket distribution
	if population > 0:
		var estimated_avg := float(age_buckets[0]) * 7.0 + float(age_buckets[1]) * 30.0 + float(age_buckets[2]) * 55.0
		avg_age = estimated_avg / float(population)

	# Cap pregnant count to surviving fertile women
	var fertile_women := _get_fertile_women_count()
	pregnant_count = mini(pregnant_count, fertile_women)

	return deaths


## Simulate one game month: pregnancy advancement, conception, births.
## Returns number of births this month.
func tick_month(rng: RandomNumberGenerator, cohesion: float = 0.5) -> int:
	if population <= 0:
		return 0

	var births := 0

	# Advance existing pregnancies
	if pregnant_count > 0:
		avg_pregnancy_months += 1.0
		if avg_pregnancy_months >= GESTATION_MONTHS:
			# All current pregnancies deliver (simplified batch)
			births = pregnant_count
			age_buckets[0] += births
			population += births
			# Assign sex roughly 50/50
			var new_males := births / 2
			male_count += new_males
			female_count += births - new_males
			pregnant_count = 0
			avg_pregnancy_months = 0.0

	# New conceptions
	var fertile_women := _get_fertile_women_count() - pregnant_count
	if fertile_women > 0 and male_count > 0:
		var nutrition_factor := clampf(avg_hunger * avg_thirst * 2.0, 0.1, 1.0)
		var chance := MONTHLY_CONCEPTION_CHANCE * (0.8 + cohesion * 0.4) * nutrition_factor
		var new_pregnancies := 0
		for _i in range(fertile_women):
			if rng.randf() < chance:
				new_pregnancies += 1
		if new_pregnancies > 0:
			# Blend pregnancy months for staggered delivery
			if pregnant_count > 0:
				avg_pregnancy_months = (avg_pregnancy_months * float(pregnant_count)) / float(pregnant_count + new_pregnancies)
			else:
				avg_pregnancy_months = 0.0
			pregnant_count += new_pregnancies

	return births


## Estimate fertile women count from demographics.
func _get_fertile_women_count() -> int:
	if population <= 0 or female_count <= 0 or age_buckets[1] <= 0:
		return 0
	# Adult women (15-44) who aren't pregnant — use ceili to avoid truncating
	# small populations to zero (a village with 1 adult female should have 1 fertile woman)
	var adult_women := maxi(1, roundi(float(age_buckets[1]) * float(female_count) / float(population)))
	adult_women = mini(adult_women, mini(age_buckets[1], female_count))
	# Apply health filter (matching PersonInstance: health > 0.3)
	var healthy_fraction := clampf(avg_health, 0.0, 1.0)
	return maxi(1, roundi(float(adult_women) * healthy_fraction)) if healthy_fraction > 0.3 else 0


## Simulate resource pressure for deflated villages.
## Drifts avg_hunger based on carrying capacity vs population, causes starvation deaths.
## Returns number of starvation deaths.
func tick_resource_pressure(carrying_capacity: float, competition_factor: float, season_food_mod: float, rng: RandomNumberGenerator) -> int:
	if population <= 0:
		return 0

	# Effective food production scaled by competition and season
	var food_production := carrying_capacity * competition_factor * season_food_mod
	var food_ratio := food_production / maxf(float(population), 1.0)

	# Drift avg_hunger toward food ratio (smoothed)
	var target_hunger := clampf(food_ratio, 0.05, 1.0)
	avg_hunger = lerpf(avg_hunger, target_hunger, 0.3)

	# Water is terrain-based (generally abundant), slight pressure at high pop
	var water_ratio := clampf(1.2 - float(population) / 200.0, 0.3, 1.0)
	avg_thirst = lerpf(avg_thirst, water_ratio, 0.3)

	# Starvation deaths when hunger critically low and population exceeds capacity
	var starvation_deaths := 0
	if avg_hunger < 0.2 and population > int(carrying_capacity):
		var excess := population - int(carrying_capacity)
		var death_chance := (0.2 - avg_hunger) * 0.5
		for _i in range(excess):
			if rng.randf() < death_chance:
				starvation_deaths += 1
		# Cap at 25% of population per tick to prevent mass die-off
		starvation_deaths = mini(starvation_deaths, population / 4)

		# Remove from buckets (adults first, then children, then elders)
		var remaining := starvation_deaths
		for bi in [1, 0, 2]:
			var remove := mini(remaining, age_buckets[bi])
			age_buckets[bi] -= remove
			remaining -= remove
			if remaining <= 0:
				break
		population -= starvation_deaths
		# Update sex counts proportionally
		if population > 0:
			var male_ratio := float(male_count) / float(male_count + female_count) if (male_count + female_count) > 0 else 0.5
			male_count = int(round(population * male_ratio))
			female_count = population - male_count

	return starvation_deaths


## Split demographics: create a child village with fraction of population.
## Biases young adults toward child (matching VillageManager._split_village).
## Returns child demographics. Modifies self (parent) in place.
func split(fraction: float, rng: RandomNumberGenerator) -> VillageDemographics:
	var child := VillageDemographics.new()
	var split_count := maxi(5, int(population * fraction))
	if split_count >= population:
		split_count = population / 2

	# Bias: take more from adult bucket (young adults leave)
	var adults_to_take := mini(int(split_count * 0.7), age_buckets[1])
	var children_to_take := mini(int(split_count * 0.2), age_buckets[0])
	var elders_to_take := split_count - adults_to_take - children_to_take
	elders_to_take = clampi(elders_to_take, 0, age_buckets[2])
	# Adjust if we don't have enough
	var actual_total := adults_to_take + children_to_take + elders_to_take
	if actual_total < split_count:
		var deficit := split_count - actual_total
		var extra_adults := mini(deficit, age_buckets[1] - adults_to_take)
		adults_to_take += extra_adults
		deficit -= extra_adults
		if deficit > 0:
			var extra_children := mini(deficit, age_buckets[0] - children_to_take)
			children_to_take += extra_children

	child.age_buckets = [children_to_take, adults_to_take, elders_to_take] as Array[int]
	child.population = child.age_buckets[0] + child.age_buckets[1] + child.age_buckets[2]

	# Sex distribution
	var male_ratio := float(male_count) / float(population) if population > 0 else 0.5
	child.male_count = int(round(child.population * male_ratio))
	child.female_count = child.population - child.male_count

	# Copy averages
	child.avg_health = avg_health
	child.avg_age = 25.0  # skewed young since we biased adults
	child.avg_skills = avg_skills.duplicate()
	child.max_skill_levels = max_skill_levels.duplicate()
	child.avg_hunger = avg_hunger
	child.avg_thirst = avg_thirst
	child.avg_rest = avg_rest

	# Split pregnancies proportionally
	if pregnant_count > 0:
		var preg_ratio := float(child.age_buckets[1]) / float(age_buckets[1]) if age_buckets[1] > 0 else 0.0
		child.pregnant_count = int(round(pregnant_count * preg_ratio))
		child.avg_pregnancy_months = avg_pregnancy_months
		pregnant_count -= child.pregnant_count

	# Remove from parent
	age_buckets[0] -= children_to_take
	age_buckets[1] -= adults_to_take
	age_buckets[2] -= elders_to_take
	population = age_buckets[0] + age_buckets[1] + age_buckets[2]
	male_count = int(round(population * male_ratio))
	female_count = population - male_count

	return child


func get_population() -> int:
	return population


func get_adult_count() -> int:
	return age_buckets[1] + age_buckets[2]


func get_average_age() -> float:
	return avg_age


func get_average_health() -> float:
	return avg_health


func to_dict() -> Dictionary:
	return {
		"population": population,
		"male_count": male_count,
		"female_count": female_count,
		"age_buckets": [age_buckets[0], age_buckets[1], age_buckets[2]],
		"avg_health": avg_health,
		"avg_age": avg_age,
		"avg_skills": avg_skills.duplicate(),
		"max_skill_levels": max_skill_levels.duplicate(),
		"pregnant_count": pregnant_count,
		"avg_pregnancy_months": avg_pregnancy_months,
		"avg_hunger": avg_hunger,
		"avg_thirst": avg_thirst,
		"avg_rest": avg_rest,
	}


static func from_dict(data: Dictionary) -> VillageDemographics:
	var demo := VillageDemographics.new()
	demo.population = data.get("population", 0)
	demo.male_count = data.get("male_count", 0)
	demo.female_count = data.get("female_count", 0)
	var buckets: Array = data.get("age_buckets", [0, 0, 0])
	demo.age_buckets = [int(buckets[0]), int(buckets[1]), int(buckets[2])] as Array[int]
	demo.avg_health = data.get("avg_health", 1.0)
	demo.avg_age = data.get("avg_age", 0.0)
	var skills_data: Dictionary = data.get("avg_skills", {})
	for key in skills_data:
		demo.avg_skills[str(key)] = float(skills_data[key])
	var max_data: Dictionary = data.get("max_skill_levels", {})
	for key in max_data:
		demo.max_skill_levels[str(key)] = int(max_data[key])
	demo.pregnant_count = data.get("pregnant_count", 0)
	demo.avg_pregnancy_months = data.get("avg_pregnancy_months", 0.0)
	demo.avg_hunger = data.get("avg_hunger", 0.7)
	demo.avg_thirst = data.get("avg_thirst", 0.7)
	demo.avg_rest = data.get("avg_rest", 0.8)
	return demo


## Probabilistic rounding: floor(value) + 1 with probability equal to the fractional part.
## Ensures small fractions (e.g. 0.5 children graduating) still produce results over time.
static func _prob_round(value: float, rng: RandomNumberGenerator) -> int:
	var base := int(value)
	var frac := value - float(base)
	if frac > 0.0 and rng.randf() < frac:
		base += 1
	return base
