class_name VillageResourceMemory
extends RefCounted

## Tracks all resource positions a village knows about and its active gathering targets.
## Known positions accumulate as scouts discover resources.
## Active targets are the current gathering destinations per resource type.

## Resource type constants
const BERRY := "berry"
const FIREWOOD := "firewood"
const WATER := "water"

## All known resource positions: type -> Dictionary(Vector2i -> true)
var _known: Dictionary = {}

## Current active gathering target per type: type -> Vector2i
var _active_target: Dictionary = {}

## Camp position (always one per village)
var camp_position: Vector2i = Vector2i(-1, -1)


func _init() -> void:
	_known[BERRY] = {}
	_known[FIREWOOD] = {}
	_known[WATER] = {}


func add_known(type: String, pos: Vector2i) -> void:
	if pos.x < 0 or pos.y < 0:
		return
	if not _known.has(type):
		_known[type] = {}
	_known[type][pos] = true


func remove_known(type: String, pos: Vector2i) -> void:
	if _known.has(type):
		_known[type].erase(pos)


func has_known(type: String, pos: Vector2i) -> bool:
	if not _known.has(type):
		return false
	return _known[type].has(pos)


func get_all_known(type: String) -> Array[Vector2i]:
	if not _known.has(type):
		return []
	var result: Array[Vector2i] = []
	for pos: Vector2i in _known[type]:
		result.append(pos)
	return result


func get_known_count(type: String) -> int:
	if not _known.has(type):
		return 0
	return _known[type].size()


func set_target(type: String, pos: Vector2i) -> void:
	_active_target[type] = pos
	add_known(type, pos)


func get_target(type: String) -> Vector2i:
	return _active_target.get(type, Vector2i(-1, -1))


func clear() -> void:
	for type in _known:
		_known[type].clear()
	_active_target.clear()
	camp_position = Vector2i(-1, -1)


func to_dict() -> Dictionary:
	var known_data: Dictionary = {}
	for type in _known:
		var positions: Array = []
		for pos: Vector2i in _known[type]:
			positions.append({"x": pos.x, "y": pos.y})
		known_data[type] = positions
	var targets_data: Dictionary = {}
	for type in _active_target:
		var pos: Vector2i = _active_target[type]
		targets_data[type] = {"x": pos.x, "y": pos.y}
	return {
		"known": known_data,
		"active_target": targets_data,
		"camp_x": camp_position.x,
		"camp_y": camp_position.y,
	}


static func from_dict(data: Dictionary) -> VillageResourceMemory:
	var mem := VillageResourceMemory.new()
	mem.camp_position = Vector2i(data.get("camp_x", -1), data.get("camp_y", -1))
	var known_data: Dictionary = data.get("known", {})
	for type in known_data:
		if not mem._known.has(type):
			mem._known[type] = {}
		var positions = known_data[type]
		if positions is Array:
			for pos_data in positions:
				mem._known[type][Vector2i(pos_data.get("x", -1), pos_data.get("y", -1))] = true
	var targets_data: Dictionary = data.get("active_target", {})
	for type in targets_data:
		var pos_data = targets_data[type]
		mem._active_target[type] = Vector2i(pos_data.get("x", -1), pos_data.get("y", -1))
	return mem
