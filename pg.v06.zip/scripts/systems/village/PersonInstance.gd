class_name PersonInstance
extends RefCounted

## Represents a single person within a village simulation.
## Tracks age, health, traits, skills, and relationships.
## Skills are constrained to what the village's group_knowledge contains.

enum Sex { MALE, FEMALE }

const LOG_TAG := "PERSON"

## Gestation and postpartum timing (in game months)
const GESTATION_MONTHS := 9
const POSTPARTUM_MONTHS := 12  # nursing/recovery before next conception
const MONTHLY_CONCEPTION_CHANCE := 0.03  # ~5 children over fertile lifetime

## Unique identifier for this person
var person_id: String = ""

## Display name (assigned by scenario)
var name: String = ""

var sex: Sex = Sex.MALE
var age: int = 0            # In game years
var health: float = 1.0     # 0.0-1.0

## Villager needs state (persisted for save/load, managed by VillagerSystem)
var hunger: float = 0.7
var thirst: float = 0.7
var rest: float = 1.0
var metabolism: float = 1.0

## Heritable traits from scenario trait_definitions (e.g. "strong", "perceptive")
var traits: Array[String] = []

## Skill levels constrained to village group_knowledge keys
## skill_key -> level (0-100)
var skills: Dictionary = {}

## Social bonds: person_id -> affinity (-1.0 hostile to 1.0 close)
var relationships: Dictionary = {}

## Spiritual/religious conviction. Also susceptibility to psychic influence.
var beliefs: float = 0.5    # 0.0-1.0

## Whether this person has been touched by the player
var is_hero: bool = false

## Degree of player influence (0.0 = none, 1.0 = fully shaped)
var hero_influence: float = 0.0

## Reproductive state
var is_pregnant: bool = false
var pregnancy_months: int = 0
var months_since_child: int = 999  # High default so new adults can conceive


func initialize(p_id: String, p_name: String, p_sex: Sex, p_age: int, group_knowledge: Array[String]) -> void:
	person_id = p_id
	name = p_name
	sex = p_sex
	age = p_age
	health = randf_range(0.7, 1.0)
	beliefs = randf_range(0.2, 0.8)

	# Initialize skills at low levels for each known skill
	for skill_key in group_knowledge:
		skills[skill_key] = randi_range(5, 30)


## Tick called once per game year by VillageInstance.
## Returns true if still alive after the tick.
func tick_year(rng: RandomNumberGenerator, village_population: int = 25) -> bool:
	age += 1

	# Child mortality: disease, accident, malnutrition (ages 0-5)
	if age <= 5 and rng.randf() < 0.05:
		health = 0.0
		return false

	# Natural aging reduces health gradually after middle age
	if age > 40:
		var aging_rate = 0.008 * (1.0 + (age - 40) * 0.04)
		health = maxf(0.0, health - aging_rate)

	# Random health events (illness scales with population density)
	var density_modifier := 1.0 + float(village_population) / 80.0
	var illness_threshold := 0.04 * density_modifier
	var health_event = rng.randf()
	if health_event < illness_threshold:
		# Illness or injury
		health = maxf(0.0, health - rng.randf_range(0.05, 0.20))
	elif health_event > 0.90:
		# Recovery
		health = minf(1.0, health + rng.randf_range(0.03, 0.12))

	# Skill growth (slow, natural learning)
	for skill_key in skills:
		if rng.randf() < 0.3:
			skills[skill_key] = mini(100, skills[skill_key] + rng.randi_range(0, 2))

	return is_alive()


func is_alive() -> bool:
	if health <= 0.0:
		return false
	# Maximum lifespan: ~65 years base, health extends up to 75
	var max_age = 65 + int(health * 10.0)
	return age < max_age


func is_of_reproductive_age() -> bool:
	return age >= 15 and age <= 45 and health > 0.3


## Whether this woman can become pregnant this month.
func can_conceive() -> bool:
	return sex == Sex.FEMALE and is_of_reproductive_age() and not is_pregnant and months_since_child >= POSTPARTUM_MONTHS


## Advance pregnancy by one month. Returns true if baby is born this month.
func tick_pregnancy() -> bool:
	if not is_pregnant:
		return false
	pregnancy_months += 1
	if pregnancy_months >= GESTATION_MONTHS:
		is_pregnant = false
		pregnancy_months = 0
		months_since_child = 0
		return true
	return false


## Begin pregnancy.
func conceive() -> void:
	is_pregnant = true
	pregnancy_months = 0


## Advance postpartum counter by one month.
func tick_postpartum() -> void:
	if months_since_child < POSTPARTUM_MONTHS + 1:
		months_since_child += 1


## Legacy compatibility — still used by some tests
func can_have_child() -> bool:
	return can_conceive()


func get_dominant_skill() -> String:
	var best_skill := ""
	var best_level := 0
	for skill_key in skills:
		if skills[skill_key] > best_level:
			best_level = skills[skill_key]
			best_skill = skill_key
	return best_skill


func to_dict() -> Dictionary:
	return {
		"person_id": person_id,
		"name": name,
		"sex": sex,
		"age": age,
		"health": health,
		"traits": traits.duplicate(),
		"skills": skills.duplicate(),
		"beliefs": beliefs,
		"is_hero": is_hero,
		"hero_influence": hero_influence,
		"is_pregnant": is_pregnant,
		"pregnancy_months": pregnancy_months,
		"months_since_child": months_since_child,
		"hunger": hunger,
		"thirst": thirst,
		"rest": rest,
		"metabolism": metabolism,
	}


static func from_dict(data: Dictionary) -> PersonInstance:
	var person := PersonInstance.new()
	person.person_id = data.get("person_id", "")
	person.name = data.get("name", "")
	person.sex = data.get("sex", Sex.MALE)
	person.age = data.get("age", 0)
	person.health = data.get("health", 1.0)
	var saved_traits = data.get("traits", [])
	person.traits = []
	for t in saved_traits:
		person.traits.append(str(t))
	person.skills = {}
	var saved_skills = data.get("skills", {})
	for key in saved_skills:
		person.skills[str(key)] = int(saved_skills[key])
	person.beliefs = data.get("beliefs", 0.5)
	person.is_hero = data.get("is_hero", false)
	person.hero_influence = data.get("hero_influence", 0.0)
	person.is_pregnant = data.get("is_pregnant", false)
	person.pregnancy_months = data.get("pregnancy_months", 0)
	person.months_since_child = data.get("months_since_child", 999)
	person.hunger = data.get("hunger", 0.7)
	person.thirst = data.get("thirst", 0.7)
	person.rest = data.get("rest", 1.0)
	person.metabolism = data.get("metabolism", 1.0)
	return person
