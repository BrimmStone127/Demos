# Planet.gd - Updated to show name labels when probed
class_name Planet
extends Node2D

const LOG_TAG := "PLANET"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


var data: PlanetData

var orbit_center: Vector2 = Vector2.ZERO
var planet_sprite: Sprite2D
var shadow_sprite: Sprite2D  # NEW: Shadow layer sprite

# Proxies to PlanetData for compatibility
var semi_major_axis: float:
	get: return data.semi_major_axis if data else 0.0
	set(v): if data: data.semi_major_axis = v

var eccentricity: float:
	get: return data.eccentricity if data else 0.0
	set(v): if data: data.eccentricity = v

var orbit_angle: float:
	get: return data.orbit_angle if data else 0.0
	set(v): if data: data.orbit_angle = v

var orbit_speed: float:
	get: return data.orbit_speed if data else 0.0
	set(v): if data: data.orbit_speed = v

var rotation_angle: float:
	get: return data.rotation_angle if data else 0.0
	set(v): if data: data.rotation_angle = v

var rotation_period: float:
	get: return data.rotation_period if data else 1.0
	set(v): if data: data.rotation_period = v

var rotation_speed: float = 0.0          # Deg/sec calculated from period

const MOON_TEXTURE := preload("res://assets/moon1.png")
const MOON_COLOR := Color(0.85, 0.87, 0.9)
const MOON_DISTANCE_MULTIPLIER := 0.1
const MOON_SIZE_BOOST := 0.35
const MIN_MOON_SCALE := 0.0015
const MOON_PERIOD_SCALE := 3.0
const MOON_BASE_ORBIT_MULTIPLIER := 2.2
const MOON_ORBIT_GROWTH_BASE := 1.12
const MOON_ORBIT_VARIATION := 0.25
const MOON_SPACING_SIZE_FACTOR := 1.2
const MOON_LOG_MAX := 5
const MOON_PERIOD_EXPONENT := 0.9
const MOON_PERIOD_MIN := 0.25
const MOON_BASE_ORBIT_RATIO := 1.2
const MOON_ORBIT_MULTIPLIERS := {
	PlanetEnums.PlanetType.ROCKY_SMALL: 1.05,
	PlanetEnums.PlanetType.ROCKY_MEDIUM: 1.35,
	PlanetEnums.PlanetType.SUPER_EARTH: 1.8,
	PlanetEnums.PlanetType.ICE_GIANT: 2.4,
	PlanetEnums.PlanetType.GAS_GIANT: 3.2,
	PlanetEnums.PlanetType.SUPER_JUPITER: 4.0
}
const MOON_MAX_BY_TYPE := {
	PlanetEnums.PlanetType.ROCKY_SMALL: 1,
	PlanetEnums.PlanetType.ROCKY_MEDIUM: 3,
	PlanetEnums.PlanetType.SUPER_EARTH: 4,
	PlanetEnums.PlanetType.ICE_GIANT: 6,
	PlanetEnums.PlanetType.GAS_GIANT: 8,
	PlanetEnums.PlanetType.SUPER_JUPITER: 12
}
const MOON_SIZE_RANGE := Vector2(0.025, 0.1)
const MOON_DENSE_GROWTH := 1.05
const MOON_DENSE_SPACING := 1.05
const MOON_DENSE_THRESHOLD := 8

var _moons: Array[Dictionary] = []  # Array of moon data dictionaries
var moons: Array:
	get:
		return _moons
	set(value):
		_moons = _finalize_moon_layout(value)
		_log_moon_layout(_moons)
		_rebuild_moon_visuals()

var moon_visuals: Array[Dictionary] = []

var planet_type: int:
	get: return data.planet_type if data else 0
	set(v): if data: data.planet_type = v

var planet_name: String:
	get: return data.planet_name if data else ""
	set(v): if data: data.planet_name = v

var planet_size: float:
	get: return data.size if data else 0.0
	set(v): if data: data.size = v

var has_atmosphere: bool # Still needed for basic toggle
var selected: bool = false
var color_index: int:
	get: return data.color_index if data else 0
	set(v): if data: data.color_index = v

var base_color: Color:
	get: return data.base_color if data else Color.WHITE
	set(v): if data: data.base_color = v

var probed_by: String = ""
var probe_indicator: Label = null
var name_label: Label = null  # NEW: Name label for probed planets
var habitable_zone_type: int = -1 # HabitableZone.ZoneType

# Atmosphere and other enhanced properties are now in PlanetData
var atmosphere_type: int:
	get: return data.atmosphere_type if data else 0
	set(v): if data: data.atmosphere_type = v

var atmosphere_pressure: float:
	get: return data.atmosphere_pressure if data else 0.0
	set(v): if data: data.atmosphere_pressure = v

var atmosphere_composition: Dictionary:
	get: return data.atmosphere_composition if data else {}
	set(v): if data: data.atmosphere_composition = v

var magnetosphere_strength: int:
	get: return data.magnetosphere_strength if data else 0
	set(v): if data: data.magnetosphere_strength = v

var magnetic_field_strength: float:
	get: return data.magnetic_field_strength if data else 0.0
	set(v): if data: data.magnetic_field_strength = v

var geological_activity: int:
	get: return data.geological_activity if data else 0
	set(v): if data: data.geological_activity = v

var tectonic_plates: int:
	get: return data.tectonic_plates if data else 0
	set(v): if data: data.tectonic_plates = v

var volcanic_activity: float:
	get: return data.volcanic_activity if data else 0.0
	set(v): if data: data.volcanic_activity = v

var climate_type: int:
	get: return data.climate_type if data else 0
	set(v): if data: data.climate_type = v

var surface_temperature: float:
	get: return data.surface_temperature if data else 0.0
	set(v): if data: data.surface_temperature = v

var temperature_variation: float:
	get: return data.temperature_variation if data else 0.0
	set(v): if data: data.temperature_variation = v

var surface_liquids: Dictionary:
	get: return data.surface_liquids if data else {}
	set(v): if data: data.surface_liquids = v

var surface_composition: Dictionary:
	get: return data.surface_composition if data else {}
	set(v): if data: data.surface_composition = v

var habitability_score: float:
	get: return data.habitability_score if data else 0.0
	set(v): if data: data.habitability_score = v

var enhanced_properties_generated: bool:
	get: return data.enhanced_properties_generated if data else false
	set(v): if data: data.enhanced_properties_generated = v

# Atmospheric composition presets
const ATMOSPHERE_PRESETS = {
	PlanetEnums.AtmosphereType.NONE: {},
	PlanetEnums.AtmosphereType.THIN: {
		"CO2": 95.0,
		"N2": 3.0,
		"Ar": 2.0
	},
	PlanetEnums.AtmosphereType.MODERATE: {
		"N2": 78.0,
		"O2": 21.0,
		"Ar": 0.9,
		"CO2": 0.1
	},
	PlanetEnums.AtmosphereType.THICK: {
		"CO2": 96.0,
		"N2": 3.0,
		"SO2": 1.0
	},
	PlanetEnums.AtmosphereType.DENSE: {
		"N2": 70.0,
		"O2": 25.0,
		"CO2": 3.0,
		"Ar": 2.0
	},
	PlanetEnums.AtmosphereType.GAS_GIANT: {
		"H2": 75.0,
		"He": 24.0,
		"CH4": 1.0
	}
}

func _init(p_texture: Texture2D, p_semi_major: float, p_eccentricity: float, p_type: int, p_props: Dictionary, p_has_atmosphere: bool = false):
	data = PlanetData.new()
	data.semi_major_axis = p_semi_major
	data.eccentricity = p_eccentricity
	data.planet_type = p_type
	has_atmosphere = p_has_atmosphere
	
	# Randomize initial orbit angle between 0 and 2*PI
	data.orbit_angle = randf() * 2 * PI
	
	# Create main planet sprite
	planet_sprite = Sprite2D.new()
	planet_sprite.texture = p_texture
	planet_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	add_child(planet_sprite)
	
	# NEW: Load and create shadow sprite
	var shadow_texture = load("res://assets/planet_polar_shadow.png")
	if shadow_texture:
		shadow_sprite = Sprite2D.new()
		shadow_sprite.texture = shadow_texture
		shadow_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
		shadow_sprite.z_index = 1  # Render above planet
		shadow_sprite.modulate.a = 0.5
		add_child(shadow_sprite)
	
	# Set planet visual properties
	var scale_value = randf_range(p_props.scale_range.x, p_props.scale_range.y)
	data.size = scale_value
	planet_sprite.scale = Vector2.ONE * scale_value
	
	# Apply same scale to shadow
	if shadow_sprite:
		shadow_sprite.scale = Vector2.ONE * scale_value
	
	# Store color index for hover state management
	data.color_index = randi() % p_props.colors.size()
	data.base_color = p_props.colors[data.color_index]
	planet_sprite.modulate = data.base_color
	
	# Calculate orbit speed using Kepler's Third Law (approximation)
	# Smaller orbits should be faster
	data.orbit_speed = 0.05 / sqrt(data.semi_major_axis / 100)

	# Initial rotation angle (deterministic based on semi_major_axis)
	var rotation_seed = int(data.semi_major_axis * 1000) % 360
	data.rotation_angle = float(rotation_seed)
	
	# Set rotation period (placeholder formula if not provided in props)
	# Inner planets rotate slower, outer giants rotate faster
	rotation_period = 0.6 + (data.semi_major_axis / 400.0)
	if planet_type == PlanetEnums.PlanetType.SUPER_EARTH:
		rotation_period += 0.2 # Super earths are a bit slower
	elif planet_type >= 3: # Gaseous giants
		rotation_period *= 0.4
	
	rotation_period = clamp(rotation_period, 0.1, 10.0)
	
	_calculate_rotation_speed()

	# Set initial position and shadow rotation
	update_position()
	_update_shadow_rotation()
	
	# Generate planet name based on type
	data.planet_name = generate_planet_name()
	
	# Store planet size for info display and collision detection
	planet_size = scale_value

func _ready() -> void:
	_rebuild_moon_visuals()

func _calculate_rotation_speed() -> void:
	"""Calculate rotation speed in degrees per second based on rotation period."""
	# TimeManager.SECONDS_PER_GAME_DAY = 60.0 seconds
	const SECONDS_PER_GAME_DAY = 60.0
	var seconds_per_rotation = rotation_period * SECONDS_PER_GAME_DAY
	rotation_speed = 360.0 / seconds_per_rotation

func get_local_time_of_day() -> float:
	"""Returns 0.0-1.0 representing day progress (0=midnight, 0.5=noon)."""
	return fmod(rotation_angle / 360.0, 1.0)

func is_daytime() -> bool:
	"""Returns true if daytime (roughly 6am-6pm)."""
	var time = get_local_time_of_day()
	return time >= 0.25 and time < 0.75

func _process(delta: float) -> void:
	# Get time manager for time scale
	var time_manager = _get_time_manager()
	var effective_delta = delta
	if time_manager:
		effective_delta *= time_manager.current_time_scale

	# Update orbit position
	orbit_angle += orbit_speed * effective_delta

	# Keep angle between 0 and 2*PI
	if orbit_angle > 2 * PI:
		orbit_angle -= 2 * PI

	# Update axial rotation (independent of orbit)
	rotation_angle += rotation_speed * effective_delta
	if rotation_angle >= 360.0:
		rotation_angle -= 360.0

	# Apply rotation to sprite
	planet_sprite.rotation = deg_to_rad(rotation_angle)

	update_position()
	_update_shadow_rotation()
	_update_moon_positions(effective_delta)

func update_position() -> void:
	# Calculate position on elliptical orbit
	var distance = semi_major_axis * (1 - eccentricity * eccentricity) / (1 + eccentricity * cos(orbit_angle))
	position = orbit_center + Vector2(cos(orbit_angle), sin(orbit_angle)) * distance

func _get_time_manager() -> TimeManager:
	"""Get TimeManager instance via main node group."""
	if get_tree():
		for node in get_tree().get_nodes_in_group("main"):
			if "time_manager" in node and node.time_manager is TimeManager:
				return node.time_manager
	return null

func _update_shadow_rotation():
	"""Update the shadow rotation to always face away from the star"""
	if not shadow_sprite:
		return
	
	# Calculate direction from planet to star (orbit center)
	var to_star = orbit_center - global_position
	
	# Calculate angle from planet to star
	var star_angle = to_star.angle()
	
	# The shadow texture has its dark side on the left by default
	# When star is to the right (angle 0), we want dark side to the left (no rotation)
	# When star is above (angle PI/2), we want dark side down (rotate by PI/2)
	# So the rotation should match the star angle
	shadow_sprite.rotation = star_angle

func _update_day_night_brightness() -> void:
	"""Update planet brightness based on rotation angle relative to star.
	The side facing the star is brighter (daytime), the opposite side is darker (nighttime).
	"""
	if not planet_sprite:
		return

	# Calculate angle from planet to star
	var to_star = orbit_center - global_position
	var angle_to_star = to_star.angle()

	# Calculate relative angle between rotation and star direction
	# rotation_angle is in degrees, convert to radians for comparison
	var rotation_rad = deg_to_rad(rotation_angle)
	var relative_angle = rotation_rad - angle_to_star

	# Normalize to -PI to PI
	while relative_angle > PI:
		relative_angle -= TAU
	while relative_angle < -PI:
		relative_angle += TAU

	# Calculate brightness: 1.0 at star-facing (noon), 0.3 at opposite (midnight)
	var brightness = 0.3 + 0.7 * cos(relative_angle)

	# Apply brightness to base color
	var adjusted_color = Color(
		base_color.r * brightness,
		base_color.g * brightness,
		base_color.b * brightness,
		base_color.a
	)

	# Apply selection highlight if selected
	if selected:
		adjusted_color = adjusted_color.lightened(0.2)

	planet_sprite.modulate = adjusted_color

func _update_moon_positions(delta: float) -> void:
	if moon_visuals.is_empty():
		return

	for i in range(moon_visuals.size()):
		var info: Dictionary = moon_visuals[i] as Dictionary
		var angle: float = float(info.get("angle", 0.0))
		var speed: float = float(info.get("angular_speed", 0.0))
		angle = wrapf(angle + speed * delta, 0.0, TAU)
		info["angle"] = angle
		moon_visuals[i] = info
		var node_variant: Variant = info.get("node")
		if node_variant and is_instance_valid(node_variant) and node_variant is Sprite2D:
			var node: Sprite2D = node_variant as Sprite2D
			node.position = Vector2(cos(angle), sin(angle)) * float(info.get("radius", 0.0))

func _clear_moon_visuals() -> void:
	for info_entry in moon_visuals:
		var info_dict: Dictionary = info_entry as Dictionary
		var node: Node = info_dict.get("node") as Node
		if node and is_instance_valid(node):
			node.queue_free()
	moon_visuals.clear()

func _rebuild_moon_visuals() -> void:
	_clear_moon_visuals()
	if not is_inside_tree():
		return
	if not planet_sprite or not planet_sprite.texture or not MOON_TEXTURE:
		return
	if _moons.is_empty():
		return

	for moon_entry in _moons:
		if not (moon_entry is Dictionary):
			continue
		var moon_data: Dictionary = moon_entry
		var sprite := Sprite2D.new()
		sprite.texture = MOON_TEXTURE
		sprite.modulate = MOON_COLOR
		sprite.z_index = planet_sprite.z_index + 1
		sprite.centered = true
		var scale_value: float = _calculate_moon_scale(moon_data)
		sprite.scale = Vector2.ONE * scale_value
		add_child(sprite)
		var period: float = max(float(moon_data.get("orbital_period", 1.0)), 0.25) * MOON_PERIOD_SCALE
		var angular_speed: float = (TAU / period) if period != 0 else 0.0
		var angle: float = float(moon_data.get("current_angle", randf_range(0.0, TAU)))
		var radius: float = _calculate_moon_orbit_radius(moon_data)
		var info: Dictionary = {
			"node": sprite,
			"angle": angle,
			"angular_speed": angular_speed,
			"radius": radius
		}
		moon_visuals.append(info)
		sprite.position = Vector2(cos(angle), sin(angle)) * radius

func _get_planet_size_safe() -> float:
	return max(planet_size, 0.001)

func _get_base_moon_orbit_ratio() -> float:
	if MOON_ORBIT_MULTIPLIERS.has(planet_type):
		return float(MOON_ORBIT_MULTIPLIERS[planet_type])
	return MOON_BASE_ORBIT_RATIO

func _get_max_moons_for_type() -> int:
	if MOON_MAX_BY_TYPE.has(planet_type):
		return int(MOON_MAX_BY_TYPE[planet_type])
	return 0

func _clamp_moon_size(size_value: float) -> float:
	var safe_size := _get_planet_size_safe()
	var min_size := safe_size * MOON_SIZE_RANGE.x
	var max_size := safe_size * MOON_SIZE_RANGE.y
	return clamp(size_value, min_size, max_size)

func _finalize_moon_layout(raw: Variant) -> Array[Dictionary]:
	var candidates: Array[Dictionary] = []
	if raw is Array:
		for entry in raw:
			if entry is Dictionary:
				candidates.append((entry as Dictionary).duplicate(true))

	var max_allowed: int = _get_max_moons_for_type()
	if max_allowed <= 0 or candidates.is_empty():
		return []

	candidates.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return float(a.get("distance", 0.0)) < float(b.get("distance", 0.0)))
	while candidates.size() > max_allowed:
		candidates.pop_back()

	var result: Array[Dictionary] = []
	var base_ratio: float = max(_get_base_moon_orbit_ratio(), MOON_BASE_ORBIT_RATIO)
	var safe_planet_size: float = _get_planet_size_safe()
	var moon_count: int = candidates.size()
	var growth_factor: float = MOON_ORBIT_GROWTH_BASE
	var spacing_factor: float = MOON_SPACING_SIZE_FACTOR
	if moon_count > MOON_DENSE_THRESHOLD:
		var density_scale: float = clamp(float(moon_count) / float(MOON_DENSE_THRESHOLD), 1.0, 3.0)
		growth_factor = lerp(MOON_DENSE_GROWTH, MOON_ORBIT_GROWTH_BASE, 1.0 / density_scale)
		spacing_factor = lerp(MOON_DENSE_SPACING, MOON_SPACING_SIZE_FACTOR, 1.0 / density_scale)

	var previous_ratio: float = base_ratio * 0.5
	var previous_size_ratio: float = MOON_SIZE_RANGE.x
	for i in range(moon_count):
		var entry: Dictionary = candidates[i]
		var moon_size_value: float = _clamp_moon_size(float(entry.get("size", safe_planet_size * 0.02)))
		var size_ratio: float = moon_size_value / safe_planet_size
		var target_ratio: float = base_ratio * pow(growth_factor, i)
		target_ratio *= randf_range(1.0 - MOON_ORBIT_VARIATION, 1.0 + MOON_ORBIT_VARIATION)
		var spacing_ratio: float = (previous_size_ratio + size_ratio) * spacing_factor
		var orbit_ratio: float = max(target_ratio, previous_ratio + spacing_ratio)
		previous_ratio = orbit_ratio
		previous_size_ratio = size_ratio
		var orbital_period: float = max(pow(orbit_ratio, MOON_PERIOD_EXPONENT) * MOON_PERIOD_SCALE, MOON_PERIOD_MIN)
		entry["size"] = moon_size_value
		entry["distance"] = orbit_ratio * safe_planet_size
		entry["orbital_period"] = orbital_period
		if not entry.has("current_angle") or typeof(entry.get("current_angle")) != TYPE_FLOAT:
			entry["current_angle"] = randf_range(0.0, TAU)
		entry["is_tidally_locked"] = orbit_ratio < 12.0
		result.append(entry)

	return result

func _log_moon_layout(layout: Array[Dictionary]) -> void:
	if layout.is_empty():
		_log_info("Moon generation: %s has no natural satellites", [planet_name])
		return

	var entries: Array[String] = []
	var safe_planet_size: float = _get_planet_size_safe()
	var sample_count: int = min(MOON_LOG_MAX, layout.size())
	for i in range(sample_count):
		var info: Dictionary = layout[i]
		var ratio: float = float(info.get("distance", safe_planet_size)) / safe_planet_size
		entries.append("%s@%.2f" % [info.get("name", "Moon"), ratio])
	_log_info("Moon generation: %s -> %s moons (%s)", [planet_name, layout.size(), ", ".join(entries)])

func _calculate_moon_orbit_radius(moon_data: Dictionary) -> float:
	if not planet_sprite or not planet_sprite.texture:
		return 0.0
	var base_radius: float = (planet_sprite.texture.get_width() * planet_sprite.scale.x) * 0.5
	var safe_planet_size: float = _get_planet_size_safe()
	var distance_value: float = float(moon_data.get("distance", safe_planet_size * _get_base_moon_orbit_ratio()))
	var ratio: float = max(distance_value / safe_planet_size, 0.0)
	return base_radius * (1.0 + ratio)

func _calculate_moon_scale(moon_data: Dictionary) -> float:
	var base_scale: float = planet_size
	var size_value: float = _clamp_moon_size(float(moon_data.get("size", base_scale * 0.02)))
	var boosted: float = size_value * MOON_SIZE_BOOST
	return clamp(boosted, MIN_MOON_SCALE, base_scale * MOON_SIZE_RANGE.y)

func get_visual_extent() -> float:
	if not planet_sprite or not planet_sprite.texture:
		return 0.0
	var base_radius: float = (planet_sprite.texture.get_width() * planet_sprite.scale.x) * 0.5
	var max_extent: float = base_radius
	if moon_visuals.is_empty():
		for moon_entry in _moons:
			if not (moon_entry is Dictionary):
				continue
			var moon_data: Dictionary = moon_entry
			var radius: float = _calculate_moon_orbit_radius(moon_data)
			var moon_scale: float = _calculate_moon_scale(moon_data)
			var moon_radius: float = 0.0
			if MOON_TEXTURE:
				moon_radius = (MOON_TEXTURE.get_width() * moon_scale) * 0.5
			max_extent = max(max_extent, radius + moon_radius)
	else:
		for info_entry in moon_visuals:
			var info_dict: Dictionary = info_entry as Dictionary
			var radius: float = float(info_dict.get("radius", base_radius))
			var node_variant: Variant = info_dict.get("node")
			var moon_radius: float = 0.0
			if node_variant and is_instance_valid(node_variant) and node_variant is Sprite2D:
				var sprite: Sprite2D = node_variant as Sprite2D
				if sprite.texture:
					moon_radius = (sprite.texture.get_width() * sprite.scale.x) * 0.5
			max_extent = max(max_extent, radius + moon_radius)
	return max_extent

func generate_planet_name() -> String:
	# This is a placeholder name that will be updated once the planet is added to the star system
	# The real name will be set in the StarSystem.generate() function
	return "Planet"

# Add this method to generate enhanced properties (call after basic planet creation)
func generate_enhanced_properties():
	if enhanced_properties_generated:
		return
	
	# Use a deterministic RNG seeded by semi_major_axis to ensure consistent generation
	var rng = RandomNumberGenerator.new()
	rng.seed = int(data.semi_major_axis * 100000)
	
	data.generate_enhanced(rng)
	
	# Handle moons separately as they involve child nodes/visuals
	_generate_moons()

func _generate_moons():
	# Generate moons based on planet type and size
	var max_moons = 0
	
	match planet_type:
		PlanetEnums.PlanetType.ROCKY_SMALL:
			max_moons = 0 if randf() < 0.8 else 1
		PlanetEnums.PlanetType.ROCKY_MEDIUM:
			max_moons = randi_range(0, 2)
		PlanetEnums.PlanetType.SUPER_EARTH:
			max_moons = randi_range(0, 3)
		PlanetEnums.PlanetType.ICE_GIANT:
			max_moons = randi_range(1, 4)
		PlanetEnums.PlanetType.GAS_GIANT:
			max_moons = randi_range(2, 7)
		PlanetEnums.PlanetType.SUPER_JUPITER:
			max_moons = randi_range(4, 10)
	
	var raw_moons: Array[Dictionary] = []
	if max_moons == 0:
		_moons = []
		_log_moon_layout(_moons)
		if is_inside_tree():
			_rebuild_moon_visuals()
		return

	var safe_planet_size: float = _get_planet_size_safe()
	for i in range(max_moons):
		var moon_size_value = randf_range(MOON_SIZE_RANGE.x, MOON_SIZE_RANGE.y) * safe_planet_size
		var moon: Dictionary = {
			"name": planet_name + " Moon " + str(i + 1),
			"size": moon_size_value,
			"distance": float(i + 1) * safe_planet_size,
			"orbital_period": 1.0,
			"is_tidally_locked": false
		}
		raw_moons.append(moon)

	_moons = _finalize_moon_layout(raw_moons)
	_log_moon_layout(_moons)
	if is_inside_tree():
		_rebuild_moon_visuals()

func calculate_habitability_score(habitable_zone: HabitableZone) -> float:
	if not habitable_zone:
		return 0.0
	
	# Use the enhanced calculation that considers orbital dynamics
	var mass_estimate = planet_size * planet_size * planet_size  # Rough mass approximation
	habitability_score = habitable_zone.calculate_habitability_score(
		semi_major_axis, 
		planet_type, 
		mass_estimate,
		eccentricity
	)
	
	# FIXED: More generous additional factors for enhanced properties
	if habitability_score > 0 and enhanced_properties_generated:
		# Atmosphere factors (more generous)
		match atmosphere_type:
			PlanetEnums.AtmosphereType.MODERATE:
				habitability_score *= 1.5  # Increased bonus
			PlanetEnums.AtmosphereType.THIN:
				habitability_score *= 1.1  # Small bonus instead of penalty
			PlanetEnums.AtmosphereType.THICK:
				habitability_score *= 0.8  # Reduced penalty
			PlanetEnums.AtmosphereType.DENSE:
				habitability_score *= 0.9  # Reduced penalty
			PlanetEnums.AtmosphereType.NONE:
				habitability_score *= 0.3  # Still low but not crushing
		
		# Magnetic field protection (more generous)
		match magnetosphere_strength:
			PlanetEnums.MagnetosphereStrength.MODERATE, PlanetEnums.MagnetosphereStrength.STRONG:
				habitability_score *= 1.3  # Increased bonus
			PlanetEnums.MagnetosphereStrength.WEAK:
				habitability_score *= 1.0  # No penalty
			PlanetEnums.MagnetosphereStrength.NONE:
				habitability_score *= 0.7  # Reduced penalty
			PlanetEnums.MagnetosphereStrength.EXTREME:
				habitability_score *= 1.2  # Good protection
		
		# Geological activity (more generous)
		match geological_activity:
			PlanetEnums.GeologicalActivity.MODERATE:
				habitability_score *= 1.3  # Increased bonus
			PlanetEnums.GeologicalActivity.LOW:
				habitability_score *= 1.1  # Small bonus
			PlanetEnums.GeologicalActivity.HIGH:
				habitability_score *= 1.0  # No penalty
			PlanetEnums.GeologicalActivity.DEAD:
				habitability_score *= 0.8  # Reduced penalty
			PlanetEnums.GeologicalActivity.EXTREME:
				habitability_score *= 0.8  # Reduced penalty
		
		# Surface liquid water is crucial (more generous)
		if surface_liquids.has("water") and surface_liquids.water > 0.1:
			habitability_score *= 1.6  # Increased bonus
		elif surface_liquids.has("ice") and surface_liquids.ice > 0.3:
			habitability_score *= 1.3  # Increased bonus for subsurface potential
		
		# Temperature range considerations (more generous)
		match climate_type:
			PlanetEnums.ClimateType.TEMPERATE:
				habitability_score *= 1.4  # Increased bonus
			PlanetEnums.ClimateType.COLD, PlanetEnums.ClimateType.HOT:
				habitability_score *= 1.0  # No penalty
			PlanetEnums.ClimateType.FROZEN:
				habitability_score *= 0.4  # Reduced penalty
			PlanetEnums.ClimateType.SCORCHING:
				habitability_score *= 0.3  # Reduced penalty
			PlanetEnums.ClimateType.VARIABLE:
				habitability_score *= 0.8  # Reduced penalty
	
	habitability_score = clamp(habitability_score, 0.0, 1.0)
	
	# Store which zone type this planet is in
	if habitable_zone:
		habitable_zone_type = habitable_zone.get_zone_type(semi_major_axis, orbit_angle)
	
	return habitability_score

func get_current_habitability(habitable_zone: HabitableZone) -> float:
	if not habitable_zone or habitability_score <= 0:
		return 0.0
	
	# Everything in pixels now - no conversion needed!
	var current_distance = semi_major_axis * (1 - eccentricity * eccentricity) / (1 + eccentricity * cos(orbit_angle))
	
	return habitable_zone.get_current_habitability(
		current_distance,  # Already in pixels
		orbit_angle,
		planet_type,
		habitability_score
	)

# Get fraction of orbit that's habitable
func get_habitable_orbit_fraction(habitable_zone: HabitableZone) -> float:
	if not habitable_zone:
		return 0.0
	
	# Everything in pixels now - no conversion needed!
	return habitable_zone.calculate_habitable_orbit_fraction(
		semi_major_axis,  # Already in pixels
		eccentricity,
		planet_type
	)

# Check if planet crosses habitable zones during its orbit
func crosses_habitable_zones(habitable_zone: HabitableZone) -> bool:
	if not habitable_zone:
		return false
	
	var zones_encountered = {}
	var sample_points = 8  # Check 8 points around the orbit
	
	# Everything in pixels now - no conversion needed!
	for i in range(sample_points):
		var angle = (i * 2.0 * PI) / sample_points
		var distance = semi_major_axis * (1 - eccentricity * eccentricity) / (1 + eccentricity * cos(angle))
		var zone = habitable_zone.get_zone_type(distance, angle)
		zones_encountered[zone] = true
	
	# Planet crosses zones if it encounters more than one zone type
	return zones_encountered.size() > 1

func get_info() -> Dictionary:
	var info = {
		"name": planet_name,
		"type": get_planet_type_name(),
		"size": planet_size,
		"distance": semi_major_axis,
		"atmosphere": has_atmosphere,
		"eccentricity": eccentricity,
		"orbit_speed": orbit_speed
	}
	
	# Add enhanced info if generated
	if enhanced_properties_generated:
		info["mass"] = data.mass
		info["radius"] = data.radius
		info["surface_gravity"] = data.surface_gravity
		info["axial_tilt"] = data.axial_tilt
		info["is_tidally_locked"] = data.is_tidally_locked
		info["atmosphere_type"] = PlanetEnums.AtmosphereType.keys()[atmosphere_type]
		info["atmosphere_pressure"] = atmosphere_pressure
		info["magnetosphere"] = PlanetEnums.MagnetosphereStrength.keys()[magnetosphere_strength]
		info["geological_activity"] = PlanetEnums.GeologicalActivity.keys()[geological_activity]
		info["climate_type"] = PlanetEnums.ClimateType.keys()[climate_type]
		info["surface_temperature"] = surface_temperature
		info["temperature_variation"] = data.temperature_variation
		info["moons_count"] = moons.size()
		info["tectonic_plates"] = tectonic_plates
		info["surface_liquids"] = surface_liquids
		info["surface_composition"] = surface_composition
		info["habitable_zone"] = HabitableZone.ZoneType.keys()[habitable_zone_type] if habitable_zone_type >= 0 else "UNKNOWN"
		
		# Add orbital habitability info
		var parent_system = get_parent()
		if parent_system and parent_system.habitable_zone:
			info["habitable_orbit_fraction"] = get_habitable_orbit_fraction(parent_system.habitable_zone)
			info["crosses_zones"] = crosses_habitable_zones(parent_system.habitable_zone)
			info["current_habitability"] = get_current_habitability(parent_system.habitable_zone)
	
	return info

func get_planet_type_name() -> String:
	# Planet types are defined in StarSystem, but to avoid circular dependencies,
	# we'll hardcode the names here
	var type_names = ["ROCKY_SMALL", "ROCKY_MEDIUM", "SUPER_EARTH", "ICE_GIANT", "GAS_GIANT", "SUPER_JUPITER"]
	if planet_type >= 0 and planet_type < type_names.size():
		return type_names[planet_type]
	return "UNKNOWN"

func set_selected(is_selected: bool) -> void:
	selected = is_selected
	if selected:
		planet_sprite.modulate = base_color.lightened(0.2)
	else:
		planet_sprite.modulate = base_color
			
func needs_enhanced_properties() -> bool:
	return not enhanced_properties_generated
	
func regenerate_enhanced_properties_if_needed():
	if not enhanced_properties_generated:
		generate_enhanced_properties()

func validate_enhanced_properties() -> bool:
	if not enhanced_properties_generated:
		return false
	
	# Check that required properties are set
	var required_checks = [
		atmosphere_type >= 0,
		atmosphere_pressure >= 0.0,
		magnetosphere_strength >= 0,
		geological_activity >= 0,
		climate_type >= 0,
		surface_temperature > 0.0
	]
	
	for check in required_checks:
		if not check:
			_log_warn('Warning: Enhanced properties validation failed for %s', [planet_name])
			return false
	
	return true
	
func get_enhanced_properties_summary() -> Dictionary:
	if not enhanced_properties_generated:
		return {"status": "not_generated"}
	
	return {
		"status": "generated",
		"atmosphere_type": PlanetEnums.AtmosphereType.keys()[atmosphere_type],
		"magnetosphere": PlanetEnums.MagnetosphereStrength.keys()[magnetosphere_strength],
		"geological_activity": PlanetEnums.GeologicalActivity.keys()[geological_activity],
		"climate_type": PlanetEnums.ClimateType.keys()[climate_type],
		"habitability_score": habitability_score,
		"surface_temperature": surface_temperature,
		"moons_count": moons.size()
	}

func set_probed_by(player_name: String):
	probed_by = player_name
	_update_probe_indicator()
	_update_name_label()  # NEW: Added this line
	_log_debug('DEBUG: set_probed_by called for %s by %s', [planet_name, player_name])
	
func _update_probe_indicator():
	if probe_indicator:
		probe_indicator.queue_free()
		probe_indicator = null
		
	if probed_by != "":
		probe_indicator = Label.new()
		probe_indicator.add_theme_font_override("font", TerminalTheme.get_terminal_font())
		probe_indicator.add_theme_color_override("font_color", Color.CYAN)
		probe_indicator.position = Vector2(planet_size + 5, -planet_size - 5)
		probe_indicator.tooltip_text = "Probed by: " + probed_by
		add_child(probe_indicator)

func _update_name_label():
	
	# Remove existing name label
	if name_label:
		name_label.queue_free()
		name_label = null
	
	# Only show name label if planet has been probed
	if probed_by != "":
		
		name_label = Label.new()
		name_label.text = planet_name
		name_label.add_theme_font_size_override("font_size", 10)
		
		# Apply terminal font styling
		name_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
		
		# Position the label to the right of the planet
		var label_offset = Vector2(planet_size + 20, 0)
		name_label.position = label_offset
		name_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		
		# Check if planet is habitable (habitability score > 0.5)
		var is_habitable = habitability_score > 0.5
		
		var text_color: Color
		var bg_color: Color
		
		if is_habitable:
			text_color = Color.WHITE
			bg_color = Color(0.2, 0.8, 0.2, 0.9)  # Bright green background
		else:
			text_color = Color.WHITE
			bg_color = Color(0.3, 0.3, 0.3, 0.8)  # Gray background
		
		name_label.add_theme_color_override("font_color", text_color)
		
		# Add background for visibility
		var stylebox = StyleBoxFlat.new()
		stylebox.bg_color = bg_color
		stylebox.corner_radius_top_left = 4
		stylebox.corner_radius_top_right = 4
		stylebox.corner_radius_bottom_left = 4
		stylebox.corner_radius_bottom_right = 4
		stylebox.content_margin_left = 6
		stylebox.content_margin_right = 6
		stylebox.content_margin_top = 3
		stylebox.content_margin_bottom = 3
		name_label.add_theme_stylebox_override("normal", stylebox)
		
		add_child(name_label)

