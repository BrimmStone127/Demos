class_name TreeInstance
extends RefCounted

## Represents a single tree with growth state on a planet surface.
## Trees age, grow through stages, and eventually die.

enum GrowthStage {
	SEEDLING,       # VG_1 - tiny tree sprout
	YOUNG_SAPLING,  # VG_2 - small young tree
	SAPLING,        # VG_3 - medium sapling
	YOUNG_MATURE,   # VG_4 - young adult, starts producing seeds
	MATURE,         # VG_5 - full mature, peak seed production
	VERY_MATURE,    # VG_6 - ancient tree, high seed production
	DORMANT         # DORM_6 - dead/fallen, will be removed
}

# Grid position on the planet map
var position: Vector2i
# Tile type used for the species visual (SF_TREE_1, SF_TREE_2, SF_TREE_3)
var species: int
var growth_stage: GrowthStage = GrowthStage.SEEDLING
var age_in_ticks: int = 0
var health: float = 1.0        # 0.0-1.0
var seed_production: float = 0.0

# Visual variation (consistent across lifecycle)
var visual_offset: Vector2 = Vector2.ZERO  # Random offset within tile for placement variety
var visual_scale: float = 1.0              # Size multiplier (affected by elevation)

## Dynamic growth thresholds set per-instance based on species and planet
## Array of 7 thresholds: [young_sapling, sapling, young_mature, mature, very_mature, dormant, removal]
## Calculated from: base_threshold / (species_multiplier × planet_modifier)
var _thresholds: Array[int] = []

const LOG_TAG := "TREE_INSTANCE"

## Initializes growth thresholds based on species config and planet modifier
##
## This creates instance-specific growth rates combining:
## - Base species growth rate (maple baseline = 1.0)
## - Planet environmental modifier (tropical = 1.5x faster, frozen = 0.3x slower)
##
## Example: Maple tree on tropical planet (species=1.0, planet=1.5):
##   Base threshold: 80 ticks
##   Final: 80 / (1.0 × 1.5) = 53 ticks to young sapling
func initialize_with_config(config: PlantSpeciesConfig, planet_modifier: float) -> void:
	_thresholds.clear()

	var effective_rate = config.growth_rate_multiplier * planet_modifier
	if effective_rate <= 0.0:
		GameLog.warn(LOG_TAG, "Invalid growth rate: species=%f planet=%f, defaulting to 1.0" % [
			config.growth_rate_multiplier, planet_modifier
		])
		effective_rate = 1.0

	# Calculate scaled thresholds for all 7 stages
	for base_threshold in config.base_tick_thresholds:
		var scaled = max(1, int(base_threshold / effective_rate))
		_thresholds.append(scaled)

	GameLog.debug(LOG_TAG, "Initialized %s at %s: thresholds=%s (rate=%.2f)" % [
		config.species_name,
		position,
		str(_thresholds),
		effective_rate
	])

## Set visual properties for sprite rendering
## elevation: 0-7, affects size (higher = larger trees, 1.0x to 1.5x base scale)
## Random variation adds 0% to +30% on top of elevation scaling
## Final range: 1.0x (normal) to 1.95x (nearly double) tree size
## seed: optional deterministic seed for reproducible placement
func set_visual_properties(elevation: int, p_seed: int = -1) -> void:
	# Use position-based seed for deterministic but varied placement
	var rng = RandomNumberGenerator.new()
	if p_seed >= 0:
		rng.seed = p_seed
	else:
		# Create deterministic seed from position
		rng.seed = hash(Vector2(position))

	# Random offset within tile (reduced for 1/4-height grass tiles: ±15px X, ±8px Y)
	visual_offset = Vector2(
		rng.randf_range(-15.0, 15.0),
		rng.randf_range(-8.0, 8.0)
	)

	# Elevation-based scaling: higher elevation = larger trees
	# Base range: 1.0 at elevation 0 → 1.5 at elevation 7 (50% larger at peaks)
	var elevation_factor = 1.0 + (float(elevation) / 7.0) * 0.5

	# Add random size variation: 0% to +30% for natural diversity
	# This makes each tree unique while maintaining elevation trend
	var random_factor = rng.randf_range(1.0, 1.3)

	# Combine factors: trees range from normal (1.0) to massive (1.95)
	visual_scale = elevation_factor * random_factor

func tick(health_delta: float = 0.0) -> void:
	age_in_ticks += 1
	health = clamp(health + health_delta, 0.0, 1.0)
	_update_growth_stage()
	_update_seed_production()

func _update_growth_stage() -> void:
	var old_stage = growth_stage

	# Health-based death - tree dies if health reaches 0
	if health <= 0.0:
		growth_stage = GrowthStage.DORMANT
		if old_stage != growth_stage:
			GameLog.warn(LOG_TAG, "Tree at %s died from health loss (health=%.2f)" % [position, health])
		return

	# Check if thresholds have been initialized
	if _thresholds.is_empty():
		GameLog.warn(LOG_TAG, "No thresholds set for tree at %s - call initialize_with_config first" % [position])
		return

	# Age-based progression using dynamic thresholds
	# Thresholds: [young_sapling, sapling, young_mature, mature, very_mature, dormant, removal]
	if age_in_ticks < _thresholds[0]:
		growth_stage = GrowthStage.SEEDLING
	elif age_in_ticks < _thresholds[1]:
		growth_stage = GrowthStage.YOUNG_SAPLING
	elif age_in_ticks < _thresholds[2]:
		growth_stage = GrowthStage.SAPLING
	elif age_in_ticks < _thresholds[3]:
		growth_stage = GrowthStage.YOUNG_MATURE
	elif age_in_ticks < _thresholds[4]:
		growth_stage = GrowthStage.MATURE
	elif age_in_ticks < _thresholds[5]:
		growth_stage = GrowthStage.VERY_MATURE
	else:
		# Past dormant threshold - tree dies
		growth_stage = GrowthStage.DORMANT

func _update_seed_production() -> void:
	match growth_stage:
		GrowthStage.YOUNG_MATURE:
			# Young mature trees start producing seeds
			seed_production = health * 0.5
		GrowthStage.MATURE:
			# Full mature trees have peak seed production
			seed_production = health * 1.0
		GrowthStage.VERY_MATURE:
			# Ancient trees still produce lots of seeds
			seed_production = health * 1.2
		_:
			# Seedlings, saplings, and dormant trees don't produce seeds
			seed_production = 0.0

func is_alive() -> bool:
	return growth_stage != GrowthStage.DORMANT and health > 0.0

## Returns true if tree should be removed from simulation.
## DORMANT trees stay visible for a period before removal.
func should_be_removed() -> bool:
	if growth_stage != GrowthStage.DORMANT:
		return false

	if _thresholds.size() < 7:
		# No removal threshold set, remove immediately
		return true

	# Tree is DORMANT - check if it's been dormant long enough to remove
	return age_in_ticks >= _thresholds[6]
