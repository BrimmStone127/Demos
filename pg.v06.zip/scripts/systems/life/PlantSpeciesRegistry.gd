class_name PlantSpeciesRegistry
extends RefCounted

## Central registry of all plant species configurations
##
## Singleton pattern provides global access to species data.
## Used by EcosystemManager to initialize plants with correct growth characteristics.

static var _instance: PlantSpeciesRegistry = null

## Maps tile type ID to species configuration
var _species_by_id: Dictionary = {}  # {int: PlantSpeciesConfig}

const LOG_TAG := "SPECIES_REGISTRY"

## Gets or creates the singleton instance
static func get_instance() -> PlantSpeciesRegistry:
	if _instance == null:
		_instance = PlantSpeciesRegistry.new()
		_instance._register_default_species()
	return _instance

## Resets the singleton instance (for testing)
static func reset_instance() -> void:
	_instance = null

## Registers all built-in species (trees and ground cover)
func _register_default_species() -> void:
	# Register ALL maple tree variants (both vegetative and dormant)
	# Use the actual tile IDs from MapleTreeTypes constants
	# Register all vegetative (green) maple trees
	for tile_id in MapleTreeTypes.ALL_VEGETATIVE:
		var config = PlantSpeciesConfig.create_maple_tree()
		config.species_id = tile_id
		_species_by_id[tile_id] = config

	# Register all dormant (bare) maple trees
	for tile_id in MapleTreeTypes.ALL_DORMANT:
		var config = PlantSpeciesConfig.create_maple_tree()
		config.species_id = tile_id
		_species_by_id[tile_id] = config

	GameLog.info(LOG_TAG, "Registered %d maple tree variants" % [
		MapleTreeTypes.ALL_VEGETATIVE.size() + MapleTreeTypes.ALL_DORMANT.size()
	])

	# Ground cover species
	var grass = PlantSpeciesConfig.create_grass()
	grass.species_id = 40  # R2 C0 - grass tile
	_species_by_id[40] = grass
	GameLog.info(LOG_TAG, "Registered grass (ID 40)")

	var goldenrod = PlantSpeciesConfig.create_goldenrod()
	goldenrod.species_id = 45  # R2 C5 - goldenrod tile
	_species_by_id[45] = goldenrod
	GameLog.info(LOG_TAG, "Registered goldenrod (ID 45)")

	GameLog.info(LOG_TAG, "Species registry initialized with %d species" % [_species_by_id.size()])

## Gets species configuration for a given tile ID
## Returns null if species not registered
func get_species_config(species_id: int) -> PlantSpeciesConfig:
	return _species_by_id.get(species_id, null)

## Registers a new species or replaces existing one
func register_species(config: PlantSpeciesConfig) -> void:
	if config.species_id < 0:
		GameLog.warn(LOG_TAG, "Attempted to register species with invalid ID: %d" % [config.species_id])
		return

	_species_by_id[config.species_id] = config
	GameLog.info(LOG_TAG, "Registered species: %s (ID %d)" % [config.species_name, config.species_id])

## Gets all registered species IDs
func get_all_species_ids() -> Array[int]:
	var ids: Array[int] = []
	for id in _species_by_id.keys():
		ids.append(id)
	return ids

## Gets count of registered species
func get_species_count() -> int:
	return _species_by_id.size()
