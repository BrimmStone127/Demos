class_name EcosystemManager
extends Node

## Manages living ecosystems on planet surfaces.
## Receives simulation ticks from TimeManager and updates tree growth/spreading.
## Trees grow through stages and spread seeds to adjacent grass tiles.

const LOG_TAG := "ECOSYSTEM"

## When true, trees start with varied ages for natural ecosystem distribution
## When false, all trees start at mature stage (old behavior)
const VARIED_INITIAL_AGES := true

## When true, ground cover (grass/goldenrod) is simulated alongside trees
## When false, only trees are simulated (simpler ecosystem model)
const ENABLE_GROUND_COVER_SIMULATION := false

## PERFORMANCE LIMITS to prevent lag spikes
# Base limits for 64×64 maps - these scale dynamically with map size
const BASE_MAX_SPREADS_PER_TICK := 512  # Maximum new trees per simulation tick (scales with map area)
const BASE_MAX_DEATHS_PER_TICK := 512   # Maximum tree removals per tick (balanced with spreads)
const MAX_TREES_PROCESSED_PER_TICK := 2000  # Hard cap on trees updated per tick (prevents lag with huge populations)
const PERF_LOG_THRESHOLD := 50     # Log warning if simulation takes >50ms

## CHUNKING SYSTEM (Minecraft-style)
# Divide map into chunks, only simulate active chunks
const CHUNK_SIZE := 64  # Tiles per chunk (64×64 tiles = ~10,240 pixels)
const ACTIVE_CHUNK_RADIUS := 3  # Simulate chunks within 3 chunks of center (7×7 = 49 chunks)
const CHUNK_UPDATE_THRESHOLD := 32  # Tiles - only update chunks if camera moves this far

signal tree_planted(position: Vector2i, species: int)
signal tree_died(position: Vector2i)
signal tree_spread(from_pos: Vector2i, to_pos: Vector2i)
signal tree_stage_changed(position: Vector2i)
signal ground_cover_planted(position: Vector2i, species: int)
signal ground_cover_died(position: Vector2i)

# PERFORMANCE: Batch signal emission - collect changes during simulation, emit after
signal trees_batch_updated(changed_positions: Array)  # Batched tree visual updates
signal ground_cover_batch_updated(changed_positions: Array)  # Batched ground cover visual updates

# planet_id -> Array[TreeInstance]
var trees_by_planet: Dictionary = {}

# PERFORMANCE: O(1) tree lookup by position
# planet_id -> { Vector2i -> TreeInstance }
var _trees_by_position: Dictionary = {}

# planet_id -> Array[GroundCoverInstance]
var ground_cover_by_planet: Dictionary = {}

# PERFORMANCE: O(1) ground cover lookup by position
# planet_id -> { Vector2i -> GroundCoverInstance }
var _ground_cover_by_position: Dictionary = {}

## Ground cover constants
# Base limits for 64×64 maps - these scale dynamically with map size
const BASE_MAX_GROUND_COVER_SPREADS_PER_TICK := 1024  # Much faster spreading than trees (scales with map area)
const BASE_MAX_GROUND_COVER_DEATHS_PER_TICK := 512
const GROUND_COVER_RANDOM_SPAWN_ATTEMPTS := 16  # Try to spawn this many new plants per tick on empty grass

## Tree random spawning (bootstrap empty ecosystems)
const TREE_RANDOM_SPAWN_ATTEMPTS := 4  # Fewer than ground cover (trees are larger/rarer)

## Testing: Set to false to disable random tree spawning (allows predictable test behavior)
var enable_random_tree_spawning := true

# planet_id -> Array (2D map tiles reference) for terrain queries
var map_tiles_by_planet: Dictionary = {}

# planet_id -> probe_data dict (contains climate_type etc.)
var planet_data_by_id: Dictionary = {}

# PERFORMANCE CACHE: planet_id -> pre-calculated environment modifier
# Avoids recalculating modifier every time a tree spreads
var _planet_env_modifiers: Dictionary = {}

# PERFORMANCE: planet_id -> tree processing offset (rotates through array)
# Ensures all trees get processed over multiple ticks, not just first N
var _tree_processing_offset: Dictionary = {}

## CHUNKING SYSTEM DATA STRUCTURES
# planet_id -> Dictionary[Vector2i chunk_pos -> Array[TreeInstance]]
var _tree_chunks: Dictionary = {}

# planet_id -> Array[Vector2i] (list of active chunk positions)
var _active_chunks: Dictionary = {}

# planet_id -> Vector2i (center chunk position for active area)
var _chunk_center: Dictionary = {}

# planet_id -> bool (true = simulate entire map, false = only active chunks)
# Sandbox can disable chunking to see full ecosystem behavior on large CSV maps
var _disable_chunking: Dictionary = {}

# planet_id -> int (custom chunk radius, overrides ACTIVE_CHUNK_RADIUS constant)
# Allows tuning performance vs ecosystem spread on per-planet basis
var _custom_chunk_radius: Dictionary = {}

# MAP SIZE CACHE: planet_id -> Vector2i (actual map bounds)
# Allows ecosystem to scale beyond hardcoded MAP_SIZE constant
var _planet_map_sizes: Dictionary = {}

# Phase 2 Integration: planet_id -> PlanetMapData reference (optional)
# Provides access to CoordinateSystem and centralized tile data
var _map_data_by_planet: Dictionary = {}

# Phase 3 Integration: ChunkManager handles chunk visibility logic
# Delegates chunk operations while keeping local _active_chunks synced for backward compat
var _chunk_manager: ChunkManager = null

# RNG seeded per planet for deterministic spreading
var _rng: RandomNumberGenerator = null

# Species registry singleton (lazily initialized)
var _species_registry: PlantSpeciesRegistry = null

func _ready():
	# Initialize RNG (cannot call .new() in class-level declarations)
	_rng = RandomNumberGenerator.new()
	_chunk_manager = ChunkManager.new()
	_ensure_species_registry()

## Ensures species registry is available (lazy initialization)
func _ensure_species_registry() -> void:
	if _species_registry == null:
		_species_registry = PlantSpeciesRegistry.get_instance()
		_log_info("EcosystemManager initialized with %d registered species", [_species_registry.get_species_count()])

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

# Called by TimeManager's simulation_tick signal
func on_simulation_tick(tick_number: int, _game_days: float) -> void:
	for planet_id in trees_by_planet:
		_simulate_planet_trees(planet_id, tick_number)
		if ENABLE_GROUND_COVER_SIMULATION:
			_simulate_planet_ground_cover(planet_id, tick_number)

# Register a planet's trees and map data for simulation
# map_data is optional - if provided, used for coordinate system access (Phase 2 integration)
func register_planet(planet_id: String, initial_trees: Array, map_tiles: Array, probe_data: Dictionary, map_data: PlanetMapData = null) -> void:
	# Store map_data reference if provided (enables CoordinateSystem usage)
	if map_data:
		_map_data_by_planet[planet_id] = map_data
	# Ensure species registry is available (needed before _ready if called early)
	_ensure_species_registry()

	# PERFORMANCE: Calculate and cache planet environmental modifier ONCE
	var env_modifier = _calculate_environment_modifier(probe_data)
	_planet_env_modifiers[planet_id] = env_modifier  # Cache for reuse during simulation

	# SCALABILITY: Calculate and cache actual map size (supports any size, not just 64×64!)
	var map_width = map_tiles.size()
	var map_height = 0
	if map_width > 0 and map_tiles[0] != null:
		map_height = map_tiles[0].size()
	var map_size = Vector2i(map_width, map_height)

	# Phase 3: Initialize ChunkManager for this planet
	if _chunk_manager:
		var coord_sys = map_data.coordinate_system if map_data else CoordinateSystem.new(map_size)
		_chunk_manager.initialize_planet(planet_id, map_size, coord_sys)
	_planet_map_sizes[planet_id] = map_size

	_log_info("Planet %s: %dx%d map, env_modifier=%.2f (climate: %s)", [
		planet_id, map_size.x, map_size.y, env_modifier, probe_data.get("climate_type", "TEMPERATE")
	])

	# Initialize trees with species config and planet modifier
	var initialized_trees: Array = []
	var skipped_trees := 0

	for tree in initial_trees:
		var original_species = tree.species
		var config = _species_registry.get_species_config(tree.species)
		var species_was_remapped := false

		if not config:
			# Unknown species - try to map to a known one or skip
			_log_warn("Unknown species %d at %s - attempting fallback", [original_species, tree.position])

			# Try to use any registered maple tree as fallback
			var fallback_id = MapleTreeTypes.ALL_VEGETATIVE[0] if MapleTreeTypes.ALL_VEGETATIVE.size() > 0 else -1
			if fallback_id >= 0:
				config = _species_registry.get_species_config(fallback_id)
				if config:
					tree.species = fallback_id  # Update to valid species
					species_was_remapped = true
					_log_info("Remapped species %d -> %d (maple fallback)", [original_species, fallback_id])

		if config:
			# Initialize if thresholds aren't set OR if species was remapped
			# (remapped species need fresh thresholds for the new species)
			var needs_init = tree._thresholds.is_empty() or species_was_remapped
			if needs_init:
				tree.initialize_with_config(config, env_modifier)

			# Apply varied ages for natural ecosystem distribution
			# This applies to BOTH new trees (age=0, stage=MATURE) AND restored trees
			# For restored trees, we re-randomize if VARIED_INITIAL_AGES is enabled
			if tree._thresholds.size() >= 7 and VARIED_INITIAL_AGES and initial_trees.size() >= 10:
				# Natural distribution: mostly mature, some young, some old/dormant
				# Use deterministic randomness based on position for consistency
				var pos_hash = abs(hash(str(tree.position)))
				var roll = pos_hash % 100

				if roll < 5:
					# 5% seedlings
					tree.age_in_ticks = 0
					tree.growth_stage = TreeInstance.GrowthStage.SEEDLING
				elif roll < 15:
					# 10% saplings
					tree.age_in_ticks = tree._thresholds[1]
					tree.growth_stage = TreeInstance.GrowthStage.SAPLING
				elif roll < 30:
					# 15% young mature
					tree.age_in_ticks = tree._thresholds[3]
					tree.growth_stage = TreeInstance.GrowthStage.YOUNG_MATURE
				elif roll < 70:
					# 40% mature
					tree.age_in_ticks = tree._thresholds[4]
					tree.growth_stage = TreeInstance.GrowthStage.MATURE
				elif roll < 90:
					# 20% very mature
					tree.age_in_ticks = tree._thresholds[5] - 1
					tree.growth_stage = TreeInstance.GrowthStage.VERY_MATURE
				else:
					# 10% dormant (ready for removal soon)
					tree.age_in_ticks = tree._thresholds[6]
					tree.growth_stage = TreeInstance.GrowthStage.DORMANT
			elif needs_init and tree._thresholds.size() >= 4:
				# Fallback: start at mature threshold if varied ages disabled
				tree.age_in_ticks = tree._thresholds[3]

			# Set visual properties for placement variety and elevation-based sizing
			var elevation = 0
			if tree.position.x < map_tiles.size() and tree.position.y < map_tiles[tree.position.x].size():
				var tile = map_tiles[tree.position.x][tree.position.y]
				if tile:
					elevation = tile.elevation
			tree.set_visual_properties(elevation)

			initialized_trees.append(tree)
		else:
			# No config available - skip this tree entirely
			skipped_trees += 1
			_log_warn("Skipping tree with unknown species %d at %s (no fallback)", [tree.species, tree.position])

	# DEBUG: Log stage distribution
	var stage_counts = {}
	for tree in initialized_trees:
		var stage_name = TreeInstance.GrowthStage.keys()[tree.growth_stage]
		stage_counts[stage_name] = stage_counts.get(stage_name, 0) + 1
	_log_info("Tree stage distribution: %s" % [stage_counts])

	if skipped_trees > 0:
		_log_warn("Skipped %d trees with unknown species during registration", [skipped_trees])

	trees_by_planet[planet_id] = initialized_trees
	ground_cover_by_planet[planet_id] = []  # Start with no ground cover
	map_tiles_by_planet[planet_id] = map_tiles
	planet_data_by_id[planet_id] = probe_data

	# PERFORMANCE: Build position index for O(1) lookup
	var pos_index: Dictionary = {}
	for tree in initialized_trees:
		pos_index[tree.position] = tree
	_trees_by_position[planet_id] = pos_index

	_log_info("Registered planet %s with %d initial trees", [planet_id, initialized_trees.size()])

## Add trees for a newly loaded chunk (chunk-mode planets only)
## Called after register_planet() as each chunk loads; initializes thresholds and
## distributes ages naturally. Skips positions already occupied.
func add_trees_for_chunk(planet_id: String, trees: Array[TreeInstance]) -> void:
	_ensure_species_registry()

	var env_modifier: float = _planet_env_modifiers.get(planet_id, 1.0)
	var existing_trees: Array = trees_by_planet.get(planet_id, [])
	var pos_index: Dictionary = _trees_by_position.get(planet_id, {})

	var initialized_count := 0
	for tree in trees:
		if pos_index.has(tree.position):
			continue  # Already registered (chunk reload)

		var config = _species_registry.get_species_config(tree.species)
		if not config:
			var fallback_id = MapleTreeTypes.ALL_VEGETATIVE[0] if MapleTreeTypes.ALL_VEGETATIVE.size() > 0 else -1
			if fallback_id >= 0:
				config = _species_registry.get_species_config(fallback_id)
				if config:
					tree.species = fallback_id
		if not config:
			continue

		tree.initialize_with_config(config, env_modifier)

		# Natural age distribution (same as VARIED_INITIAL_AGES in register_planet)
		if tree._thresholds.size() >= 7:
			var pos_hash: int = abs(hash(str(tree.position)))
			var roll: int = pos_hash % 100
			if roll < 5:
				tree.age_in_ticks = 0
				tree.growth_stage = TreeInstance.GrowthStage.SEEDLING
			elif roll < 15:
				tree.age_in_ticks = tree._thresholds[1]
				tree.growth_stage = TreeInstance.GrowthStage.SAPLING
			elif roll < 30:
				tree.age_in_ticks = tree._thresholds[3]
				tree.growth_stage = TreeInstance.GrowthStage.YOUNG_MATURE
			elif roll < 70:
				tree.age_in_ticks = tree._thresholds[4]
				tree.growth_stage = TreeInstance.GrowthStage.MATURE
			elif roll < 90:
				tree.age_in_ticks = tree._thresholds[5] - 1
				tree.growth_stage = TreeInstance.GrowthStage.VERY_MATURE
			else:
				tree.age_in_ticks = tree._thresholds[6]
				tree.growth_stage = TreeInstance.GrowthStage.DORMANT

		# Visual properties: deterministic from position hash (elevation hint is 0 since
		# chunk mode doesn't provide MapTile objects for elevation lookup)
		tree.set_visual_properties(0)

		existing_trees.append(tree)
		pos_index[tree.position] = tree
		add_tree_to_chunk(planet_id, tree)
		initialized_count += 1

	trees_by_planet[planet_id] = existing_trees
	_trees_by_position[planet_id] = pos_index

	_log_info("Added %d trees for chunk (planet %s, total: %d)", [initialized_count, planet_id, existing_trees.size()])

# Unregister a planet (e.g., when leaving the map view)
func unregister_planet(planet_id: String) -> void:
	trees_by_planet.erase(planet_id)
	ground_cover_by_planet.erase(planet_id)
	map_tiles_by_planet.erase(planet_id)
	planet_data_by_id.erase(planet_id)
	_planet_env_modifiers.erase(planet_id)  # Clear performance cache
	_trees_by_position.erase(planet_id)  # Clear position index
	_ground_cover_by_position.erase(planet_id)  # Clear ground cover position index
	_map_data_by_planet.erase(planet_id)  # Clear PlanetMapData reference (Phase 2)

	# Phase 3: Clean up ChunkManager state
	if _chunk_manager:
		_chunk_manager.unregister_planet(planet_id)

## Update planet map size when dynamic region loading expands the map
func _update_planet_map_size(planet_id: String, new_size: Vector2i) -> void:
	var old_size = _planet_map_sizes.get(planet_id, Vector2i(64, 64))
	if old_size != new_size:
		_planet_map_sizes[planet_id] = new_size
		_log_info("Planet %s map size updated: %s -> %s", [planet_id, old_size, new_size])

		# Update ChunkManager if present
		if _chunk_manager:
			var map_data = _map_data_by_planet.get(planet_id)
			var coord_sys = map_data.coordinate_system if map_data else CoordinateSystem.new(new_size)
			_chunk_manager.initialize_planet(planet_id, new_size, coord_sys)

## Calculates planet environmental growth rate modifier based on climate and atmosphere
##
## Returns multiplier for growth rates:
## - 1.0 = baseline (temperate)
## - >1.0 = faster growth (tropical, thick atmosphere)
## - <1.0 = slower growth (cold, thin atmosphere)
func _calculate_environment_modifier(probe_data: Dictionary) -> float:
	var climate: String = probe_data.get("climate_type", "TEMPERATE")
	var base_modifier := 1.0

	# Climate-based growth rate
	match climate:
		"TROPICAL":
			base_modifier = 1.5  # 50% faster - lush tropical growth
		"HOT":
			base_modifier = 1.2  # 20% faster
		"TEMPERATE":
			base_modifier = 1.0  # Baseline
		"COLD":
			base_modifier = 0.6  # 40% slower - harsh conditions
		"FROZEN":
			base_modifier = 0.3  # 70% slower - barely any growth
		_:
			base_modifier = 1.0

	# Atmosphere density bonus (thicker atmosphere = more protection/nutrients)
	var atmosphere_bonus = 1.0
	var atmo_type: String = probe_data.get("atmosphere_type", "MODERATE")
	if atmo_type == "THICK":
		atmosphere_bonus = 1.1  # 10% bonus
	elif atmo_type == "THIN":
		atmosphere_bonus = 0.9  # 10% penalty

	return base_modifier * atmosphere_bonus

func get_trees_for_planet(planet_id: String) -> Array:
	return trees_by_planet.get(planet_id, [])

func get_tree_at(p_planet_id: String, pos: Vector2i) -> TreeInstance:
	# PERFORMANCE: O(1) lookup using position index
	var pos_index: Dictionary = _trees_by_position.get(p_planet_id, {})
	return pos_index.get(pos, null)

## Count trees within a radius of a center position (for relocation site scoring)
func get_tree_count_near(p_planet_id: String, center: Vector2i, radius: int) -> int:
	var pos_index: Dictionary = _trees_by_position.get(p_planet_id, {})
	var count := 0
	for dx in range(-radius, radius + 1):
		for dy in range(-radius, radius + 1):
			if pos_index.has(center + Vector2i(dx, dy)):
				count += 1
	return count


func remove_tree_at(p_planet_id: String, pos: Vector2i) -> bool:
	var pos_index: Dictionary = _trees_by_position.get(p_planet_id, {})
	var tree: TreeInstance = pos_index.get(pos, null)
	if tree == null:
		return false

	# Remove from position index
	pos_index.erase(pos)

	# Remove from flat array
	var trees: Array = trees_by_planet.get(p_planet_id, [])
	trees.erase(tree)

	# Remove from chunk index
	remove_tree_from_chunk(p_planet_id, tree)

	emit_signal("tree_died", pos)
	return true

func _simulate_planet_trees(planet_id: String, tick_number: int) -> void:
	_ensure_species_registry()  # Ensure registry is available
	var start_time := Time.get_ticks_msec()  # Performance monitoring

	# CHUNKING: Use only active chunks (Minecraft-style optimization)
	var trees: Array[TreeInstance] = get_active_trees(planet_id)

	# Fallback: if chunks not initialized, use all trees and rebuild
	if trees.is_empty() and trees_by_planet.has(planet_id):
		var all_trees = trees_by_planet[planet_id]
		if not all_trees.is_empty():
			# First run: rebuild chunks
			var chunk_init_size = _planet_map_sizes.get(planet_id, Vector2i(64, 64))
			update_active_chunks(planet_id, Vector2i(chunk_init_size.x >> 1, chunk_init_size.y >> 1))
			rebuild_tree_chunks(planet_id)
			trees = get_active_trees(planet_id)
	# Don't early return if empty - we want to run bootstrapping spawns!

	var map_tiles: Array = map_tiles_by_planet.get(planet_id, [])
	var probe_data: Dictionary = planet_data_by_id.get(planet_id, {})
	var climate_type: String = probe_data.get("climate_type", "TEMPERATE")
	var map_size: Vector2i = _planet_map_sizes.get(planet_id, Vector2i(64, 64))

	# Seed RNG with planet + tick for determinism
	# Ensure RNG is initialized (for tests that don't go through _ready())
	if _rng == null:
		_rng = RandomNumberGenerator.new()
	_rng.seed = abs(hash(planet_id)) + tick_number

	var new_trees: Array[TreeInstance] = []
	var dead_positions: Array[Vector2i] = []
	var spread_count := 0  # Track spreads for performance limit

	# PERFORMANCE: Collect all changed positions for batched update
	var changed_positions: Array[Vector2i] = []

	# Calculate scaled limits based on map size (sqrt scaling for performance)
	# Cap spawn_multiplier at 2.0 to prevent overload on large maps (experimental/bootstrap-attempts fix)
	var base_area = 64 * 64
	var actual_area = map_size.x * map_size.y
	var area_ratio = float(actual_area) / float(base_area)
	var spawn_multiplier = minf(sqrt(area_ratio), 2.0)  # Capped at 2.0 to prevent system overload
	var max_spreads = int(BASE_MAX_SPREADS_PER_TICK * spawn_multiplier)
	var max_deaths = int(BASE_MAX_DEATHS_PER_TICK * spawn_multiplier)

	# Build a set of occupied positions for quick lookup
	var occupied: Dictionary = {}
	for tree in trees:
		occupied[tree.position] = true

	# PERFORMANCE: Limit how many trees we process per tick
	# On large maps with thousands of trees, processing all of them is expensive
	# Hard cap at MAX_TREES_PROCESSED_PER_TICK to prevent lag spikes
	# Rotate through array using offset so all trees eventually get processed
	var spread_attempts_remaining = max_spreads * 3  # Allow multiple attempts per successful spread
	var trees_processed = 0
	var max_trees_to_process = mini(trees.size(), MAX_TREES_PROCESSED_PER_TICK)
	var start_offset = _tree_processing_offset.get(planet_id, 0)

	# Rotate offset for next tick (wrap around at array size)
	_tree_processing_offset[planet_id] = (start_offset + max_trees_to_process) % maxi(trees.size(), 1)

	for i in range(trees.size()):
		var tree_index = (start_offset + i) % trees.size()
		var tree = trees[tree_index]
		# PERFORMANCE: Stop processing when we hit the per-tick limit
		if trees_processed >= max_trees_to_process:
			break
		trees_processed += 1

		var old_stage = tree.growth_stage
		var tile: MapTile = _get_tile(map_tiles, tree.position)
		var health_delta = _calculate_health_delta(tree, tile, climate_type, occupied)
		tree.tick(health_delta)

		# PERFORMANCE: Collect stage changes instead of emitting immediately
		if tree.growth_stage != old_stage:
			changed_positions.append(tree.position)
			# Emit individual signal for stage change (tests/listeners may need this)
			emit_signal("tree_stage_changed", tree.position)

		# Check if tree should be removed (DORMANT trees stay visible for a while)
		if tree.should_be_removed():
			dead_positions.append(tree.position)
			occupied.erase(tree.position)
			continue

		# DORMANT trees don't spread but stay in simulation until removal
		if not tree.is_alive():
			continue

		# PERFORMANCE: Stop processing trees if we've exhausted spread attempts
		# This prevents checking thousands of trees when population is large
		if spread_attempts_remaining <= 0:
			break

		# Mature/old trees attempt to spread seeds
		# PERFORMANCE LIMIT: Cap spreads per tick to prevent lag spikes (scales with map size)
		# Note: With chunking, we don't need a hard population cap since we only simulate active chunks
		if tree.growth_stage >= TreeInstance.GrowthStage.MATURE and spread_count < max_spreads:
			spread_attempts_remaining -= 1  # Decrement before attempting
			var spread_pos = _try_spread_seed(tree, map_tiles, occupied, map_size)
			if spread_pos != Vector2i(-1, -1):
				var new_tree = TreeInstance.new()
				new_tree.position = spread_pos
				new_tree.species = tree.species

				# PERFORMANCE: Use cached environment modifier instead of recalculating
				var config = _species_registry.get_species_config(tree.species)
				if config:
					var env_modifier = _planet_env_modifiers.get(planet_id, 1.0)
					new_tree.initialize_with_config(config, env_modifier)

					# JITTER: Add random initial age to spread out lifecycle progressions
					# This prevents all trees from dying/transitioning at the same tick
					# Jitter by 0 to (lifecycle_length / 2) to spread deaths across multiple ticks
					if new_tree._thresholds.size() >= 7:
						var max_jitter = new_tree._thresholds[6] >> 1  # Half lifecycle length
						new_tree.age_in_ticks = _rng.randi_range(0, max_jitter)

				# Set visual properties for placement variety and size
				var elevation = 0
				if spread_pos.x < map_tiles.size() and spread_pos.y < map_tiles[spread_pos.x].size():
					var spread_tile = map_tiles[spread_pos.x][spread_pos.y]
					if spread_tile:
						elevation = spread_tile.elevation
				new_tree.set_visual_properties(elevation)

				new_trees.append(new_tree)
				occupied[spread_pos] = true
				spread_count += 1
				changed_positions.append(spread_pos)  # New tree needs visual update

	# Remove dead trees using O(n) batch filter instead of O(n²) individual removal
	# Limit to max_deaths to prevent signal spam
	var removal_count := 0
	var positions_to_remove: Dictionary = {}  # Set of positions to remove

	for dead_pos in dead_positions:
		if removal_count >= max_deaths:
			_log_warn("Hit max_deaths limit (%d), %d trees left to remove", [max_deaths, dead_positions.size() - removal_count])
			break
		positions_to_remove[dead_pos] = true
		changed_positions.append(dead_pos)  # Dead tree needs visual update (removal)
		removal_count += 1

	# Get position index for this planet
	var pos_index: Dictionary = _trees_by_position.get(planet_id, {})

	# Single pass filter - O(n) instead of O(n²)
	if positions_to_remove.size() > 0:
		var surviving_trees: Array[TreeInstance] = []
		for tree in trees:
			if not positions_to_remove.has(tree.position):
				surviving_trees.append(tree)
			else:
				# PERFORMANCE: Remove from position index
				pos_index.erase(tree.position)
				# PERFORMANCE: Incremental chunk removal (O(1) per tree instead of O(n) rebuild)
				remove_tree_from_chunk(planet_id, tree)
				# Emit tree_died signal for each removed tree
				emit_signal("tree_died", tree.position)
		trees = surviving_trees

	# Add new saplings from spreading
	for new_tree in new_trees:
		trees.append(new_tree)
		# PERFORMANCE: Add to position index
		pos_index[new_tree.position] = new_tree
		# CHUNKING: Add to appropriate chunk
		add_tree_to_chunk(planet_id, new_tree)

	# BOOTSTRAP: Randomly spawn new trees on empty grass (helps start ecosystems from zero)
	# Can be disabled via enable_random_tree_spawning flag for predictable test behavior
	if not enable_random_tree_spawning:
		# Skip spawning section entirely for tests
		trees_by_planet[planet_id] = trees
		_trees_by_position[planet_id] = pos_index

		# NOTE: Chunk updates now happen incrementally:
		# - New trees added via add_tree_to_chunk() when spawned
		# - Dead trees removed via remove_tree_from_chunk() during filtering
		# No need for expensive rebuild_tree_chunks() call!

		# PERFORMANCE: Emit single batched signal AFTER simulation completes
		if changed_positions.size() > 0:
			emit_signal("trees_batch_updated", changed_positions)

		# PERFORMANCE MONITORING: Log if simulation took too long
		var early_elapsed := Time.get_ticks_msec() - start_time
		if early_elapsed > PERF_LOG_THRESHOLD:
			_log_warn("Planet %s sim=%dms (trees:%d, changes:%d, spreads:%d, deaths:%d)", [
				planet_id, early_elapsed, trees.size(), changed_positions.size(), spread_count, removal_count
			])
		else:
			_log_debug("Planet %s: %d trees after tick (%dms)", [planet_id, trees.size(), early_elapsed])
		return

	# Adaptive spawn rate based on map size (like ground cover)
	# Reuse spawn_multiplier from earlier calculation
	var tree_spawn_attempts = int(TREE_RANDOM_SPAWN_ATTEMPTS * spawn_multiplier)

	# Calculate spawn bounds (constrain to active chunks if chunking enabled)
	var spawn_bounds = _get_spawn_bounds(planet_id, map_size)

	# DEBUG: Log spawn parameters on first tick
	if tick_number == 1:
		_log_info("Tree spawn debug: map_size=%s, spawn_bounds=%s, attempts=%d, area_ratio=%.2f",
			[map_size, spawn_bounds, tree_spawn_attempts, area_ratio])

	var spawn_success_count := 0
	var spawn_fail_count := 0
	var max_x_attempted := 0
	var max_y_attempted := 0

	for _i in range(tree_spawn_attempts):
		var random_pos = Vector2i(_rng.randi_range(spawn_bounds.position.x, spawn_bounds.end.x - 1),
								   _rng.randi_range(spawn_bounds.position.y, spawn_bounds.end.y - 1))

		max_x_attempted = maxi(max_x_attempted, random_pos.x)
		max_y_attempted = maxi(max_y_attempted, random_pos.y)

		if _is_valid_tree_position(random_pos, map_tiles, occupied, map_size):
			spawn_success_count += 1
			# Randomly pick a tree species from maple variants
			var species = MapleTreeTypes.ALL_VEGETATIVE[_rng.randi() % MapleTreeTypes.ALL_VEGETATIVE.size()]
			var new_tree = TreeInstance.new()
			new_tree.position = random_pos
			new_tree.species = species

			# Initialize with config and environment
			var config = _species_registry.get_species_config(species)
			if config:
				var env_modifier = _planet_env_modifiers.get(planet_id, 1.0)
				new_tree.initialize_with_config(config, env_modifier)

				# JITTER: Add random initial age to spread out lifecycle progressions
				# This prevents all spawned trees from dying at the exact same tick
				if new_tree._thresholds.size() >= 7:
					var max_jitter = new_tree._thresholds[6] >> 1  # Half lifecycle length
					new_tree.age_in_ticks = _rng.randi_range(0, max_jitter)

			# Set visual properties based on tile elevation
			var tile: MapTile = _get_tile(map_tiles, random_pos)
			if tile:
				new_tree.set_visual_properties(tile.elevation)

			trees.append(new_tree)
			pos_index[new_tree.position] = new_tree
			# CHUNKING: Add to appropriate chunk
			add_tree_to_chunk(planet_id, new_tree)
			occupied[random_pos] = true
			changed_positions.append(random_pos)
		else:
			spawn_fail_count += 1

	# DEBUG: Log spawn results on first few ticks
	if tick_number <= 3:
		_log_info("Tree spawn results (tick %d): successes=%d, failures=%d, max_pos=(%d,%d), map_size=%s",
			[tick_number, spawn_success_count, spawn_fail_count, max_x_attempted, max_y_attempted, map_size])

	trees_by_planet[planet_id] = trees
	_trees_by_position[planet_id] = pos_index

	# NOTE: Chunk updates now happen incrementally:
	# - New trees added via add_tree_to_chunk() when spawned
	# - Dead trees removed via remove_tree_from_chunk() during filtering
	# No need for expensive rebuild_tree_chunks() call!

	# PERFORMANCE: Emit single batched signal AFTER simulation completes
	# This allows the renderer to process all updates at once instead of blocking the loop
	if changed_positions.size() > 0:
		emit_signal("trees_batch_updated", changed_positions)

	# PERFORMANCE MONITORING: Log if simulation took too long
	var elapsed := Time.get_ticks_msec() - start_time
	if elapsed > PERF_LOG_THRESHOLD:
		_log_warn("Planet %s sim=%dms (trees:%d, changes:%d, spreads:%d, deaths:%d)", [
			planet_id, elapsed, trees.size(), changed_positions.size(), spread_count, removal_count
		])
	else:
		_log_debug("Planet %s: %d trees after tick (%dms)", [planet_id, trees.size(), elapsed])

func _calculate_health_delta(_tree: TreeInstance, _tile: MapTile, _climate_type: String, _occupied: Dictionary) -> float:
	# NO HEALTH PENALTIES - trees only die from old age
	# This ensures all trees live through all 6 visual stages
	return 0.0

func _try_spread_seed(tree: TreeInstance, map_tiles: Array, occupied: Dictionary, map_size: Vector2i = Vector2i(64, 64)) -> Vector2i:
	# Dynamic spread radius based on map size for faster coverage on large maps
	# 64×64: radius=1, 452×452: radius=3, 903×903: radius=4
	# Reduced max from 5 to 3 to limit neighbor checks on very large maps
	var area_ratio = float(map_size.x * map_size.y) / float(64 * 64)
	var spread_radius = clampi(int(sqrt(area_ratio)), 1, 3)  # Min 1, max 3 (48 neighbors vs 80)

	var neighbors = _get_neighbor_positions(tree.position, spread_radius)
	# Shuffle for random spread direction using seeded RNG
	for i in range(neighbors.size() - 1, 0, -1):
		var j = _rng.randi_range(0, i)
		var tmp = neighbors[i]
		neighbors[i] = neighbors[j]
		neighbors[j] = tmp

	for pos in neighbors:
		if _is_valid_tree_position(pos, map_tiles, occupied, map_size):
			if _rng.randf() < tree.seed_production * 0.1:
				return pos

	return Vector2i(-1, -1)

const SPREAD_EDGE_MARGIN := 0  # Allow spreading to edge tiles (full map coverage)
const MAP_SIZE := 64  # Legacy default (prefer using cached planet map sizes)

func _is_valid_tree_position(pos: Vector2i, map_tiles: Array, occupied: Dictionary, map_size: Vector2i = Vector2i(64, 64)) -> bool:
	# Don't spread to edge tiles (match generator's EDGE_MARGIN)
	if pos.x < SPREAD_EDGE_MARGIN or pos.x >= map_size.x - SPREAD_EDGE_MARGIN:
		return false
	if pos.y < SPREAD_EDGE_MARGIN or pos.y >= map_size.y - SPREAD_EDGE_MARGIN:
		return false

	if occupied.has(pos):
		return false
	var tile: MapTile = _get_tile(map_tiles, pos)
	if tile == null:
		return false
	return (tile.type == PlanetMapTileConfig.TileType.GRASS_0 or
		tile.type == PlanetMapTileConfig.TileType.GRASS_1 or
		tile.type == PlanetMapTileConfig.TileType.GRASS_2)

func _get_neighbor_positions(pos: Vector2i, radius: int = 1) -> Array[Vector2i]:
	"""Get all positions within radius tiles of pos (scales with map size for faster coverage)."""
	var neighbors: Array[Vector2i] = []
	for dx in range(-radius, radius + 1):
		for dy in range(-radius, radius + 1):
			if dx == 0 and dy == 0:
				continue
			var neighbor = pos + Vector2i(dx, dy)
			# Only check for negative bounds - upper bounds checked by validation functions
			# This allows spreading on any size map (64x64, 903x903, etc.)
			if neighbor.x >= 0 and neighbor.y >= 0:
				neighbors.append(neighbor)
	return neighbors

func _count_adjacent_trees(pos: Vector2i, occupied: Dictionary) -> int:
	var count := 0
	for dx in [-1, 0, 1]:
		for dy in [-1, 0, 1]:
			if dx == 0 and dy == 0:
				continue
			if occupied.has(pos + Vector2i(dx, dy)):
				count += 1
	return count

func _get_tile(map_tiles: Array, pos: Vector2i) -> MapTile:
	if map_tiles.is_empty():
		return null
	if pos.x < 0 or pos.y < 0 or pos.x >= map_tiles.size():
		return null
	var column = map_tiles[pos.x]
	if column == null or pos.y >= column.size():
		return null
	var tile = column[pos.y]
	return tile if tile is MapTile else null

## Simulates ground cover growth and spreading for one planet
func _simulate_planet_ground_cover(planet_id: String, tick_number: int) -> void:
	var ground_cover: Array = ground_cover_by_planet.get(planet_id, [])
	var map_tiles: Array = map_tiles_by_planet.get(planet_id, [])
	var trees: Array = trees_by_planet.get(planet_id, [])
	var map_size: Vector2i = _planet_map_sizes.get(planet_id, Vector2i(64, 64))

	# Build occupied positions (trees + existing ground cover)
	var occupied: Dictionary = {}
	var tree_positions: Dictionary = {}
	for tree in trees:
		occupied[tree.position] = true
		tree_positions[tree.position] = tree
	for plant in ground_cover:
		occupied[plant.position] = true

	var new_plants: Array[GroundCoverInstance] = []
	var dead_positions: Array[Vector2i] = []
	var changed_positions: Array[Vector2i] = []
	var spread_count := 0

	# Calculate scaled limits based on map size (sqrt scaling for performance)
	# Cap spawn_multiplier at 2.0 to prevent overload on large maps (experimental/bootstrap-attempts fix)
	var base_area = 64 * 64
	var actual_area = map_size.x * map_size.y
	var area_ratio = float(actual_area) / float(base_area)
	var spawn_multiplier = minf(sqrt(area_ratio), 2.0)  # Capped at 2.0 to prevent system overload
	var max_spreads = int(BASE_MAX_GROUND_COVER_SPREADS_PER_TICK * spawn_multiplier)
	var max_deaths = int(BASE_MAX_GROUND_COVER_DEATHS_PER_TICK * spawn_multiplier)

	# Tick existing ground cover
	for plant in ground_cover:
		var old_stage = plant.growth_stage
		plant.tick(0.0)  # No health penalties

		if plant.growth_stage != old_stage:
			changed_positions.append(plant.position)

		if plant.should_be_removed():
			dead_positions.append(plant.position)
			occupied.erase(plant.position)
			continue

		if not plant.is_alive():
			continue

		# Mature ground cover spreads seeds
		if plant.growth_stage == GroundCoverInstance.GrowthStage.MATURE and spread_count < max_spreads:
			var spread_pos = _try_spread_ground_cover(plant, map_tiles, occupied, map_size)
			if spread_pos != Vector2i(-1, -1):
				var new_plant = GroundCoverInstance.new()
				new_plant.position = spread_pos
				new_plant.species = plant.species  # Same species (goldenrod spreads goldenrod)

				var config = _species_registry.get_species_config(plant.species)
				if config:
					var env_modifier = _planet_env_modifiers.get(planet_id, 1.0)
					new_plant.initialize_with_config(config, env_modifier)

				new_plants.append(new_plant)
				occupied[spread_pos] = true
				spread_count += 1
				changed_positions.append(spread_pos)

	# Randomly spawn new goldenrod on empty grass tiles (creates independent fields)
	# Reuse spawn_multiplier from earlier calculation
	var spawn_attempts = int(GROUND_COVER_RANDOM_SPAWN_ATTEMPTS * spawn_multiplier)

	# Use same spawn bounds as trees (constrained to active chunks if chunking enabled)
	var spawn_bounds = _get_spawn_bounds(planet_id, map_size)

	var gc_spawn_success := 0
	var gc_spawn_fail := 0
	var gc_max_x := 0
	var gc_max_y := 0

	for _i in range(spawn_attempts):
		var random_pos = Vector2i(_rng.randi_range(spawn_bounds.position.x, spawn_bounds.end.x - 1),
								   _rng.randi_range(spawn_bounds.position.y, spawn_bounds.end.y - 1))

		gc_max_x = maxi(gc_max_x, random_pos.x)
		gc_max_y = maxi(gc_max_y, random_pos.y)

		if _is_valid_ground_cover_position(random_pos, map_tiles, occupied, map_size):
			gc_spawn_success += 1
			var goldenrod = GroundCoverInstance.new()
			goldenrod.position = random_pos
			goldenrod.species = 45  # Goldenrod tile ID (R2C5)

			var config = _species_registry.get_species_config(45)
			if config:
				var env_modifier = _planet_env_modifiers.get(planet_id, 1.0)
				goldenrod.initialize_with_config(config, env_modifier)

			new_plants.append(goldenrod)
			occupied[random_pos] = true
			changed_positions.append(random_pos)
		else:
			gc_spawn_fail += 1

	# DEBUG: Log ground cover spawn results on first few ticks
	if tick_number <= 3:
		_log_info("Ground cover spawn (tick %d): successes=%d, failures=%d, max_pos=(%d,%d), map_size=%s",
			[tick_number, gc_spawn_success, gc_spawn_fail, gc_max_x, gc_max_y, map_size])

	# Remove dead ground cover (O(n) batch filter)
	var removal_count := 0
	var positions_to_remove: Dictionary = {}
	for dead_pos in dead_positions:
		if removal_count >= max_deaths:
			break
		positions_to_remove[dead_pos] = true
		removal_count += 1

	# Get/create position index
	var pos_index: Dictionary = _ground_cover_by_position.get(planet_id, {})

	if positions_to_remove.size() > 0:
		var surviving: Array = []
		for plant in ground_cover:
			if not positions_to_remove.has(plant.position):
				surviving.append(plant)
			else:
				pos_index.erase(plant.position)
		ground_cover = surviving

	# Add new plants
	for new_plant in new_plants:
		ground_cover.append(new_plant)
		pos_index[new_plant.position] = new_plant

	ground_cover_by_planet[planet_id] = ground_cover
	_ground_cover_by_position[planet_id] = pos_index

	# Emit batched update signal
	if changed_positions.size() > 0:
		emit_signal("ground_cover_batch_updated", changed_positions)

	_log_debug("Ground cover: %d plants, %d new, %d died" % [ground_cover.size(), new_plants.size(), removal_count])

## Try to spread ground cover to a neighboring grass tile
func _try_spread_ground_cover(plant: GroundCoverInstance, map_tiles: Array, occupied: Dictionary, map_size: Vector2i = Vector2i(64, 64)) -> Vector2i:
	# Dynamic spread radius (same as trees) for faster coverage on large maps
	var area_ratio = float(map_size.x * map_size.y) / float(64 * 64)
	var spread_radius = clampi(int(sqrt(area_ratio)), 1, 3)  # Min 1, max 3 (performance)

	var neighbors = _get_neighbor_positions(plant.position, spread_radius)

	# Shuffle neighbors
	for i in range(neighbors.size() - 1, 0, -1):
		var j = _rng.randi_range(0, i)
		var tmp = neighbors[i]
		neighbors[i] = neighbors[j]
		neighbors[j] = tmp

	for pos in neighbors:
		if _is_valid_ground_cover_position(pos, map_tiles, occupied, map_size):
			if _rng.randf() < plant.seed_production * 0.9:  # Very high spread chance - carpets ground quickly
				return pos

	return Vector2i(-1, -1)

## Check if a position is valid for ground cover
func _is_valid_ground_cover_position(pos: Vector2i, map_tiles: Array, occupied: Dictionary, map_size: Vector2i = Vector2i(64, 64)) -> bool:
	# Edge margins (same as trees)
	if pos.x < SPREAD_EDGE_MARGIN or pos.x >= map_size.x - SPREAD_EDGE_MARGIN:
		return false
	if pos.y < SPREAD_EDGE_MARGIN or pos.y >= map_size.y - SPREAD_EDGE_MARGIN:
		return false

	if occupied.has(pos):
		return false

	var tile: MapTile = _get_tile(map_tiles, pos)
	if tile == null:
		return false

	# Ground cover grows on grass tiles without trees
	return (tile.type == PlanetMapTileConfig.TileType.GRASS_0 or
		tile.type == PlanetMapTileConfig.TileType.GRASS_1 or
		tile.type == PlanetMapTileConfig.TileType.GRASS_2)

## ============================================================================
## CHUNKING SYSTEM (Minecraft-style optimization)
## ============================================================================

## Convert world tile position to chunk coordinates
func world_pos_to_chunk(pos: Vector2i) -> Vector2i:
	return Vector2i(pos.x >> 6, pos.y >> 6)

## Get or create chunk tree array for a planet
func get_chunk_trees(planet_id: String, chunk_pos: Vector2i) -> Array:
	if not _tree_chunks.has(planet_id):
		_tree_chunks[planet_id] = {}
	var planet_chunks = _tree_chunks[planet_id]
	if not planet_chunks.has(chunk_pos):
		planet_chunks[chunk_pos] = []
	return planet_chunks[chunk_pos]

## Add tree to appropriate chunk
func add_tree_to_chunk(planet_id: String, tree: TreeInstance) -> void:
	var chunk_pos = world_pos_to_chunk(tree.position)
	var chunk_trees = get_chunk_trees(planet_id, chunk_pos)
	chunk_trees.append(tree)

## Remove tree from its chunk (O(1) lookup + O(chunk_size) removal)
## Much faster than rebuild_tree_chunks() which is O(total_trees)
func remove_tree_from_chunk(planet_id: String, tree: TreeInstance) -> void:
	if not _tree_chunks.has(planet_id):
		return
	var chunk_pos = world_pos_to_chunk(tree.position)
	var planet_chunks = _tree_chunks[planet_id]
	if planet_chunks.has(chunk_pos):
		var chunk_trees: Array = planet_chunks[chunk_pos]
		chunk_trees.erase(tree)  # O(chunk_size) but chunk is small (~50-200 trees)

## Update which chunks are active (near center position)
## Phase 3: Now delegates to ChunkManager while keeping local state synced for backward compat
func update_active_chunks(planet_id: String, center_pos: Vector2i) -> void:
	# Delegate to ChunkManager if available
	if _chunk_manager:
		_chunk_manager.update_active_chunks(planet_id, center_pos)
		# Sync local state for backward compatibility with code that reads _active_chunks directly
		_active_chunks[planet_id] = _chunk_manager.get_active_chunks(planet_id)
		_chunk_center[planet_id] = world_pos_to_chunk(center_pos)
	else:
		# Legacy fallback: calculate locally
		var center_chunk = world_pos_to_chunk(center_pos)
		_chunk_center[planet_id] = center_chunk

		# Use custom radius if set, otherwise use default
		var chunk_radius = _custom_chunk_radius.get(planet_id, ACTIVE_CHUNK_RADIUS)

		var active = []
		for dx in range(-chunk_radius, chunk_radius + 1):
			for dy in range(-chunk_radius, chunk_radius + 1):
				active.append(center_chunk + Vector2i(dx, dy))

		_active_chunks[planet_id] = active

	# DEBUG: Log chunk initialization (using info for visibility)
	var total_chunks = _active_chunks.get(planet_id, []).size()
	var log_radius = _custom_chunk_radius.get(planet_id, ACTIVE_CHUNK_RADIUS)
	_log_info("[CHUNKS] Active chunks set for %s: %d chunks (center: %s, radius: %d)",
		[planet_id, total_chunks, _chunk_center.get(planet_id, Vector2i.ZERO), log_radius])

## Get all trees in active chunks (or all trees if chunking disabled)
func get_active_trees(planet_id: String) -> Array[TreeInstance]:
	# If chunking disabled for this planet, return all trees
	if _disable_chunking.get(planet_id, false):
		var all_trees: Array = trees_by_planet.get(planet_id, [])
		var result: Array[TreeInstance] = []
		for tree in all_trees:
			result.append(tree)
		return result

	# Otherwise, return only trees in active chunks
	var active_trees: Array[TreeInstance] = []
	var active = _active_chunks.get(planet_id, [])

	if not _tree_chunks.has(planet_id):
		return active_trees

	var planet_chunks = _tree_chunks[planet_id]
	for chunk_pos in active:
		if planet_chunks.has(chunk_pos):
			var chunk_trees: Array = planet_chunks[chunk_pos]
			for tree in chunk_trees:
				active_trees.append(tree)

	return active_trees

## Rebuild chunk structure from existing tree array
func rebuild_tree_chunks(planet_id: String) -> void:
	var trees = trees_by_planet.get(planet_id, [])
	_tree_chunks[planet_id] = {}
	
	for tree in trees:
		add_tree_to_chunk(planet_id, tree)
	
	_log_info("Rebuilt chunks for planet %s: %d trees in %d chunks", 
		[planet_id, trees.size(), _tree_chunks[planet_id].size()])

## Update chunk center based on camera position (with hysteresis)
## Only updates if the chunk center actually changes (not just pixel movement)
## Phase 3: Now delegates to ChunkManager while keeping local state synced
func update_chunk_center_from_camera(planet_id: String, camera_world_pos: Vector2) -> bool:
	# Delegate to ChunkManager if available
	if _chunk_manager:
		# Get or create coordinate system for this planet
		var coord_sys: CoordinateSystem = null
		if _map_data_by_planet.has(planet_id):
			coord_sys = _map_data_by_planet[planet_id].coordinate_system

		var changed = _chunk_manager.update_chunk_center_from_camera(planet_id, camera_world_pos, coord_sys)

		# Sync local state if chunks changed
		if changed:
			_active_chunks[planet_id] = _chunk_manager.get_active_chunks(planet_id)
			var cam_tile_pos = world_to_tile(camera_world_pos)
			_chunk_center[planet_id] = world_pos_to_chunk(cam_tile_pos)
			var active_tree_count = get_active_trees(planet_id).size()
			_log_info("[CHUNKS] Chunk changed via ChunkManager | Active: %d chunks, %d trees",
				[_active_chunks.get(planet_id, []).size(), active_tree_count])

		return changed

	# Legacy fallback: calculate locally
	var tile_pos = world_to_tile(camera_world_pos)
	var current_chunk = world_pos_to_chunk(tile_pos)

	# First call for this planet - initialize and force update
	if not _chunk_center.has(planet_id):
		update_active_chunks(planet_id, tile_pos)
		_log_info("[CHUNKS] First camera position for %s: chunk %s | Active: 49 chunks", [planet_id, current_chunk])
		return true

	# Get the previous chunk center
	var last_chunk = _chunk_center[planet_id]

	# Only update if chunk center actually changed
	if current_chunk == last_chunk:
		return false  # No update needed - still in same chunk region

	# Chunk changed - update active chunks
	update_active_chunks(planet_id, tile_pos)

	var active_trees = get_active_trees(planet_id).size()
	_log_info("[CHUNKS] Chunk changed %s -> %s | Active: 49 chunks, %d trees",
		[last_chunk, current_chunk, active_trees])

	return true  # Chunks were updated

## Get spawn bounds for random tree/ground cover placement
## If chunking enabled, constrain to active chunks. If disabled, use full map.
## Phase 3: Now delegates to ChunkManager while keeping local fallback
func _get_spawn_bounds(planet_id: String, map_size: Vector2i) -> Rect2i:
	# Delegate to ChunkManager if available
	if _chunk_manager:
		return _chunk_manager.get_spawn_bounds(planet_id, map_size, SPREAD_EDGE_MARGIN)

	# Legacy fallback: calculate locally
	# If chunking disabled, spawn across entire map
	if _disable_chunking.get(planet_id, false):
		return Rect2i(Vector2i(SPREAD_EDGE_MARGIN, SPREAD_EDGE_MARGIN),
			Vector2i(map_size.x - SPREAD_EDGE_MARGIN * 2, map_size.y - SPREAD_EDGE_MARGIN * 2))

	# Otherwise, calculate bounds from active chunks
	var active = _active_chunks.get(planet_id, [])
	if active.is_empty():
		# Fallback to center chunk if no active chunks set
		return Rect2i(Vector2i(0, 0), Vector2i(CHUNK_SIZE, CHUNK_SIZE))

	# Find min/max chunk positions
	var min_chunk = active[0]
	var max_chunk = active[0]
	for chunk_pos in active:
		min_chunk.x = mini(min_chunk.x, chunk_pos.x)
		min_chunk.y = mini(min_chunk.y, chunk_pos.y)
		max_chunk.x = maxi(max_chunk.x, chunk_pos.x)
		max_chunk.y = maxi(max_chunk.y, chunk_pos.y)

	# Convert chunk positions to tile positions
	var min_tile = min_chunk * CHUNK_SIZE
	var max_tile = (max_chunk + Vector2i(1, 1)) * CHUNK_SIZE

	# Apply edge margin and clamp to map bounds
	var spawn_min = Vector2i(maxi(min_tile.x + SPREAD_EDGE_MARGIN, SPREAD_EDGE_MARGIN),
							 maxi(min_tile.y + SPREAD_EDGE_MARGIN, SPREAD_EDGE_MARGIN))
	var spawn_max = Vector2i(mini(max_tile.x - SPREAD_EDGE_MARGIN, map_size.x - SPREAD_EDGE_MARGIN),
							 mini(max_tile.y - SPREAD_EDGE_MARGIN, map_size.y - SPREAD_EDGE_MARGIN))

	return Rect2i(spawn_min, spawn_max - spawn_min)

## Convert world position to tile position (isometric)
func world_to_tile(world_pos: Vector2) -> Vector2i:
	# Isometric coordinate conversion
	# Based on PlanetMapTileConfig.TILE_SIZE = (160, 80)
	var tile_width = 160.0
	var tile_height = 80.0
	
	# Inverse isometric transformation
	var tile_x = int((world_pos.x / tile_width) + (world_pos.y / tile_height))
	var tile_y = int((world_pos.y / tile_height) - (world_pos.x / tile_width))
	
	return Vector2i(tile_x, tile_y)

## Set custom chunk radius for a planet (controls how many chunks around camera to simulate)
## Default is ACTIVE_CHUNK_RADIUS (3) = 7x7 = 49 chunks
## Smaller values = better performance but more "pocket" effect
## Larger values = worse performance but more natural ecosystem spread
## Examples: radius=1 -> 3x3=9 chunks, radius=2 -> 5x5=25 chunks, radius=3 -> 7x7=49 chunks
func set_chunk_radius(planet_id: String, radius: int) -> void:
	_custom_chunk_radius[planet_id] = radius

	# Phase 3: Sync with ChunkManager
	if _chunk_manager:
		_chunk_manager.set_chunk_radius(planet_id, radius)

	var chunk_count = (radius * 2 + 1) * (radius * 2 + 1)
	_log_info("Chunk radius set to %d for %s -> %dx%d = %d chunks active",
		[radius, planet_id, radius * 2 + 1, radius * 2 + 1, chunk_count])

## Disable chunking for a planet (simulate entire map instead of just active chunks)
## Use this for sandbox/testing scenarios where you want to see full ecosystem behavior
## WARNING: Performance intensive on large maps! Only use for testing/visualization
func set_chunking_disabled(planet_id: String, disabled: bool) -> void:
	_disable_chunking[planet_id] = disabled

	# Phase 3: Sync with ChunkManager
	if _chunk_manager:
		_chunk_manager.set_chunking_disabled(planet_id, disabled)

	if disabled:
		_log_info("Chunking DISABLED for %s - will simulate entire map (performance intensive!)", [planet_id])
	else:
		_log_info("Chunking ENABLED for %s - will only simulate active chunks", [planet_id])

## Call this every frame/tick to keep chunks synchronized with camera
## @param camera_node: The Camera2D node tracking the view
func sync_chunks_with_camera(planet_id: String, camera_node: Camera2D) -> void:
	if not camera_node or not is_instance_valid(camera_node):
		_log_warn("sync_chunks_with_camera: invalid camera node for planet %s", [planet_id])
		return

	# Get camera's world position and update chunks if needed
	var camera_pos = camera_node.get_screen_center_position()
	update_chunk_center_from_camera(planet_id, camera_pos)
