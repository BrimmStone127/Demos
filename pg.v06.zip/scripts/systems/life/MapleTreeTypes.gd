class_name MapleTreeTypes
extends RefCounted

## Maple tree asset aliases for lifecycle simulation
##
## Provides semantic names for maple tree growth stages:
## - VG (Vegetative): Green, leafy trees in active growth
## - DORM (Dormant): Bare trees without leaves (winter/declining state)
##
## Each type has 6 size variants, with 6 being the largest.
## Located in tileset at:
## - Row 3, Columns 14-19: Dormant trees (DORM_1 through DORM_6)
## - Row 4, Columns 14-19: Vegetative trees (VG_1 through VG_6)

const GenTiles = GeneratedTileTypes.TileType

# Dormant trees (bare, no leaves) - Row 3, Cols 14-19
const TR_MAPL_DORM_1 = GenTiles.TILE_R3_C14  # Smallest dormant
const TR_MAPL_DORM_2 = GenTiles.TILE_R3_C15
const TR_MAPL_DORM_3 = GenTiles.TILE_R3_C16
const TR_MAPL_DORM_4 = GenTiles.TILE_R3_C17
const TR_MAPL_DORM_5 = GenTiles.TILE_R3_C18
const TR_MAPL_DORM_6 = GenTiles.TILE_R3_C19  # Largest dormant

# Vegetative trees (green, leafy) - Row 4, Cols 14-19
const TR_MAPL_VG_1 = GenTiles.TILE_R4_C14    # Smallest vegetative
const TR_MAPL_VG_2 = GenTiles.TILE_R4_C15
const TR_MAPL_VG_3 = GenTiles.TILE_R4_C16
const TR_MAPL_VG_4 = GenTiles.TILE_R4_C17
const TR_MAPL_VG_5 = GenTiles.TILE_R4_C18
const TR_MAPL_VG_6 = GenTiles.TILE_R4_C19    # Largest vegetative

# All vegetative tree sizes in order (for random selection)
const ALL_VEGETATIVE = [
	TR_MAPL_VG_1,
	TR_MAPL_VG_2,
	TR_MAPL_VG_3,
	TR_MAPL_VG_4,
	TR_MAPL_VG_5,
	TR_MAPL_VG_6,
]

# All dormant tree sizes in order
const ALL_DORMANT = [
	TR_MAPL_DORM_1,
	TR_MAPL_DORM_2,
	TR_MAPL_DORM_3,
	TR_MAPL_DORM_4,
	TR_MAPL_DORM_5,
	TR_MAPL_DORM_6,
]

# All maple tree types combined (for generator diversity)
const ALL_MAPLE_TREES = [
	TR_MAPL_VG_1,
	TR_MAPL_VG_2,
	TR_MAPL_VG_3,
	TR_MAPL_VG_4,
	TR_MAPL_VG_5,
	TR_MAPL_VG_6,
	TR_MAPL_DORM_1,
	TR_MAPL_DORM_2,
	TR_MAPL_DORM_3,
	TR_MAPL_DORM_4,
	TR_MAPL_DORM_5,
	TR_MAPL_DORM_6,
]

## Get tree tile for a specific growth stage
## Direct 1:1 mapping - each growth stage = one visual asset
static func get_tile_for_growth(stage: TreeInstance.GrowthStage, _age_in_ticks: int) -> int:
	var tile_id = -1

	match stage:
		TreeInstance.GrowthStage.SEEDLING:
			tile_id = TR_MAPL_VG_1  # VG_1 - tiny tree sprout

		TreeInstance.GrowthStage.YOUNG_SAPLING:
			tile_id = TR_MAPL_VG_2  # VG_2 - small young tree

		TreeInstance.GrowthStage.SAPLING:
			tile_id = TR_MAPL_VG_3  # VG_3 - medium sapling

		TreeInstance.GrowthStage.YOUNG_MATURE:
			tile_id = TR_MAPL_VG_4  # VG_4 - young adult (starts seeding)

		TreeInstance.GrowthStage.MATURE:
			tile_id = TR_MAPL_VG_5  # VG_5 - full mature (peak seeding)

		TreeInstance.GrowthStage.VERY_MATURE:
			tile_id = TR_MAPL_VG_6  # VG_6 - ancient tree (high seeding)

		TreeInstance.GrowthStage.DORMANT:
			tile_id = TR_MAPL_DORM_6  # DORM_6 - dead tree (will be removed)

		_:
			tile_id = TR_MAPL_VG_1  # Fallback

	return tile_id
