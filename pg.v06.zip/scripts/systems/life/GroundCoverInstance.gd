class_name GroundCoverInstance
extends RefCounted

## Represents ground cover plants (grass, goldenrod, etc.)
##
## Simpler lifecycle than trees - only 4 stages instead of 7.
## Ground cover grows quickly and fills in areas without trees or under small trees.

## Growth stages for ground cover plants
enum GrowthStage {
	SPROUT,     ## Just appeared, tiny
	GROWING,    ## Actively growing
	MATURE,     ## Full size, can spread seeds
	DORMANT     ## Dead, will be removed soon
}

## Grid position of this plant
var position: Vector2i = Vector2i.ZERO

## Tile type ID (40=grass, 45=goldenrod)
var species: int = -1

## Current growth stage
var growth_stage: GrowthStage = GrowthStage.SPROUT

## Age in simulation ticks (4 ticks per game day)
var age_in_ticks: int = 0

## Health from 0.0 (dead) to 1.0 (healthy)
var health: float = 1.0

## Current seed production rate (0.0 to 1.0)
var seed_production: float = 0.0

## Scaled tick thresholds for this plant instance
## Set during initialization based on species config and planet environment
var _thresholds: Array[int] = []

const LOG_TAG := "GROUND_COVER"

## Initializes growth thresholds based on species config and planet modifier
##
## Final threshold = base_threshold / (species_multiplier × planet_modifier)
## Example: Grass on tropical planet (species=3.0, planet=1.5):
##   Base: 40 ticks → Final: 40 / (3.0 × 1.5) = 8.9 ≈ 9 ticks
func initialize_with_config(config: PlantSpeciesConfig, planet_modifier: float) -> void:
	_thresholds.clear()

	var effective_rate = config.growth_rate_multiplier * planet_modifier
	if effective_rate <= 0.0:
		GameLog.warn(LOG_TAG, "Invalid growth rate: species=%f planet=%f" % [config.growth_rate_multiplier, planet_modifier])
		effective_rate = 1.0

	for base_threshold in config.base_tick_thresholds:
		var scaled = max(1, int(base_threshold / effective_rate))
		_thresholds.append(scaled)

	GameLog.debug(LOG_TAG, "Initialized %s: thresholds=%s (rate=%.2f)" % [
		config.species_name,
		str(_thresholds),
		effective_rate
	])

## Advances the plant by one simulation tick
## health_delta is added to current health (can be negative for damage)
func tick(health_delta: float = 0.0) -> void:
	age_in_ticks += 1
	health = clamp(health + health_delta, 0.0, 1.0)
	_update_growth_stage()
	_update_seed_production()

## Updates growth stage based on age and health
func _update_growth_stage() -> void:
	if health <= 0.0:
		growth_stage = GrowthStage.DORMANT
		return

	if _thresholds.is_empty():
		GameLog.warn(LOG_TAG, "No thresholds set for ground cover at %s" % [position])
		return

	# Progress through stages: SPROUT → GROWING → MATURE → DORMANT
	if age_in_ticks < _thresholds[0]:
		growth_stage = GrowthStage.SPROUT
	elif age_in_ticks < _thresholds[1]:
		growth_stage = GrowthStage.GROWING
	elif age_in_ticks < _thresholds[2]:
		growth_stage = GrowthStage.MATURE
	else:
		growth_stage = GrowthStage.DORMANT

## Updates seed production based on growth stage and health
## Only mature plants produce seeds
func _update_seed_production() -> void:
	if growth_stage == GrowthStage.MATURE:
		seed_production = health * 0.8  # Mature plants at 80% capacity when healthy
	else:
		seed_production = 0.0

## Returns true if plant is alive (not dormant and has health)
func is_alive() -> bool:
	return growth_stage != GrowthStage.DORMANT and health > 0.0

## Returns true if plant should be removed from simulation
## Dormant plants are removed after aging past the removal threshold
func should_be_removed() -> bool:
	if growth_stage != GrowthStage.DORMANT:
		return false

	if _thresholds.size() < 4:
		return true  # No removal threshold set, remove immediately

	return age_in_ticks >= _thresholds[3]  # Removal threshold

## Gets the tile type to display for this plant's current state
## Returns -1 if no visual should be shown (dormant)
func get_visual_tile() -> int:
	match growth_stage:
		GrowthStage.SPROUT:
			return 40  # Small grass sprite (R2 C0) for all ground cover sprouts
		GrowthStage.GROWING, GrowthStage.MATURE:
			return species  # Full species tile (grass or goldenrod)
		GrowthStage.DORMANT:
			return -1  # No visual (removed from map)
		_:
			return species

## Serializes ground cover to dictionary for saving
func serialize() -> Dictionary:
	return {
		"position": {"x": position.x, "y": position.y},
		"species": species,
		"growth_stage": growth_stage,
		"age_in_ticks": age_in_ticks,
		"health": health,
		"seed_production": seed_production,
		"thresholds": _thresholds
	}

## Deserializes ground cover from saved dictionary
static func deserialize(data: Dictionary) -> GroundCoverInstance:
	var plant = GroundCoverInstance.new()
	var pos = data.get("position", {"x": 0, "y": 0})
	plant.position = Vector2i(pos.x, pos.y)
	plant.species = data.get("species", -1)
	plant.growth_stage = data.get("growth_stage", GrowthStage.SPROUT) as GrowthStage
	plant.age_in_ticks = data.get("age_in_ticks", 0)
	plant.health = data.get("health", 1.0)
	plant.seed_production = data.get("seed_production", 0.0)
	plant._thresholds = data.get("thresholds", [])
	return plant
