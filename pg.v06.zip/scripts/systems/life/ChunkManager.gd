class_name ChunkManager
extends RefCounted

## ChunkManager - Manages chunk visibility for ecosystem simulation
##
## Responsibilities:
## - Determines which chunks are "active" based on camera position
## - Tracks active chunk list per planet
## - Handles camera synchronization with hysteresis
## - Provides visibility queries
## - Delegates coordinate math to CoordinateSystem
##
## Does NOT handle:
## - Entity storage (trees/ground cover) - that's EcosystemManager's job
## - Entity lifecycle - only visibility

const CHUNK_SIZE := 64
const DEFAULT_ACTIVE_RADIUS := 3
const CAMERA_MOVE_THRESHOLD := 32.0  # Hysteresis for camera tracking

# Visibility state per planet
var _active_chunks: Dictionary = {}           # planet_id -> Array[Vector2i]
var _chunk_center: Dictionary = {}            # planet_id -> Vector2i
var _custom_chunk_radius: Dictionary = {}     # planet_id -> int
var _disable_chunking: Dictionary = {}        # planet_id -> bool

# Coordinate conversion per planet
var _coordinate_systems: Dictionary = {}      # planet_id -> CoordinateSystem
var _planet_map_sizes: Dictionary = {}        # planet_id -> Vector2i

## Lifecycle

func initialize_planet(planet_id: String, map_size: Vector2i, coord_sys: CoordinateSystem) -> void:
	## Initialize chunk tracking for a planet.
	_planet_map_sizes[planet_id] = map_size
	_coordinate_systems[planet_id] = coord_sys
	_active_chunks[planet_id] = []
	_chunk_center[planet_id] = Vector2i(0, 0)
	_custom_chunk_radius[planet_id] = DEFAULT_ACTIVE_RADIUS
	_disable_chunking[planet_id] = false

func unregister_planet(planet_id: String) -> void:
	## Clean up all state for a planet.
	_planet_map_sizes.erase(planet_id)
	_coordinate_systems.erase(planet_id)
	_active_chunks.erase(planet_id)
	_chunk_center.erase(planet_id)
	_custom_chunk_radius.erase(planet_id)
	_disable_chunking.erase(planet_id)

## Active chunks

func update_active_chunks(planet_id: String, center_tile: Vector2i) -> void:
	## Update which chunks are active based on center tile position.
	if _disable_chunking.get(planet_id, false):
		return

	var center_chunk = _tile_to_chunk(center_tile)
	_chunk_center[planet_id] = center_chunk

	var radius = _custom_chunk_radius.get(planet_id, DEFAULT_ACTIVE_RADIUS)
	var active: Array[Vector2i] = []

	for dx in range(-radius, radius + 1):
		for dy in range(-radius, radius + 1):
			active.append(center_chunk + Vector2i(dx, dy))

	_active_chunks[planet_id] = active

func get_active_chunks(planet_id: String) -> Array:
	## Get list of currently active chunk positions.
	return _active_chunks.get(planet_id, [])

func is_chunk_active(planet_id: String, chunk_pos: Vector2i) -> bool:
	## Check if a specific chunk is currently active.
	if _disable_chunking.get(planet_id, false):
		return true

	var active = _active_chunks.get(planet_id, [])
	return chunk_pos in active

## Camera sync

func update_chunk_center_from_camera(planet_id: String, camera_world_pos: Vector2, coord_sys: CoordinateSystem = null) -> bool:
	## Update chunk center from camera position with hysteresis. Returns true if chunks changed.
	if _disable_chunking.get(planet_id, false):
		return false

	# Use provided coordinate system or fall back to stored one
	var cs = coord_sys if coord_sys != null else _coordinate_systems.get(planet_id)
	if cs == null:
		return false

	# Convert camera world position to tile coordinates
	var camera_tile = cs.world_to_tile(camera_world_pos)
	var new_center_chunk = _tile_to_chunk(camera_tile)
	var old_center_chunk = _chunk_center.get(planet_id, Vector2i(0, 0))

	# Calculate distance moved in world coordinates (hysteresis)
	var old_world = cs.tile_to_world(old_center_chunk * CHUNK_SIZE)
	var new_world = cs.tile_to_world(new_center_chunk * CHUNK_SIZE)
	var distance = old_world.distance_to(new_world)

	# Only update if moved far enough
	if distance >= CAMERA_MOVE_THRESHOLD:
		update_active_chunks(planet_id, camera_tile)
		return true

	return false

func sync_chunks_with_camera(planet_id: String, camera_node: Camera2D) -> void:
	## Synchronize active chunks with camera position every frame.
	if camera_node == null or _disable_chunking.get(planet_id, false):
		return

	update_chunk_center_from_camera(planet_id, camera_node.get_screen_center_position())

## Spawn bounds

func get_spawn_bounds(planet_id: String, map_size: Vector2i, edge_margin: int = 0) -> Rect2i:
	## Get the spawn bounds for entity generation (respects chunking if enabled).
	if _disable_chunking.get(planet_id, false):
		# Full map with margin
		return Rect2i(
			edge_margin,
			edge_margin,
			map_size.x - edge_margin * 2,
			map_size.y - edge_margin * 2
		)

	# Calculate bounds from active chunks
	var active = _active_chunks.get(planet_id, [])
	if active.is_empty():
		return Rect2i(0, 0, map_size.x, map_size.y)

	var min_chunk = active[0]
	var max_chunk = active[0]

	for chunk_pos in active:
		min_chunk.x = min(min_chunk.x, chunk_pos.x)
		min_chunk.y = min(min_chunk.y, chunk_pos.y)
		max_chunk.x = max(max_chunk.x, chunk_pos.x)
		max_chunk.y = max(max_chunk.y, chunk_pos.y)

	# Convert chunk bounds to tile bounds
	var tile_min = min_chunk * CHUNK_SIZE
	var tile_max = (max_chunk + Vector2i(1, 1)) * CHUNK_SIZE

	# Apply margin
	tile_min += Vector2i(edge_margin, edge_margin)
	tile_max -= Vector2i(edge_margin, edge_margin)

	# Clamp to map bounds
	tile_min.x = clampi(tile_min.x, 0, map_size.x)
	tile_min.y = clampi(tile_min.y, 0, map_size.y)
	tile_max.x = clampi(tile_max.x, 0, map_size.x)
	tile_max.y = clampi(tile_max.y, 0, map_size.y)

	return Rect2i(tile_min, tile_max - tile_min)

## Configuration

func set_chunk_radius(planet_id: String, radius: int) -> void:
	## Set the active chunk radius (affects how many chunks are loaded).
	_custom_chunk_radius[planet_id] = radius

func get_chunk_radius(planet_id: String) -> int:
	## Get the current chunk radius.
	return _custom_chunk_radius.get(planet_id, DEFAULT_ACTIVE_RADIUS)

func set_chunking_disabled(planet_id: String, disabled: bool) -> void:
	## Enable or disable chunking for a planet.
	_disable_chunking[planet_id] = disabled

func is_chunking_disabled(planet_id: String) -> bool:
	## Check if chunking is disabled for a planet.
	return _disable_chunking.get(planet_id, false)

## Coordinate conversion (delegates to CoordinateSystem)

func world_pos_to_chunk(pos: Vector2i, _planet_id: String = "") -> Vector2i:
	## Convert a world tile position to chunk coordinates.
	return _tile_to_chunk(pos)

func world_to_tile(world_pos: Vector2, planet_id: String = "") -> Vector2i:
	## Convert a world position (pixels) to tile coordinates using stored CoordinateSystem.
	if planet_id.is_empty():
		push_error("ChunkManager.world_to_tile requires planet_id")
		return Vector2i(0, 0)

	var cs = _coordinate_systems.get(planet_id)
	if cs == null:
		push_error("No CoordinateSystem found for planet: " + planet_id)
		return Vector2i(0, 0)

	return cs.world_to_tile(world_pos)

## Internal helpers

func _tile_to_chunk(tile_pos: Vector2i) -> Vector2i:
	## Convert tile coordinates to chunk coordinates (internal helper).
	return Vector2i(
		int(floor(float(tile_pos.x) / CHUNK_SIZE)),
		int(floor(float(tile_pos.y) / CHUNK_SIZE))
	)
