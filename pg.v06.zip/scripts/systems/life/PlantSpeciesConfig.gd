class_name PlantSpeciesConfig
extends RefCounted

## Defines growth and behavior characteristics for a plant species
##
## Each species has a growth rate multiplier that modifies base growth thresholds.
## Combined with planet environmental modifiers, this creates diverse ecosystem dynamics.

## Tile type ID (e.g., 93 for TR_MAPL_VG_1)
var species_id: int = -1

## Human-readable name for the species
var species_name: String = ""

## Relative growth speed (1.0 = baseline, 2.0 = twice as fast, 0.5 = half speed)
var growth_rate_multiplier: float = 1.0

## Relative seed production rate (1.0 = baseline)
var seed_production_multiplier: float = 1.0

## Species type determines lifecycle pattern
enum SpeciesType {
	TREE,           ## Full tree lifecycle (7 stages: seedling -> dormant -> removal)
	GROUND_COVER    ## Simpler lifecycle (4 stages: sprout -> mature -> dormant -> removal)
}
var species_type: SpeciesType = SpeciesType.TREE

## Base tick thresholds before planet/species modifiers are applied
## For TREE: [young_sapling, sapling, young_mature, mature, very_mature, dormant, removal]
## For GROUND_COVER: [growing, mature, dormant, removal]
var base_tick_thresholds: Array[int] = []

## Creates a maple tree species configuration with baseline growth rates
static func create_maple_tree() -> PlantSpeciesConfig:
	var config = PlantSpeciesConfig.new()
	config.species_name = "Maple Tree"
	config.species_type = SpeciesType.TREE
	config.growth_rate_multiplier = 1.0  # Baseline tree speed
	# Thresholds: [young_sapling, sapling, young_mature, mature, very_mature, dormant, removal]
	# Fast but balanced: quick early growth, longer seed-producing stages
	# - Stages 0-2 (seedling to sapling): 1 tick each (fast visual progression)
	# - Stages 3-5 (mature stages): 2 ticks each (time to spread seeds)
	# - Stage 6 (dormant to removal): 2 ticks (visible decline)
	# Total lifecycle: 11 ticks = ~41 seconds at 4x speed
	config.base_tick_thresholds.append_array([1, 2, 3, 5, 7, 9, 11])
	config.seed_production_multiplier = 1.0
	return config

## Creates a grass ground cover species - grows quickly, short lifecycle
static func create_grass() -> PlantSpeciesConfig:
	var config = PlantSpeciesConfig.new()
	config.species_name = "Grass"
	config.species_type = SpeciesType.GROUND_COVER
	config.growth_rate_multiplier = 3.0  # Grows 3x faster than baseline trees
	# Thresholds: [growing, mature, dormant, removal] - fast for testing
	# Note: Must be spaced enough that 3x divisor still gives distinct values
	config.base_tick_thresholds.append_array([6, 12, 24, 30])
	config.seed_production_multiplier = 0.5  # Moderate spreading
	return config

## Creates a goldenrod ground cover species - slower than grass, moderate lifecycle
static func create_goldenrod() -> PlantSpeciesConfig:
	var config = PlantSpeciesConfig.new()
	config.species_name = "Goldenrod"
	config.species_type = SpeciesType.GROUND_COVER
	config.growth_rate_multiplier = 2.0  # Slower than grass, faster than trees
	# Thresholds: [growing, mature, dormant, removal] - fast for testing
	config.base_tick_thresholds.append_array([6, 12, 24, 30])
	config.seed_production_multiplier = 0.3  # Less aggressive spreading
	return config
