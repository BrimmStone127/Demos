class_name ForestSpecies
extends RefCounted

## Registry of all tree species used in the static chunk forest.
##
## Each species has a vegetative tile, a dormant (dead) tile, and a wood yield
## in armloads — the number of firewood trips before the dead tree is depleted.
##
## Maple dormant trees scale by size (DORM_1 through DORM_6).
## All other species are single-tile and use a fixed yield.
##
## Species weights control relative abundance in the forest.
## They do not need to sum to any particular value.

const GenTiles = GeneratedTileTypes.TileType

# ---- Tile IDs ---------------------------------------------------------------

# Maple (6 size variants each)
const MAPLE_VG  = [
	GenTiles.TILE_R4_C14,  # size 1 - smallest
	GenTiles.TILE_R4_C15,
	GenTiles.TILE_R4_C16,
	GenTiles.TILE_R4_C17,
	GenTiles.TILE_R4_C18,
	GenTiles.TILE_R4_C19,  # size 6 - largest
]
const MAPLE_DORM = [
	GenTiles.TILE_R3_C14,
	GenTiles.TILE_R3_C15,
	GenTiles.TILE_R3_C16,
	GenTiles.TILE_R3_C17,
	GenTiles.TILE_R3_C18,
	GenTiles.TILE_R3_C19,
]
# Wood yield per dormant size (armloads)
const MAPLE_DORM_WOOD = [15, 30, 50, 75, 100, 125]

# Beech (single tile per state)
const BEECH_VG   = GenTiles.TILE_R7_C0
const BEECH_DORM = GenTiles.TILE_R7_C1
const BEECH_WOOD = 100  # Dense hardwood, good yield

# Oak (single tile per state)
const OAK_VG   = GenTiles.TILE_R7_C3
const OAK_DORM = GenTiles.TILE_R7_C4
const OAK_WOOD = 125  # Best firewood, dense

# Birch (single tile per state)
const BIRCH_VG   = GenTiles.TILE_R7_C5
const BIRCH_DORM = GenTiles.TILE_R7_C6
const BIRCH_WOOD = 60  # Lighter wood, burns fast

# Raspberry bush (understory food resource — coexists with trees)
const RASPBERRY_BUSH = GenTiles.TILE_R7_C7
# ~8% of non-water, non-camp tiles get a raspberry bush in the understory
const RASPBERRY_CHANCE_DEAD := 0.45  # dead/bare tiles — light gap, undergrowth thrives
const RASPBERRY_CHANCE_LIVE := 0.05  # dense live-tree canopy — low understory light

# ---- Species weights (relative abundance) -----------------------------------
# Cahokia floodplain: maple dominant, oak common, beech moderate, birch sparse
const WEIGHT_MAPLE = 50
const WEIGHT_OAK   = 20
const WEIGHT_BEECH = 15
const WEIGHT_BIRCH = 15
const WEIGHT_TOTAL = WEIGHT_MAPLE + WEIGHT_OAK + WEIGHT_BEECH + WEIGHT_BIRCH

# ~10% of tiles get a dead tree
const DEAD_TREE_CHANCE = 0.10

# ---- Helpers -----------------------------------------------------------------

# Shared RNG — reseeded per call to avoid 12K+ allocations per chunk population pass.
static var _rng: RandomNumberGenerator = RandomNumberGenerator.new()

## Pick a vegetative tile for this world position using a seeded RNG.
## Returns [tile_id, is_dead, wood_yield] where is_dead=false for live trees.
static func pick_live_tile(world_pos: Vector2i) -> int:
	_rng.seed = hash(Vector2(world_pos)) ^ 0xABCD1234

	var species := _pick_species(_rng)
	match species:
		"maple":
			# All 6 size variants for natural distribution; scale in renderer adds further variation
			var size := _rng.randi_range(0, 5)
			return MAPLE_VG[size]
		"oak":
			return OAK_VG
		"beech":
			return BEECH_VG
		_:  # birch
			return BIRCH_VG


## Pick a dead tree tile and its wood yield for this world position.
## Returns [tile_id, wood_yield].
static func pick_dead_tile(world_pos: Vector2i) -> Array:
	_rng.seed = hash(Vector2(world_pos)) ^ 0xDEAD5678

	var species := _pick_species(_rng)
	match species:
		"maple":
			var size := _rng.randi_range(3, 5)  # large dead maples
			return [MAPLE_DORM[size], MAPLE_DORM_WOOD[size]]
		"oak":
			return [OAK_DORM, OAK_WOOD]
		"beech":
			return [BEECH_DORM, BEECH_WOOD]
		_:  # birch
			return [BIRCH_DORM, BIRCH_WOOD]


## Returns true if this world position should have a dead tree.
static func is_dead_tree_position(world_pos: Vector2i) -> bool:
	_rng.seed = hash(Vector2(world_pos)) ^ 0xF00DCAFE
	return _rng.randf() < DEAD_TREE_CHANCE


## Returns true if tile_id is any dead/dormant tree variant.
static func is_dead_tree(tile_id: int) -> bool:
	if tile_id == BEECH_DORM or tile_id == OAK_DORM or tile_id == BIRCH_DORM:
		return true
	for t in MAPLE_DORM:
		if tile_id == t:
			return true
	return false


## Returns the wood yield for a known dead tree tile. Returns 0 if not a dead tree.
static func wood_yield_for_tile(tile_id: int) -> int:
	if tile_id == BEECH_DORM: return BEECH_WOOD
	if tile_id == OAK_DORM:   return OAK_WOOD
	if tile_id == BIRCH_DORM: return BIRCH_WOOD
	for i in range(MAPLE_DORM.size()):
		if tile_id == MAPLE_DORM[i]:
			return MAPLE_DORM_WOOD[i]
	return 0


## Returns true if this world position should have a raspberry bush in the understory.
## Pass chance = RASPBERRY_CHANCE_DEAD near dead trees, RASPBERRY_CHANCE_LIVE elsewhere.
static func is_raspberry_position(world_pos: Vector2i, chance: float = RASPBERRY_CHANCE_LIVE) -> bool:
	_rng.seed = hash(Vector2(world_pos)) ^ 0xBEEF1234
	return _rng.randf() < chance


## Returns true if tile_id is a raspberry bush.
static func is_raspberry_bush(tile_id: int) -> bool:
	return tile_id == RASPBERRY_BUSH


static func _pick_species(rng: RandomNumberGenerator) -> String:
	var roll := rng.randi() % WEIGHT_TOTAL
	if roll < WEIGHT_MAPLE:
		return "maple"
	roll -= WEIGHT_MAPLE
	if roll < WEIGHT_OAK:
		return "oak"
	roll -= WEIGHT_OAK
	if roll < WEIGHT_BEECH:
		return "beech"
	return "birch"


