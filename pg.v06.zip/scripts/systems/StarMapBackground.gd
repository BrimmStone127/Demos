# Replace this in your StarMapBackground.gd
# This approach will make the background completely ignore zoom

extends ParallaxBackground

const LOG_TAG := "STAR_MAP_BACKGROUND"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


# Using ParallaxBackground for more reliable parallax scrolling
@export var texture: Texture2D
const PARALLAX_FACTOR = 0.3  # Background moves at 30% of camera movement

func _ready():
	# Disable background zoom - this makes the background ignore camera zoom
	scroll_ignore_camera_zoom = true
	
	if not texture:
		texture = load("res://assets/star_map.png")
		if not texture:
			_log_error('Error: Could not load star map texture!')
			return
	
	# Create parallax layer
	var layer = ParallaxLayer.new()
	layer.motion_scale = Vector2(PARALLAX_FACTOR, PARALLAX_FACTOR)
	add_child(layer)
	
	# Create a 3x3 grid of background sprites to ensure coverage
	var texture_size = texture.get_size()
	for x in range(-1, 2):
		for y in range(-1, 2):
			var sprite = Sprite2D.new()
			sprite.texture = texture
			sprite.position = Vector2(x * texture_size.x, y * texture_size.y)
			layer.add_child(sprite)
	
	# Scale all sprites and set up motion mirroring
	scale_background()
	
	# Connect to window resize signal
	get_tree().get_root().size_changed.connect(func(): scale_background())

func scale_background():
	# Get viewport size from the root viewport
	var viewport_size = get_tree().get_root().get_visible_rect().size
	var texture_size = texture.get_size()
	
	# Calculate scale to cover viewport with extra margin
	var scale_x = viewport_size.x / texture_size.x
	var scale_y = viewport_size.y / texture_size.y
	var scale_value = max(scale_x, scale_y) * 1.5  # 50% extra margin
	
	# Get the parallax layer
	var layer = get_child(0) as ParallaxLayer
	if not layer:
		return
	
	# Scale each sprite
	for sprite in layer.get_children():
		sprite.scale = Vector2(scale_value, scale_value)
	
	# Set motion mirroring to the scaled texture size * 3 (for our 3x3 grid)
	layer.motion_mirroring = texture_size * scale_value * 3
