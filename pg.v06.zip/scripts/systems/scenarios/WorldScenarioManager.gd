class_name WorldScenarioManager
extends RefCounted

## Determines which world scenario (if any) is active for a given sector.
## World scenarios are narrative/encounter overlays that modify what the player finds
## across multiple star systems. They are deterministic: same galaxy_seed + sector_index
## always produces the same result.

const LOG_TAG := "WORLD_SCENARIO"

## Active world scenario IDs
const SCENARIO_NONE := ""
const SCENARIO_OPOSSUM_SECTOR := "opossum_sector"

## ~1 in 8 sectors is an opossum sector. Adjust divisor to tune frequency.
const OPOSSUM_SECTOR_FREQUENCY := 8

var _galaxy_seed: int = 0

func initialize(galaxy_seed: int) -> void:
	_galaxy_seed = galaxy_seed

## Returns the world scenario ID for the given sector, or "" for normal generation.
func get_sector_scenario(sector_index: int) -> String:
	if _is_opossum_sector(sector_index):
		return SCENARIO_OPOSSUM_SECTOR
	return SCENARIO_NONE

## Maps a world scenario to the village scenario_id used in planet simulation.
static func get_village_scenario_id(world_scenario: String) -> String:
	match world_scenario:
		SCENARIO_OPOSSUM_SECTOR:
			return "opossum"
		_:
			return "mississippi_early"

func _is_opossum_sector(sector_index: int) -> bool:
	var h: int = abs(hash(_galaxy_seed ^ (sector_index * 7919)))
	return (h % OPOSSUM_SECTOR_FREQUENCY) == 0
