class_name PlanetMapRendererMinimap
extends IPlanetMapRenderer

## Simple 2D minimap renderer - strategic overview
##
## This is a minimal implementation showing how alternative renderers work.
## Renders tiles as colored pixels/small squares instead of detailed sprites.
##
## Use cases:
## - Strategic overview alongside main 3D view
## - Mobile-friendly low-detail mode
## - Fast prototyping / debugging
## - Performance baseline for benchmarking

const PIXEL_SIZE := 4  # Each tile = 4x4 pixel square
const TILE_COLORS := {
	# Water/Ice
	PlanetMapTileConfig.TileType.FRESH_WATER: Color(0.08, 0.18, 0.45),
	PlanetMapTileConfig.TileType.ICE: Color(0.8, 0.9, 1.0),

	# Terrain
	PlanetMapTileConfig.TileType.GRASS_0: Color(0.3, 0.6, 0.2),
	PlanetMapTileConfig.TileType.GRASS_1: Color(0.35, 0.65, 0.25),
	PlanetMapTileConfig.TileType.GRASS_2: Color(0.4, 0.7, 0.3),
	PlanetMapTileConfig.TileType.ROCK: Color(0.5, 0.5, 0.5),
	PlanetMapTileConfig.TileType.MOUNTAIN: Color(0.6, 0.6, 0.6),
	PlanetMapTileConfig.TileType.DESERT: Color(0.9, 0.8, 0.5),

	# Surface features (brighter versions)
	PlanetMapTileConfig.TileType.SF_TREE_1: Color(0.1, 0.4, 0.1),
	PlanetMapTileConfig.TileType.SF_TREE_2: Color(0.15, 0.45, 0.15),
	PlanetMapTileConfig.TileType.SF_TREE_3: Color(0.2, 0.5, 0.2),
	PlanetMapTileConfig.TileType.SF_GRASS: Color(0.5, 0.8, 0.4),
	PlanetMapTileConfig.TileType.SF_GOLDENROD: Color(0.9, 0.8, 0.2),
}

var _parent: Node
var _viewport: SubViewport
var _camera: Camera2D
var _canvas: Node2D
var _pixels: Dictionary  # Vector2i -> ColorRect (for fast updates)

## Renderer lifecycle ─────────────────────────────────────────────────────────

func initialize(parent: Node, viewport: SubViewport) -> void:
	_parent = parent
	_viewport = viewport

	# Create simple 2D canvas
	_canvas = Node2D.new()
	_canvas.name = "MinimapCanvas"
	_viewport.add_child(_canvas)

	# Create camera
	_camera = Camera2D.new()
	_camera.name = "MinimapCamera"
	_canvas.add_child(_camera)

	# Configure viewport for pixel-perfect minimap
	_viewport.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST

func cleanup() -> void:
	# Remove all pixel ColorRects
	for pixel in _pixels.values():
		if is_instance_valid(pixel):
			pixel.queue_free()
	_pixels.clear()

	# Remove canvas
	if is_instance_valid(_canvas):
		_canvas.queue_free()

	_parent = null
	_viewport = null
	_camera = null
	_canvas = null

## Tile rendering ─────────────────────────────────────────────────────────────

func render_tile(tile_data) -> void:  # MapTile
	var pos_key = tile_data.position

	# Create or update pixel
	var pixel: ColorRect
	if _pixels.has(pos_key):
		pixel = _pixels[pos_key]
	else:
		pixel = ColorRect.new()
		pixel.custom_minimum_size = Vector2(PIXEL_SIZE, PIXEL_SIZE)
		pixel.size = Vector2(PIXEL_SIZE, PIXEL_SIZE)
		_canvas.add_child(pixel)
		_pixels[pos_key] = pixel

	# Position in minimap space (simple grid layout)
	pixel.position = Vector2(pos_key.x * PIXEL_SIZE, pos_key.y * PIXEL_SIZE)

	# Color based on tile type
	var base_color = TILE_COLORS.get(tile_data.type, Color.MAGENTA)  # Magenta = unknown type

	# Apply elevation brightness (darker at low elevations)
	var brightness = PlanetMapTileConfig.get_elevation_brightness(tile_data.elevation)
	pixel.color = base_color * brightness

func remove_tile(tile_pos: Vector2i) -> void:
	if _pixels.has(tile_pos):
		var pixel = _pixels[tile_pos]
		if is_instance_valid(pixel):
			pixel.queue_free()
		_pixels.erase(tile_pos)

func update_tiles_batch(tiles_to_add: Array, tiles_to_remove: Array[Vector2i]) -> void:
	# Remove old tiles
	for pos in tiles_to_remove:
		remove_tile(pos)

	# Add new tiles
	for tile in tiles_to_add:
		render_tile(tile)

func clear_all_tiles() -> void:
	for pixel in _pixels.values():
		if is_instance_valid(pixel):
			pixel.queue_free()
	_pixels.clear()

## Surface feature rendering ──────────────────────────────────────────────────

func render_surface_feature(position: Vector2i, feature_type: int, elevation: int, metadata: Dictionary = {}) -> void:
	# For minimap, surface features just override the tile color
	# Create a temporary MapTile-like object
	var pseudo_tile = {
		"position": position,
		"type": feature_type,
		"elevation": elevation,
	}
	render_tile(pseudo_tile)

func remove_surface_feature(position: Vector2i) -> void:
	# In minimap, removing surface feature means reverting to terrain color
	# This is simplified - in real implementation, we'd need to know what terrain is underneath
	remove_tile(position)

## Camera and viewport ────────────────────────────────────────────────────────

func get_camera() -> Node:
	return _camera

func set_camera_position(world_pos: Vector2) -> void:
	if _camera:
		# In minimap, world position is just pixel grid position
		_camera.global_position = world_pos

func set_camera_zoom(zoom: float) -> void:
	if _camera:
		_camera.zoom = Vector2(zoom, zoom)

func get_world_bounds() -> Rect2:
	# Calculate bounds from rendered pixels
	if _pixels.is_empty():
		return Rect2(0, 0, 640, 640)  # Default 64x64 map in pixels

	var min_x = INF
	var min_y = INF
	var max_x = -INF
	var max_y = -INF

	for pos in _pixels.keys():
		min_x = min(min_x, pos.x)
		min_y = min(min_y, pos.y)
		max_x = max(max_x, pos.x)
		max_y = max(max_y, pos.y)

	return Rect2(
		min_x * PIXEL_SIZE,
		min_y * PIXEL_SIZE,
		(max_x - min_x + 1) * PIXEL_SIZE,
		(max_y - min_y + 1) * PIXEL_SIZE
	)

## Input handling ─────────────────────────────────────────────────────────────

func screen_to_tile(screen_pos: Vector2) -> Variant:  # Vector2i or null
	# Convert screen to world (accounting for camera)
	var world_pos = _camera.get_global_mouse_position() if _camera else screen_pos

	# Convert world to tile (simple grid)
	var tile_x = int(world_pos.x / PIXEL_SIZE)
	var tile_y = int(world_pos.y / PIXEL_SIZE)
	var tile_pos = Vector2i(tile_x, tile_y)

	# Check if this tile exists
	if _pixels.has(tile_pos):
		return tile_pos
	return null

func tile_to_world(tile_pos: Vector2i) -> Vector2:
	# Simple grid: tile center in world space
	return Vector2(
		tile_pos.x * PIXEL_SIZE + (PIXEL_SIZE >> 1),
		tile_pos.y * PIXEL_SIZE + (PIXEL_SIZE >> 1)
	)

## Visual effects ─────────────────────────────────────────────────────────────

func apply_theme(theme_name: String) -> void:
	# Minimap ignores themes - always uses simple colors
	pass

func set_time_of_day(time_normalized: float) -> void:
	# Could darken entire canvas for night
	# For now, no time-of-day effects
	pass

## Renderer capabilities ──────────────────────────────────────────────────────

func get_capabilities() -> Dictionary:
	return {
		"supports_rotation": false,
		"supports_tilt": false,
		"supports_dynamic_lighting": false,
		"supports_3d_structures": false,
		"pixel_perfect": true,
		"max_elevation_layers": 16,
		"performance_tier": "ultra_fast",  # Fastest renderer!
	}

func get_renderer_name() -> String:
	return "Minimap (2D Pixel Grid)"
