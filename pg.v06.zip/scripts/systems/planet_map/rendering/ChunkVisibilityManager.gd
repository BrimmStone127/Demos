class_name ChunkVisibilityManager
extends Node2D

## Manages chunk loading/unloading based on camera position.
##
## TWO-TIER SYSTEM:
##   _data_cache   — ChunkTileData kept for UNLOAD_RADIUS ring (data only, no scene nodes)
##   loaded_chunks — ChunkTileMapGroup visual nodes for LOAD_RADIUS ring (always visible)
##
## Lifecycle (all data loading is async — no synchronous work on boundary crossing):
##   UNLOADED → [enters LOAD_RADIUS] → queued for async data load → VISUAL
##            → [enters VISIBILITY_RADIUS] → priority data queue + higher tiles_per_frame
##            → [leaves VISIBILITY_RADIUS] → lower budget, off-screen GPU-culled
##            → [leaves LOAD_RADIUS] → DATA_ONLY (free visual, keep data)
##            → [leaves UNLOAD_RADIUS] → UNLOADED
##
## CONCURRENCY LIMIT: Only MAX_CONCURRENT_RENDERERS chunks render tiles per frame.
## Each tile costs ~4 set_cell() calls (elevation layers) × 1-2μs each. Without a
## concurrency cap, crossing a chunk boundary starts 4-8 chunks rendering simultaneously
## and blows the frame budget. Closest chunks render first; excess chunks are paused
## (tiles_per_frame=0) until a slot opens.

const LOG_TAG := "CHUNK_VISIBILITY"

func _ready():
	# y_sort DISABLED — z_index handles all depth ordering (SURFACE_FEATURE_Z_INDEX + row_y
	# for trees, ELEVATION_Z_SPACING for terrain layers). y_sort on this container caused
	# one-frame black flashes in SubViewport: each chunk visibility toggle triggered a full
	# re-sort, delaying rendering by one frame and exposing the viewport's clear color.
	# See Godot issues #107201, #75206.
	y_sort_enabled = false
	# LOD container sits IN FRONT of live chunks — acts as a curtain that fades
	# away to reveal fully-rendered chunks underneath. Prevents any flicker from
	# partially-rendered or partially-transparent chunks showing through.
	_lod_container = Node2D.new()
	_lod_container.name = "LODContainer"
	_lod_container.z_index = 10000
	add_child(_lod_container)

func _process(_delta):
	# Pre-load chunk data around camera (even in LOD mode — ready for zoom-in)
	var data_loaded := 0
	while data_loaded < MAX_DATA_LOADS_PER_FRAME and not _pending_data_chunks.is_empty():
		var chunk_pos: Vector2i = _pending_data_chunks.pop_front()
		_pending_data_set.erase(chunk_pos)
		if not _data_cache.has(chunk_pos):
			_load_chunk_data(chunk_pos)
			if not _lod_mode and _data_cache.has(chunk_pos):
				if not loaded_chunks.has(chunk_pos) \
						and not _pending_visual_chunks.has(chunk_pos):
					_pending_visual_chunks.append(chunk_pos)
		data_loaded += 1

	if _lod_mode:
		return

	# Check if LOD backdrop can fade out (enough chunks rendered)
	if _lod_fade_pending:
		_check_lod_fade()

	_distribute_render_budget()

	# Drain visual creation queue — closest-to-camera first
	if _pending_visual_chunks.is_empty():
		return
	var created := 0
	while created < MAX_VISUALS_PER_FRAME and not _pending_visual_chunks.is_empty():
		var best_idx := 0
		var best_dist := _chunk_distance(_pending_visual_chunks[0], current_camera_chunk)
		for i in range(1, _pending_visual_chunks.size()):
			var d := _chunk_distance(_pending_visual_chunks[i], current_camera_chunk)
			if d < best_dist:
				best_dist = d
				best_idx = i
		var chunk_pos: Vector2i = _pending_visual_chunks[best_idx]
		_pending_visual_chunks.remove_at(best_idx)
		if _data_cache.has(chunk_pos) and not loaded_chunks.has(chunk_pos):
			var dist := _chunk_distance(chunk_pos, current_camera_chunk)
			_create_chunk_visual(chunk_pos, _tiles_budget_for_distance(dist))
		created += 1

# Configuration
const CHUNK_SIZE: int = 64
const VISIBILITY_RADIUS: int = 2  # Priority rendering: 5×5 = 25 chunks
const LOAD_RADIUS: int = 3        # Visual nodes exist: 7×7 = 49 chunks (off-screen GPU-culled)
const UNLOAD_RADIUS: int = 5      # Data kept but no visual: 11×11 = 121 chunks

# Signals
signal chunks_loaded(chunk_positions: Array[Vector2i])
signal chunks_unloaded(chunk_positions: Array[Vector2i])
signal chunks_visibility_changed(visible_count: int, hidden_count: int)

# All visual chunks — both in-view and off-screen outer ring
var loaded_chunks: Dictionary = {}  # Vector2i → ChunkTileMapGroup

# Data cache — for chunks between LOAD_RADIUS and UNLOAD_RADIUS (no scene nodes)
var _data_cache: Dictionary = {}  # Vector2i → ChunkTileData

# Pending creation queues
var _pending_visual_chunks: Array[Vector2i] = []
const MAX_VISUALS_PER_FRAME: int = 4

var _pending_data_chunks: Array[Vector2i] = []
var _pending_data_set: Dictionary = {}  # O(1) membership check
const MAX_DATA_LOADS_PER_FRAME: int = 8

# Max chunks allowed to render simultaneously. Prevents cumulative FPS spike when
# many chunks enter view at boundary crossings. Paused chunks resume when slots open.
# At 2 concurrent: worst case 512+256 = 768 tiles/frame × ~3 set_cell = ~3.5ms.
const MAX_CONCURRENT_RENDERERS: int = 2

# Per-chunk tile budgets by distance from camera.
# set_cell() costs ~1-2μs each. These values keep each chunk's cost reasonable.
const TILES_PER_FRAME_PRIORITY: int = 4096  # Ctrl+F target — full chunk instantly
const TILES_PER_FRAME_CAMERA: int = 512     # camera chunk
const TILES_PER_FRAME_INNER: int = 256      # visibility ring
const TILES_PER_FRAME_OUTER: int = 64       # outer ring background

var current_camera_chunk: Vector2i = Vector2i(-999, -999)

var terrain_source: TerrainDataSource = null
var feature_populator: Callable = Callable()

var total_chunks_loaded: int = 0
var total_chunks_unloaded: int = 0

# LOD state — when zoomed out, show pre-baked overview image (no chunk loading)
var _lod_mode: bool = false
var _lod_sprite: Sprite2D = null  # Single pre-baked overview sprite
var _lod_container: Node2D = null
var _lod_fade_pending: bool = false  # LOD sprite fading out while chunks render
var _lod_fade_tween: Tween = null    # Active fade tween (killed on re-enter to prevent conflicts)
var _current_zoom: float = 1.0

# View mode state — applied to newly created chunks
var _trees_visible: bool = true
var _heatmap_active: bool = false

func set_trees_visible(show: bool) -> void:
	_trees_visible = show
	for chunk: ChunkTileMapGroup in loaded_chunks.values():
		chunk.set_trees_visible(show)
	_update_lod_texture()

func set_heatmap_mode(enabled: bool) -> void:
	_heatmap_active = enabled
	for chunk: ChunkTileMapGroup in loaded_chunks.values():
		chunk.set_heatmap_mode(enabled)
	_update_lod_texture()

func _get_current_overview_path() -> String:
	if _heatmap_active:
		return PlanetMapTileConfig.OVERVIEW_HEATMAP_PATH
	elif not _trees_visible:
		return PlanetMapTileConfig.OVERVIEW_NO_TREES_PATH
	return PlanetMapTileConfig.OVERVIEW_TEXTURE_PATH

func _update_lod_texture() -> void:
	if not _lod_sprite or not is_instance_valid(_lod_sprite):
		return
	var tex := load(_get_current_overview_path()) as Texture2D
	if tex:
		_lod_sprite.texture = tex

func _tiles_budget_for_distance(dist: int) -> int:
	if dist == 0:
		return TILES_PER_FRAME_CAMERA
	if dist <= VISIBILITY_RADIUS:
		return TILES_PER_FRAME_INNER
	return TILES_PER_FRAME_OUTER

## Limit concurrent rendering chunks to MAX_CONCURRENT_RENDERERS.
## Closest chunks render at full budget; excess chunks paused (budget=0) until slots open.
## Skips chunks with PRIORITY budget (Ctrl+F / initial load) — those always render.
func _distribute_render_budget():
	var rendering: Array = []
	for cp in loaded_chunks:
		var vis: ChunkTileMapGroup = loaded_chunks[cp]
		if not vis._is_rendering:
			continue
		# Never throttle priority chunks (Ctrl+F jump, initial load)
		if vis.tiles_per_frame >= TILES_PER_FRAME_PRIORITY:
			continue
		rendering.append({"vis": vis, "dist": _chunk_distance(cp, current_camera_chunk)})

	if rendering.size() <= MAX_CONCURRENT_RENDERERS:
		return  # under limit — budgets already correct

	# Sort closest-first, pause excess
	rendering.sort_custom(func(a, b): return a["dist"] < b["dist"])
	for i in rendering.size():
		if i < MAX_CONCURRENT_RENDERERS:
			rendering[i]["vis"].tiles_per_frame = _tiles_budget_for_distance(rendering[i]["dist"])
		else:
			rendering[i]["vis"].tiles_per_frame = 0

func set_terrain_source(source: TerrainDataSource):
	terrain_source = source
	if terrain_source:
		GameLog.info(LOG_TAG, "Terrain source set: %s" % terrain_source)

func update_camera_position(camera_world_pos: Vector2):
	if not terrain_source:
		GameLog.warn(LOG_TAG, "No terrain source set, cannot update chunks")
		return
	var camera_chunk = _world_to_chunk(camera_world_pos)
	if camera_chunk == current_camera_chunk:
		return
	current_camera_chunk = camera_chunk
	_update_chunk_visibility()
	if not _pending_data_chunks.is_empty():
		_sort_pending_data_by_distance()

## Update chunk states when camera crosses a chunk boundary.
func _update_chunk_visibility():
	if _lod_mode:
		_queue_data_around_camera()
		return

	var load_chunks := _get_chunks_in_radius(current_camera_chunk, LOAD_RADIUS)
	var load_set: Dictionary = {}
	for cp in load_chunks:
		load_set[cp] = true

	# --- Ensure all chunks in radius have data queued ---
	for chunk_pos in load_chunks:
		if not terrain_source.is_valid_chunk(chunk_pos):
			continue
		var dist := _chunk_distance(chunk_pos, current_camera_chunk)

		if not _data_cache.has(chunk_pos) and not loaded_chunks.has(chunk_pos):
			if not _pending_data_set.has(chunk_pos):
				_pending_data_set[chunk_pos] = true
				if dist <= VISIBILITY_RADIUS:
					_pending_data_chunks.push_front(chunk_pos)
				else:
					_pending_data_chunks.append(chunk_pos)
		else:
			# Queue visual creation for data-cached chunks
			if _data_cache.has(chunk_pos) and not loaded_chunks.has(chunk_pos) \
					and not _pending_visual_chunks.has(chunk_pos):
				_pending_visual_chunks.append(chunk_pos)

		# Adjust tiles_per_frame for existing visual chunks as camera moves
		if loaded_chunks.has(chunk_pos):
			var vis: ChunkTileMapGroup = loaded_chunks[chunk_pos]
			if vis._is_rendering:
				vis.tiles_per_frame = _tiles_budget_for_distance(dist)

	# --- Cancel queued chunks that left radius ---
	_pending_data_chunks = _pending_data_chunks.filter(func(cp): return load_set.has(cp))
	_pending_data_set.clear()
	for cp in _pending_data_chunks:
		_pending_data_set[cp] = true
	_pending_visual_chunks = _pending_visual_chunks.filter(func(cp): return load_set.has(cp))

	# Free visuals for chunks that left LOAD_RADIUS
	var to_free_visual: Array[Vector2i] = []
	for chunk_pos in loaded_chunks.keys():
		if not load_set.has(chunk_pos):
			to_free_visual.append(chunk_pos)
	for chunk_pos in to_free_visual:
		_free_chunk_visual(chunk_pos)

	# --- Free data for chunks beyond unload radius ---
	var to_unload: Array[Vector2i] = []
	for chunk_pos in _data_cache.keys():
		if _chunk_distance(chunk_pos, current_camera_chunk) > UNLOAD_RADIUS:
			to_unload.append(chunk_pos)
	if to_unload.size() > 0:
		for chunk_pos in to_unload:
			_free_chunk_visual(chunk_pos)
			_free_chunk_data(chunk_pos)
		chunks_unloaded.emit(to_unload)
		total_chunks_unloaded += to_unload.size()
		GameLog.info(LOG_TAG, "Unloaded %d chunks beyond radius %d" % [to_unload.size(), UNLOAD_RADIUS])

	chunks_visibility_changed.emit(loaded_chunks.size(), 0)

# ── Internal: data and visual ─────────────────────────────────────────────────

func _load_chunk_data(chunk_pos: Vector2i) -> void:
	if _data_cache.has(chunk_pos):
		return
	var chunk_data := terrain_source.load_chunk(chunk_pos)
	if not chunk_data:
		GameLog.error(LOG_TAG, "Failed to load chunk data for %s" % chunk_pos)
		return
	if feature_populator.is_valid():
		feature_populator.call(chunk_pos, chunk_data)
	_data_cache[chunk_pos] = chunk_data

func _create_chunk_visual(chunk_pos: Vector2i, tiles_budget: int = TILES_PER_FRAME_INNER) -> void:
	if loaded_chunks.has(chunk_pos):
		return
	var chunk_data: ChunkTileData = _data_cache.get(chunk_pos, null)
	if not chunk_data:
		GameLog.error(LOG_TAG, "Cannot create visual for %s — no data cached" % chunk_pos)
		return
	var neighbor_edges := _gather_neighbor_edges(chunk_pos)
	var chunk_visual := ChunkTileMapGroup.new()
	chunk_visual.tiles_per_frame = tiles_budget
	chunk_visual._trees_visible = _trees_visible
	chunk_visual._heatmap_active = _heatmap_active
	chunk_visual.initialize(chunk_pos, chunk_data, neighbor_edges)
	chunk_visual.visible = false  # hidden until rendering complete — no tile-crawl
	add_child(chunk_visual)
	loaded_chunks[chunk_pos] = chunk_visual
	total_chunks_loaded += 1

## Extract edge render_layers from adjacent cached chunks.
## Returns Dict with "north"/"south"/"east"/"west" -> PackedByteArray[CHUNK_SIZE].
## Missing neighbors omitted — ChunkTileMapGroup falls back to layer 0 for those edges.
func _gather_neighbor_edges(chunk_pos: Vector2i) -> Dictionary:
	var edges := {}
	var CS := ChunkTileData.CHUNK_SIZE

	# North neighbor: its south edge (y=CS-1 row)
	var north_data: ChunkTileData = _data_cache.get(chunk_pos + Vector2i(0, -1), null)
	if north_data:
		var edge := PackedByteArray()
		edge.resize(CS)
		var row_start := (CS - 1) * CS
		for i in CS:
			edge[i] = north_data.render_layers[row_start + i]
		edges["north"] = edge

	# South neighbor: its north edge (y=0 row)
	var south_data: ChunkTileData = _data_cache.get(chunk_pos + Vector2i(0, 1), null)
	if south_data:
		edges["south"] = south_data.render_layers.slice(0, CS)

	# West neighbor: its east edge (x=CS-1 column)
	var west_data: ChunkTileData = _data_cache.get(chunk_pos + Vector2i(-1, 0), null)
	if west_data:
		var edge := PackedByteArray()
		edge.resize(CS)
		for i in CS:
			edge[i] = west_data.render_layers[i * CS + CS - 1]
		edges["west"] = edge

	# East neighbor: its west edge (x=0 column)
	var east_data: ChunkTileData = _data_cache.get(chunk_pos + Vector2i(1, 0), null)
	if east_data:
		var edge := PackedByteArray()
		edge.resize(CS)
		for i in CS:
			edge[i] = east_data.render_layers[i * CS]
		edges["east"] = edge

	return edges

# ── LOD mode ──────────────────────────────────────────────────────────────────

## Called every frame from PlanetMapSystem with current camera zoom level.
## Triggers LOD mode transitions with hysteresis to prevent rapid cycling.
func update_zoom(zoom_level: float) -> void:
	_current_zoom = zoom_level
	if not _lod_mode and zoom_level < PlanetMapTileConfig.LOD_ZOOM_ENTER:
		_enter_lod_mode()
	elif _lod_mode and zoom_level > PlanetMapTileConfig.LOD_ZOOM_EXIT:
		_exit_lod_mode()

func _enter_lod_mode() -> void:
	_lod_mode = true
	_lod_fade_pending = false  # Cancel any pending fade from previous exit
	# Kill any active fade-out tween — prevents it from overriding modulate.a = 1.0 below
	if _lod_fade_tween and _lod_fade_tween.is_valid():
		_lod_fade_tween.kill()
		_lod_fade_tween = null
	GameLog.info(LOG_TAG, "Entering LOD mode (zoom=%.4f)" % _current_zoom)

	# Show pre-baked overview BEFORE freeing chunks — prevents gap where
	# neither chunks nor LOD sprite are visible (black flash).
	_ensure_lod_sprite()
	if _lod_sprite and is_instance_valid(_lod_sprite):
		_lod_sprite.modulate.a = 1.0

	# Stop pending visual work (but keep data loading)
	_pending_visual_chunks.clear()

	# Free all live chunks — data cache stays
	for chunk_pos in loaded_chunks.keys().duplicate():
		_free_chunk_visual(chunk_pos)

	# Queue data loading around camera for zoom-in readiness
	_queue_data_around_camera()

func _exit_lod_mode() -> void:
	_lod_mode = false
	_lod_fade_pending = true
	GameLog.info(LOG_TAG, "Exiting LOD mode (zoom=%.4f) — LOD sprite stays as backdrop" % _current_zoom)

	# Keep LOD sprite visible as backdrop while chunks render.
	# _check_lod_fade() in _process() will fade it out once enough chunks are ready.

	# Queue live chunk creation around camera
	_update_chunk_visibility()

## Check if enough chunks have finished rendering AND faded in before fading LOD curtain.
## LOD sprite sits IN FRONT of chunks (z_index 10000), covering all rendering artifacts.
## Only fades out once chunks are nearly fully opaque underneath.
func _check_lod_fade() -> void:
	if not _lod_fade_pending:
		return
	# Count how many chunks in the visibility ring are fully rendered AND opaque
	var needed := 0
	var ready := 0
	var vis_chunks := _get_chunks_in_radius(current_camera_chunk, VISIBILITY_RADIUS)
	for chunk_pos in vis_chunks:
		if not terrain_source or not terrain_source.is_valid_chunk(chunk_pos):
			continue
		needed += 1
		if loaded_chunks.has(chunk_pos):
			var vis: ChunkTileMapGroup = loaded_chunks[chunk_pos]
			if vis.visible and not vis._is_rendering:
				ready += 1
	# Require ALL visible-ring chunks to be rendered before fading LOD curtain.
	# 80% threshold left gaps — unfinished chunks exposed dark background during fade.
	if needed > 0 and ready >= needed:
		_lod_fade_pending = false
		_fade_out_lod_sprite()

## Fade the LOD sprite out over 0.3s, then hide it.
func _fade_out_lod_sprite() -> void:
	if not _lod_sprite or not is_instance_valid(_lod_sprite):
		return
	# Kill previous fade tween if still running (prevents double-fade)
	if _lod_fade_tween and _lod_fade_tween.is_valid():
		_lod_fade_tween.kill()
	_lod_fade_tween = create_tween()
	_lod_fade_tween.tween_property(_lod_sprite, "modulate:a", 0.0, 0.3)
	_lod_fade_tween.tween_callback(func():
		_lod_fade_tween = null
		# Don't toggle visible — modulate.a = 0.0 is enough. Toggling visible
		# inside SubViewport triggers re-draw that can cause one-frame black flash.
	)

## Create or show the pre-baked overview sprite.
## Uses modulate.a instead of visible toggling to avoid SubViewport re-draw flash.
func _ensure_lod_sprite() -> void:
	if _lod_sprite and is_instance_valid(_lod_sprite):
		_lod_sprite.modulate.a = 1.0
		var current_tex := load(_get_current_overview_path()) as Texture2D
		if current_tex:
			_lod_sprite.texture = current_tex
		return

	var overview_path := _get_current_overview_path()
	var tex := load(overview_path) as Texture2D
	if tex == null:
		tex = load(PlanetMapTileConfig.OVERVIEW_TEXTURE_PATH) as Texture2D
	if tex == null:
		GameLog.warn(LOG_TAG, "Overview texture not found: %s" % overview_path)
		return

	_lod_sprite = Sprite2D.new()
	_lod_sprite.texture = tex
	_lod_sprite.centered = false
	_lod_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

	# Isometric transform: each pixel = one tile in world space
	var tile_offset := PlanetMapTileConfig.TILE_OFFSET
	_lod_sprite.transform = Transform2D(
		tile_offset,                                   # x-axis: grid x direction
		Vector2(-tile_offset.x, tile_offset.y),        # y-axis: grid y direction
		PlanetMapCoordinates.grid_to_world(Vector2i.ZERO))

	_lod_sprite.visible = true
	_lod_container.add_child(_lod_sprite)

# ── Internal: data and visual ─────────────────────────────────────────────────

func _free_chunk_visual(chunk_pos: Vector2i) -> void:
	if not loaded_chunks.has(chunk_pos):
		return
	loaded_chunks[chunk_pos].queue_free()
	loaded_chunks.erase(chunk_pos)

func _free_chunk_data(chunk_pos: Vector2i) -> void:
	_data_cache.erase(chunk_pos)

# ── Public API ─────────────────────────────────────────────────────────────────

func load_one_chunk(chunk_pos: Vector2i) -> bool:
	if loaded_chunks.has(chunk_pos):
		return false
	if not terrain_source or not terrain_source.is_valid_chunk(chunk_pos):
		return false
	if not _data_cache.has(chunk_pos):
		_load_chunk_data(chunk_pos)
	if not _data_cache.has(chunk_pos):
		return false
	_create_chunk_visual(chunk_pos)
	return loaded_chunks.has(chunk_pos)

func load_chunk_data_only(chunk_pos: Vector2i) -> bool:
	if _data_cache.has(chunk_pos):
		return false
	if not terrain_source or not terrain_source.is_valid_chunk(chunk_pos):
		return false
	_load_chunk_data(chunk_pos)
	return _data_cache.has(chunk_pos)

func load_chunk_immediate(chunk_pos: Vector2i):
	if not _data_cache.has(chunk_pos):
		_load_chunk_data(chunk_pos)
	if not loaded_chunks.has(chunk_pos):
		_create_chunk_visual(chunk_pos, TILES_PER_FRAME_PRIORITY)
	else:
		var vis: ChunkTileMapGroup = loaded_chunks[chunk_pos]
		if vis._is_rendering:
			vis.tiles_per_frame = TILES_PER_FRAME_PRIORITY
		vis.visible = true
	var neighbors := _get_chunks_in_radius(chunk_pos, 1)
	for neighbor_pos in neighbors:
		if terrain_source.is_valid_chunk(neighbor_pos) and not _data_cache.has(neighbor_pos):
			_load_chunk_data(neighbor_pos)

func is_chunk_loaded(chunk_pos: Vector2i) -> bool:
	return loaded_chunks.has(chunk_pos)

func is_chunk_data_cached(chunk_pos: Vector2i) -> bool:
	return _data_cache.has(chunk_pos)

func get_loaded_chunk_positions() -> Array[Vector2i]:
	var positions: Array[Vector2i] = []
	positions.assign(loaded_chunks.keys())
	return positions

func get_loaded_chunk_count() -> int:
	return loaded_chunks.size()

func get_chunk_visual(chunk_pos: Vector2i) -> ChunkTileMapGroup:
	return loaded_chunks.get(chunk_pos, null)

func get_chunk_data(chunk_pos: Vector2i) -> ChunkTileData:
	return _data_cache.get(chunk_pos, null)

func clear_all_chunks():
	_pending_visual_chunks.clear()
	_pending_data_chunks.clear()
	for chunk_visual in loaded_chunks.values():
		chunk_visual.queue_free()
	loaded_chunks.clear()
	if _lod_sprite and is_instance_valid(_lod_sprite):
		_lod_sprite.queue_free()
		_lod_sprite = null
	_data_cache.clear()
	_lod_mode = false
	_lod_fade_pending = false
	if _lod_fade_tween and _lod_fade_tween.is_valid():
		_lod_fade_tween.kill()
		_lod_fade_tween = null
	GameLog.info(LOG_TAG, "Cleared all chunks")

# ── Helpers ───────────────────────────────────────────────────────────────────

func _world_to_chunk(world_pos: Vector2) -> Vector2i:
	var tile_pos := PlanetMapCoordinates.world_to_grid(world_pos - PlanetMapTileConfig.TILE_OFFSET)
	return Vector2i(
		floori(float(tile_pos.x) / CHUNK_SIZE),
		floori(float(tile_pos.y) / CHUNK_SIZE)
	)

func _get_chunks_in_radius(center: Vector2i, radius: int) -> Array[Vector2i]:
	var chunks: Array[Vector2i] = []
	for dy in range(-radius, radius + 1):
		for dx in range(-radius, radius + 1):
			chunks.append(center + Vector2i(dx, dy))
	return chunks

func _chunk_distance(a: Vector2i, b: Vector2i) -> int:
	return maxi(absi(a.x - b.x), absi(a.y - b.y))

## Queue data loading for chunks around camera (used in LOD mode for zoom-in readiness).
func _queue_data_around_camera() -> void:
	if not terrain_source:
		return
	var chunks := _get_chunks_in_radius(current_camera_chunk, LOAD_RADIUS)
	for chunk_pos in chunks:
		if not terrain_source.is_valid_chunk(chunk_pos):
			continue
		if not _data_cache.has(chunk_pos) and not _pending_data_set.has(chunk_pos):
			_pending_data_set[chunk_pos] = true
			_pending_data_chunks.append(chunk_pos)
	if not _pending_data_chunks.is_empty():
		_sort_pending_data_by_distance()

## Sort pending data queue by distance from camera (nearest first).
## Called on LOD entry and camera chunk change to avoid O(n) scan per pop.
func _sort_pending_data_by_distance() -> void:
	var cam := current_camera_chunk
	_pending_data_chunks.sort_custom(func(a, b):
		return _chunk_distance(a, cam) < _chunk_distance(b, cam)
	)

func get_stats() -> Dictionary:
	return {
		"visual_chunks": loaded_chunks.size(),
		"data_cached_chunks": _data_cache.size(),
		"total_loaded": total_chunks_loaded,
		"total_unloaded": total_chunks_unloaded,
		"camera_chunk": current_camera_chunk,
		"lod_mode": _lod_mode,
		"zoom": _current_zoom,
	}

func _to_string() -> String:
	return "ChunkVisibilityManager(visual=%d, data=%d, camera=%s, lod_mode=%s)" % [
		loaded_chunks.size(), _data_cache.size(),
		current_camera_chunk, _lod_mode
	]
