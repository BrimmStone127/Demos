class_name ChunkTileMapGroup
extends Node2D

## Visual representation of one 64x64 tile chunk.
## Contains 16 elevation TileMaps, 3 MultiMeshInstance2D nodes (trees/shadows/understory),
## and Sprite2D for structure tiles (longhouse) and post-render feature updates.
##
## Rendering pipeline:
##   1. Incremental collection phase (_process): reads tile data, collects instance arrays.
##   2. Build phase (one frame when done): creates MultiMesh from collected arrays.
##   3. Post-render updates (update_tree_at etc.): hide MultiMesh instance, add fallback Sprite2D.

const LOG_TAG := "CHUNK_VISUAL"

# Tiles to render per _process() frame. ChunkVisibilityManager overrides this per-instance
# based on distance from camera (512 camera, 256 inner, 64 outer) and enforces a global
# concurrency limit so only MAX_CONCURRENT_RENDERERS chunks render simultaneously.
var tiles_per_frame: int = 256

# Chunk position in chunk-space
var chunk_pos: Vector2i = Vector2i.ZERO

# Elevation layers (up to 16 TileMaps, created lazily)
var elevation_tilemaps: Array[TileMap] = []
# Water layers — same slots as elevation but no darkening modulate
var water_tilemaps: Array[TileMap] = []

# Flow direction overlay container (above terrain, below shadows/trees)
var flow_container: Node2D = null

# Smoke emitter cache — local_pos -> {emitters: Array[GPUParticles2D], max_spreads: Array}
var smoke_cache: Dictionary = {}

# Trees — one MultiMeshInstance2D per species (grouped by tile_id)
var _tree_mms: Dictionary = {}       # tile_id → MultiMeshInstance2D
# Shadows — one MultiMeshInstance2D for all shadow blobs
var _shadow_mm: MultiMeshInstance2D = null
# Understory — one MultiMeshInstance2D per species (grouped by tile_id)
var _understory_mms: Dictionary = {} # tile_id → MultiMeshInstance2D

# Index maps for post-render updates
var _tree_idx: Dictionary = {}      # local_pos → {tile_id: int, idx: int}
var _shadow_idx: Dictionary = {}    # local_pos → int (shadow MultiMesh instance index)
var _understory_idx: Dictionary = {} # local_pos → {tile_id: int, idx: int}

# Fallback container for post-render Sprite2D additions (structure tiles, updated trees)
var _update_container: Node2D = null

# sprite_cache kept for external has_tree_at() checks (local_pos -> true)
var sprite_cache: Dictionary = {}

# Pending instance data collected during incremental pass — cleared after _build_multimeshes()
var _pending_trees: Array = []      # {pos, tile_id, transform, color}
var _pending_shadows: Array = []    # {pos, transform}
var _pending_understory: Array = [] # {pos, tile_id, transform, color}
var _pending_flow: Array = []       # {pos, atlas, flip_h, layer} — built as Sprite2Ds after tiles done

# Shared resources (static = one per class, not per chunk)
static var _shadow_texture: ImageTexture = null
static var _smoke_texture: ImageTexture = null
static var _smoke_shader_mat: ShaderMaterial = null
# Per-tile-type ArrayMesh with UVs baked to atlas region (bottom-center pivot).
# AtlasTexture does NOT remap UVs in MultiMeshInstance2D — baking UVs into mesh is required.
static var _tile_meshes: Dictionary = {}    # tile_id → ArrayMesh
static var _center_quad: QuadMesh = null    # size=1x1, centered pivot (shadows only)
static var _understory_mat: ShaderMaterial = null  # palette_swap with swap+wind disabled

# Elevation per local position — populated during tile rendering
var _local_elevation: Dictionary = {}

# Original tile types per local position — for restoring after heatmap mode
var _local_tile_types: Dictionary = {}

# Current display mode
var _trees_visible: bool = true
var _heatmap_active: bool = false

# Neighbor edge render layers for cross-chunk stacking.
# Keys: "north"/"south"/"east"/"west" -> PackedByteArray[CHUNK_SIZE]
# Without this, edge tiles conservatively fill all layers to 0 (252 tiles × ~8 extra set_cell each).
var _neighbor_edges: Dictionary = {}

# Visibility / rendering state
var is_loaded: bool = false
var _tile_data: ChunkTileData = null
var _render_index: int = 0  # cursor into tile grid (0..CHUNK_SIZE²), no array needed
var _is_rendering: bool = false

# ── Initialization ─────────────────────────────────────────────────────────────

## Initialize chunk visual with data. Starts incremental collection phase.
## neighbor_edges: optional Dict of edge render_layers from adjacent cached chunks.
## Without it, edge tiles fill to layer 0 (conservative); with it, edges use actual neighbor data.
func initialize(chunk_coords: Vector2i, tile_data: ChunkTileData, neighbor_edges: Dictionary = {}):
	chunk_pos = chunk_coords
	_tile_data = tile_data
	_neighbor_edges = neighbor_edges
	position = _calculate_chunk_world_offset(chunk_coords)

	_create_tilemaps()
	_create_flow_container()
	_create_update_container()
	_start_incremental_rendering()
	is_loaded = true

	GameLog.debug(LOG_TAG, "Initialized chunk %s at %s" % [chunk_pos, position])

## Calculate world position offset for this chunk
func _calculate_chunk_world_offset(coords: Vector2i) -> Vector2:
	var tile_offset = coords * ChunkTileData.CHUNK_SIZE
	return PlanetMapCoordinates.grid_to_world(tile_offset)

## Initialize slot array — TileMaps created lazily on first use
func _create_tilemaps():
	elevation_tilemaps.clear()
	elevation_tilemaps.resize(PlanetMapTileConfig.NUM_RENDER_LAYERS)
	water_tilemaps.clear()
	water_tilemaps.resize(PlanetMapTileConfig.NUM_RENDER_LAYERS)
	for i in range(PlanetMapTileConfig.NUM_RENDER_LAYERS):
		elevation_tilemaps[i] = null
		water_tilemaps[i] = null

## Get or create a TileMap for the given elevation layer (lazy creation)
func _get_or_create_tilemap(layer: int) -> TileMap:
	if layer < 0 or layer >= elevation_tilemaps.size():
		return null
	if elevation_tilemaps[layer] != null and is_instance_valid(elevation_tilemaps[layer]):
		return elevation_tilemaps[layer]

	var tilemap = TileMap.new()
	tilemap.name = "Elevation_%d" % layer
	tilemap.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	tilemap.tile_set = PlanetMapTileConfig.get_shared_tileset()
	tilemap.position = Vector2(0, -layer * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET)
	tilemap.z_index = layer * PlanetMapTileConfig.ELEVATION_Z_SPACING
	var brightness = PlanetMapTileConfig.get_elevation_brightness(layer)
	tilemap.modulate = Color(brightness, brightness, brightness, 1.0)
	tilemap.y_sort_enabled = true
	# One quadrant per TileMap = one draw call per visible layer. Default (16) = 16 draw calls.
	tilemap.rendering_quadrant_size = ChunkTileData.CHUNK_SIZE
	add_child(tilemap)
	elevation_tilemaps[layer] = tilemap
	return tilemap

## Get or create a water TileMap for the given layer (no elevation darkening)
func _get_or_create_water_tilemap(layer: int) -> TileMap:
	if layer < 0 or layer >= water_tilemaps.size():
		return null
	if water_tilemaps[layer] != null and is_instance_valid(water_tilemaps[layer]):
		return water_tilemaps[layer]

	var tilemap = TileMap.new()
	tilemap.name = "Water_%d" % layer
	tilemap.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	tilemap.tile_set = PlanetMapTileConfig.get_shared_tileset()
	tilemap.position = Vector2(0, -layer * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET)
	tilemap.z_index = layer * PlanetMapTileConfig.ELEVATION_Z_SPACING
	tilemap.y_sort_enabled = true
	tilemap.rendering_quadrant_size = ChunkTileData.CHUNK_SIZE
	add_child(tilemap)
	water_tilemaps[layer] = tilemap
	return tilemap

func _create_flow_container():
	flow_container = Node2D.new()
	flow_container.name = "FlowContainer"
	flow_container.y_sort_enabled = false
	flow_container.z_index = 0
	add_child(flow_container)

## Container for structure-tile Sprite2D and post-render fallback sprites
func _create_update_container():
	_update_container = Node2D.new()
	_update_container.name = "UpdateContainer"
	_update_container.y_sort_enabled = false
	add_child(_update_container)

# ── Incremental rendering ──────────────────────────────────────────────────────

func _start_incremental_rendering():
	_render_index = 0
	_is_rendering = true

## Incremental collection phase: read tile data into pending arrays, tiles_per_frame/frame.
## Uses index cursor instead of Array.pop_front() to avoid O(n) shifting per tile
## (pop_front on 4096 elements = ~47MB of Variant data moved per frame).
## When complete, builds all MultiMeshes and flow overlays in one shot.
func _process(_delta):
	if not _is_rendering:
		return

	var tiles_done := 0
	@warning_ignore("integer_division")
	var total: int = ChunkTileData.CHUNK_SIZE * ChunkTileData.CHUNK_SIZE
	while tiles_done < tiles_per_frame and _render_index < total:
		var local_pos := Vector2i(
			_render_index % ChunkTileData.CHUNK_SIZE,
			_render_index / ChunkTileData.CHUNK_SIZE)
		var flat_idx: int = _render_index
		_render_index += 1

		var elevation: float = _tile_data.elevations[flat_idx]
		var tile_type: int = _tile_data.tile_types[flat_idx]
		var render_layer: int = _tile_data.render_layers[flat_idx]

		_render_tile_at(local_pos, elevation, tile_type, render_layer)

		var flow_dir: int = _tile_data.get_flow_direction(local_pos)
		if flow_dir != 255 and flow_dir != 8:
			_collect_flow_at(local_pos, render_layer, flow_dir)

		var feature = _tile_data.get_feature(local_pos)
		if feature != null:
			_collect_feature_at(local_pos, elevation, feature, render_layer)

		var understory = _tile_data.get_understory(local_pos)
		if understory != null:
			_collect_understory_at(local_pos, elevation, understory, render_layer)

		tiles_done += 1

	if _render_index >= total:
		_is_rendering = false
		_tile_data = null
		_neighbor_edges.clear()
		_build_flow_overlays()
		_build_multimeshes()
		if not _trees_visible:
			set_trees_visible(false)
		if _heatmap_active:
			_apply_heatmap(true)
		set_process(false)
		# Reveal chunk at end of frame via call_deferred — setting visible=true mid-frame
		# triggers y_sort re-sort in the parent container, which can cause a one-frame
		# rendering delay in the SubViewport (Godot #107201). Deferring ensures the
		# visibility change happens after the current render cycle completes.
		modulate.a = 1.0
		set_deferred("visible", true)

# ── Tile rendering (TileMap) ───────────────────────────────────────────────────

func _render_tile_at(local_pos: Vector2i, elevation: float, tile_type: int, render_layer: int = -1):
	_local_elevation[local_pos] = elevation
	_local_tile_types[local_pos] = tile_type
	var target_layer: int = render_layer if render_layer >= 0 else \
		clampi(PlanetMapTileConfig.get_render_layer(elevation), 0, PlanetMapTileConfig.NUM_RENDER_LAYERS - 1)

	var is_water = (tile_type == PlanetMapTileConfig.TileType.FRESH_WATER)
	if is_water and target_layer > 0:
		target_layer -= 1

	var atlas_coords = PlanetMapTileConfig.get_atlas_coords(tile_type as PlanetMapTileConfig.TileType)

	# Determine the bottom-most layer to fill.
	# Strategy: fill MIN_BODY_LAYERS below target, extend to any lower neighbor (cliff faces).
	# Edge tiles use neighbor chunk edge data when available; fall back to layer 0 without it.
	const MIN_BODY_LAYERS := 2  # 40px visual mass at 20px/layer
	var bottom_layer: int
	if _tile_data != null:
		const CS := ChunkTileData.CHUNK_SIZE
		var lx := local_pos.x
		var ly := local_pos.y
		bottom_layer = maxi(0, target_layer - MIN_BODY_LAYERS + 1)

		# West neighbor
		if lx > 0:
			bottom_layer = mini(bottom_layer, int(_tile_data.render_layers[ly * CS + lx - 1]))
		elif _neighbor_edges.has("west"):
			bottom_layer = mini(bottom_layer, _neighbor_edges["west"][ly])
		else:
			bottom_layer = 0

		# East neighbor
		if bottom_layer > 0:
			if lx < CS - 1:
				bottom_layer = mini(bottom_layer, int(_tile_data.render_layers[ly * CS + lx + 1]))
			elif _neighbor_edges.has("east"):
				bottom_layer = mini(bottom_layer, _neighbor_edges["east"][ly])
			else:
				bottom_layer = 0

		# North neighbor
		if bottom_layer > 0:
			if ly > 0:
				bottom_layer = mini(bottom_layer, int(_tile_data.render_layers[(ly - 1) * CS + lx]))
			elif _neighbor_edges.has("north"):
				bottom_layer = mini(bottom_layer, _neighbor_edges["north"][lx])
			else:
				bottom_layer = 0

		# South neighbor
		if bottom_layer > 0:
			if ly < CS - 1:
				bottom_layer = mini(bottom_layer, int(_tile_data.render_layers[(ly + 1) * CS + lx]))
			elif _neighbor_edges.has("south"):
				bottom_layer = mini(bottom_layer, _neighbor_edges["south"][lx])
			else:
				bottom_layer = 0
	else:
		bottom_layer = 0  # post-render update: conservative

	for layer in range(bottom_layer, target_layer + 1):
		var tilemap = _get_or_create_tilemap(layer)
		if tilemap:
			tilemap.set_cell(0, local_pos, PlanetMapTileConfig.TILESET_SOURCE_ID, atlas_coords)

## Collect flow overlay data during incremental pass (O(1) append).
## Sprite2Ds created in batch by _build_flow_overlays() after all tiles are done,
## so Sprite2D/add_child cost doesn't inflate the per-tile budget.
func _collect_flow_at(local_pos: Vector2i, render_layer: int, flow_dir: int) -> void:
	var atlas_coords: Vector2i
	var flip_h := false
	match flow_dir:
		0, 4:  atlas_coords = Vector2i(14, 5)
		2, 6:  atlas_coords = Vector2i(13, 5)
		1, 5:  atlas_coords = Vector2i(15, 5)
		3, 7:
			atlas_coords = Vector2i(15, 5)
			flip_h = true
		_: return
	var target_layer: int = render_layer - 1 if render_layer > 0 else 0
	_pending_flow.append({
		"pos": local_pos,
		"atlas": atlas_coords,
		"flip_h": flip_h,
		"layer": target_layer,
	})

## Batch-create flow overlay Sprite2Ds from collected data.
func _build_flow_overlays() -> void:
	if _pending_flow.is_empty():
		return
	var tile_size := PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	var inset := PlanetMapTileConfig.TILESET_REGION_INSET
	var region_size := tile_size - inset * 2
	for entry in _pending_flow:
		var target_layer: int = entry["layer"]
		var ref_tilemap = _get_or_create_tilemap(target_layer)
		if ref_tilemap == null:
			continue
		var sprite := Sprite2D.new()
		sprite.texture = PlanetMapTileConfig.TILESET_TEXTURE
		sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		sprite.region_enabled = true
		sprite.flip_h = entry["flip_h"]
		sprite.region_rect = Rect2i(entry["atlas"] * tile_size + inset, region_size)
		sprite.position = ref_tilemap.position + ref_tilemap.map_to_local(entry["pos"])
		sprite.centered = true
		sprite.z_as_relative = false
		sprite.z_index = target_layer * PlanetMapTileConfig.ELEVATION_Z_SPACING + 1
		var brightness := PlanetMapTileConfig.get_elevation_brightness(target_layer)
		sprite.modulate = Color(brightness, brightness, brightness, 1.0)
		flow_container.add_child(sprite)
	_pending_flow.clear()

# ── Feature / shadow / understory collection ───────────────────────────────────

## Collect tree instance data for a feature tile. Structure tiles (longhouse) get Sprite2D directly.
func _collect_feature_at(local_pos: Vector2i, elevation: float, feature, precomputed_layer: int = -1) -> void:
	var tile_id: int = int(feature)
	if tile_id <= 0:
		return

	var render_layer: int = precomputed_layer if precomputed_layer >= 0 else \
		clampi(PlanetMapTileConfig.get_render_layer(elevation), 0, elevation_tilemaps.size() - 1)
	var atlas_coords: Vector2i = GeneratedTileTypes.get_atlas_coords(tile_id as GeneratedTileTypes.TileType)
	if atlas_coords == Vector2i(-1, -1):
		return

	if _is_structure_tile(tile_id):
		if _tile_data and _tile_data.is_ruin(local_pos):
			add_ruin_at(local_pos, tile_id)
		else:
			_create_structure_sprite(local_pos, elevation, tile_id, render_layer, atlas_coords)
		return

	var ref_tilemap := elevation_tilemaps[render_layer]
	if not ref_tilemap:
		return

	var tile_size := PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	var inset := PlanetMapTileConfig.TILESET_REGION_INSET
	var region_size := tile_size - inset * 2

	var world_pos := chunk_pos * ChunkTileData.CHUNK_SIZE + local_pos
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(Vector2(world_pos))
	var x_offset: float = rng.randf_range(-16.0, 16.0)
	var base_scale: float = _pick_tree_scale(tile_id, rng)
	var flip_h: bool = rng.randf() > 0.5
	var elev_scale: float = 1.0 + (float(render_layer) / float(PlanetMapTileConfig.NUM_RENDER_LAYERS - 1)) * 0.4
	var final_scale: float = base_scale * elev_scale

	var sprite_pos: Vector2 = ref_tilemap.position + ref_tilemap.map_to_local(local_pos) + Vector2(x_offset, 0.0)

	# Transform encodes position and size in pixels (1 unit = 1 pixel in 2D).
	# x_axis.x negative = horizontal flip.
	var W: float = region_size.x * final_scale * (-1.0 if flip_h else 1.0)
	var H: float = region_size.y * final_scale
	var instance_transform := Transform2D(Vector2(W, 0.0), Vector2(0.0, H), sprite_pos)

	var brightness: float = PlanetMapTileConfig.get_elevation_brightness(render_layer)
	var instance_color := Color(brightness, brightness, brightness, 1.0)

	sprite_cache[local_pos] = true
	_pending_trees.append({
		"pos": local_pos,
		"tile_id": tile_id,
		"transform": instance_transform,
		"color": instance_color,
	})

	_collect_shadow_at(local_pos, render_layer, ref_tilemap, x_offset, tile_id)

## Collect shadow instance data for a tree at local_pos.
func _collect_shadow_at(local_pos: Vector2i, render_layer: int, ref_tilemap: TileMap,
		x_offset: float, tile_id: int) -> void:
	var tile_local := ref_tilemap.map_to_local(local_pos)
	var shadow_pos := ref_tilemap.position + tile_local + Vector2(x_offset, -6.0)

	# Shadow displayed size = texture_size * sprite_scale (same as original Sprite2D).
	const SHADOW_TEX_W := 48.0
	const SHADOW_TEX_H := 20.0
	const SHADOW_SCALE_X := 5.5
	const SHADOW_SCALE_Y := 5.0
	var size_mult := _pick_shadow_size(tile_id)
	var W := SHADOW_TEX_W * SHADOW_SCALE_X * size_mult
	var H := SHADOW_TEX_H * SHADOW_SCALE_Y * size_mult
	var instance_transform := Transform2D(Vector2(W, 0.0), Vector2(0.0, H), shadow_pos)

	_pending_shadows.append({
		"pos": local_pos,
		"transform": instance_transform,
	})

## Collect understory instance data.
func _collect_understory_at(local_pos: Vector2i, elevation: float, tile_id: int, precomputed_layer: int = -1) -> void:
	if tile_id <= 0:
		return
	var render_layer: int = precomputed_layer if precomputed_layer >= 0 else \
		clampi(PlanetMapTileConfig.get_render_layer(elevation), 0, elevation_tilemaps.size() - 1)
	var atlas_coords: Vector2i = GeneratedTileTypes.get_atlas_coords(tile_id as GeneratedTileTypes.TileType)
	if atlas_coords == Vector2i(-1, -1):
		return

	var ref_tilemap := elevation_tilemaps[render_layer]
	if not ref_tilemap:
		return

	var tile_size := PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	var inset := PlanetMapTileConfig.TILESET_REGION_INSET
	var region_size := tile_size - inset * 2

	var world_pos := chunk_pos * ChunkTileData.CHUNK_SIZE + local_pos
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(Vector2(world_pos)) ^ 0xBEEF4321
	var x_offset: float = rng.randf_range(-14.0, 14.0)
	var final_scale: float = _pick_understory_scale(tile_id, rng)
	var flip_h: bool = rng.randf() > 0.5

	var sprite_pos: Vector2 = ref_tilemap.position + ref_tilemap.map_to_local(local_pos) + Vector2(x_offset, 1.0)

	var W: float = region_size.x * final_scale * (-1.0 if flip_h else 1.0)
	var H: float = region_size.y * final_scale
	var instance_transform := Transform2D(Vector2(W, 0.0), Vector2(0.0, H), sprite_pos)

	var brightness: float = PlanetMapTileConfig.get_elevation_brightness(render_layer)
	var instance_color := Color(brightness, brightness, brightness, 1.0)

	_pending_understory.append({
		"pos": local_pos,
		"tile_id": tile_id,
		"transform": instance_transform,
		"color": instance_color,
	})

## Create a Sprite2D directly for structure tiles (longhouse). Also spawns smoke.
func _create_structure_sprite(local_pos: Vector2i, elevation: float, tile_id: int,
		render_layer: int, atlas_coords: Vector2i) -> void:
	var tile_size := PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	var inset := PlanetMapTileConfig.TILESET_REGION_INSET
	var region_pos := atlas_coords * tile_size + inset
	var region_size := tile_size - inset * 2

	var ref_tilemap := elevation_tilemaps[render_layer]
	if not ref_tilemap:
		return
	var tile_local := ref_tilemap.map_to_local(local_pos)

	var sprite := Sprite2D.new()
	sprite.texture = PlanetMapTileConfig.TILESET_TEXTURE
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.region_enabled = true
	sprite.region_rect = Rect2i(region_pos, region_size)
	sprite.centered = false
	sprite.offset = Vector2(-region_size.x / 2.0, -region_size.y)
	sprite.position = ref_tilemap.position + tile_local
	sprite.position.y += PlanetMapTileConfig.TILE_SIZE.y / 2.0
	sprite.z_as_relative = false
	sprite.z_index = PlanetMapTileConfig.SURFACE_FEATURE_Z_INDEX + 2
	sprite.modulate = Color(
		PlanetMapTileConfig.get_elevation_brightness(render_layer),
		PlanetMapTileConfig.get_elevation_brightness(render_layer),
		PlanetMapTileConfig.get_elevation_brightness(render_layer),
		1.0
	)
	_update_container.add_child(sprite)
	sprite_cache[local_pos] = true
	_spawn_smoke_at(local_pos, sprite.position)

# ── MultiMesh build ────────────────────────────────────────────────────────────

## Build all three MultiMeshes from collected pending arrays. Called once when collection is done.
## Trees and understory are grouped by tile_id — one MultiMeshInstance2D per species, each with
## its own AtlasTexture that auto-remaps UV (0-1) to the correct atlas region. No shader UV tricks.
func _build_multimeshes() -> void:
	# ── Trees (one MultiMeshInstance2D per species-row pair) ─────────────────
	# Group key: Vector2i(tile_id, row_y). Each row gets its own z_index offset so
	# row Y=30 always renders behind row Y=31, regardless of species. Correct isometric depth.
	if not _pending_trees.is_empty():
		var groups: Dictionary = {}  # Vector2i(tile_id, row_y) → Array of pending entries
		for entry in _pending_trees:
			var key := Vector2i(entry["tile_id"], entry["pos"].y)
			if not groups.has(key):
				groups[key] = []
			groups[key].append(entry)

		var vm := VariantManager.get_instance()
		# Use the MultiMesh-specific material — is_multimesh=true fixes wind sway.
		# VERTEX in MultiMesh is local mesh space [-1,0], not canvas pixels like Sprite2D.
		var shared_mat: ShaderMaterial = vm.get_shared_tree_material_for_multimesh() if vm else null

		for group_key in groups.keys():
			var tile_id: int = group_key.x
			var row_y: int = group_key.y
			var entries: Array = groups[group_key]
			var atlas_coords := GeneratedTileTypes.get_atlas_coords(tile_id as GeneratedTileTypes.TileType)

			var mm := MultiMesh.new()
			mm.transform_format = MultiMesh.TRANSFORM_2D
			mm.use_colors = false
			mm.use_custom_data = true
			mm.mesh = _get_tile_mesh(tile_id, atlas_coords)
			mm.instance_count = entries.size()
			for i in entries.size():
				var d = entries[i]
				mm.set_instance_transform_2d(i, d["transform"])
				mm.set_instance_custom_data(i, d["color"])
				_tree_idx[d["pos"]] = {"group_key": group_key, "idx": i}

			var mm_node := MultiMeshInstance2D.new()
			mm_node.multimesh = mm
			mm_node.texture = PlanetMapTileConfig.TILESET_TEXTURE
			mm_node.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
			mm_node.z_index = PlanetMapTileConfig.SURFACE_FEATURE_Z_INDEX + row_y
			if shared_mat:
				mm_node.material = shared_mat
			add_child(mm_node)
			_tree_mms[group_key] = mm_node

	_pending_trees.clear()

	# ── Shadows (one MultiMeshInstance2D, shared shadow texture) ──────────────
	if not _pending_shadows.is_empty():
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_2D
		mm.use_colors = false
		mm.use_custom_data = false
		mm.mesh = _get_center_quad()
		mm.instance_count = _pending_shadows.size()
		for i in _pending_shadows.size():
			var d = _pending_shadows[i]
			mm.set_instance_transform_2d(i, d["transform"])
			_shadow_idx[d["pos"]] = i

		_shadow_mm = MultiMeshInstance2D.new()
		_shadow_mm.multimesh = mm
		_shadow_mm.texture = _get_shadow_texture()
		_shadow_mm.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
		_shadow_mm.modulate = Color(0.0, 0.0, 0.0, 0.5)
		_shadow_mm.z_index = PlanetMapTileConfig.SURFACE_FEATURE_Z_INDEX - 1
		add_child(_shadow_mm)

	_pending_shadows.clear()

	# ── Understory (one MultiMeshInstance2D per species) ──────────────────────
	if not _pending_understory.is_empty():
		var groups: Dictionary = {}
		for entry in _pending_understory:
			var tid: int = entry["tile_id"]
			if not groups.has(tid):
				groups[tid] = []
			groups[tid].append(entry)

		var u_mat := _get_understory_material()

		for tile_id in groups.keys():
			var entries: Array = groups[tile_id]
			var atlas_coords := GeneratedTileTypes.get_atlas_coords(tile_id as GeneratedTileTypes.TileType)

			var mm := MultiMesh.new()
			mm.transform_format = MultiMesh.TRANSFORM_2D
			mm.use_colors = false
			mm.use_custom_data = true
			mm.mesh = _get_tile_mesh(tile_id, atlas_coords)
			mm.instance_count = entries.size()
			for i in entries.size():
				var d = entries[i]
				mm.set_instance_transform_2d(i, d["transform"])
				mm.set_instance_custom_data(i, d["color"])
				_understory_idx[d["pos"]] = {"tile_id": tile_id, "idx": i}

			var mm_node := MultiMeshInstance2D.new()
			mm_node.multimesh = mm
			mm_node.texture = PlanetMapTileConfig.TILESET_TEXTURE
			mm_node.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
			mm_node.z_index = PlanetMapTileConfig.SURFACE_FEATURE_Z_INDEX - 2
			mm_node.material = u_mat
			add_child(mm_node)
			_understory_mms[tile_id] = mm_node

	_pending_understory.clear()

# ── Post-render feature updates ────────────────────────────────────────────────

## Update the tree (and shadow) at a local position. Hides MultiMesh instance, adds fallback Sprite2D.
func update_tree_at(local_pos: Vector2i, tile_id: int) -> void:
	remove_tree_at(local_pos)
	if tile_id > 0:
		var elevation: float = _local_elevation.get(local_pos, 0.5)
		_create_fallback_tree_sprite(local_pos, elevation, tile_id)

## Remove the tree (and shadow) at a local position.
func remove_tree_at(local_pos: Vector2i) -> void:
	# Hide tree MultiMesh instance via zero-scale transform (collapses mesh to single point).
	# Alpha-based hiding (set_instance_color alpha=0) would require all trees to be invisible
	# unless the shader explicitly reads instance color — zero-scale is simpler and avoids artifacts.
	var t_info = _tree_idx.get(local_pos, null)
	if t_info != null:
		var mm_node: MultiMeshInstance2D = _tree_mms.get(t_info["group_key"], null)
		if mm_node and mm_node.multimesh:
			mm_node.multimesh.set_instance_transform_2d(t_info["idx"],
				Transform2D(Vector2.ZERO, Vector2.ZERO, Vector2.ZERO))
	# Hide shadow MultiMesh instance (same zero-scale approach)
	var s_idx: int = _shadow_idx.get(local_pos, -1)
	if s_idx >= 0 and _shadow_mm and _shadow_mm.multimesh:
		_shadow_mm.multimesh.set_instance_transform_2d(s_idx,
			Transform2D(Vector2.ZERO, Vector2.ZERO, Vector2.ZERO))
	sprite_cache.erase(local_pos)

## Create a fallback Sprite2D for a tree that was added/updated post-render.
func _create_fallback_tree_sprite(local_pos: Vector2i, elevation: float, tile_id: int) -> void:
	var render_layer: int = clampi(PlanetMapTileConfig.get_render_layer(elevation), 0, elevation_tilemaps.size() - 1)
	var atlas_coords: Vector2i = GeneratedTileTypes.get_atlas_coords(tile_id as GeneratedTileTypes.TileType)
	if atlas_coords == Vector2i(-1, -1):
		return

	var ref_tilemap := elevation_tilemaps[render_layer]
	if not ref_tilemap:
		return

	var tile_size := PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	var inset := PlanetMapTileConfig.TILESET_REGION_INSET
	var region_pos := atlas_coords * tile_size + inset
	var region_size := tile_size - inset * 2

	var world_pos := chunk_pos * ChunkTileData.CHUNK_SIZE + local_pos
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(Vector2(world_pos))
	var x_offset: float = rng.randf_range(-16.0, 16.0)
	var base_scale: float = _pick_tree_scale(tile_id, rng)
	var flip_h: bool = rng.randf() > 0.5
	var elev_scale: float = 1.0 + (float(render_layer) / float(PlanetMapTileConfig.NUM_RENDER_LAYERS - 1)) * 0.4
	var final_scale: float = base_scale * elev_scale

	var sprite := Sprite2D.new()
	sprite.texture = PlanetMapTileConfig.TILESET_TEXTURE
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.region_enabled = true
	sprite.region_rect = Rect2i(region_pos, region_size)
	sprite.centered = false
	sprite.offset = Vector2(-region_size.x / 2.0, -region_size.y)
	sprite.position = ref_tilemap.position + ref_tilemap.map_to_local(local_pos) + Vector2(x_offset, 0.0)
	sprite.scale = Vector2((-1.0 if flip_h else 1.0) * final_scale, final_scale)
	sprite.z_as_relative = false
	sprite.z_index = PlanetMapTileConfig.SURFACE_FEATURE_Z_INDEX

	var brightness: float = PlanetMapTileConfig.get_elevation_brightness(render_layer)
	var vm := VariantManager.get_instance()
	if vm and not _is_structure_tile(tile_id):
		var mat := vm.get_shared_tree_material_for_layer(render_layer, brightness)
		if mat:
			sprite.material = mat
	else:
		sprite.modulate = Color(brightness, brightness, brightness, 1.0)

	_update_container.add_child(sprite)
	sprite_cache[local_pos] = true

## Remove the understory sprite at a local position.
func remove_understory_at(local_pos: Vector2i) -> void:
	var u_info = _understory_idx.get(local_pos, null)
	if u_info != null:
		var mm_node: MultiMeshInstance2D = _understory_mms.get(u_info["tile_id"], null)
		if mm_node and mm_node.multimesh:
			mm_node.multimesh.set_instance_transform_2d(u_info["idx"],
				Transform2D(Vector2.ZERO, Vector2.ZERO, Vector2.ZERO))

## Restore (or replace) understory at a local position.
func update_understory_at(local_pos: Vector2i, tile_id: int) -> void:
	remove_understory_at(local_pos)
	if tile_id > 0:
		var elevation: float = _local_elevation.get(local_pos, 0.5)
		if not _is_rendering:
			# Post-render: can't add instances to existing MultiMesh — use fallback Sprite2D
			_create_fallback_understory_sprite(local_pos, elevation, tile_id)
		else:
			_collect_understory_at(local_pos, elevation, tile_id)

## Create fallback Sprite2D for understory (post-render update path).
func _create_fallback_understory_sprite(local_pos: Vector2i, elevation: float, tile_id: int) -> void:
	var render_layer: int = clampi(PlanetMapTileConfig.get_render_layer(elevation), 0, elevation_tilemaps.size() - 1)
	var atlas_coords: Vector2i = GeneratedTileTypes.get_atlas_coords(tile_id as GeneratedTileTypes.TileType)
	if atlas_coords == Vector2i(-1, -1):
		return
	var ref_tilemap := elevation_tilemaps[render_layer]
	if not ref_tilemap:
		return

	var tile_size := PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	var inset := PlanetMapTileConfig.TILESET_REGION_INSET
	var region_size := tile_size - inset * 2

	var world_pos := chunk_pos * ChunkTileData.CHUNK_SIZE + local_pos
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(Vector2(world_pos)) ^ 0xBEEF4321
	var x_offset: float = rng.randf_range(-14.0, 14.0)
	var final_scale: float = _pick_understory_scale(tile_id, rng)
	var flip_h: bool = rng.randf() > 0.5

	var sprite := Sprite2D.new()
	sprite.texture = PlanetMapTileConfig.TILESET_TEXTURE
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.region_enabled = true
	sprite.region_rect = Rect2i(atlas_coords * tile_size + inset, region_size)
	sprite.centered = false
	sprite.offset = Vector2(-region_size.x / 2.0, -region_size.y)
	sprite.position = ref_tilemap.position + ref_tilemap.map_to_local(local_pos) + Vector2(x_offset, 1.0)
	sprite.scale = Vector2((-1.0 if flip_h else 1.0) * final_scale, final_scale)
	var brightness: float = PlanetMapTileConfig.get_elevation_brightness(render_layer)
	sprite.modulate = Color(brightness, brightness, brightness, 1.0)
	sprite.z_as_relative = false
	sprite.z_index = PlanetMapTileConfig.SURFACE_FEATURE_Z_INDEX - 2
	_update_container.add_child(sprite)

# ── Theme / material update ────────────────────────────────────────────────────

## Update the tree shader material (called on theme change by PlanetMapSystem).
func apply_tree_material(material: ShaderMaterial) -> void:
	for mm_node in _tree_mms.values():
		if is_instance_valid(mm_node):
			mm_node.material = material
	# Also update any fallback Sprite2D tree sprites in _update_container
	if _update_container:
		for child in _update_container.get_children():
			if child is Sprite2D and child.material != null:
				child.material = material

# ── Smoke (longhouse chimneys) ─────────────────────────────────────────────────

## Push current wind to all smoke emitters in this chunk.
func set_wind_drift(drift_x: float) -> void:
	for entry in smoke_cache.values():
		for p in entry["emitters"]:
			if is_instance_valid(p):
				var mat := p.process_material as ParticleProcessMaterial
				if mat:
					mat.gravity = Vector3(drift_x, -4.0, 0.0)

## Set smoke emission rate for a longhouse at local_pos.
func set_smoke_rate(local_pos: Vector2i, factor: float) -> void:
	if not smoke_cache.has(local_pos):
		return
	var entry: Dictionary = smoke_cache[local_pos]
	var clamped := clampf(factor, 0.0, 1.0)
	var scaled := clamped * clamped
	var emitters: Array = entry["emitters"]
	var max_spreads: Array = entry["max_spreads"]
	for i in emitters.size():
		var p: GPUParticles2D = emitters[i]
		if not is_instance_valid(p):
			continue
		p.speed_scale = scaled
		p.emitting = scaled > 0.01
		var mat := p.process_material as ParticleProcessMaterial
		if mat:
			mat.spread = max_spreads[i] * scaled

func _spawn_smoke_at(local_pos: Vector2i, sprite_pos: Vector2) -> void:
	var chimney := sprite_pos + Vector2(-55.0, -90.0)
	var col   := _make_smoke_emitter(chimney, 8.0,  55.0, 80.0, 1.2, 2.8,  80, 12.0, 0.35, true,  8.0)
	var drift := _make_smoke_emitter(chimney, 28.0, 12.0, 25.0, 0.7, 1.4,  30,  8.0, 0.35, false, 3.0)
	add_child(col)
	add_child(drift)
	smoke_cache[local_pos] = {
		"emitters": [col, drift],
		"max_spreads": [8.0, 28.0],
	}

func _make_smoke_emitter(pos: Vector2, spread: float, v_min: float, v_max: float,
		s_min: float, s_max: float, amount: int, lifetime: float,
		grey: float, angular: bool, drift_x: float = 0.0) -> GPUParticles2D:
	var mat := ParticleProcessMaterial.new()
	mat.direction = Vector3(0.0, -1.0, 0.0)
	mat.spread = spread
	mat.initial_velocity_min = v_min
	mat.initial_velocity_max = v_max
	mat.gravity = Vector3(drift_x, -4.0, 0.0)
	mat.scale_min = s_min
	mat.scale_max = s_max
	mat.lifetime_randomness = 0.2
	if angular:
		mat.angular_velocity_min = -90.0
		mat.angular_velocity_max = 90.0

	var grad := Gradient.new()
	grad.offsets = PackedFloat32Array([0.0, 0.08, 0.75, 1.0])
	grad.colors = PackedColorArray([
		Color(grey, grey, grey, 0.0),
		Color(grey, grey, grey, 0.55),
		Color(grey + 0.15, grey + 0.15, grey + 0.15, 0.45),
		Color(0.4, 0.4, 0.4, 0.0),
	])
	var grad_tex := GradientTexture1D.new()
	grad_tex.gradient = grad
	mat.color_ramp = grad_tex

	var particles := GPUParticles2D.new()
	particles.process_material = mat
	particles.texture = _get_smoke_texture()
	particles.amount = amount
	particles.lifetime = lifetime
	particles.z_as_relative = false
	particles.z_index = PlanetMapTileConfig.SURFACE_FEATURE_Z_INDEX + ChunkTileData.CHUNK_SIZE + 10
	particles.position = pos
	return particles

static func _get_smoke_shader_mat() -> ShaderMaterial:
	if _smoke_shader_mat != null:
		return _smoke_shader_mat

	var noise := FastNoiseLite.new()
	noise.noise_type = FastNoiseLite.TYPE_PERLIN
	noise.fractal_octaves = 4
	noise.frequency = 0.025

	var noise_tex := NoiseTexture2D.new()
	noise_tex.width = 128
	noise_tex.height = 128
	noise_tex.seamless = true
	noise_tex.noise = noise

	var shader := Shader.new()
	shader.code = """
shader_type canvas_item;
uniform sampler2D noise_tex : hint_default_white;
uniform float distortion : hint_range(0.0, 1.0) = 0.28;
void fragment() {
	vec2 uv = UV;
	vec2 nuv = uv * 2.0 + vec2(TIME * 0.04, TIME * 0.025);
	float n = texture(noise_tex, nuv).r;
	uv += (n - 0.5) * distortion;
	float dist = length(uv - vec2(0.5)) * 2.0;
	float alpha = smoothstep(1.0, 0.0, dist);
	alpha *= smoothstep(0.1, 0.65, n);
	alpha = pow(alpha, 1.4);
	COLOR.a *= alpha;
}
"""
	_smoke_shader_mat = ShaderMaterial.new()
	_smoke_shader_mat.shader = shader
	_smoke_shader_mat.set_shader_parameter("noise_tex", noise_tex)
	_smoke_shader_mat.set_shader_parameter("distortion", 0.28)
	return _smoke_shader_mat

func _get_smoke_texture() -> ImageTexture:
	if _smoke_texture != null:
		return _smoke_texture
	var size := 48
	var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
	var center := size * 0.5
	var radius := center * 0.88
	for y in range(size):
		for x in range(size):
			var dist := sqrt((x - center) * (x - center) + (y - center) * (y - center)) / radius
			var a := clampf(1.0 - dist, 0.0, 1.0)
			a = a * a
			img.set_pixel(x, y, Color(1.0, 1.0, 1.0, a))
	_smoke_texture = ImageTexture.create_from_image(img)
	return _smoke_texture

# ── Shared textures / materials / meshes ───────────────────────────────────────

func _get_shadow_texture() -> ImageTexture:
	if _shadow_texture != null:
		return _shadow_texture
	var w := 48
	var h := 20
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	var cx := w * 0.5
	var cy := h * 0.5
	var rx := w * 0.46
	var ry := h * 0.46
	for y in range(h):
		for x in range(w):
			var nx: float = (x - cx) / rx
			var ny: float = (y - cy) / ry
			var dist: float = sqrt(nx * nx + ny * ny)
			var a: float = clampf(1.0 - dist, 0.0, 1.0)
			a = a * a
			img.set_pixel(x, y, Color(0.0, 0.0, 0.0, a))
	_shadow_texture = ImageTexture.create_from_image(img)
	return _shadow_texture

## Shared material for understory MultiMesh — palette_swap with swap+wind disabled.
static func _get_understory_material() -> ShaderMaterial:
	if _understory_mat != null:
		return _understory_mat
	_understory_mat = ShaderMaterial.new()
	_understory_mat.shader = load("res://shaders/palette_swap.gdshader")
	_understory_mat.set_shader_parameter("enabled", false)
	_understory_mat.set_shader_parameter("wind_enabled", false)
	_understory_mat.set_shader_parameter("is_multimesh", true)
	return _understory_mat

## ArrayMesh with UVs baked to the atlas region for tile_id, bottom-center pivot.
## AtlasTexture does NOT remap UVs in MultiMeshInstance2D — UV must be baked into mesh geometry.
## Pivot: x ∈ (-0.5, 0.5), y ∈ (-1.0, 0.0). Transform x_axis encodes width, y_axis height.
## UV flip_h handled by negative x_axis in the instance transform (mirrors vertex positions).
static func _get_tile_mesh(tile_id: int, atlas_coords: Vector2i) -> ArrayMesh:
	if _tile_meshes.has(tile_id):
		return _tile_meshes[tile_id]

	var tile_size := PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	var inset := PlanetMapTileConfig.TILESET_REGION_INSET
	var region_pos := atlas_coords * tile_size + inset
	var region_sz := tile_size - inset * 2
	var tex_size := Vector2(PlanetMapTileConfig.TILESET_TEXTURE.get_size())

	var u0 := float(region_pos.x) / tex_size.x
	var v0 := float(region_pos.y) / tex_size.y
	var u1 := float(region_pos.x + region_sz.x) / tex_size.x
	var v1 := float(region_pos.y + region_sz.y) / tex_size.y

	var verts := PackedVector3Array([
		Vector3(-0.5, -1.0, 0.0),  # top-left
		Vector3( 0.5, -1.0, 0.0),  # top-right
		Vector3( 0.5,  0.0, 0.0),  # bottom-right
		Vector3(-0.5,  0.0, 0.0),  # bottom-left
	])
	var uvs := PackedVector2Array([
		Vector2(u0, v0),  # top-left  — atlas region coords
		Vector2(u1, v0),  # top-right
		Vector2(u1, v1),  # bottom-right
		Vector2(u0, v1),  # bottom-left
	])
	var indices := PackedInt32Array([0, 1, 2, 0, 2, 3])

	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices

	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_tile_meshes[tile_id] = mesh
	return mesh

## Shared QuadMesh for shadow instances — centered pivot matches Sprite2D centered=true.
static func _get_center_quad() -> QuadMesh:
	if _center_quad != null:
		return _center_quad
	_center_quad = QuadMesh.new()
	_center_quad.size = Vector2(1.0, 1.0)
	return _center_quad

# ── Helpers ────────────────────────────────────────────────────────────────────

func _pick_tree_scale(tile_id: int, rng: RandomNumberGenerator) -> float:
	if ForestSpecies.is_dead_tree(tile_id):
		return rng.randf_range(0.6, 1.2)
	if tile_id == ForestSpecies.OAK_VG:
		return rng.randf_range(0.9, 1.5)
	if tile_id == ForestSpecies.BEECH_VG:
		return rng.randf_range(1.0, 1.9)
	if tile_id == ForestSpecies.BIRCH_VG:
		return rng.randf_range(1.1, 2.1)
	return rng.randf_range(0.8, 1.5)

func _pick_understory_scale(tile_id: int, rng: RandomNumberGenerator) -> float:
	if tile_id == ForestSpecies.RASPBERRY_BUSH:
		return rng.randf_range(0.75, 1.20)
	return rng.randf_range(0.70, 1.10)

func _pick_shadow_size(tile_id: int) -> float:
	if ForestSpecies.is_dead_tree(tile_id):
		return 0.35
	for i in range(ForestSpecies.MAPLE_VG.size()):
		if tile_id == ForestSpecies.MAPLE_VG[i]:
			if i < 2:
				return 0.35
			elif i < 4:
				return 0.55
			else:
				return 3.0
	return 3.0

func _is_structure_tile(tile_id: int) -> bool:
	return tile_id == GeneratedTileTypes.TileType.TILE_R2_C11

func _is_valid_local_pos(local_pos: Vector2i) -> bool:
	return (local_pos.x >= 0 and local_pos.y >= 0 and
			local_pos.x < ChunkTileData.CHUNK_SIZE and
			local_pos.y < ChunkTileData.CHUNK_SIZE)

# ── Public API ─────────────────────────────────────────────────────────────────

## Add a structure sprite (e.g. longhouse) at a local position dynamically.
func add_structure_at(local_pos: Vector2i, tile_id: int) -> void:
	if not _is_valid_local_pos(local_pos):
		return
	var elevation: float = _local_elevation.get(local_pos, 0.5)
	var render_layer: int = clampi(PlanetMapTileConfig.get_render_layer(elevation), 0, elevation_tilemaps.size() - 1)
	var atlas_coords: Vector2i = GeneratedTileTypes.get_atlas_coords(tile_id as GeneratedTileTypes.TileType)
	if atlas_coords == Vector2i(-1, -1):
		return
	_create_structure_sprite(local_pos, elevation, tile_id, render_layer, atlas_coords)


## Add a ruin sprite (darkened longhouse, no smoke) at a local position.
func add_ruin_at(local_pos: Vector2i, tile_id: int) -> void:
	if not _is_valid_local_pos(local_pos):
		return
	var elevation: float = _local_elevation.get(local_pos, 0.5)
	var render_layer: int = clampi(PlanetMapTileConfig.get_render_layer(elevation), 0, elevation_tilemaps.size() - 1)
	var atlas_coords: Vector2i = GeneratedTileTypes.get_atlas_coords(tile_id as GeneratedTileTypes.TileType)
	if atlas_coords == Vector2i(-1, -1):
		return
	# Create structure sprite without smoke, with darkened modulate
	var tile_size := PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	var inset := PlanetMapTileConfig.TILESET_REGION_INSET
	var region_pos := atlas_coords * tile_size + inset
	var region_size := tile_size - inset * 2

	var ref_tilemap := elevation_tilemaps[render_layer]
	if not ref_tilemap:
		return
	var tile_local := ref_tilemap.map_to_local(local_pos)

	var sprite := Sprite2D.new()
	sprite.texture = PlanetMapTileConfig.TILESET_TEXTURE
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.region_enabled = true
	sprite.region_rect = Rect2i(region_pos, region_size)
	sprite.centered = false
	sprite.offset = Vector2(-region_size.x / 2.0, -region_size.y)
	sprite.position = ref_tilemap.position + tile_local
	sprite.position.y += PlanetMapTileConfig.TILE_SIZE.y / 2.0
	sprite.z_as_relative = false
	sprite.z_index = PlanetMapTileConfig.SURFACE_FEATURE_Z_INDEX + 1
	sprite.modulate = Color(0.45, 0.42, 0.35, 0.7)
	_update_container.add_child(sprite)
	sprite_cache[local_pos] = true


## Remove a structure sprite and its smoke at a local position.
func remove_structure_at(local_pos: Vector2i) -> void:
	if not _is_valid_local_pos(local_pos):
		return
	# Remove from sprite cache and free the sprite node
	if sprite_cache.has(local_pos):
		sprite_cache.erase(local_pos)
	# Remove smoke emitters
	if smoke_cache.has(local_pos):
		for emitter in smoke_cache[local_pos]:
			if is_instance_valid(emitter):
				emitter.queue_free()
		smoke_cache.erase(local_pos)
	# Find and remove sprite from update container
	if _update_container:
		for child in _update_container.get_children():
			if child is Sprite2D and child.position == _get_structure_position(local_pos):
				child.queue_free()
				break


func _get_structure_position(local_pos: Vector2i) -> Vector2:
	var elevation: float = _local_elevation.get(local_pos, 0.5)
	var render_layer: int = clampi(PlanetMapTileConfig.get_render_layer(elevation), 0, elevation_tilemaps.size() - 1)
	if render_layer >= elevation_tilemaps.size() or not elevation_tilemaps[render_layer]:
		return Vector2.ZERO
	var ref_tilemap := elevation_tilemaps[render_layer]
	var tile_local := ref_tilemap.map_to_local(local_pos)
	return ref_tilemap.position + tile_local


## Update single terrain tile (for dynamic changes).
func update_tile(local_pos: Vector2i, elevation: float, tile_type: int):
	if not _is_valid_local_pos(local_pos):
		GameLog.warn(LOG_TAG, "Invalid local position %s for chunk %s" % [local_pos, chunk_pos])
		return
	for tilemap in elevation_tilemaps:
		if tilemap and is_instance_valid(tilemap):
			tilemap.erase_cell(0, local_pos)
	for tilemap in water_tilemaps:
		if tilemap and is_instance_valid(tilemap):
			tilemap.erase_cell(0, local_pos)
	_render_tile_at(local_pos, elevation, tile_type)

## Get total number of terrain tiles rendered.
func get_tile_count() -> int:
	var count = 0
	for tilemap in elevation_tilemaps:
		if tilemap and is_instance_valid(tilemap):
			count += tilemap.get_used_cells(0).size()
	for tilemap in water_tilemaps:
		if tilemap and is_instance_valid(tilemap):
			count += tilemap.get_used_cells(0).size()
	return count

# ── View mode toggles ─────────────────────────────────────────────────────────

func set_trees_visible(show: bool) -> void:
	_trees_visible = show
	for mm_node in _tree_mms.values():
		if is_instance_valid(mm_node):
			mm_node.visible = show
	if _shadow_mm and is_instance_valid(_shadow_mm):
		_shadow_mm.visible = show
	for mm_node in _understory_mms.values():
		if is_instance_valid(mm_node):
			mm_node.visible = show
	if _update_container and is_instance_valid(_update_container):
		_update_container.visible = show

func set_heatmap_mode(enabled: bool) -> void:
	if _heatmap_active == enabled:
		return
	_heatmap_active = enabled
	_apply_heatmap(enabled)

func _apply_heatmap(enabled: bool) -> void:
	if _is_rendering:
		return
	var white_coords := PlanetMapTileConfig.get_atlas_coords(PlanetMapTileConfig.TileType.FLIR_0)
	# Update layer modulate colors
	for layer in range(elevation_tilemaps.size()):
		var tilemap = elevation_tilemaps[layer]
		if not tilemap or not is_instance_valid(tilemap):
			continue
		if enabled:
			var layer_elev: float = float(layer) / float(PlanetMapTileConfig.NUM_RENDER_LAYERS - 1)
			var flir_color := ChunkTileData.get_flir_color(layer_elev)
			tilemap.modulate = Color(flir_color.r, flir_color.g, flir_color.b, 1.0)
		else:
			var brightness := PlanetMapTileConfig.get_elevation_brightness(layer)
			tilemap.modulate = Color(brightness, brightness, brightness, 1.0)
	# Swap tile atlas coords
	for local_pos in _local_elevation:
		var elevation: float = _local_elevation[local_pos]
		var render_layer: int = clampi(
			PlanetMapTileConfig.get_render_layer(elevation),
			0, PlanetMapTileConfig.NUM_RENDER_LAYERS - 1)
		var atlas_coords: Vector2i
		if enabled:
			atlas_coords = white_coords
		else:
			var original_type: int = _local_tile_types.get(local_pos, PlanetMapTileConfig.TileType.PLAINS)
			atlas_coords = PlanetMapTileConfig.get_atlas_coords(
				original_type as PlanetMapTileConfig.TileType)
		var is_water = (_local_tile_types.get(local_pos, -1) == PlanetMapTileConfig.TileType.FRESH_WATER)
		var target_layer: int = render_layer - 1 if is_water and render_layer > 0 else render_layer
		for layer in range(0, target_layer + 1):
			var tilemap = elevation_tilemaps[layer] if layer < elevation_tilemaps.size() else null
			if tilemap and is_instance_valid(tilemap):
				if tilemap.get_cell_source_id(0, local_pos) != -1:
					tilemap.set_cell(0, local_pos, PlanetMapTileConfig.TILESET_SOURCE_ID, atlas_coords)

## Clear all tile visuals.
func clear_tiles():
	for tilemap in elevation_tilemaps:
		if tilemap and is_instance_valid(tilemap):
			tilemap.clear()
	for tilemap in water_tilemaps:
		if tilemap and is_instance_valid(tilemap):
			tilemap.clear()
	if flow_container:
		for child in flow_container.get_children():
			child.queue_free()
	if _update_container:
		for child in _update_container.get_children():
			child.queue_free()
	for entry in smoke_cache.values():
		for p in entry["emitters"]:
			if is_instance_valid(p):
				p.queue_free()
	smoke_cache.clear()
	for mm_node in _tree_mms.values():
		if is_instance_valid(mm_node):
			mm_node.queue_free()
	_tree_mms.clear()
	if _shadow_mm and is_instance_valid(_shadow_mm):
		_shadow_mm.queue_free()
		_shadow_mm = null
	for mm_node in _understory_mms.values():
		if is_instance_valid(mm_node):
			mm_node.queue_free()
	_understory_mms.clear()
	sprite_cache.clear()
	_tree_idx.clear()
	_shadow_idx.clear()
	_understory_idx.clear()
	_local_elevation.clear()
	_local_tile_types.clear()

func _exit_tree():
	clear_tiles()
