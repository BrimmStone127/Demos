class_name PlanetMapRenderer3D
extends IPlanetMapRenderer

## Orthogonal 3D renderer for planet maps
##
## Renders tiles as 3D billboarded sprites or meshes viewed from isometric angle.
## Uses orthogonal projection to maintain consistent scale (like 2D isometric).
##
## Benefits over 2D:
## - Can rotate camera around map (optional gameplay feature)
## - Real 3D lighting and shadows
## - Easier to mix 2D sprites with 3D structures
## - Elevation is actual Y-height (simpler than layer stacking)
##
## This is a PROTOTYPE implementation - shows the pattern, not production-ready.

var _parent: Node
var _viewport: SubViewport
var _camera: Camera3D
var _world: Node3D
var _tile_sprites: Dictionary  # Vector2i -> Sprite3D or MeshInstance3D
var _feature_sprites: Dictionary  # Vector2i -> Sprite3D

# Tile textures (would load from actual tileset)
var _tile_textures: Dictionary = {}

## Renderer lifecycle ─────────────────────────────────────────────────────────

func initialize(parent: Node, viewport: SubViewport) -> void:
	_parent = parent
	_viewport = viewport

	# Create 3D world
	_world = Node3D.new()
	_world.name = "PlanetMap3D"
	_viewport.add_child(_world)

	# Create 3D camera with orthogonal projection
	_camera = Camera3D.new()
	_camera.name = "IsometricCamera3D"
	_camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	_camera.size = 30.0  # Orthogonal view size

	# Position camera at isometric angle
	# Standard isometric: 45° horizontal rotation, ~35.264° vertical tilt
	_camera.position = Vector3(20, 20, 20)
	_camera.look_at(Vector3.ZERO, Vector3.UP)

	_world.add_child(_camera)

	# Optional: Add directional light for day/night
	var sun = DirectionalLight3D.new()
	sun.name = "Sun"
	sun.light_energy = 0.8
	sun.rotation_degrees = Vector3(-45, 45, 0)
	_world.add_child(sun)

	# Load tile textures (simplified - would use actual asset system)
	_load_tile_textures()

func cleanup() -> void:
	# Free all sprites
	for sprite in _tile_sprites.values():
		if is_instance_valid(sprite):
			sprite.queue_free()
	_tile_sprites.clear()

	for sprite in _feature_sprites.values():
		if is_instance_valid(sprite):
			sprite.queue_free()
	_feature_sprites.clear()

	# Free world
	if is_instance_valid(_world):
		_world.queue_free()

	_parent = null
	_viewport = null
	_camera = null
	_world = null

func _load_tile_textures() -> void:
	# TODO: Load actual textures from big_iso_tileset.png
	# For now, just placeholder
	pass

## Tile rendering ─────────────────────────────────────────────────────────────

func render_tile(tile_data) -> void:  # MapTile
	var pos_key = tile_data.position

	# Create or update sprite
	var sprite: Sprite3D
	if _tile_sprites.has(pos_key):
		sprite = _tile_sprites[pos_key]
	else:
		sprite = Sprite3D.new()
		sprite.billboard = BaseMaterial3D.BILLBOARD_DISABLED  # Fixed orientation
		sprite.pixel_size = 0.01  # Scale for pixel art
		sprite.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST  # Pixel-perfect!
		_world.add_child(sprite)
		_tile_sprites[pos_key] = sprite

	# Position in 3D world
	# X/Z = tile position, Y = elevation height
	var world_pos = _tile_to_world_3d(tile_data.position, tile_data.elevation)
	sprite.position = world_pos

	# Set texture based on tile type
	# TODO: Load actual texture from tileset
	# sprite.texture = _tile_textures.get(tile_data.type)

	# Apply elevation brightness (consistent with 2D)
	var brightness = PlanetMapTileConfig.get_elevation_brightness(tile_data.elevation)
	sprite.modulate = Color(brightness, brightness, brightness, 1.0)

func remove_tile(tile_pos: Vector2i) -> void:
	if _tile_sprites.has(tile_pos):
		var sprite = _tile_sprites[tile_pos]
		if is_instance_valid(sprite):
			sprite.queue_free()
		_tile_sprites.erase(tile_pos)

func update_tiles_batch(tiles_to_add: Array, tiles_to_remove: Array[Vector2i]) -> void:
	# Remove old tiles
	for pos in tiles_to_remove:
		remove_tile(pos)

	# Add new tiles
	for tile in tiles_to_add:
		render_tile(tile)

func clear_all_tiles() -> void:
	for sprite in _tile_sprites.values():
		if is_instance_valid(sprite):
			sprite.queue_free()
	_tile_sprites.clear()

## Surface feature rendering ──────────────────────────────────────────────────

func render_surface_feature(position: Vector2i, feature_type: int, elevation: int, metadata: Dictionary = {}) -> void:
	# Similar to tiles, but stored separately for easy removal
	var sprite: Sprite3D
	if _feature_sprites.has(position):
		sprite = _feature_sprites[position]
	else:
		sprite = Sprite3D.new()
		sprite.billboard = BaseMaterial3D.BILLBOARD_DISABLED
		sprite.pixel_size = 0.01
		sprite.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST

		# Trees render above terrain (Y offset)
		sprite.offset = Vector3(0, 0.5, 0)  # Lift trees up slightly

		_world.add_child(sprite)
		_feature_sprites[position] = sprite

	# Position in 3D world
	var world_pos = _tile_to_world_3d(position, elevation)
	sprite.position = world_pos

	# TODO: Load texture for feature type
	# sprite.texture = get_feature_texture(feature_type)

	# Apply brightness and metadata
	var brightness = metadata.get("brightness", 1.0)
	sprite.modulate = Color(brightness, brightness, brightness, 1.0)

func remove_surface_feature(position: Vector2i) -> void:
	if _feature_sprites.has(position):
		var sprite = _feature_sprites[position]
		if is_instance_valid(sprite):
			sprite.queue_free()
		_feature_sprites.erase(position)

## Camera and viewport ────────────────────────────────────────────────────────

func get_camera() -> Node:
	return _camera

func set_camera_position(world_pos: Vector2) -> void:
	if _camera:
		# Convert 2D world position to 3D camera position
		# Maintain isometric angle, just translate X/Z
		var offset = world_pos - Vector2.ZERO
		_camera.position = Vector3(20 + offset.x, 20, 20 + offset.y)
		_camera.look_at(Vector3(offset.x, 0, offset.y), Vector3.UP)

func set_camera_zoom(zoom: float) -> void:
	if _camera:
		# Orthogonal camera: zoom = size (smaller = more zoomed in)
		_camera.size = 30.0 / zoom

func get_world_bounds() -> Rect2:
	# Calculate bounds from rendered tiles
	if _tile_sprites.is_empty():
		return Rect2(0, 0, 64, 64)

	var min_x = INF
	var min_z = INF
	var max_x = -INF
	var max_z = -INF

	for pos in _tile_sprites.keys():
		min_x = min(min_x, pos.x)
		min_z = min(min_z, pos.y)
		max_x = max(max_x, pos.x)
		max_z = max(max_z, pos.y)

	return Rect2(min_x, min_z, max_x - min_x + 1, max_z - min_z + 1)

## Input handling ─────────────────────────────────────────────────────────────

func screen_to_tile(screen_pos: Vector2) -> Variant:  # Vector2i or null
	# 3D picking: raycast from camera through screen position
	if not _camera or not _viewport:
		return null

	# Project ray from camera
	var from = _camera.project_ray_origin(screen_pos)
	var direction = _camera.project_ray_normal(screen_pos)

	# Raycast against tile sprites (simplified - real version would use physics layers)
	# For now, intersect with XZ plane at various Y heights
	var closest_tile = null
	var closest_distance = INF

	for pos_key in _tile_sprites.keys():
		var sprite = _tile_sprites[pos_key]
		var distance = _ray_to_point_distance(from, direction, sprite.global_position)

		if distance < 0.5 and distance < closest_distance:  # Within 0.5 units
			closest_distance = distance
			closest_tile = pos_key

	return closest_tile

func tile_to_world(tile_pos: Vector2i) -> Vector2:
	# Convert 3D world position back to 2D (for interface compatibility)
	var world_3d = _tile_to_world_3d(tile_pos, 0)
	return Vector2(world_3d.x, world_3d.z)

func _tile_to_world_3d(tile_pos: Vector2i, elevation: int) -> Vector3:
	# Simple grid layout in 3D space
	# X = tile.x, Z = tile.y, Y = elevation
	return Vector3(
		tile_pos.x * 1.0,  # 1 unit per tile in X
		elevation * 0.25,   # 0.25 units per elevation layer
		tile_pos.y * 1.0   # 1 unit per tile in Z
	)

func _ray_to_point_distance(ray_origin: Vector3, ray_direction: Vector3, point: Vector3) -> float:
	# Calculate shortest distance from ray to point
	var to_point = point - ray_origin
	var projection = to_point.dot(ray_direction)
	var closest_on_ray = ray_origin + ray_direction * projection
	return closest_on_ray.distance_to(point)

## Visual effects ─────────────────────────────────────────────────────────────

func apply_theme(theme_name: String) -> void:
	# TODO: Apply shader-based theme to all sprites
	# 3D version could use actual materials instead of palette swap
	pass

func set_time_of_day(time_normalized: float) -> void:
	# Rotate directional light for day/night cycle
	var sun = _world.get_node_or_null("Sun")
	if sun and sun is DirectionalLight3D:
		# Rotate sun from -90° (midnight) to +90° (noon) to -90° (midnight)
		var angle = (time_normalized - 0.5) * PI  # -90° to +90°
		sun.rotation_degrees.x = rad_to_deg(angle)

		# Dim light at night
		var brightness = abs(cos(angle))  # 0 at midnight, 1 at noon
		sun.light_energy = 0.3 + brightness * 0.7  # 0.3 to 1.0

## Renderer capabilities ──────────────────────────────────────────────────────

func get_capabilities() -> Dictionary:
	return {
		"supports_rotation": true,        # Can rotate camera 360°!
		"supports_tilt": true,            # Can adjust viewing angle!
		"supports_dynamic_lighting": true,  # Real-time shadows!
		"supports_3d_structures": true,   # Can mix 3D models!
		"pixel_perfect": true,            # Via TEXTURE_FILTER_NEAREST
		"max_elevation_layers": 16,
		"performance_tier": "medium",     # Slower than 2D but manageable
	}

func get_renderer_name() -> String:
	return "Orthogonal 3D (Isometric)"
