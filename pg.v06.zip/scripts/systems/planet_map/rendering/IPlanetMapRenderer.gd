class_name IPlanetMapRenderer
extends RefCounted

## Abstract interface for planet map renderers
## Implementations can use 2D TileMaps, 3D meshes, or any other approach
##
## This enables renderer-agnostic game logic - the ecosystem, terrain generation,
## and gameplay systems don't need to know HOW the map is being rendered.
##
## Example implementations:
## - PlanetMapRenderer2D (current TileMap-based)
## - PlanetMapRenderer3D (future orthogonal 3D)
## - PlanetMapRendererMinimap (simplified 2D overview)
## - PlanetMapRendererVR (first-person 3D exploration)

## Renderer lifecycle ─────────────────────────────────────────────────────────

## Initialize the renderer with a parent node and viewport
func initialize(parent: Node, viewport: SubViewport) -> void:
	push_error("IPlanetMapRenderer.initialize() must be implemented")

## Clean up all rendering resources
func cleanup() -> void:
	push_error("IPlanetMapRenderer.cleanup() must be implemented")

## Tile rendering ─────────────────────────────────────────────────────────────

## Render a single tile at the specified position
## tile_data: MapTile containing type, elevation, position
func render_tile(tile_data) -> void:  # MapTile type
	push_error("IPlanetMapRenderer.render_tile() must be implemented")

## Remove rendering for a tile at the specified position
func remove_tile(tile_pos: Vector2i) -> void:
	push_error("IPlanetMapRenderer.remove_tile() must be implemented")

## Update multiple tiles efficiently (batched rendering)
## tiles_to_add: Array of MapTile objects to render
## tiles_to_remove: Array of Vector2i positions to clear
func update_tiles_batch(tiles_to_add: Array, tiles_to_remove: Array[Vector2i]) -> void:
	push_error("IPlanetMapRenderer.update_tiles_batch() must be implemented")

## Clear all rendered tiles
func clear_all_tiles() -> void:
	push_error("IPlanetMapRenderer.clear_all_tiles() must be implemented")

## Surface feature rendering ──────────────────────────────────────────────────

## Render a surface feature (tree, structure, ground cover)
## position: Tile position (Vector2i)
## feature_type: TileType enum value
## elevation: Height layer (0-15)
## metadata: Optional Dictionary with variant, brightness, offset, etc.
func render_surface_feature(position: Vector2i, feature_type: int, elevation: int, metadata: Dictionary = {}) -> void:
	push_error("IPlanetMapRenderer.render_surface_feature() must be implemented")

## Remove surface feature rendering at position
func remove_surface_feature(position: Vector2i) -> void:
	push_error("IPlanetMapRenderer.remove_surface_feature() must be implemented")

## Camera and viewport ────────────────────────────────────────────────────────

## Get the camera node (Camera2D or Camera3D depending on implementation)
func get_camera() -> Node:
	push_error("IPlanetMapRenderer.get_camera() must be implemented")
	return null

## Set camera position in world coordinates
func set_camera_position(world_pos: Vector2) -> void:
	push_error("IPlanetMapRenderer.set_camera_position() must be implemented")

## Set camera zoom level (implementation-specific scale)
func set_camera_zoom(zoom: float) -> void:
	push_error("IPlanetMapRenderer.set_camera_zoom() must be implemented")

## Get world bounds of the rendered map (for camera clamping)
func get_world_bounds() -> Rect2:
	push_error("IPlanetMapRenderer.get_world_bounds() must be implemented")
	return Rect2()

## Input handling ─────────────────────────────────────────────────────────────

## Convert screen position to tile coordinates
## Returns Vector2i tile position or null if outside map
func screen_to_tile(screen_pos: Vector2) -> Variant:  # Vector2i or null
	push_error("IPlanetMapRenderer.screen_to_tile() must be implemented")
	return null

## Convert tile coordinates to world position (for camera movement, etc.)
func tile_to_world(tile_pos: Vector2i) -> Vector2:
	push_error("IPlanetMapRenderer.tile_to_world() must be implemented")
	return Vector2.ZERO

## Visual effects ─────────────────────────────────────────────────────────────

## Apply theme/variant system to all rendered elements
func apply_theme(theme_name: String) -> void:
	push_error("IPlanetMapRenderer.apply_theme() must be implemented")

## Set time-of-day lighting (0.0 = midnight, 0.5 = noon, 1.0 = midnight again)
func set_time_of_day(time_normalized: float) -> void:
	push_error("IPlanetMapRenderer.set_time_of_day() must be implemented")

## Renderer capabilities ──────────────────────────────────────────────────────

## Query what rendering features this implementation supports
func get_capabilities() -> Dictionary:
	return {
		"supports_rotation": false,      # Can camera rotate 360°?
		"supports_tilt": false,          # Can camera tilt viewing angle?
		"supports_dynamic_lighting": false,  # Real-time shadows/lighting?
		"supports_3d_structures": false, # Can render actual 3D geometry?
		"pixel_perfect": true,           # Maintains pixel-perfect rendering?
		"max_elevation_layers": 16,      # How many elevation layers?
	}

## Get human-readable renderer name
func get_renderer_name() -> String:
	return "BaseRenderer"
