class_name PlanetMapGenerator
extends RefCounted

const LOG_TAG := "PLANET_MAP_GEN"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


# Detailed Planet Map Generation System
# Generates scientifically-based surface maps using your existing planet data

# Map generation parameters
const MAP_SIZE = Vector2i(64, 64)  # 64x64 for large detailed maps
const MAX_ELEVATION = 7  # Maximum elevation layers for planet maps (0-7)

# Elevation pattern types (matching sandbox patterns)
enum ElevationPattern {
	FLAT,       # All tiles at elevation 0
	RANDOM,     # Random elevation per tile
	NOISE,      # Perlin-like noise terrain
	HILLS,      # Smooth rolling hills
	MOUNTAIN,   # Peak in center
	CRATER,     # Depression in center
	ISLAND,     # High center with low edges
	RIDGES      # Mountain ridge patterns
}

# Noise generation for terrain
var heightmap_noise: FastNoiseLite
var temperature_noise: FastNoiseLite
var moisture_noise: FastNoiseLite
var geological_noise: FastNoiseLite

# Planet data input
var planet_data: Dictionary
var surface_liquids: Dictionary
var surface_composition: Dictionary
var _map_seed: int = -1
var geological_activity: String
var climate_type: String
var atmosphere_type: String
var surface_temperature: float
var tectonic_plates: int
var magnetosphere: String
var moons: Array

func _init():
	_setup_noise_generators()

func _setup_noise_generators():
	# Heightmap - creates mountain ranges and valleys
	heightmap_noise = FastNoiseLite.new()
	heightmap_noise.noise_type = FastNoiseLite.TYPE_PERLIN
	heightmap_noise.frequency = 0.1
	heightmap_noise.fractal_octaves = 4
	heightmap_noise.fractal_gain = 0.5
	
	# Temperature variation - affects local climate
	temperature_noise = FastNoiseLite.new()
	temperature_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
	temperature_noise.frequency = 0.05
	temperature_noise.fractal_octaves = 2
	
	# Moisture patterns - affects vegetation and liquid distribution
	moisture_noise = FastNoiseLite.new()
	moisture_noise.noise_type = FastNoiseLite.TYPE_CELLULAR
	moisture_noise.frequency = 0.08
	moisture_noise.cellular_return_type = FastNoiseLite.RETURN_CELL_VALUE
	
	# Geological features - fault lines, volcanic regions
	geological_noise = FastNoiseLite.new()
	geological_noise.noise_type = FastNoiseLite.TYPE_PERLIN  # Changed from TYPE_RIDGED
	geological_noise.frequency = 0.15
	geological_noise.fractal_octaves = 3

func _extract_planet_data(planet: Planet, probe_data: Dictionary):
	# Extract all relevant data from planet and probe results
	surface_liquids = probe_data.get("surface_liquids", {})
	surface_composition = probe_data.get("surface_composition", {})
	geological_activity = probe_data.get("geological_activity", "MODERATE")
	climate_type = probe_data.get("climate_type", "TEMPERATE")
	atmosphere_type = probe_data.get("atmosphere_type", "MODERATE")
	surface_temperature = probe_data.get("surface_temperature", 273.0)
	tectonic_plates = probe_data.get("tectonic_plates", 5)
	magnetosphere = probe_data.get("magnetosphere", "MODERATE")
	moons = probe_data.get("moons", [])
	
	# Store planet type and habitability data
	planet_data = {
		"planet_type": planet.planet_type,
		"habitability_score": planet.habitability_score,
		"atmosphere_composition": probe_data.get("atmosphere_composition", {}),
		"surface_liquids": surface_liquids,
		"surface_composition": surface_composition
	}

func generate_map(planet: Planet, probe_data: Dictionary, map_seed: int = -1) -> Array:
	_log_debug('=== PLANET MAP GENERATOR START ===')

	_map_seed = map_seed
	_extract_planet_data(planet, probe_data)
	_configure_noise_for_planet()

	var map_tiles = _initialize_tile_array()
	if map_tiles.is_empty():
		_log_error('ERROR: Tile initialization failed')
		return []

	_log_info('Generating flat terrain map (%sx%s)', [MAP_SIZE.x, MAP_SIZE.y])

	_apply_flat_layout(map_tiles)
	_populate_moisture_levels(map_tiles)
	_add_surface_features(map_tiles)
	_log_debug('=== PLANET MAP GENERATOR COMPLETE ===')
	return map_tiles

## Returns initial TreeInstance array for ecosystem simulation.
## Call after generate_map() with the same tile array.
func extract_initial_trees(map_tiles: Array) -> Array[TreeInstance]:
	var trees: Array[TreeInstance] = []
	for x in range(MAP_SIZE.x):
		if x >= map_tiles.size():
			continue
		var row = map_tiles[x]
		if row == null:
			continue
		for y in range(MAP_SIZE.y):
			if y >= row.size():
				continue
			var tile = row[y]
			if tile == null or not tile is MapTile:
				continue
			if tile.surface_feature_type != null:
				var tree = TreeInstance.new()
				tree.position = Vector2i(x, y)
				tree.species = tile.surface_feature_type
				# Initial trees from map generation start at MATURE stage
				# Age and thresholds will be initialized by EcosystemManager.register_planet()
				tree.growth_stage = TreeInstance.GrowthStage.MATURE
				tree.age_in_ticks = 0  # Will be set to mature threshold after initialization
				tree.health = 1.0
				trees.append(tree)
	_log_info('Extracted %d initial trees for ecosystem', [trees.size()])
	return trees

func _configure_noise_for_planet():
	# Adapt noise parameters based on planet characteristics
	var planet_seed = _map_seed if _map_seed != -1 else abs(hash(str(planet_data)))
	
	heightmap_noise.seed = planet_seed
	temperature_noise.seed = planet_seed + 1
	moisture_noise.seed = planet_seed + 2
	geological_noise.seed = planet_seed + 3
	
	# Adjust frequency based on geological activity
	match geological_activity:
		"EXTREME":
			heightmap_noise.frequency = 0.15  # More chaotic terrain
			geological_noise.frequency = 0.25
		"HIGH":
			heightmap_noise.frequency = 0.12
			geological_noise.frequency = 0.20
		"MODERATE":
			heightmap_noise.frequency = 0.10
			geological_noise.frequency = 0.15
		"LOW":
			heightmap_noise.frequency = 0.08
			geological_noise.frequency = 0.10
		"NONE":
			heightmap_noise.frequency = 0.05  # Smooth, ancient terrain
			geological_noise.frequency = 0.05

func _initialize_tile_array() -> Array:
	_log_debug('Creating 2D tile array: %sx%s', [MAP_SIZE.x, MAP_SIZE.y])

	var tiles = []
	tiles.resize(MAP_SIZE.x)

	var total_tiles_created = 0

	for x in range(MAP_SIZE.x):
		tiles[x] = []
		tiles[x].resize(MAP_SIZE.y)

		for y in range(MAP_SIZE.y):
			var new_tile = MapTile.new(Vector2i(x, y))
			if new_tile == null:
				_log_error('ERROR: Failed to create MapTile at [%s][%s]', [x, y])
				return []

			tiles[x][y] = new_tile
			total_tiles_created += 1

	_log_debug('Tile array initialized: %s tiles', [total_tiles_created])

	return tiles

func _apply_flat_layout(tiles: Array):
	# Generate terrain with elevation patterns based on planet type
	if tiles.is_empty():
		_log_error('Error: tiles array is empty in _apply_flat_layout')
		return

	var composition_template: Dictionary = {}
	if surface_composition and not surface_composition.is_empty():
		composition_template = surface_composition.duplicate(true)

	var default_temperature = 0.0
	if surface_temperature != null:
		default_temperature = surface_temperature

	# Determine the primary tile type based on planet characteristics
	var primary_tile_type = _determine_primary_tile_type()

	# Generate elevation map
	var elevation_map: Dictionary = _generate_elevation_map()

	for x in range(MAP_SIZE.x):
		for y in range(MAP_SIZE.y):
			var tile: MapTile = tiles[x][y]
			if tile == null:
				_log_warn('Null tile at [%s][%s] during flat layout', [x, y])
				continue

			# Get base elevation from map
			var cell := Vector2i(x, y)
			var base_elevation = elevation_map.get(cell, 0)

			tile.special_features.clear()
			tile.temperature = default_temperature
			if composition_template.is_empty():
				tile.composition = {}
			else:
				tile.composition = composition_template.duplicate(true)

			# Simple assignment: use primary tile type and elevation
			tile.type = primary_tile_type
			tile.elevation = base_elevation
			tile.discovered = true
			tiles[x][y] = tile

func _add_surface_features(tiles: Array):
	"""
	Add surface features (trees, vegetation, structures) to the planet map.
	Surface features are placed on a separate layer and don't affect elevation.
	"""
	if tiles.is_empty():
		_log_error('Error: tiles array is empty in _add_surface_features')
		return

	# Create RNG with planet seed for consistent results
	var rng = RandomNumberGenerator.new()
	var feature_seed = _map_seed if _map_seed != -1 else abs(hash(str(planet_data))) + 100
	rng.seed = feature_seed

	# Check if this planet should have trees (habitable planets with grass)
	var hab_score = planet_data.get("habitability_score", 0.0)
	var has_vegetation = hab_score > 0.5  # Only habitable planets (>50%) get trees

	if not has_vegetation:
		_log_info('Planet not habitable enough for vegetation (habitability: %.1f%%)', [hab_score * 100])
		return

	# Adjust density based on habitability - highly habitable planets are more lush
	var tree_density = 0.08  # Base 8% for moderately habitable planets
	var _undergrowth_density = 0.0  # Disabled for now (only trees)

	if hab_score >= 0.7:
		# Highly habitable planets (AI discovery threshold) are significantly more lush
		tree_density = 0.15  # 15% tree coverage
		_log_info('Highly habitable planet - using lush vegetation density')

	var tree_count = 0
	var _undergrowth_count = 0

	# Available tree types for initial generation
	# Use ALL vegetative tree sizes for visual variety
	# All generated trees start at MATURE stage in the lifecycle
	# The ecosystem will handle aging them to OLD (DORM) and spreading new SEEDLINGS
	var tree_types = MapleTreeTypes.ALL_VEGETATIVE

	# Undergrowth disabled (trees only)
	var _undergrowth_types = []

	_log_info('Adding surface features to planet map (habitability: %.1f%%)...', [hab_score * 100])

	var grass_tiles = 0

	# Edge margin removed - allow surface features on all tiles (including edges)
	# With 1/4-height grass tiles, visual overlap is no longer an issue
	const EDGE_MARGIN = 0  # No margin - full map coverage

	for x in range(MAP_SIZE.x):
		for y in range(MAP_SIZE.y):
			var tile: MapTile = tiles[x][y]
			if tile == null:
				continue

			# Check if tile is within safe bounds (not too close to edges)
			var is_near_edge = (x < EDGE_MARGIN or x >= MAP_SIZE.x - EDGE_MARGIN or
								 y < EDGE_MARGIN or y >= MAP_SIZE.y - EDGE_MARGIN)

			# Only place vegetation on grass/land tiles that aren't near edges
			if (tile.type == PlanetMapTileConfig.TileType.GRASS_0 or \
				tile.type == PlanetMapTileConfig.TileType.GRASS_1 or \
				tile.type == PlanetMapTileConfig.TileType.GRASS_2) and not is_near_edge:

				grass_tiles += 1

				# Try to place a tree
				if rng.randf() < tree_density:
					# Randomly select from maple tree types for variety
					var tree_type = tree_types[rng.randi_range(0, tree_types.size() - 1)]
					tile.surface_feature_type = tree_type
					tree_count += 1

	_log_info('Surface feature generation complete:')
	_log_info('  - Trees placed: %d (%.1f%% of grass tiles)', [tree_count, (float(tree_count) / grass_tiles * 100.0) if grass_tiles > 0 else 0.0])

func _populate_moisture_levels(tiles: Array) -> void:
	"""Sample moisture noise into each tile's moisture_level property."""
	for x in range(MAP_SIZE.x):
		if x >= tiles.size():
			continue
		var row = tiles[x]
		if row == null:
			continue
		for y in range(MAP_SIZE.y):
			if y >= row.size():
				continue
			var tile: MapTile = row[y]
			if tile == null:
				continue
			# moisture_noise returns -1..1; remap to 0..1
			var raw = moisture_noise.get_noise_2d(float(x), float(y))
			tile.moisture_level = clamp((raw + 1.0) * 0.5, 0.0, 1.0)

func _determine_primary_tile_type() -> PlanetMapTileConfig.TileType:
	"""
	Determines the primary tile type based on planet characteristics.
	Returns appropriate tile type for gas planets, liquid surfaces, rocky planets, and habitable worlds.
	"""

	# Get planet type from the planet data
	var current_planet_type = planet_data.get("planet_type", -1)

	# Check for gas giants and ice giants
	if current_planet_type == PlanetEnums.PlanetType.ICE_GIANT:
		_log_info('Ice giant detected, using ice tiles')
		return PlanetMapTileConfig.TileType.ICE

	if (current_planet_type == PlanetEnums.PlanetType.GAS_GIANT or
		current_planet_type == PlanetEnums.PlanetType.SUPER_JUPITER):
		_log_info('Gas planet detected, using ocean tiles for gas representation')
		return PlanetMapTileConfig.TileType.FRESH_WATER

	# Check habitability for grass tiles FIRST
	var hab_score = planet_data.get("habitability_score", 0.0)

	# PRIORITY: Highly habitable planets always use grass
	# This represents focusing on the most advantageous, habitable locations on the planet
	if hab_score >= 0.7:
		_log_info('Highly habitable planet detected (habitability: %.2f), focusing on advantageous grass-covered regions',
			[hab_score])
		return PlanetMapTileConfig.TileType.GRASS_0

	# Get liquid coverage data for non-habitable planet classification
	var ice_coverage = surface_liquids.get("ice", 0.0)
	var lava_coverage = surface_liquids.get("lava", 0.0)
	var water_coverage = surface_liquids.get("water", 0.0)
	var total_liquid_coverage = water_coverage + ice_coverage + lava_coverage

	# Check for predominantly liquid surfaces (water worlds without life)
	# This now only catches non-habitable water worlds
	if total_liquid_coverage > 0.6:
		if ice_coverage > water_coverage and ice_coverage > lava_coverage:
			_log_info('Ice-dominated surface detected (%.1f%% ice), using ice tiles', [ice_coverage * 100])
			return PlanetMapTileConfig.TileType.ICE  # Ice-dominated
		elif lava_coverage > 0.3:
			_log_info('Lava-dominated surface detected (%.1f%% lava), using ocean tiles', [lava_coverage * 100])
			return PlanetMapTileConfig.TileType.FRESH_WATER  # Lava world
		else:
			_log_info('Water-dominated surface detected (%.1f%% water), using ocean tiles', [water_coverage * 100])
			return PlanetMapTileConfig.TileType.FRESH_WATER  # Water world
	
	# Check for specific rocky planet types
	match current_planet_type:
		PlanetEnums.PlanetType.ROCKY_SMALL:
			# Small rocky planets are usually barren
			_log_info('Small rocky planet, using rock tiles')
			return PlanetMapTileConfig.TileType.STONE_0
			
		PlanetEnums.PlanetType.ROCKY_MEDIUM:
			# Medium rocky planets could be habitable or barren
			if hab_score > 0.3:
				_log_info('Medium rocky planet with decent habitability, using plains tiles')
				return PlanetMapTileConfig.TileType.STONE_0
			else:
				_log_info('Medium rocky planet, low habitability, using rock tiles')
				return PlanetMapTileConfig.TileType.STONE_0
				
		PlanetEnums.PlanetType.SUPER_EARTH:
			# Super-earths are often rocky but could support life
			if hab_score > 0.4:
				_log_info('Super-Earth with good habitability, using highlands tiles')
				return PlanetMapTileConfig.TileType.STONE_0
			else:
				_log_info('Super-Earth, using mountain tiles')
				return PlanetMapTileConfig.TileType.STONE_0
	
	# Check surface composition for final fallback
	var rock_content = surface_composition.get("rock", 0.0)
	var gas_content = surface_composition.get("gas", 0.0)
	
	if gas_content > 0.5:
		_log_info('Gas-dominated composition, using ocean tiles')
		return PlanetMapTileConfig.TileType.FRESH_WATER
	elif rock_content > 0.7:
		_log_info('Rock-dominated composition, using stone tiles')
		return PlanetMapTileConfig.TileType.STONE_0
	
	# Default fallback to stone for rocky worlds
	_log_info('Default case: using stone tiles')
	return PlanetMapTileConfig.TileType.STONE_0

# ============================================================================
# ELEVATION PATTERN GENERATION
# ============================================================================

func _determine_elevation_pattern() -> ElevationPattern:
	"""Determine appropriate elevation pattern based on planet type and geological activity"""
	var current_planet_type = planet_data.get("planet_type", -1)

	# Gas giants have no solid surface - always flat
	if (current_planet_type == PlanetEnums.PlanetType.GAS_GIANT or
		current_planet_type == PlanetEnums.PlanetType.ICE_GIANT or
		current_planet_type == PlanetEnums.PlanetType.SUPER_JUPITER):
		return ElevationPattern.FLAT

	# Base pattern by planet type
	var base_pattern: ElevationPattern

	match current_planet_type:
		PlanetEnums.PlanetType.ROCKY_SMALL:
			# Mercury-like - cratered dead worlds
			base_pattern = ElevationPattern.CRATER

		PlanetEnums.PlanetType.ROCKY_MEDIUM:
			# Earth-like - realistic varied terrain
			base_pattern = ElevationPattern.NOISE

		PlanetEnums.PlanetType.SUPER_EARTH:
			# Massive terrain features
			base_pattern = ElevationPattern.MOUNTAIN

		_:
			base_pattern = ElevationPattern.NOISE

	# Modify based on geological activity
	match geological_activity:
		"EXTREME":
			# Extreme volcanic activity - use ridges or mountains
			if randf() < 0.5:
				return ElevationPattern.RIDGES
			else:
				return ElevationPattern.MOUNTAIN

		"HIGH":
			# High activity - mountains or hills
			if base_pattern == ElevationPattern.CRATER:
				return ElevationPattern.HILLS  # Override crater for active planets
			return base_pattern

		"DEAD", "NONE":
			# Dead worlds - craters or flat
			if current_planet_type == PlanetEnums.PlanetType.ROCKY_SMALL:
				return ElevationPattern.CRATER
			else:
				return ElevationPattern.HILLS  # Smooth, worn terrain

		_:
			return base_pattern

func _calculate_elevation_for_cell(cell: Vector2i, pattern: ElevationPattern, max_height: int) -> int:
	"""Calculate elevation for a single cell based on pattern type"""
	var elevation: int = 0

	# Normalized coordinates (0.0 to 1.0)
	var nx: float = float(cell.x) / float(max(MAP_SIZE.x - 1, 1))
	var ny: float = float(cell.y) / float(max(MAP_SIZE.y - 1, 1))

	# Centered coordinates (-0.5 to 0.5)
	var cx: float = nx - 0.5
	var cy: float = ny - 0.5

	match pattern:
		ElevationPattern.FLAT:
			elevation = 0

		ElevationPattern.RANDOM:
			elevation = randi_range(0, max_height)

		ElevationPattern.NOISE:
			# Use proper Perlin noise for realistic Earth-like terrain
			elevation = _generate_earth_like_elevation(cell, max_height)

		ElevationPattern.HILLS:
			# Smooth rolling hills
			var hill_value: float = sin(nx * PI * 3.0) * cos(ny * PI * 2.5)
			hill_value = (hill_value + 1.0) * 0.5  # Normalize to 0-1
			elevation = int(hill_value * float(max_height))

		ElevationPattern.MOUNTAIN:
			# Peak in center, falls off with distance
			var dist: float = sqrt(cx * cx + cy * cy)
			var mountain_value: float = 1.0 - (dist / 0.707)  # 0.707 is max dist to corner
			mountain_value = clamp(mountain_value, 0.0, 1.0)
			elevation = int(mountain_value * float(max_height))

		ElevationPattern.CRATER:
			# Depression in center
			var dist: float = sqrt(cx * cx + cy * cy)
			var crater_value: float = dist / 0.707
			crater_value = clamp(crater_value, 0.0, 1.0)
			elevation = int(crater_value * float(max_height))

		ElevationPattern.ISLAND:
			# High center with low edges (more dramatic than mountain)
			var dist: float = sqrt(cx * cx + cy * cy)
			var island_value: float = 1.0 - (dist / 0.5)  # Falls off faster
			island_value = clamp(island_value, 0.0, 1.0)
			island_value = pow(island_value, 1.5)  # Make it steeper
			elevation = int(island_value * float(max_height))

		ElevationPattern.RIDGES:
			# Mountain ridges using absolute sine waves
			var ridge_value: float = abs(sin(nx * PI * 6.0 + ny * PI * 2.0))
			ridge_value = pow(ridge_value, 0.7)  # Make ridges sharper
			elevation = int(ridge_value * float(max_height))

	return clampi(elevation, 0, MAX_ELEVATION)

func _generate_earth_like_elevation(cell: Vector2i, max_height: int) -> int:
	"""
	Generate realistic Earth-like terrain using multiple layers of noise.
	Creates continents, mountain ranges, plains, and varied coastlines.
	"""
	var x = float(cell.x)
	var y = float(cell.y)

	# Layer 1: Continental shapes (large-scale features)
	# Low frequency for big landmasses
	var continental = heightmap_noise.get_noise_2d(x * 0.5, y * 0.5)

	# Layer 2: Regional terrain variation (medium-scale)
	# Medium frequency for hills and valleys
	var regional = heightmap_noise.get_noise_2d(x * 2.0, y * 2.0) * 0.5

	# Layer 3: Local detail (small-scale features)
	# High frequency for fine detail
	var local_detail = heightmap_noise.get_noise_2d(x * 6.0, y * 6.0) * 0.25

	# Layer 4: Mountain ranges using geological noise
	# Creates ridge-like features for mountain ranges
	var mountains = geological_noise.get_noise_2d(x * 1.5, y * 1.5)
	# Only add mountains where terrain is already elevated
	var mountain_mask = max(0.0, continental + regional)
	mountains = abs(mountains) * mountain_mask * 0.3

	# Combine all layers with weighted influence
	var combined = continental + regional + local_detail + mountains

	# Normalize properly for balanced distribution
	# Range is approximately -1.75 to 2.3, so normalize to 0-1
	combined = (combined + 2.0) / 4.0
	combined = clamp(combined, 0.0, 1.0)

	# Apply a subtle power curve to create slightly more dramatic high terrain
	# Values > 0.5 get amplified slightly, values < 0.5 get compressed slightly
	# This creates more varied terrain without skewing the distribution too much
	if combined > 0.5:
		# Highlands - make them slightly more dramatic
		combined = 0.5 + pow((combined - 0.5) * 2.0, 1.1) * 0.5
	else:
		# Lowlands - keep more linear
		combined = combined

	var elevation = int(combined * float(max_height))
	return clampi(elevation, 0, MAX_ELEVATION)

func _generate_elevation_map() -> Dictionary:
	"""Generate elevation values for all map cells"""

	# Try to use PNG heightmap for habitable planets
	var hab_score = planet_data.get("habitability_score", 0.0)
	if hab_score >= 0.7 and TerrainRegionSelector.png_exists():
		var png_result = _try_load_png_terrain()
		if png_result.success:
			return png_result.elevation_map
		# Fall through to procedural generation on failure
		_log_warn('PNG terrain loading failed, falling back to procedural generation')

	var pattern: ElevationPattern = _determine_elevation_pattern()
	var max_height: int = MAX_ELEVATION

	# Reduce elevation range for low geological activity
	match geological_activity:
		"DEAD", "NONE":
				max_height = MAX_ELEVATION >> 1
		"LOW":
			max_height = int(MAX_ELEVATION * 0.7)

	_log_info('Generating elevation pattern: %s with max height %d', [ElevationPattern.keys()[pattern], max_height])

	var elevation_map: Dictionary = {}
	var min_elev = 999
	var max_elev = -1

	for x in range(MAP_SIZE.x):
		for y in range(MAP_SIZE.y):
			var cell := Vector2i(x, y)
			var elevation := _calculate_elevation_for_cell(cell, pattern, max_height)
			elevation_map[cell] = elevation
			min_elev = min(min_elev, elevation)
			max_elev = max(max_elev, elevation)

	# Normalize integer elevations to 0.0-1.0 range for MapTile.elevation
	# This matches the format from PNGTerrainLoader
	for pos in elevation_map.keys():
		var int_elev = elevation_map[pos]
		elevation_map[pos] = float(int_elev) / float(MAX_ELEVATION) if MAX_ELEVATION > 0 else 0.0

	_log_info('Elevation map generated: min=%d, max=%d, cells=%d (normalized to 0.0-1.0)', [min_elev, max_elev, elevation_map.size()])

	return elevation_map

func _try_load_png_terrain() -> Dictionary:
	"""
	Load terrain from PNG heightmap for habitable planets.
	Uses pre-calculated global stats for fast region loading with consistent remapping.
	Returns a result dictionary with success flag and elevation_map.
	"""
	# Get region for this planet's seed
	var region_data = TerrainRegionSelector.get_region_for_seed(_map_seed)
	var region_info = TerrainRegionSelector.get_region_info(_map_seed)
	var region_bounds = region_data["bounds"]

	_log_info('Loading PNG terrain for habitable planet: %s', [region_info])

	# Load pre-calculated global statistics for consistent remapping
	var global_stats = _load_terrain_metadata()
	if global_stats.is_empty():
		_log_warn('No terrain metadata found, falling back to full PNG load')
		return _try_load_png_terrain_full()

	# OPTIMIZED: Load only the 64x64 region we need
	var loader = PNGTerrainLoader.new()
	var png_path = TerrainRegionSelector.get_png_path()

	_log_info('Loading region with pre-calculated global stats (fast path)...')
	# Skip automatic remapping - we'll apply global remapping manually
	var result = loader.load_png(png_path, 1, region_bounds, true)

	if not result.success:
		_log_error('Failed to load PNG region: %s', [result.error])
		return {"success": false, "elevation_map": {}}

	# Apply global remapping to region using pre-calculated stats
	var remap_min = global_stats.get("percentile_min", 0.0)
	var remap_max = global_stats.get("percentile_max", 1.0)

	_log_info('Applying global remapping: [%.4f - %.4f]', [remap_min, remap_max])

	for pos in result.elevation_map.keys():
		var raw_elev = result.elevation_map[pos]
		result.elevation_map[pos] = PlanetMapTileConfig.remap_elevation(raw_elev, remap_min, remap_max)

	_log_info('Region loaded: %dx%d tiles with global remapping', [result.grid_size.x, result.grid_size.y])

	return {
		"success": true,
		"elevation_map": result.elevation_map
	}

func _load_terrain_metadata() -> Dictionary:
	"""Load pre-calculated global statistics from metadata file."""
	var metadata_path = "res://assets/terrain/terrain_metadata.json"

	if not FileAccess.file_exists(metadata_path):
		return {}

	var file = FileAccess.open(metadata_path, FileAccess.READ)
	if file == null:
		_log_warn('Failed to open terrain metadata file')
		return {}

	var json_text = file.get_as_text()
	file.close()

	var json = JSON.new()
	var parse_result = json.parse(json_text)

	if parse_result != OK:
		_log_error('Failed to parse terrain metadata JSON: %s', [json.get_error_message()])
		return {}

	return json.data

func _try_load_png_terrain_full() -> Dictionary:
	"""Fallback: Load full PNG when metadata not available (slow but works)."""
	var region_data = TerrainRegionSelector.get_region_for_seed(_map_seed)
	var region_offset = region_data["pixel_offset"]

	var loader = PNGTerrainLoader.new()
	var png_path = TerrainRegionSelector.get_png_path()

	_log_info('Loading full PNG for global remapping (slow fallback)...')
	var full_result = loader.load_png(png_path, 1, {})

	if not full_result.success:
		return {"success": false, "elevation_map": {}}

	# Extract region from full map
	var region_elevation_map: Dictionary = {}
	for local_y in range(MAP_SIZE.y):
		for local_x in range(MAP_SIZE.x):
			var global_pos = Vector2i(region_offset.x + local_x, region_offset.y + local_y)
			var local_pos = Vector2i(local_x, local_y)
			region_elevation_map[local_pos] = full_result.elevation_map.get(global_pos, 0.5)

	return {"success": true, "elevation_map": region_elevation_map}
