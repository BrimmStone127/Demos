class_name PlanetMapCoordinates
extends RefCounted

# Coordinate conversion utilities for the planet map system
# Handles conversions between grid coordinates and world/visual positions
# Can be reused by sandbox and other systems that need isometric coordinate conversions

# Round a Vector2 to integer values
static func round_vec2(value: Vector2) -> Vector2:
	return Vector2(round(value.x), round(value.y))

# Convert grid coordinates to world position (isometric)
static func grid_to_world(cell: Vector2i) -> Vector2:
	var world_x := (cell.x - cell.y) * PlanetMapTileConfig.TILE_OFFSET.x
	var world_y := (cell.x + cell.y) * PlanetMapTileConfig.TILE_OFFSET.y
	return Vector2(round(world_x), round(world_y))

# Get the center position of the map in world coordinates
static func get_map_center_world_position(map_size: Vector2i = PlanetMapTileConfig.MAP_SIZE) -> Vector2:
	var half_cols: float = float(max(map_size.x - 1, 0)) * 0.5
	var half_rows: float = float(max(map_size.y - 1, 0)) * 0.5
	var world_x: float = (half_cols - half_rows) * PlanetMapTileConfig.TILE_OFFSET.x
	var world_y: float = (half_cols + half_rows) * PlanetMapTileConfig.TILE_OFFSET.y
	return Vector2(world_x, world_y)

# Convert a world position to grid coordinates (inverse of grid_to_world)
static func world_to_grid(world_pos: Vector2) -> Vector2i:
	# Isometric inverse transformation
	var tile_x = (world_pos.x / PlanetMapTileConfig.TILE_OFFSET.x + world_pos.y / PlanetMapTileConfig.TILE_OFFSET.y) / 2.0
	var tile_y = (world_pos.y / PlanetMapTileConfig.TILE_OFFSET.y - world_pos.x / PlanetMapTileConfig.TILE_OFFSET.x) / 2.0
	return Vector2i(round(tile_x), round(tile_y))

# Get the visual world position for a tile at a specific elevation
static func get_tile_visual_position(cell: Vector2i, elevation: int) -> Vector2:
	var base_pos := grid_to_world(cell)
	base_pos.y -= elevation * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET
	return base_pos

# Get the visual world position using a TileMap's map_to_local (more accurate)
static func get_tile_visual_position_from_tilemap(tilemap: TileMap, cell: Vector2i, elevation: int) -> Vector2:
	var center := tilemap.map_to_local(cell)
	center.y -= elevation * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET
	return center

# Check if a grid position is within map bounds
# If map_size is not provided, uses the default PlanetMapTileConfig.MAP_SIZE
static func is_valid_grid_position(cell: Vector2i, map_size: Vector2i = Vector2i.ZERO) -> bool:
	var actual_size = map_size if map_size != Vector2i.ZERO else PlanetMapTileConfig.MAP_SIZE
	return cell.x >= 0 and cell.y >= 0 and cell.x < actual_size.x and cell.y < actual_size.y


# Get the world-space bounding rectangle for the map
# Useful for camera bounds and visibility calculations
static func get_map_world_bounds(map_size: Vector2i = PlanetMapTileConfig.MAP_SIZE) -> Rect2:
	# In isometric space, the map forms a diamond shape
	# The corners in grid space (0,0), (w-1,0), (0,h-1), (w-1,h-1) map to world space

	# Top corner (grid 0, 0)
	var top = grid_to_world(Vector2i(0, 0))

	# Right corner (grid w-1, 0)
	var right = grid_to_world(Vector2i(map_size.x - 1, 0))

	# Left corner (grid 0, h-1)
	var left = grid_to_world(Vector2i(0, map_size.y - 1))

	# Bottom corner (grid w-1, h-1)
	var bottom = grid_to_world(Vector2i(map_size.x - 1, map_size.y - 1))

	# Calculate bounding rectangle
	var min_x = min(top.x, min(right.x, min(left.x, bottom.x)))
	var max_x = max(top.x, max(right.x, max(left.x, bottom.x)))
	var min_y = min(top.y, min(right.y, min(left.y, bottom.y)))
	var max_y = max(top.y, max(right.y, max(left.y, bottom.y)))

	# Add tile size padding for visual extent
	min_x -= PlanetMapTileConfig.TILE_OFFSET.x
	max_x += PlanetMapTileConfig.TILE_OFFSET.x
	min_y -= PlanetMapTileConfig.TILE_OFFSET.y
	max_y += PlanetMapTileConfig.TILE_OFFSET.y

	return Rect2(min_x, min_y, max_x - min_x, max_y - min_y)

# Get the Y-sort value for a tile at a given position and elevation
# Used for proper depth sorting in isometric view
static func get_y_sort_value(cell: Vector2i, elevation: int) -> float:
	# Y-sort is based on the visual Y position (lower on screen = higher sort value)
	var visual_pos := get_tile_visual_position(cell, elevation)
	return visual_pos.y


# ── Reusable TileMap pick / draw helpers ─────────────────────────────────────
# Use these in minigames and one-off maps instead of reimplementing the
# coordinate chain.

## Convert a viewport click to a tilemap cell.
## viewport_point: position in SubViewport pixel space (e.g. from SVC gui_input).
## viewport:       the SubViewport the tilemap lives in.
## tilemap:        the TileMap node to pick against.
## visual_offset:  per-tile-type shift from map_to_local() to visual center.
##                 Default ZERO works for slab/grass tiles.
static func pick_cell(viewport_point: Vector2, viewport: SubViewport, tilemap: TileMap,
		visual_offset: Vector2 = Vector2.ZERO) -> Vector2i:
	var world_point := viewport.get_canvas_transform().affine_inverse() * viewport_point
	var tilemap_local := tilemap.get_global_transform().affine_inverse() * world_point
	return tilemap.local_to_map(tilemap_local - visual_offset)


## World position for the visual center of a cell — use for drawing overlays,
## sprites, highlights, etc.  Matches pick_cell() so draw and click always agree.
static func cell_center(cell: Vector2i, tilemap: TileMap,
		visual_offset: Vector2 = Vector2.ZERO) -> Vector2:
	return tilemap.map_to_local(cell) + tilemap.global_position + visual_offset
