class_name PlanetMapSystem
extends Node2D

# Core orchestrator for the planet map system
# Coordinates all map components: generation, rendering, selection, camera
# No UI dependencies - can be used independently or with PlanetMapView

const LOG_TAG := "PLANET_MAP_SYSTEM"

# Signals
signal tile_selected(tile: MapTile)
signal tile_discovered(tile_data: Dictionary)
signal map_generated()
## Emitted during incremental chunk loading. progress is 0.0-1.0, status is a short description.
signal map_loading_progress(progress: float, status: String)

# Components
var tile_manager: PlanetMapTileManager = null
var camera_controller: PlanetMapCamera = null
var selection_manager: PlanetMapSelection = null
var renderer: PlanetMapRenderer = null
var ecosystem_manager: EcosystemManager = null
var harvester_manager: HarvesterManager = null
var village_manager: VillageManager = null
var villager_system: VillagerSystem = null
# DEPRECATED: Old dynamic region loading system - replaced with chunk visibility system
# var dynamic_region_loader: DynamicRegionLoader = null  # For exploring large maps

# Chunk rendering system (for large maps)
var chunk_manager: ChunkVisibilityManager = null
var using_chunks: bool = false

# Map data - PlanetMapData is the new centralized data store
var map_data: PlanetMapData = null  # Single source of truth for tile data + coordinate system

# Backward-compatible accessor for map_tiles
var map_tiles: Array:
	get:
		return map_data.tiles if map_data else []
	set(value):
		if map_data:
			map_data.set_all_tiles(value)
		else:
			# Create map_data if needed (supports old code paths)
			var size = Vector2i(value.size(), value[0].size() if value.size() > 0 else 0)
			map_data = PlanetMapData.new(size, planet_id)
			map_data.set_all_tiles(value)

var current_planet: Planet = null
var probe_system: ProbeSystem = null
var planet_data: Dictionary = {}
var planet_id: String = ""
var is_map_generated: bool = false

## Active world scenario — set before generate_map() to override village scenario selection.
var world_scenario: String = ""

# Viewport reference (set by parent if needed for selection)
var map_viewport: SubViewport = null

# PERFORMANCE: O(1) sprite lookup cache - position -> Sprite2D
var _sprite_cache: Dictionary = {}  # Vector2i -> Sprite2D

# PERFORMANCE: Deferred update queue - positions waiting to be rendered
var _pending_sprite_updates: Array[Vector2i] = []
const MAX_SPRITE_UPDATES_PER_FRAME := 32  # Limit updates per frame to prevent hitches

# Firewood supply tracking: how many armloads remain at each dead tree position
var _deadwood_supply: Dictionary = {}    # Vector2i -> int
# Positions fully depleted so they are excluded from future dead-tree searches
var _depleted_positions: Dictionary = {} # Vector2i -> true
# Positions where trees were explicitly removed (laser, harvester, etc.)
var _removed_tree_positions: Dictionary = {} # Vector2i -> true
# Positions where ruin sprites are placed (abandoned longhouse sites)
var _ruin_positions: Dictionary = {} # Vector2i -> true

# Berry bush supply: picks remaining per bush position
var _berry_supply: Dictionary = {}         # Vector2i -> int
# Berry regrowth timers: ticks remaining before a depleted bush regrows
var _berry_regrowth_timers: Dictionary = {}  # Vector2i -> int

const BERRY_MAX_PICKS := 4  # trips before bush is stripped (regrows after cooldown)
const BERRY_REGROWTH_TICKS := 400  # simulation ticks before depleted bush regrows (~100 game days)

# Wind simulation state
var _wind_x: float = 0.0          # current wind direction/strength (-1 to 1)
var _wind_push_timer: float = 0.0 # throttle smoke updates to every 0.5s

# Terrain source cache — shared across all planet visits (same PNG every time)
static var _cached_terrain_source: PNGTerrainSource = null

# Incremental chunk loading state machine
enum ChunkLoadState { IDLE, LOADING_CENTER, LOADING_VISIBLE, LOADING_PRELOAD }
var _chunk_loading_state: ChunkLoadState = ChunkLoadState.IDLE
var _chunk_load_queue_visible: Array[Vector2i] = []
var _chunk_load_queue_preload: Array[Vector2i] = []
var _chunk_center: Vector2i = Vector2i(-999, -999)
var _chunk_total_visible: int = 0
# Time budgets in milliseconds per frame. Keeps frame times sane regardless of chunk cost.
const CHUNK_BUDGET_MS_VISIBLE := 8    # up to 8ms/frame during initial reveal
const CHUNK_BUDGET_MS_PRELOAD := 3    # up to 3ms/frame for background preload

# Village placement
const NPC_VILLAGE_COUNT := 8          # NPC villages to place on the map
const MIN_CAMP_SPACING := 80       # minimum tile distance between any two camps
const VILLAGE_TERRITORY_RADIUS := 55  # resource search radius per village (< half spacing)
const MAX_WATER_DISTANCE := 25        # reject camp positions with water farther than this

func _ready():
	GameLog.info(LOG_TAG, "PlanetMapSystem._ready() called")
	_initialize_components()
	GameLog.info(LOG_TAG, "PlanetMapSystem._ready() complete, ecosystem_manager=%s" % [ecosystem_manager != null])

func _initialize_components():
	GameLog.info(LOG_TAG, "_initialize_components() starting...")

	# Connect to VariantManager for live theme updates
	VariantManager.get_instance().theme_changed.connect(_on_theme_changed)
	GameLog.info(LOG_TAG, "✓ VariantManager connected")

	# Create tile manager
	tile_manager = PlanetMapTileManager.new()
	tile_manager.name = "TileManager"
	add_child(tile_manager)
	GameLog.info(LOG_TAG, "✓ TileManager created")

	# Note: Tile manager position will be set by _update_tile_manager_position()
	# after map_data is available with actual map size

	# Create camera controller
	# Camera will be initialized in its _ready() with zoom (2.0, 2.0) and position (0, 0)
	camera_controller = PlanetMapCamera.new()
	camera_controller.name = "CameraController"
	add_child(camera_controller)
	GameLog.info(LOG_TAG, "✓ CameraController created")

	# Create selection manager
	selection_manager = PlanetMapSelection.new()
	selection_manager.name = "SelectionManager"
	tile_manager.ensure_overlay_layer().add_child(selection_manager)
	GameLog.info(LOG_TAG, "✓ SelectionManager created")

	# Connect selection signals
	selection_manager.tile_selected.connect(_on_tile_selected)
	selection_manager.selection_cleared.connect(_on_selection_cleared)

	# Create renderer
	renderer = PlanetMapRenderer.new()
	GameLog.info(LOG_TAG, "✓ Renderer created")

	# Create ecosystem manager
	GameLog.info(LOG_TAG, "About to create EcosystemManager...")
	ecosystem_manager = EcosystemManager.new()
	GameLog.info(LOG_TAG, "EcosystemManager.new() returned: %s" % [ecosystem_manager != null])
	ecosystem_manager.name = "EcosystemManager"
	add_child(ecosystem_manager)
	GameLog.info(LOG_TAG, "✓ EcosystemManager added as child")
	# PERFORMANCE: Use batched signals for all visual updates (stage changes, births, deaths)
	ecosystem_manager.trees_batch_updated.connect(_on_trees_batch_updated)
	ecosystem_manager.ground_cover_batch_updated.connect(_on_ground_cover_batch_updated)
	GameLog.info(LOG_TAG, "✓ EcosystemManager connected: trees_batch_updated, ground_cover_batch_updated")

	# Create harvester manager
	harvester_manager = HarvesterManager.new()
	harvester_manager.name = "HarvesterManager"
	harvester_manager.planet_map_system = self
	harvester_manager.ecosystem_manager = ecosystem_manager
	add_child(harvester_manager)
	GameLog.info(LOG_TAG, "HarvesterManager created")

	# Create village manager
	village_manager = VillageManager.new()
	village_manager.name = "VillageManager"
	village_manager.ecosystem_manager = ecosystem_manager
	village_manager.map_data = map_data
	village_manager.planet_map_system = self
	add_child(village_manager)
	GameLog.info(LOG_TAG, "VillageManager created")

	# Create villager system (map_container set later by PlanetMapView)
	villager_system = VillagerSystem.new()
	villager_system.name = "VillagerSystem"
	villager_system.planet_map_system = self
	add_child(villager_system)
	village_manager.villager_system = villager_system
	GameLog.info(LOG_TAG, "VillagerSystem created")

	GameLog.info(LOG_TAG, "Planet map system components initialized")

# Setup the planet map with planet data
func setup_planet(planet: Planet, probe_sys: ProbeSystem, p_planet_id: String = ""):
	GameLog.info(LOG_TAG, "Setting up planet map for: %s" % planet.planet_name)

	current_planet = planet
	probe_system = probe_sys
	planet_id = p_planet_id

	if planet_id == "" and probe_system:
		planet_id = probe_system._get_stable_planet_id(planet)
		GameLog.info(LOG_TAG, "Generated planet_id from probe_system: '%s'" % planet_id)

	if planet_id == "":
		GameLog.error(LOG_TAG, "Planet ID is empty string - persistence will NOT work!")

	# Load planet data from probe system
	if probe_system and planet_id != "":
		planet_data = probe_system.discovered_planets.get(planet_id, {})
		GameLog.debug(LOG_TAG, "Planet data loaded: %s keys" % planet_data.keys().size())
	elif not probe_system:
		GameLog.warn(LOG_TAG, "No probe_system available - cannot load planet data")

# Generate or load the map
func generate_map() -> bool:
	if is_map_generated:
		GameLog.warn(LOG_TAG, "Map already generated")
		return true

	if not current_planet:
		GameLog.error(LOG_TAG, "Cannot generate map: no planet set")
		return false

	# Check if we should use chunk rendering (do this BEFORE cache check)
	if _should_use_chunk_rendering():
		var chunk_seed = 0
		if probe_system and planet_id != "":
			chunk_seed = probe_system.get_surface_map_seed(planet_id)
		else:
			chunk_seed = abs(hash(str(current_planet.get_instance_id())))

		GameLog.info(LOG_TAG, "Planet is habitable (%.2f) - using chunk rendering (ignoring cache)" % current_planet.habitability_score)
		return _enable_chunk_rendering_for_planet(chunk_seed)

	# Try to load from cache for non-chunk planets
	if planet_id != "" and probe_system:
		var cached_tiles = PlanetMapCache.try_load_cached_map(planet_id, probe_system)
		if not cached_tiles.is_empty():
			GameLog.info(LOG_TAG, "Loading 64x64 map from cache (non-habitable planet)")
			# Create PlanetMapData from cached tiles
			var cache_size = Vector2i(cached_tiles.size(), cached_tiles[0].size())
			map_data = PlanetMapData.new(cache_size, planet_id)
			map_data.set_all_tiles(cached_tiles)
			map_data.planet = current_planet
			map_data.probe_data = planet_data.get("revealed_data", {})

			# Update tile manager position for actual map size
			_update_tile_manager_position()

			is_map_generated = true
			_create_tile_visuals()
			var cached_probe_results = planet_data.get("revealed_data", {})
			_setup_ecosystem(cached_probe_results)
			_setup_villages()
			map_generated.emit()
			return true

	# Generate new map
	var stable_id = planet_id if planet_id != "" else ""
	var map_seed = 0
	if probe_system and stable_id != "":
		map_seed = probe_system.get_surface_map_seed(stable_id)
	else:
		map_seed = abs(hash(str(current_planet.get_instance_id())))

	GameLog.info(LOG_TAG, "Generating map with seed: %s" % map_seed)

	# Check if we should use chunk rendering for this planet
	if _should_use_chunk_rendering():
		GameLog.info(LOG_TAG, "Planet is habitable (%.2f) - using chunk rendering" % current_planet.habitability_score)
		return _enable_chunk_rendering_for_planet(map_seed)

	# Get probe results
	var probe_results = planet_data.get("revealed_data", {})
	if probe_results.is_empty():
		GameLog.error(LOG_TAG, "No probe results available for map generation")
		return false

	# Generate tiles using PlanetMapGenerator
	var generator = PlanetMapGenerator.new()
	var generated_tiles = generator.generate_map(current_planet, probe_results, map_seed)

	if generated_tiles == null or generated_tiles.is_empty():
		GameLog.error(LOG_TAG, "Map generation failed")
		return false

	GameLog.info(LOG_TAG, "Map generated: %sx%s" % [generated_tiles.size(), generated_tiles[0].size()])

	# Create PlanetMapData with full metadata
	var map_size = Vector2i(generated_tiles.size(), generated_tiles[0].size())
	map_data = PlanetMapData.new(map_size, planet_id)
	map_data.set_all_tiles(generated_tiles)
	map_data.planet = current_planet
	map_data.probe_data = probe_results

	# Update tile manager position for actual map size
	_update_tile_manager_position()

	# Cache the generated map
	if probe_system and stable_id != "":
		PlanetMapCache.save_map_cache(stable_id, map_tiles, map_seed, probe_system)

	# Set up ecosystem with initial trees
	_setup_ecosystem(probe_results)
	if village_manager:
		village_manager.map_data = map_data
	_setup_villages()

	# Initialize chunk system for Minecraft-style optimization
	if ecosystem_manager and map_tiles.size() > 0:
		var map_width = map_tiles.size()
		var map_height = map_tiles[0].size() if map_tiles[0] != null else 0
		var map_center = Vector2i(map_width >> 1, map_height >> 1)

		# Set initial active chunks to map center
		ecosystem_manager.update_active_chunks(planet_id, map_center)

		# Build chunk structure from existing trees
		ecosystem_manager.rebuild_tree_chunks(planet_id)

		GameLog.info(LOG_TAG, "Chunking system initialized: map=%sx%s, center=%s" % [map_width, map_height, map_center])

	is_map_generated = true

	# Create visuals
	_create_tile_visuals()

	map_generated.emit()
	return true

# ============================================================================
# CHUNK RENDERING SYSTEM
# ============================================================================

## Check if chunk rendering should be used for this planet
func _should_use_chunk_rendering() -> bool:
	if not current_planet:
		return false

	# Use chunks for highly habitable planets (PNG terrain available)
	var habitability = current_planet.habitability_score
	if habitability < 0.7:
		return false

	# Check if PNG terrain resource exists (use ResourceLoader, not FileAccess —
	# FileAccess cannot see inside the exported PCK, only raw OS filesystem)
	var png_path = "res://assets/terrain/reference/full_map_8bit.png"
	if not ResourceLoader.exists(png_path):
		GameLog.warn(LOG_TAG, "PNG terrain not found, falling back to traditional rendering")
		return false

	return true

## Enable chunk-based rendering for the current planet.
## Synchronously sets up terrain, camera, and villages, then queues chunks for
## incremental loading via _process(). map_generated emits when the visible area is ready.
func _enable_chunk_rendering_for_planet(map_seed: int) -> bool:
	GameLog.info(LOG_TAG, "Enabling chunk rendering for planet (incremental)...")
	map_loading_progress.emit(0.0, "Initializing terrain scanner...")

	# Reuse cached terrain source — same PNG files for all habitable planets.
	# First visit loads from disk; subsequent visits reuse the in-memory Image data.
	if _cached_terrain_source == null or not _cached_terrain_source.is_loaded():
		var png_path = "res://assets/terrain/reference/full_map_8bit.png"
		var water_mask_path = "res://assets/terrain/reference/water_mask.png"
		var flow_dir_path   = "res://assets/terrain/reference/flow_direction.png"
		if not ResourceLoader.exists(flow_dir_path):
			flow_dir_path = ""  # optional — game works fine without it
		GameLog.info(LOG_TAG, "Loading PNG terrain from disk (first visit)...")
		_cached_terrain_source = PNGTerrainSource.new(png_path, true, water_mask_path, flow_dir_path)
	else:
		GameLog.info(LOG_TAG, "Reusing cached PNG terrain source (subsequent visit)")

	var terrain_source := _cached_terrain_source
	if not terrain_source.is_loaded():
		GameLog.error(LOG_TAG, "Failed to load PNG terrain")
		return false

	GameLog.info(LOG_TAG, "PNG terrain ready: %dx%d" % [terrain_source.get_png_size().x, terrain_source.get_png_size().y])
	map_loading_progress.emit(0.1, "Terrain data ready")

	# Create chunk manager
	chunk_manager = ChunkVisibilityManager.new()
	chunk_manager.name = "ChunkManager"
	chunk_manager.set_terrain_source(terrain_source)

	# Add to tile manager (parent node for map content)
	if tile_manager:
		tile_manager.add_child(chunk_manager)
	else:
		GameLog.error(LOG_TAG, "No tile_manager found to add chunk_manager")
		return false

	# Enable chunk mode
	using_chunks = true

	# Determine start tile from planet seed (deterministic per planet)
	var region_info = TerrainRegionSelector.get_region_for_seed(map_seed)
	var start_tile = region_info["pixel_offset"] + Vector2i(32, 32)

	# Create map_data with full PNG size for bounds checking
	var png_size = terrain_source.get_png_size()
	map_data = PlanetMapData.new(png_size, planet_id)
	map_data.planet = current_planet
	map_data.probe_data = planet_data.get("revealed_data", {})

	# Update tile manager position BEFORE positioning camera so tile_manager.global_position is correct
	_update_tile_manager_position()

	# Position camera
	if camera_controller and camera_controller.camera:
		var start_layer := 0
		var start_elev := terrain_source.get_elevation_at_tile(start_tile)
		start_layer = PlanetMapTileConfig.get_render_layer(start_elev)
		var start_tilemap = tile_manager.ensure_layer_tilemap(start_layer)
		if start_tilemap:
			var local_pos = start_tilemap.map_to_local(start_tile) + start_tilemap.position
			camera_controller.camera.global_position = tile_manager.to_global(local_pos)
			GameLog.info(LOG_TAG, "Camera positioned at region %s (tile %s, layer %d, global %s)" % [region_info["region_index"], start_tile, start_layer, camera_controller.camera.global_position])

	# Mark as generated and initialize selection before village/chunk setup
	is_map_generated = true
	_setup_selection_for_chunks()
	map_loading_progress.emit(0.12, "Calibrating tile grid...")

	# Register villages before the feature populator so camp clearings are known when chunks load
	if village_manager:
		village_manager.map_data = map_data
	_setup_villages()
	map_loading_progress.emit(0.14, "Placing villages...")

	# Attach forest population callback BEFORE chunk loading so every chunk gets features
	chunk_manager.feature_populator = _populate_chunk_forest

	map_loading_progress.emit(0.15, "Queueing surface tiles...")

	# Compute camera chunk position
	var camera_chunk := Vector2i(-999, -999)
	if camera_controller and camera_controller.camera:
		var cam_local := tile_manager.to_local(camera_controller.camera.global_position)
		var tile_pos := PlanetMapCoordinates.world_to_grid(cam_local - PlanetMapTileConfig.TILE_OFFSET)
		camera_chunk = Vector2i(
			floori(float(tile_pos.x) / ChunkVisibilityManager.CHUNK_SIZE),
			floori(float(tile_pos.y) / ChunkVisibilityManager.CHUNK_SIZE)
		)
	chunk_manager.current_camera_chunk = camera_chunk

	# Center chunk loads first and triggers map_generated; remaining chunks load in background
	_chunk_center = camera_chunk

	# Build visible/preload queues excluding the center chunk
	for dy in range(-ChunkVisibilityManager.LOAD_RADIUS, ChunkVisibilityManager.LOAD_RADIUS + 1):
		for dx in range(-ChunkVisibilityManager.LOAD_RADIUS, ChunkVisibilityManager.LOAD_RADIUS + 1):
			var cp := camera_chunk + Vector2i(dx, dy)
			if cp == camera_chunk:
				continue  # loaded separately in LOADING_CENTER phase
			if terrain_source.is_valid_chunk(cp):
				var chebyshev := maxi(absi(dx), absi(dy))
				if chebyshev <= ChunkVisibilityManager.VISIBILITY_RADIUS:
					_chunk_load_queue_visible.append(cp)
				else:
					_chunk_load_queue_preload.append(cp)

	_chunk_total_visible = _chunk_load_queue_visible.size()
	_chunk_loading_state = ChunkLoadState.LOADING_CENTER
	GameLog.info(LOG_TAG, "Queued center + %d visible + %d preload chunks for incremental load" % [
		_chunk_load_queue_visible.size(), _chunk_load_queue_preload.size()
	])
	return true

## Runs each frame from _process(). Loads chunks within a per-frame time budget.
## Phase 0 (LOADING_CENTER): loads single camera chunk, emits map_generated immediately.
## Phase 1 (LOADING_VISIBLE): up to CHUNK_BUDGET_MS_VISIBLE ms/frame for remaining visible ring.
## Phase 2 (LOADING_PRELOAD): up to CHUNK_BUDGET_MS_PRELOAD ms/frame in background.
func _process_chunk_load_queue() -> void:
	if _chunk_loading_state == ChunkLoadState.IDLE or not chunk_manager:
		return

	var frame_start_ms := Time.get_ticks_msec()

	if _chunk_loading_state == ChunkLoadState.LOADING_CENTER:
		map_loading_progress.emit(0.85, "Scanning surface... (1 / %d)" % (_chunk_total_visible + 1))
		if chunk_manager.terrain_source and chunk_manager.terrain_source.is_valid_chunk(_chunk_center):
			chunk_manager.load_one_chunk(_chunk_center)
			var vis := chunk_manager.get_chunk_visual(_chunk_center)
			if vis:
				vis.visible = true
		GameLog.info(LOG_TAG, "Center chunk loaded. Emitting map_generated.")
		_chunk_loading_state = ChunkLoadState.LOADING_VISIBLE
		map_generated.emit()

	elif _chunk_loading_state == ChunkLoadState.LOADING_VISIBLE:
		while not _chunk_load_queue_visible.is_empty():
			var cp: Vector2i = _chunk_load_queue_visible.pop_front()
			if chunk_manager.load_one_chunk(cp):
				var vis := chunk_manager.get_chunk_visual(cp)
				if vis:
					vis.visible = true
			if Time.get_ticks_msec() - frame_start_ms >= CHUNK_BUDGET_MS_VISIBLE:
				break

		if _chunk_load_queue_visible.is_empty():
			_chunk_loading_state = ChunkLoadState.LOADING_PRELOAD
			GameLog.info(LOG_TAG, "Visible ring loaded (%d chunks)." % _chunk_total_visible)

	elif _chunk_loading_state == ChunkLoadState.LOADING_PRELOAD:
		while not _chunk_load_queue_preload.is_empty():
			var cp: Vector2i = _chunk_load_queue_preload.pop_front()
			chunk_manager.load_chunk_data_only(cp)  # data only — no scene nodes
			if Time.get_ticks_msec() - frame_start_ms >= CHUNK_BUDGET_MS_PRELOAD:
				break
		if _chunk_load_queue_preload.is_empty():
			_chunk_loading_state = ChunkLoadState.IDLE
			GameLog.info(LOG_TAG, "All chunk data preloaded (no visual nodes for preload ring).")


## DEPRECATED: Old dynamic region loading system
## This method is deprecated and will be replaced with chunk visibility system
## Call this after generate_map() to allow camera-based region streaming
func enable_dynamic_loading(load_radius: int = 2) -> bool:
	push_warning("enable_dynamic_loading() is deprecated - chunk visibility system coming soon")
	print("[PLANET_MAP_SYSTEM] enable_dynamic_loading() called with radius=%d" % load_radius)

	if not current_planet or not is_map_generated:
		print("[PLANET_MAP_SYSTEM] ERROR: Cannot enable dynamic loading - map_generated=%s, has_planet=%s" % [is_map_generated, current_planet != null])
		GameLog.error(LOG_TAG, "Cannot enable dynamic loading: map not generated")
		return false

	# Check if this is a habitable planet (only habitable planets have PNG terrain)
	var hab_score = current_planet.habitability_score
	print("[PLANET_MAP_SYSTEM] Planet habitability: %.2f (need >= 0.7)" % hab_score)

	if hab_score < 0.7:
		print("[PLANET_MAP_SYSTEM] Dynamic loading not enabled - planet not habitable enough")
		GameLog.info(LOG_TAG, "Dynamic loading not available for non-habitable planets (%.2f)" % hab_score)
		return false

	# Get map seed (deprecated - kept for reference only)
	var stable_id = planet_id if planet_id != "" else ""
	var _map_seed = 0
	if probe_system and stable_id != "":
		_map_seed = probe_system.get_surface_map_seed(stable_id)
	else:
		_map_seed = abs(hash(str(current_planet.get_instance_id())))

	# Load global terrain metadata
	print("[PLANET_MAP_SYSTEM] Loading terrain metadata...")
	var global_stats = _load_terrain_metadata()

	if global_stats.is_empty():
		print("[PLANET_MAP_SYSTEM] ERROR: No terrain metadata found!")
		GameLog.warn(LOG_TAG, "No terrain metadata found - dynamic loading disabled")
		return false

	print("[PLANET_MAP_SYSTEM] Metadata loaded successfully: %s" % global_stats.keys())

	# DEPRECATED: Dynamic region loader code removed
	# This functionality will be replaced with chunk visibility system
	#dynamic_region_loader = DynamicRegionLoader.new(map_seed, global_stats)
	#dynamic_region_loader.set_load_radius(load_radius)
	#dynamic_region_loader.regions_changed.connect(_on_dynamic_regions_changed)
	print("[PLANET_MAP_SYSTEM] Dynamic loading deprecated - returning false")

	#print("[PLANET_MAP_SYSTEM] ✓ Dynamic region loading enabled (radius=%d)" % load_radius)
	#GameLog.info(LOG_TAG, "Dynamic region loading enabled (radius=%d)" % load_radius)
	return false  # Deprecated - always returns false

func _load_terrain_metadata() -> Dictionary:
	"""Load pre-calculated global statistics from metadata file."""
	var metadata_path = "res://assets/terrain/terrain_metadata.json"

	if not FileAccess.file_exists(metadata_path):
		return {}

	var file = FileAccess.open(metadata_path, FileAccess.READ)
	if file == null:
		return {}

	var json_text = file.get_as_text()
	file.close()

	var json = JSON.new()
	var parse_result = json.parse(json_text)

	if parse_result != OK:
		GameLog.error(LOG_TAG, "Failed to parse terrain metadata JSON")
		return {}

	return json.data

## DEPRECATED: Old dynamic region loading handler
func _on_dynamic_regions_changed(_added_regions: Array, _removed_regions: Array):
	push_warning("_on_dynamic_regions_changed() is deprecated")


## Update tile manager position based on actual map size
func _update_tile_manager_position():
	var map_size = map_data.map_size if map_data else PlanetMapTileConfig.MAP_SIZE
	var world_center = PlanetMapCoordinates.get_map_center_world_position(map_size)
	tile_manager.position = -world_center
	GameLog.debug(LOG_TAG, "Tile manager position updated for map size %s" % map_size)


# Create visual representation of tiles
func _create_tile_visuals():
	GameLog.debug(LOG_TAG, "Creating tile visuals...")

	if map_tiles == null or map_tiles.is_empty():
		GameLog.error(LOG_TAG, "Cannot create visuals: no map tiles")
		return

	# Clear existing tiles
	tile_manager.clear_all_tiles()

	# Initialize tileset
	tile_manager.ensure_tilemap_tileset()
	if tile_manager.tile_map_source_id == -1:
		GameLog.error(LOG_TAG, "Failed to initialize tileset")
		return

	var created_count := 0
	var _surface_feature_count := 0
	var surface_feature_rendered := 0
	var sf_elevation_counts := {}  # Track elevation distribution of rendered features

	# Calculate actual map bounds dynamically
	var actual_width = map_tiles.size()
	var actual_height = 0
	if actual_width > 0 and map_tiles[0] != null:
		actual_height = map_tiles[0].size()

	# Place all tiles
	for x in range(actual_width):
		if x >= map_tiles.size():
			continue

		var row = map_tiles[x]
		if row == null or typeof(row) != TYPE_ARRAY:
			continue

		for y in range(actual_height):
			if y >= row.size():
				continue

			var tile = row[y]
			if tile == null or not tile is MapTile:
				continue

			var cell := Vector2i(x, y)
			tile.position = cell
			tile.world_position = PlanetMapCoordinates.grid_to_world(cell)

			# Get atlas coordinates
			var atlas_coords: Vector2i = PlanetMapTileConfig.get_atlas_coords(tile.type)
			if atlas_coords == Vector2i(-1, -1):
				continue

			# Place tile on all elevation layers up to its elevation
			# Use NUM_RENDER_LAYERS for precise quantization (e.g., 32 layers instead of 8)
			var target_elevation: int = tile.get_render_layer()  # Uses NUM_RENDER_LAYERS default
			var layers_to_create = max(1, target_elevation + 1)

			# Render terrain on all elevation layers up to tile's elevation
			for layer in range(layers_to_create):
				var tilemap = tile_manager.ensure_layer_tilemap(layer)
				if tilemap:
					# Render base terrain on layer 0 of this elevation TileMap
					tilemap.set_cell(PlanetMapTileConfig.TILEMAP_LAYER_TERRAIN, cell, tile_manager.tile_map_source_id, atlas_coords, 0)

			# Render surface feature if present (render as sprite for offset/scaling support)
			if tile.surface_feature_type != null:
				_surface_feature_count += 1
				# Render feature as sprite node instead of TileMap cell to support offset and scaling
				_render_feature_sprite(tile, target_elevation, tile.surface_feature_type)
				surface_feature_rendered += 1
				# Track elevation distribution
				sf_elevation_counts[target_elevation] = sf_elevation_counts.get(target_elevation, 0) + 1

			created_count += 1

			if created_count % 500 == 0:
				GameLog.debug(LOG_TAG, "Placed %s tiles..." % created_count)

	GameLog.info(LOG_TAG, "Visual tile creation complete: %s tiles, %d surface features" % [created_count, surface_feature_rendered])

	# Log surface feature elevation distribution
	var elev_keys = sf_elevation_counts.keys()
	elev_keys.sort()
	for elev in elev_keys:
		GameLog.info(LOG_TAG, "  - Rendered %d surface features at elevation %d" % [sf_elevation_counts[elev], elev])

	# Update selection manager references
	if selection_manager:
		selection_manager.map_tiles = map_tiles
		selection_manager.layer_tilemaps = tile_manager.get_all_layer_tilemaps()
		selection_manager.map_viewport = map_viewport

# Render a surface feature sprite (tree or ground cover) with offset and scaling
func _render_feature_sprite(tile: MapTile, elevation: int, feature_tile_id: int) -> void:
	# Get the unified sprite container (all sprites are siblings for proper y-sorting)
	var sprite_container = tile_manager.ensure_sprite_container()
	if not sprite_container:
		return

	# Use terrain layer tilemap as reference (no extra offset like surface feature layer has)
	var ref_tilemap = tile_manager.ensure_layer_tilemap(elevation)
	if not ref_tilemap:
		return

	# Create a sprite for the feature
	var sprite = Sprite2D.new()
	sprite.texture = PlanetMapTileConfig.TILESET_TEXTURE
	# CRITICAL: Set texture filter to NEAREST for pixel-perfect rendering
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

	# Set the region to show the feature tile from the tileset
	# Use GeneratedTileTypes for atlas coords (handles all 200 tiles)
	var tree_atlas_coords = GeneratedTileTypes.get_atlas_coords(feature_tile_id as GeneratedTileTypes.TileType)
	if tree_atlas_coords == Vector2i(-1, -1):
		sprite.queue_free()
		return

	# Calculate region from atlas coordinates manually since GeneratedTileTypes doesn't have get_tileset_region
	var region_pos = tree_atlas_coords * PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE + PlanetMapTileConfig.TILESET_REGION_INSET
	var region_rect = Rect2i(region_pos, PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE - PlanetMapTileConfig.TILESET_REGION_INSET * 2)
	sprite.region_enabled = true
	sprite.region_rect = region_rect

	# Check if this is ground cover (small tile, no offset/scale)
	var is_ground_cover = (feature_tile_id == 40 or feature_tile_id == 45)  # Grass or goldenrod

	# Calculate WORLD position accounting for elevation
	# ref_tilemap.map_to_local gives position in tilemap's local space
	var tile_local = ref_tilemap.map_to_local(tile.position)
	# ref_tilemap.position is the tilemap's world offset for this elevation
	var tile_world = ref_tilemap.position + tile_local

	if is_ground_cover:
		# Ground cover: render 40px above tile center (one elevation step up)
		sprite.position = tile_world + Vector2(0, -40)
		sprite.scale = Vector2.ONE
		# Center the sprite on the tile
		sprite.centered = true
		sprite.offset = Vector2.ZERO
	else:
		# Trees: center on tile horizontally, bottom-align vertically at tile center
		var tree_offset = Vector2.ZERO
		var tree_scale = 1.0

		if ecosystem_manager:
			var tree = get_tree_at(tile.position)
			if tree:
				# Only use X offset for horizontal variation (ignore Y offset)
				tree_offset = Vector2(tree.visual_offset.x, 0)
				tree_scale = tree.visual_scale

		# Position tree with bottom at tile center (no Y adjustment)
		sprite.position = tile_world + tree_offset
		sprite.scale = Vector2.ONE * tree_scale
		# Bottom-center alignment for trees (roots at tile center)
		sprite.centered = false
		sprite.offset = Vector2(-region_rect.size.x / 2, -region_rect.size.y)

	# Y-sorting is handled by the parent container, not individual sprites
	sprite.y_sort_enabled = false

	# No need to set z_index on sprite - parent container handles it
	sprite.z_index = 0
	sprite.z_as_relative = true  # Use parent's z_index

	# Store grid position and elevation as metadata so we can find and update this sprite later
	sprite.set_meta("grid_pos", tile.position)
	sprite.set_meta("elevation", elevation)

	# Calculate elevation-based brightness
	var brightness = PlanetMapTileConfig.get_elevation_brightness(elevation)

	# Apply variant palette-swap shader if applicable (shared instance — no per-sprite duplicate)
	_apply_variant_to_sprite(sprite, feature_tile_id, brightness)

	# Always apply brightness via modulate (shader no longer handles it internally)
	sprite.modulate = Color(brightness, brightness, brightness, 1.0)

	# Add to the UNIFIED sprite container (all sprites as siblings for y-sorting)
	sprite_container.add_child(sprite)

	# PERFORMANCE: Cache sprite for O(1) lookup
	_sprite_cache[tile.position] = sprite

# Get tile at grid position
func get_tile_at(grid_pos: Vector2i) -> MapTile:
	if grid_pos.x < 0 or grid_pos.y < 0:
		return null
	# Use actual map dimensions, not hardcoded MAP_SIZE constant
	if map_tiles == null or grid_pos.x >= map_tiles.size():
		return null
	var column = map_tiles[grid_pos.x]
	if column == null or grid_pos.y >= column.size():
		return null
	var tile = column[grid_pos.y]
	return tile if tile is MapTile else null

## Get raw elevation float (0.0-1.0) at a grid position.
## Works in both standard and chunk mode.
## In chunk mode, get_tile_at() returns null (map_data is not populated per-tile),
## so this method queries the terrain source directly instead.
func get_elevation_at(grid_pos: Vector2i) -> float:
	if using_chunks and chunk_manager and chunk_manager.terrain_source:
		return chunk_manager.terrain_source.get_elevation_at_tile(grid_pos)
	var tile := get_tile_at(grid_pos)
	return tile.elevation if tile else 0.0

## Get D8 flow direction at grid_pos.
## Returns 0-7 (E/SE/S/SW/W/NW/N/NE), 8 (lake), 255 (not water / no data).
## Only meaningful for SHALLOW_WATER tiles once flow_direction.png is loaded.
func get_flow_direction_at(grid_pos: Vector2i) -> int:
	if using_chunks and chunk_manager and chunk_manager.terrain_source:
		return chunk_manager.terrain_source.get_flow_direction_at_tile(grid_pos)
	return 255

# Get TreeInstance at the given grid position (if any)
func get_tree_at(grid_pos: Vector2i) -> TreeInstance:
	if ecosystem_manager == null:
		return null
	var eid = planet_id if planet_id != "" else str(current_planet.get_instance_id()) if current_planet else ""
	return ecosystem_manager.get_tree_at(eid, grid_pos)

## Return the tile ID of the static forest feature at grid_pos.
## Since the chunk forest is stamped deterministically from ForestSpecies, we can
## reconstruct it from position without storing it per-tile.
## Returns -1 if the position has been depleted or has no static forest tile.
func get_static_forest_tile_id(grid_pos: Vector2i) -> int:
	if _depleted_positions.has(grid_pos):
		return -1
	if ForestSpecies.is_dead_tree_position(grid_pos):
		return ForestSpecies.pick_dead_tile(grid_pos)[0]
	return ForestSpecies.pick_live_tile(grid_pos)


## Returns true if a tree sprite exists at this position (covers both EcosystemManager
## trees and static forest tiles placed via _populate_chunk_forest).
func has_tree_at(grid_pos: Vector2i) -> bool:
	# Check EcosystemManager first
	if get_tree_at(grid_pos) != null:
		return true
	# Fall back to chunk visual sprite_cache for static forest tiles
	if using_chunks and chunk_manager:
		var chunk_pos = Vector2i(grid_pos.x >> 6, grid_pos.y >> 6)
		var chunk_visual = chunk_manager.get_chunk_visual(chunk_pos)
		if chunk_visual:
			var local_pos = Vector2i(grid_pos.x % ChunkTileData.CHUNK_SIZE, grid_pos.y % ChunkTileData.CHUNK_SIZE)
			return chunk_visual.sprite_cache.has(local_pos)
	return false

func remove_tree_at(grid_pos: Vector2i) -> bool:
	var chunk_pos := Vector2i(grid_pos.x >> 6, grid_pos.y >> 6)
	var local_pos := Vector2i(grid_pos.x % ChunkTileData.CHUNK_SIZE, grid_pos.y % ChunkTileData.CHUNK_SIZE)

	# Try EcosystemManager first (simulation trees)
	var removed_from_ecosystem := false
	if ecosystem_manager:
		var eid = planet_id if planet_id != "" else str(current_planet.get_instance_id()) if current_planet else ""
		removed_from_ecosystem = ecosystem_manager.remove_tree_at(eid, grid_pos)

	# Always clear the visual sprite from the chunk (covers both static and simulation trees)
	var removed_visual := false
	if using_chunks and chunk_manager:
		var chunk_visual = chunk_manager.get_chunk_visual(chunk_pos)
		if chunk_visual and chunk_visual.sprite_cache.has(local_pos):
			chunk_visual.remove_tree_at(local_pos)
			removed_visual = true
		# Also clear feature from data cache so LOD re-render doesn't bring it back
		var chunk_data: ChunkTileData = chunk_manager.get_chunk_data(chunk_pos)
		if chunk_data:
			chunk_data.set_feature(local_pos, null)

	# Track removal so chunk re-render doesn't bring tree back
	if removed_from_ecosystem or removed_visual:
		_removed_tree_positions[grid_pos] = true

	return removed_from_ecosystem or removed_visual

# Get the currently selected tile
func get_selected_tile() -> MapTile:
	return selection_manager.selected_tile if selection_manager else null

# Select a tile at the given viewport point
func select_tile_at_viewport_point(viewport_point: Vector2):
	if selection_manager:
		selection_manager.select_tile_from_viewport_point(viewport_point)

# Clear tile selection
func clear_selection():
	if selection_manager:
		selection_manager.clear_selection()

# Select a tile directly (called by input handler)
func select_tile(tile: MapTile):
	if selection_manager and tile:
		selection_manager.apply_tile_selection(tile)

## Stamp a static dense forest into chunk_data before the chunk visual is created.
## Called by ChunkVisibilityManager via feature_populator for each newly loaded chunk.
## No simulation — trees are fixed sprites chosen deterministically from position hash.
##
## Uses ForestSpecies for mixed species (maple dominant, oak/beech/birch also present).
## ~10% of tiles get a dead/dormant tree; the rest get a live vegetative tile.
func _populate_chunk_forest(chunk_pos: Vector2i, chunk_data: ChunkTileData) -> void:
	var eid = planet_id if planet_id != "" else str(current_planet.get_instance_id()) if current_planet else ""
	var chunk_origin := chunk_pos * ChunkTileData.CHUNK_SIZE

	# Single pass — feature and understory populated together.
	# Direct tile_types array access avoids bounds-check overhead of get_tile_type().
	for local_y in range(ChunkTileData.CHUNK_SIZE):
		for local_x in range(ChunkTileData.CHUNK_SIZE):
			var flat_idx: int = local_y * ChunkTileData.CHUNK_SIZE + local_x
			var tile_type: int = chunk_data.tile_types[flat_idx]

			# No trees or understory on water tiles
			if tile_type == PlanetMapTileConfig.TileType.FRESH_WATER:
				continue

			var local_pos := Vector2i(local_x, local_y)
			var world_pos := chunk_origin + local_pos

			# Village camps take priority — stamp longhouse marker, no understory
			if village_manager and eid != "" and village_manager.has_village_at(eid, world_pos):
				chunk_data.set_feature(local_pos, GeneratedTileTypes.TileType.TILE_R2_C11)
				continue

			# Ruin positions get marked (rendered with darkened modulate by ChunkTileMapGroup)
			if _ruin_positions.has(world_pos):
				chunk_data.set_feature(local_pos, GeneratedTileTypes.TileType.TILE_R2_C11)
				chunk_data.set_ruin(local_pos, true)
				continue

			# 5x5 clearing around each camp — no trees or understory
			if village_manager and eid != "" and village_manager.is_in_village_area(eid, world_pos):
				continue

			# Skip positions where trees were explicitly removed
			if _removed_tree_positions.has(world_pos):
				continue

			# Determine feature: ~10% dead tree, rest live tree
			var feature_id: int
			if ForestSpecies.is_dead_tree_position(world_pos):
				var dead_result := ForestSpecies.pick_dead_tile(world_pos)
				feature_id = dead_result[0]
			else:
				feature_id = ForestSpecies.pick_live_tile(world_pos)
			chunk_data.set_feature(local_pos, feature_id)

			# Understory: dead trees let in light — raspberry thrives; dense canopy suppresses it
			var chance := ForestSpecies.RASPBERRY_CHANCE_DEAD if \
					ForestSpecies.is_dead_tree(feature_id) \
					else ForestSpecies.RASPBERRY_CHANCE_LIVE
			if ForestSpecies.is_raspberry_position(world_pos, chance):
				chunk_data.set_understory(local_pos, ForestSpecies.RASPBERRY_BUSH)

## Set up selection_manager references so picking and highlighting work in chunk mode.
## Called after chunk rendering is enabled; empty layer tilemaps handle coordinate math.
func _setup_selection_for_chunks():
	if not selection_manager:
		return
	selection_manager.map_viewport = map_viewport
	var chunk_tilemaps: Array[TileMap] = []
	for i in range(PlanetMapTileConfig.NUM_RENDER_LAYERS):
		chunk_tilemaps.append(tile_manager.ensure_layer_tilemap(i))
	selection_manager.layer_tilemaps = chunk_tilemaps
	GameLog.info(LOG_TAG, "Selection manager initialized for chunk mode (%d tilemaps)" % chunk_tilemaps.size())

## Pick a tile in chunk mode by iterating elevation layers top-to-bottom.
## Each layer's tilemap is at position (0, -N*LAYER_HEIGHT_OFFSET), so converting the
## world click point through tilemap_N's global transform automatically removes the
## elevation offset — no manual correction needed.
func pick_tile_chunk_mode(viewport_point: Vector2) -> MapTile:
	if not chunk_manager or not chunk_manager.terrain_source:
		GameLog.warn(LOG_TAG, "Cannot pick in chunk mode: no chunk manager or terrain source")
		return null
	if not map_viewport or not is_instance_valid(map_viewport):
		GameLog.warn(LOG_TAG, "Cannot pick in chunk mode: no viewport")
		return null

	# Convert viewport -> global world coordinates
	var canvas_transform: Transform2D = map_viewport.get_canvas_transform()
	var world_point: Vector2 = canvas_transform.affine_inverse() * viewport_point

	var png_size: Vector2i = chunk_manager.terrain_source.get_png_size()

	# Iterate layers highest→lowest. Each tilemap_N is offset by (0, -N*LAYER_HEIGHT_OFFSET),
	# so its local_to_map automatically accounts for that elevation shift.
	for layer in range(PlanetMapTileConfig.NUM_RENDER_LAYERS - 1, -1, -1):
		var tilemap: TileMap = tile_manager.ensure_layer_tilemap(layer)
		if not tilemap or not is_instance_valid(tilemap):
			continue

		var tilemap_local: Vector2 = tilemap.get_global_transform().affine_inverse() * world_point
		var tile_pos: Vector2i = tilemap.local_to_map(tilemap_local)

		if tile_pos.x < 0 or tile_pos.y < 0 or tile_pos.x >= png_size.x or tile_pos.y >= png_size.y:
			continue

		var elevation_raw: float = chunk_manager.terrain_source.get_elevation_at_tile(tile_pos)
		var tile_type: int = chunk_manager.terrain_source.get_tile_type_at_tile(tile_pos)
		var tile_render_layer: int = PlanetMapTileConfig.get_render_layer(elevation_raw)
		var is_water = (tile_type == PlanetMapTileConfig.TileType.FRESH_WATER)
		if is_water and tile_render_layer > 0:
			tile_render_layer -= 1

		if tile_render_layer == layer:
			var tile: MapTile = MapTile.new(tile_pos, tile_type)
			tile.elevation = elevation_raw
			# Check if a village camp is at this position
			var eid = planet_id if planet_id != "" else str(current_planet.get_instance_id()) if current_planet else ""
			if village_manager and eid != "" and village_manager.has_village_at(eid, tile_pos):
				tile.surface_feature_type = GeneratedTileTypes.TileType.TILE_R2_C11
			return tile

	return null

# Get the camera
func get_camera() -> Camera2D:
	return camera_controller.get_camera() if camera_controller else null

# Handle input events (for camera control)
func handle_input_event(event: InputEvent) -> bool:
	if camera_controller:
		return camera_controller.handle_input_event(event)
	return false

# Set up village simulation for the generated map
func _setup_villages() -> void:
	if village_manager == null or map_data == null:
		return

	var eid = planet_id if planet_id != "" else str(current_planet.get_instance_id()) if current_planet else ""
	if eid == "":
		return

	# Don't re-register villages if already set up for this planet
	if not village_manager.get_villages_on_planet(eid).is_empty():
		return

	# Check for saved village data in probe_system
	if probe_system and probe_system.discovered_planets.has(eid):
		var pdata: Dictionary = probe_system.discovered_planets[eid]
		if pdata.has("village_data"):
			_restore_villages(eid, pdata["village_data"])
		# Restore harvesters
		if pdata.has("harvester_data") and harvester_manager:
			harvester_manager.import_harvesters(eid, pdata["harvester_data"])
		if pdata.has("village_data"):
			return

	var map_size = map_data.map_size
	var placed_camps: Array[Vector2i] = []
	var claimed_water: Array[Vector2i] = []

	# --- Player village near camera start position ---
	var center := Vector2i(map_size.x >> 1, map_size.y >> 1)
	if camera_controller and camera_controller.camera and tile_manager:
		var cam_local := tile_manager.to_local(camera_controller.camera.global_position)
		var cam_grid := PlanetMapCoordinates.world_to_grid(cam_local)
		if cam_grid != Vector2i.ZERO:
			center = cam_grid.clamp(Vector2i(1, 1), map_size - Vector2i(2, 2))

	var scenario_id: String = WorldScenarioManager.get_village_scenario_id(world_scenario)

	var player_start := _find_village_camp_position(center, 0, placed_camps, claimed_water)
	if player_start != Vector2i(-1, -1):
		placed_camps.append(player_start)
	var player_territory: Array[Vector2i] = _build_territory(player_start, 6)
	var player_village = village_manager.register_village(eid, "village_player", scenario_id, player_territory, true)
	if player_village:
		player_village.camp_position = player_start
		player_village.carrying_capacity = village_manager._estimate_carrying_capacity(player_start)
		player_village.active_site.layout_longhouses(player_village.get_population(), VillageInstance.LONGHOUSE_CAPACITY)
		_assign_resource_positions(player_village, claimed_water, VILLAGE_TERRITORY_RADIUS)
		if player_village.water_pos != Vector2i(-1, -1):
			claimed_water.append(player_village.water_pos)
		_clear_camp_area(player_village.camp_position, eid, player_village.active_site.clearing_radius)
		for lh_pos in player_village.get_all_longhouse_positions():
			_update_surface_feature_at(lh_pos)
		if villager_system:
			villager_system.setup_village(player_village)

	# --- NPC villages via Poisson-disk rejection sampling near player start ---
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(eid) ^ hash(player_start)  # varies per planet + start location

	var npc_placed := 0
	var attempts := 0
	var max_attempts := NPC_VILLAGE_COUNT * 60

	# Map must be large enough to fit at least one NPC village with spacing
	var margin := MIN_CAMP_SPACING
	if map_size.x <= margin * 2 or map_size.y <= margin * 2:
		GameLog.warn(LOG_TAG, "Map too small for NPC villages (size %s, spacing %d)" % [map_size, MIN_CAMP_SPACING])
		return

	# NPC villages cluster within this radius of the player start
	const NPC_SPAWN_RADIUS := 256
	var spawn_min := (player_start - Vector2i(NPC_SPAWN_RADIUS, NPC_SPAWN_RADIUS)).clamp(Vector2i(margin, margin), map_size - Vector2i(margin, margin))
	var spawn_max := (player_start + Vector2i(NPC_SPAWN_RADIUS, NPC_SPAWN_RADIUS)).clamp(Vector2i(margin, margin), map_size - Vector2i(margin, margin))

	while npc_placed < NPC_VILLAGE_COUNT and attempts < max_attempts:
		attempts += 1
		var candidate := Vector2i(
			rng.randi_range(spawn_min.x, spawn_max.x),
			rng.randi_range(spawn_min.y, spawn_max.y)
		)

		# Reject candidates too close to existing camps
		var too_close := false
		for camp in placed_camps:
			if Vector2(candidate).distance_to(Vector2(camp)) < MIN_CAMP_SPACING:
				too_close = true
				break
		if too_close:
			continue

		var npc_start := _find_village_camp_position(candidate, npc_placed + 1, placed_camps, claimed_water)
		if npc_start == Vector2i(-1, -1):
			continue

		placed_camps.append(npc_start)
		var village_id := "village_npc_%02d" % (npc_placed + 1)
		var territory := _build_territory(npc_start, 6)
		var npc_village = village_manager.register_village(eid, village_id, scenario_id, territory, false)
		if npc_village:
			npc_village.camp_position = npc_start
			npc_village.carrying_capacity = village_manager._estimate_carrying_capacity(npc_start)
			npc_village.active_site.layout_longhouses(npc_village.get_population(), VillageInstance.LONGHOUSE_CAPACITY)
			_assign_resource_positions(npc_village, claimed_water, VILLAGE_TERRITORY_RADIUS)
			if npc_village.water_pos != Vector2i(-1, -1):
				claimed_water.append(npc_village.water_pos)
			_clear_camp_area(npc_village.camp_position, eid, npc_village.active_site.clearing_radius)
			for lh_pos in npc_village.get_all_longhouse_positions():
				_update_surface_feature_at(lh_pos)
			if villager_system:
				# Deflate NPC villages immediately — no per-person objects until camera approaches
				npc_village.deflate()
				villager_system.setup_village(npc_village)
			npc_placed += 1

	GameLog.info(LOG_TAG, "Villages placed: 1 player + %d/%d NPC villages (%d placement attempts)" % [
		npc_placed, NPC_VILLAGE_COUNT, attempts
	])


## Restore villages from saved data (returning to planet or loading save)
func _restore_villages(eid: String, data: Dictionary) -> void:
	var villages := village_manager.import_villages(eid, data)
	for village in villages:
		# Clear camp area and place longhouse surface features
		if village.active_site:
			_clear_camp_area(village.camp_position, eid, village.active_site.clearing_radius)
			for lh_pos in village.get_all_longhouse_positions():
				_update_surface_feature_at(lh_pos)
		# Set up villager sprites
		if villager_system:
			villager_system.setup_village(village)
	# Restore visited tiles for territory overlay
	if villager_system:
		var visited_data: Dictionary = data.get("visited_tiles", {})
		for vid in visited_data:
			var tiles = visited_data[vid]
			if tiles is Array:
				for pos_data in tiles:
					if not villager_system._visited_tiles.has(vid):
						villager_system._visited_tiles[vid] = {}
					villager_system._visited_tiles[vid][Vector2i(pos_data.get("x", 0), pos_data.get("y", 0))] = true
	GameLog.info(LOG_TAG, "Restored %d villages for planet %s" % [villages.size(), eid])


## Find a grass tile near target_pos suitable for a village camp.
## Rejects positions within MIN_CAMP_SPACING of any camp in existing_camps.
## Returns Vector2i(-1,-1) if no valid position found within search radius.
func _find_village_camp_position(target_pos: Vector2i, offset_seed: int, existing_camps: Array[Vector2i] = [], claimed_water: Array[Vector2i] = []) -> Vector2i:
	var map_size = map_data.map_size if map_data else Vector2i(64, 64)
	for radius in range(0, 20):
		for dx in range(-radius, radius + 1):
			for dy in range(-radius, radius + 1):
				if abs(dx) != radius and abs(dy) != radius:
					continue
				var check = target_pos + Vector2i(dx + offset_seed, dy)
				check = check.clamp(Vector2i(1, 1), map_size - Vector2i(2, 2))

				# Tile type + elevation check — supports both standard and chunk maps
				var is_grass := false
				var elevation := 0.0
				if using_chunks and chunk_manager and chunk_manager.terrain_source:
					var t = chunk_manager.terrain_source.get_tile_type_at_tile(check)
					elevation = chunk_manager.terrain_source.get_elevation_at_tile(check)
					is_grass = (t == PlanetMapTileConfig.TileType.GRASS_0 or
						t == PlanetMapTileConfig.TileType.GRASS_1 or
						t == PlanetMapTileConfig.TileType.GRASS_2)
				else:
					var tile = get_tile_at(check)
					if tile == null:
						continue
					elevation = tile.elevation
					is_grass = (tile.type == PlanetMapTileConfig.TileType.GRASS_0 or
						tile.type == PlanetMapTileConfig.TileType.GRASS_1 or
						tile.type == PlanetMapTileConfig.TileType.GRASS_2)

				if is_grass and elevation < 0.6:
					# Enforce minimum spacing from all placed camps
					var valid := true
					for camp in existing_camps:
						if Vector2(check).distance_to(Vector2(camp)) < MIN_CAMP_SPACING:
							valid = false
							break
					if not valid:
						continue

					# Reject positions too far from water — villagers starve on long trips
					var water := _find_nearest_water_tile(check, claimed_water, MAX_WATER_DISTANCE, true)
					if water == Vector2i(-1, -1):
						continue

					return check

	# Fallback: return target clamped to map (only used when existing_camps is empty,
	# i.e. player village — NPC placement returns -1,-1 and retries with a new candidate)
	if existing_camps.is_empty():
		return target_pos.clamp(Vector2i(1, 1), map_size - Vector2i(2, 2))
	return Vector2i(-1, -1)


## Place water, berry, and firewood resource tiles near the camp.
## territory_radius caps how far the village searches for berries and firewood,
## keeping resource zones from heavily overlapping between nearby villages.
func _assign_resource_positions(village: VillageInstance, claimed_water: Array[Vector2i] = [], territory_radius: int = 120) -> void:
	var c := village.camp_position
	village.water_pos    = _find_nearest_water_tile(c, claimed_water)
	village.berry_pos    = find_next_berry(c, territory_radius)
	village.firewood_pos = _find_nearest_dead_tree_raw(c, mini(territory_radius, 80))


## Find the nearest FRESH_WATER tile to center by true Euclidean distance.
## Searches expanding circles (radius doubles each pass) until water is found.
## Skips any tile in claimed to ensure each village gets a distinct water point.
## Returns Vector2i(-1, -1) if none found within max_radius.
func _find_nearest_water_tile(center: Vector2i, claimed: Array[Vector2i] = [], max_radius: int = 300, silent: bool = false) -> Vector2i:
	if not chunk_manager or not chunk_manager.terrain_source:
		return Vector2i(-1, -1)
	var source = chunk_manager.terrain_source
	var search_radius := mini(25, max_radius)  # Start small, expand
	while search_radius <= max_radius:
		var candidates: Array = []
		for dx in range(-search_radius, search_radius + 1):
			for dy in range(-search_radius, search_radius + 1):
				var sq_dist := dx * dx + dy * dy
				if sq_dist > search_radius * search_radius:
					continue  # Circular scan, not square
				var check := center + Vector2i(dx, dy)
				if claimed.has(check):
					continue
				if source.get_tile_type_at_tile(check) == PlanetMapTileConfig.TileType.FRESH_WATER:
					candidates.append([sq_dist, check])
		if not candidates.is_empty():
			candidates.sort_custom(func(a, b): return a[0] < b[0])
			return candidates[0][1]
		search_radius *= 2
	if not silent:
		GameLog.warn(LOG_TAG, "No water tile found within %d tiles of camp %s" % [max_radius, center])
	return Vector2i(-1, -1)


## Find the nearest raspberry bush position to center, searching outward.
## Uses the same deterministic hash check as the understory pass in _populate_chunk_forest.
## Public — also called by VillagerSystem when a bush is depleted and village must retarget.
func find_next_berry(center: Vector2i, max_radius: int = 120) -> Vector2i:
	# Guard against invalid/origin center — no point scanning from map edge
	if center.x <= 5 or center.y <= 5:
		return center + Vector2i(2, 5)
	# Cap search radius to prevent runaway spiral searches
	max_radius = mini(max_radius, 120)
	var eid := planet_id if planet_id != "" else str(current_planet.get_instance_id()) if current_planet else ""
	for radius in range(3, max_radius + 1):
		for dx in range(-radius, radius + 1):
			for dy in range(-radius, radius + 1):
				if abs(dx) != radius and abs(dy) != radius:
					continue
				var check := center + Vector2i(dx, dy)
				if check.x < 0 or check.y < 0:
					continue
				if village_manager and eid != "" and village_manager.is_in_village_area(eid, check):
					continue
				if using_chunks and chunk_manager and chunk_manager.terrain_source:
					var t := chunk_manager.terrain_source.get_tile_type_at_tile(check)
					if t == PlanetMapTileConfig.TileType.FRESH_WATER:
						continue
				# Skip permanently depleted positions
				if _depleted_positions.has(check):
					continue
				# Only target dead-tree positions — high raspberry density, clearly visible
				if ForestSpecies.is_dead_tree_position(check) and \
						ForestSpecies.is_raspberry_position(check, ForestSpecies.RASPBERRY_CHANCE_DEAD):
					return check
	GameLog.debug(LOG_TAG, "No raspberry position found near %s within radius %d" % [center, max_radius])
	return center + Vector2i(2, 5)  # fallback


## Find the nearest ForestSpecies dead-tree position to center, searching outward.
## Excludes the 5×5 camp clearing, water tiles, and already-depleted positions.
## Returns the fallback offset if nothing is found within max_radius.
func _find_nearest_dead_tree_raw(center: Vector2i, max_radius: int = 80) -> Vector2i:
	if center.x <= 5 or center.y <= 5:
		return center + Vector2i(3, 3)
	max_radius = mini(max_radius, 80)
	var eid := planet_id if planet_id != "" else str(current_planet.get_instance_id()) if current_planet else ""
	for radius in range(5, max_radius + 1):
		for dx in range(-radius, radius + 1):
			for dy in range(-radius, radius + 1):
				if abs(dx) != radius and abs(dy) != radius:
					continue
				var check := center + Vector2i(dx, dy)
				if check.x < 0 or check.y < 0:
					continue
				# Skip the cleared camp area
				if village_manager and eid != "" and village_manager.is_in_village_area(eid, check):
					continue
				# Skip previously depleted positions
				if _depleted_positions.has(check):
					continue
				# Skip water
				if using_chunks and chunk_manager and chunk_manager.terrain_source:
					var t := chunk_manager.terrain_source.get_tile_type_at_tile(check)
					if t == PlanetMapTileConfig.TileType.FRESH_WATER:
						continue
				if ForestSpecies.is_dead_tree_position(check):
					return check
	GameLog.debug(LOG_TAG, "No dead tree found near %s within radius %d" % [center, max_radius])
	return center + Vector2i(-4, 1)  # fallback to old fixed offset


## Called by VillagerSystem each time a villager completes a firewood gathering trip.
## Decrements the wood supply at pos. When exhausted, removes the visual sprite and
## returns the next nearest dead tree position for the village to retarget.
## Returns pos if wood remains, or a new Vector2i if the tree is depleted.
func collect_firewood_at(pos: Vector2i, camp_pos: Vector2i) -> Vector2i:
	# Lazy-initialize supply for this position from ForestSpecies data
	if not _deadwood_supply.has(pos):
		var dead_result := ForestSpecies.pick_dead_tile(pos)
		_deadwood_supply[pos] = dead_result[1]  # wood yield (armloads)

	_deadwood_supply[pos] -= 1

	if _deadwood_supply[pos] > 0:
		return pos  # Still has wood — stay on same tree

	# Tree fully depleted
	_deadwood_supply.erase(pos)
	_depleted_positions[pos] = true
	remove_tree_at(pos)
	GameLog.info(LOG_TAG, "Dead tree depleted at %s — searching for next" % pos)

	var next_pos := _find_nearest_dead_tree_raw(camp_pos)
	return next_pos


## Update smoke emission rate for the longhouse at camp_grid.
## factor 0.0 = no smoke, 1.0 = full smoke (mirrors firewood_stored).
func update_longhouse_smoke(camp_grid: Vector2i, factor: float) -> void:
	if not chunk_manager:
		return
	var chunk_pos := Vector2i(camp_grid.x >> 6, camp_grid.y >> 6)
	var local_pos := Vector2i(
		camp_grid.x % ChunkTileData.CHUNK_SIZE,
		camp_grid.y % ChunkTileData.CHUNK_SIZE
	)
	var chunk_visual: ChunkTileMapGroup = chunk_manager.get_chunk_visual(chunk_pos)
	if chunk_visual:
		chunk_visual.set_smoke_rate(local_pos, factor)


## Returns berry bush state at a world position for the info panel.
## has_bush: tile deterministically has a raspberry; picks_remaining: 0 when stripped.
func get_berry_info(pos: Vector2i) -> Dictionary:
	var is_dead := ForestSpecies.is_dead_tree_position(pos)
	var chance := ForestSpecies.RASPBERRY_CHANCE_DEAD if is_dead else ForestSpecies.RASPBERRY_CHANCE_LIVE
	if not ForestSpecies.is_raspberry_position(pos, chance):
		return {"has_bush": false, "picks_remaining": 0, "regrowing": false}
	if _depleted_positions.has(pos):
		var regrowing := _berry_regrowth_timers.has(pos)
		return {"has_bush": true, "picks_remaining": 0, "regrowing": regrowing}
	var picks: int = _berry_supply.get(pos, BERRY_MAX_PICKS)
	return {"has_bush": true, "picks_remaining": picks, "regrowing": false}


## Returns true if pos has a harvestable raspberry bush (not depleted).
func has_berry_at(pos: Vector2i) -> bool:
	if _depleted_positions.has(pos):
		return false
	if _is_water_tile(pos):
		return false
	var is_dead := ForestSpecies.is_dead_tree_position(pos)
	var chance := ForestSpecies.RASPBERRY_CHANCE_DEAD if is_dead else ForestSpecies.RASPBERRY_CHANCE_LIVE
	return ForestSpecies.is_raspberry_position(pos, chance)


## Returns true if pos has a dead tree available for firewood (not already depleted).
func has_dead_tree_at(pos: Vector2i) -> bool:
	if _depleted_positions.has(pos):
		return false
	if _is_water_tile(pos):
		return false
	return ForestSpecies.is_dead_tree_position(pos)


## Check if a tile is water (resources cannot exist on water).
func _is_water_tile(pos: Vector2i) -> bool:
	if not chunk_manager or not chunk_manager.terrain_source:
		return false
	return chunk_manager.terrain_source.get_tile_type_at_tile(pos) == PlanetMapTileConfig.TileType.FRESH_WATER


## Public wrapper for water tile check (used by TerrainPathfinder).
func is_water_tile(pos: Vector2i) -> bool:
	return _is_water_tile(pos)


## Called by VillagerSystem when a villager completes a berry gathering trip.
## Returns true if the bush had berries (food awarded), false if already stripped.
## Depleted bushes are permanently removed — same behaviour as dead trees.
func collect_berry_at(pos: Vector2i) -> bool:
	if _depleted_positions.has(pos):
		return false  # already stripped

	if not _berry_supply.has(pos):
		_berry_supply[pos] = BERRY_MAX_PICKS

	_berry_supply[pos] -= 1

	if _berry_supply[pos] > 0:
		return true

	# Bush stripped bare — hide sprite and start regrowth timer
	_berry_supply.erase(pos)
	_depleted_positions[pos] = true
	_berry_regrowth_timers[pos] = BERRY_REGROWTH_TICKS
	_set_understory_visible(pos, false)
	return true  # last pick still awards food


func is_berry_depleted(pos: Vector2i) -> bool:
	return _depleted_positions.has(pos)


## Tick handler — advance berry regrowth timers and restore depleted bushes.
func on_simulation_tick(_tick: int, _days: float) -> void:
	var restored: Array[Vector2i] = []
	for pos in _berry_regrowth_timers:
		_berry_regrowth_timers[pos] -= 1
		if _berry_regrowth_timers[pos] <= 0:
			restored.append(pos)

	for pos in restored:
		_berry_regrowth_timers.erase(pos)
		_depleted_positions.erase(pos)
		_berry_supply[pos] = BERRY_MAX_PICKS
		_set_understory_visible(pos, true)


## Show or hide the understory sprite at a world position.
func _set_understory_visible(pos: Vector2i, p_visible: bool) -> void:
	if not using_chunks or not chunk_manager:
		return
	var chunk_pos_local := Vector2i(
		floori(float(pos.x) / ChunkTileData.CHUNK_SIZE),
		floori(float(pos.y) / ChunkTileData.CHUNK_SIZE)
	)
	var local_pos := Vector2i(
		pos.x % ChunkTileData.CHUNK_SIZE,
		pos.y % ChunkTileData.CHUNK_SIZE
	)
	var chunk_visual = chunk_manager.get_chunk_visual(chunk_pos_local)
	if not chunk_visual:
		return
	if p_visible:
		chunk_visual.update_understory_at(local_pos, ForestSpecies.RASPBERRY_BUSH)
	else:
		chunk_visual.remove_understory_at(local_pos)



## Remove all trees in a clearing around the camp so the village has cleared ground.
## radius defaults to 4 (9x9 area). SettlementSite.clearing_radius grows with longhouse count.
func _clear_camp_area(camp: Vector2i, eid: String, radius: int = 4) -> void:
	if ecosystem_manager == null:
		return
	for dx in range(-radius, radius + 1):
		for dy in range(-radius, radius + 1):
			var pos := camp + Vector2i(dx, dy)
			if ecosystem_manager.get_tree_at(eid, pos) == null:
				continue
			ecosystem_manager.remove_tree_at(eid, pos)
			if using_chunks and chunk_manager:
				var chunk_pos := Vector2i(pos.x >> 6, pos.y >> 6)
				var local_pos := pos - chunk_pos * ChunkTileData.CHUNK_SIZE
				var chunk: ChunkTileMapGroup = chunk_manager.loaded_chunks.get(chunk_pos, null)
				if chunk:
					chunk.remove_tree_at(local_pos)
			else:
				_update_surface_feature_at(pos)


## Build a territory footprint of radius tiles around a center position
func _build_territory(center: Vector2i, radius: int) -> Array[Vector2i]:
	var territory: Array[Vector2i] = []
	var map_size = map_data.map_size if map_data else Vector2i(64, 64)
	for dx in range(-radius, radius + 1):
		for dy in range(-radius, radius + 1):
			var pos = (center + Vector2i(dx, dy)).clamp(Vector2i.ZERO, map_size - Vector2i(1, 1))
			if not territory.has(pos):
				territory.append(pos)
	return territory


# Set up ecosystem simulation for the generated map
func _setup_ecosystem(probe_results: Dictionary) -> void:
	if ecosystem_manager == null:
		return
	var eid = planet_id if planet_id != "" else str(current_planet.get_instance_id())

	# Check if we have saved tree state from a previous visit
	var initial_trees: Array[TreeInstance] = []
	if probe_system and planet_id != "":
		var pdata = probe_system.discovered_planets.get(planet_id, {})
		var saved = pdata.get("ecosystem_trees", null)
		if saved != null and saved.size() > 0:
			initial_trees = _deserialize_trees(saved)
			GameLog.info(LOG_TAG, "Restored %d trees from saved ecosystem state for planet %s" % [initial_trees.size(), planet_id])
		else:
			GameLog.info(LOG_TAG, "No saved ecosystem found for planet %s - will extract from tiles" % planet_id)

		# Restore removed tree positions
		var removed_data = pdata.get("removed_tree_positions", [])
		for entry in removed_data:
			_removed_tree_positions[Vector2i(int(entry.x), int(entry.y))] = true

		# Restore depleted positions
		var depleted_data = pdata.get("depleted_positions", [])
		for entry in depleted_data:
			_depleted_positions[Vector2i(int(entry.x), int(entry.y))] = true

		# Restore berry regrowth timers
		var regrowth_data = pdata.get("berry_regrowth_timers", [])
		for entry in regrowth_data:
			_berry_regrowth_timers[Vector2i(int(entry.x), int(entry.y))] = int(entry.ticks)

	if initial_trees.is_empty():
		initial_trees = _extract_trees_from_tiles(map_tiles)
		GameLog.info(LOG_TAG, "Extracted %d trees from tile surface features" % initial_trees.size())

	ecosystem_manager.register_planet(eid, initial_trees, map_tiles, probe_results)
	GameLog.info(LOG_TAG, "Ecosystem set up with %d trees" % initial_trees.size())

# Extract TreeInstance objects from tiles that have surface features
func _extract_trees_from_tiles(tiles: Array) -> Array[TreeInstance]:
	var trees: Array[TreeInstance] = []
	for x in range(PlanetMapTileConfig.MAP_SIZE.x):
		if x >= tiles.size():
			continue
		var row = tiles[x]
		if row == null:
			continue
		for y in range(PlanetMapTileConfig.MAP_SIZE.y):
			if y >= row.size():
				continue
			var tile = row[y]
			if tile == null or not tile is MapTile:
				continue
			if tile.surface_feature_type != null:
				var tree = TreeInstance.new()
				tree.position = Vector2i(x, y)
				tree.species = tile.surface_feature_type
				tree.growth_stage = TreeInstance.GrowthStage.MATURE  # Start trees from map gen as mature
				tree.health = 1.0
				# Age and thresholds will be initialized by EcosystemManager.register_planet()
				# Start at mature age (will be calculated based on species config)
				tree.age_in_ticks = 0  # Will be overridden after initialization
				trees.append(tree)
	return trees

# Serialize trees to a plain Array of Dictionaries for storage in probe_system
func _serialize_trees(trees: Array) -> Array:
	var result := []
	for tree in trees:
		result.append({
			"px": tree.position.x, "py": tree.position.y,
			"species": tree.species,
			"stage": int(tree.growth_stage),
			"age": tree.age_in_ticks,
			"health": tree.health,
			"seed_prod": tree.seed_production,
			"thresholds": tree._thresholds,  # Save thresholds to preserve growth rates
			"v_off_x": tree.visual_offset.x,  # Save visual offset for consistent placement
			"v_off_y": tree.visual_offset.y,
			"v_scale": tree.visual_scale      # Save scale for elevation-based sizing
		})
	return result

# Deserialize trees from stored Array of Dictionaries
func _deserialize_trees(data: Array) -> Array[TreeInstance]:
	var trees: Array[TreeInstance] = []
	for d in data:
		var tree = TreeInstance.new()
		tree.position = Vector2i(int(d.get("px", 0)), int(d.get("py", 0)))
		tree.species = int(d.get("species", 0))
		tree.growth_stage = int(d.get("stage", 0)) as TreeInstance.GrowthStage
		tree.age_in_ticks = int(d.get("age", 0))
		tree.health = float(d.get("health", 1.0))
		tree.seed_production = float(d.get("seed_prod", 0.0))

		# Restore thresholds if saved, otherwise will be initialized by EcosystemManager
		var saved_thresholds = d.get("thresholds", [])
		if saved_thresholds is Array and saved_thresholds.size() > 0:
			tree._thresholds.clear()  # Clear instead of reassign (preserves typed array)
			for t in saved_thresholds:
				tree._thresholds.append(int(t))

		# Restore visual properties for consistent appearance
		tree.visual_offset = Vector2(float(d.get("v_off_x", 0.0)), float(d.get("v_off_y", 0.0)))
		tree.visual_scale = float(d.get("v_scale", 1.0))

		trees.append(tree)
	return trees

# Connect TimeManager so ecosystem receives ticks (call after adding to scene tree)
func connect_time_manager(time_manager: TimeManager) -> void:
	if ecosystem_manager and time_manager:
		if not time_manager.simulation_tick.is_connected(ecosystem_manager.on_simulation_tick):
			time_manager.simulation_tick.connect(ecosystem_manager.on_simulation_tick)
	if village_manager and time_manager:
		if not time_manager.simulation_tick.is_connected(village_manager.on_simulation_tick):
			time_manager.simulation_tick.connect(village_manager.on_simulation_tick)
	# Wire village death/collapse signals
	if villager_system and village_manager:
		if not villager_system.villager_died.is_connected(_on_villager_died):
			villager_system.villager_died.connect(_on_villager_died)
		if not village_manager.village_collapsed.is_connected(_on_village_collapsed):
			village_manager.village_collapsed.connect(_on_village_collapsed)
		if not village_manager.person_died.is_connected(villager_system.on_person_died):
			village_manager.person_died.connect(villager_system.on_person_died)
		if not village_manager.person_born.is_connected(villager_system.on_person_born):
			village_manager.person_born.connect(villager_system.on_person_born)
		if not village_manager.longhouse_added.is_connected(_on_longhouse_added):
			village_manager.longhouse_added.connect(_on_longhouse_added)
		if not village_manager.longhouse_removed.is_connected(_on_longhouse_removed):
			village_manager.longhouse_removed.connect(_on_longhouse_removed)
		if not village_manager.village_relocated.is_connected(_on_village_relocated):
			village_manager.village_relocated.connect(_on_village_relocated)
		if not village_manager.site_regrown.is_connected(_on_site_regrown):
			village_manager.site_regrown.connect(_on_site_regrown)
		if not village_manager.village_split.is_connected(_on_village_split):
			village_manager.village_split.connect(_on_village_split)
	if time_manager:
		if not time_manager.simulation_tick.is_connected(on_simulation_tick):
			time_manager.simulation_tick.connect(on_simulation_tick)

func _on_villager_died(p_village_id: String, person_name: String) -> void:
	if village_manager:
		village_manager.emit_signal("person_died", p_village_id, person_name)


func _on_village_collapsed(p_village_id: String) -> void:
	if villager_system:
		villager_system.remove_village(p_village_id)


func _on_village_relocated(p_village_id: String, old_center: Vector2i, new_center: Vector2i) -> void:
	var eid = planet_id if planet_id != "" else ""
	if eid == "":
		return
	var village = village_manager.get_village(p_village_id) if village_manager else null
	if not village or not village.active_site:
		return

	# Remove old longhouse features and stamp ruin sprites
	# (check past_sites for the just-abandoned site to get its longhouse positions)
	for site in village.past_sites:
		if site.center == old_center and site.status == SettlementSite.Status.ABANDONED:
			for lh_pos in site.longhouse_positions:
				_on_longhouse_removed(p_village_id, lh_pos)
				_stamp_ruin_at(lh_pos)
			# Enable regrowth at old site: remove positions from _removed_tree_positions
			for dx in range(-site.clearing_radius, site.clearing_radius + 1):
				for dy in range(-site.clearing_radius, site.clearing_radius + 1):
					var pos := old_center + Vector2i(dx, dy)
					_removed_tree_positions.erase(pos)
			break

	# Clear new area and stamp new longhouses
	_clear_camp_area(new_center, eid, village.active_site.clearing_radius)
	for lh_pos in village.active_site.longhouse_positions:
		_update_surface_feature_at(lh_pos)
		if using_chunks and chunk_manager:
			var chunk_pos := Vector2i(lh_pos.x >> 6, lh_pos.y >> 6)
			var local_pos: Vector2i = lh_pos - chunk_pos * ChunkTileData.CHUNK_SIZE
			var chunk_data: ChunkTileData = chunk_manager.get_chunk_data(chunk_pos)
			if chunk_data:
				chunk_data.set_feature(local_pos, GeneratedTileTypes.TileType.TILE_R2_C11)
			var chunk_visual: ChunkTileMapGroup = chunk_manager.loaded_chunks.get(chunk_pos, null)
			if chunk_visual:
				chunk_visual.add_structure_at(local_pos, GeneratedTileTypes.TileType.TILE_R2_C11)

	# Reassign resource positions
	var claimed_water: Array[Vector2i] = []
	for v in village_manager.get_villages_on_planet(eid):
		if v.village_id != p_village_id and v.water_pos != Vector2i(-1, -1):
			claimed_water.append(v.water_pos)
	_assign_resource_positions(village, claimed_water, VILLAGE_TERRITORY_RADIUS)

	# Re-setup villagers at new location
	if villager_system:
		villager_system.remove_village(p_village_id)
		villager_system.setup_village(village)

	GameLog.info(LOG_TAG, "Village %s relocated visuals from %s to %s" % [
		p_village_id, str(old_center), str(new_center)
	])


func _on_village_split(_parent_id: String, child_id: String) -> void:
	var eid = planet_id if planet_id != "" else ""
	if eid == "":
		return
	var child = village_manager.get_village(child_id) if village_manager else null
	if not child or not child.active_site:
		return
	# Clear area and stamp longhouses for the new village
	_clear_camp_area(child.camp_position, eid, child.active_site.clearing_radius)
	for lh_pos in child.get_all_longhouse_positions():
		_update_surface_feature_at(lh_pos)
		if using_chunks and chunk_manager:
			var chunk_pos := Vector2i(lh_pos.x >> 6, lh_pos.y >> 6)
			var local_pos: Vector2i = lh_pos - chunk_pos * ChunkTileData.CHUNK_SIZE
			var chunk_data: ChunkTileData = chunk_manager.get_chunk_data(chunk_pos)
			if chunk_data:
				chunk_data.set_feature(local_pos, GeneratedTileTypes.TileType.TILE_R2_C11)
			var chunk_visual: ChunkTileMapGroup = chunk_manager.loaded_chunks.get(chunk_pos, null)
			if chunk_visual:
				chunk_visual.add_structure_at(local_pos, GeneratedTileTypes.TileType.TILE_R2_C11)
	# Assign resources
	var claimed_water: Array[Vector2i] = []
	for v in village_manager.get_villages_on_planet(eid):
		if v.village_id != child_id and v.water_pos != Vector2i(-1, -1):
			claimed_water.append(v.water_pos)
	_assign_resource_positions(child, claimed_water, VILLAGE_TERRITORY_RADIUS)
	# Setup villager visuals
	if villager_system:
		villager_system.setup_village(child)


func _on_site_regrown(_p_village_id: String, _site_center: Vector2i, longhouse_positions: Array) -> void:
	for pos in longhouse_positions:
		_remove_ruin_at(pos)


## Place a darkened ruin sprite at a position (abandoned longhouse)
func _stamp_ruin_at(position: Vector2i) -> void:
	_ruin_positions[position] = true
	if using_chunks and chunk_manager:
		var chunk_pos := Vector2i(position.x >> 6, position.y >> 6)
		var local_pos: Vector2i = position - chunk_pos * ChunkTileData.CHUNK_SIZE
		var chunk_visual: ChunkTileMapGroup = chunk_manager.loaded_chunks.get(chunk_pos, null)
		if chunk_visual:
			chunk_visual.add_ruin_at(local_pos, GeneratedTileTypes.TileType.TILE_R2_C11)


## Remove a ruin sprite at a position (site regrown or returned to)
func _remove_ruin_at(position: Vector2i) -> void:
	_ruin_positions.erase(position)
	if using_chunks and chunk_manager:
		var chunk_pos := Vector2i(position.x >> 6, position.y >> 6)
		var local_pos: Vector2i = position - chunk_pos * ChunkTileData.CHUNK_SIZE
		var chunk_visual: ChunkTileMapGroup = chunk_manager.loaded_chunks.get(chunk_pos, null)
		if chunk_visual:
			chunk_visual.remove_structure_at(local_pos)


func _on_longhouse_added(p_village_id: String, position: Vector2i, new_clearing_radius: int) -> void:
	var eid = planet_id if planet_id != "" else ""
	if eid == "":
		return
	# Clear trees in newly expanded radius around the village center
	var village = village_manager.get_village(p_village_id) if village_manager else null
	if village and village.active_site:
		_clear_camp_area(village.active_site.center, eid, new_clearing_radius)
	# Stamp longhouse feature at new position
	if using_chunks and chunk_manager:
		var chunk_pos := Vector2i(position.x >> 6, position.y >> 6)
		var local_pos: Vector2i = position - chunk_pos * ChunkTileData.CHUNK_SIZE
		var chunk_data: ChunkTileData = chunk_manager.get_chunk_data(chunk_pos)
		if chunk_data:
			chunk_data.set_feature(local_pos, GeneratedTileTypes.TileType.TILE_R2_C11)
		var chunk_visual: ChunkTileMapGroup = chunk_manager.loaded_chunks.get(chunk_pos, null)
		if chunk_visual:
			chunk_visual.add_structure_at(local_pos, GeneratedTileTypes.TileType.TILE_R2_C11)
	else:
		_update_surface_feature_at(position)


func _on_longhouse_removed(_p_village_id: String, position: Vector2i) -> void:
	# Remove longhouse feature at position
	if using_chunks and chunk_manager:
		var chunk_pos := Vector2i(position.x >> 6, position.y >> 6)
		var local_pos: Vector2i = position - chunk_pos * ChunkTileData.CHUNK_SIZE
		var chunk_data: ChunkTileData = chunk_manager.get_chunk_data(chunk_pos)
		if chunk_data:
			chunk_data.set_feature(local_pos, null)
		var chunk_visual: ChunkTileMapGroup = chunk_manager.loaded_chunks.get(chunk_pos, null)
		if chunk_visual:
			chunk_visual.remove_structure_at(local_pos)
	else:
		_update_surface_feature_at(position)


# PERFORMANCE: Queue positions for deferred rendering - never blocks time system
func _on_trees_batch_updated(changed_positions: Array) -> void:
	# Just queue positions - actual rendering happens in _process()
	for pos in changed_positions:
		if not _pending_sprite_updates.has(pos):
			_pending_sprite_updates.append(pos)

# PERFORMANCE: Queue ground cover positions for deferred rendering
func _on_ground_cover_batch_updated(changed_positions: Array) -> void:
	# Queue ground cover positions for rendering in _process()
	for pos in changed_positions:
		if not _pending_sprite_updates.has(pos):
			_pending_sprite_updates.append(pos)

const REGION_CHECK_INTERVAL: float = 0.5  # Only check camera position every 0.5 seconds

func _process(delta: float) -> void:
	# Incremental chunk loading — runs during initial map reveal
	_process_chunk_load_queue()

	# Wind simulation — two overlapping sines for organic direction changes
	var t := Time.get_ticks_msec() * 0.001
	_wind_x = sin(t * 0.12) * 0.7 + sin(t * 0.031) * 0.3  # slow ~20-40s cycles

	# Wind direction is now computed inside palette_swap.gdshader from TIME,
	# so per-frame GDScript pushes are no longer needed.

	# Push wind drift to smoke emitters (throttled — gravity change is heavier)
	_wind_push_timer -= delta
	if _wind_push_timer <= 0.0:
		_wind_push_timer = 0.5
		if using_chunks and chunk_manager:
			var drift_x := _wind_x * 10.0  # scale to pixels/s^2
			for chunk_visual in chunk_manager.loaded_chunks.values():
				chunk_visual.set_wind_drift(drift_x)

	# Update chunk visibility based on camera position (skip during initial load to avoid interference)
	if _chunk_loading_state == ChunkLoadState.IDLE and using_chunks and chunk_manager and camera_controller and camera_controller.camera:
		# Convert camera global position to tile_manager local space
		var camera_local_pos = tile_manager.to_local(camera_controller.camera.global_position)
		chunk_manager.update_camera_position(camera_local_pos)
		chunk_manager.update_zoom(camera_controller.camera.zoom.x)

	if _pending_sprite_updates.is_empty():
		return

	# Process up to MAX_SPRITE_UPDATES_PER_FRAME this frame
	var processed := 0
	while processed < MAX_SPRITE_UPDATES_PER_FRAME and not _pending_sprite_updates.is_empty():
		var pos = _pending_sprite_updates.pop_front()
		_update_surface_feature_at(pos)
		processed += 1

func _update_surface_feature_at(grid_pos: Vector2i) -> void:
	var tile: MapTile = get_tile_at(grid_pos)
	if tile == null or tile_manager == null:
		return

	var eid = planet_id if planet_id != "" else str(current_planet.get_instance_id()) if current_planet else ""

	# PERFORMANCE: O(1) tree lookup
	var found_tree: TreeInstance = ecosystem_manager.get_tree_at(eid, grid_pos) if ecosystem_manager else null

	# PERFORMANCE: O(1) ground cover lookup
	var found_ground_cover: GroundCoverInstance = _get_ground_cover_at(eid, grid_pos)

	# Determine feature to display (village camps > trees > ground cover)
	var new_feature = null
	if village_manager and village_manager.has_village_at(eid, grid_pos):
		new_feature = GeneratedTileTypes.TileType.TILE_R2_C11
	elif found_tree != null:
		# Show tree tile based on growth stage
		var tile_id = MapleTreeTypes.get_tile_for_growth(found_tree.growth_stage, found_tree.age_in_ticks)
		if tile_id != -1:
			new_feature = tile_id
	elif found_ground_cover != null:
		# Show ground cover tile based on growth stage
		var visual_tile = found_ground_cover.get_visual_tile()
		if visual_tile != -1:
			new_feature = visual_tile

	tile.surface_feature_type = new_feature

	# Update sprites
	var target_elevation: int = tile.get_render_layer()  # Uses NUM_RENDER_LAYERS for precise elevation
	var sf_tilemap = tile_manager.ensure_surface_feature_layer(target_elevation)
	if sf_tilemap == null:
		return

	# PERFORMANCE: O(1) sprite lookup and removal using cache
	if _sprite_cache.has(grid_pos):
		var old_sprite = _sprite_cache[grid_pos]
		if is_instance_valid(old_sprite):
			old_sprite.queue_free()
		_sprite_cache.erase(grid_pos)

	# If there's a new feature, render it as a sprite
	if new_feature != null:
		_render_feature_sprite(tile, target_elevation, new_feature)

## Get ground cover at position (O(1) using ecosystem manager's position index)
func _get_ground_cover_at(eid: String, pos: Vector2i) -> GroundCoverInstance:
	if ecosystem_manager == null:
		return null
	# Access the position index directly (same pattern as trees)
	var pos_index: Dictionary = ecosystem_manager._ground_cover_by_position.get(eid, {})
	return pos_index.get(pos, null)

# Apply variant theme shader to a tree sprite.
# Uses the shared ShaderMaterial — no per-sprite duplicate.
# Brightness must be applied by the caller via sprite.modulate.
func _apply_variant_to_sprite(sprite: Sprite2D, tile_id: int, _brightness: float = 1.0) -> void:
	var vm = VariantManager.get_instance()
	if vm == null:
		return

	var current_theme = vm.get_current_theme()
	if current_theme == null or current_theme.name == "default":
		sprite.material = null
		return

	var veg_tile_ids: Array[int] = VariantManager.get_vegetative_tree_tile_ids()
	if not veg_tile_ids.has(tile_id):
		return

	var tree_material := vm.get_shared_tree_material()
	if tree_material != null:
		sprite.material = tree_material

# Signal handlers
func _on_tile_selected(tile: MapTile):
	tile_selected.emit(tile)

func _on_selection_cleared():
	pass

# Handle theme changes - reapply variant to all tree sprites
func _on_theme_changed(_theme_name: String) -> void:
	if tile_manager == null:
		return

	GameLog.info(LOG_TAG, "Theme changed to '%s', reapplying to tree sprites" % _theme_name)

	# Fetch the new shared material once (VariantManager already cleared its cache in set_theme)
	var vm := VariantManager.get_instance()
	var new_material: ShaderMaterial = vm.get_shared_tree_material() if vm else null

	# Update ecosystem sprites in the unified container
	var sprite_container = tile_manager.all_sprites_container
	if sprite_container and is_instance_valid(sprite_container):
		for child in sprite_container.get_children():
			if child is Sprite2D and child.has_meta("grid_pos"):
				var grid_pos = child.get_meta("grid_pos")
				var tile = get_tile_at(grid_pos)
				if tile and tile.surface_feature_type != null:
					var veg_ids: Array[int] = VariantManager.get_vegetative_tree_tile_ids()
					if veg_ids.has(tile.surface_feature_type):
						child.material = new_material

	# Update chunk tree MultiMesh materials
	if using_chunks and chunk_manager:
		for chunk_visual in chunk_manager.loaded_chunks.values():
			if not chunk_visual or not is_instance_valid(chunk_visual):
				continue
			chunk_visual.apply_tree_material(new_material)

# Save village state to probe_system so it survives this node being freed.
# Call this BEFORE the node is queue_free'd (e.g., when the user presses Back).
func save_village_state() -> void:
	if village_manager == null or planet_id == "" or probe_system == null:
		return
	# Sync runtime villager needs back to PersonInstance before exporting
	if villager_system:
		villager_system.sync_needs_to_persons()
	var eid = planet_id
	var village_data := village_manager.export_villages(eid)
	# Include visited tiles from villager system (for territory overlay)
	if villager_system:
		var visited_export: Dictionary = {}
		var all_visited := villager_system.get_all_visited_tiles()
		for vid in all_visited:
			var tiles: Array = []
			for pos: Vector2i in all_visited[vid]:
				tiles.append({"x": pos.x, "y": pos.y})
			visited_export[vid] = tiles
		village_data["visited_tiles"] = visited_export
	var pdata: Dictionary = probe_system.discovered_planets.get(eid, {})
	pdata["village_data"] = village_data
	probe_system.discovered_planets[eid] = pdata
	GameLog.info(LOG_TAG, "Saved %d villages to probe_system for planet %s" % [
		village_data.get("villages", []).size(), eid
	])

	# Save harvester state
	if harvester_manager:
		pdata["harvester_data"] = harvester_manager.export_harvesters(eid)
		probe_system.discovered_planets[eid] = pdata


# Save current ecosystem tree state to probe_system so it survives this node being freed.
# Call this BEFORE the node is queue_free'd (e.g., when the user presses Back).
func save_ecosystem_state() -> void:
	GameLog.info(LOG_TAG, "save_ecosystem_state() called - planet_id='%s', has_ecosystem=%s, has_probe_system=%s" % [planet_id, ecosystem_manager != null, probe_system != null])
	if ecosystem_manager == null:
		GameLog.warn(LOG_TAG, "Cannot save ecosystem: ecosystem_manager is NULL")
		return
	if planet_id == "":
		GameLog.warn(LOG_TAG, "Cannot save ecosystem: planet_id is empty string")
		return
	if probe_system == null:
		GameLog.warn(LOG_TAG, "Cannot save ecosystem: probe_system is NULL")
		return
	var trees = ecosystem_manager.get_trees_for_planet(planet_id)
	var serialized = _serialize_trees(trees)
	var pdata: Dictionary = probe_system.discovered_planets.get(planet_id, {})
	pdata["ecosystem_trees"] = serialized
	# Persist removed tree positions so chunk re-render skips them
	var removed_arr := []
	for pos in _removed_tree_positions:
		removed_arr.append({"x": pos.x, "y": pos.y})
	pdata["removed_tree_positions"] = removed_arr
	# Persist depleted positions (firewood/berry)
	var depleted_arr := []
	for pos in _depleted_positions:
		depleted_arr.append({"x": pos.x, "y": pos.y})
	pdata["depleted_positions"] = depleted_arr
	# Persist berry regrowth timers
	var regrowth_arr := []
	for pos in _berry_regrowth_timers:
		regrowth_arr.append({"x": pos.x, "y": pos.y, "ticks": _berry_regrowth_timers[pos]})
	pdata["berry_regrowth_timers"] = regrowth_arr
	probe_system.discovered_planets[planet_id] = pdata
	GameLog.info(LOG_TAG, "Saved %d trees to probe_system for planet %s" % [trees.size(), planet_id])

# Manually place a single tree at the specified position
# Returns true if successful, false if position is invalid or already occupied
func manually_place_tree(tile_pos: Vector2i, species: int = -1) -> bool:
	if ecosystem_manager == null or planet_id == "":
		GameLog.warn(LOG_TAG, "Cannot place tree: ecosystem not initialized")
		return false

	# Get the tile at this position
	var tile: MapTile = _get_tile_at_grid(tile_pos)
	if tile == null:
		GameLog.warn(LOG_TAG, "Cannot place tree at %s: no tile found" % tile_pos)
		return false

	# Check if it's grass (valid for tree placement)
	var is_grass = (tile.type == PlanetMapTileConfig.TileType.GRASS_0 or
		tile.type == PlanetMapTileConfig.TileType.GRASS_1 or
		tile.type == PlanetMapTileConfig.TileType.GRASS_2)

	if not is_grass:
		GameLog.warn(LOG_TAG, "Cannot place tree at %s: not grass terrain (type=%d)" % [tile_pos, tile.type])
		return false

	# Check if a tree already exists at this position
	var existing_tree = ecosystem_manager.get_tree_at(planet_id, tile_pos)
	if existing_tree != null:
		GameLog.warn(LOG_TAG, "Cannot place tree at %s: tree already exists" % tile_pos)
		return false

	# Choose a random species if not specified
	var tree_species = species
	if tree_species == -1:
		tree_species = [MapleTreeTypes.TR_MAPL_VG_1, MapleTreeTypes.TR_MAPL_VG_2, MapleTreeTypes.TR_MAPL_VG_3][randi() % 3]

	# Create new tree instance
	var new_tree = TreeInstance.new()
	new_tree.position = tile_pos
	new_tree.species = tree_species
	new_tree.growth_stage = TreeInstance.GrowthStage.SEEDLING
	new_tree.age_in_ticks = 0
	new_tree.health = 1.0

	# Add to ecosystem manager's tree array
	var trees = ecosystem_manager.get_trees_for_planet(planet_id)
	trees.append(new_tree)
	ecosystem_manager.trees_by_planet[planet_id] = trees

	# Update visual
	_update_surface_feature_at(tile_pos)

	# Emit signal
	ecosystem_manager.emit_signal("tree_planted", tile_pos, tree_species)

	GameLog.info(LOG_TAG, "Manually placed tree at %s (species=%d)" % [tile_pos, tree_species])
	return true

func _get_tile_at_grid(grid_pos: Vector2i) -> MapTile:
	"""Get tile from map_tiles 2D array by grid position."""
	if map_tiles.is_empty():
		return null
	if grid_pos.y < 0 or grid_pos.y >= map_tiles.size():
		return null
	var row = map_tiles[grid_pos.y]
	if grid_pos.x < 0 or grid_pos.x >= row.size():
		return null
	return row[grid_pos.x]

# Cleanup
func clear_map():
	# Unregister ecosystem before clearing
	if ecosystem_manager and planet_id != "":
		ecosystem_manager.unregister_planet(planet_id)
	map_tiles.clear()
	is_map_generated = false
	# Cancel any in-progress incremental chunk loading
	_chunk_loading_state = ChunkLoadState.IDLE
	_chunk_load_queue_visible.clear()
	_chunk_load_queue_preload.clear()
	_chunk_center = Vector2i(-999, -999)
	_chunk_total_visible = 0
	if tile_manager:
		tile_manager.clear_all_tiles()
	if selection_manager:
		selection_manager.clear_selection()
