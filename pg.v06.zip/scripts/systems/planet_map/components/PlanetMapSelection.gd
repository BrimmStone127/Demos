class_name PlanetMapSelection
extends Node2D

# Handles tile selection logic for planet map
# Manages picking, highlighting, and selection state
# Emits signals when tiles are selected

const LOG_TAG := "PLANET_MAP_SELECTION"

signal tile_selected(tile: MapTile)
signal selection_cleared()

var selected_tile: MapTile = null
var selection_highlight: Polygon2D = null

# References (set by parent system)
var map_tiles: Array = []  # 2D array of MapTiles
var layer_tilemaps: Array[TileMap] = []  # Reference to layer tilemaps for picking
var map_viewport: SubViewport = null  # Reference to viewport for coordinate conversion

func _ready():
	ensure_selection_highlight()

# Get tile at grid position
func get_tile_at(grid_pos: Vector2i) -> MapTile:
	if grid_pos.x < 0 or grid_pos.y < 0:
		return null
	if map_tiles == null or grid_pos.x >= map_tiles.size():
		return null
	var column = map_tiles[grid_pos.x]
	if column == null or grid_pos.y >= column.size():
		return null
	var tile = column[grid_pos.y]
	return tile if tile is MapTile else null

# Apply tile selection
func apply_tile_selection(tile: MapTile):
	if not tile or not is_instance_valid(tile):
		GameLog.warn(LOG_TAG, "apply_tile_selection: invalid tile")
		return
	selected_tile = tile
	GameLog.info(LOG_TAG, "apply_tile_selection: tile at %s, elevation %d, layer_tilemaps.size=%d" % [tile.position, tile.elevation, layer_tilemaps.size()])
	update_selection_highlight()
	tile_selected.emit(tile)

# Clear selection
func clear_selection():
	selected_tile = null
	hide_selection_highlight()
	selection_cleared.emit()

# Hide the selection highlight
func hide_selection_highlight():
	if selection_highlight and is_instance_valid(selection_highlight):
		selection_highlight.visible = false

# Ensure selection highlight polygon exists
func ensure_selection_highlight() -> Polygon2D:
	if selection_highlight and is_instance_valid(selection_highlight):
		return selection_highlight

	# Create a Polygon2D for drawing the selection highlight
	selection_highlight = Polygon2D.new()
	selection_highlight.name = "SelectionHighlight"
	selection_highlight.z_as_relative = false
	selection_highlight.visible = false
	# Use a bright color with transparency for the selection highlight
	selection_highlight.color = Color(0.2, 0.8, 1.0, 0.4)  # Cyan with transparency

	add_child(selection_highlight)
	GameLog.info(LOG_TAG, "ensure_selection_highlight: created highlight, parent=%s, self.in_tree=%s" % [str(get_parent()), is_inside_tree()])
	return selection_highlight

# Calculate the visual center position of a tile (where highlight/camera should be)
# This is the canonical calculation used by both highlight and camera positioning
func calculate_tile_visual_center(tile: MapTile) -> Vector2:
	if not tile:
		return Vector2.ZERO

	var tile_layer := tile.get_render_layer()
	var center: Vector2

	# Use the tile's actual render layer tilemap
	if layer_tilemaps.size() > tile_layer and layer_tilemaps[tile_layer] and is_instance_valid(layer_tilemaps[tile_layer]):
		center = layer_tilemaps[tile_layer].map_to_local(tile.position)
		center += layer_tilemaps[tile_layer].position
	else:
		# Fallback to manual calculation
		center = PlanetMapCoordinates.grid_to_world(tile.position)
		center.y -= tile_layer * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET

	return center

# Update the selection highlight to match selected tile
func update_selection_highlight():
	if not selected_tile:
		hide_selection_highlight()
		return

	var highlight = ensure_selection_highlight()
	if not highlight:
		GameLog.warn(LOG_TAG, "update_selection_highlight: could not ensure highlight")
		return

	# Use the canonical tile center calculation
	var center = calculate_tile_visual_center(selected_tile)

	# Create the diamond - same size for all (ground footprint is the same)
	var polygon_points := PackedVector2Array([
		center + Vector2(0, -PlanetMapTileConfig.TILE_OFFSET.y),      # Top
		center + Vector2(PlanetMapTileConfig.TILE_OFFSET.x, 0),       # Right
		center + Vector2(0, PlanetMapTileConfig.TILE_OFFSET.y),       # Bottom
		center + Vector2(-PlanetMapTileConfig.TILE_OFFSET.x, 0),      # Left
	])

	highlight.polygon = polygon_points
	# Fixed z-index that's guaranteed to be above all terrain (max z=2800) and trees (max z=3050)
	# but within Godot's limit of 4096. Using 3500 ensures visibility on all elevations.
	highlight.z_index = 3500
	highlight.visible = true
	highlight.show()

# Check if a point is inside a tile's diamond in tilemap space
func is_point_inside_tile_tilemap_space(point_local: Vector2, cell: Vector2i, tilemap: TileMap) -> bool:
	"""Check if a point (in TileMap local coordinates) is inside the given tile's diamond."""
	if cell.x < 0 or cell.y < 0:
		return false

	# Get tile center position from TileMap (this is in TileMap's local space)
	var center := tilemap.map_to_local(cell)

	# Define the diamond corners - same size for all
	var corners := PackedVector2Array([
		center + Vector2(0, -PlanetMapTileConfig.TILE_OFFSET.y),
		center + Vector2(PlanetMapTileConfig.TILE_OFFSET.x, 0),
		center + Vector2(0, PlanetMapTileConfig.TILE_OFFSET.y),
		center + Vector2(-PlanetMapTileConfig.TILE_OFFSET.x, 0),
	])

	return Geometry2D.is_point_in_polygon(point_local, corners)

# Pick a tile from a viewport point (returns tile and debug info)
func pick_tile_from_viewport_point(viewport_point: Vector2) -> Dictionary:
	var debug: Dictionary = {}
	if not map_viewport or not is_instance_valid(map_viewport):
		debug["error"] = "viewport_missing"
		return {"tile": null, "debug": debug}

	# Use Godot's canvas transform to properly convert viewport to world coordinates
	var canvas_transform := map_viewport.get_canvas_transform()
	var world_point := canvas_transform.affine_inverse() * viewport_point

	# Check layers from highest to lowest (top to bottom) to find clicked tile
	# This makes elevated tiles clickable
	for layer in range(PlanetMapTileConfig.NUM_RENDER_LAYERS - 1, -1, -1):
		# Skip if no tilemap for this layer
		if layer >= layer_tilemaps.size() or not layer_tilemaps[layer] or not is_instance_valid(layer_tilemaps[layer]):
			continue

		var tile_map_node = layer_tilemaps[layer]

		# Convert from world space to tilemap local space
		var tilemap_global_transform := tile_map_node.get_global_transform()
		var tilemap_local := tilemap_global_transform.affine_inverse() * world_point

		var tilemap_cell := tile_map_node.local_to_map(tilemap_local)

		# For more precise hit detection, check neighboring cells
		var candidates: Array[Vector2i] = []

		# Calculate actual map bounds dynamically
		var map_width = map_tiles.size() if map_tiles != null else 0
		var map_height = (map_tiles[0].size() if map_tiles.size() > 0 and map_tiles[0] != null else 0)

		# Add the primary cell and its neighbors
		for dx in range(-1, 2):
			for dy in range(-1, 2):
				var candidate := Vector2i(tilemap_cell.x + dx, tilemap_cell.y + dy)
				if candidate.x >= 0 and candidate.y >= 0 and candidate.x < map_width and candidate.y < map_height:
					candidates.append(candidate)

		# Find the best matching tile using polygon hit testing
		var cell := Vector2i(-1, -1)
		for candidate in candidates:
			if is_point_inside_tile_tilemap_space(tilemap_local, candidate, tile_map_node):
				cell = candidate
				break

		# Fallback to the TileMap's primary result if no polygon match
		if cell == Vector2i(-1, -1):
			if tilemap_cell.x >= 0 and tilemap_cell.y >= 0 and tilemap_cell.x < map_width and tilemap_cell.y < map_height:
				cell = tilemap_cell

		# If we found a valid cell on this layer, check if it's the top layer for this tile
		if cell.x >= 0 and cell.y >= 0 and cell.x < map_width and cell.y < map_height:
			var tile := get_tile_at(cell)
			if tile:
				# Only return the tile if we're on its top layer (tile.get_render_layer() == layer)
				# This ensures we click the visible top surface, not lower layers
				if tile.get_render_layer() == layer:  # Uses NUM_RENDER_LAYERS default
					debug["viewport_point"] = viewport_point
					debug["layer_clicked"] = layer
					debug["cell"] = cell
					debug["tile_elevation"] = tile.elevation
					return {"tile": tile, "debug": debug}
				# If tile exists but we're not on its top layer, skip and continue checking lower layers

	# No tile found on any layer
	debug["error"] = "no_tile_hit"
	return {"tile": null, "debug": debug}

# Select a tile from viewport point (convenience method)
func select_tile_from_viewport_point(viewport_point: Vector2):
	var pick_result := pick_tile_from_viewport_point(viewport_point)
	if pick_result == null:
		return

	var tile: MapTile = pick_result.get("tile", null)
	if tile and is_instance_valid(tile):
		apply_tile_selection(tile)
		if PlanetMapTileConfig.ENABLE_PICK_DEBUG:
			GameLog.info(LOG_TAG, "Tile clicked at %s, %s" % [tile.position.x, tile.position.y])
	else:
		clear_selection()
		if PlanetMapTileConfig.ENABLE_PICK_DEBUG:
			GameLog.info(LOG_TAG, "Tile click ignored: no valid tile resolved")
