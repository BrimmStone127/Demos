class_name PlanetMapRenderer
extends RefCounted

# Handles all rendering logic for planet map tiles
# Creates textures, draws isometric tiles, applies colors and patterns
# Can be reused for sandbox or other isometric rendering needs

# Cache for generated textures
var tile_texture_cache: Dictionary = {}
var placeholder_texture_cache: Dictionary = {}

# Get a placeholder texture for a tile type (fallback when atlas not available)
func get_placeholder_texture(tile_type: PlanetMapTileConfig.TileType, size: Vector2, elevation: int = 0) -> ImageTexture:
	# Check cache first
	var cache_key = str(tile_type) + "_" + str(size) + "_" + str(elevation)
	if placeholder_texture_cache.has(cache_key):
		return placeholder_texture_cache[cache_key]

	# Create proper isometric placeholder tiles with elevation and shading
	var image = Image.create(int(size.x), int(size.y), false, Image.FORMAT_RGBA8)
	image.fill(Color.TRANSPARENT)

	# Get base color for tile type
	var base_color = get_tile_color(tile_type)

	# Apply elevation shading (higher = lighter)
	var elevation_factor = elevation / 10.0
	base_color = base_color.lightened(elevation_factor * 0.3)

	# Create isometric diamond shape
	var half_width = size.x * 0.5
	var half_height = size.y * 0.5

	for x in range(int(size.x)):
		for y in range(int(size.y)):
			if is_inside_isometric_diamond(x, y, half_width, half_height):
				# Add some simple shading
				var shade_factor = 1.0
				if y > half_height:  # Bottom half is darker
					shade_factor = 0.8

				var final_color = base_color * shade_factor
				final_color.a = 1.0
				image.set_pixel(x, y, final_color)

	var texture = ImageTexture.new()
	texture.set_image(image)

	# Cache it
	placeholder_texture_cache[cache_key] = texture
	return texture

# Get display color for a tile type (used by placeholder textures)
func get_tile_color(tile_type: PlanetMapTileConfig.TileType) -> Color:
	match tile_type:
		PlanetMapTileConfig.TileType.FRESH_WATER:
			return Color(0.08, 0.18, 0.45)
		PlanetMapTileConfig.TileType.ICE:
			return Color(0.8, 0.9, 1.0)  # Light blue-white
		PlanetMapTileConfig.TileType.POLAR_ICE:
			return Color(0.9, 0.95, 1.0)  # White
		PlanetMapTileConfig.TileType.ROCK:
			return Color(0.6, 0.5, 0.4)  # Brown-gray
		PlanetMapTileConfig.TileType.MOUNTAIN:
			return Color(0.5, 0.5, 0.5)  # Gray
		PlanetMapTileConfig.TileType.VOLCANIC:
			return Color(0.8, 0.3, 0.1)  # Red-orange
		PlanetMapTileConfig.TileType.CRATER:
			return Color(0.4, 0.4, 0.4)  # Dark gray
		PlanetMapTileConfig.TileType.DESERT:
			return Color(0.9, 0.8, 0.5)  # Sandy yellow
		PlanetMapTileConfig.TileType.FROZEN_SURFACE:
			return Color(0.7, 0.8, 0.9)  # Pale blue
		PlanetMapTileConfig.TileType.RIFT:
			return Color(0.3, 0.2, 0.2)  # Very dark
		PlanetMapTileConfig.TileType.PLAINS:
			return Color(0.5, 0.7, 0.3)  # Green
		PlanetMapTileConfig.TileType.HIGHLANDS:
			return Color(0.6, 0.6, 0.5)  # Light brown
		PlanetMapTileConfig.TileType.LOWLANDS:
			return Color(0.4, 0.6, 0.2)  # Dark green
		PlanetMapTileConfig.TileType.IMPACT_SITE:
			return Color(0.4, 0.3, 0.3)  # Dark brown
		PlanetMapTileConfig.TileType.GEOTHERMAL:
			return Color(0.9, 0.7, 0.2)  # Yellow-orange
		_:
			return Color(0.5, 0.5, 0.5)  # Default gray

# Get base color for tile rendering (used in procedural tile drawing)
func get_base_tile_color(tile_type: PlanetMapTileConfig.TileType) -> Color:
	match tile_type:
		PlanetMapTileConfig.TileType.FRESH_WATER:
			return Color(0.08, 0.18, 0.45)
		PlanetMapTileConfig.TileType.ICE:
			return Color(0.8, 0.9, 1.0)
		PlanetMapTileConfig.TileType.POLAR_ICE:
			return Color(0.9, 0.95, 1.0)
		PlanetMapTileConfig.TileType.ROCK:
			return Color(0.5, 0.4, 0.3)
		PlanetMapTileConfig.TileType.MOUNTAIN:
			return Color(0.6, 0.5, 0.4)
		PlanetMapTileConfig.TileType.VOLCANIC:
			return Color(0.8, 0.2, 0.1)
		PlanetMapTileConfig.TileType.CRATER:
			return Color(0.4, 0.3, 0.2)
		PlanetMapTileConfig.TileType.DESERT:
			return Color(0.9, 0.7, 0.4)
		PlanetMapTileConfig.TileType.FROZEN_SURFACE:
			return Color(0.7, 0.8, 0.9)
		PlanetMapTileConfig.TileType.RIFT:
			return Color(0.3, 0.2, 0.1)
		PlanetMapTileConfig.TileType.PLAINS:
			return Color(0.4, 0.6, 0.3)
		PlanetMapTileConfig.TileType.HIGHLANDS:
			return Color(0.6, 0.6, 0.5)
		PlanetMapTileConfig.TileType.LOWLANDS:
			return Color(0.3, 0.5, 0.3)
		PlanetMapTileConfig.TileType.IMPACT_SITE:
			return Color(0.5, 0.3, 0.3)
		PlanetMapTileConfig.TileType.GEOTHERMAL:
			return Color(0.7, 0.5, 0.2)
		_:
			return Color(0.5, 0.5, 0.5)

# Draw a complete isometric tile with elevation
func draw_isometric_tile(image: Image, base_size: Vector2, top_color: Color, left_color: Color, right_color: Color, elevation: int, tile_type: PlanetMapTileConfig.TileType):
	var half_width = base_size.x / 2.0
	var half_height = base_size.y / 2.0
	var elevation_offset = elevation * 4

	# Draw the tile from bottom to top to handle overlapping properly

	# 1. Draw elevation sides first (if elevated)
	if elevation > 0:
		draw_elevation_sides(image, half_width, half_height, elevation_offset, left_color, right_color)

	# 2. Draw the main isometric face
	draw_isometric_top(image, half_width, half_height, elevation_offset, top_color, tile_type)

# Draw the vertical sides of an elevated tile
func draw_elevation_sides(image: Image, half_width: float, half_height: float, elevation_offset: int, left_color: Color, right_color: Color):
	# Draw left side face
	for y in range(elevation_offset):
		var y_pos = int(half_height + y)
		if y_pos >= 0 and y_pos < image.get_height():
			for x in range(int(half_width)):
				var x_pos = x
				if x_pos >= 0 and x_pos < image.get_width():
					# Gradient effect on side face
					var fade = 1.0 - (float(x) / half_width) * 0.3
					var side_color = left_color * fade
					image.set_pixel(x_pos, y_pos, side_color)

	# Draw right side face
	for y in range(elevation_offset):
		var y_pos = int(half_height + y)
		if y_pos >= 0 and y_pos < image.get_height():
			for x in range(int(half_width), int(half_width * 2)):
				var x_pos = x
				if x_pos >= 0 and x_pos < image.get_width():
					# Gradient effect on side face
					var fade = 1.0 - (float(x - half_width) / half_width) * 0.3
					var side_color = right_color * fade
					image.set_pixel(x_pos, y_pos, side_color)

# Draw the top diamond face of an isometric tile
func draw_isometric_top(image: Image, half_width: float, half_height: float, elevation_offset: int, top_color: Color, tile_type: PlanetMapTileConfig.TileType):
	# Draw diamond-shaped top face
	for y in range(int(half_height * 2)):
		for x in range(int(half_width * 2)):
			if is_inside_isometric_diamond(x, y, half_width, half_height):
				var y_pos = y + elevation_offset
				if y_pos >= 0 and y_pos < image.get_height() and x >= 0 and x < image.get_width():
					var final_color = apply_tile_texture(top_color, x, y, half_width, half_height, tile_type)
					image.set_pixel(x, y_pos, final_color)

# Check if a point is inside the isometric diamond
func is_inside_isometric_diamond(x: int, y: int, half_width: float, half_height: float) -> bool:
	# Convert to diamond coordinates
	var dx = abs(x - half_width) / half_width
	var dy = abs(y - half_height) / half_height
	return (dx + dy) <= 1.0

# Apply texture patterns to a tile color based on tile type
func apply_tile_texture(base_color: Color, x: int, y: int, half_width: float, half_height: float, tile_type: PlanetMapTileConfig.TileType) -> Color:
	# Add simple texture patterns to make tiles more distinctive
	var color = base_color

	match tile_type:
		PlanetMapTileConfig.TileType.FRESH_WATER:
			# Water ripple effect
			var ripple = sin((x + y) * 0.3) * 0.1
			color = color.lightened(ripple)

		PlanetMapTileConfig.TileType.MOUNTAIN, PlanetMapTileConfig.TileType.HIGHLANDS:
			# Rocky texture with highlights
			if (x + y) % 3 == 0:
				color = color.lightened(0.2)
			elif (x + y) % 5 == 0:
				color = color.darkened(0.1)

		PlanetMapTileConfig.TileType.VOLCANIC:
			# Lava glow effect
			var center_dist = sqrt(pow(x - half_width, 2) + pow(y - half_height, 2))
			var glow = max(0, 1.0 - center_dist / (half_width * 0.5))
			color = color.lightened(glow * 0.3)
			# Add some red spots
			if (x * 3 + y * 7) % 11 == 0:
				color = Color(1.0, 0.3, 0.0)

		PlanetMapTileConfig.TileType.ICE, PlanetMapTileConfig.TileType.POLAR_ICE:
			# Crystalline effect
			if (x + y) % 4 == 0 or (x - y) % 4 == 0:
				color = color.lightened(0.3)

		PlanetMapTileConfig.TileType.DESERT:
			# Sand dune pattern
			var wave = sin(x * 0.2) * sin(y * 0.15) * 0.1
			color = color.lightened(wave)

		PlanetMapTileConfig.TileType.CRATER:
			# Darker center, lighter rim
			var center_dist = sqrt(pow(x - half_width, 2) + pow(y - half_height, 2))
			var rim_effect = center_dist / half_width
			if rim_effect > 0.7:
				color = color.lightened(0.2)  # Bright rim
			else:
				color = color.darkened(rim_effect * 0.3)  # Dark center

		PlanetMapTileConfig.TileType.PLAINS:
			# Subtle grass texture
			if (x * 2 + y) % 6 == 0:
				color = color.lightened(0.1)

		PlanetMapTileConfig.TileType.RIFT:
			# Deep shadow effect
			var center_dist = sqrt(pow(x - half_width, 2) + pow(y - half_height, 2))
			var depth_effect = 1.0 - (center_dist / half_width)
			color = color.darkened(depth_effect * 0.5)

		PlanetMapTileConfig.TileType.GEOTHERMAL:
			# Steam/heat shimmer
			var shimmer = sin((x + y) * 0.5) * 0.15
			color = color.lightened(abs(shimmer))
			# Add yellow/orange spots
			if (x * 5 + y * 3) % 13 == 0:
				color = Color(1.0, 0.8, 0.2)

	return color

# Clear all texture caches
func clear_caches():
	tile_texture_cache.clear()
	placeholder_texture_cache.clear()
