class_name PlanetMapTileManager
extends Node2D

# Manages TileMap layers for planet map rendering
# Handles elevation layers, surface features, and tileset configuration
# Can be attached to map content nodes

const LOG_TAG := "PLANET_MAP_TILE_MANAGER"

# Tileset version - increment this to force recreation of tilesets with new settings
const TILESET_VERSION := 6  # v6: Reverted to per-elevation TileMap rendering (simpler, actually works)

# TileMap management
var tile_map_tileset: TileSet = null
var tile_map_source_id: int = -1
var tileset_version: int = -1  # Version of currently cached tileset
var layer_tilemaps: Array[TileMap] = []  # One TileMap per elevation layer (terrain only)
var surface_features_tilemap: TileMap = null  # Dedicated TileMap for all surface features (renders on top)
var surface_feature_layer_tilemaps: Array[TileMap] = []  # One TileMap per elevation for surface features with vertical offset
var all_sprites_container: Node2D = null  # SINGLE container for ALL surface feature sprites (for proper y-sorting)
var tile_map: TileMap = null  # Legacy single layer (layer 0 reference)
var overlay_layer: Node2D = null  # For highlights, indicators
var feature_layer: Node2D = null  # For feature markers

# Initialize the tileset used by all TileMaps
func ensure_tilemap_tileset():
	# Check if we have a valid cached tileset with the correct version
	if tile_map_tileset and is_instance_valid(tile_map_tileset) and tile_map_source_id != -1 and tileset_version == TILESET_VERSION:
		return

	var tileset := TileSet.new()
	tileset.tile_shape = TileSet.TILE_SHAPE_ISOMETRIC
	var layout_value := -1
	# Use DIAMOND_DOWN for standard isometric layout with (0,0) at top
	if ClassDB.class_has_integer_constant("TileSet", "TILE_LAYOUT_DIAMOND_DOWN"):
		layout_value = ClassDB.class_get_integer_constant("TileSet", "TILE_LAYOUT_DIAMOND_DOWN")
	elif ClassDB.class_has_integer_constant("TileSet", "TILE_LAYOUT_DIAMOND_RIGHT"):
		layout_value = ClassDB.class_get_integer_constant("TileSet", "TILE_LAYOUT_DIAMOND_RIGHT")
	elif ClassDB.class_has_integer_constant("TileSet", "TILE_LAYOUT_STACKED"):
		layout_value = ClassDB.class_get_integer_constant("TileSet", "TILE_LAYOUT_STACKED")
	if layout_value != -1:
		@warning_ignore("int_as_enum_without_cast")
		tileset.tile_layout = layout_value
		GameLog.info(LOG_TAG, "TileSet layout set to: %s" % layout_value)
	tileset.tile_size = Vector2i(int(PlanetMapTileConfig.TILE_SIZE.x), int(PlanetMapTileConfig.TILE_SIZE.y))

	var atlas_source := TileSetAtlasSource.new()
	atlas_source.texture = PlanetMapTileConfig.TILESET_TEXTURE
	atlas_source.texture_region_size = PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE

	# Create tiles for ALL GeneratedTileTypes (200 tiles in 20x10 grid)
	# This ensures all maple tree assets (VG_1-6, DORM_1-6) are available
	for tile_type in GeneratedTileTypes.TILESET_REGION_MAP.keys():
		var coords: Vector2i = GeneratedTileTypes.TILESET_REGION_MAP[tile_type]
		if not atlas_source.has_tile(coords):
			atlas_source.create_tile(coords)

	tile_map_tileset = tileset
	tile_map_source_id = tile_map_tileset.add_source(atlas_source)
	tileset_version = TILESET_VERSION

# Get or create a TileMap for the specified elevation layer
func ensure_layer_tilemap(layer: int) -> TileMap:
	ensure_tilemap_tileset()
	if not tile_map_tileset or tile_map_source_id == -1:
		return null

	# Expand array if needed
	while layer_tilemaps.size() <= layer:
		layer_tilemaps.append(null)

	# Return existing tilemap if valid
	if layer_tilemaps[layer] and is_instance_valid(layer_tilemaps[layer]):
		return layer_tilemaps[layer]

	# Create new TileMap for this layer
	var tilemap = TileMap.new()
	tilemap.name = "Layer%dTileMap" % layer
	tilemap.y_sort_enabled = true
	# Use shared tileset for consistency and memory efficiency
	tilemap.tile_set = PlanetMapTileConfig.get_shared_tileset()
	# Set nearest-neighbor filtering for crisp pixels
	if tilemap.has_method("set_texture_filter"):
		tilemap.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

	# Position offset: higher layers move UP (negative Y)
	tilemap.position = Vector2(0, -layer * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET)

	# Higher layers should draw on top, so give them higher base z_index
	# Calculate spacing to fit NUM_RENDER_LAYERS within z_index limit
	# Max layer: 31, sprites at 3200, so max terrain z = 31 * 90 = 2790 (safe margin)
	const Z_INDEX_SPACING = 90  # Spacing between elevation layers (fits 32 layers under sprite z=3200)
	tilemap.z_index = layer * Z_INDEX_SPACING

	# TileMaps start with 1 layer (layer 0), we need to add layer 1 for surface features
	# Layer 0 = base terrain, Layer 1 = surface features (trees, vegetation)
	if tilemap.has_method("add_layer"):
		tilemap.add_layer(-1)  # Add layer 1 for surface features

	# Enable and configure terrain layer (layer 0)
	if tilemap.has_method("set_layer_enabled"):
		tilemap.set_layer_enabled(PlanetMapTileConfig.TILEMAP_LAYER_TERRAIN, true)
	if tilemap.has_method("set_layer_y_sort_enabled"):
		tilemap.set_layer_y_sort_enabled(PlanetMapTileConfig.TILEMAP_LAYER_TERRAIN, true)
	if tilemap.has_method("set_layer_y_sort_origin"):
		tilemap.set_layer_y_sort_origin(PlanetMapTileConfig.TILEMAP_LAYER_TERRAIN, int(PlanetMapTileConfig.TILE_SIZE.y))

	# Enable and configure surface features layer (layer 1)
	if tilemap.has_method("set_layer_enabled"):
		tilemap.set_layer_enabled(PlanetMapTileConfig.TILEMAP_LAYER_SURFACE_FEATURES, true)
	if tilemap.has_method("set_layer_y_sort_enabled"):
		tilemap.set_layer_y_sort_enabled(PlanetMapTileConfig.TILEMAP_LAYER_SURFACE_FEATURES, true)
	if tilemap.has_method("set_layer_y_sort_origin"):
		# Higher origin helps tall sprites (trees) sort in front of nearer tiles
		tilemap.set_layer_y_sort_origin(PlanetMapTileConfig.TILEMAP_LAYER_SURFACE_FEATURES, int(PlanetMapTileConfig.TILE_SIZE.y))

	# Apply layer darkening: lower layers are darker, higher layers are brighter
	var brightness = PlanetMapTileConfig.get_elevation_brightness(layer)
	tilemap.modulate = Color(brightness, brightness, brightness, 1.0)

	GameLog.debug(LOG_TAG, "Created TileMap for layer %d at position %s with z_index %d and brightness %.2f" % [layer, tilemap.position, tilemap.z_index, brightness])

	add_child(tilemap)
	layer_tilemaps[layer] = tilemap

	# Update legacy tile_map reference for layer 0
	if layer == 0:
		tile_map = tilemap

	return tilemap

# Get or create the dedicated surface features TileMap
# This TileMap renders ALL surface features on top of all elevation layers
func ensure_surface_features_tilemap() -> TileMap:
	ensure_tilemap_tileset()
	if not tile_map_tileset or tile_map_source_id == -1:
		return null

	# Return existing if valid
	if surface_features_tilemap and is_instance_valid(surface_features_tilemap):
		return surface_features_tilemap

	# Create new TileMap for surface features
	var tilemap = TileMap.new()
	tilemap.name = "SurfaceFeaturesTileMap"
	tilemap.y_sort_enabled = true
	# Use shared tileset for consistency and memory efficiency
	tilemap.tile_set = PlanetMapTileConfig.get_shared_tileset()
	# Set nearest-neighbor filtering for crisp pixels
	if tilemap.has_method("set_texture_filter"):
		tilemap.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

	# Position at y=0 (no elevation offset needed)
	tilemap.position = Vector2.ZERO

	# z_index above all elevation layer tilemaps (max layer*90 = 2790 for 32 layers)
	# Use 3200 to be safely above all terrain within Godot's limit of 4096
	tilemap.z_index = 3200

	GameLog.debug(LOG_TAG, "Created dedicated surface features TileMap with z_index %d" % tilemap.z_index)

	add_child(tilemap)
	surface_features_tilemap = tilemap

	return tilemap

# Create or get the overlay layer for highlights and indicators
func ensure_overlay_layer() -> Node2D:
	if overlay_layer and is_instance_valid(overlay_layer):
		if overlay_layer.get_parent() != self:
			if overlay_layer.get_parent():
				overlay_layer.get_parent().remove_child(overlay_layer)
			add_child(overlay_layer)
		return overlay_layer

	overlay_layer = Node2D.new()
	overlay_layer.name = "TileOverlayLayer"
	overlay_layer.z_index = 4000  # Above all tilemaps, within Godot's limit of 4096
	overlay_layer.z_as_relative = false
	overlay_layer.position = Vector2.ZERO

	add_child(overlay_layer)
	return overlay_layer

# Create or get the feature layer for special feature markers
func ensure_feature_layer() -> Node2D:
	var overlay_parent := ensure_overlay_layer()
	if not overlay_parent:
		return null

	if feature_layer and is_instance_valid(feature_layer):
		if feature_layer.get_parent() != overlay_parent:
			if feature_layer.get_parent():
				feature_layer.get_parent().remove_child(feature_layer)
			overlay_parent.add_child(feature_layer)
		return feature_layer

	feature_layer = Node2D.new()
	feature_layer.name = "FeatureOverlay"
	feature_layer.z_index = 100
	overlay_parent.add_child(feature_layer)
	return feature_layer

# Get or create a per-elevation TileMap for surface features with vertical lift
func ensure_surface_feature_layer(layer: int) -> TileMap:
	if layer < 0:
		return null
	ensure_tilemap_tileset()
	if not tile_map_tileset or tile_map_source_id == -1:
		return null

	while surface_feature_layer_tilemaps.size() <= layer:
		surface_feature_layer_tilemaps.append(null)

	if surface_feature_layer_tilemaps[layer] and is_instance_valid(surface_feature_layer_tilemaps[layer]):
		return surface_feature_layer_tilemaps[layer]

	var tilemap = TileMap.new()
	tilemap.name = "SurfaceFeaturesLayer%d" % layer
	tilemap.y_sort_enabled = true
	# Use shared tileset for consistency and memory efficiency
	tilemap.tile_set = PlanetMapTileConfig.get_shared_tileset()
	# Set nearest-neighbor filtering for crisp pixels
	if tilemap.has_method("set_texture_filter"):
		tilemap.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

	# Apply current theme's color variant to vegetative trees
	_apply_variant_theme(tilemap)

	# Position offset: Match elevation PLUS extra lift for tall sprites (trees)
	# This additional offset is needed for proper coordinate conversion in tile selection
	tilemap.position = Vector2(0, -layer * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET - PlanetMapTileConfig.SURFACE_FEATURE_LAYER_OFFSET_Y)

	# Z-index: All surface features use the SAME z-index (3200) so y-sort works across elevations
	# This is above all terrain layers (max terrain z = 7*400 = 2800)
	# Y-sorting will handle depth ordering based on visual position
	tilemap.z_index = 3200

	# Single layer (0) for features
	if tilemap.has_method("set_layer_enabled"):
		tilemap.set_layer_enabled(0, true)
	if tilemap.has_method("set_layer_y_sort_enabled"):
		tilemap.set_layer_y_sort_enabled(0, true)
	if tilemap.has_method("set_layer_y_sort_origin"):
		# CRITICAL: Use same y_sort_origin as terrain (TILE_SIZE.y = 80) for consistent depth sorting
		tilemap.set_layer_y_sort_origin(0, int(PlanetMapTileConfig.TILE_SIZE.y))

	add_child(tilemap)
	surface_feature_layer_tilemaps[layer] = tilemap
	return tilemap

# Ensure the single sprite container exists for ALL surface feature sprites
# This container holds all sprites regardless of elevation for proper cross-elevation y-sorting
func ensure_sprite_container() -> Node2D:
	if all_sprites_container and is_instance_valid(all_sprites_container):
		return all_sprites_container

	all_sprites_container = Node2D.new()
	all_sprites_container.name = "AllSurfaceFeatureSprites"
	all_sprites_container.y_sort_enabled = true
	# Z-index above all terrain layers (max terrain = 7*400 = 2800)
	all_sprites_container.z_index = 3200
	all_sprites_container.z_as_relative = false

	add_child(all_sprites_container)
	GameLog.info(LOG_TAG, "Created unified sprite container for cross-elevation y-sorting")
	return all_sprites_container

# Clear all tiles from all layers
func clear_all_tiles():
	# Clear all elevation layer TileMaps (each has terrain + surface feature layers)
	for tilemap in layer_tilemaps:
		if tilemap and is_instance_valid(tilemap):
			tilemap.clear()  # Clears all layers within this TileMap
	for sf_tilemap in surface_feature_layer_tilemaps:
		if sf_tilemap and is_instance_valid(sf_tilemap):
			sf_tilemap.clear()

	# Clear all sprites from the unified container
	if all_sprites_container and is_instance_valid(all_sprites_container):
		for child in all_sprites_container.get_children():
			child.queue_free()

	# Clear feature overlays (markers, highlights, etc)
	if feature_layer and is_instance_valid(feature_layer):
		for child in feature_layer.get_children():
			child.queue_free()

# Get the TileMap for a specific layer (null if not created yet)
func get_layer_tilemap(layer: int) -> TileMap:
	if layer < 0:
		return null
	if layer >= 0 and layer < layer_tilemaps.size():
		return layer_tilemaps[layer]
	return null

# Get all layer TileMaps
func get_all_layer_tilemaps() -> Array[TileMap]:
	return layer_tilemaps

# Apply current theme's variant to vegetative tiles on the tilemap
# Uses VariantManager for centralized theme management
func _apply_variant_theme(tilemap: TileMap) -> void:
	var vm = VariantManager.get_instance()
	var veg_tile_ids: Array[int] = VariantManager.get_vegetative_tree_tile_ids()
	vm.apply_theme_to_tilemap(tilemap, veg_tile_ids)
	GameLog.info(LOG_TAG, "Applied theme '%s' to tilemap '%s'" % [vm.get_current_theme_name(), tilemap.name])
