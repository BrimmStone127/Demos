class_name PlanetMapCamera
extends Node2D

# Camera controller for the planet map
# Handles panning, zooming, and keyboard/mouse controls
# Can be reused in sandbox or other isometric views

const LOG_TAG := "PLANET_MAP_CAMERA"

@onready var camera: Camera2D = null

# Camera configuration (can be overridden)
var keyboard_speed: float = PlanetMapTileConfig.CAMERA_KEYBOARD_SPEED
var zoom_min: Vector2 = PlanetMapTileConfig.CAMERA_ZOOM_MIN
var zoom_max: Vector2 = PlanetMapTileConfig.CAMERA_ZOOM_MAX
var zoom_step: float = PlanetMapTileConfig.CAMERA_ZOOM_STEP
var zoom_step_accel: float = PlanetMapTileConfig.CAMERA_ZOOM_STEP_ACCEL
var keyboard_zoom_rate: float = PlanetMapTileConfig.CAMERA_KEYBOARD_ZOOM_RATE

var is_active: bool = true  # Enable/disable camera control

func _ready():
	setup_camera()

func setup_camera(initial_zoom: Vector2 = Vector2(2.0, 2.0), initial_position: Vector2 = Vector2.ZERO):
	GameLog.info(LOG_TAG, "Setting up camera...")

	# Create camera if it doesn't exist
	if camera and is_instance_valid(camera):
		camera.queue_free()

	camera = Camera2D.new()
	camera.name = "PlanetCamera"
	camera.enabled = true

	# Camera pixel snapping DISABLED — causes tile shimmer at fractional zoom levels.
	# Crisp rendering handled by NEAREST texture_filter on individual TileMaps/Sprites.

	# Disable smoothing for responsive camera movement
	if camera.has_method("set_position_smoothing_enabled"):
		camera.position_smoothing_enabled = false
	elif camera.has_method("set_smoothing_enabled"):
		camera.smoothing_enabled = false
	if camera.has_method("set_rotation_smoothing_enabled"):
		camera.rotation_smoothing_enabled = false

	camera.zoom = initial_zoom
	camera.position = initial_position

	add_child(camera)

	GameLog.info(LOG_TAG, "Camera setup complete at %s with zoom %s" % [camera.position, camera.zoom])

func get_camera() -> Camera2D:
	if camera and is_instance_valid(camera):
		return camera
	# Try to find camera as child
	var cam_node = get_node_or_null("PlanetCamera")
	if cam_node and cam_node is Camera2D:
		camera = cam_node
		return camera
	return null

func clamp_zoom(zoom: Vector2) -> Vector2:
	return Vector2(
		clamp(zoom.x, zoom_min.x, zoom_max.x),
		clamp(zoom.y, zoom_min.y, zoom_max.y)
	)

func zoom_in(accelerated: bool = false):
	var cam = get_camera()
	if not cam:
		GameLog.warn(LOG_TAG, "Cannot zoom in: camera not initialized")
		return
	var step = zoom_step_accel if accelerated else zoom_step
	var next_zoom = cam.zoom * step
	cam.zoom = clamp_zoom(next_zoom)

func zoom_out(accelerated: bool = false):
	var cam = get_camera()
	if not cam:
		GameLog.warn(LOG_TAG, "Cannot zoom out: camera not initialized")
		return
	var step = zoom_step_accel if accelerated else zoom_step
	var next_zoom = cam.zoom / step
	cam.zoom = clamp_zoom(next_zoom)

func pan(delta: Vector2):
	var cam = get_camera()
	if cam:
		cam.position += delta

func set_position_direct(pos: Vector2):
	var cam = get_camera()
	if cam:
		cam.position = pos

func set_zoom_direct(zoom: Vector2):
	var cam = get_camera()
	if cam:
		cam.zoom = clamp_zoom(zoom)

# Move camera to a specific world position with smooth animation
func move_to_position(world_pos: Vector2, duration: float = 0.5, target_zoom: Vector2 = Vector2.ZERO):
	var cam = get_camera()
	if not cam:
		GameLog.warn(LOG_TAG, "Cannot move camera: camera not initialized")
		return

	# Create tween for smooth animation
	var tween = create_tween()
	tween.set_parallel(true)
	tween.set_trans(Tween.TRANS_CUBIC)
	tween.set_ease(Tween.EASE_IN_OUT)

	# CRITICAL: Use global_position not position!
	# world_pos is calculated in world coordinates (tilemap.map_to_local + tilemap.position)
	# so we must set global_position to match
	tween.tween_property(cam, "global_position", world_pos, duration)

	# Animate zoom if specified
	if target_zoom != Vector2.ZERO:
		var clamped_zoom = clamp_zoom(target_zoom)
		tween.tween_property(cam, "zoom", clamped_zoom, duration)

	GameLog.info(LOG_TAG, "Moving camera to global_position %s over %.1fs (current: %s)" % [world_pos, duration, cam.global_position])

# Handle keyboard movement
func _process(delta: float):
	if not is_active:
		return

	var cam = get_camera()
	if not cam:
		return

	var direction = Vector2.ZERO

	# Keyboard zoom controls (matching system view):
	# - Shift: Zoom IN
	# - Control/Ctrl: Zoom OUT
	# - Plus/Equals: Zoom IN (Mac-friendly alternative)
	# - Minus: Zoom OUT (Mac-friendly alternative)
	#
	# IMPORTANT: Don't apply keyboard zoom while mouse buttons are pressed
	# (to avoid conflicts with Control+click for right-click drag on Mac)
	var is_dragging = Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) or \
	                  Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT) or \
	                  Input.is_mouse_button_pressed(MOUSE_BUTTON_MIDDLE)

	var zoom_in_pressed = false
	var zoom_out_pressed = false

	if not is_dragging:
		# Shift = zoom in, Ctrl zoom removed (conflicts with Ctrl+F and other shortcuts)
		zoom_in_pressed = Input.is_key_pressed(KEY_SHIFT)
		# Ctrl zoom disabled - use +/- keys or mouse wheel instead

	# Regular WASD movement
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		direction.y -= 1
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		direction.y += 1

	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		direction.x -= 1
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		direction.x += 1

	# Mac-friendly alternative zoom keys (also disabled while dragging)
	if not is_dragging:
		if Input.is_key_pressed(KEY_EQUAL) or Input.is_key_pressed(KEY_PLUS) or Input.is_key_pressed(KEY_KP_ADD):
			zoom_in_pressed = true
		if Input.is_key_pressed(KEY_MINUS) or Input.is_key_pressed(KEY_UNDERSCORE) or Input.is_key_pressed(KEY_KP_SUBTRACT):
			zoom_out_pressed = true

	# Apply keyboard zoom
	if zoom_in_pressed or zoom_out_pressed:
		var zoom_rate = 1.0 + (keyboard_zoom_rate * delta)
		if zoom_in_pressed:
			cam.zoom = clamp_zoom(cam.zoom * zoom_rate)
		else:
			cam.zoom = clamp_zoom(cam.zoom / zoom_rate)

	# Apply keyboard movement
	if direction != Vector2.ZERO:
		direction = direction.normalized()
		var movement = direction * keyboard_speed * delta
		# Account for zoom level
		movement.x /= cam.zoom.x
		movement.y /= cam.zoom.y
		cam.position += movement

# Handle mouse wheel zoom, middle/right mouse drag, and Mac trackpad gestures
func handle_input_event(event: InputEvent) -> bool:
	if not is_active:
		return false

	var cam = get_camera()
	if not cam:
		return false

	# Mouse wheel zoom (works on mouse and some trackpads)
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
			zoom_in(event.shift_pressed)
			return true
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
			zoom_out(event.shift_pressed)
			return true

	# Pan/drag with middle mouse OR right mouse (for Mac trackpad compatibility)
	# Middle mouse: standard desktop behavior
	# Right mouse: Mac trackpad two-finger click or control+click
	if event is InputEventMouseMotion:
		if Input.is_mouse_button_pressed(MOUSE_BUTTON_MIDDLE) or Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
			cam.position -= event.relative / cam.zoom
			return true

	# Mac trackpad pinch-to-zoom gesture support
	if event is InputEventMagnifyGesture:
		var magnify_event = event as InputEventMagnifyGesture
		var zoom_factor = magnify_event.factor
		# Factor > 1.0 means zoom in (pinch out), < 1.0 means zoom out (pinch in)
		if zoom_factor > 1.0:
			var step = 1.0 + (zoom_factor - 1.0) * 2.0  # Amplify the gesture
			cam.zoom = clamp_zoom(cam.zoom * step)
		else:
			var step = 1.0 / (1.0 + (1.0 - zoom_factor) * 2.0)
			cam.zoom = clamp_zoom(cam.zoom * step)
		return true

	# Mac trackpad two-finger pan gesture support
	if event is InputEventPanGesture:
		var pan_event = event as InputEventPanGesture
		# Pan gesture delta is inverted compared to mouse movement
		var pan_delta = Vector2(pan_event.delta.x, pan_event.delta.y) * 2.0  # Amplify for better feel
		cam.position += pan_delta / cam.zoom
		return true

	return false
