class_name ProceduralTerrainSource
extends TerrainDataSource

## Procedural terrain generation for testing
## Generates simple gradient patterns for debugging chunk system
##
## Patterns:
## - GRADIENT_X: East-to-west elevation gradient
## - GRADIENT_Y: North-to-south elevation gradient
## - GRADIENT_RADIAL: Radial gradient from center
## - CHECKERBOARD: Alternating high/low chunks
##
## Usage:
##   var source = ProceduralTerrainSource.new(Vector2i(56, 56), ProceduralTerrainSource.Pattern.GRADIENT_X)
##   var chunk = source.load_chunk(Vector2i(10, 10))

enum Pattern {
	GRADIENT_X,      # East-to-west elevation gradient
	GRADIENT_Y,      # North-to-south elevation gradient
	GRADIENT_RADIAL, # Radial gradient from center
	CHECKERBOARD,    # Alternating high/low chunks (good for visibility testing)
}

# Map size in chunks
var _map_size_chunks: Vector2i

# Generation pattern
var _pattern: Pattern

# Random seed for procedural generation
var _seed: int

func _init(map_size_chunks: Vector2i = Vector2i(56, 56), pattern: Pattern = Pattern.GRADIENT_X, generation_seed: int = 0):
	_map_size_chunks = map_size_chunks
	_pattern = pattern
	_seed = generation_seed if generation_seed != 0 else randi()

func get_bounds() -> Rect2i:
	return Rect2i(Vector2i.ZERO, _map_size_chunks)

func load_chunk(chunk_pos: Vector2i) -> ChunkTileData:
	if not is_valid_chunk(chunk_pos):
		GameLog.warn(LOG_TAG, "Chunk %s out of bounds %s" % [chunk_pos, _map_size_chunks])
		return null

	var chunk_data = ChunkTileData.new(chunk_pos)

	# Generate elevation and tile type based on pattern
	match _pattern:
		Pattern.GRADIENT_X:
			_generate_gradient_x(chunk_data)
		Pattern.GRADIENT_Y:
			_generate_gradient_y(chunk_data)
		Pattern.GRADIENT_RADIAL:
			_generate_gradient_radial(chunk_data)
		Pattern.CHECKERBOARD:
			_generate_checkerboard(chunk_data)

	return chunk_data

## Generate east-to-west elevation gradient
func _generate_gradient_x(chunk_data: ChunkTileData):
	var map_width_tiles = _map_size_chunks.x * ChunkTileData.CHUNK_SIZE
	var chunk_offset = chunk_data.chunk_pos * ChunkTileData.CHUNK_SIZE

	for local_x in range(ChunkTileData.CHUNK_SIZE):
		for local_y in range(ChunkTileData.CHUNK_SIZE):
			var absolute_x = chunk_offset.x + local_x
			var elevation = float(absolute_x) / float(map_width_tiles - 1)

			chunk_data.set_elevation(Vector2i(local_x, local_y), elevation)
			chunk_data.set_tile_type(Vector2i(local_x, local_y), _elevation_to_tile_type(elevation))

## Generate north-to-south elevation gradient
func _generate_gradient_y(chunk_data: ChunkTileData):
	var map_height_tiles = _map_size_chunks.y * ChunkTileData.CHUNK_SIZE
	var chunk_offset = chunk_data.chunk_pos * ChunkTileData.CHUNK_SIZE

	for local_x in range(ChunkTileData.CHUNK_SIZE):
		for local_y in range(ChunkTileData.CHUNK_SIZE):
			var absolute_y = chunk_offset.y + local_y
			var elevation = float(absolute_y) / float(map_height_tiles - 1)

			chunk_data.set_elevation(Vector2i(local_x, local_y), elevation)
			chunk_data.set_tile_type(Vector2i(local_x, local_y), _elevation_to_tile_type(elevation))

## Generate radial gradient from map center
func _generate_gradient_radial(chunk_data: ChunkTileData):
	var map_size_tiles = _map_size_chunks * ChunkTileData.CHUNK_SIZE
	var center = map_size_tiles / 2  # Vector2i / int is fine
	var max_distance = center.length()

	var chunk_offset = chunk_data.chunk_pos * ChunkTileData.CHUNK_SIZE

	for local_x in range(ChunkTileData.CHUNK_SIZE):
		for local_y in range(ChunkTileData.CHUNK_SIZE):
			var absolute_pos = chunk_offset + Vector2i(local_x, local_y)
			var distance = (absolute_pos - center).length()
			var elevation = clampf(distance / max_distance, 0.0, 1.0)

			chunk_data.set_elevation(Vector2i(local_x, local_y), elevation)
			chunk_data.set_tile_type(Vector2i(local_x, local_y), _elevation_to_tile_type(elevation))

## Generate checkerboard pattern (good for testing chunk visibility)
func _generate_checkerboard(chunk_data: ChunkTileData):
	# Entire chunk is either high (0.8) or low (0.2) elevation
	var is_high = (chunk_data.chunk_pos.x + chunk_data.chunk_pos.y) % 2 == 0
	var elevation = 0.8 if is_high else 0.2

	for local_x in range(ChunkTileData.CHUNK_SIZE):
		for local_y in range(ChunkTileData.CHUNK_SIZE):
			chunk_data.set_elevation(Vector2i(local_x, local_y), elevation)
			chunk_data.set_tile_type(Vector2i(local_x, local_y), _elevation_to_tile_type(elevation))

## Convert elevation (0.0-1.0) to appropriate tile type
func _elevation_to_tile_type(elev: float) -> int:
	# Simple mapping for testing
	if elev < 0.2:
		return PlanetMapTileConfig.TileType.FRESH_WATER
	elif elev < 0.4:
		return PlanetMapTileConfig.TileType.DESERT
	elif elev < 0.7:
		return PlanetMapTileConfig.TileType.GRASS_0
	elif elev < 0.9:
		return PlanetMapTileConfig.TileType.ROCK
	else:
		return PlanetMapTileConfig.TileType.MOUNTAIN

## Debug string with pattern name
func _to_string() -> String:
	var pattern_names = ["GRADIENT_X", "GRADIENT_Y", "GRADIENT_RADIAL", "CHECKERBOARD"]
	return "ProceduralTerrainSource(pattern=%s, chunks=%s, seed=%d)" % [
		pattern_names[_pattern],
		_map_size_chunks,
		_seed
	]
