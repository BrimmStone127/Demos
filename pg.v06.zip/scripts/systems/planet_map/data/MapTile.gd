class_name MapTile
extends RefCounted

# Individual tile data for planet map
# Represents a single tile on the planet surface with its properties

var type: PlanetMapTileConfig.TileType
var position: Vector2i  # Grid coordinates
var world_position: Vector2  # World position for rendering
var elevation: float  # 0.0-1.0, preserves CSV precision - converts to discrete layers on demand
var temperature: float
var composition: Dictionary
var special_features: Array[String] = []
var discovered: bool = true  # Set to false for fog of war
var surface_feature_type = null  # Optional TileType for surface features (trees, grass, etc) - null means no feature
var surface_feature_offset: Vector2 = Vector2.ZERO  # Position offset for surface feature within tile
var surface_feature_scale: float = 1.0  # Scale multiplier for surface feature (>1.0 makes it larger and overlap adjacent tiles)
var moisture_level: float = 0.5  # 0.0-1.0, affects tree growth (set during map generation)

func _init(grid_pos: Vector2i, tile_type: PlanetMapTileConfig.TileType = PlanetMapTileConfig.TileType.ROCK):
	position = grid_pos
	type = tile_type
	elevation = 0
	temperature = 0.0
	composition = {}
	surface_feature_type = null

## Convert precise float elevation to discrete render layer
## Supports variable precision (8/16/32/64 layers) for different use cases
## @param num_layers: Number of discrete render layers to quantize to
## @return: Integer layer index from 0 to num_layers-1
func get_render_layer(num_layers: int = PlanetMapTileConfig.NUM_RENDER_LAYERS) -> int:
	return clampi(int(elevation * float(num_layers - 1)), 0, num_layers - 1)
