class_name PlanetMapTileConfig
extends RefCounted

# Configuration constants for the planet map tile system
# This class provides all tile-related constants, enums, and mappings
# Can be reused by both the main map view and sandbox mode

# Map configuration - isometric tiles
const MAP_SIZE = Vector2i(64, 64)  # Map dimensions in tiles (64x64 large detailed maps)
const TILE_SIZE = Vector2(160, 80)  # Isometric tile footprint (width, height)
const TILE_OFFSET = Vector2(80, 40)  # Half tile for isometric offset with full-res art
const ENABLE_PICK_DEBUG := true
const ENABLE_VISUAL_DEBUG := false  # Draw click area polygons for debugging

# Elevation/Layer configuration
const MAX_LAYERS := 8  # 0-7 elevation layers
const NUM_RENDER_LAYERS := 16  # Configurable elevation detail (8/16/32/64 for different precision levels)
const LAYER_HEIGHT_OFFSET := 20.0  # Vertical offset per layer (1/4 height for shorter grass tiles)

# Z-index configuration for layering
const ELEVATION_Z_SPACING := 90  # Z-index gap between elevation layers (fits 32 layers under 4096 limit)
const SURFACE_FEATURE_Z_INDEX := 3200  # Z-index for sprites (trees, rocks, etc.) - above all terrain

# Brightness configuration for elevation-based shading
const LAYER_DARKENING_MIN := 0.5  # Minimum brightness for lowest layer
const LAYER_DARKENING_MAX := 1.0  # Maximum brightness for highest layer

# Elevation remapping - use actual terrain range instead of full 0-1
# Set these to focus rendering on interesting elevation ranges
const ELEVATION_REMAP_ENABLED := true  # Enable smart elevation remapping
const ELEVATION_PERCENTILE_MIN := 0.10  # Ignore bottom 10% (low outliers)
const ELEVATION_PERCENTILE_MAX := 0.95  # Ignore top 5% (high outliers)

# TileMap rendering layers (native Godot layers within a single TileMap)
const TILEMAP_LAYER_TERRAIN := 0  # Base terrain tiles (grass, rock, water, etc)
const TILEMAP_LAYER_SURFACE_FEATURES := 1  # Trees, vegetation, structures (renders on top)

# Tileset source ID (for set_cell operations)
const TILESET_SOURCE_ID := 0  # First (and only) tileset source

# Tile types based on planet characteristics
enum TileType {
	TILE_BORDER,
	FLIR_0,
	FLIR_1,
	FLIR_2,
	FLIR_3,
	FLIR_4,
	FLIR_5,
	FLIR_6,
	FLIR_7,
	FLIR_8,
	FLIR_9,
	FLIR_10,
	FLIR_11,
	FLIR_12,
	FLIR_13,
	FLIR_14,
	FRESH_WATER,
	ICE,
	POLAR_ICE,
	ROCK,
	MOUNTAIN,
	VOLCANIC,
	CRATER,
	DESERT,
	FROZEN_SURFACE,
	RIFT,
	PLAINS,
	HIGHLANDS,
	LOWLANDS,
	IMPACT_SITE,
	GEOTHERMAL,
	UNKNOWN,  # For unexplored areas if you want fog of war
	GRAYSCALE_0,
	GRAYSCALE_1,
	GRAYSCALE_2,
	GRAYSCALE_3,
	GRAYSCALE_4,
	GRAYSCALE_5,
	GRAYSCALE_6,
	GRAYSCALE_7,
	GRASS_0,
	GRASS_1,
	GRASS_2,
	CRATER_0,
	STONE_0,
	# Sloped tiles for elevation transitions
	SLOPE_2TILE_LEFT_LOWER,
	SLOPE_2TILE_LEFT_UPPER,
	SLOPE_2TILE_PYRAMID,
	SLOPE_2TILE_RIGHT_UPPER,
	SLOPE_2TILE_RIGHT_LOWER,
	SLOPE_1TILE_RIGHT,
	SLOPE_1TILE_INNER_EDGE,
	SLOPE_1TILE_LEFT,
	SLOPE_1TILE_PYRAMID,
	# Surface features - render on top of base tiles without affecting elevation
	SF_GRASS,
	SF_LEAVES_1,
	SF_LEAVES_2,
	SF_LEAVES_3,
	SF_VINES,
	SF_GOLDENROD,
	SF_GRASS_2,
	SF_CRATERS,
	SF_TREE_1,
	SF_TREE_2,
	SF_TREE_3,
	SF_LONG_HOUSE,
	# New tree assets - 6 sizes in dormant and vegetative states (12 total)
	SF_TREE_DORMANT_SIZE1,
	SF_TREE_DORMANT_SIZE2,
	SF_TREE_DORMANT_SIZE3,
	SF_TREE_DORMANT_SIZE4,
	SF_TREE_DORMANT_SIZE5,
	SF_TREE_DORMANT_SIZE6,
	SF_TREE_VEG_SIZE1,
	SF_TREE_VEG_SIZE2,
	SF_TREE_VEG_SIZE3,
	SF_TREE_VEG_SIZE4,
	SF_TREE_VEG_SIZE5,
	SF_TREE_VEG_SIZE6
}

# Tileset configuration
const TILESET_TEXTURE: Texture2D = preload("res://assets/big_iso_tileset.png")
const TILESET_SOURCE_TILE_SIZE := Vector2i(160, 160)
const TILESET_GRID_SIZE := Vector2i(20, 10)  # big_iso atlas layout (columns, rows)
const TILESET_REGION_INSET := Vector2i(1, 1)  # 1-pixel inset to prevent texture bleeding
const TILESET_VISUAL_OFFSET := Vector2.ZERO  # Slab tiles: no offset needed (was -40 for legacy cube tiles)
const SURFACE_FEATURE_LAYER_OFFSET_Y := TILESET_SOURCE_TILE_SIZE.y - TILE_SIZE.y  # Raise tall sprites (trees) so bases sit on tile

# Shared tileset instance (singleton pattern to reduce GPU memory usage)
static var _shared_tileset: TileSet = null

# Atlas mapping - maps TileType to grid coordinates in the tileset
const TILESET_REGION_MAP := {
	# Vector2i(column, row) into the 20x10 atlas grid
	TileType.TILE_BORDER: Vector2i(11, 1),
	TileType.FLIR_0: Vector2i(0, 6),
	TileType.FLIR_1: Vector2i(1, 6),
	TileType.FLIR_2: Vector2i(2, 6),
	TileType.FLIR_3: Vector2i(3, 6),
	TileType.FLIR_4: Vector2i(4, 6),
	TileType.FLIR_5: Vector2i(5, 6),
	TileType.FLIR_6: Vector2i(6, 6),
	TileType.FLIR_7: Vector2i(7, 6),
	TileType.FLIR_8: Vector2i(8, 6),
	TileType.FLIR_9: Vector2i(9, 6),
	TileType.FLIR_10: Vector2i(10, 6),
	TileType.FLIR_11: Vector2i(11, 6),
	TileType.FLIR_12: Vector2i(12, 6),
	TileType.FLIR_13: Vector2i(13, 6),
	TileType.FLIR_14: Vector2i(14, 6),
	TileType.FRESH_WATER: Vector2i(0, 5),
	TileType.ICE: Vector2i(4, 1),
	TileType.POLAR_ICE: Vector2i(8, 3),
	TileType.ROCK: Vector2i(5, 0),
	TileType.MOUNTAIN: Vector2i(6, 0),
	TileType.VOLCANIC: Vector2i(7, 0),
	TileType.CRATER: Vector2i(17, 9),
	TileType.DESERT: Vector2i(5, 1),
	TileType.FROZEN_SURFACE: Vector2i(4, 1),
	TileType.RIFT: Vector2i(15, 0),
	TileType.PLAINS: Vector2i(1, 0),
	TileType.HIGHLANDS: Vector2i(7, 1),
	TileType.LOWLANDS: Vector2i(8, 1),
	TileType.IMPACT_SITE: Vector2i(16, 0),
	TileType.GEOTHERMAL: Vector2i(7, 6),
	TileType.UNKNOWN: Vector2i(7, 2),
	TileType.GRAYSCALE_0: Vector2i(0, 3),
	TileType.GRAYSCALE_1: Vector2i(1, 3),
	TileType.GRAYSCALE_2: Vector2i(2, 3),
	TileType.GRAYSCALE_3: Vector2i(3, 3),
	TileType.GRAYSCALE_4: Vector2i(4, 3),
	TileType.GRAYSCALE_5: Vector2i(5, 3),
	TileType.GRAYSCALE_6: Vector2i(6, 3),
	TileType.GRAYSCALE_7: Vector2i(7, 3),
	TileType.GRASS_0: Vector2i(11, 5),  # Short centered grass tile (R5_C11)
	TileType.GRASS_1: Vector2i(11, 5),  # Short centered grass tile (R5_C11)
	TileType.GRASS_2: Vector2i(11, 5),  # Short centered grass tile (R5_C11)
	TileType.CRATER_0: Vector2i(3, 4),
	TileType.STONE_0: Vector2i(4,4),
	# Sloped tiles (row 6)
	TileType.SLOPE_2TILE_LEFT_LOWER: Vector2i(0, 6),
	TileType.SLOPE_2TILE_LEFT_UPPER: Vector2i(1, 6),
	TileType.SLOPE_2TILE_PYRAMID: Vector2i(2, 6),
	TileType.SLOPE_2TILE_RIGHT_UPPER: Vector2i(3, 6),
	TileType.SLOPE_2TILE_RIGHT_LOWER: Vector2i(4, 6),
	TileType.SLOPE_1TILE_RIGHT: Vector2i(5, 6),
	TileType.SLOPE_1TILE_INNER_EDGE: Vector2i(6, 6),
	TileType.SLOPE_1TILE_LEFT: Vector2i(7, 6),
	TileType.SLOPE_1TILE_PYRAMID: Vector2i(8, 6),
	# Surface features (row 2) - render on surface feature layer
	TileType.SF_GRASS: Vector2i(0, 2),
	TileType.SF_LEAVES_1: Vector2i(1, 2),
	TileType.SF_LEAVES_2: Vector2i(2, 2),
	TileType.SF_LEAVES_3: Vector2i(3, 2),
	TileType.SF_VINES: Vector2i(4, 2),
	TileType.SF_GOLDENROD: Vector2i(5, 2),
	TileType.SF_GRASS_2: Vector2i(6, 2),
	TileType.SF_CRATERS: Vector2i(7, 2),
	TileType.SF_TREE_1: Vector2i(8, 2),
	TileType.SF_TREE_2: Vector2i(9, 2),
	TileType.SF_TREE_3: Vector2i(10, 2),
	TileType.SF_LONG_HOUSE: Vector2i(11, 2),
	# New tree assets - 6 sizes each, row 3 for dormant, row 4 for vegetative
	TileType.SF_TREE_DORMANT_SIZE1: Vector2i(13, 3),
	TileType.SF_TREE_DORMANT_SIZE2: Vector2i(14, 3),
	TileType.SF_TREE_DORMANT_SIZE3: Vector2i(15, 3),
	TileType.SF_TREE_DORMANT_SIZE4: Vector2i(16, 3),
	TileType.SF_TREE_DORMANT_SIZE5: Vector2i(17, 3),
	TileType.SF_TREE_DORMANT_SIZE6: Vector2i(18, 3),
	TileType.SF_TREE_VEG_SIZE1: Vector2i(13, 4),
	TileType.SF_TREE_VEG_SIZE2: Vector2i(14, 4),
	TileType.SF_TREE_VEG_SIZE3: Vector2i(15, 4),
	TileType.SF_TREE_VEG_SIZE4: Vector2i(16, 4),
	TileType.SF_TREE_VEG_SIZE5: Vector2i(17, 4),
	TileType.SF_TREE_VEG_SIZE6: Vector2i(18, 4)
}

# Camera configuration
const CAMERA_KEYBOARD_SPEED := 600.0
const CAMERA_ZOOM_MIN := Vector2(0.001953125, 0.001953125)  # Min zoom — full planet view (1/512)
const CAMERA_ZOOM_MAX := Vector2(4.0, 4.0)  # Maximum zoom (4x size)
const CAMERA_ZOOM_STEP := 1.25  # Smooth zoom: ~25% per scroll step
const CAMERA_ZOOM_STEP_ACCEL := 1.5  # Faster zoom when holding modifier
const CAMERA_KEYBOARD_ZOOM_RATE := 2.0  # Integer keyboard zoom rate

# LOD: hysteresis thresholds prevent rapid cycling at boundary.
# Enter LOD when zoom drops below ENTER; exit only when zoom rises above EXIT.
# Gap ratio ~1.6x prevents scroll-wobble toggling.
const LOD_ZOOM_ENTER := 0.03125   # Zoom out past this → enter LOD
const LOD_ZOOM_EXIT := 0.05       # Zoom in past this → exit LOD
# Pre-baked overview image (generated by tools/generate_overview.gd)
const OVERVIEW_TEXTURE_PATH := "res://assets/terrain/overview.png"
const OVERVIEW_HEATMAP_PATH := "res://assets/terrain/overview_heatmap.png"
const OVERVIEW_NO_TREES_PATH := "res://assets/terrain/overview_no_trees.png"

# Helper function to get the atlas region for a tile type
static func get_tileset_region(tile_type: TileType) -> Rect2i:
	var atlas_coords = TILESET_REGION_MAP.get(tile_type, Vector2i(0, 0))
	var region_pos = atlas_coords * TILESET_SOURCE_TILE_SIZE + TILESET_REGION_INSET
	return Rect2i(region_pos, TILESET_SOURCE_TILE_SIZE - TILESET_REGION_INSET * 2)

# Helper function to get atlas coordinates for a tile type
static func get_atlas_coords(tile_type: TileType) -> Vector2i:
	return TILESET_REGION_MAP.get(tile_type, Vector2i(-1, -1))


# Remap elevation from actual data range to full 0.0-1.0 range
# This ensures all 32 layers are used even if terrain only spans 0.3-0.7
# @param elevation: Raw elevation value (0.0-1.0)
# @param min_elev: Minimum elevation in dataset (e.g., 0.25)
# @param max_elev: Maximum elevation in dataset (e.g., 0.85)
# @return: Remapped elevation (0.0-1.0) that uses full range
static func remap_elevation(elevation: float, min_elev: float, max_elev: float) -> float:
	if not ELEVATION_REMAP_ENABLED:
		return elevation

	# Clamp to data range
	var clamped = clampf(elevation, min_elev, max_elev)

	# Remap to full 0-1 range
	if max_elev > min_elev:
		return (clamped - min_elev) / (max_elev - min_elev)
	else:
		return 0.5  # Fallback if no variation

# Calculate brightness for a given elevation layer
# Uses NUM_RENDER_LAYERS for smooth transitions (e.g., 32 brightness steps instead of 8)
# Returns a value between LAYER_DARKENING_MIN (0.4) and LAYER_DARKENING_MAX (1.0)
static func get_elevation_brightness(elevation: int) -> float:
	if NUM_RENDER_LAYERS > 1:
		var layer_normalized = float(elevation) / float(NUM_RENDER_LAYERS - 1)
		return LAYER_DARKENING_MIN + layer_normalized * (LAYER_DARKENING_MAX - LAYER_DARKENING_MIN)
	else:
		return LAYER_DARKENING_MAX

## Convert float elevation (0.0-1.0) to integer render layer (0 to NUM_RENDER_LAYERS-1)
static func get_render_layer(elevation: float, num_layers: int = NUM_RENDER_LAYERS) -> int:
	var layer = int(elevation * (num_layers - 1))
	return clampi(layer, 0, num_layers - 1)

## Get or create shared tileset instance (singleton pattern)
## This reduces GPU memory usage by reusing one TileSet across all TileMaps
## instead of creating 784 separate instances (49 chunks × 16 layers)
static func get_shared_tileset() -> TileSet:
	if _shared_tileset == null:
		_shared_tileset = create_tileset()
		# DEBUG: Verify tileset was created properly
		var atlas = _shared_tileset.get_source(TILESET_SOURCE_ID) as TileSetAtlasSource
		if atlas:
			var tile_count = 0
			for coords in TILESET_REGION_MAP.values():
				if atlas.has_tile(coords):
					tile_count += 1
			print("[DEBUG] Shared TileSet created: %d/%d tiles in atlas, texture=%s" % [
				tile_count, TILESET_REGION_MAP.size(), atlas.texture != null
			])
		else:
			print("[ERROR] Shared TileSet has no atlas source!")
	return _shared_tileset

## Create a tileset for use with TileMaps
static func create_tileset() -> TileSet:
	var tileset = TileSet.new()

	# CRITICAL: Configure for isometric rendering
	tileset.tile_shape = TileSet.TILE_SHAPE_ISOMETRIC

	# Set isometric layout (try DIAMOND_DOWN first, with fallbacks)
	var layout_value := -1
	if ClassDB.class_has_integer_constant("TileSet", "TILE_LAYOUT_DIAMOND_DOWN"):
		layout_value = ClassDB.class_get_integer_constant("TileSet", "TILE_LAYOUT_DIAMOND_DOWN")
	elif ClassDB.class_has_integer_constant("TileSet", "TILE_LAYOUT_DIAMOND_RIGHT"):
		layout_value = ClassDB.class_get_integer_constant("TileSet", "TILE_LAYOUT_DIAMOND_RIGHT")
	elif ClassDB.class_has_integer_constant("TileSet", "TILE_LAYOUT_STACKED"):
		layout_value = ClassDB.class_get_integer_constant("TileSet", "TILE_LAYOUT_STACKED")
	if layout_value != -1:
		@warning_ignore("int_as_enum_without_cast")
		tileset.tile_layout = layout_value

	# CRITICAL: Use isometric footprint (160x80), NOT source tile size (160x160)
	tileset.tile_size = Vector2i(int(TILE_SIZE.x), int(TILE_SIZE.y))

	# Create atlas source
	var atlas_source = TileSetAtlasSource.new()
	atlas_source.texture = TILESET_TEXTURE  # Already preloaded, don't call load()
	atlas_source.texture_region_size = TILESET_SOURCE_TILE_SIZE  # 160x160 atlas regions

	# Create tiles for all coordinates in the region map
	# This is essential - without this, set_cell() won't work!
	for tile_type in TILESET_REGION_MAP.keys():
		var coords: Vector2i = TILESET_REGION_MAP[tile_type]
		if not atlas_source.has_tile(coords):
			atlas_source.create_tile(coords)

	# Add the atlas source to tileset
	tileset.add_source(atlas_source, TILESET_SOURCE_ID)

	return tileset
