class_name VariantTheme
extends RefCounted

## Data class for theme definitions
##
## A theme defines which color variants to apply to tiles. It supports:
## - Per-tile variant assignment (tile_id -> variant_name)
## - Per-category variant assignment (category -> variant_name)
## - Future animation settings (structure only, not implemented yet)
##
## Tile-specific variants take priority over category variants.
##
## Usage:
##   var theme = VariantTheme.new()
##   theme.name = "autumn"
##   theme.description = "Fall colors for trees"
##   theme.set_category_variant("Trees", "autumn")
##   theme.set_tile_variant(93, "autumn_maple")

## Theme identifier (used for lookup)
var name: String = ""

## Human-readable description
var description: String = ""

## Per-tile variant assignments: {tile_id: variant_name}
## Tile IDs are from tile_catalog.json (row * 20 + col)
var tile_variants: Dictionary = {}

## Per-category variant assignments: {category: variant_name}
## Categories match those in tile_catalog.json (e.g., "Trees", "Grass")
var category_variants: Dictionary = {}

## Future animation support - data structure only, not implemented yet
## Format: {tile_id: {enabled: bool, type: String, speed: float, intensity: float}}
var animation_settings: Dictionary = {}


## Get the variant name to use for a specific tile
## Tile-specific takes priority over category
func get_variant_for_tile(tile_id: int, category: String) -> String:
	# Check tile-specific first
	if tile_variants.has(tile_id):
		return tile_variants[tile_id]

	# Fall back to category
	if category_variants.has(category):
		return category_variants[category]

	# No variant specified
	return ""


## Set variant for a specific tile
func set_tile_variant(tile_id: int, variant_name: String) -> void:
	if variant_name.is_empty():
		tile_variants.erase(tile_id)
	else:
		tile_variants[tile_id] = variant_name


## Set variant for an entire category
func set_category_variant(category: String, variant_name: String) -> void:
	if variant_name.is_empty():
		category_variants.erase(category)
	else:
		category_variants[category] = variant_name


## Clear a tile-specific variant (will fall back to category)
func clear_tile_variant(tile_id: int) -> void:
	tile_variants.erase(tile_id)


## Clear a category variant
func clear_category_variant(category: String) -> void:
	category_variants.erase(category)


## Check if theme has any variants defined
func has_variants() -> bool:
	return not tile_variants.is_empty() or not category_variants.is_empty()


## Serialize to Dictionary for JSON storage
func to_dict() -> Dictionary:
	# Convert tile_variants keys to strings for JSON
	var tile_vars_str: Dictionary = {}
	for tile_id in tile_variants:
		tile_vars_str[str(tile_id)] = tile_variants[tile_id]

	return {
		"name": name,
		"description": description,
		"tile_variants": tile_vars_str,
		"category_variants": category_variants,
		"animation_settings": animation_settings
	}


## Deserialize from Dictionary
static func from_dict(data: Dictionary) -> VariantTheme:
	var theme = VariantTheme.new()
	theme.name = data.get("name", "")
	theme.description = data.get("description", "")

	# Convert tile_variants keys back to integers
	var tile_vars_raw = data.get("tile_variants", {})
	for key in tile_vars_raw:
		var tile_id = int(key) if key is String else key
		theme.tile_variants[tile_id] = tile_vars_raw[key]

	theme.category_variants = data.get("category_variants", {})
	theme.animation_settings = data.get("animation_settings", {})

	return theme


## Create a copy of this theme
func duplicate_theme() -> VariantTheme:
	var copy = VariantTheme.new()
	copy.name = name
	copy.description = description
	copy.tile_variants = tile_variants.duplicate()
	copy.category_variants = category_variants.duplicate()
	copy.animation_settings = animation_settings.duplicate(true)
	return copy
