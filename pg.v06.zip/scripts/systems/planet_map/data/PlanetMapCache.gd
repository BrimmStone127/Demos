class_name PlanetMapCache
extends RefCounted

# Handles serialization and caching of planet map tiles
# Works with ProbeSystem to store/restore generated maps

const LOG_TAG := "PLANET_MAP_CACHE"

# Serialize map tiles to a dictionary array for storage
static func serialize_map_tiles(tiles: Array) -> Array:
	var serialized: Array = []
	if tiles == null:
		return serialized

	var surface_feature_count = 0

	for x in range(tiles.size()):
		var row_serialized: Array = []
		var row = tiles[x]
		if row is Array:
			for y in range(row.size()):
				var tile = row[y]
				if tile == null:
					row_serialized.append({})
					continue

				var composition_data = tile.composition if tile.composition is Dictionary else {}
				var features_data = tile.special_features if tile.special_features is Array else []
				var surface_feature = tile.surface_feature_type

				if surface_feature != null:
					surface_feature_count += 1
					if surface_feature_count <= 3:
						GameLog.info(LOG_TAG, "DEBUG: Serializing surface feature %d at [%d,%d]" % [surface_feature, x, y])

				row_serialized.append({
					"type": tile.type,
					"position": tile.position,
					"elevation": tile.elevation,
					"temperature": tile.temperature,
					"composition": composition_data.duplicate(true) if composition_data is Dictionary else {},
					"special_features": features_data.duplicate() if features_data is Array else [],
					"discovered": tile.discovered,
					"surface_feature_type": surface_feature,
					"surface_feature_offset": tile.surface_feature_offset,
					"surface_feature_scale": tile.surface_feature_scale
				})
		serialized.append(row_serialized)

	GameLog.info(LOG_TAG, "Serialization complete: %d tiles with surface features" % surface_feature_count)
	return serialized

# Deserialize map tiles from a dictionary array
static func deserialize_map_tiles(serialized: Array) -> Array:
	var tiles: Array = []
	if serialized == null:
		return tiles

	var surface_feature_count = 0

	for x in range(serialized.size()):
		var row_serialized = serialized[x]
		var row: Array = []
		if row_serialized is Array:
			for y in range(row_serialized.size()):
				var tile_data = row_serialized[y]
				var grid_pos = Vector2i(x, y)  # Use x,y instead of potentially corrupted data
				var tile_type = PlanetMapTileConfig.TileType.ROCK

				if tile_data is Dictionary and not tile_data.is_empty():
					tile_type = tile_data.get("type", PlanetMapTileConfig.TileType.ROCK)

				var map_tile = MapTile.new(grid_pos, tile_type)

				if tile_data is Dictionary and not tile_data.is_empty():
					map_tile.elevation = tile_data.get("elevation", 0)
					map_tile.temperature = tile_data.get("temperature", 0.0)

					var composition_data = tile_data.get("composition", {})
					map_tile.composition = composition_data.duplicate(true) if composition_data is Dictionary else {}

					# Fix for special_features - ensure it's properly typed
					var special_features_data = tile_data.get("special_features", [])
					if special_features_data is Array:
						# Clear the existing array and add items individually to maintain type
						map_tile.special_features.clear()
						for feature in special_features_data:
							if feature is String:
								map_tile.special_features.append(feature)

					map_tile.discovered = tile_data.get("discovered", true)
					map_tile.surface_feature_type = tile_data.get("surface_feature_type", null)

					# Handle surface_feature_offset with type checking (old saves may have wrong type)
					var offset_data = tile_data.get("surface_feature_offset", Vector2.ZERO)
					if offset_data is Vector2:
						map_tile.surface_feature_offset = offset_data
					else:
						map_tile.surface_feature_offset = Vector2.ZERO

					map_tile.surface_feature_scale = tile_data.get("surface_feature_scale", 1.0)

					if map_tile.surface_feature_type != null:
						surface_feature_count += 1
						if surface_feature_count <= 3:
							GameLog.info(LOG_TAG, "DEBUG: Deserialized surface feature %d at [%d,%d]" % [map_tile.surface_feature_type, x, y])

				row.append(map_tile)
		tiles.append(row)

	GameLog.info(LOG_TAG, "Deserialization complete: %d tiles with surface features" % surface_feature_count)
	return tiles

# Try to load a cached map from the probe system
static func try_load_cached_map(stable_id: String, probe_system) -> Array:
	if not probe_system:
		return []

	var cache = probe_system.get_surface_map_cache(stable_id)
	if cache.is_empty():
		return []

	var cached_version = cache.get("version", 0)
	if cached_version != probe_system.PLANET_SURFACE_MAP_VERSION:
		GameLog.info(LOG_TAG, "Cached surface map version mismatch (%s), clearing cache" % cached_version)
		probe_system.clear_surface_map_cache(stable_id)
		return []

	var serialized_tiles = cache.get("tiles", [])
	if typeof(serialized_tiles) != TYPE_ARRAY or serialized_tiles.is_empty():
		GameLog.warn(LOG_TAG, "Surface map cache missing tile data, regenerating")
		probe_system.clear_surface_map_cache(stable_id)
		return []

	var restored_tiles = deserialize_map_tiles(serialized_tiles)
	if restored_tiles.is_empty():
		GameLog.warn(LOG_TAG, "Surface map cache could not be deserialized, regenerating")
		probe_system.clear_surface_map_cache(stable_id)
		return []

	var width = restored_tiles.size()
	var height = 0
	if width > 0 and restored_tiles[0] is Array:
		height = restored_tiles[0].size()
	GameLog.info(LOG_TAG, "Restored %s x %s tile map from cache" % [width, height])

	return restored_tiles

# Save a map to the probe system cache
static func save_map_cache(stable_id: String, map_tiles: Array, map_seed: int, probe_system) -> void:
	if not probe_system or stable_id == "":
		return

	var cache_payload = {
		"version": probe_system.PLANET_SURFACE_MAP_VERSION,
		"seed": map_seed,
		"generated_at": Time.get_unix_time_from_system(),
		"tiles": serialize_map_tiles(map_tiles)
	}
	probe_system.set_surface_map_cache(stable_id, cache_payload)
	GameLog.info(LOG_TAG, "Surface map cache stored for %s" % stable_id)
