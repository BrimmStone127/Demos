class_name ChunkTileData
extends RefCounted

## Data container for one chunk's tile information
## A chunk is 64×64 tiles with elevation and type data
##
## Chunk coordinates are absolute: chunk (5, 10) contains tiles (320-383, 640-703)
## This ensures stable coordinates - tile (350, 670) is always (350, 670) regardless of loading
##
## Storage layout: flat packed arrays, index = local_y * CHUNK_SIZE + local_x
## PackedFloat32Array and PackedInt32Array are C-array backed → single dereference,
## contiguous memory, no GDScript Array object overhead. Significant speedup in the
## 4096-tile rendering loop vs the previous nested Array[Array] layout.

const LOG_TAG := "CHUNK_DATA"
const CHUNK_SIZE := 64  # Tiles per chunk dimension

# Chunk position in chunk-space (e.g., (0,0), (1,0), (5,10))
var chunk_pos: Vector2i

# Tile elevation data — flat PackedFloat32Array, index = local_y * CHUNK_SIZE + local_x
var elevations: PackedFloat32Array

# Tile type data — flat PackedInt32Array, same index scheme
var tile_types: PackedInt32Array

# Pre-computed render layers (0-15) — updated whenever elevation is set.
# Avoids calling get_render_layer() per tile in the rendering hot loop.
var render_layers: PackedByteArray

# Surface features (sparse dictionary, only populated tiles)
# features[local_pos] -> SurfaceFeatureType
var features: Dictionary = {}

# Understory plants (sparse dictionary, independent of features)
# understory[local_pos] -> tile_id (e.g., raspberry bush)
var understory: Dictionary = {}

# Ruin positions (sparse — only abandoned longhouse sites)
# ruins[local_pos] -> true
var ruins: Dictionary = {}

# Flow direction per water tile (sparse — only water tiles populated)
# flow_directions[local_pos] -> int  (0-7 compass dir, 8 = lake, 255 = not water)
var flow_directions: Dictionary = {}

# LOD thumbnail — 64x64 pixel image colored by tile type + elevation brightness.
# Generated lazily on first access, invalidated when tile data changes.
var _thumbnail: ImageTexture = null
var _thumbnail_dirty: bool = true

# Hardcoded terrain colors for LOD thumbnails
static var THUMBNAIL_COLORS: Dictionary = {
	PlanetMapTileConfig.TileType.FRESH_WATER: Color(0.08, 0.18, 0.45),
	PlanetMapTileConfig.TileType.ICE: Color(0.8, 0.9, 1.0),
	PlanetMapTileConfig.TileType.GRASS_0: Color(0.3, 0.6, 0.2),
	PlanetMapTileConfig.TileType.GRASS_1: Color(0.35, 0.65, 0.25),
	PlanetMapTileConfig.TileType.GRASS_2: Color(0.4, 0.7, 0.3),
	PlanetMapTileConfig.TileType.ROCK: Color(0.5, 0.5, 0.5),
	PlanetMapTileConfig.TileType.MOUNTAIN: Color(0.6, 0.6, 0.6),
	PlanetMapTileConfig.TileType.DESERT: Color(0.9, 0.8, 0.5),
	PlanetMapTileConfig.TileType.PLAINS: Color(0.45, 0.65, 0.3),
	PlanetMapTileConfig.TileType.HIGHLANDS: Color(0.55, 0.6, 0.35),
	PlanetMapTileConfig.TileType.LOWLANDS: Color(0.35, 0.55, 0.25),
}

# FLIR heatmap endpoint colors — gradient from dark blue (low) to white (high)
const FLIR_COLOR_LOW := Color(0.05, 0.05, 0.30)   # darkest blue (lowest elevation)
const FLIR_COLOR_HIGH := Color(1.00, 1.00, 1.00)  # white (highest elevation)

# Get FLIR gradient color for a normalized elevation (0.0-1.0)
static func get_flir_color(elevation: float) -> Color:
	return FLIR_COLOR_LOW.lerp(FLIR_COLOR_HIGH, clampf(elevation, 0.0, 1.0))

# Feature (tree) colors sampled from tileset texture — built once on first use
static var _feature_colors: Dictionary = {}  # tile_id -> Color
static var _features_sampled: bool = false

func _init(chunk_coords: Vector2i = Vector2i.ZERO):
	chunk_pos = chunk_coords
	_initialize_arrays()

func _initialize_arrays():
	var n := CHUNK_SIZE * CHUNK_SIZE
	elevations = PackedFloat32Array()
	elevations.resize(n)
	elevations.fill(0.5)  # Mid elevation default

	tile_types = PackedInt32Array()
	tile_types.resize(n)
	tile_types.fill(PlanetMapTileConfig.TileType.ROCK)  # Default type

	render_layers = PackedByteArray()
	render_layers.resize(n)
	# Pre-compute render layers for default elevation 0.5
	var default_layer := clampi(int(0.5 * (PlanetMapTileConfig.NUM_RENDER_LAYERS - 1)),
		0, PlanetMapTileConfig.NUM_RENDER_LAYERS - 1)
	render_layers.fill(default_layer)

## Flat index from local tile position.
func _idx(local: Vector2i) -> int:
	return local.y * CHUNK_SIZE + local.x

## Convert local tile position (0-63) to absolute map position
func get_absolute_tile_pos(local: Vector2i) -> Vector2i:
	return chunk_pos * CHUNK_SIZE + local

## Convert absolute map position to local tile position (0-63)
## Returns null if position is not in this chunk
func get_local_tile_pos(absolute: Vector2i) -> Vector2i:
	var expected_chunk = Vector2i(
		floori(float(absolute.x) / CHUNK_SIZE),
		floori(float(absolute.y) / CHUNK_SIZE)
	)

	if expected_chunk != chunk_pos:
		return Vector2i(-1, -1)  # Not in this chunk

	return Vector2i(
		absolute.x % CHUNK_SIZE,
		absolute.y % CHUNK_SIZE
	)

## Check if local position is valid (0-63 range)
func is_valid_local_pos(local: Vector2i) -> bool:
	return local.x >= 0 and local.y >= 0 and local.x < CHUNK_SIZE and local.y < CHUNK_SIZE

## Get elevation at local position (returns 0.5 if invalid)
func get_elevation(local: Vector2i) -> float:
	if not is_valid_local_pos(local):
		GameLog.warn(LOG_TAG, "Invalid local position %s for chunk %s" % [local, chunk_pos])
		return 0.5
	return elevations[_idx(local)]

## Set elevation at local position. Also updates pre-computed render_layers entry.
func set_elevation(local: Vector2i, value: float):
	if not is_valid_local_pos(local):
		GameLog.warn(LOG_TAG, "Invalid local position %s for chunk %s" % [local, chunk_pos])
		return
	var clamped := clampf(value, 0.0, 1.0)
	var idx := _idx(local)
	elevations[idx] = clamped
	render_layers[idx] = clampi(
		int(clamped * (PlanetMapTileConfig.NUM_RENDER_LAYERS - 1)),
		0, PlanetMapTileConfig.NUM_RENDER_LAYERS - 1)
	_thumbnail_dirty = true

## Get tile type at local position
func get_tile_type(local: Vector2i) -> int:
	if not is_valid_local_pos(local):
		return PlanetMapTileConfig.TileType.ROCK
	return tile_types[_idx(local)]

## Set tile type at local position
func set_tile_type(local: Vector2i, tile_type: int):
	if not is_valid_local_pos(local):
		GameLog.warn(LOG_TAG, "Invalid local position %s for chunk %s" % [local, chunk_pos])
		return
	tile_types[_idx(local)] = tile_type
	_thumbnail_dirty = true

## Get surface feature at local position (returns null if none)
func get_feature(local: Vector2i):
	return features.get(local, null)

## Set surface feature at local position
func set_feature(local: Vector2i, feature):
	if not is_valid_local_pos(local):
		GameLog.warn(LOG_TAG, "Invalid local position %s for chunk %s" % [local, chunk_pos])
		return

	if feature == null:
		features.erase(local)
	else:
		features[local] = feature
	_thumbnail_dirty = true

## Get chunk bounds in absolute tile coordinates
func get_absolute_bounds() -> Rect2i:
	var min_tile = chunk_pos * CHUNK_SIZE
	return Rect2i(min_tile, Vector2i(CHUNK_SIZE, CHUNK_SIZE))

## Get flow direction at local position. Returns 255 (not water) if not set.
func get_flow_direction(local: Vector2i) -> int:
	return flow_directions.get(local, 255)

## Set flow direction at local position. Skips 255 (not-water) to keep dict sparse.
func set_flow_direction(local: Vector2i, direction: int) -> void:
	if not is_valid_local_pos(local):
		return
	if direction == 255:
		flow_directions.erase(local)
	else:
		flow_directions[local] = direction


## Get understory plant at local position (returns null if none)
func get_understory(local: Vector2i):
	return understory.get(local, null)

## Set understory plant at local position
func set_understory(local: Vector2i, tile_id) -> void:
	if not is_valid_local_pos(local):
		return
	if tile_id == null:
		understory.erase(local)
	else:
		understory[local] = tile_id

## Mark a local position as a ruin (or clear it)
func set_ruin(local: Vector2i, is_ruin: bool) -> void:
	if not is_valid_local_pos(local):
		return
	if is_ruin:
		ruins[local] = true
	else:
		ruins.erase(local)


## Check if a local position is a ruin
func is_ruin(local: Vector2i) -> bool:
	return ruins.has(local)


## Get total number of tiles with features
func get_feature_count() -> int:
	return features.size()

# ── LOD Thumbnail ─────────────────────────────────────────────────────────────

## Get or generate LOD thumbnail (64x64 Image, one pixel per tile).
func get_thumbnail() -> ImageTexture:
	if _thumbnail_dirty or _thumbnail == null:
		_generate_thumbnail()
	return _thumbnail

## Mark thumbnail as stale (called automatically by set_elevation, set_tile_type, set_feature).
func invalidate_thumbnail() -> void:
	_thumbnail_dirty = true

func _generate_thumbnail() -> void:
	if not _features_sampled:
		_sample_feature_colors()

	# Find most common tree species in this chunk
	var tree_color := Color(0.12, 0.35, 0.12)  # fallback
	if not features.is_empty():
		var counts: Dictionary = {}  # tile_id -> count
		for feat in features.values():
			var tid := int(feat)
			counts[tid] = counts.get(tid, 0) + 1
		var best_id := -1
		var best_count := 0
		for tid in counts:
			if counts[tid] > best_count:
				best_count = counts[tid]
				best_id = tid
		if best_id >= 0 and _feature_colors.has(best_id):
			tree_color = _feature_colors[best_id]

	var img := Image.create(CHUNK_SIZE, CHUNK_SIZE, false, Image.FORMAT_RGB8)
	var default_color := Color(0.5, 0.5, 0.5)
	for y in CHUNK_SIZE:
		var row_offset := y * CHUNK_SIZE
		for x in CHUNK_SIZE:
			var idx := row_offset + x
			var color: Color
			var tt: int = tile_types[idx]
			var is_water := (tt == PlanetMapTileConfig.TileType.FRESH_WATER)
			if is_water:
				color = THUMBNAIL_COLORS.get(tt, default_color)
				img.set_pixel(x, y, color)
			else:
				color = tree_color
				var brightness: float = PlanetMapTileConfig.get_elevation_brightness(render_layers[idx])
				img.set_pixel(x, y, Color(color.r * brightness, color.g * brightness, color.b * brightness))
	_thumbnail = ImageTexture.create_from_image(img)
	_thumbnail_dirty = false

## Sample canopy colors from tileset texture for each feature tile_id. Called once.
static func _sample_feature_colors() -> void:
	_features_sampled = true
	var tileset_image: Image = PlanetMapTileConfig.TILESET_TEXTURE.get_image()
	if tileset_image == null:
		return
	var tile_sz := PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	var inset := PlanetMapTileConfig.TILESET_REGION_INSET
	var img_w := tileset_image.get_width()
	var img_h := tileset_image.get_height()

	for tile_type in GeneratedTileTypes.TILESET_REGION_MAP.keys():
		var atlas: Vector2i = GeneratedTileTypes.TILESET_REGION_MAP[tile_type]
		var region_pos := atlas * tile_sz + inset
		var region_sz := tile_sz - inset * 2
		# Average non-transparent pixels in upper 70% (canopy, skip trunk)
		var r := 0.0
		var g := 0.0
		var b := 0.0
		var count := 0
		var y_end := region_sz.y * 7 / 10
		for sy in range(0, y_end, 3):
			for sx in range(0, region_sz.x, 3):
				var px := region_pos.x + sx
				var py := region_pos.y + sy
				if px >= img_w or py >= img_h:
					continue
				var c := tileset_image.get_pixel(px, py)
				if c.a > 0.3:
					r += c.r
					g += c.g
					b += c.b
					count += 1
		if count > 0:
			_feature_colors[tile_type] = Color(r / count, g / count, b / count, 1.0)

## Debug string representation
func _to_string() -> String:
	return "ChunkTileData(chunk=%s, bounds=%s-%s, features=%d)" % [
		chunk_pos,
		chunk_pos * CHUNK_SIZE,
		(chunk_pos + Vector2i.ONE) * CHUNK_SIZE - Vector2i.ONE,
		features.size()
	]
