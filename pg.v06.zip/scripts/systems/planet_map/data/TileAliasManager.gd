class_name TileAliasManager
extends RefCounted

## Singleton manager for tile aliases and metadata
##
## Loads tile catalog from JSON and provides access to tile metadata,
## custom aliases, and color variants.
##
## Usage:
##   var manager = TileAliasManager.new()
##   manager.load_catalog()
##   var tile = manager.get_tile_by_coords(3, 13)
##   print(tile.get_display_name())

const CATALOG_PATH := "res://tools/tile_catalog.json"
const USER_CATALOG_PATH := "user://tile_catalog.json"

## All tiles indexed by ID (row * 20 + col)
var tiles_by_id: Dictionary = {}  # int -> TileAliasData

## All tiles indexed by atlas coords (for quick lookup)
var tiles_by_coords: Dictionary = {}  # Vector2i -> TileAliasData

## Version of loaded catalog
var catalog_version: String = "1.0"

## Grid dimensions
var grid_cols: int = 20
var grid_rows: int = 10

## Total tile count
var total_tiles: int = 200

func _init():
	pass

## Load the tile catalog from JSON
func load_catalog() -> bool:
	# Try user catalog first (has custom edits), fall back to default
	var path = USER_CATALOG_PATH if FileAccess.file_exists(USER_CATALOG_PATH) else CATALOG_PATH

	if not FileAccess.file_exists(path):
		push_error("TileAliasManager: Catalog not found at %s" % path)
		return false

	var file = FileAccess.open(path, FileAccess.READ)
	if not file:
		push_error("TileAliasManager: Failed to open catalog at %s" % path)
		return false

	var json_string = file.get_as_text()
	file.close()

	var json = JSON.new()
	var error = json.parse(json_string)
	if error != OK:
		push_error("TileAliasManager: JSON parse error: %s" % json.get_error_message())
		return false

	var data = json.data
	if not data is Dictionary:
		push_error("TileAliasManager: Invalid catalog format")
		return false

	_parse_catalog(data)

	print("TileAliasManager: Loaded %d tiles from %s" % [tiles_by_id.size(), path])
	return true

func _parse_catalog(data: Dictionary) -> void:
	"""Parse the catalog JSON into TileAliasData objects."""
	catalog_version = data.get("version", "1.0")

	var grid_size = data.get("grid_size", {})
	grid_cols = grid_size.get("cols", 20)
	grid_rows = grid_size.get("rows", 10)
	total_tiles = grid_cols * grid_rows

	tiles_by_id.clear()
	tiles_by_coords.clear()

	var tiles_array = data.get("tiles", [])
	for tile_data in tiles_array:
		var tile = TileAliasData.from_dict(tile_data)
		tiles_by_id[tile.id] = tile
		tiles_by_coords[tile.atlas_coords] = tile

## Save the catalog to user:// directory (preserves custom edits)
func save_catalog() -> bool:
	var catalog = {
		"version": catalog_version,
		"tileset_path": "assets/big_iso_tileset.png",
		"tile_size": {
			"width": 160,
			"height": 160
		},
		"grid_size": {
			"cols": grid_cols,
			"rows": grid_rows
		},
		"tiles": []
	}

	# Serialize all tiles
	for tile_id in tiles_by_id:
		var tile: TileAliasData = tiles_by_id[tile_id]
		catalog["tiles"].append(tile.to_dict())

	# Save to user directory
	var json_string = JSON.stringify(catalog, "\t")
	var real_path = ProjectSettings.globalize_path(USER_CATALOG_PATH)
	print("TileAliasManager: Saving catalog to: %s (real path: %s)" % [USER_CATALOG_PATH, real_path])

	var file = FileAccess.open(USER_CATALOG_PATH, FileAccess.WRITE)
	if not file:
		var error = FileAccess.get_open_error()
		push_error("TileAliasManager: Failed to save catalog to %s (error: %s)" % [USER_CATALOG_PATH, error])
		return false

	file.store_string(json_string)
	file.close()

	print("TileAliasManager: ✓ Saved catalog with %d tiles to %s" % [tiles_by_id.size(), real_path])
	return true

## Get tile by ID (row * 20 + col)
func get_tile_by_id(tile_id: int) -> TileAliasData:
	return tiles_by_id.get(tile_id, null)

## Get tile by atlas coordinates (col, row)
func get_tile_by_coords(col: int, row: int) -> TileAliasData:
	return tiles_by_coords.get(Vector2i(col, row), null)

## Get tile by Vector2i coords
func get_tile_by_vector(coords: Vector2i) -> TileAliasData:
	return tiles_by_coords.get(coords, null)

## Get all tiles as an array
func get_all_tiles() -> Array[TileAliasData]:
	var result: Array[TileAliasData] = []
	# Sort by ID to maintain consistent order
	var sorted_ids = tiles_by_id.keys()
	sorted_ids.sort()
	for tile_id in sorted_ids:
		result.append(tiles_by_id[tile_id])
	return result

## Set custom alias for a tile
func set_custom_alias(tile_id: int, alias: String) -> bool:
	var tile = get_tile_by_id(tile_id)
	if not tile:
		return false
	tile.custom_alias = alias
	return true

## Set category for a tile
func set_category(tile_id: int, category: String) -> bool:
	var tile = get_tile_by_id(tile_id)
	if not tile:
		return false
	tile.category = category
	return true

## Add variant to a tile
func add_variant(tile_id: int, variant_name: String, color_swaps: Array[Dictionary]) -> bool:
	var tile = get_tile_by_id(tile_id)
	if not tile:
		return false
	tile.add_variant(variant_name, color_swaps)
	return true

## Search tiles by name (checks both default and custom aliases)
func search_tiles(query: String) -> Array[TileAliasData]:
	var results: Array[TileAliasData] = []
	var query_lower = query.to_lower()

	for tile in get_all_tiles():
		var name = tile.get_display_name().to_lower()
		if name.contains(query_lower):
			results.append(tile)

	return results

## Filter tiles by category
func get_tiles_by_category(category: String) -> Array[TileAliasData]:
	var results: Array[TileAliasData] = []
	for tile in get_all_tiles():
		if tile.category == category:
			results.append(tile)
	return results

## Get all unique categories
func get_all_categories() -> Array[String]:
	var categories: Dictionary = {}
	for tile in get_all_tiles():
		categories[tile.category] = true

	var result: Array[String] = []
	for cat in categories.keys():
		result.append(cat)
	result.sort()
	return result
