class_name TerrainDataSource
extends RefCounted

## Abstract interface for loading terrain chunk data
##
## Implementations:
## - PNGTerrainSource: Load from heightmap PNG
## - ProceduralTerrainSource: Generate with algorithms
## - CSVTerrainSource: Load from CSV (if needed)
##
## Usage:
##   var source = PNGTerrainSource.new("res://assets/terrain/reference/full_map_8bit.png")
##   var chunk_data = source.load_chunk(Vector2i(5, 10))

const LOG_TAG := "TERRAIN_SOURCE"

## Load chunk data at given chunk coordinates
## Returns ChunkTileData with elevation/type/feature data
## Must be overridden by subclasses
func load_chunk(_chunk_pos: Vector2i) -> ChunkTileData:
	push_error("TerrainDataSource.load_chunk() must be overridden by subclass")
	return null

## Get tile type at an absolute tile position
## Subclasses should override to return accurate types (e.g. water vs grass)
func get_tile_type_at_tile(_tile_pos: Vector2i) -> int:
	return PlanetMapTileConfig.TileType.GRASS_0

## Get total map bounds in chunk coordinates
## e.g., Rect2i(0, 0, 56, 56) for 3612×3612 map (56 chunks per axis)
## Must be overridden by subclasses
func get_bounds() -> Rect2i:
	push_error("TerrainDataSource.get_bounds() must be overridden by subclass")
	return Rect2i()

## Check if chunk position is within valid bounds
func is_valid_chunk(chunk_pos: Vector2i) -> bool:
	var bounds = get_bounds()
	return (chunk_pos.x >= bounds.position.x and
			chunk_pos.y >= bounds.position.y and
			chunk_pos.x < bounds.end.x and
			chunk_pos.y < bounds.end.y)

## Get total map size in tiles (convenience method)
func get_tile_size() -> Vector2i:
	var bounds = get_bounds()
	return bounds.size * ChunkTileData.CHUNK_SIZE

## Convert absolute tile position to chunk coordinates
static func tile_to_chunk(tile_pos: Vector2i) -> Vector2i:
	return Vector2i(
		floori(float(tile_pos.x) / ChunkTileData.CHUNK_SIZE),
		floori(float(tile_pos.y) / ChunkTileData.CHUNK_SIZE)
	)

## Convert chunk coordinates to absolute tile position (top-left corner)
static func chunk_to_tile(chunk_pos: Vector2i) -> Vector2i:
	return chunk_pos * ChunkTileData.CHUNK_SIZE

## Debug string representation
func _to_string() -> String:
	var bounds = get_bounds()
	var tile_size = get_tile_size()
	return "%s(chunks=%s, tiles=%dx%d)" % [
		get_script().get_global_name(),
		bounds.size,
		tile_size.x,
		tile_size.y
	]
