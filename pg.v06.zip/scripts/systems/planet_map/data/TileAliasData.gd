class_name TileAliasData
extends RefCounted

## Data class representing a tile's metadata and aliases
##
## Each tile in the tileset has:
## - Position in the atlas (row, col)
## - Default and custom aliases (names)
## - Category and tags for organization
## - Color variants for customization

var id: int = -1  # Unique tile ID (row * cols + col)
var row: int = -1  # Row in tileset (0-9)
var col: int = -1  # Column in tileset (0-19)
var atlas_coords: Vector2i = Vector2i(-1, -1)  # [col, row] for Godot atlas

var default_alias: String = ""  # Generated default name
var custom_alias: String = ""  # User-defined name (empty = use default)

var category: String = "Uncategorized"  # Organization category
var tags: Array[String] = []  # Search tags

var variants: Array = []  # Color variants [{name: String, swaps: Array}] - untyped for JSON compat

func _init(p_id: int = -1, p_row: int = -1, p_col: int = -1):
	id = p_id
	row = p_row
	col = p_col
	atlas_coords = Vector2i(p_col, p_row)
	default_alias = "Tile_R%d_C%d" % [p_row, p_col]

## Get the display name (custom if set, otherwise default)
func get_display_name() -> String:
	return custom_alias if custom_alias.length() > 0 else default_alias

## Check if this tile has a custom alias
func has_custom_alias() -> bool:
	return custom_alias.length() > 0

## Add a color variant
func add_variant(variant_name: String, color_swaps: Array) -> void:
	# Remove existing variant with same name
	remove_variant(variant_name)

	# Add new variant
	variants.append({
		"name": variant_name,
		"swaps": color_swaps
	})

## Get variant by name
func get_variant(variant_name: String) -> Dictionary:
	for variant in variants:
		if variant.name == variant_name:
			return variant
	return {}

## Remove variant by name
func remove_variant(variant_name: String) -> bool:
	for i in range(variants.size()):
		if variants[i].name == variant_name:
			variants.remove_at(i)
			return true
	return false

## Serialize to Dictionary for JSON export
func to_dict() -> Dictionary:
	return {
		"id": id,
		"row": row,
		"col": col,
		"atlas_coords": [atlas_coords.x, atlas_coords.y],
		"default_alias": default_alias,
		"custom_alias": custom_alias,
		"category": category,
		"tags": tags,
		"variants": variants
	}

## Deserialize from Dictionary
static func from_dict(data: Dictionary) -> TileAliasData:
	var tile = TileAliasData.new()
	tile.id = data.get("id", -1)
	tile.row = data.get("row", -1)
	tile.col = data.get("col", -1)

	var coords = data.get("atlas_coords", [0, 0])
	tile.atlas_coords = Vector2i(coords[0], coords[1])

	tile.default_alias = data.get("default_alias", "")

	# Handle null custom_alias (JSON has null, we need empty string)
	var custom_alias_value = data.get("custom_alias", "")
	tile.custom_alias = custom_alias_value if custom_alias_value != null else ""

	tile.category = data.get("category", "Uncategorized")

	# Handle tags (typed array needs manual copy)
	tile.tags.clear()
	var tags_data = data.get("tags", [])
	for tag in tags_data:
		tile.tags.append(str(tag))

	# Handle variants (untyped array, direct assignment OK)
	var variants_data = data.get("variants", [])
	tile.variants = variants_data if variants_data != null else []

	return tile
