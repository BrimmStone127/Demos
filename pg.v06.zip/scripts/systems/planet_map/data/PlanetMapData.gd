class_name PlanetMapData
extends RefCounted

## Central data store for planet map information
## Single source of truth for tile data, map size, and coordinate system
##
## Ownership Model:
##   - PlanetMapSystem OWNS the PlanetMapData instance
##   - Other systems (EcosystemManager, etc.) hold REFERENCES
##   - No duplication - single source of truth

# Map dimensions
var map_size: Vector2i

# Coordinate conversion system
var coordinate_system: CoordinateSystem

# Tile data (2D array of MapTile)
var tiles: Array  # Array[Array[MapTile]]

# Planet metadata
var planet_id: String
var planet: Planet = null
var probe_data: Dictionary = {}

func _init(p_map_size: Vector2i = Vector2i(64, 64), p_planet_id: String = ""):
	map_size = p_map_size
	planet_id = p_planet_id

	# Create coordinate system (using isometric footprint, not atlas source size)
	coordinate_system = CoordinateSystem.new(
		map_size,
		Vector2i(int(PlanetMapTileConfig.TILE_SIZE.x), int(PlanetMapTileConfig.TILE_SIZE.y)),
		64  # EcosystemManager.CHUNK_SIZE
	)

	# Initialize empty tile array
	tiles = []
	_initialize_tile_array()

func _initialize_tile_array() -> void:
	## Create empty tile array with correct dimensions
	tiles.clear()
	for x in range(map_size.x):
		var row: Array = []
		row.resize(map_size.y)
		tiles.append(row)

## Get tile at position (returns null if out of bounds)
func get_tile(pos: Vector2i) -> MapTile:
	if coordinate_system.is_valid_tile(pos):
		return tiles[pos.x][pos.y]
	return null

## Set tile at position (does nothing if out of bounds)
func set_tile(pos: Vector2i, tile: MapTile) -> void:
	if coordinate_system.is_valid_tile(pos):
		tiles[pos.x][pos.y] = tile

## Bulk set all tiles (updates map_size if dimensions changed)
func set_all_tiles(new_tiles: Array) -> void:
	tiles = new_tiles

	# Update map_size if it changed
	if tiles.size() > 0:
		var new_width = tiles.size()
		var new_height = tiles[0].size() if new_width > 0 else 0
		var new_size = Vector2i(new_width, new_height)

		if new_size != map_size:
			map_size = new_size
			# Recreate coordinate system with new size
			coordinate_system = CoordinateSystem.new(
				map_size,
				PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE,
				64
			)

## Get all tiles as 2D array (returns reference, not copy)
func get_all_tiles() -> Array:
	return tiles

## Check if tile array is empty
func is_empty() -> bool:
	return tiles.is_empty()

## Get number of tiles
func get_tile_count() -> int:
	var count = 0
	for row in tiles:
		count += row.size()
	return count

## Serialize to dictionary (for saving/caching)
func to_dict() -> Dictionary:
	return {
		"map_size": {"x": map_size.x, "y": map_size.y},
		"planet_id": planet_id,
		"tiles": _serialize_tiles()
	}

func _serialize_tiles() -> Array:
	## Convert tiles to serializable format
	var result = []
	for row in tiles:
		var row_data = []
		for tile in row:
			if tile:
				row_data.append(tile.to_dict() if tile.has_method("to_dict") else null)
			else:
				row_data.append(null)
		result.append(row_data)
	return result

## Load from dictionary
static func from_dict(data: Dictionary) -> PlanetMapData:
	var map_size_data = data.get("map_size", {"x": 64, "y": 64})
	var _map_size = Vector2i(int(map_size_data.x), int(map_size_data.y))
	var _planet_id = data.get("planet_id", "")

	var map_data = PlanetMapData.new(_map_size, _planet_id)

	# Deserialize tiles if present
	var tiles_data = data.get("tiles", [])
	if not tiles_data.is_empty():
		var loaded_tiles = []
		for row_data in tiles_data:
			var row = []
			for tile_data in row_data:
				if tile_data:
					# TODO: MapTile.from_dict() if we add serialization
					row.append(null)  # Placeholder
				else:
					row.append(null)
			loaded_tiles.append(row)
		map_data.tiles = loaded_tiles

	return map_data

## Get string representation for debugging
## Override built-in _to_string() for debug representation
func _to_string() -> String:
	return "PlanetMapData(id=%s, size=%dx%d, tiles=%d)" % [
		planet_id,
		map_size.x,
		map_size.y,
		get_tile_count()
	]
