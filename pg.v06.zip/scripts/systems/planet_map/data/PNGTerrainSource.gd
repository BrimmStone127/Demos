class_name PNGTerrainSource
extends TerrainDataSource

## Load terrain from PNG heightmap file
## Supports loading individual 64×64 chunks from large PNG files
##
## The PNG is loaded once and cached in memory for fast chunk extraction
## Grayscale PNG: pixel brightness (0.0-1.0) = elevation
##
## Optional water mask: a second grayscale PNG (same dimensions) where
## white pixels (>0.5) override tile type to SHALLOW_WATER.
## Edit water_mask.png in GIMP to adjust river/lake boundaries.
##
## Usage:
##   var source = PNGTerrainSource.new("res://assets/terrain/reference/full_map_8bit.png")
##   var chunk = source.load_chunk(Vector2i(10, 10))

# Full PNG image (loaded once, cached)
var _image: Image = null

# Optional water mask PNG (same dimensions as _image)
var _water_mask: Image = null

## Optional flow direction PNG (same dimensions as _image)
## Pixel values: 0-7 direction (E SE S SW W NW N NE), 8 = lake, 255 = not water
var _flow_direction: Image = null

# PNG dimensions in pixels (equals tile count)
var _png_size: Vector2i

# PNG file path
var _png_path: String

# Map bounds in chunks
var _bounds_chunks: Rect2i

# Optional elevation remapping (for consistent rendering across chunks)
var _use_percentile_remap: bool = false
var _percentile_min: float = 0.1  # 10th percentile
var _percentile_max: float = 0.95 # 95th percentile
var _cached_remap_values: Dictionary = {}  # Cache computed min/max

func _init(png_path: String, use_percentile_remap: bool = false, water_mask_path: String = "", flow_direction_path: String = ""):
	_png_path = png_path
	_use_percentile_remap = use_percentile_remap
	_load_png()
	if water_mask_path != "":
		_load_water_mask(water_mask_path)
	if flow_direction_path != "":
		_load_flow_direction(flow_direction_path)

## Load an Image from a res:// path, compatible with editor and exported builds.
## Image.load_from_file() fails inside exported PCKs (reads OS filesystem only).
## ResourceLoader works in exports but get_image() returns null or bad pixel data
## in editor/dev builds due to Godot's internal texture compression pipeline.
## Solution: try load_from_file first (editor), fall back to ResourceLoader (exports).
func _load_image_from_path(path: String) -> Image:
	var abs_path = ProjectSettings.globalize_path(path)
	var img := Image.load_from_file(abs_path)
	if img != null:
		return img
	# Fallback for exported builds where raw PNG is inside the PCK as .ctex
	var tex := ResourceLoader.load(path, "Texture2D") as Texture2D
	if tex == null:
		return null
	return tex.get_image()


func _load_flow_direction(path: String) -> void:
	if not ResourceLoader.exists(path):
		GameLog.warn(LOG_TAG, "Flow direction map not found: %s" % path)
		return
	_flow_direction = _load_image_from_path(path)
	if _flow_direction == null:
		GameLog.warn(LOG_TAG, "Failed to load flow direction map: %s" % path)
		return
	var fd_size = Vector2i(_flow_direction.get_width(), _flow_direction.get_height())
	if fd_size != _png_size:
		GameLog.warn(LOG_TAG, "Flow direction size %s != terrain size %s — ignoring" % [fd_size, _png_size])
		_flow_direction = null
		return
	GameLog.info(LOG_TAG, "Flow direction map loaded: %dx%d" % [fd_size.x, fd_size.y])


func _load_water_mask(mask_path: String):
	if not ResourceLoader.exists(mask_path):
		GameLog.warn(LOG_TAG, "Water mask not found: %s" % mask_path)
		return
	_water_mask = _load_image_from_path(mask_path)
	if _water_mask == null:
		GameLog.warn(LOG_TAG, "Failed to load water mask: %s" % mask_path)
		return
	var mask_size = Vector2i(_water_mask.get_width(), _water_mask.get_height())
	if mask_size != _png_size:
		GameLog.warn(LOG_TAG, "Water mask size %s does not match terrain size %s — ignoring" % [mask_size, _png_size])
		_water_mask = null
		return
	GameLog.info(LOG_TAG, "Water mask loaded: %dx%d" % [mask_size.x, mask_size.y])

func _load_png():
	"""Load PNG file and calculate bounds"""
	if not ResourceLoader.exists(_png_path):
		GameLog.error(LOG_TAG, "PNG file not found: %s" % _png_path)
		return

	_image = _load_image_from_path(_png_path)

	if _image == null:
		GameLog.error(LOG_TAG, "Failed to load PNG: %s" % _png_path)
		return

	_png_size = Vector2i(_image.get_width(), _image.get_height())

	# Calculate chunk bounds (round up to include partial chunks)
	var chunks_x = ceili(float(_png_size.x) / ChunkTileData.CHUNK_SIZE)
	var chunks_y = ceili(float(_png_size.y) / ChunkTileData.CHUNK_SIZE)
	_bounds_chunks = Rect2i(Vector2i.ZERO, Vector2i(chunks_x, chunks_y))

	GameLog.info(LOG_TAG, "Loaded PNG: %dx%d pixels, %dx%d chunks" % [
		_png_size.x, _png_size.y,
		chunks_x, chunks_y
	])

	# Pre-calculate percentile remapping if enabled — load from disk cache if available
	if _use_percentile_remap:
		if not _load_percentile_cache():
			_calculate_percentile_remapping()
			_save_percentile_cache()

## Path for the persistent percentile cache file.
## Keyed to the PNG filename so a different terrain asset invalidates automatically.
func _percentile_cache_path() -> String:
	var key = _png_path.get_file().get_basename()
	return "user://terrain_percentile_%s.json" % key

## Load cached percentile values from disk. Returns true if loaded successfully.
func _load_percentile_cache() -> bool:
	var path := _percentile_cache_path()
	if not FileAccess.file_exists(path):
		return false
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return false
	var data = JSON.parse_string(f.get_as_text())
	f.close()
	if data == null or not data.has("min") or not data.has("max") or not data.has("png_size"):
		return false
	# Invalidate if PNG dimensions changed (asset was replaced)
	var cached_size = data["png_size"]
	if cached_size.get("x", -1) != _png_size.x or cached_size.get("y", -1) != _png_size.y:
		GameLog.info(LOG_TAG, "Terrain percentile cache invalid (size mismatch), recomputing...")
		return false
	_cached_remap_values["min"] = float(data["min"])
	_cached_remap_values["max"] = float(data["max"])
	GameLog.info(LOG_TAG, "Percentile remapping loaded from cache: %.3f - %.3f" % [
		_cached_remap_values["min"], _cached_remap_values["max"]
	])
	return true

## Write computed percentile values to disk so future sessions skip the calculation.
func _save_percentile_cache() -> void:
	if not _cached_remap_values.has("min"):
		return
	var path := _percentile_cache_path()
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		GameLog.warn(LOG_TAG, "Could not write percentile cache to %s" % path)
		return
	var data = {
		"png_size": {"x": _png_size.x, "y": _png_size.y},
		"min": _cached_remap_values["min"],
		"max": _cached_remap_values["max"],
	}
	f.store_string(JSON.stringify(data))
	f.close()
	GameLog.info(LOG_TAG, "Percentile cache saved to %s" % path)

func _calculate_percentile_remapping():
	"""Sample PNG to find 10th and 95th percentile elevations for remapping"""
	if _image == null:
		return

	GameLog.info(LOG_TAG, "Calculating percentile remapping (first time — will be cached)...")

	var sample_step = 10  # Sample every 10th pixel for speed
	var elevations: Array[float] = []

	for y in range(0, _png_size.y, sample_step):
		for x in range(0, _png_size.x, sample_step):
			var color = _image.get_pixel(x, y)
			elevations.append(color.r)  # Grayscale value

	elevations.sort()

	if elevations.size() > 0:
		var p10_idx = int(elevations.size() * _percentile_min)
		var p95_idx = int(elevations.size() * _percentile_max)

		_cached_remap_values["min"] = elevations[p10_idx]
		_cached_remap_values["max"] = elevations[p95_idx]

		GameLog.info(LOG_TAG, "Percentile remapping: %.3f - %.3f" % [
			_cached_remap_values["min"],
			_cached_remap_values["max"]
		])

func get_bounds() -> Rect2i:
	return _bounds_chunks

func load_chunk(chunk_pos: Vector2i) -> ChunkTileData:
	if _image == null:
		GameLog.error(LOG_TAG, "Cannot load chunk - PNG not loaded")
		return null

	if not is_valid_chunk(chunk_pos):
		GameLog.warn(LOG_TAG, "Chunk %s out of bounds %s" % [chunk_pos, _bounds_chunks.size])
		return null

	var chunk_data = ChunkTileData.new(chunk_pos)

	# Calculate pixel region for this chunk
	var pixel_offset = chunk_pos * ChunkTileData.CHUNK_SIZE

	# Extract 64×64 elevation values from PNG
	for local_y in range(ChunkTileData.CHUNK_SIZE):
		for local_x in range(ChunkTileData.CHUNK_SIZE):
			var px = pixel_offset.x + local_x
			var py = pixel_offset.y + local_y

			var elevation: float
			if px >= 0 and px < _png_size.x and py >= 0 and py < _png_size.y:
				var color = _image.get_pixel(px, py)
				elevation = color.r  # Grayscale value (0.0-1.0)

				# Apply percentile remapping if enabled
				if _use_percentile_remap and not _cached_remap_values.is_empty():
					elevation = _remap_elevation(elevation)
			else:
				# Out of bounds = default elevation
				elevation = 0.5

			chunk_data.set_elevation(Vector2i(local_x, local_y), elevation)
			var tile_type = _elevation_to_tile_type(elevation)
			if _water_mask != null and px >= 0 and px < _png_size.x and py >= 0 and py < _png_size.y:
				if _water_mask.get_pixel(px, py).r > 0.5:
					tile_type = PlanetMapTileConfig.TileType.FRESH_WATER
			chunk_data.set_tile_type(Vector2i(local_x, local_y), tile_type)

			if _flow_direction != null and px >= 0 and px < _png_size.x and py >= 0 and py < _png_size.y:
				var fd_value: int = int(_flow_direction.get_pixel(px, py).r * 255.0)
				chunk_data.set_flow_direction(Vector2i(local_x, local_y), fd_value)

	return chunk_data

func _remap_elevation(raw_elevation: float) -> float:
	"""Remap elevation using percentile values for consistent rendering"""
	var min_val = _cached_remap_values.get("min", 0.0)
	var max_val = _cached_remap_values.get("max", 1.0)

	if max_val <= min_val:
		return raw_elevation

	# Clamp and remap to 0.0-1.0 range
	var clamped = clampf(raw_elevation, min_val, max_val)
	return (clamped - min_val) / (max_val - min_val)

## Convert elevation (0.0-1.0) to appropriate tile type
func _elevation_to_tile_type(_elevation: float) -> int:
	# PNG terrain is only used for highly habitable planets (habitability >= 0.7)
	# For habitable planets, ALL tiles are GRASS_0 regardless of elevation
	# Elevation differences are shown through brightness shading, not tile type variation
	return PlanetMapTileConfig.TileType.GRASS_0

## Get tile type at a specific tile position, accounting for water mask
func get_tile_type_at_tile(tile_pos: Vector2i) -> int:
	if _water_mask != null and tile_pos.x >= 0 and tile_pos.y >= 0 and tile_pos.x < _png_size.x and tile_pos.y < _png_size.y:
		if _water_mask.get_pixel(tile_pos.x, tile_pos.y).r > 0.5:
			return PlanetMapTileConfig.TileType.FRESH_WATER
	return PlanetMapTileConfig.TileType.GRASS_0

## Get the elevation at a specific tile position (direct pixel lookup)
func get_elevation_at_tile(tile_pos: Vector2i) -> float:
	if _image == null:
		return 0.5
	if tile_pos.x < 0 or tile_pos.y < 0 or tile_pos.x >= _png_size.x or tile_pos.y >= _png_size.y:
		return 0.5
	var elevation = _image.get_pixel(tile_pos.x, tile_pos.y).r
	if _use_percentile_remap and not _cached_remap_values.is_empty():
		elevation = _remap_elevation(elevation)
	return elevation

## Get flow direction at a specific tile position.
## Returns 0-7 (compass direction), 8 (lake), or 255 (not water / no data).
func get_flow_direction_at_tile(tile_pos: Vector2i) -> int:
	if _flow_direction == null:
		return 255
	if tile_pos.x < 0 or tile_pos.y < 0 or tile_pos.x >= _png_size.x or tile_pos.y >= _png_size.y:
		return 255
	return int(_flow_direction.get_pixel(tile_pos.x, tile_pos.y).r * 255.0)

## Returns true if flow direction data is loaded.
func has_flow_direction() -> bool:
	return _flow_direction != null

## Check if PNG loaded successfully
func is_loaded() -> bool:
	return _image != null

## Get PNG dimensions in tiles
func get_png_size() -> Vector2i:
	return _png_size

## Debug string
func _to_string() -> String:
	return "PNGTerrainSource(path=%s, size=%dx%d, chunks=%dx%d)" % [
		_png_path.get_file(),
		_png_size.x, _png_size.y,
		_bounds_chunks.size.x, _bounds_chunks.size.y
	]
