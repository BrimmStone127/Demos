class_name CoordinateSystem
extends RefCounted

## Central authority for all coordinate system conversions
## Handles tile <-> world <-> chunk coordinate transformations
## Supports dynamic map sizes (not hardcoded to 64x64)

const LOG_TAG := "COORD_SYSTEM"

# Map properties
var map_size: Vector2i
var tile_size: Vector2i
var chunk_size: int

# Constructor
func _init(p_map_size: Vector2i = Vector2i(64, 64), p_tile_size: Vector2i = Vector2i(160, 80), p_chunk_size: int = 64):
	map_size = p_map_size
	tile_size = p_tile_size
	chunk_size = p_chunk_size
	_log_info("CoordinateSystem initialized: map=%sx%s, tile=%sx%s, chunk_size=%d", [
		map_size.x, map_size.y, tile_size.x, tile_size.y, chunk_size
	])

func _log_info(message: String, values: Array = []):
	if values.is_empty():
		GameLog.info(LOG_TAG, message)
	else:
		GameLog.info(LOG_TAG, message % values)

## TILE COORDINATES
## Integer grid positions (0-based): (0,0) to (map_size.x-1, map_size.y-1)

func is_valid_tile(tile: Vector2i) -> bool:
	return tile.x >= 0 and tile.y >= 0 and tile.x < map_size.x and tile.y < map_size.y

func clamp_tile(tile: Vector2i) -> Vector2i:
	return Vector2i(
		clampi(tile.x, 0, map_size.x - 1),
		clampi(tile.y, 0, map_size.y - 1)
	)

## WORLD COORDINATES
## Pixel positions in the game world (isometric space)

func tile_to_world(tile: Vector2i) -> Vector2:
	# Isometric projection: tile grid to world pixels
	# Formula from PlanetMapCoordinates.grid_to_world()
	var world_x = (tile.x - tile.y) * (tile_size.x / 2.0)
	var world_y = (tile.x + tile.y) * (tile_size.y / 2.0)
	return Vector2(world_x, world_y)

func world_to_tile(world: Vector2) -> Vector2i:
	# Inverse isometric projection: world pixels to tile grid
	# Formula from PlanetMapCoordinates.world_to_grid()
	var tile_x = (world.x / (tile_size.x / 2.0) + world.y / (tile_size.y / 2.0)) / 2.0
	var tile_y = (world.y / (tile_size.y / 2.0) - world.x / (tile_size.x / 2.0)) / 2.0
	return Vector2i(int(floor(tile_x)), int(floor(tile_y)))

## CHUNK COORDINATES
## Chunk grid positions (tiles divided into chunk_size regions)

func tile_to_chunk(tile: Vector2i) -> Vector2i:
	@warning_ignore("integer_division")
	return Vector2i(tile.x / chunk_size, tile.y / chunk_size)

func chunk_to_tile_bounds(chunk: Vector2i) -> Rect2i:
	# Returns the tile range for this chunk
	var min_tile = Vector2i(chunk.x * chunk_size, chunk.y * chunk_size)
	var max_tile = Vector2i(
		mini((chunk.x + 1) * chunk_size, map_size.x),
		mini((chunk.y + 1) * chunk_size, map_size.y)
	)
	return Rect2i(min_tile, max_tile - min_tile)

func world_to_chunk(world: Vector2) -> Vector2i:
	var tile = world_to_tile(world)
	return tile_to_chunk(tile)

## MAP CENTER

func get_map_center_tile() -> Vector2i:
	return Vector2i(map_size.x >> 1, map_size.y >> 1)

func get_map_center_world() -> Vector2:
	return tile_to_world(get_map_center_tile())

## BOUNDS CHECKING

func get_tile_bounds() -> Rect2i:
	return Rect2i(Vector2i(0, 0), map_size)

func get_chunk_bounds() -> Rect2i:
	@warning_ignore("integer_division")
	var max_chunk = Vector2i(
		(map_size.x + chunk_size - 1) / chunk_size,  # Ceiling division
		(map_size.y + chunk_size - 1) / chunk_size
	)
	return Rect2i(Vector2i(0, 0), max_chunk)

## DEBUG
## Override built-in _to_string() for debug representation

func _to_string() -> String:
	return "CoordinateSystem[map=%sx%s, tile=%sx%s, chunk=%d]" % [
		map_size.x, map_size.y, tile_size.x, tile_size.y, chunk_size
	]
