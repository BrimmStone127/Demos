class_name BaseballField
extends Node2D

# Renders a flat grass field using the shared isometric tileset.
# Deliberately has NO _draw() — all field markings and game elements are drawn
# by BaseballGame._FieldOverlay, which sits above this node in the SubViewport.
# All ground tiles use GRASS_0 (the slab-style tile used throughout the game).

const FIELD_SIZE    := Vector2i(16, 16)

# Key grid positions.
# iso rule: visual bottom = high x+y, visual right = high x low y
# Diamond spans (7,7)→(14,14) — home plate anchored at (14,14).
const HOME_PLATE    := Vector2i(14, 14)   # visual bottom
const FIRST_BASE    := Vector2i(14, 7)    # visual right
const SECOND_BASE   := Vector2i(7, 7)     # visual top
const THIRD_BASE    := Vector2i(7, 14)    # visual left
const PITCHER_MOUND := Vector2i(10, 10)   # between home and 2nd


var tilemap: TileMap   # exposed for picking / drawing alignment

func _ready() -> void:
	tilemap = TileMap.new()
	tilemap.name = "FieldTileMap"
	tilemap.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	tilemap.tile_set = PlanetMapTileConfig.get_shared_tileset()
	tilemap.y_sort_enabled = true
	add_child(tilemap)

	var atlas := PlanetMapTileConfig.get_atlas_coords(PlanetMapTileConfig.TileType.GRASS_0)
	for x in range(FIELD_SIZE.x):
		for y in range(FIELD_SIZE.y):
			tilemap.set_cell(0, Vector2i(x, y), PlanetMapTileConfig.TILESET_SOURCE_ID, atlas)
