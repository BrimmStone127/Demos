class_name BaseballGame
extends Control

# Home run derby minigame.
# The field is rendered in a SubViewport using the real isometric tileset.
# _FieldOverlay (a Node2D above the field in the SubViewport) draws EVERYTHING:
# field lines, bases, pitcher marker, batter, and the ball.
# Input is handled on this Control so the whole panel acts as the click target.

signal back_pressed()

const LOG_TAG := "BASEBALL"

# ── Timing ────────────────────────────────────────────────────────────────────
const WINDUP_DURATION       := 0.7
const PITCH_DURATION        := 0.35   # Ball travel time — must exceed HIT_WINDOW_CENTER + FOUL_ZONE_HALF
const HIT_WINDOW_CENTER     := 0.24   # Seconds in (ball near plate)
const RESULT_DISPLAY_TIME   := 1.2

# Swing timing zones (distance from HIT_WINDOW_CENTER):
#   0..SWEET_SPOT  → home run, max exit speed, near center field
#   SWEET_SPOT..GOOD_HIT → solid hit, good speed, angled by timing
#   GOOD_HIT..FOUL → foul ball, clipped it
#   beyond FOUL   → whiff (strike)
const SWEET_SPOT_HALF       := 0.035
const GOOD_HIT_HALF         := 0.055
const FOUL_ZONE_HALF        := 0.080

# Hit ball physics
const BALL_SPEED_HR         := 1400.0   # Exit speed for sweet spot
const BALL_SPEED_GOOD       := 900.0    # Exit speed at edge of good-hit zone
const BALL_SPEED_FOUL       := 500.0    # Foul ball speed
const PULL_ANGLE_MAX        := 0.8      # Max radians from center-field axis

# ── Visuals ───────────────────────────────────────────────────────────────────
const COLOR_BASELINE        := Color(1.0, 1.0, 1.0, 0.85)
const COLOR_BASE            := Color(1.0, 1.0, 1.0, 1.0)
const COLOR_MOUND           := Color(0.9, 0.75, 0.5, 1.0)
const COLOR_PITCHER_IDLE    := Color(0.35, 0.35, 0.35)
const COLOR_PITCHER_WINDUP  := Color(0.95, 0.85, 0.1)
const COLOR_PITCHER_THROW   := Color(0.9, 0.15, 0.15)
const COLOR_BATTER          := Color(0.2, 0.7, 1.0)
const COLOR_BALL            := Color(1.0, 1.0, 1.0)
const COLOR_BALL_HIT        := Color(1.0, 0.9, 0.1)   # gold tint when crushed
const COLOR_HIGHLIGHT       := Color(0.2, 0.8, 1.0, 0.4)   # cyan tile highlight
const COLOR_BALL_FOUL       := Color(0.7, 0.7, 0.7)        # grey for foul balls
const PITCHER_HALF          := 18.0
const BATTER_HALF           := 14.0
const BASE_HALF             := 12.0
const MOUND_RADIUS          := 10.0
const BALL_RADIUS           := 12.0
const LINE_WIDTH            := 2.0

# ── State ─────────────────────────────────────────────────────────────────────
enum _State { IDLE, WINDUP, PITCH, RESULT }
enum _HitResult { NONE, STRIKE, FOUL, HIT, HOME_RUN }

var _state: _State           = _State.IDLE
var _hit_result: _HitResult  = _HitResult.NONE
var _pitch_timer: float      = 0.0
var _pitch_elapsed: float    = 0.0
var _swung: bool             = false
var _hr_count: int           = 0
var _hit_count: int          = 0
var _streak: int             = 0

# World-space positions (SubViewport coordinate space)
var _pitcher_world: Vector2
var _home_world: Vector2
var _ball_pos: Vector2
var _ball_visible: bool = false
var _ball_is_hit: bool  = false
var _ball_vel: Vector2  = Vector2.ZERO
var _pitcher_color: Color = COLOR_PITCHER_IDLE
var _selected_cell: Vector2i = Vector2i(-1, -1)   # right-click tile pick

# ── UI refs ───────────────────────────────────────────────────────────────────
var _hr_label: Label
var _status_label: Label
var _prompt_label: Label
var _tile_label: Label

# ── Viewport refs ─────────────────────────────────────────────────────────────
var _sub_viewport: SubViewport
var _overlay: _FieldOverlay
var _camera_controller: PlanetMapCamera
var _svc: SubViewportContainer
var _field: BaseballField


func _ready() -> void:
	_build_ui()
	# Compute world positions AFTER _build_ui() so _field.tilemap exists.
	_pitcher_world = _grid_to_world(BaseballField.PITCHER_MOUND)
	_home_world    = _grid_to_world(BaseballField.HOME_PLATE)
	_ball_pos      = _pitcher_world
	call_deferred("_setup_camera")


func _setup_camera() -> void:
	if _camera_controller == null:
		return
	var center := (_grid_to_world(BaseballField.HOME_PLATE) + _grid_to_world(BaseballField.SECOND_BASE)) * 0.5
	_camera_controller.setup_camera(Vector2(0.70, 0.70), center)


func _grid_to_world(cell: Vector2i) -> Vector2:
	# Reusable helper — visual_offset defaults to ZERO for slab/grass tiles.
	return PlanetMapCoordinates.cell_center(cell, _field.tilemap)


# ── UI construction ───────────────────────────────────────────────────────────

func _build_ui() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP   # ensures _gui_input fires on this control

	var vbox := VBoxContainer.new()
	vbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	vbox.add_theme_constant_override("separation", 0)
	add_child(vbox)

	vbox.add_child(_build_header())
	vbox.add_child(_build_viewport_container())
	vbox.add_child(_build_status_bar())


func _build_header() -> Control:
	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 16)
	hbox.custom_minimum_size.y = 36

	var back_btn := Button.new()
	back_btn.text = "Back"
	back_btn.pressed.connect(func(): back_pressed.emit())
	hbox.add_child(back_btn)

	_hr_label = Label.new()
	_hr_label.text = "HR: 0  HITS: 0"
	_hr_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_hr_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hbox.add_child(_hr_label)

	_prompt_label = Label.new()
	_prompt_label.text = "Click anywhere to start"
	_prompt_label.custom_minimum_size.x = 220
	_prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	hbox.add_child(_prompt_label)

	return hbox


func _build_viewport_container() -> Control:
	var svc := SubViewportContainer.new()
	svc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	svc.size_flags_vertical   = Control.SIZE_EXPAND_FILL
	svc.stretch = false
	svc.mouse_filter = Control.MOUSE_FILTER_PASS   # propagate clicks up to BaseballGame
	svc.resized.connect(_on_svc_resized.bind(svc))

	_sub_viewport = SubViewport.new()
	_sub_viewport.size = Vector2i(960, 640)   # initial size; resized signal updates it
	_sub_viewport.transparent_bg = false
	_sub_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS

	if _sub_viewport.has_method("set_snap_2d_transforms_to_pixel"):
		_sub_viewport.snap_2d_transforms_to_pixel = true
	if _sub_viewport.has_method("set_snap_2d_vertices_to_pixel"):
		_sub_viewport.snap_2d_vertices_to_pixel = true
	if ClassDB.class_has_integer_constant("Viewport", "DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST"):
		_sub_viewport.canvas_item_default_texture_filter = ClassDB.class_get_integer_constant(
			"Viewport", "DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST"
		)
	svc.add_child(_sub_viewport)

	# Field (TileMap) — no drawing, just grass tiles
	_field = BaseballField.new()
	_sub_viewport.add_child(_field)

	# Overlay draws on TOP of the field: lines, bases, pitcher, batter, ball.
	# Added AFTER the field so it renders above it.
	_overlay = _FieldOverlay.new()
	_overlay.game = self
	_sub_viewport.add_child(_overlay)

	# Camera controller — middle-click pan, scroll zoom, WASD movement.
	# Initial position/zoom set in _setup_camera() via call_deferred.
	_camera_controller = PlanetMapCamera.new()
	_sub_viewport.add_child(_camera_controller)

	_svc = svc
	# Connect directly to the SVC's gui_input so event.position is already in SubViewport
	# pixel space — matches how MapViewport.gd handles coordinate conversion.
	svc.gui_input.connect(_on_svc_gui_input)
	return svc


func _build_status_bar() -> Control:
	var container := PanelContainer.new()
	container.custom_minimum_size.y = 36

	var hbox := HBoxContainer.new()
	container.add_child(hbox)

	_status_label = Label.new()
	_status_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status_label.add_theme_font_size_override("font_size", 20)
	hbox.add_child(_status_label)

	_tile_label = Label.new()
	_tile_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_tile_label.custom_minimum_size.x = 120
	hbox.add_child(_tile_label)

	return container


func _on_svc_resized(svc: SubViewportContainer) -> void:
	if _sub_viewport and svc.size.x > 0 and svc.size.y > 0:
		_sub_viewport.size = Vector2i(int(svc.size.x), int(svc.size.y))


# ── Input ─────────────────────────────────────────────────────────────────────

func _gui_input(event: InputEvent) -> void:
	# Forward all events to the camera controller (scroll zoom, middle/right-click pan).
	if _camera_controller and _camera_controller.handle_input_event(event):
		return

	# Only left-click game actions here — right-click is handled by _on_svc_gui_input.
	if not (event is InputEventMouseButton):
		return
	var mb := event as InputEventMouseButton
	if mb.button_index != MOUSE_BUTTON_LEFT or not mb.pressed:
		return

	match _state:
		_State.IDLE:
			_begin_windup()
		_State.PITCH:
			if not _swung:
				_swing()


func _on_svc_gui_input(event: InputEvent) -> void:
	# Tile picking via right-click.
	# event.position here is in the SVC's LOCAL coordinate space, which with
	# stretch=false equals SubViewport pixel space — the correct input for
	# get_canvas_transform().affine_inverse().  This matches MapViewport.gd.
	if not (event is InputEventMouseButton):
		return
	var mb := event as InputEventMouseButton
	if mb.button_index == MOUSE_BUTTON_RIGHT and mb.pressed:
		_pick_tile_at(mb.position)


func _pick_tile_at(vp_point: Vector2) -> void:
	# Reusable helper — visual_offset defaults to ZERO for slab/grass tiles.
	if _sub_viewport == null or _field == null or _field.tilemap == null:
		return
	var cell := PlanetMapCoordinates.pick_cell(vp_point, _sub_viewport, _field.tilemap)
	# Clamp to field bounds
	var fs := BaseballField.FIELD_SIZE
	if cell.x < 0 or cell.y < 0 or cell.x >= fs.x or cell.y >= fs.y:
		_selected_cell = Vector2i(-1, -1)
		_tile_label.text = ""
	else:
		_selected_cell = cell
		_tile_label.text = "(%d, %d)" % [cell.x, cell.y]
	_overlay.queue_redraw()



# ── Game loop ─────────────────────────────────────────────────────────────────

func _process(delta: float) -> void:
	match _state:

		_State.WINDUP:
			_pitch_timer -= delta
			if _pitch_timer <= 0.0:
				_launch_pitch()

		_State.PITCH:
			_pitch_elapsed += delta
			var t := clampf(_pitch_elapsed / PITCH_DURATION, 0.0, 1.0)
			_ball_pos = _pitcher_world.lerp(_home_world, t)
			_overlay.queue_redraw()
			if t >= 1.0:
				_hit_result = _HitResult.STRIKE
				_ball_visible = false
				_resolve()

		_State.RESULT:
			_pitch_timer -= delta
			if _ball_visible:
				_ball_pos += _ball_vel * delta
				_overlay.queue_redraw()
			if _pitch_timer <= 0.0:
				_begin_windup()


func _begin_windup() -> void:
	_state = _State.WINDUP
	_pitch_timer = WINDUP_DURATION
	_swung = false
	_hit_result = _HitResult.NONE
	_ball_visible = false
	_ball_is_hit  = false
	_pitcher_color = COLOR_PITCHER_WINDUP
	_overlay.queue_redraw()
	_prompt_label.text = "Get ready..."
	_status_label.text = ""


func _launch_pitch() -> void:
	_state = _State.PITCH
	_pitch_elapsed = 0.0
	_ball_pos = _pitcher_world
	_ball_visible = true
	_pitcher_color = COLOR_PITCHER_THROW
	_overlay.queue_redraw()
	_prompt_label.text = "SWING!"


func _swing() -> void:
	_swung = true
	var timing_offset := _pitch_elapsed - HIT_WINDOW_CENTER   # negative=early, positive=late
	var abs_offset := absf(timing_offset)

	# Determine result from timing zone
	if abs_offset <= SWEET_SPOT_HALF:
		_hit_result = _HitResult.HOME_RUN
	elif abs_offset <= GOOD_HIT_HALF:
		_hit_result = _HitResult.HIT
	elif abs_offset <= FOUL_ZONE_HALF:
		_hit_result = _HitResult.FOUL
	else:
		_hit_result = _HitResult.STRIKE

	# Compute ball direction and speed for non-whiff results
	if _hit_result == _HitResult.HOME_RUN or _hit_result == _HitResult.HIT or _hit_result == _HitResult.FOUL:
		_ball_is_hit = true
		_ball_visible = true
		# Center-field direction: home plate → second base (normalized)
		var center_dir := (_grid_to_world(BaseballField.SECOND_BASE) - _home_world).normalized()
		# Rotate by timing: early swing pulls, late swing goes opposite field
		var angle_factor := clampf(timing_offset / GOOD_HIT_HALF, -1.0, 1.0)
		var angle := angle_factor * PULL_ANGLE_MAX
		var hit_dir := center_dir.rotated(angle)
		# Speed based on how close to center
		var speed: float
		match _hit_result:
			_HitResult.HOME_RUN:
				speed = BALL_SPEED_HR
			_HitResult.HIT:
				var t := BaseballGame.inversf(abs_offset, SWEET_SPOT_HALF, GOOD_HIT_HALF)
				speed = lerpf(BALL_SPEED_HR, BALL_SPEED_GOOD, t)
			_HitResult.FOUL:
				speed = BALL_SPEED_FOUL
				# Fouls go more sideways — exaggerate the angle
				hit_dir = center_dir.rotated(angle_factor * PI * 0.45)
		_ball_vel = hit_dir * speed
	else:
		_ball_is_hit = false
		_ball_vel = Vector2.ZERO
		_ball_visible = false

	_resolve()


## Map abs_offset from range [from, to] into 0..1
static func inversf(value: float, from: float, to: float) -> float:
	if to == from:
		return 0.0
	return clampf((value - from) / (to - from), 0.0, 1.0)


func _resolve() -> void:
	_state = _State.RESULT
	_pitch_timer = RESULT_DISPLAY_TIME
	_pitcher_color = COLOR_PITCHER_IDLE
	_overlay.queue_redraw()

	if not _swung:
		_hit_result = _HitResult.STRIKE

	match _hit_result:
		_HitResult.HOME_RUN:
			_hr_count += 1
			_streak += 1
			_status_label.text = "HOME RUN!" if _streak == 1 else "HOME RUN! x%d streak" % _streak
		_HitResult.HIT:
			_hit_count += 1
			_streak = 0
			_status_label.text = "Solid hit!"
		_HitResult.FOUL:
			_streak = 0
			_status_label.text = "Foul ball"
		_HitResult.STRIKE, _HitResult.NONE:
			_streak = 0
			_status_label.text = "Strike!" if _swung else "Strike! (looking)"
	_hr_label.text = "HR: %d  HITS: %d" % [_hr_count, _hit_count]
	_prompt_label.text = ""


# ── Inner class: all in-world drawing ─────────────────────────────────────────

class _FieldOverlay extends Node2D:
	var game: BaseballGame

	# Helper: world position for a grid cell — delegates to the game's TileMap-based calculation.
	func _wp(cell: Vector2i) -> Vector2:
		return game._grid_to_world(cell)

	func _draw() -> void:
		if game == null:
			return

		var home   := _wp(BaseballField.HOME_PLATE)
		var first  := _wp(BaseballField.FIRST_BASE)
		var second := _wp(BaseballField.SECOND_BASE)
		var third  := _wp(BaseballField.THIRD_BASE)
		var mound  := _wp(BaseballField.PITCHER_MOUND)

		# ── Field markings ────────────────────────────────────────────────────
		# Baselines
		draw_line(home,   first,  BaseballGame.COLOR_BASELINE, BaseballGame.LINE_WIDTH)
		draw_line(first,  second, BaseballGame.COLOR_BASELINE, BaseballGame.LINE_WIDTH)
		draw_line(second, third,  BaseballGame.COLOR_BASELINE, BaseballGame.LINE_WIDTH)
		draw_line(third,  home,   BaseballGame.COLOR_BASELINE, BaseballGame.LINE_WIDTH)

		# Bases (white squares)
		for pt in [first, second, third]:
			var bh := BaseballGame.BASE_HALF
			draw_rect(Rect2(pt - Vector2(bh, bh), Vector2(bh * 2.0, bh * 2.0)), BaseballGame.COLOR_BASE)

		# Home plate (slightly larger pentagon-ish — use rect for placeholder)
		var hbh := BaseballGame.BASE_HALF * 1.3
		draw_rect(Rect2(home - Vector2(hbh, hbh), Vector2(hbh * 2.0, hbh * 2.0)), BaseballGame.COLOR_BASE)

		# Pitcher mound (circle)
		draw_circle(mound, BaseballGame.MOUND_RADIUS, BaseballGame.COLOR_MOUND)

		# ── Pitcher marker (colored square, changes state) ────────────────────
		var ph := BaseballGame.PITCHER_HALF
		draw_rect(
			Rect2(mound - Vector2(ph, ph), Vector2(ph * 2.0, ph * 2.0)),
			game._pitcher_color
		)

		# ── Batter (always visible at home plate) ─────────────────────────────
		var bth := BaseballGame.BATTER_HALF
		draw_rect(
			Rect2(home - Vector2(bth, bth), Vector2(bth * 2.0, bth * 2.0)),
			BaseballGame.COLOR_BATTER
		)

		# ── Tile selection highlight ──────────────────────────────────────────
		if game._selected_cell != Vector2i(-1, -1):
			var sc := _wp(game._selected_cell)
			var tx := PlanetMapTileConfig.TILE_OFFSET.x
			var ty := PlanetMapTileConfig.TILE_OFFSET.y
			var diamond := PackedVector2Array([
				sc + Vector2(0, -ty),
				sc + Vector2(tx, 0),
				sc + Vector2(0, ty),
				sc + Vector2(-tx, 0),
			])
			draw_colored_polygon(diamond, BaseballGame.COLOR_HIGHLIGHT)

		# ── Ball ──────────────────────────────────────────────────────────────
		if game._ball_visible:
			var col: Color
			if game._hit_result == BaseballGame._HitResult.HOME_RUN:
				col = BaseballGame.COLOR_BALL_HIT    # gold
			elif game._hit_result == BaseballGame._HitResult.FOUL:
				col = BaseballGame.COLOR_BALL_FOUL   # grey
			elif game._hit_result == BaseballGame._HitResult.HIT:
				col = BaseballGame.COLOR_BALL        # white
			else:
				col = BaseballGame.COLOR_BALL
			draw_circle(game._ball_pos, BaseballGame.BALL_RADIUS, col)
