class_name MatchingBoard
extends RefCounted

# Pure logic for a match-3 grid game.
# No rendering - just grid state, match detection, gravity, and chain resolution.

const EMPTY := -1

var width: int
var height: int
var num_types: int

var _grid: Array  # Array[Array[int]], indexed [y][x]
var _rng: RandomNumberGenerator


func initialize(p_width: int, p_height: int, p_num_types: int, p_seed: int = 0) -> void:
	width = p_width
	height = p_height
	num_types = p_num_types
	_rng = RandomNumberGenerator.new()
	if p_seed > 0:
		_rng.seed = p_seed
	_grid = []
	for y in range(height):
		_grid.append([])
		for x in range(width):
			_grid[y].append(EMPTY)
	_fill_initial()


func get_tile(x: int, y: int) -> int:
	if x < 0 or x >= width or y < 0 or y >= height:
		return EMPTY
	return _grid[y][x]


# Returns true if tiles at a and b are orthogonally adjacent.
func can_swap(a: Vector2i, b: Vector2i) -> bool:
	return abs(a.x - b.x) + abs(a.y - b.y) == 1


# Swaps adjacent tiles unconditionally. Returns true if the tiles were adjacent.
# After calling this, use find_matches() / resolve_step() to score any combos.
func swap(a: Vector2i, b: Vector2i) -> bool:
	if not can_swap(a, b):
		return false
	_swap_tiles(a, b)
	return true


# Checks whether swapping would create a match WITHOUT committing the swap.
# Returns true if a match would result. The board is unchanged either way.
func try_swap(a: Vector2i, b: Vector2i) -> bool:
	if not can_swap(a, b):
		return false
	_swap_tiles(a, b)
	if find_matches().is_empty():
		_swap_tiles(a, b)
		return false
	_swap_tiles(a, b)  # always revert — this is a check only
	return true


# Returns all tile positions that are part of a match (3+ in a row/column).
func find_matches() -> Array[Vector2i]:
	var matched: Dictionary = {}

	# Horizontal runs
	for y in range(height):
		var x := 0
		while x < width:
			var t: int = _grid[y][x]
			if t == EMPTY:
				x += 1
				continue
			var end_x := x + 1
			while end_x < width and _grid[y][end_x] == t:
				end_x += 1
			if end_x - x >= 3:
				for j in range(x, end_x):
					matched[Vector2i(j, y)] = true
			x = end_x

	# Vertical runs
	for x in range(width):
		var y := 0
		while y < height:
			var t: int = _grid[y][x]
			if t == EMPTY:
				y += 1
				continue
			var end_y := y + 1
			while end_y < height and _grid[end_y][x] == t:
				end_y += 1
			if end_y - y >= 3:
				for j in range(y, end_y):
					matched[Vector2i(x, j)] = true
			y = end_y

	var result: Array[Vector2i] = []
	result.assign(matched.keys())
	return result


# Removes the given tiles from the board (sets them to EMPTY).
func remove_matches(positions: Array[Vector2i]) -> void:
	_remove_tiles(positions)


# Tiles fall downward to fill gaps. Returns move records: [{from, to}].
func apply_gravity() -> Array:
	var moves := []
	for x in range(width):
		var write_y := height - 1
		for y in range(height - 1, -1, -1):
			if _grid[y][x] != EMPTY:
				if write_y != y:
					moves.append({"from": Vector2i(x, y), "to": Vector2i(x, write_y)})
					_grid[write_y][x] = _grid[y][x]
					_grid[y][x] = EMPTY
				write_y -= 1
	return moves


# Fills EMPTY cells with new random tiles. Returns the positions that were filled.
func fill_empty() -> Array[Vector2i]:
	var spawns: Array[Vector2i] = []
	for y in range(height):
		for x in range(width):
			if _grid[y][x] == EMPTY:
				_grid[y][x] = _random_type()
				spawns.append(Vector2i(x, y))
	return spawns


# Convenience: one full chain step used by tests and silent startup clearing.
func resolve_step() -> Dictionary:
	var matches := find_matches()
	if matches.is_empty():
		return {}
	remove_matches(matches)
	apply_gravity()
	fill_empty()
	return {"match_count": matches.size(), "positions": matches}


# ===== PRIVATE =====

func _random_type() -> int:
	return _rng.randi_range(0, num_types - 1)


func _fill_initial() -> void:
	for y in range(height):
		for x in range(width):
			var attempts := 0
			_grid[y][x] = _random_type()
			while _creates_match_at(x, y) and attempts < 20:
				_grid[y][x] = _random_type()
				attempts += 1


# True if placing a tile at (x, y) would create a 3+ run with existing neighbors.
func _creates_match_at(x: int, y: int) -> bool:
	var t: int = _grid[y][x]
	if t == EMPTY:
		return false

	var left := 0
	var i := x - 1
	while i >= 0 and _grid[y][i] == t:
		left += 1
		i -= 1
	var right := 0
	i = x + 1
	while i < width and _grid[y][i] == t:
		right += 1
		i += 1
	if left + right >= 2:
		return true

	var up := 0
	i = y - 1
	while i >= 0 and _grid[i][x] == t:
		up += 1
		i -= 1
	var down := 0
	i = y + 1
	while i < height and _grid[i][x] == t:
		down += 1
		i += 1
	return up + down >= 2


func _swap_tiles(a: Vector2i, b: Vector2i) -> void:
	var temp: int = _grid[a.y][a.x]
	_grid[a.y][a.x] = _grid[b.y][b.x]
	_grid[b.y][b.x] = temp


func _remove_tiles(positions: Array[Vector2i]) -> void:
	for pos in positions:
		_grid[pos.y][pos.x] = EMPTY


