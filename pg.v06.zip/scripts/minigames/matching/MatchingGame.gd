class_name MatchingGame
extends Control

# Playable match-3 game widget.
# Renders the board via _draw() with animated swaps, falls, and match flashes.
# Embed in any scene or page - call reset() to restart.

signal score_changed(new_score: int)
signal combo_achieved(combo: int, tiles_cleared: int)

const GRID_W := 8
const GRID_H := 8
const NUM_TYPES := 6
const TILE_SIZE := 50
const GAP := 2
const CELL_SIZE := TILE_SIZE + GAP

# Animation durations in seconds
const ANIM_SWAP         := 0.12
const ANIM_FLASH        := 0.18
const ANIM_FALL         := 0.18   # duration for a single-row fall
const ANIM_FALL_STAGGER := 0.025  # delay between tiles in the same column

const TILE_COLORS: Array[Color] = [
	Color(0.0, 0.80, 0.20),  # green
	Color(0.0, 0.80, 0.80),  # cyan
	Color(0.9, 0.50, 0.00),  # amber
	Color(0.7, 0.00, 0.80),  # magenta
	Color(0.8, 0.20, 0.20),  # red
	Color(0.2, 0.45, 1.00),  # blue
]

const TILE_SYMBOLS: Array[String] = ["#", "@", "O", "*", "+", "="]

const COLOR_BACKGROUND    := Color(0.0, 0.0, 0.0)
const COLOR_BORDER        := Color(0.18, 0.18, 0.18)
const COLOR_SELECTED_FILL := Color(1.0, 1.0, 1.0, 0.15)
const COLOR_SELECTED_BORDER := Color(1.0, 1.0, 1.0, 0.9)
const FONT_SIZE := 26

enum _State { IDLE, SELECTED, RESOLVING }

var _board: MatchingBoard
var _state: _State = _State.IDLE
var _selected: Vector2i = Vector2i(-1, -1)
var _score: int = 0

# ---- animation state ----
# _tile_offsets: extra pixel offset applied when drawing the tile at a grid position.
#   Used for swap and fall animations — tile draws at (grid_px + offset), offset tweens to zero.
var _tile_offsets: Dictionary = {}  # Vector2i -> Vector2

# _tile_flash: 0=normal color, 1=full white. Lerps tile color toward white on match.
var _tile_flash: Dictionary = {}    # Vector2i -> float


# ===== LIFECYCLE =====

func _ready() -> void:
	custom_minimum_size = Vector2(GRID_W * CELL_SIZE - GAP, GRID_H * CELL_SIZE - GAP)
	_board = MatchingBoard.new()
	_board.initialize(GRID_W, GRID_H, NUM_TYPES)
	_clear_starting_matches()


func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		queue_redraw()


func reset() -> void:
	_board.initialize(GRID_W, GRID_H, NUM_TYPES)
	_clear_starting_matches()
	_state = _State.IDLE
	_selected = Vector2i(-1, -1)
	_tile_offsets.clear()
	_tile_flash.clear()
	_score = 0
	score_changed.emit(0)
	queue_redraw()


func get_score() -> int:
	return _score


# ===== RENDERING =====

func _get_grid_offset() -> Vector2:
	var grid_px := Vector2(GRID_W * CELL_SIZE - GAP, GRID_H * CELL_SIZE - GAP)
	var half_spare := (size - grid_px) * 0.5
	return Vector2(maxf(half_spare.x, 0.0), maxf(half_spare.y, 0.0))


func _tile_rect(x: int, y: int) -> Rect2:
	var offset := _get_grid_offset()
	return Rect2(offset + Vector2(x * CELL_SIZE, y * CELL_SIZE), Vector2(TILE_SIZE, TILE_SIZE))


func _draw() -> void:
	var font := TerminalTheme.get_terminal_font()
	for y in range(GRID_H):
		for x in range(GRID_W):
			_draw_tile(x, y, font)


func _draw_tile(x: int, y: int, font: Font) -> void:
	var pos    := Vector2i(x, y)
	var base   := _tile_rect(x, y)

	# Apply animation offset - slides tile from its old visual position to its grid position
	var anim_offset := _tile_offsets.get(pos, Vector2.ZERO) as Vector2
	var rect   := Rect2(base.position + anim_offset, base.size)

	var tile_type  := _board.get_tile(x, y)
	var is_selected := _selected == pos

	# Background
	draw_rect(rect, COLOR_BACKGROUND)
	if is_selected:
		draw_rect(rect, COLOR_SELECTED_FILL)

	# Border
	draw_rect(rect,
		COLOR_SELECTED_BORDER if is_selected else COLOR_BORDER,
		false,
		2.0 if is_selected else 1.0)

	if tile_type == MatchingBoard.EMPTY:
		return

	# Tile color, lerped toward white during match flash
	var flash := _tile_flash.get(pos, 0.0) as float
	var color := TILE_COLORS[tile_type].lerp(Color.WHITE, flash)

	# Center symbol using actual font metrics.
	# draw_string pos.y = baseline. Formula: baseline = center_y + (ascent - descent) / 2
	var ascent    := font.get_ascent(FONT_SIZE)
	var descent   := font.get_descent(FONT_SIZE)
	var baseline_y := rect.get_center().y + (ascent - descent) * 0.5

	# pos.x = LEFT edge of alignment box; CENTER alignment places glyph in middle of [x, x+width]
	draw_string(font, Vector2(rect.position.x, baseline_y),
		TILE_SYMBOLS[tile_type], HORIZONTAL_ALIGNMENT_CENTER, TILE_SIZE, FONT_SIZE, color)


# ===== ANIMATION HELPERS =====

# These are used as tween_method callbacks. Using named methods with .bind()
# avoids GDScript closure capture issues in loops.

func _set_tile_offset(v: Vector2, pos: Vector2i) -> void:
	_tile_offsets[pos] = v
	queue_redraw()


func _set_tile_flash(v: float, pos: Vector2i) -> void:
	_tile_flash[pos] = v
	queue_redraw()


func _animate_swap(a: Vector2i, b: Vector2i) -> void:
	# After board.swap(), the types have already moved. a holds old-b's type,
	# b holds old-a's type. We start each at the other's pixel position and
	# slide them to their actual positions — producing a visible swap slide.
	var a_px := _tile_rect(a.x, a.y).position
	var b_px := _tile_rect(b.x, b.y).position

	var tween := create_tween().set_parallel(true)
	tween.tween_method(_set_tile_offset.bind(a), b_px - a_px, Vector2.ZERO, ANIM_SWAP)
	tween.tween_method(_set_tile_offset.bind(b), a_px - b_px, Vector2.ZERO, ANIM_SWAP)
	await tween.finished

	_tile_offsets.erase(a)
	_tile_offsets.erase(b)
	queue_redraw()


func _animate_flash(matches: Array[Vector2i]) -> void:
	# Tiles flash to white, then are removed from the board when the tween ends.
	var tween := create_tween().set_parallel(true)
	for pos in matches:
		tween.tween_method(_set_tile_flash.bind(pos), 0.0, 1.0, ANIM_FLASH)
	await tween.finished

	_board.remove_matches(matches)
	for pos in matches:
		_tile_flash.erase(pos)
	queue_redraw()


func _animate_fall(moves: Array) -> void:
	if moves.is_empty():
		return

	# Sort so the lowest-destination tile in each column goes first.
	# Then stagger each successive tile in the same column by ANIM_FALL_STAGGER.
	# This breaks the rigid-block look: tiles that fall the same distance would
	# otherwise have identical offsets and duration and move as one unit.
	var sorted := moves.duplicate()
	sorted.sort_custom(func(a, b): return a.to.y > b.to.y)

	var col_delay: Dictionary = {}
	var tween := create_tween().set_parallel(true)
	for move in sorted:
		var delay: float = col_delay.get(move.to.x, 0.0)
		col_delay[move.to.x] = delay + ANIM_FALL_STAGGER

		var from_px := _tile_rect(move.from.x, move.from.y).position
		var to_px   := _tile_rect(move.to.x,   move.to.y  ).position
		var start   := from_px - to_px
		_tile_offsets[move.to] = start
		tween.tween_method(_set_tile_offset.bind(move.to), start, Vector2.ZERO, ANIM_FALL) \
			.set_delay(delay)
	await tween.finished

	for move in moves:
		_tile_offsets.erase(move.to)
	queue_redraw()


func _animate_spawn(spawns: Array[Vector2i]) -> void:
	if spawns.is_empty():
		return

	# Constant speed: duration scales with distance (rows to fall × ANIM_FALL per row).
	# y=0 arrives first, then y=1, then y=2 — a natural top-to-bottom cascade.
	# No stagger needed here; the varying durations produce the sequencing automatically.
	var tween := create_tween().set_parallel(true)
	for pos in spawns:
		var fall_cells := pos.y + 1
		var start    := Vector2(0.0, -fall_cells * CELL_SIZE)
		var duration := fall_cells * ANIM_FALL
		_tile_offsets[pos] = start
		tween.tween_method(_set_tile_offset.bind(pos), start, Vector2.ZERO, duration)
	await tween.finished

	for pos in spawns:
		_tile_offsets.erase(pos)
	queue_redraw()


# ===== GAME LOGIC =====

func _clear_starting_matches() -> void:
	# Silently remove any matches that slipped through initialization — no scoring.
	var safety := 0
	while not _board.find_matches().is_empty() and safety < 50:
		_board.resolve_step()
		safety += 1


func _attempt_swap(a: Vector2i, b: Vector2i) -> void:
	_state = _State.RESOLVING
	_selected = Vector2i(-1, -1)

	_board.swap(a, b)
	await _animate_swap(a, b)
	await _resolve_chains_animated()
	queue_redraw()


func _resolve_chains_animated() -> void:
	var combo := 0

	while true:
		var matches := _board.find_matches()
		if matches.is_empty():
			break

		combo += 1
		_score += matches.size() * 10 * combo
		score_changed.emit(_score)
		if combo > 1:
			combo_achieved.emit(combo, matches.size())

		# Flash tiles white, then remove them from the board
		await _animate_flash(matches)

		# Existing tiles above the gaps fall down
		var moves := _board.apply_gravity()
		await _animate_fall(moves)

		# Fill gaps at the top with new tiles, then animate them falling in
		var spawns := _board.fill_empty()
		await _animate_spawn(spawns)

		# Brief pause before checking for chains
		await get_tree().create_timer(0.05).timeout

	_state = _State.IDLE


# ===== INPUT =====

func _gui_input(event: InputEvent) -> void:
	if _state == _State.RESOLVING:
		return
	if not (event is InputEventMouseButton):
		return
	var mb := event as InputEventMouseButton
	if mb.button_index != MOUSE_BUTTON_LEFT or not mb.pressed:
		return

	var clicked := _pixel_to_grid(mb.position)
	if clicked.x < 0:
		_deselect()
		return

	_on_grid_clicked(clicked)


func _pixel_to_grid(pixel: Vector2) -> Vector2i:
	var local := pixel - _get_grid_offset()
	if local.x < 0 or local.y < 0:
		return Vector2i(-1, -1)
	var gx := int(local.x / CELL_SIZE)
	var gy := int(local.y / CELL_SIZE)
	if gx >= GRID_W or gy >= GRID_H:
		return Vector2i(-1, -1)
	return Vector2i(gx, gy)


func _on_grid_clicked(pos: Vector2i) -> void:
	if _state == _State.IDLE:
		_selected = pos
		_state = _State.SELECTED
		queue_redraw()
		return

	# State == SELECTED
	if pos == _selected:
		_deselect()
		return

	if _board.can_swap(_selected, pos):
		_attempt_swap(_selected, pos)  # starts async, sets state RESOLVING immediately
	else:
		_selected = pos  # re-select new tile
		queue_redraw()


func _deselect() -> void:
	_selected = Vector2i(-1, -1)
	_state = _State.IDLE
	queue_redraw()
