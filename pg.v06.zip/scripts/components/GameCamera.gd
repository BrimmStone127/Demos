# GameCamera.gd - Simple enhanced zoom system

class_name GameCamera
extends Camera2D

const LOG_TAG := "GAME_CAMERA"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


signal camera_panned

var zoom_level: float = 1.0
var zoom_speed: float = 0.2   # Much faster base zoom speed
var min_zoom: float = 0.1     # Zoom out even more
var max_zoom: float = 15.0    # Much closer zoom (was 6.0)
var pan_speed: float = 1.0
var keyboard_pan_speed: float = 300.0  
var max_pan_distance: float = 12000.0  # Increased for larger zoom range
var movement_keys: Dictionary = {
	"up": KEY_W,
	"down": KEY_S,
	"left": KEY_A,
	"right": KEY_D,
	"zoom_in": KEY_SHIFT,
	"zoom_out": KEY_CTRL
}
var keys_pressed: Dictionary = {
	"up": false,
	"down": false,
	"left": false,
	"right": false,
	"zoom_in": false,
	"zoom_out": false
}

var tracking_target: Node2D = null
var tracking_offset: Vector2 = Vector2.ZERO
var tracking_speed: float = 5.0
var is_tracking: bool = false
var auto_adjust_zoom: bool = true
var has_panned: bool = false

func _ready():
	make_current()
	add_to_group("cameras")

func _is_text_input_focused() -> bool:
	var focus_owner = get_viewport().gui_get_focus_owner()
	return focus_owner is LineEdit or focus_owner is TextEdit

func _is_mouse_over_scrollable_ui() -> bool:
	var viewport = get_viewport()
	if not viewport or not viewport.has_method("gui_get_hovered_control"):
		return false
	var hovered = viewport.gui_get_hovered_control()
	if not hovered:
		return false
	# Check if hovered control or any of its ancestors is a ScrollContainer
	var node = hovered
	while node:
		if node is ScrollContainer:
			return true
		node = node.get_parent()
	return false

func _input(event):
	if event is InputEventMouseButton and event.button_mask == MOUSE_BUTTON_MASK_MIDDLE and is_tracking:
		stop_tracking()
	
	# Enhanced mouse wheel zoom with better scaling
	# Skip zoom if mouse is over a scrollable UI element
	if event is InputEventMouseButton and not _is_mouse_over_scrollable_ui():
		if event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
			var zoom_amount = _get_adaptive_zoom_speed()
			apply_zoom_change(zoom_amount)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
			var zoom_amount = _get_adaptive_zoom_speed()
			apply_zoom_change(-zoom_amount)
	
	# Pan the camera with middle mouse button
	if event is InputEventMouseMotion and event.button_mask == MOUSE_BUTTON_MASK_MIDDLE:
		var pan_amount = event.relative / zoom_level * pan_speed
		position -= pan_amount
		
		if is_tracking:
			stop_tracking()
		
		if !has_panned and position.length() > 5.0:
			has_panned = true
			emit_signal("camera_panned")
		
		var distance = position.length()
		if distance > max_pan_distance:
			position = position.normalized() * max_pan_distance
	
	# Handle WASD key presses and releases
	if event is InputEventKey:
		# Skip camera controls if user is typing in a text field
		if _is_text_input_focused():
			return

		var key_pressed = event.pressed

		if event.keycode == movement_keys.up:
			keys_pressed.up = key_pressed
			if key_pressed and is_tracking:
				stop_tracking()
		elif event.keycode == movement_keys.down:
			keys_pressed.down = key_pressed
			if key_pressed and is_tracking:
				stop_tracking()
		elif event.keycode == movement_keys.left:
			keys_pressed.left = key_pressed
			if key_pressed and is_tracking:
				stop_tracking()
		elif event.keycode == movement_keys.right:
			keys_pressed.right = key_pressed
			if key_pressed and is_tracking:
				stop_tracking()
		elif event.keycode == movement_keys.zoom_in:
			keys_pressed.zoom_in = key_pressed
		elif event.keycode == movement_keys.zoom_out:
			keys_pressed.zoom_out = key_pressed

func _get_effective_delta(delta: float) -> float:
	var time_scale = Engine.time_scale
	if time_scale <= 0.0:
		return delta
	return delta / time_scale

# Much simpler and faster zoom speed - no complex scaling
func _get_adaptive_zoom_speed() -> float:
	return zoom_speed * 2.0  # Just make it consistently faster

func _process(delta):
	var effective_delta := _get_effective_delta(delta)
	# If tracking a target, update position to follow it
	if is_tracking:
		if tracking_target and is_instance_valid(tracking_target):
			var target_pos = tracking_target.global_position + tracking_offset
			var distance_to_target = position.distance_to(target_pos)
			
			# Auto-adjust zoom based on distance if enabled
			if auto_adjust_zoom and distance_to_target > 1000:
				var ideal_zoom = clamp(1.0 / (distance_to_target / 1000.0), min_zoom, 1.5)
				zoom_level = lerp(zoom_level, ideal_zoom, effective_delta)
				zoom = Vector2(zoom_level, zoom_level)
			var lerp_t = clamp(tracking_speed * effective_delta, 0.0, 1.0)
			position = position.lerp(target_pos, lerp_t)
			
			if !has_panned:
				has_panned = true
				emit_signal("camera_panned")
				
			var tracking_distance = position.length()
			if tracking_distance > max_pan_distance:
				position = position.normalized() * max_pan_distance
		else:
			_log_warn('Warning: Tracked object no longer valid')
			stop_tracking()
	else:
		# Handle keyboard movement with zoom-adjusted speed
		var movement = Vector2.ZERO
		
		if keys_pressed.up:
			movement.y -= 1
		if keys_pressed.down:
			movement.y += 1
		if keys_pressed.left:
			movement.x -= 1
		if keys_pressed.right:
			movement.x += 1
		
		if movement.length_squared() > 0:
			movement = movement.normalized()
			
			if !has_panned and position.length() > 5.0:
				has_panned = true
				emit_signal("camera_panned")
			
			# Adjust movement speed based on zoom level for better control
			var adjusted_speed = keyboard_pan_speed / zoom_level
			position += movement * adjusted_speed * effective_delta
	
	# Handle zoom - much faster and simpler
	var zoom_change = 0
	if keys_pressed.zoom_in:
		zoom_change += zoom_speed * effective_delta * 15  # Much faster keyboard zoom
	if keys_pressed.zoom_out:
		zoom_change -= zoom_speed * effective_delta * 15
		
	if zoom_change != 0:
		apply_zoom_change(zoom_change)
	
	# Limit distance from origin
	var distance = position.length()
	if distance > max_pan_distance:
		position = position.normalized() * max_pan_distance

func apply_zoom_change(amount: float):
	zoom_level = clamp(zoom_level + amount, min_zoom, max_zoom)
	zoom = Vector2(zoom_level, zoom_level)

func track_object(object: Node2D, p_offset: Vector2 = Vector2.ZERO, custom_zoom: float = -1):
	if not object or not is_instance_valid(object):
		_log_warn('Warning: Attempted to track an invalid object')
		return

	tracking_target = object
	tracking_offset = p_offset
	is_tracking = true

	# Check distance to target for auto-zoom
	var target_pos = object.global_position + p_offset
	var distance_to_target = position.distance_to(target_pos)
	
	# Smart auto-zoom: closer zoom for planets, moderate for system
	if custom_zoom > 0:
		zoom_level = clamp(custom_zoom, min_zoom, max_zoom)
		zoom = Vector2(zoom_level, zoom_level)
	elif object is Planet:
		# Automatically zoom to a good level for planet viewing
		var planet_zoom = 4.0  # Increased zoom level for better planet detail
		zoom_level = clamp(planet_zoom, min_zoom, max_zoom)
		zoom = Vector2(zoom_level, zoom_level)
	elif distance_to_target > 2000 and auto_adjust_zoom:
		# For distant objects, zoom out a bit
		var distant_zoom = clamp(0.8 / (distance_to_target / 2000.0), min_zoom, 1.0)
		zoom_level = distant_zoom
		zoom = Vector2(zoom_level, zoom_level)
	
	if !has_panned:
		has_panned = true
		emit_signal("camera_panned")

func stop_tracking():
	is_tracking = false
	tracking_target = null
	
func reset_position():
	position = Vector2.ZERO
	zoom_level = 1.0
	zoom = Vector2(zoom_level, zoom_level)
	keys_pressed.up = false
	keys_pressed.down = false
	keys_pressed.left = false
	keys_pressed.right = false
	keys_pressed.zoom_in = false
	keys_pressed.zoom_out = false
	stop_tracking()
	has_panned = false

func set_auto_zoom(p_enabled: bool):
	auto_adjust_zoom = p_enabled

# Helper method to smoothly zoom to a specific level
func zoom_to_level(target_zoom: float, duration: float = 0.5):
	var tween = create_tween()
	tween.tween_method(
		func(level): 
			zoom_level = clamp(level, min_zoom, max_zoom)
			zoom = Vector2(zoom_level, zoom_level),
		zoom_level, 
		target_zoom, 
		duration
	)

