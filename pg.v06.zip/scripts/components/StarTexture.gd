@tool
extends EditorScript

const LOG_TAG := "STAR_TEXTURE"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


# This script generates a simple star texture for the background
# Run this in the Godot editor to generate the texture

func _run():
	# Create a 16x16 image for the star
	var image = Image.create(16, 16, false, Image.FORMAT_RGBA8)
	
	# Fill with transparent
	image.fill(Color(0, 0, 0, 0))
	
	# Center of the image
	var center = Vector2(7.5, 7.5)
	
	# Draw a soft circular gradient
	for x in range(16):
		for y in range(16):
			var pos = Vector2(x, y)
			var dist = pos.distance_to(center)
			
			if dist < 8:
				# Calculate alpha based on distance from center
				var alpha = 1.0 - (dist / 7.5)
				
				# Use a quadratic falloff for smoother edges
				alpha = pow(alpha, 2.0)
				
				# Set pixel
				if alpha > 0.01:  # Only set pixels with visible alpha
					image.set_pixel(x, y, Color(1, 1, 1, alpha))
	
	# Save the image as a texture to user data directory
	# Use user:// instead of res:// for cross-platform compatibility (Mac, Linux, Windows)
	# res:// is read-only at runtime and will fail on packaged builds
	var save_dir = "user://assets"
	DirAccess.make_dir_recursive_absolute(save_dir)

	var save_path = "user://assets/star_particle.png"
	var err = image.save_png(save_path)
	if err == OK:
		_log_info('Star texture saved successfully to: %s', [save_path])
		var actual_path = ProjectSettings.globalize_path(save_path)
		_log_info('Actual file location: %s', [actual_path])
	else:
		_log_error('Error saving star texture: %s', [err])

# To use this script:
# 1. Save it as StarTexture.gd in your project
# 2. In the Godot editor, go to Script menu
# 3. Select "Run" or press Ctrl+Shift+X
# 4. The texture will be saved to user://assets/star_particle.png
# 5. On Mac: ~/Library/Application Support/Godot/app_userdata/[ProjectName]/assets/
# 6. On Windows: %APPDATA%\Godot\app_userdata\[ProjectName]\assets\
# 7. On Linux: ~/.local/share/godot/app_userdata/[ProjectName]/assets/
