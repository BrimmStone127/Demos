class_name WhiteNoiseGenerator
extends AudioStreamPlayer

# Configuration
@export var noise_volume: float = 0.05  # Much quieter for background ambience
@export var sample_rate: int = 44100
@export var tone_depth: float = 0.99  # Higher = deeper tone (0.95-0.999)

var audio_stream: AudioStreamGenerator
var playback: AudioStreamGeneratorPlayback
var previous_sample: float = 0.0  # For smoothing

func _ready():
	# Create the audio stream generator
	audio_stream = AudioStreamGenerator.new()
	audio_stream.mix_rate = sample_rate  # Correct property name in Godot 4
	audio_stream.buffer_length = 0.1  # Small buffer for responsiveness
	
	# Set up the audio player
	stream = audio_stream
	volume_db = linear_to_db(noise_volume)
	autoplay = true
	
	# Start playing
	play()
	
	# Get the playback stream
	playback = get_stream_playback()

func _process(_delta):
	# Generate noise less frequently with larger chunks
	if playback and playback.can_push_buffer(1):
		var frames_available = playback.get_frames_available()
		if frames_available > 1024:  # Only when we need a substantial amount
			_push_noise_frames(min(frames_available, 2048))  # Larger chunks

func _push_noise_frames(frame_count: int):
	var frames = PackedVector2Array()
	
	for i in range(frame_count):
		# Generate brown noise (deeper than white noise)
		var raw_sample = (randf() * 2.0 - 1.0) * noise_volume * 0.3
		
		# Use tone_depth for filtering (deeper = more filtering)
		var sample = previous_sample * tone_depth + raw_sample * (1.0 - tone_depth)
		previous_sample = sample
		
		frames.append(Vector2(sample, sample))
	
	playback.push_buffer(frames)

func set_noise_volume(new_volume: float):
	noise_volume = clamp(new_volume, 0.0, 1.0)
	volume_db = linear_to_db(noise_volume)

func start_noise():
	if not playing:
		play()

func stop_noise():
	stop()
