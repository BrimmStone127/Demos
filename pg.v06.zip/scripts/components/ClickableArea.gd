class_name ClickableArea
extends Area2D

signal object_clicked(object)

var parent_object: Node2D  # Reference to either a StarSystem or Planet

func _init(p_object, collision_radius: float):
	parent_object = p_object
	
	# Set input flags to ensure we catch clicks
	input_pickable = true
	collision_layer = 1  # Set to layer 1 for testing
	collision_mask = 0   # Don't detect collisions with physics objects
	monitoring = true    # Make sure monitoring is enabled
	monitorable = true   # Make sure it can be monitored
	
	var shape = CircleShape2D.new()
	
	if p_object is StarSystem:
		var star_sprite = p_object.get_child(0)
		if star_sprite is Sprite2D:
			var texture_size = star_sprite.texture.get_width() * star_sprite.scale.x
			shape.radius = texture_size * 0.5  # Half the texture size
		else:
			shape.radius = collision_radius  # Fallback to provided radius
	else:
		# For planets, the collision radius should match the visual size
		shape.radius = collision_radius
	
	var collision = CollisionShape2D.new()
	collision.shape = shape
	add_child(collision)
	
	# Connect signals
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)
	input_event.connect(_on_input_event)

func _ready():
	# Make sure these are at a high z-index to get input priority
	z_index = 100
	
	# Force input_pickable to be true again just to be sure
	input_pickable = true

func _on_input_event(_viewport, event, _shape_idx):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		emit_signal("object_clicked", parent_object)

func _on_mouse_entered():
	if parent_object is StarSystem:
		var star = parent_object.get_child(0)  # First child should be the star sprite
		if star is Sprite2D:
			star.modulate = star.modulate.lightened(0.2)
	elif parent_object is Planet:
		parent_object.set_selected(true)
	
	Input.set_default_cursor_shape(Input.CURSOR_POINTING_HAND)

func _on_mouse_exited():
	if parent_object is StarSystem:
		var star = parent_object.get_child(0)
		if star is Sprite2D:
			star.modulate = parent_object.STAR_PROPERTIES[parent_object.star_type].color
	elif parent_object is Planet:
		parent_object.set_selected(false)
	
	Input.set_default_cursor_shape(Input.CURSOR_ARROW)
