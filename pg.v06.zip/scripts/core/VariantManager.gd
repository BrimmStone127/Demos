class_name VariantManager
extends RefCounted

## Singleton service for managing visual themes and color variants
##
## Manages a collection of VariantThemes and applies them to TileMaps using
## the existing PaletteSwapper shader system.
##
## Usage:
##   var vm = VariantManager.get_instance()
##   vm.set_theme("verdant")
##   vm.apply_theme_to_tilemap(my_tilemap, [93, 94, 95])  # Apply to specific tiles
##
## Built-in themes:
##   - "default": No color modifications
##   - "verdant": Lush green vegetation (maps to "vrdant" variant in catalog)

const LOG_TAG := "VARIANT_MANAGER"
const THEMES_SAVE_PATH := "user://variant_themes.json"
const THEMES_VERSION := "1.0"

## Flat file storing tree palette color swaps — source of truth for get_shared_tree_material().
## Format: {"swaps": [{"src": [r,g,b,a], "tgt": [r,g,b,a]}, ...]}
const TREE_PALETTE_PATH := "user://tree_palette.json"

## Signals
signal theme_changed(theme_name: String)
signal variant_applied(tilemap: TileMap, theme_name: String)

## Singleton instance
static var _instance: VariantManager = null

## Currently active theme
var _current_theme: VariantTheme = null

## All available themes by name
var _themes: Dictionary = {}  # {name: VariantTheme}

## Tile catalog manager for loading variant data
var _alias_manager: TileAliasManager = null

## Cached catalog load status
var _catalog_loaded: bool = false

## Shared ShaderMaterial for tree palette swap — one instance for all tree sprites
var _shared_tree_material: ShaderMaterial = null

## MultiMesh variant of _shared_tree_material with is_multimesh=true.
## VERTEX space differs: MultiMesh uses local mesh coords [-1,0], Sprite2D uses canvas pixels.
var _shared_tree_material_mm: ShaderMaterial = null

## Per-elevation-layer shared tree materials (16 entries max).
## Keys: render layer int (0-15). Values: ShaderMaterial with modulate_color pre-set.
## Avoids duplicating one material per sprite (~92K → 16 ShaderMaterial objects).
var _shared_tree_materials_by_layer: Dictionary = {}


## Get the singleton instance
static func get_instance() -> VariantManager:
	if _instance == null:
		_instance = VariantManager.new()
		_instance._initialize()
	return _instance


## Reset singleton (for testing)
static func reset_instance() -> void:
	_instance = null


func _initialize() -> void:
	# Load tile catalog
	_alias_manager = TileAliasManager.new()
	_catalog_loaded = _alias_manager.load_catalog()
	if not _catalog_loaded:
		GameLog.warn(LOG_TAG, "Failed to load tile catalog - variants may not work")

	# Create built-in themes
	_create_builtin_themes()

	# Load user themes from file
	_load_user_themes()

	# Set default theme to verdant (lush green vegetation variant)
	if _current_theme == null:
		set_theme("verdant")

	GameLog.info(LOG_TAG, "Initialized with %d themes, current: '%s'" % [_themes.size(), _current_theme.name if _current_theme else "none"])


## Create the built-in themes
func _create_builtin_themes() -> void:
	# Default theme: no modifications
	var default_theme = VariantTheme.new()
	default_theme.name = "default"
	default_theme.description = "Original tile colors, no modifications"
	_themes["default"] = default_theme

	# Verdant theme: lush green vegetation
	var verdant_theme = VariantTheme.new()
	verdant_theme.name = "verdant"
	verdant_theme.description = "Lush green vegetation with vibrant emerald tones"
	verdant_theme.set_category_variant("Trees", "vrdant")
	_themes["verdant"] = verdant_theme


## Load user-created themes from file
func _load_user_themes() -> void:
	if not FileAccess.file_exists(THEMES_SAVE_PATH):
		return

	var file = FileAccess.open(THEMES_SAVE_PATH, FileAccess.READ)
	if not file:
		GameLog.warn(LOG_TAG, "Failed to open themes file: %s" % THEMES_SAVE_PATH)
		return

	var json_string = file.get_as_text()
	file.close()

	var json = JSON.new()
	var error = json.parse(json_string)
	if error != OK:
		GameLog.error(LOG_TAG, "JSON parse error in themes file: %s" % json.get_error_message())
		return

	var data = json.data
	if not data is Dictionary:
		GameLog.error(LOG_TAG, "Invalid themes file format")
		return

	var themes_array = data.get("themes", [])
	for theme_data in themes_array:
		var loaded_theme = VariantTheme.from_dict(theme_data)
		if loaded_theme.name.is_empty():
			continue
		# Don't overwrite built-in themes
		if loaded_theme.name == "default" or loaded_theme.name == "verdant":
			continue
		_themes[loaded_theme.name] = loaded_theme

	GameLog.info(LOG_TAG, "Loaded %d user themes from file" % themes_array.size())


## Save user themes to file
func _save_user_themes() -> void:
	var themes_to_save: Array = []
	for theme_name in _themes:
		# Skip built-in themes
		if theme_name == "default" or theme_name == "verdant":
			continue
		themes_to_save.append(_themes[theme_name].to_dict())

	var data = {
		"version": THEMES_VERSION,
		"themes": themes_to_save
	}

	var json_string = JSON.stringify(data, "\t")
	var file = FileAccess.open(THEMES_SAVE_PATH, FileAccess.WRITE)
	if not file:
		GameLog.error(LOG_TAG, "Failed to save themes to: %s" % THEMES_SAVE_PATH)
		return

	file.store_string(json_string)
	file.close()
	GameLog.info(LOG_TAG, "Saved %d user themes to file" % themes_to_save.size())


## Get the current theme
func get_current_theme() -> VariantTheme:
	return _current_theme


## Get current theme name
func get_current_theme_name() -> String:
	return _current_theme.name if _current_theme else "default"


## Set the active theme by name
## Returns true if theme was found and set
func set_theme(theme_name: String) -> bool:
	if not _themes.has(theme_name):
		GameLog.warn(LOG_TAG, "Theme not found: '%s'" % theme_name)
		return false

	var old_name = _current_theme.name if _current_theme else ""
	_current_theme = _themes[theme_name]
	_shared_tree_material = null  # Clear cached material so it rebuilds for new theme
	_shared_tree_material_mm = null
	_shared_tree_materials_by_layer.clear()

	if old_name != theme_name:
		GameLog.info(LOG_TAG, "Theme changed: '%s' -> '%s'" % [old_name, theme_name])
		theme_changed.emit(theme_name)

	return true


## Get all available theme names
func get_all_theme_names() -> Array[String]:
	var names: Array[String] = []
	for name in _themes.keys():
		names.append(name)
	names.sort()
	return names


## Get a theme by name
func get_theme(theme_name: String) -> VariantTheme:
	return _themes.get(theme_name, null)


## Add or update a theme
func add_theme(theme: VariantTheme) -> void:
	if theme.name.is_empty():
		GameLog.error(LOG_TAG, "Cannot add theme with empty name")
		return

	_themes[theme.name] = theme
	_save_user_themes()
	GameLog.info(LOG_TAG, "Added/updated theme: '%s'" % theme.name)


## Remove a user theme (cannot remove built-in themes)
func remove_theme(theme_name: String) -> bool:
	if theme_name == "default" or theme_name == "verdant":
		GameLog.warn(LOG_TAG, "Cannot remove built-in theme: '%s'" % theme_name)
		return false

	if not _themes.has(theme_name):
		return false

	_themes.erase(theme_name)
	_save_user_themes()

	# If we removed the current theme, switch to verdant (default)
	if _current_theme and _current_theme.name == theme_name:
		set_theme("verdant")

	GameLog.info(LOG_TAG, "Removed theme: '%s'" % theme_name)
	return true


## Get variant info for a tile based on current theme
## Returns Dictionary with variant data, or empty if no variant applies
func get_variant_for_tile(tile_id: int) -> Dictionary:
	if _current_theme == null or _current_theme.name == "default":
		return {}

	if not _catalog_loaded:
		return {}

	# Get tile category from catalog
	var tile = _alias_manager.get_tile_by_id(tile_id)
	if tile == null:
		return {}

	# Get variant name from theme
	var variant_name = _current_theme.get_variant_for_tile(tile_id, tile.category)
	if variant_name.is_empty():
		return {}

	# Get variant data from tile catalog
	var variant = tile.get_variant(variant_name)
	if variant.is_empty():
		return {}

	return variant


## Apply the current theme to a tilemap for specified tile IDs
## tile_ids: Array of tile IDs that should receive variant treatment
func apply_theme_to_tilemap(tilemap: TileMap, tile_ids: Array[int]) -> void:
	if _current_theme == null:
		return

	# Default theme means no shader
	if _current_theme.name == "default":
		tilemap.material = null
		variant_applied.emit(tilemap, "default")
		return

	if not _catalog_loaded:
		GameLog.warn(LOG_TAG, "Cannot apply theme - catalog not loaded")
		return

	# Collect all color swaps from all specified tiles
	var swapper = PaletteSwapper.new()
	var total_swaps := 0
	var tiles_with_variants := 0

	for tile_id in tile_ids:
		var variant = get_variant_for_tile(tile_id)
		if variant.is_empty() or not variant.has("swaps"):
			continue

		tiles_with_variants += 1
		for swap in variant.swaps:
			var source = Color(swap.source.r, swap.source.g, swap.source.b, swap.source.a)
			var target = Color(swap.target.r, swap.target.g, swap.target.b, swap.target.a)
			swapper.add_color_swap(source, target)
			total_swaps += 1

	# Apply if we have any swaps
	if total_swaps > 0:
		swapper.apply_to_tilemap(tilemap)
		GameLog.info(LOG_TAG, "Applied theme '%s' to '%s': %d swaps from %d tiles" %
			[_current_theme.name, tilemap.name, total_swaps, tiles_with_variants])
	else:
		# No swaps found - use fallback preset for verdant theme
		if _current_theme.name == "verdant":
			var verdant_swapper = PaletteSwapper.create_verdant()
			verdant_swapper.apply_to_tilemap(tilemap)
			GameLog.info(LOG_TAG, "Applied built-in verdant preset to '%s' (no catalog variants)" % tilemap.name)
		else:
			tilemap.material = null

	variant_applied.emit(tilemap, _current_theme.name)


## Convenience method to apply theme to multiple tilemaps
func apply_theme_to_tilemaps(tilemaps: Array, tile_ids: Array[int]) -> void:
	for tm in tilemaps:
		if tm is TileMap:
			apply_theme_to_tilemap(tm, tile_ids)


## Get the vegetative tree tile IDs for all live tree species.
## These receive the palette-swap shader when a theme is active.
static func get_vegetative_tree_tile_ids() -> Array[int]:
	var ids: Array[int] = []
	# Maple VG: Row 4, Cols 14-19 (IDs 94-99)
	for col in range(14, 20):
		ids.append(4 * 20 + col)
	# Beech VG: Row 7, Col 0 (ID 140)
	ids.append(7 * 20 + 0)
	# Oak VG: Row 7, Col 3 (ID 143)
	ids.append(7 * 20 + 3)
	# Birch VG: Row 7, Col 5 (ID 145)
	ids.append(7 * 20 + 5)
	return ids


## Return a shared ShaderMaterial for tree sprites under the current theme.
## Reads color swaps from the flat tree_palette.json file saved by the sandbox editor.
## Falls back to the hardcoded verdant preset if no file exists yet.
## All sprites share this one instance — brightness is applied via sprite.modulate.
func get_shared_tree_material() -> ShaderMaterial:
	if _current_theme == null or _current_theme.name == "default":
		return null
	if _shared_tree_material != null:
		return _shared_tree_material

	var swapper := _load_tree_palette()
	_shared_tree_material = swapper.get_material()
	return _shared_tree_material


## Return a shared ShaderMaterial for MultiMesh tree rendering (is_multimesh=true).
## VERTEX space in MultiMesh is local mesh coords [-1,0], not canvas pixels like Sprite2D.
## The sway math in palette_swap.gdshader branches on this flag.
func get_shared_tree_material_for_multimesh() -> ShaderMaterial:
	if _current_theme == null or _current_theme.name == "default":
		return null
	if _shared_tree_material_mm != null:
		return _shared_tree_material_mm
	var base := get_shared_tree_material()
	if base == null:
		return null
	_shared_tree_material_mm = base.duplicate()
	_shared_tree_material_mm.set_shader_parameter("is_multimesh", true)
	return _shared_tree_material_mm


## Return a shared ShaderMaterial for tree sprites at a specific elevation render layer.
## Uses one material per layer (16 max) instead of duplicating per sprite.
## modulate_color is pre-baked for the layer's brightness — no per-sprite duplication needed.
func get_shared_tree_material_for_layer(render_layer: int, brightness: float) -> ShaderMaterial:
	var base := get_shared_tree_material()
	if base == null:
		return null
	if _shared_tree_materials_by_layer.has(render_layer):
		return _shared_tree_materials_by_layer[render_layer]
	var mat := base.duplicate()
	mat.set_shader_parameter("modulate_color", Color(brightness, brightness, brightness, 1.0))
	_shared_tree_materials_by_layer[render_layer] = mat
	return mat


## Load color swaps from tree_palette.json.
## Returns a configured PaletteSwapper ready to call get_material() on.
## Falls back to the hardcoded verdant preset if the file is missing or empty.
func _load_tree_palette() -> PaletteSwapper:
	if FileAccess.file_exists(TREE_PALETTE_PATH):
		var file := FileAccess.open(TREE_PALETTE_PATH, FileAccess.READ)
		if file:
			var json := JSON.new()
			if json.parse(file.get_as_text()) == OK:
				var data = json.data
				if data is Dictionary and data.has("swaps") and data["swaps"].size() > 0:
					var swapper := PaletteSwapper.new()
					for entry in data["swaps"]:
						var s: Array = entry["src"]
						var t: Array = entry["tgt"]
						swapper.add_color_swap(
							Color(s[0], s[1], s[2], s[3]),
							Color(t[0], t[1], t[2], t[3])
						)
					GameLog.info(LOG_TAG, "Loaded %d tree palette swaps from %s" % [data["swaps"].size(), TREE_PALETTE_PATH])
					return swapper

	GameLog.info(LOG_TAG, "No tree_palette.json found — using built-in verdant preset")
	return PaletteSwapper.create_verdant()


## Save color swaps to tree_palette.json, merging with existing swaps.
## New swaps replace existing ones with the same source color; others are kept.
## Called by the sandbox editor's Apply to Forest button.
func save_tree_palette(new_swaps: Array[Dictionary]) -> bool:
	# Load existing swaps first
	var existing: Dictionary = {}  # source_key -> entry dict
	if FileAccess.file_exists(TREE_PALETTE_PATH):
		var read_file := FileAccess.open(TREE_PALETTE_PATH, FileAccess.READ)
		if read_file:
			var json := JSON.new()
			if json.parse(read_file.get_as_text()) == OK:
				var data = json.data
				if data is Dictionary and data.has("swaps"):
					for entry in data["swaps"]:
						var s: Array = entry["src"]
						var key: String = "%f,%f,%f,%f" % [s[0], s[1], s[2], s[3]]
						existing[key] = entry

	# Merge: new swaps overwrite by source color
	for swap in new_swaps:
		var s: Array = swap["src"]
		var key: String = "%f,%f,%f,%f" % [s[0], s[1], s[2], s[3]]
		existing[key] = swap

	var out := {"swaps": existing.values()}
	var file := FileAccess.open(TREE_PALETTE_PATH, FileAccess.WRITE)
	if not file:
		GameLog.error(LOG_TAG, "Failed to write tree palette to %s" % TREE_PALETTE_PATH)
		return false

	file.store_string(JSON.stringify(out, "\t"))
	file.close()

	# Invalidate cache and trigger live update
	_shared_tree_material = null
	_shared_tree_material_mm = null
	_shared_tree_materials_by_layer.clear()
	theme_changed.emit(_current_theme.name if _current_theme else "verdant")
	GameLog.info(LOG_TAG, "Saved %d tree palette swaps" % out["swaps"].size())
	return true


## Check if catalog is loaded
func is_catalog_loaded() -> bool:
	return _catalog_loaded


## Force reload of catalog and themes
func reload() -> void:
	_catalog_loaded = _alias_manager.load_catalog()
	_themes.clear()
	_create_builtin_themes()
	_load_user_themes()
	if _current_theme:
		set_theme(_current_theme.name)
	GameLog.info(LOG_TAG, "Reloaded catalog and themes")
