class_name Foundation
extends Node

## Foundation economy system
## Tracks credits, lifetime credits, rank, and system observation states.

const LOG_TAG := "FOUNDATION"

signal credits_changed(new_balance: int, delta: int, reason: String)
signal rank_changed(new_rank: int, old_rank: int)
signal system_observation_changed(system_seed: int, new_state: int)
signal blueprint_unlocked(blueprint_id: String)

enum ObservationState {
	UNOBSERVED,
	OBSERVED,
	EXPLORED,
	SURVEYED
}

# Rank thresholds — rank number equals index in array where lifetime_credits >= threshold
const RANK_THRESHOLDS: Array[int] = [0, 100, 500, 2000, 5000, 15000, 50000]

# Credit awards
const CREDITS_OBSERVE_SYSTEM := 10
const CREDITS_ANALYZE_PLANET := 5

## Blueprint catalog — purchasable array modules
const BLUEPRINTS := {
	"laser": {"name": "Laser Module", "cost": 50, "description": "Orbital laser for tree removal"},
	"compiler_beam": {"name": "Compiler Beam", "cost": 200, "description": "Deploys slime mold harvester"},
}

var credits: int = 0
var lifetime_credits: int = 0
var rank: int = 0
var observed_systems: Dictionary = {}  # system_seed -> ObservationState
var analyzed_planets: Dictionary = {}  # planet_id -> true (prevents double credits)
var unlocked_blueprints: Dictionary = {}  # blueprint_id -> true

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, message.format(values) if values.size() > 0 else message)

# --- Credit operations ---

func award_credits(amount: int, reason: String = "") -> void:
	if amount <= 0:
		return
	credits += amount
	lifetime_credits += amount
	var old_rank := rank
	rank = _calculate_rank()
	if reason != "":
		_log_info("Awarded {0} credits: {1} (balance: {2})", [amount, reason, credits])
	emit_signal("credits_changed", credits, amount, reason)
	if rank != old_rank:
		_log_info("Rank increased: {0} -> {1}", [old_rank, rank])
		emit_signal("rank_changed", rank, old_rank)

func spend_credits(amount: int) -> bool:
	if amount <= 0 or amount > credits:
		return false
	credits -= amount
	emit_signal("credits_changed", credits, -amount)
	return true

func can_afford(amount: int) -> bool:
	return credits >= amount

# --- Blueprints ---

func has_blueprint(blueprint_id: String) -> bool:
	return unlocked_blueprints.has(blueprint_id)

func purchase_blueprint(blueprint_id: String) -> bool:
	if unlocked_blueprints.has(blueprint_id):
		return false
	var bp = BLUEPRINTS.get(blueprint_id)
	if not bp:
		return false
	if not spend_credits(bp.cost):
		return false
	unlocked_blueprints[blueprint_id] = true
	blueprint_unlocked.emit(blueprint_id)
	_log_info("Blueprint unlocked: {0} (cost: {1})", [blueprint_id, bp.cost])
	return true

func _calculate_rank() -> int:
	var r := 0
	for i in range(RANK_THRESHOLDS.size()):
		if lifetime_credits >= RANK_THRESHOLDS[i]:
			r = i
	return r

# --- Observation state ---

func get_observation_state(system_seed: int) -> int:
	return observed_systems.get(system_seed, ObservationState.UNOBSERVED)

func set_observation_state(system_seed: int, state: int) -> void:
	var current: int = get_observation_state(system_seed)
	if state <= current:
		return  # Never downgrade
	observed_systems[system_seed] = state
	emit_signal("system_observation_changed", system_seed, state)

func is_new_system(system_seed: int) -> bool:
	return not observed_systems.has(system_seed)

# --- Reward hooks (called by ExplorationSession / DiscoveryBroker) ---

func on_system_observed(system_seed: int, _star_type: String = "") -> void:
	if not is_new_system(system_seed):
		set_observation_state(system_seed, ObservationState.OBSERVED)
		return
	set_observation_state(system_seed, ObservationState.OBSERVED)
	award_credits(CREDITS_OBSERVE_SYSTEM, "System observation")

func on_planet_analyzed(system_seed: int, planet_id: String = "") -> void:
	if planet_id != "" and analyzed_planets.has(planet_id):
		return  # Already awarded credits for this planet
	set_observation_state(system_seed, ObservationState.EXPLORED)
	if planet_id != "":
		analyzed_planets[planet_id] = true
	award_credits(CREDITS_ANALYZE_PLANET, "Planet analysis")

# --- Persistence ---

func export_data() -> Dictionary:
	return {
		"credits": credits,
		"lifetime_credits": lifetime_credits,
		"rank": rank,
		"observed_systems": observed_systems.duplicate(),
		"analyzed_planets": analyzed_planets.duplicate(),
		"unlocked_blueprints": unlocked_blueprints.duplicate()
	}

func import_data(data: Dictionary) -> void:
	credits = data.get("credits", 0)
	lifetime_credits = data.get("lifetime_credits", 0)
	observed_systems = data.get("observed_systems", {}).duplicate()
	analyzed_planets = data.get("analyzed_planets", {}).duplicate()
	unlocked_blueprints = data.get("unlocked_blueprints", {}).duplicate()
	rank = _calculate_rank()
