class_name DiscoveryBroker
extends Node

const HABITABLE_DISCOVERY_CONVO = "res://assets/narrative/conversations/habitable_discovery.json"

var dialogue_manager: DialogueManager
var probe_system: ProbeSystem
var system_state_manager: SystemStateManager
var star_system_provider: Callable

func configure(probe_sys: ProbeSystem, dialogue_mgr: DialogueManager, state_manager: SystemStateManager, star_provider: Callable):
	_remove_existing_connections()
	probe_system = probe_sys
	dialogue_manager = dialogue_mgr
	system_state_manager = state_manager
	star_system_provider = star_provider

	if probe_system:
		probe_system.probe_launched.connect(_on_probe_launched)
		probe_system.probe_arrived.connect(_on_probe_arrived)
		probe_system.discovery_made.connect(_on_discovery_made)

func _remove_existing_connections():
	if probe_system:
		if probe_system.probe_launched.is_connected(_on_probe_launched):
			probe_system.probe_launched.disconnect(_on_probe_launched)
		if probe_system.probe_arrived.is_connected(_on_probe_arrived):
			probe_system.probe_arrived.disconnect(_on_probe_arrived)
		if probe_system.discovery_made.is_connected(_on_discovery_made):
			probe_system.discovery_made.disconnect(_on_discovery_made)

func show_planet_discovered_message(planet_name: String):
	if dialogue_manager:
		dialogue_manager.show_ai_message(
			"Planetary body detected: " + planet_name + ". Updating stellar cartography database.",
			"friendly"
		)

func _on_probe_launched(target, _probe_type):
	var target_name = _extract_target_name(target)
	GameLog.info("DISCOVERY", "Probe launched to %s" % target_name)

func _on_probe_arrived(target, _probe_type, data):
	var target_name = _extract_target_name(target)
	GameLog.info("DISCOVERY", "Probe arrived at %s" % target_name)
	_save_state()
	_show_major_discovery_if_needed(target_name, data)

func _on_discovery_made(discovery_type: String, target, data):
	var target_name = _extract_target_name(target)
	GameLog.info("DISCOVERY", "Discovery made: %s on %s" % [discovery_type, target_name])
	_save_state()
	_show_discovery_dialogue(discovery_type, target_name, data)

func _extract_target_name(target) -> String:
	if target is Planet:
		return target.planet_name
	if target is String:
		return target
	return "Unknown Target"

func _save_state():
	if not system_state_manager or not probe_system:
		return
	var star_system = star_system_provider.call() if star_system_provider else null
	if star_system:
		system_state_manager.save_system_state(star_system, probe_system)

func _show_major_discovery_if_needed(target_name: String, data: Dictionary):
	# Habitable world discoveries are now handled via conversation in _show_discovery_dialogue
	# This function only handles non-habitable major discoveries
	if not dialogue_manager:
		return

	# Skip if this is a habitable world (handled by conversation)
	if data.has("habitability_score") and data.habitability_score > 0.5:
		return

	var message = ""
	var personality = "alert"

	if data.has("biosignatures") and data.biosignatures.has("detected") and data.biosignatures.detected:
		message = "Biosignatures detected on " + target_name + "."
	elif data.has("surface_liquids") and data.surface_liquids.has("water") and data.surface_liquids.water > 0.5:
		message = "Extensive liquid water detected on " + target_name + "."

	if message != "":
		dialogue_manager.show_ai_message(message, personality)

func _show_discovery_dialogue(discovery_type: String, target_name: String, data: Dictionary):
	if not dialogue_manager:
		return

	match discovery_type:
		"habitable_world":
			if data.get("habitability_score", 0) > 0.5:
				# Use conversation for habitable planet discoveries
				_start_habitable_discovery_conversation(target_name, data)
				return
		"biosignatures":
			dialogue_manager.show_ai_message(
				"BREAKTHROUGH: Confirmed biosignatures detected on " + target_name + "!",
				"alert"
			)
		"extreme_geology":
			dialogue_manager.show_ai_message(
				"Remarkable geological phenomena detected on " + target_name + ".",
				"concerned"
			)
		"unusual_atmosphere":
			dialogue_manager.show_ai_message(
				"Atmospheric anomaly confirmed on " + target_name + ".",
				"concerned"
			)

func _start_habitable_discovery_conversation(planet_name: String, _data: Dictionary):
	# Start the habitable discovery conversation
	# The conversation file can reference planet_name via metadata if needed
	dialogue_manager.start_conversation_from_file(HABITABLE_DISCOVERY_CONVO, "habitable_discovery_" + planet_name)
