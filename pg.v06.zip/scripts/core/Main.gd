extends Node2D
#Main.gd

const MAIN_LOG_TAG := "MAIN"

func _log_info(message: String, values: Array = []):
	GameLog.info(MAIN_LOG_TAG, message % values if values.size() > 0 else message)

@export var sun_texture: Texture2D
@export var planet_texture: Texture2D
@export var star_texture: Texture2D

var bootstrap: GameBootstrap
var session: ExplorationSession
var discovery_broker: DiscoveryBroker

var display_scale_manager: DisplayScaleManager
var network_manager: NetworkManager
var input_manager: InputManager
var camera_manager: CameraManager
var system_state_manager: SystemStateManager
var multiplayer_game_manager: MultiplayerGameManager
var dialogue_manager: DialogueManager
var transition_manager: TransitionManager
var time_manager: TimeManager
var ui_manager: UIManager
var scene_manager: SceneManager
var system_generation_manager: SystemGenerationManager
var save_game_manager: SaveGameManager
var foundation: Foundation
var game_services: GameServices
var game_assets: GameAssets
var game_logger: GameLogger
var show_orbits: bool = true
var game_started: bool = false
var current_seed: int = 0
var star_system: StarSystem
var system_history: StarSystemHistory
var current_star_type: String = ""
var probe_system: ProbeSystem
var dialogue_system: DialogueSystem
var star_background: ProceduralStarBackground

func _ready():
	bootstrap = GameBootstrap.new()
	add_child(bootstrap)
	bootstrap.boot_completed.connect(_on_boot_completed)
	bootstrap.initialize(self, sun_texture, planet_texture, star_texture)

func _on_boot_completed(services: GameServices, assets: GameAssets, system_gen_manager: SystemGenerationManager):
	game_services = services
	game_assets = assets
	system_generation_manager = system_gen_manager
	save_game_manager = self.save_game_manager

	# Managers were assigned during bootstrap
	display_scale_manager = self.display_scale_manager
	input_manager = self.input_manager
	camera_manager = self.camera_manager
	network_manager = self.network_manager
	transition_manager = self.transition_manager
	time_manager = self.time_manager
	ui_manager = self.ui_manager
	scene_manager = self.scene_manager
	multiplayer_game_manager = self.multiplayer_game_manager

	discovery_broker = DiscoveryBroker.new()
	add_child(discovery_broker)

	session = ExplorationSession.new()
	add_child(session)
	session.initialize(self, game_services, game_assets, system_generation_manager, discovery_broker, star_texture)
	session.star_system_changed.connect(_on_session_star_system_changed)
	session.game_started.connect(_on_session_game_started)
	session.system_state_manager_ready.connect(_on_system_state_manager_ready)
	session.system_history_ready.connect(_on_system_history_ready)
	session.probe_system_ready.connect(_on_probe_system_ready)
	session.dialogue_manager_ready.connect(_on_dialogue_manager_ready)
	session.star_background_ready.connect(_on_star_background_ready)
	session.show_orbits_changed.connect(_on_show_orbits_changed)

func _on_session_game_started():
	game_started = true

func _on_session_star_system_changed(system: StarSystem, seed_value: int, star_type: String):
	star_system = system
	current_seed = seed_value
	current_star_type = star_type

func _on_system_state_manager_ready(manager: SystemStateManager):
	system_state_manager = manager

func _on_system_history_ready(history: StarSystemHistory):
	system_history = history

func _on_probe_system_ready(probe_sys: ProbeSystem):
	probe_system = probe_sys

func _on_dialogue_manager_ready(manager: DialogueManager):
	dialogue_manager = manager
	if session:
		dialogue_system = session.dialogue_system

func _on_star_background_ready(background: ProceduralStarBackground):
	star_background = background

func _on_show_orbits_changed(enabled: bool):
	show_orbits = enabled

func is_system_valid() -> bool:
	return session and session.is_system_valid()

func get_current_star_system() -> StarSystem:
	return session.get_current_star_system() if session else null

func get_current_seed() -> int:
	return session.get_current_seed() if session else current_seed

func generate_star_system(seed_value: int = randi()):
	if session:
		session.generate_star_system(seed_value)

func clear_current_system():
	if system_generation_manager and star_system:
		system_generation_manager._clear_existing_system(star_system)

func _on_escape_pressed():
	if session:
		session._on_escape_pressed()

func _on_debug_habitability_requested():
	if session:
		session._on_debug_habitability_requested()

func _on_toggle_habitable_zone_requested():
	if session:
		session._on_toggle_habitable_zone_requested()

func _on_show_probe_status_requested():
	if session:
		session._on_show_probe_status_requested()

func _on_ai_message_requested():
	if session:
		session._on_ai_message_requested()

func _on_transmission_requested():
	if session:
		session._on_transmission_requested()

func _on_camera_panned():
	if session:
		session._on_camera_panned()

func _on_camera_state_changed(is_tracking: bool, is_moved: bool):
	if session:
		session._on_camera_state_changed(is_tracking, is_moved)

func show_system_generation_message():
	if session:
		session.show_system_generation_message()

func _on_new_system_requested():
	if session:
		session._on_new_system_requested()

func _on_options_requested():
	if session:
		session._on_options_requested()

func _on_history_system_selected(seed_value: int):
	if session:
		session._on_history_system_selected(seed_value)

func _on_toggle_orbits_requested(value: bool):
	if session:
		session._on_toggle_orbits_requested(value)

func update_orbit_visibility():
	if session:
		session.update_orbit_visibility()

func _show_celestial_info():
	if session:
		session._show_celestial_info()

func _on_info_panel_view_changed(view_type):
	if session:
		session._on_info_panel_view_changed(view_type)

func _open_planet_map_scene(planet: Planet):
	if session:
		session._open_planet_map_scene(planet)

func _on_object_clicked(object):
	if session:
		session._on_object_clicked(object)

func _on_stats_panel_clicked():
	if session:
		session._on_stats_panel_clicked()

func _on_stop_tracking_requested():
	if session:
		session._on_stop_tracking_requested()

func _on_reset_camera_requested():
	if session:
		session._on_reset_camera_requested()

func _show_options_menu():
	if session:
		session._show_options_menu()

func _on_seed_loaded(seed_value: int):
	if session:
		session._on_seed_loaded(seed_value)

func _on_system_info_requested():
	if session:
		session._on_system_info_requested()

func _on_history_requested():
	if session:
		session._on_history_requested()

func _on_open_asset_test_requested():
	if session:
		session._on_open_asset_test_requested()

func _on_dialogue_requested(type: DialogueSystem.DialogueType, data: DialogueData):
	if session:
		session._on_dialogue_requested(type, data)

func show_planet_discovered_message(planet_name: String):
	if discovery_broker:
		discovery_broker.show_planet_discovered_message(planet_name)

func save_current_system_state():
	if session:
		session.save_current_system_state()

func rename_planet(planet: Planet, new_name: String, old_name: String = "") -> bool:
	if session:
		return session.rename_planet(planet, new_name, old_name)
	return false

func get_system_state_summary(system_seed: int) -> Dictionary:
	return session.get_system_state_summary(system_seed) if session else {}

func has_visited_system(system_seed: int) -> bool:
	return session.has_visited_system(system_seed) if session else false


func _log_shutdown_step(label: String, start_ms: int) -> int:
	var now = Time.get_ticks_msec()
	_log_info('%s took %sms', [label, now - start_ms])
	return now

func _notification(what):
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		# Log session duration before shutdown
		if time_manager:
			var stats = time_manager.get_time_stats()
			_log_info('Session ended - Game time: %s, Real time: %.1fs', [
				time_manager.get_formatted_game_time(),
				stats.real_time
			])
		var shutdown_start = Time.get_ticks_msec()
		var step_start = shutdown_start
		if session:
			session.save_current_system_state()
			step_start = _log_shutdown_step('session.save_current_system_state', step_start)
		if star_background and is_instance_valid(star_background):
			star_background.cleanup()
			step_start = _log_shutdown_step('star_background.cleanup', step_start)
		if scene_manager:
			scene_manager.cleanup()
			step_start = _log_shutdown_step('scene_manager.cleanup', step_start)
		if input_manager:
			input_manager.cleanup()
			step_start = _log_shutdown_step('input_manager.cleanup', step_start)
		if camera_manager:
			camera_manager.cleanup()
			step_start = _log_shutdown_step('camera_manager.cleanup', step_start)
		if ui_manager:
			ui_manager.cleanup()
			step_start = _log_shutdown_step('ui_manager.cleanup', step_start)
		_log_shutdown_step('shutdown.total', shutdown_start)
		get_tree().quit()
