# GameServices.gd
class_name GameServices
extends RefCounted

var main_node: Node2D
var time_manager: TimeManager
var transition_manager: TransitionManager
var ui_manager: UIManager
var camera_manager: CameraManager
var system_state_manager: SystemStateManager
var system_history: StarSystemHistory
var network_manager: NetworkManager
var scene_manager: SceneManager
var star_background: ProceduralStarBackground
var probe_system: ProbeSystem
var dialogue_manager: DialogueManager
var save_game_manager: SaveGameManager
var foundation: Foundation
var logger: GameLogger

func required_service_names() -> PackedStringArray:
	return PackedStringArray([
		"main_node",
		"transition_manager",
		"ui_manager",
		"time_manager",
		"camera_manager",
		"scene_manager"
	])

func missing_required() -> Array[String]:
	var missing: Array[String] = []
	for name in required_service_names():
		if get(name) == null:
			missing.append(name)
	return missing

func update_from(other: GameServices):
	if other == null:
		return
	main_node = other.main_node
	time_manager = other.time_manager
	transition_manager = other.transition_manager
	ui_manager = other.ui_manager
	camera_manager = other.camera_manager
	system_state_manager = other.system_state_manager
	system_history = other.system_history
	network_manager = other.network_manager
	scene_manager = other.scene_manager
	star_background = other.star_background
	probe_system = other.probe_system
	dialogue_manager = other.dialogue_manager
	logger = other.logger
