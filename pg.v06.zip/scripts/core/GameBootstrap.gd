class_name GameBootstrap
extends Node

signal boot_completed(services: GameServices, assets: GameAssets, system_generation_manager: SystemGenerationManager)

var services: GameServices
var assets: GameAssets
var logger: GameLogger

func initialize(main_node: Node2D, sun_texture: Texture2D, planet_texture: Texture2D, _star_texture: Texture2D):
	if not main_node:
		push_error("GameBootstrap requires a valid main node")
		return

	services = GameServices.new()
	services.main_node = main_node

	logger = GameLogger.new()
	services.logger = logger
	GameLog.set_logger(logger)
	logger.setup_file_logging()  # Initialize file logging

	assets = GameAssets.new()
	assets.sun_texture = sun_texture
	assets.planet_texture = planet_texture

	main_node.game_services = services
	main_node.game_assets = assets
	main_node.game_logger = logger
	main_node.add_to_group("main")

	var display_scale_manager = DisplayScaleManager.new()
	var input_manager = InputManager.new()
	var camera_manager = CameraManager.new()
	var transition_manager = TransitionManager.new()
	var time_manager = TimeManager.new()
	# Disable networking on web platform (no threading support)
	var network_manager = NetworkManager.new() if OS.get_name() != "Web" else null
	var scene_manager = SceneManager.new()
	var ui_manager = UIManager.new()
	# Disable multiplayer on web platform (no threading support)
	var multiplayer_manager = MultiplayerGameManager.new() if OS.get_name() != "Web" else null
	var system_generation_manager = SystemGenerationManager.new()
	var save_game_manager = SaveGameManager.new()
	var foundation = Foundation.new()

	if not display_scale_manager or not input_manager or not camera_manager or not transition_manager or not time_manager or not scene_manager or not ui_manager or not system_generation_manager or not save_game_manager:
		push_error("Failed to create one or more core managers")
		return

	main_node.display_scale_manager = display_scale_manager
	main_node.input_manager = input_manager
	main_node.camera_manager = camera_manager
	main_node.transition_manager = transition_manager
	main_node.time_manager = time_manager
	if network_manager:
		main_node.network_manager = network_manager
	if multiplayer_manager:
		main_node.multiplayer_game_manager = multiplayer_manager
	main_node.system_generation_manager = system_generation_manager
	main_node.save_game_manager = save_game_manager
	main_node.foundation = foundation
	main_node.scene_manager = scene_manager
	main_node.ui_manager = ui_manager

	main_node.add_child(display_scale_manager)
	main_node.add_child(input_manager)
	main_node.add_child(camera_manager)
	main_node.add_child(transition_manager)
	if transition_manager.has_method("set_time_manager"):
		transition_manager.set_time_manager(time_manager)
	main_node.add_child(time_manager)
	if network_manager:
		main_node.add_child(network_manager)
	main_node.add_child(scene_manager)
	main_node.add_child(ui_manager)
	if multiplayer_manager:
		main_node.add_child(multiplayer_manager)
	main_node.add_child(system_generation_manager)
	main_node.add_child(save_game_manager)
	main_node.add_child(foundation)

	# Initialize display scaling early, before UI setup
	display_scale_manager.initialize()

	services.transition_manager = transition_manager
	services.time_manager = time_manager
	services.ui_manager = ui_manager
	services.camera_manager = camera_manager
	if network_manager:
		services.network_manager = network_manager
	services.scene_manager = scene_manager
	services.save_game_manager = save_game_manager
	services.foundation = foundation

	if network_manager:
		network_manager.init_single_player()
	scene_manager.initialize(main_node.get_viewport(), camera_manager, input_manager, main_node)

	if not scene_manager.ui_manager and scene_manager.has_method("set_ui_manager"):
		scene_manager.set_ui_manager(ui_manager)

	var canvas_layer = main_node.get_node_or_null("CanvasLayer")
	if multiplayer_manager and multiplayer_manager.has_method("initialize"):
		multiplayer_manager.initialize(network_manager, transition_manager, canvas_layer)

	save_game_manager.initialize(services)

	emit_signal("boot_completed", services, assets, system_generation_manager)
