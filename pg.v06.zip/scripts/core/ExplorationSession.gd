class_name ExplorationSession
extends Node
signal star_system_changed(star_system: StarSystem, seed_value: int, star_type: String)
signal game_started()
signal system_state_manager_ready(manager: SystemStateManager)
signal system_history_ready(history: StarSystemHistory)
signal probe_system_ready(probe_system: ProbeSystem)
signal dialogue_manager_ready(dialogue_manager: DialogueManager)
signal star_background_ready(background: ProceduralStarBackground)
signal show_orbits_changed(enabled: bool)
const LOG_TAG := "SESSION"
func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, message.format(values) if values.size() > 0 else message)
func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, message.format(values) if values.size() > 0 else message)
func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, message.format(values) if values.size() > 0 else message)
func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, message.format(values) if values.size() > 0 else message)
var main_node: Node2D
var services: GameServices
var assets: GameAssets
var discovery_broker: DiscoveryBroker
var system_generation_manager: SystemGenerationManager
var star_texture: Texture2D
var input_manager: InputManager
var camera_manager: CameraManager
var scene_manager: SceneManager
var ui_manager: UIManager
var network_manager: NetworkManager
var transition_manager: TransitionManager
var time_manager: TimeManager
var canvas_layer: CanvasLayer
var show_orbits := true
var session_started := false
var current_seed: int = 0
var current_star_type: String = ""
var star_system: StarSystem
var system_state_manager: SystemStateManager
var system_history: StarSystemHistory
var dialogue_system: DialogueSystem
var dialogue_manager: DialogueManager
var probe_system: ProbeSystem
var automated_explorer_ai: AutomatedExplorerAI
var save_game_manager: SaveGameManager
var foundation: Foundation
var star_background: ProceduralStarBackground
var pending_ui_restore: bool = false
var intro_sequence_manager: IntroSequenceManager
var intro_sequence_scene: IntroSequenceScene

# Sector system
var galaxy_seed: int = 0       # Top-level seed for this game
var sector_index: int = 0      # Which sector player is in
var sector_seed: int = 0       # Seed for current sector (derived)
var sector_size: int = 0       # How many stars in current sector (200-1024)
var star_index: int = 0        # Which star within the sector
var current_world_scenario: String = ""  # Active world scenario for current sector
var _world_scenario_manager: WorldScenarioManager = null
var opossum_systems_visited: int = 0     # How many opossum sector systems seen this game
var _loading_save: bool = false

# After this many opossum systems the Opossum God encounter hint fires
const OPOSSUM_BOSS_TRIGGER := 5

func initialize(p_main_node: Node2D, p_services: GameServices, p_assets: GameAssets, system_gen_manager: SystemGenerationManager, discovery: DiscoveryBroker, p_star_texture: Texture2D):
	self.main_node = p_main_node
	self.services = p_services
	save_game_manager = p_services.save_game_manager if p_services else null
	foundation = p_services.foundation if p_services else null
	self.assets = p_assets
	system_generation_manager = system_gen_manager
	discovery_broker = discovery
	self.star_texture = p_star_texture

	input_manager = main_node.input_manager
	camera_manager = main_node.camera_manager
	scene_manager = main_node.scene_manager
	ui_manager = main_node.ui_manager
	network_manager = main_node.network_manager
	transition_manager = main_node.transition_manager
	time_manager = main_node.time_manager
	canvas_layer = main_node.get_node_or_null("CanvasLayer")

	_connect_manager_signals()
	_prepare_history()
	_setup_start_screen()

func _connect_manager_signals():
	if input_manager:
		input_manager.escape_pressed.connect(_on_escape_pressed)
		input_manager.debug_habitability_requested.connect(_on_debug_habitability_requested)
		input_manager.toggle_habitable_zone_requested.connect(_on_toggle_habitable_zone_requested)
		input_manager.show_probe_status_requested.connect(_on_show_probe_status_requested)
		input_manager.ai_message_requested.connect(_on_ai_message_requested)
		input_manager.transmission_requested.connect(_on_transmission_requested)
		input_manager.new_system_requested.connect(_on_new_system_requested)

	if camera_manager:
		camera_manager.camera_panned.connect(_on_camera_panned)
		camera_manager.camera_state_changed.connect(_on_camera_state_changed)

	if scene_manager:
		scene_manager.scene_changed.connect(_on_scene_changed)
		scene_manager.planet_map_options_requested.connect(_on_planet_map_options_requested)

	if system_generation_manager:
		system_generation_manager.system_generation_started.connect(_on_system_generation_started)
		system_generation_manager.system_generation_complete.connect(_on_system_generation_complete)
		system_generation_manager.system_generation_failed.connect(_on_system_generation_failed)
		system_generation_manager.ui_loading_state_changed.connect(_on_generation_loading_state_changed)
		system_generation_manager.ui_state_save_requested.connect(_on_generation_ui_state_save_requested)
		system_generation_manager.ui_state_restore_requested.connect(_on_generation_ui_state_restore_requested)
		system_generation_manager.info_panel_close_requested.connect(_on_generation_info_panel_close_requested)
		system_generation_manager.options_info_changed.connect(_on_generation_options_info_changed)
		system_generation_manager.object_clicked.connect(_on_object_clicked)

	if main_node.multiplayer_game_manager:
		main_node.multiplayer_game_manager.game_initialization_requested.connect(_on_mp_game_initialization_requested)
		main_node.multiplayer_game_manager.star_system_generation_requested.connect(_on_mp_star_system_generation_requested)
		main_node.multiplayer_game_manager.start_screen_cleanup_requested.connect(_on_mp_start_screen_cleanup_requested)

	if ui_manager:
		ui_manager.control_panel_new_system_requested.connect(_on_new_system_requested)
		ui_manager.control_panel_options_requested.connect(_on_options_requested)
		ui_manager.control_panel_ai_toggle_requested.connect(_on_ai_toggle_requested)
		ui_manager.camera_reset_requested.connect(_on_reset_camera_requested)
		ui_manager.camera_stop_tracking_requested.connect(_on_stop_tracking_requested)
		ui_manager.celestial_body_selected.connect(_on_celestial_body_selected)
		ui_manager.stats_panel_clicked.connect(_on_stats_panel_clicked)
		ui_manager.options_toggle_orbits_requested.connect(_on_toggle_orbits_requested)
		ui_manager.options_seed_loaded.connect(_on_seed_loaded)
		ui_manager.asset_test_requested.connect(_on_open_asset_test_requested)
		ui_manager.save_game_requested.connect(_on_save_game_requested)
		ui_manager.load_game_requested.connect(_on_load_game_requested)
		ui_manager.save_to_slot_requested.connect(_on_save_to_slot)
		ui_manager.load_from_slot_requested.connect(_on_load_from_slot)
		ui_manager.info_panel_restore_requested.connect(_on_info_panel_restore_requested)
		ui_manager.asset_test_closed.connect(_on_sandbox_closed)
		ui_manager.main_menu_requested.connect(_on_main_menu_requested)
		ui_manager.quit_requested.connect(_on_quit_requested)

	if time_manager:
		time_manager.time_scale_changed.connect(_on_time_scale_changed)
func _prepare_history():
	system_history = StarSystemHistory.new()
	system_history.system_selected.connect(_on_history_system_selected)
	services.system_history = system_history
	emit_signal("system_history_ready", system_history)

	if ui_manager and canvas_layer:
		ui_manager.initialize(canvas_layer, system_history, time_manager)
		ui_manager.save_game_manager = save_game_manager

func _setup_start_screen():
	var save_summary = _get_save_summary()
	var start_screen = ui_manager.show_start_screen(save_summary) if ui_manager else null
	if start_screen:
		start_screen.start_game_requested.connect(_on_start_game_requested)
		start_screen.load_game_requested.connect(_on_start_screen_load_requested)
		start_screen.multiplayer_requested.connect(_on_show_multiplayer_menu)
		start_screen.sandbox_requested.connect(_on_sandbox_requested)

	# Check for --sandbox command-line flag to auto-open sandbox
	_check_auto_sandbox()

	# Check for --auto-planet command-line flag to jump to first planet
	_check_auto_planet()

	# Check for --minigame command-line flag to open games tab
	_check_auto_minigame()

func _on_scene_changed(scene_name: String):
	_log_info("Scene changed to: {0}", [scene_name])

func _on_system_generation_started(seed_value: int):
	current_seed = seed_value
	_log_info("System generation started for seed: {0}", [seed_value])

func _on_system_generation_complete(new_star_system: StarSystem):
	star_system = new_star_system
	if time_manager and not _loading_save:
		time_manager.reset_game_time()
	_loading_save = false
	if system_generation_manager:
		current_seed = system_generation_manager.get_current_seed()
		current_star_type = system_generation_manager.get_current_star_type()
	_log_info("System generation complete for seed {0}", [current_seed])
	if foundation:
		foundation.on_system_observed(current_seed, current_star_type)
	emit_signal("star_system_changed", star_system, current_seed, current_star_type)
	_attempt_ui_restore()
	# Update camera control panel with new star system
	if ui_manager:
		ui_manager.set_star_system(star_system)

func _on_system_generation_failed(error_message: String):
	_log_error("System generation failed: {0}", [error_message])
	pending_ui_restore = false

func _on_info_panel_restore_requested():
	_show_celestial_info()
	var info_panel = ui_manager.get_current_info_panel()
	if info_panel and info_panel.controller and star_system and is_instance_valid(star_system):
		var system_model = StarSystemModel.new(star_system.star_name, star_system.current_seed, star_system.get_star_type_name())
		system_model.planet_count = _count_planets(star_system)
		_apply_sector_to_model(system_model)
		info_panel.controller.show_solar_system(system_model)

func _setup_startup_state():
	_show_celestial_info()

func _on_show_multiplayer_menu():
	if main_node.multiplayer_game_manager and ui_manager:
		main_node.multiplayer_game_manager.show_multiplayer_menu(ui_manager.start_screen)

func _on_sandbox_requested():
	"""Open the sandbox directly from the start menu"""
	if not transition_manager or not ui_manager:
		return
	var start_screen = ui_manager.start_screen if ui_manager else null
	if start_screen and is_instance_valid(start_screen):
		start_screen.set_process_input(false)
	await transition_manager.fade_to_black(0.3)
	ui_manager.hide_start_screen()
	ui_manager.show_asset_test(null, null)
	await transition_manager.fade_from_black(0.3)

func _on_sandbox_closed():
	"""Return to start screen when sandbox is closed"""
	if not transition_manager or not ui_manager:
		return
	await transition_manager.fade_to_black(0.3)
	var save_summary = _get_save_summary()
	var start_screen = ui_manager.show_start_screen(save_summary)

	# Reconnect signals to the new start screen instance
	if start_screen:
		start_screen.start_game_requested.connect(_on_start_game_requested)
		start_screen.load_game_requested.connect(_on_start_screen_load_requested)
		start_screen.multiplayer_requested.connect(_on_show_multiplayer_menu)
		start_screen.sandbox_requested.connect(_on_sandbox_requested)

	await transition_manager.fade_from_black(0.3)

func _on_main_menu_requested():
	if not transition_manager or not ui_manager:
		return
	_auto_save()
	await transition_manager.fade_to_black(0.3)
	if scene_manager:
		scene_manager.cleanup()
	session_started = false
	var save_summary = _get_save_summary()
	var start_screen = ui_manager.show_start_screen(save_summary)
	if start_screen:
		start_screen.start_game_requested.connect(_on_start_game_requested)
		start_screen.load_game_requested.connect(_on_start_screen_load_requested)
		start_screen.multiplayer_requested.connect(_on_show_multiplayer_menu)
		start_screen.sandbox_requested.connect(_on_sandbox_requested)
	await transition_manager.fade_from_black(0.3)

func _on_quit_requested():
	_auto_save()
	get_tree().quit()

func _on_start_game_requested():
	if not transition_manager or not ui_manager:
		return
	var start_screen = ui_manager.start_screen if ui_manager else null
	if start_screen and is_instance_valid(start_screen):
		start_screen.set_process_input(false)

	# Generate seed for this game
	var game_seed = randi()

	await transition_manager.fade_to_black(0.3)
	ui_manager.hide_start_screen()

	# Show intro sequence
	await _show_intro_sequence(game_seed)

	# Initialize game with the same seed
	_initialize_game(false)  # Don't auto-generate, we'll use our seed
	_init_sectors(game_seed)
	generate_star_system(_next_star_seed())

	await get_tree().create_timer(1.0).timeout
	await transition_manager.fade_from_black(0.3)

func _on_start_screen_load_requested():
	if not ui_manager:
		return
	ui_manager.show_save_list_dialog(SaveListDialog.Mode.LOAD)

func _on_load_game_requested():
	if not ui_manager:
		return
	ui_manager.show_save_list_dialog(SaveListDialog.Mode.LOAD)

func _on_load_from_slot(slot_id: String):
	if not transition_manager or not ui_manager or not save_game_manager:
		return
	var start_screen = ui_manager.start_screen if ui_manager else null
	if start_screen and is_instance_valid(start_screen):
		start_screen.set_process_input(false)
	await transition_manager.fade_to_black(0.3)
	ui_manager.hide_start_screen()
	_initialize_game(false)
	var result = save_game_manager.load_from_slot(slot_id)
	if result.success:
		_loading_save = true
		_log_info("Loaded save from slot: {0}", [slot_id])
		var meta: Dictionary = result.meta if result.meta is Dictionary else {}
		await _restore_from_meta(meta)
	else:
		_log_error("Game load failed: {0}", [result.message])
		generate_star_system()
	await get_tree().create_timer(1.0).timeout
	await transition_manager.fade_from_black(0.3)

func _restore_from_meta(meta: Dictionary):
	if meta.has("show_orbits"):
		var orbits_value = meta.get("show_orbits", show_orbits)
		if typeof(orbits_value) == TYPE_BOOL and orbits_value != show_orbits:
			show_orbits = orbits_value
			_on_toggle_orbits_requested(show_orbits)
	# Restore sector state
	if meta.has("sector_index"):
		galaxy_seed = int(meta.get("galaxy_seed", 0))
		sector_index = int(meta.get("sector_index", 0))
		sector_seed = int(meta.get("sector_seed", 0))
		sector_size = int(meta.get("sector_size", 0))
		star_index = int(meta.get("star_index", 0))
		_world_scenario_manager = WorldScenarioManager.new()
		_world_scenario_manager.initialize(galaxy_seed)
		_update_world_scenario()
		_log_info("Restored sector {0}, star {1}/{2}", [sector_index, star_index, sector_size])
	# Restore time manager state
	if time_manager and meta.has("game_time_elapsed"):
		time_manager.game_time_elapsed = float(meta.get("game_time_elapsed", 0.0))
		time_manager.game_days_elapsed = float(meta.get("game_days_elapsed", 0.0))
		time_manager.simulation_tick_count = int(meta.get("simulation_tick_count", 0))
		var saved_scale = float(meta.get("time_scale", 1.0))
		if saved_scale > 0.0:
			time_manager.set_time_scale(saved_scale)
	var seed_value = int(meta.get("current_seed", current_seed))
	if seed_value != -1:
		current_seed = seed_value
		generate_star_system(seed_value)
	else:
		generate_star_system()
	# Restore planet map view if saved while on planet map
	var active_planet_id: String = str(meta.get("active_planet_id", ""))
	if active_planet_id != "" and probe_system:
		await get_tree().create_timer(0.5).timeout
		var planet := probe_system._find_planet_by_stable_id(active_planet_id)
		if planet and is_instance_valid(planet):
			_log_info("Restoring planet map view for planet: {0}", [planet.planet_name])
			_open_planet_map_scene(planet)
		else:
			_log_warn("Could not find planet {0} to restore planet map", [active_planet_id])
func _on_mp_game_initialization_requested(skip_start_screen: bool):
	if not session_started:
		_initialize_game(not skip_start_screen)
	else:
		_log_info("Multiplayer requested initialization but session already running")

func _on_mp_star_system_generation_requested():
	generate_star_system()

func _on_mp_start_screen_cleanup_requested():
	if ui_manager:
		ui_manager.hide_start_screen()

func _show_intro_sequence(game_seed: int):
	intro_sequence_manager = IntroSequenceManager.new()
	main_node.add_child(intro_sequence_manager)

	intro_sequence_scene = IntroSequenceScene.new()
	main_node.add_child(intro_sequence_scene)

	# Wait for _ready() to be called
	await get_tree().process_frame

	intro_sequence_scene.sequence_finished.connect(_on_intro_sequence_finished)

	_log_info("Starting intro sequence with seed: {0}", [game_seed])
	intro_sequence_scene.start_sequence(intro_sequence_manager, game_seed)

	await intro_sequence_scene.sequence_finished

func _on_intro_sequence_finished():
	_log_info("Intro sequence finished")

	if intro_sequence_scene and is_instance_valid(intro_sequence_scene):
		intro_sequence_scene.queue_free()
		intro_sequence_scene = null

	if intro_sequence_manager and is_instance_valid(intro_sequence_manager):
		intro_sequence_manager.queue_free()
		intro_sequence_manager = null

func _initialize_game(generate_system: bool = true):
	session_started = true
	emit_signal("game_started")

	if input_manager:
		input_manager.set_game_started(true)

	if not system_state_manager:
		system_state_manager = SystemStateManager.new()
		services.system_state_manager = system_state_manager
		main_node.add_child(system_state_manager)
		emit_signal("system_state_manager_ready", system_state_manager)

	if system_history and not system_history.get_parent():
		main_node.add_child(system_history)

	setup_camera()
	setup_background()
	if ui_manager:
		ui_manager.foundation = foundation
		ui_manager.setup_game_ui()

	_initialize_system_generation_manager()

	if generate_system:
		generate_star_system()

	_setup_toast_notifications()
	setup_dialogue_system()
	setup_probe_system()
	setup_ai_explorer()
	setup_background_audio()

func _initialize_system_generation_manager():
	if not system_generation_manager:
		_log_error("SystemGenerationManager missing, cannot initialize")
		return

	services.transition_manager = transition_manager
	services.ui_manager = ui_manager
	services.camera_manager = camera_manager
	services.scene_manager = scene_manager
	services.network_manager = network_manager
	services.system_state_manager = system_state_manager
	services.system_history = system_history
	services.star_background = star_background
	services.probe_system = probe_system
	services.dialogue_manager = dialogue_manager

	if assets and assets.sun_texture and assets.planet_texture:
		system_generation_manager.initialize(services, assets)

func setup_camera():
	if camera_manager:
		camera_manager.setup_camera()

func setup_background():
	if main_node.has_node("StarMapBackground"):
		main_node.get_node("StarMapBackground").queue_free()

	star_background = ProceduralStarBackground.new()
	star_background.star_texture = star_texture
	main_node.add_child(star_background)
	services.star_background = star_background
	main_node.move_child(star_background, 0)
	emit_signal("star_background_ready", star_background)

func setup_dialogue_system():
	dialogue_system = DialogueSystem.new()
	main_node.add_child(dialogue_system)

	dialogue_manager = DialogueManager.new(dialogue_system)
	main_node.add_child(dialogue_manager)
	services.dialogue_manager = dialogue_manager
	emit_signal("dialogue_manager_ready", dialogue_manager)

	if input_manager:
		input_manager.initialize(dialogue_manager)

	dialogue_manager.dialogue_requested.connect(_on_dialogue_requested)

func setup_probe_system():
	probe_system = ProbeSystem.new()
	probe_system.network_manager = network_manager
	main_node.add_child(probe_system)
	services.probe_system = probe_system
	emit_signal("probe_system_ready", probe_system)

	probe_system.discovery_made.connect(func(discovery_type, _target, data):
		if discovery_type == "habitable_world" and data.get("habitability_score", 0) > 0.5:
			network_manager.found_habitable_planet()
	)

	if foundation:
		probe_system.probe_arrived.connect(_on_probe_arrived_foundation)

	if discovery_broker:
		discovery_broker.configure(probe_system, dialogue_manager, system_state_manager, func(): return star_system)

func _on_probe_arrived_foundation(target, _probe_type, _data: Dictionary) -> void:
	if not foundation:
		return
	var system_seed := current_seed
	var planet_id := ""
	if target is Planet:
		planet_id = str(system_seed) + ":" + str(star_system.get_planet_index(target)) if star_system else ""
	foundation.on_planet_analyzed(system_seed, planet_id)

func setup_ai_explorer():
	automated_explorer_ai = AutomatedExplorerAI.new()
	automated_explorer_ai.initialize(main_node)
	automated_explorer_ai.habitable_planet_discovered.connect(_on_ai_habitable_planet_discovered)
	if foundation:
		automated_explorer_ai.planet_examined.connect(_on_ai_planet_examined)
	main_node.add_child(automated_explorer_ai)
	_log_info("AI Explorer system initialized")

func _on_ai_planet_examined(planet: Planet) -> void:
	if not foundation or not star_system:
		return
	var idx := star_system.get_planet_index(planet)
	var planet_id := str(current_seed) + ":" + str(idx)
	foundation.on_planet_analyzed(current_seed, planet_id)

func setup_background_audio():
	var white_noise = WhiteNoiseGenerator.new()
	white_noise.noise_volume = 0.5
	main_node.add_child(white_noise)

func _setup_toast_notifications():
	if foundation:
		foundation.credits_changed.connect(_on_foundation_credits_toast)
		foundation.rank_changed.connect(_on_foundation_rank_toast)

func _on_foundation_credits_toast(_balance: int, delta: int, reason: String = "") -> void:
	if delta > 0 and ui_manager and ui_manager.stats_panel:
		var msg := "+%d  %s" % [delta, reason] if reason != "" else "+%d credits" % delta
		ui_manager.stats_panel.show_toast(msg, TerminalTheme.terminal_green)

func _on_foundation_rank_toast(new_rank: int, _old_rank: int) -> void:
	if ui_manager and ui_manager.stats_panel:
		ui_manager.stats_panel.show_toast("Rank up: %d" % new_rank, Color(0.9, 0.8, 0.2))

func is_system_valid() -> bool:
	return star_system != null and is_instance_valid(star_system)

func get_current_star_system() -> StarSystem:
	return star_system

func get_current_seed() -> int:
	return current_seed

func _init_sectors(p_galaxy_seed: int):
	galaxy_seed = p_galaxy_seed
	# Start in a random sector far from 0 — each game is a different region of the galaxy
	sector_index = abs(galaxy_seed) % 899999 + 100000
	star_index = 0
	opossum_systems_visited = 0
	sector_seed = _calc_sector_seed(sector_index)
	sector_size = _calc_sector_size(sector_seed)
	_world_scenario_manager = WorldScenarioManager.new()
	_world_scenario_manager.initialize(galaxy_seed)
	_update_world_scenario()
	_log_info("Sector {0} initialized: {1} stars (seed {2})", [sector_index, sector_size, sector_seed])

func _advance_sector():
	sector_index += 1
	star_index = 0
	sector_seed = _calc_sector_seed(sector_index)
	sector_size = _calc_sector_size(sector_seed)
	_update_world_scenario()
	_log_info("Entered sector {0}: {1} stars (seed {2})", [sector_index, sector_size, sector_seed])

func _update_world_scenario():
	if _world_scenario_manager:
		current_world_scenario = _world_scenario_manager.get_sector_scenario(sector_index)
		if current_world_scenario != "":
			_log_info("World scenario active: {0}", [current_world_scenario])

func _calc_sector_seed(s_index: int) -> int:
	# Deterministic per sector, unique across galaxies
	return hash(galaxy_seed ^ (s_index * 2654435761))

func _calc_sector_size(s_seed: int) -> int:
	var rng = RandomNumberGenerator.new()
	rng.seed = s_seed
	return rng.randi_range(200, 1024)

func _next_star_seed() -> int:
	# Each star in a sector gets a unique deterministic seed
	return hash(sector_seed ^ (star_index * 2246822519))

func _apply_sector_to_model(model: StarSystemModel) -> void:
	model.sector_index = sector_index
	model.star_index = star_index

func get_sector_info() -> Dictionary:
	return {
		"galaxy_seed": galaxy_seed,
		"sector_index": sector_index,
		"sector_seed": sector_seed,
		"sector_size": sector_size,
		"star_index": star_index,
	}

func generate_star_system(seed_value: int = randi()):
	if system_generation_manager:
		system_generation_manager.force_habitable_system = (current_world_scenario == WorldScenarioManager.SCENARIO_OPOSSUM_SECTOR)
		system_generation_manager.generate_star_system(seed_value)
	else:
		_log_error("SystemGenerationManager not initialized")

func _on_escape_pressed():
	if not scene_manager or not ui_manager:
		return

	match scene_manager.get_current_scene_type():
		SceneManager.SceneType.PLANET_MAP:
			if ui_manager.is_options_open:
				return
			_show_options_menu()
		SceneManager.SceneType.STAR_SYSTEM:
			if ui_manager.is_options_open:
				return
			elif ui_manager.current_info_panel:
				ui_manager.close_info_panel()
			else:
				_show_options_menu()
		_:
			if ui_manager.is_options_open:
				return
			_show_options_menu()

func _on_planet_map_options_requested():
	if ui_manager and not ui_manager.is_options_open:
		_show_options_menu()


func _on_debug_habitability_requested():
	if star_system and star_system.has_method("debug_planet_habitability"):
		star_system.debug_planet_habitability()

func _on_toggle_habitable_zone_requested():
	if star_system and star_system.has_method("set_habitable_zone_visibility"):
		star_system.show_habitable_zone = !star_system.show_habitable_zone
		star_system.queue_redraw()
		_log_debug("Habitable zone visibility: {0}", ["ON" if star_system and star_system.show_habitable_zone else "OFF"])

func _on_show_probe_status_requested():
	_log_debug("Probe system status:")
	_log_debug("  Resources: {0}", [str(probe_system.player_resources) if probe_system else "N/A"])
	_log_debug("  Active probes: {0}", [str(probe_system.active_probes.size()) if probe_system else "N/A"])

func _on_ai_message_requested():
	if dialogue_manager:
		dialogue_manager.generate_random_ai_message()

func _on_transmission_requested():
	if dialogue_manager:
		dialogue_manager.generate_random_transmission()

func _on_ai_toggle_requested():
	if not automated_explorer_ai:
		_log_warn("AI Explorer not initialized")
		return

	if automated_explorer_ai.is_active:
		# Stop the AI
		automated_explorer_ai.stop_exploration()
		if ui_manager:
			ui_manager.set_ai_explorer_active(false)
		_log_info("AI Explorer deactivated")
	else:
		# Start the AI
		automated_explorer_ai.start_exploration()
		if ui_manager:
			ui_manager.set_ai_explorer_active(true)
		_log_info("AI Explorer activated")

func _on_ai_habitable_planet_discovered(planet: Planet):
	_log_info("AI Explorer discovered highly habitable planet: %s (%.1f%% habitability)", [planet.planet_name, planet.habitability_score * 100])

	# Update UI to show AI is stopped
	if ui_manager:
		ui_manager.set_ai_explorer_active(false)

	# Show a dialogue message about the discovery
	if dialogue_manager:
		var message = "ALERT: AI Explorer has discovered a highly habitable world. Planet " + planet.planet_name + " shows exceptional conditions for life (" + str(int(planet.habitability_score * 100)) + "% habitability rating). Autonomous exploration paused for review."
		dialogue_manager.show_ai_message(message, "excited")

func _on_camera_panned():
	pass

func _on_camera_state_changed(is_tracking: bool, is_moved: bool):
	if ui_manager:
		ui_manager.update_camera_state(is_tracking, is_moved)

func _on_time_scale_changed(new_scale: float):
	_log_info("_on_time_scale_changed: new_scale=%.1f", [new_scale])

	# At 16x or higher, keep camera on star. Below 16x, track selected planet.
	if not camera_manager:
		_log_warn("_on_time_scale_changed: camera_manager is null")
		return

	var info_panel = ui_manager.get_current_info_panel() if ui_manager else null
	if not info_panel or not info_panel.controller:
		_log_debug("_on_time_scale_changed: no info panel or controller")
		return

	var controller = info_panel.controller
	if not controller.current_planet:
		_log_debug("_on_time_scale_changed: no current planet")
		return

	# Find the actual planet node
	var planet: Planet = null
	if star_system:
		for child in star_system.get_children():
			if child is Planet and child.planet_name == controller.current_planet.name:
				planet = child
				break

	if not planet:
		_log_warn("_on_time_scale_changed: planet not found")
		return

	# Update camera tracking based on time scale
	if new_scale >= 16.0:
		# At 16x+, track the star instead of the planet
		_log_info("_on_time_scale_changed: tracking star at 16x+")
		camera_manager.track_object(star_system)
	else:
		# Below 16x, track the planet normally
		_log_info("_on_time_scale_changed: tracking planet at <16x")
		camera_manager.track_object(planet)

func show_system_generation_message():
	if not dialogue_manager or not star_system:
		return

	if current_world_scenario == WorldScenarioManager.SCENARIO_OPOSSUM_SECTOR:
		_show_opossum_sector_message()
	else:
		var hab_summary = star_system.get_habitability_summary()
		var message = "New star system generated. Initiating full spectrum analysis..."
		if hab_summary.has_zone and hab_summary.potentially_habitable_count > 0:
			message += " Potential habitability detected in " + str(hab_summary.potentially_habitable_count) + " planetary bodies."
		elif hab_summary.has_zone:
			message += " Habitable zone confirmed but no suitable planetary candidates detected."
		else:
			message += " System conditions appear challenging for life development."
		dialogue_manager.show_ai_message(message, "friendly")

func _show_opossum_sector_message():
	opossum_systems_visited += 1

	var message := ""
	var personality := "concerned"

	if opossum_systems_visited == 1:
		# TODO: Clay writes first-contact opossum discovery message here
		message = "[PLACEHOLDER] Bioscan complete. Life signs confirmed. Species: Didelphis marsupialis. An opossum colony. On a terraformed world."
		personality = "surprised"
	elif opossum_systems_visited < OPOSSUM_BOSS_TRIGGER:
		# TODO: Clay writes repeat opossum encounter message here
		var lines := [
			"[PLACEHOLDER] Another one. Terraformed. Opossums.",
			"[PLACEHOLDER] Habitability index: exceptional. Colonizers: opossums. Again.",
			"[PLACEHOLDER] Bioscan nominal. Fauna catalog: opossums, opossums, opossums.",
		]
		message = lines[(opossum_systems_visited - 2) % lines.size()]
	elif opossum_systems_visited == OPOSSUM_BOSS_TRIGGER:
		# TODO: Clay writes Opossum God signal detection message here
		message = "[PLACEHOLDER] Anomalous signal detected. Narrow-band, directed. Origin appears to be deliberate. Someone is coordinating this."
		personality = "alarmed"
	else:
		# TODO: Clay writes post-threshold opossum messages here
		message = "[PLACEHOLDER] Signal strength increasing. We are being observed."

	dialogue_manager.show_ai_message(message, personality)

func _on_new_system_requested():
	star_index += 1
	if star_index >= sector_size:
		_advance_sector()
	generate_star_system(_next_star_seed())

func _on_options_requested():
	_show_options_menu()

func _on_history_system_selected(seed_value: int):
	_log_info("Selected system from history with seed: {0}", [seed_value])
	generate_star_system(seed_value)

func _on_toggle_orbits_requested(value: bool):
	show_orbits = value
	update_orbit_visibility()
	emit_signal("show_orbits_changed", show_orbits)

	if ui_manager.options_menu and is_instance_valid(ui_manager.options_menu):
		ui_manager.options_menu.orbits_button.button_pressed = show_orbits

func update_orbit_visibility():
	if not is_system_valid():
		return
	star_system.set_orbit_visibility(show_orbits)

func _show_celestial_info():
	var info_panel = ui_manager.show_celestial_info()
	if probe_system and info_panel and info_panel.controller:
		info_panel.controller.set_probe_system(probe_system)
	if info_panel and info_panel.controller and info_panel.controller.has_signal("view_changed"):
		info_panel.controller.view_changed.connect(_on_info_panel_view_changed)

func _on_info_panel_view_changed(_view_type):
	var info_panel = ui_manager.get_current_info_panel()
	if info_panel and info_panel.controller and info_panel.controller.current_view:
		TerminalTheme.apply_recursive(info_panel.controller.current_view)
		ui_manager.ensure_terminal_styling(info_panel.controller.current_view)
		if info_panel.controller.current_view is PlanetDetailView:
			var planet_detail_view = info_panel.controller.current_view
			if not planet_detail_view.open_planet_map.is_connected(_open_planet_map_scene):
				planet_detail_view.open_planet_map.connect(_open_planet_map_scene)
				_log_debug("Connected planet map signal for PlanetDetailView")

func _open_planet_map_scene(planet: Planet):
	_log_info("Opening planet map for: {0}", [planet.planet_name])
	if ui_manager:
		ui_manager.close_info_panel()
	var map_scene = PlanetMapView.new()
	map_scene.name = "PlanetMapScene"
	var scene_data = {
		"planet": planet,
		"probe_system": probe_system,
		"star_system_provider": func(): return star_system,
		"time_manager": time_manager,
		"dialogue_manager": dialogue_manager,
		"world_scenario": current_world_scenario,
	}
	scene_manager.push_scene(map_scene, SceneManager.SceneType.PLANET_MAP, scene_data)

func _on_object_clicked(object):
	if not is_instance_valid(object):
		_log_warn("Clicked on invalid object")
		return

	var info_panel = ui_manager.get_current_info_panel()
	if not info_panel:
		_show_celestial_info()
		info_panel = ui_manager.get_current_info_panel()

	if object is StarSystem:
		camera_manager.track_object(object)
		ui_manager.set_selected_celestial_body(object)
		if info_panel and info_panel.controller:
			var system_model = StarSystemModel.new(object.star_name, object.current_seed, object.get_star_type_name())
			system_model.planet_count = _count_planets(object)
			_apply_sector_to_model(system_model)
			info_panel.controller.show_solar_system(system_model)
	elif object is Planet:
		# At 16x speed or higher, keep camera on the star instead of following the planet
		if time_manager and time_manager.current_time_scale >= 16.0:
			var star_system = object.get_parent()
			if star_system:
				camera_manager.track_object(star_system)
		else:
			camera_manager.track_object(object)
		ui_manager.set_selected_celestial_body(object)
		if info_panel and info_panel.controller:
			var planet_model = PlanetModel.from_planet(object)
			info_panel.controller.show_planet_detail(planet_model)

func _on_stats_panel_clicked():
	var info_panel = ui_manager.get_current_info_panel()
	if not info_panel:
		_show_celestial_info()
		info_panel = ui_manager.get_current_info_panel()
	if info_panel and info_panel.controller:
		info_panel.controller.show_systems_list()

func _count_planets(system: StarSystem) -> int:
	var count = 0
	for child in system.get_children():
		if child is Planet:
			count += 1
	return count

func _on_stop_tracking_requested():
	if camera_manager:
		camera_manager.stop_tracking()

func _on_reset_camera_requested():
	if camera_manager:
		camera_manager.reset_camera()

func _on_celestial_body_selected(body: Node2D):
	if camera_manager and body and is_instance_valid(body):
		camera_manager.track_object(body)
	# Note: UI selection is already updated by CameraControlPanel._on_body_clicked

func _show_options_menu():
	if ui_manager:
		ui_manager.show_options_menu(show_orbits, current_seed, current_star_type)

func _on_seed_loaded(seed_value: int):
	generate_star_system(seed_value)

func _on_system_info_requested():
	if is_system_valid():
		camera_manager.reset_camera()
		_show_celestial_info()
		var info_panel = ui_manager.get_current_info_panel()
		if info_panel and info_panel.controller:
			var system_model = StarSystemModel.new(star_system.star_name, star_system.current_seed, star_system.get_star_type_name())
			system_model.planet_count = _count_planets(star_system)
			_apply_sector_to_model(system_model)
			info_panel.controller.show_solar_system(system_model)

func _on_history_requested():
	_show_celestial_info()
	var info_panel = ui_manager.get_current_info_panel()
	if info_panel and info_panel.controller:
		info_panel.controller.show_systems_list()

func _on_open_asset_test_requested():
	_log_info('Sandbox open requested')
	if ui_manager:
		ui_manager.show_asset_test(assets.sun_texture, assets.planet_texture)

func _on_dialogue_requested(_type: DialogueSystem.DialogueType, _data: DialogueData):
	pass

func _on_generation_loading_state_changed(is_loading: bool):
	if not ui_manager:
		return
	if is_loading:
		await ui_manager.show_loading()
	else:
		ui_manager.hide_loading()

func _on_generation_ui_state_save_requested():
	if ui_manager:
		ui_manager.save_ui_state()

func _on_generation_ui_state_restore_requested():
	pending_ui_restore = true
	_attempt_ui_restore()

func _attempt_ui_restore():
	if not pending_ui_restore:
		return
	if not ui_manager:
		return
	if not star_system or not is_instance_valid(star_system):
		return
	pending_ui_restore = false
	ui_manager.restore_ui_state()

func _on_generation_info_panel_close_requested():
	if ui_manager:
		ui_manager.close_info_panel()

func _on_generation_options_info_changed(seed_value: int, star_type: String):
	current_seed = seed_value
	current_star_type = star_type
	if ui_manager:
		ui_manager.update_options_seed_info(seed_value, star_type)
func _get_save_summary() -> Dictionary:
	if save_game_manager:
		return save_game_manager.get_save_summary()
	return {}
var _pending_thumbnail: Image = null

func _on_save_game_requested():
	if not ui_manager or not save_game_manager:
		_log_error("Save requested but manager unavailable")
		return
	# Capture thumbnail before showing dialog overlay
	_pending_thumbnail = save_game_manager.capture_thumbnail(get_viewport())
	ui_manager.show_save_list_dialog(SaveListDialog.Mode.SAVE)

func _on_save_to_slot(slot_id: String, _is_new: bool):
	if not save_game_manager:
		_log_error("Save to slot requested but SaveGameManager unavailable")
		return
	_save_planet_map_state()
	save_current_system_state()
	var save_meta := _build_scene_meta()
	var result = save_game_manager.save_to_slot(slot_id, save_meta, _pending_thumbnail)
	_pending_thumbnail = null
	if result.success:
		_log_info("Game saved to slot: {0}", [slot_id])
	else:
		_log_error("Game save failed: {0}", [result.message])
## Build save metadata with current scene context
func _build_scene_meta() -> Dictionary:
	var meta: Dictionary = {}
	if scene_manager and scene_manager.get_current_scene_type() == SceneManager.SceneType.PLANET_MAP:
		var scene_node = scene_manager.get_current_scene_node()
		if scene_node and scene_node is PlanetMapView and scene_node.current_planet and probe_system:
			var planet_stable_id := probe_system._get_stable_planet_id(scene_node.current_planet)
			meta["active_planet_id"] = planet_stable_id
			_log_info("Save meta: on planet map, planet_id={0}", [planet_stable_id])
	if time_manager:
		meta["game_time_elapsed"] = time_manager.game_time_elapsed
		meta["game_days_elapsed"] = time_manager.game_days_elapsed
		meta["simulation_tick_count"] = time_manager.simulation_tick_count
		meta["time_scale"] = time_manager.current_time_scale
	return meta


## Save planet map state (ecosystem + villages) if currently on planet map
func _save_planet_map_state() -> void:
	if not scene_manager:
		return
	if scene_manager.get_current_scene_type() != SceneManager.SceneType.PLANET_MAP:
		return
	var scene_node = scene_manager.get_current_scene_node()
	if scene_node and scene_node is PlanetMapView and scene_node.planet_map_system:
		scene_node.planet_map_system.save_ecosystem_state()
		scene_node.planet_map_system.save_village_state()


func _auto_save():
	_save_planet_map_state()
	save_current_system_state()
	if save_game_manager:
		var result = save_game_manager.save_game()
		if result.success:
			_log_info("Auto-saved game")
		else:
			_log_error("Auto-save failed: {0}", [result.message])

func save_current_system_state():
	if is_system_valid() and system_state_manager:
		system_state_manager.save_system_state(star_system, probe_system)
		_log_info("Manual system state save completed")

func get_system_state_summary(system_seed: int) -> Dictionary:
	if system_state_manager:
		return system_state_manager.get_system_state_summary(system_seed)
	return {}

func rename_planet(planet: Planet, new_name: String, old_name: String = "") -> bool:
	if not planet or not is_instance_valid(planet):
		_log_warn('Attempted to rename invalid planet reference')
		return false
	var sanitized = new_name.strip_edges()
	if sanitized == "":
		_log_warn('Ignoring empty planet name request')
		return false
	if probe_system and not probe_system.can_rename_planet(planet):
		_log_warn('Cannot rename planet {0}: send a probe first', [planet.planet_name])
		return false
	if old_name == "":
		old_name = planet.planet_name
	if sanitized == planet.planet_name:
		return true
	planet.planet_name = sanitized
	if planet.has_method("_update_name_label"):
		planet._update_name_label()
	if star_system and is_instance_valid(star_system):
		var planet_index = star_system.get_planet_index(planet)
		if system_state_manager and planet_index != -1:
			system_state_manager.rename_planet(star_system.current_seed, planet_index, old_name, sanitized)
	if probe_system:
		probe_system.rename_planet(planet, old_name, sanitized)
	if time_manager:
		time_manager.rename_planet(old_name, sanitized)
	_log_info('Renamed planet from {0} to {1}', [old_name, sanitized])
	return true

func has_visited_system(system_seed: int) -> bool:
	if system_state_manager:
		return system_state_manager.has_system_state(system_seed)
	return false


func _check_auto_sandbox():
	"""Check for --sandbox command-line flag and auto-open sandbox if present"""
	var args = OS.get_cmdline_user_args()
	for arg in args:
		if arg == "--sandbox" or arg == "-sandbox":
			_log_info("Auto-opening sandbox from command-line flag")
			# Wait one frame for UI to be ready
			await get_tree().process_frame
			_on_sandbox_requested()
			break


func _check_auto_minigame():
	"""Check for --minigame command-line flag and auto-open games tab"""
	var args = OS.get_cmdline_user_args()
	for arg in args:
		if arg == "--minigame" or arg == "-minigame":
			_log_info("Auto-opening minigame from command-line flag")
			await get_tree().process_frame
			_on_minigame_requested()
			break


func _on_minigame_requested():
	"""Open the sandbox directly to the Games tab"""
	if not transition_manager or not ui_manager:
		return
	var start_screen = ui_manager.start_screen if ui_manager else null
	if start_screen and is_instance_valid(start_screen):
		start_screen.set_process_input(false)
	await transition_manager.fade_to_black(0.3)
	ui_manager.hide_start_screen()
	var sandbox: SandboxApp = ui_manager.show_asset_test(null, null)
	if sandbox:
		sandbox.show_page_by_name("Games")
	await transition_manager.fade_from_black(0.3)


func _check_auto_planet():
	"""Check for --auto-planet command-line flag and jump to first planet"""
	var args = OS.get_cmdline_user_args()
	_log_info("Checking for auto-planet flag, args: %s" % str(args))
	for arg in args:
		if arg == "--auto-planet" or arg == "-auto-planet":
			_log_info("Auto-planet mode: skipping intro and jumping to first planet")

			# Wait for full initialization
			await get_tree().process_frame
			await get_tree().process_frame

			# Hide start screen and do transition
			if ui_manager and transition_manager:
				var start_screen = ui_manager.start_screen
				if start_screen and is_instance_valid(start_screen):
					start_screen.set_process_input(false)

				await transition_manager.fade_to_black(0.3)
				ui_manager.hide_start_screen()

			# Initialize game (skip intro sequence)
			_initialize_game(false)
			var game_seed = randi()
			_log_info("Generated seed for auto-planet: %d" % game_seed)

			# Connect to star_system_changed signal to continue after generation
			var system_ready_callback = func(_system, _seed, _type):
				_log_info("Signal callback! Continuing auto-planet setup...")
				_continue_auto_planet_setup()

			star_system_changed.connect(system_ready_callback)
			_log_info("Connected to star_system_changed signal")

			# Generate star system (signal will fire when ready)
			generate_star_system(game_seed)
			_log_info("Star system generation started, waiting for completion...")
			break


func _continue_auto_planet_setup():
	"""Continue auto-planet setup after star system is generated"""
	_log_info("[CONTINUE] Function started, star_system=%s" % [star_system != null])

	if not star_system:
		_log_error("Auto-planet failed: star_system is null!")
		return

	_log_info("[CONTINUE] Checking planets...")
	var planets_array = star_system.get_planets_array()
	_log_info("[CONTINUE] Got planets array, size=%d" % planets_array.size())

	if planets_array.is_empty():
		_log_error("Auto-planet failed: no planets in system")
		return

	_log_info("[CONTINUE] Planets check passed")
	_log_info("Star system ready: %s with %d planets" % [star_system.star_name, planets_array.size()])

	# Fade from black to show star system scene
	_log_info("Auto-planet: Starting fade from black...")
	if transition_manager:
		await transition_manager.fade_from_black(0.3)
		_log_info("Auto-planet: Fade complete")
	else:
		_log_warn("Auto-planet: No transition_manager!")

	# Wait for scene to be ready
	_log_info("Auto-planet: Waiting for scene to be ready...")
	await get_tree().create_timer(0.5).timeout

	# Get the first HABITABLE planet (for testing dynamic region loading)
	var planets = star_system.get_planets_array()
	var first_planet: Planet = null

	# Try to find a habitable planet first (habitability >= 0.7)
	for planet in planets:
		if planet.habitability_score >= 0.7:
			first_planet = planet
			_log_info("Selected habitable planet: %s (habitability: %.2f%%)" % [planet.planet_name, planet.habitability_score * 100.0])
			break

	# If no habitable planet, just use the first one
	if not first_planet:
		first_planet = planets[0]
		_log_info("No habitable planet found, using first planet: %s (habitability: %.2f%%)" % [first_planet.planet_name, first_planet.habitability_score * 100.0])

	# Launch a probe to the planet so it has data
	if probe_system:
		_log_info("Auto-planet: Launching probe...")
		probe_system.launch_probe(ProbeSystem.ProbeType.PRIMITIVE_ORBITAL, first_planet)
		_log_info("Auto-planet: Probe launched, waiting for arrival...")

		# Wait for probe to arrive and process results
		await probe_system.probe_arrived
		_log_info("Auto-planet: Probe arrived! Results ready")
	else:
		_log_warn("Auto-planet: No probe_system!")

	# Show planet detail view first (so agents can read data)
	_log_info("Auto-planet: Showing planet detail view...")
	if ui_manager:
		# Ensure celestial info panel is visible
		var info_panel = ui_manager.get_current_info_panel()
		if not info_panel:
			_show_celestial_info()
			info_panel = ui_manager.get_current_info_panel()

		# Show planet details
		if info_panel and info_panel.controller:
			var planet_model = PlanetModel.from_planet(first_planet)
			info_panel.controller.show_planet_detail(planet_model)
			_log_info("Auto-planet: Planet detail view displayed")

			# Wait a moment for data to be visible
			await get_tree().create_timer(1.0).timeout
		else:
			_log_warn("Auto-planet: No info_panel.controller")
	else:
		_log_warn("Auto-planet: No ui_manager!")

	# Open planet map
	_log_info("Auto-planet: Opening planet map...")
	_open_planet_map_scene(first_planet)
	_log_info("Auto-planet: Map opened for %s" % first_planet.planet_name)
