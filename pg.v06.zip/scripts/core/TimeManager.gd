class_name TimeManager
extends Node

const LOG_TAG := "TIME_MANAGER"

signal time_scale_changed(new_scale: float)
signal game_time_reset
signal simulation_tick(tick_number: int, game_days: float)

var current_time_scale: float = 1.0
var scaled_delta: float = 0.0
var game_time_elapsed: float = 0.0
var real_time_elapsed: float = 0.0
var total_orbits_completed: Dictionary = {}

# Simulation tick system
const SECONDS_PER_GAME_DAY := 60.0  # 1 minute real time = 1 game day at 1x speed
const TICKS_PER_DAY := 2            # 2 simulation updates per game day (30 sec/tick at 1x)
                                     # Tree lifecycle at 1x: 48 ticks × 30 sec = 1440 sec = 24 minutes (slow/realistic)
                                     # Tree lifecycle at 4x: 24 min / 4 = 6 minutes (watchable/testable)
var game_days_elapsed: float = 0.0
var simulation_tick_count: int = 0

const MIN_TIME_SCALE := 0.0
const MAX_TIME_SCALE := 64.0  # Higher for long-term testing

var _last_real_time_usec: int = 0

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))

func _ready():
	set_process(true)
	_last_real_time_usec = Time.get_ticks_usec()
	Engine.time_scale = current_time_scale
	_log_debug('Initialized time manager with scale %s', [current_time_scale])

func _process(delta: float):
	var now_usec = Time.get_ticks_usec()
	var real_delta := 0.0
	if _last_real_time_usec > 0:
		real_delta = float(now_usec - _last_real_time_usec) / 1_000_000.0
	_last_real_time_usec = now_usec

	real_time_elapsed += real_delta
	scaled_delta = delta
	game_time_elapsed += scaled_delta

	# Simulation tick system
	var old_days = game_days_elapsed
	game_days_elapsed = game_time_elapsed / SECONDS_PER_GAME_DAY
	var old_tick = int(old_days * TICKS_PER_DAY)
	var new_tick = int(game_days_elapsed * TICKS_PER_DAY)
	if new_tick > old_tick:
		simulation_tick_count = new_tick
		emit_signal("simulation_tick", simulation_tick_count, game_days_elapsed)

func set_time_scale(scale: float):
	var clamped_scale = clamp(scale, MIN_TIME_SCALE, MAX_TIME_SCALE)
	if is_equal_approx(clamped_scale, current_time_scale):
		return

	var old_scale = current_time_scale
	current_time_scale = clamped_scale
	Engine.time_scale = current_time_scale
	_log_info('Time scale changed from %sx to %sx', [old_scale, current_time_scale])
	emit_signal("time_scale_changed", current_time_scale)

func get_time_scale() -> float:
	return current_time_scale

func get_scaled_delta() -> float:
	return scaled_delta

func is_paused() -> bool:
	return is_equal_approx(current_time_scale, 0.0)

func get_formatted_game_time() -> String:
	var total_seconds: int = int(game_time_elapsed)
	@warning_ignore("integer_division")
	var hours: int = total_seconds / 3600
	@warning_ignore("integer_division")
	var minutes: int = (total_seconds % 3600) / 60
	var seconds: int = total_seconds % 60

	if hours > 0:
		return "%02d:%02d:%02d" % [hours, minutes, seconds]
	return "%02d:%02d" % [minutes, seconds]

func get_time_stats() -> Dictionary:
	return {
		"game_time": game_time_elapsed,
		"real_time": real_time_elapsed,
		"current_scale": current_time_scale,
		"is_paused": is_paused(),
		"game_days": game_days_elapsed,
		"simulation_tick": simulation_tick_count
	}

func reset_game_time():
	game_time_elapsed = 0.0
	real_time_elapsed = 0.0
	game_days_elapsed = 0.0
	simulation_tick_count = 0
	total_orbits_completed.clear()
	_last_real_time_usec = Time.get_ticks_usec()
	_log_info('Game time reset to zero')
	emit_signal("game_time_reset")

func register_orbit_completion(planet_name: String):
	if not total_orbits_completed.has(planet_name):
		total_orbits_completed[planet_name] = 0
	total_orbits_completed[planet_name] += 1

func rename_planet(old_name: String, new_name: String):
	if old_name == new_name:
		return
	if old_name == "" or new_name.strip_edges() == "":
		return
	if total_orbits_completed.has(old_name):
		var count = total_orbits_completed[old_name]
		total_orbits_completed.erase(old_name)
		total_orbits_completed[new_name] = count

func get_orbit_stats() -> Dictionary:
	return total_orbits_completed.duplicate()

func seconds_to_hours(seconds: float) -> float:
	return seconds / 3600.0

func hours_to_seconds(hours: float) -> float:
	return hours * 3600.0

func get_time_acceleration_description() -> String:
	if is_paused():
		return "Time is paused"
	elif current_time_scale < 1.0:
		return "Time is slowed to " + str(current_time_scale) + "x speed"
	elif is_equal_approx(current_time_scale, 1.0):
		return "Time is running at normal speed"
	return "Time is accelerated to " + str(current_time_scale) + "x speed"
