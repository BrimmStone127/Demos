﻿# GameLogger.gd
class_name GameLogger
extends RefCounted

enum Level {
	DEBUG,
	INFO,
	WARN,
	ERROR
}

var level: int = Level.INFO
var use_timestamp: bool = false
var _log_file: FileAccess = null
var _log_file_path: String = ""
var _file_logging_initialized: bool = false

func setup_file_logging():
	if _file_logging_initialized:
		return

	# Create log file in user data directory
	var user_dir = OS.get_user_data_dir()
	print("[GameLogger] User data directory: %s" % user_dir)

	var log_dir = user_dir + "/logs"
	var dir = DirAccess.open(user_dir)

	if dir:
		if not dir.dir_exists("logs"):
			var err = dir.make_dir("logs")
			if err != OK:
				print("[GameLogger] ERROR: Failed to create logs directory: %d" % err)
				return
			else:
				print("[GameLogger] Created logs directory")
	else:
		print("[GameLogger] ERROR: Cannot open user data directory")
		return

	var timestamp = Time.get_datetime_string_from_system().replace(":", "-").replace("T", "_")
	_log_file_path = log_dir + "/game_%s.log" % timestamp

	_log_file = FileAccess.open(_log_file_path, FileAccess.WRITE)
	if _log_file:
		_log_file.store_line("=== Game Log Started: %s ===" % Time.get_datetime_string_from_system())
		_log_file.flush()
		_file_logging_initialized = true
		print("[GameLogger] ✓ Logging to file: %s" % _log_file_path)
	else:
		var err = FileAccess.get_open_error()
		print("[GameLogger] ERROR: Failed to open log file: %d" % err)
		print("[GameLogger] Attempted path: %s" % _log_file_path)

func get_log_file_path() -> String:
	return _log_file_path

func set_level(new_level: int):
	level = clamp(new_level, Level.DEBUG, Level.ERROR)

func enable_timestamp(enabled: bool):
	use_timestamp = enabled

func debug(tag: String, message: String):
	write(Level.DEBUG, tag, message)

func info(tag: String, message: String):
	write(Level.INFO, tag, message)

func warn(tag: String, message: String):
	write(Level.WARN, tag, message)

func error(tag: String, message: String):
	write(Level.ERROR, tag, message)

func write(level_value: int, tag: String, message: String):
	if level_value < level:
		return
	var formatted := _format_message(level_value, tag, message)

	# Write to console FIRST (always works)
	match level_value:
		Level.WARN:
			push_warning(formatted)
		Level.ERROR:
			push_error(formatted)
		_:
			print(formatted)

	# Write to file (if available)
	if _log_file and _log_file.is_open():
		_log_file.store_line(formatted)
		_log_file.flush()  # Ensure it's written immediately

func _format_message(level_value: int, tag: String, message: String) -> String:
	var level_label := "LOG"
	match level_value:
		Level.DEBUG:
			level_label = "DEBUG"
		Level.INFO:
			level_label = "INFO"
		Level.WARN:
			level_label = "WARN"
		Level.ERROR:
			level_label = "ERROR"
	var timestamp := ""
	if use_timestamp:
		timestamp = "[%s] " % Time.get_datetime_string_from_system()
	return "%s[%s][%s] %s" % [timestamp, level_label, tag, message]
