﻿# GameAssets.gd
class_name GameAssets
extends RefCounted

var sun_texture: Texture2D
var planet_texture: Texture2D

func is_complete() -> bool:
	return sun_texture != null and planet_texture != null
