﻿# GameLog.gd
class_name GameLog
extends RefCounted

const DEFAULT_TAG := "GAME"
static var logger: GameLogger

static func set_logger(new_logger: GameLogger):
	logger = new_logger

static func debug(tag: String, message: String):
	if logger:
		logger.debug(tag, message)
	else:
		print("[DEBUG][%s] %s" % [tag, message])

static func info(tag: String, message: String):
	if logger:
		logger.info(tag, message)
	else:
		print("[INFO][%s] %s" % [tag, message])

static func warn(tag: String, message: String):
	if logger:
		logger.warn(tag, message)
	else:
		push_warning("[%s] %s" % [tag, message])

static func error(tag: String, message: String):
	if logger:
		logger.error(tag, message)
	else:
		push_error("[%s] %s" % [tag, message])

static func get_log_file_path() -> String:
	if logger and logger.has_method("get_log_file_path"):
		return logger.get_log_file_path()
	return ""
