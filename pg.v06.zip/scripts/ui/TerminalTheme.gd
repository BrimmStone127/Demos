class_name TerminalTheme
extends RefCounted

# Static class to provide terminal styling functions

# Terminal green color that will be used throughout the game
static var terminal_green: Color = Color(0.0, 0.8, 0.2)

# Cached terminal font instance
static var _cached_font: Font = null

# Get a monospace font configured for terminal style
static func get_terminal_font() -> Font:
	if _cached_font == null:
		var font = SystemFont.new()
		font.font_names = PackedStringArray(["Courier New", "Courier", "Liberation Mono", "Monospace"])
		_cached_font = font
	return _cached_font

# Create a panel style with terminal aesthetics
static func get_panel_style() -> StyleBoxFlat:
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.0, 0.0, 0.0, 1.0)  # Pure black, fully opaque
	style.border_color = terminal_green
	style.border_width_top = 1
	style.border_width_bottom = 1
	style.border_width_left = 1
	style.border_width_right = 1
	return style

# Create a button style with terminal aesthetics
static func get_button_style() -> StyleBoxFlat:
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.1, 0.1, 0.1, 0.9)
	style.border_color = terminal_green
	style.border_width_top = 1
	style.border_width_bottom = 1
	style.border_width_left = 1
	style.border_width_right = 1
	return style

# Create a button hover style
static func get_button_hover_style() -> StyleBoxFlat:
	var style = get_button_style()
	style.bg_color = Color(0.15, 0.15, 0.15, 0.9)
	return style

# Create a button pressed style
static func get_button_pressed_style() -> StyleBoxFlat:
	var style = get_button_style()
	style.bg_color = Color(0.05, 0.2, 0.05, 0.9)
	return style

# Create a line edit style with terminal aesthetics
static func get_line_edit_style() -> StyleBoxFlat:
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.0, 0.0, 0.0, 0.9)
	style.border_color = terminal_green
	style.border_width_top = 1
	style.border_width_bottom = 1
	style.border_width_left = 1
	style.border_width_right = 1
	return style

# Apply terminal styling to a label
static func apply_to_label(label: Label) -> void:
	label.add_theme_font_override("font", get_terminal_font())
	label.add_theme_color_override("font_color", terminal_green)

# Apply terminal styling to a button
static func apply_to_button(button: Button) -> void:
	button.add_theme_font_override("font", get_terminal_font())
	button.add_theme_color_override("font_color", terminal_green)
	button.add_theme_stylebox_override("normal", get_button_style())
	button.add_theme_stylebox_override("hover", get_button_hover_style())
	button.add_theme_stylebox_override("pressed", get_button_pressed_style())

# Apply terminal styling to a line edit
static func apply_to_line_edit(line_edit: LineEdit) -> void:
	line_edit.add_theme_font_override("font", get_terminal_font())
	line_edit.add_theme_color_override("font_color", terminal_green)
	line_edit.add_theme_stylebox_override("normal", get_line_edit_style())

# Apply terminal styling to a panel
static func apply_to_panel(panel: Control) -> void:
	panel.add_theme_stylebox_override("panel", get_panel_style())

# Recursively apply style to a node and all its children
static func apply_recursive(node: Node) -> void:
	# Apply styling based on node type
	if node is Panel or node is PanelContainer:
		apply_to_panel(node)
	
	if node is Label:
		apply_to_label(node)
	
	if node is Button:
		apply_to_button(node)
	
	if node is LineEdit:
		apply_to_line_edit(node)
	
	# Process all children recursively
	for child in node.get_children():
		apply_recursive(child)
