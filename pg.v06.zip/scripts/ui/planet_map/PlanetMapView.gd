class_name PlanetMapView
extends Control

## Planet mapping interface that displays detailed surface features
## REFACTORED: Now delegates to specialized components for UI, info panels, input, and day/night
## This class orchestrates components and maintains backward compatibility

const LOG_TAG := "PLANET_MAP_VIEW"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))

# Type aliases for backward compatibility
const TileType = PlanetMapTileConfig.TileType
const MAP_SIZE = PlanetMapTileConfig.MAP_SIZE
const TILE_SIZE = PlanetMapTileConfig.TILE_SIZE
const TILE_OFFSET = PlanetMapTileConfig.TILE_OFFSET
const ENABLE_PICK_DEBUG = PlanetMapTileConfig.ENABLE_PICK_DEBUG
const ENABLE_VISUAL_DEBUG = PlanetMapTileConfig.ENABLE_VISUAL_DEBUG
const MAX_LAYERS = PlanetMapTileConfig.NUM_RENDER_LAYERS  # Use NUM_RENDER_LAYERS for rendering precision
const LAYER_HEIGHT_OFFSET = PlanetMapTileConfig.LAYER_HEIGHT_OFFSET
const LAYER_DARKENING_MIN = PlanetMapTileConfig.LAYER_DARKENING_MIN
const LAYER_DARKENING_MAX = PlanetMapTileConfig.LAYER_DARKENING_MAX
const TILEMAP_LAYER_TERRAIN = PlanetMapTileConfig.TILEMAP_LAYER_TERRAIN
const TILEMAP_LAYER_SURFACE_FEATURES = PlanetMapTileConfig.TILEMAP_LAYER_SURFACE_FEATURES
const TILESET_TEXTURE = PlanetMapTileConfig.TILESET_TEXTURE
const TILESET_SOURCE_TILE_SIZE = PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
const TILESET_GRID_SIZE = PlanetMapTileConfig.TILESET_GRID_SIZE
const TILESET_REGION_INSET = PlanetMapTileConfig.TILESET_REGION_INSET
const SURFACE_FEATURE_LAYER_OFFSET_Y = PlanetMapTileConfig.SURFACE_FEATURE_LAYER_OFFSET_Y
const TILESET_REGION_MAP = PlanetMapTileConfig.TILESET_REGION_MAP
const CAMERA_KEYBOARD_SPEED = PlanetMapTileConfig.CAMERA_KEYBOARD_SPEED
const CAMERA_ZOOM_MIN = PlanetMapTileConfig.CAMERA_ZOOM_MIN
const CAMERA_ZOOM_MAX = PlanetMapTileConfig.CAMERA_ZOOM_MAX
const CAMERA_ZOOM_STEP = PlanetMapTileConfig.CAMERA_ZOOM_STEP
const CAMERA_ZOOM_STEP_ACCEL = PlanetMapTileConfig.CAMERA_ZOOM_STEP_ACCEL
const CAMERA_KEYBOARD_ZOOM_RATE = PlanetMapTileConfig.CAMERA_KEYBOARD_ZOOM_RATE

signal return_to_detail_view()
signal tile_discovered(tile_data: Dictionary)
signal options_requested()

# === COMPONENTS (NEW) ===
var _ui_builder: PlanetMapUIBuilder = null
var _info_panels: PlanetMapInfoPanels = null
var _input_handler: PlanetMapInputHandler = null
var _day_night: PlanetMapDayNight = null
var _search_dialog: TileSearchDialog = null
var _debug_hud: PlanetMapDebugHUD = null
var _debug_overlay: PlanetMapDebugOverlay = null
var _map_popup: MapInfoPopup = null
var _loading_overlay: PlanetMapLoadingOverlay = null
var _tracked_villager = null  # VillagerSystem.VillagerData
var _mouse_over_map: bool = false

# === CORE SYSTEM ===
var planet_map_system: PlanetMapSystem = null

# === UI ELEMENT REFERENCES (from ui_builder) ===
var viewport_container: SubViewportContainer = null
var map_viewport: SubViewport = null
var map_container: Node2D = null
var map_background: ColorRect = null
var day_night_modulate: CanvasModulate = null
var back_button: Button = null
var _day_label: Label = null
var _planet_name_label: Label = null
var _system_name_label: Label = null
var _tile_info_section_new: VBoxContainer = null
var _time_control_panel: TimeControlPanel = null

# === GAME REFERENCES ===
var current_planet: Planet = null
var probe_system: ProbeSystem = null
var foundation: Foundation = null
var ui_manager: UIManager = null
var scene_manager_ref: SceneManager = null
var star_system_provider: Callable = Callable()
var planet_id: String = ""
var time_manager: TimeManager = null

# === TOOLS ===
var _laser_button: Button = null
var _compiler_beam_button: Button = null
var _resources_section: VBoxContainer = null
var _map_stats_panel: StatsPanel = null
var _laser_effect: Line2D = null
var _village_panel: VillageInfoPanel = null
var _village_panel_refresh_timer: float = 0.0
const VILLAGE_PANEL_REFRESH_INTERVAL := 0.5
var _village_list: VillageListPanel = null
var _village_list_refresh_timer: float = 0.0
var _territory_overlay: VillageTerritoryOverlay = null
var _trail_renderer: VillageTrailRenderer = null
var _dialogue_manager: DialogueManager = null
var _map_loaded: bool = false
var _intro_dialogue_fired: bool = false

# === LEGACY COMPATIBILITY (keep for backward compatibility) ===
var info_panel: HBoxContainer = null  # Deprecated but kept for compatibility
var tile_info_section: VBoxContainer = null  # Legacy reference
var selection_highlight: Polygon2D = null
var overlay_layer: Node2D = null
var feature_layer: Node2D = null
var surface_feature_layer: TileMap = null
var surface_feature_layer_tilemaps: Array[TileMap] = []
var tile_texture_cache: Dictionary = {}
var placeholder_texture_cache: Dictionary = {}
var tile_map_tileset: TileSet = null
var tile_map_source_id: int = -1
var debug_overlay: Node2D = null
var tile_map: TileMap = null
var layer_tilemaps: Array[TileMap] = []
var map_content: Node2D = null
var map_generated: bool = false

# Legacy accessors for backward compatibility
var map_tiles: Array:
	get: return planet_map_system.map_tiles if planet_map_system else []
var selected_tile: MapTile:
	get: return planet_map_system.get_selected_tile() if planet_map_system else null

# === STATIC HELPER FUNCTIONS (backward compatibility) ===

static func is_surface_feature(tile_type: PlanetMapTileConfig.TileType) -> bool:
	return tile_type >= TileType.SF_GRASS and tile_type <= TileType.SF_LONG_HOUSE

func _round_vec2(value: Vector2) -> Vector2:
	return PlanetMapCoordinates.round_vec2(value)

static func grid_to_world(cell: Vector2i) -> Vector2:
	return PlanetMapCoordinates.grid_to_world(cell)

# === INITIALIZATION ===

func _ready():
	_log_info('PlanetMapView _ready() called')

	# Create UI using builder FIRST (creates map_container)
	_setup_ui()

	# Create planet map system (needs map_container)
	_setup_planet_map_system()

	# Create info panels component (no ecosystem section — replaced by action buttons)
	_info_panels = PlanetMapInfoPanels.new()
	_info_panels.initialize(null, _tile_info_section_new, _ui_builder, _resources_section)

	# Create input handler component
	_input_handler = PlanetMapInputHandler.new()
	_input_handler.initialize(map_viewport, planet_map_system, layer_tilemaps)
	_input_handler.tile_selected.connect(_on_tile_selected_by_input_handler)
	_input_handler.laser_fired.connect(_on_laser_fired)
	_input_handler.compiler_beam_fired.connect(_on_compiler_beam_fired)
	_input_handler.map_left_clicked.connect(_on_map_left_clicked)

	# Wire laser button
	if _laser_button:
		_laser_button.toggled.connect(_on_laser_toggled)

	# Wire compiler beam button
	if _compiler_beam_button:
		_compiler_beam_button.toggled.connect(_on_compiler_beam_toggled)

	# Wire harvester manager visuals (planet_id is set later in setup_planet_view)
	if planet_map_system and planet_map_system.harvester_manager:
		planet_map_system.harvester_manager.map_container = map_container

	# Wire villager system visuals
	if planet_map_system and planet_map_system.villager_system:
		planet_map_system.villager_system.map_container = map_container

	# Create map info popup
	_map_popup = MapInfoPopup.new()
	_map_popup.map_viewport = map_viewport
	_map_popup.viewport_container = viewport_container
	_map_popup.closed.connect(_on_map_popup_closed)
	add_child(_map_popup)

	# Create day/night component
	_day_night = PlanetMapDayNight.new()
	_day_night.initialize(day_night_modulate, _day_label, current_planet, time_manager)

	# Create village info panel
	_village_panel = VillageInfoPanel.new()
	add_child(_village_panel)

	# Create search dialog
	_search_dialog = TileSearchDialog.new()
	add_child(_search_dialog)
	_search_dialog.tile_search_requested.connect(_on_tile_search_requested)

	# Create debug components (hidden by default, toggle with F3)
	_setup_debug_components()

	# Loading overlay — added last so it draws on top of everything (z_index 500)
	_loading_overlay = PlanetMapLoadingOverlay.new()
	_loading_overlay.loading_complete.connect(_on_loading_complete)
	add_child(_loading_overlay)

	_log_info('PlanetMapView ready - components initialized')

func _setup_ui():
	_log_info('Setting up UI via PlanetMapUIBuilder...')

	# Create UI builder and build interface
	_ui_builder = PlanetMapUIBuilder.new()
	_ui_builder.back_button_pressed.connect(_on_back_pressed)
	_ui_builder.focus_village_pressed.connect(_on_focus_village_pressed)
	_ui_builder.toggle_trees_pressed.connect(_on_toggle_trees)
	_ui_builder.toggle_heatmap_pressed.connect(_on_toggle_heatmap)

	var ui_refs = _ui_builder.build_ui(self)

	# Extract UI references
	viewport_container = ui_refs["viewport_container"]
	map_viewport = ui_refs["map_viewport"]
	map_container = ui_refs["map_container"]
	if viewport_container:
		viewport_container.mouse_entered.connect(func(): _mouse_over_map = true)
		viewport_container.mouse_exited.connect(func(): _mouse_over_map = false; _reset_cursor())
	map_background = ui_refs["map_background"]
	day_night_modulate = ui_refs["day_night_modulate"]
	back_button = ui_refs["back_button"]
	_day_label = ui_refs["day_label"]
	_planet_name_label = ui_refs["planet_name_label"]
	_system_name_label = ui_refs["system_name_label"]
	_tile_info_section_new = ui_refs["tile_info_section"]
	_time_control_panel = ui_refs["time_control_panel"]
	_resources_section = ui_refs["resources_section"]
	_map_stats_panel = ui_refs["map_stats_panel"]
	_laser_button = ui_refs["laser_button"]
	_compiler_beam_button = ui_refs["compiler_beam_button"]

	# Connect viewport signals
	if viewport_container.has_signal("resized"):
		viewport_container.resized.connect(_on_viewport_container_resized)
	if viewport_container.has_signal("gui_input"):
		viewport_container.gui_input.connect(_on_viewport_gui_input)

	# Connect time control panel
	if _time_control_panel:
		_time_control_panel.time_scale_changed.connect(_on_planet_view_time_scale_changed)
		_time_control_panel.day_night_toggled.connect(_on_day_night_toggled)

	# Connect day refresh timer (find it in children)
	for child in get_children():
		if child is Timer:
			child.timeout.connect(_refresh_day_label)
			break

	# Initial update
	call_deferred('_update_subviewport_size')

	_log_info('UI setup complete via PlanetMapUIBuilder')

func _setup_planet_map_system():
	planet_map_system = PlanetMapSystem.new()
	planet_map_system.name = "PlanetMapSystem"
	if map_container and is_instance_valid(map_container):
		map_container.add_child(planet_map_system)
	else:
		add_child(planet_map_system)

	# CRITICAL: Pass viewport reference so selection_manager can pick tiles
	planet_map_system.map_viewport = map_viewport

	# Connect signals
	planet_map_system.tile_selected.connect(_on_tile_selected_by_system)
	planet_map_system.map_generated.connect(_on_map_generated_by_system)
	planet_map_system.map_loading_progress.connect(_on_map_loading_progress)

	# Cache layer tilemaps for input handler (legacy compatibility)
	if planet_map_system.tile_manager:
		for i in range(MAX_LAYERS):
			var tm = planet_map_system.tile_manager.ensure_layer_tilemap(i)
			if tm:
				if i >= layer_tilemaps.size():
					layer_tilemaps.resize(i + 1)
				layer_tilemaps[i] = tm

func _setup_debug_components() -> void:
	if not planet_map_system or not planet_map_system.tile_manager:
		_log_warn("Cannot create debug components: planet_map_system or tile_manager missing")
		return

	# Screen-space HUD (child of PlanetMapView)
	_debug_hud = PlanetMapDebugHUD.new()
	_debug_hud.name = "DebugHUD"
	add_child(_debug_hud)
	_debug_hud.initialize(planet_map_system, map_viewport)

	# World-space overlay (child of tile_manager so it shares the same local coordinate space)
	_debug_overlay = PlanetMapDebugOverlay.new()
	_debug_overlay.name = "DebugOverlay"
	_debug_overlay.z_index = 3600  # Above territory (3500) but under Godot max (4096)
	_debug_overlay.z_as_relative = false
	_debug_overlay.planet_map_system = planet_map_system
	_debug_overlay.map_viewport = map_viewport
	planet_map_system.tile_manager.add_child(_debug_overlay)
	_debug_overlay.visible = false

	# Always-visible trail renderer — child of map_container (same as villager sprites)
	# to guarantee coordinate alignment. Uses VillagerSystem._get_resource_container_pos()
	# for the exact same grid→container conversion as villager movement.
	_trail_renderer = VillageTrailRenderer.new()
	_trail_renderer.name = "TrailRenderer"
	_trail_renderer.planet_map_system = planet_map_system
	map_container.add_child(_trail_renderer)

	# Territory overlay (child of tile_manager for world-space rendering)
	_territory_overlay = VillageTerritoryOverlay.new()
	_territory_overlay.name = "TerritoryOverlay"
	_territory_overlay.planet_map_system = planet_map_system
	_territory_overlay.map_viewport = map_viewport
	planet_map_system.tile_manager.add_child(_territory_overlay)
	_territory_overlay.visible = false

	# Village list panel (screen-space, child of PlanetMapView)
	_village_list = VillageListPanel.new()
	_village_list.name = "VillageListPanel"
	add_child(_village_list)
	_village_list.village_selected.connect(_on_village_list_selected)
	_village_list.village_focused.connect(_on_village_list_focused)

	_log_info("Debug components created (F3 debug, F4 villages, F5 territory)")

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F3:
			_toggle_debug_view()
			get_viewport().set_input_as_handled()
		elif event.keycode == KEY_F4:
			_toggle_village_list()
			get_viewport().set_input_as_handled()
		elif event.keycode == KEY_F5:
			_toggle_territory_overlay()
			get_viewport().set_input_as_handled()

func _toggle_debug_view() -> void:
	var active := not (_debug_hud != null and _debug_hud.visible)
	if _debug_hud:
		_debug_hud.visible = active
	if _debug_overlay:
		_debug_overlay.visible = active
	_log_info("Debug view: %s" % ("ON" if active else "OFF"))


func _toggle_village_list() -> void:
	if not _village_list:
		return
	_village_list.visible = not _village_list.visible
	if _village_list.visible:
		_refresh_village_list()
	_log_info("Village list: %s" % ("ON" if _village_list.visible else "OFF"))


func _toggle_territory_overlay() -> void:
	if _territory_overlay:
		_territory_overlay.visible = not _territory_overlay.visible
		_log_info("Territory overlay: %s" % ("ON" if _territory_overlay.visible else "OFF"))


func _on_village_list_focused(village_id: String) -> void:
	if not planet_map_system or not planet_map_system.village_manager:
		return
	var village: VillageInstance = planet_map_system.village_manager.get_village(village_id)
	if not village or village.camp_position == Vector2i(-1, -1):
		return
	# Pan camera to village camp
	if planet_map_system.tile_manager and planet_map_system.camera_controller:
		var layer := 0
		if planet_map_system.chunk_manager and planet_map_system.chunk_manager.terrain_source:
			var elev: float = planet_map_system.chunk_manager.terrain_source.get_elevation_at_tile(village.camp_position)
			layer = PlanetMapTileConfig.get_render_layer(elev)
		var tilemap = planet_map_system.tile_manager.ensure_layer_tilemap(layer)
		if tilemap:
			var local_pos: Vector2 = tilemap.map_to_local(village.camp_position) + tilemap.position
			var target_pos: Vector2 = planet_map_system.tile_manager.to_global(local_pos)
			planet_map_system.camera_controller.move_to_position(target_pos, 0.6, Vector2.ZERO)


func _on_village_list_selected(village_id: String) -> void:
	if not planet_map_system or not planet_map_system.village_manager:
		return
	var village: VillageInstance = planet_map_system.village_manager.get_village(village_id)
	if village and _village_panel:
		_tracked_villager = null
		_on_village_list_focused(village_id)
		_village_panel.show_for_village(village, planet_map_system.villager_system)


func _refresh_village_list() -> void:
	if not _village_list or not _village_list.visible:
		return
	if not planet_map_system or not planet_map_system.village_manager:
		return
	var pid: String = planet_map_system.planet_id if planet_map_system else ""
	var villages: Array = planet_map_system.village_manager.get_villages_on_planet(pid)
	var collapsed: Array[VillageInstance] = planet_map_system.village_manager.get_collapsed_villages()
	var current_year := int(time_manager.game_days_elapsed / 365.0) if time_manager else 0
	_village_list.refresh(villages, current_year, collapsed)


# === PROCESS & UPDATE LOOPS ===

func _process(delta: float):
	# Update day/night lighting every frame for smooth transitions
	if _day_night and current_planet:
		_day_night.update_day_night_lighting(delta)

	# Update cursor when hovering over the map
	if _mouse_over_map and planet_map_system and planet_map_system.villager_system and map_viewport:
		var canvas_tf := map_viewport.get_canvas_transform()
		var vp_mouse := map_viewport.get_mouse_position()
		var container_pos := canvas_tf.affine_inverse() * vp_mouse
		if planet_map_system.villager_system.has_clickable_at(container_pos):
			Input.set_default_cursor_shape(Input.CURSOR_POINTING_HAND)
		else:
			_reset_cursor()

	# Follow tracked villager with camera
	if _tracked_villager and planet_map_system and planet_map_system.camera_controller:
		var vs := planet_map_system.villager_system
		if vs and is_instance_valid(_tracked_villager.node):
			# Convert container_pos to global world position for the camera
			var world_pos := map_container.to_global(_tracked_villager.container_pos)
			planet_map_system.camera_controller.set_position_direct(world_pos)

	# Refresh village panel at fixed interval while open
	if _village_panel and _village_panel.visible:
		_village_panel_refresh_timer += delta
		if _village_panel_refresh_timer >= VILLAGE_PANEL_REFRESH_INTERVAL:
			_village_panel_refresh_timer = 0.0
			_village_panel.refresh()

	# Refresh village list at same interval
	if _village_list and _village_list.visible:
		_village_list_refresh_timer += delta
		if _village_list_refresh_timer >= VILLAGE_PANEL_REFRESH_INTERVAL:
			_village_list_refresh_timer = 0.0
			_refresh_village_list()

	# Sync chunks with camera position (Minecraft-style chunking)
	if planet_map_system and planet_map_system.ecosystem_manager and planet_id:
		var camera = planet_map_system.camera_manager.camera if planet_map_system.camera_manager else null
		if camera:
			planet_map_system.ecosystem_manager.sync_chunks_with_camera(planet_id, camera)

# === PUBLIC API (backward compatible) ===

func set_dialogue_manager(dm: DialogueManager) -> void:
	_dialogue_manager = dm
	_connect_village_messages()
	# Intro message is handled by _on_loading_complete (after overlay fades).
	# Only fire here if loading already fully completed before DM arrived.
	if _map_loaded and (not _loading_overlay or not _loading_overlay.visible):
		if not _intro_dialogue_fired:
			_intro_dialogue_fired = true
			await get_tree().create_timer(0.5).timeout
			_dialogue_manager.show_ai_message("Hello, world.", "friendly")


## Connect VillageManager signals to show in-world messages via the dialogue system.
func _connect_village_messages() -> void:
	if not _dialogue_manager or not planet_map_system or not planet_map_system.village_manager:
		return
	var bm := planet_map_system.village_manager
	if not bm.person_born.is_connected(_on_village_person_born):
		bm.person_born.connect(_on_village_person_born)
	if not bm.person_died.is_connected(_on_village_person_died):
		bm.person_died.connect(_on_village_person_died)
	if not bm.village_era_changed.is_connected(_on_village_era_changed):
		bm.village_era_changed.connect(_on_village_era_changed)
	if not bm.village_collapsed.is_connected(_on_village_collapsed):
		bm.village_collapsed.connect(_on_village_collapsed)


func _on_village_person_born(_village_id: String, _person_name: String) -> void:
	pass


func _on_village_person_died(_village_id: String, _person_name: String) -> void:
	pass


func _on_village_era_changed(_village_id: String, _old_era: String, _new_era: String) -> void:
	pass


func _on_village_collapsed(_village_id: String) -> void:
	pass


var _world_scenario: String = ""

func set_world_scenario(scenario: String) -> void:
	_world_scenario = scenario

func configure_dependencies(p_ui_manager: UIManager, p_scene_manager: SceneManager, star_provider: Callable):
	ui_manager = p_ui_manager
	scene_manager_ref = p_scene_manager
	star_system_provider = star_provider if star_provider and star_provider.is_valid() else Callable()

func setup_planet_view(planet: Planet, probe_sys: ProbeSystem, p_ui_manager: UIManager = null, star_provider: Callable = Callable(), p_time_manager: TimeManager = null):
	_log_info('setup_planet_view called with planet: %s', [planet.planet_name if planet else "NULL"])
	current_planet = planet
	probe_system = probe_sys
	planet_id = ""

	# Reset per-session state
	_intro_dialogue_fired = false

	# Show loading overlay immediately — hides the incremental tile/sprite render
	if _loading_overlay:
		_loading_overlay.show_loading(planet.planet_name if planet else "")

	# Restore rotation state from saved data if available
	if current_planet and probe_system:
		var revealed_data = probe_system.get_revealed_data(current_planet)
		if revealed_data.has("rotation_angle"):
			current_planet.rotation_angle = revealed_data.get("rotation_angle", 0.0)
			_log_info("Restored rotation_angle: %.2f", [current_planet.rotation_angle])
		if revealed_data.has("rotation_period"):
			current_planet.rotation_period = revealed_data.get("rotation_period", 1.0)
			current_planet._calculate_rotation_speed()
			_log_info("Restored rotation_period: %.2f", [current_planet.rotation_period])

	if p_ui_manager:
		ui_manager = p_ui_manager
	if ui_manager and ui_manager.foundation:
		_setup_map_foundation(ui_manager.foundation)
	if star_provider and star_provider.is_valid():
		star_system_provider = star_provider
	if p_time_manager:
		time_manager = p_time_manager
		_log_info("setup_planet_view: time_manager passed directly as parameter")

	# Update header labels now that planet and system data is available
	_update_header_labels()

	# Ensure viewport is properly sized before map generation
	_update_subviewport_size()

	if is_node_ready() and planet_map_system:
		_log_info('Node is ready, setting up planet map system')
		# Clear any existing map when switching planets
		planet_map_system.clear_map()
		_clear_tileset_cache()
		planet_map_system.setup_planet(planet, probe_sys, planet_id)
		planet_map_system.world_scenario = _world_scenario
		planet_map_system.generate_map()

		# Dynamic region loading disabled for now (needs incremental update optimization)
		# TODO: Re-enable with proper incremental rendering to avoid full rebuilds
		var hab_score = planet.habitability_score if planet else 0.0
		if hab_score >= 0.7:
			_log_info('Habitable planet detected (%.2f) - dynamic loading available but disabled', [hab_score])

		# For chunk (habitable) planets the camera is already positioned at the random
		# start tile inside generate_map(). Only override for small non-chunk maps.
		if not planet_map_system.using_chunks:
			if planet_map_system.camera_controller and planet_map_system.camera_controller.camera:
				var map_size = planet_map_system.map_data.map_size if planet_map_system.map_data else Vector2i(64, 64)
				var center_tile = Vector2i(map_size.x >> 1, map_size.y >> 1)
				var center_tilemap = planet_map_system.tile_manager.ensure_layer_tilemap(0)
				if center_tilemap:
					var local_pos = center_tilemap.map_to_local(center_tile)
					var target = planet_map_system.tile_manager.to_global(local_pos)
					planet_map_system.camera_controller.camera.global_position = target
					_log_info('Positioned camera at center tile %s (global: %s, map size: %s)', [center_tile, target, map_size])

		# Update day/night component with new planet
		if _day_night:
			_day_night.set_current_planet(current_planet)

		# Connect time manager to ecosystem if available
		var tm = time_manager if time_manager else _get_time_manager()
		if tm:
			time_manager = tm  # Cache for later use
			_log_info("setup_planet_view: time_manager found and cached")
			planet_map_system.connect_time_manager(tm)

			# Update day/night component with time manager
			if _day_night:
				_day_night.set_time_manager(tm)

			if _time_control_panel:
				_time_control_panel.set_time_manager(tm)
				_log_info("setup_planet_view: TimeControlPanel.set_time_manager() called")
				# Direct connection ensures time scale changes work
				if not _time_control_panel.time_scale_changed.is_connected(tm.set_time_scale):
					_time_control_panel.time_scale_changed.connect(tm.set_time_scale)
					_log_info("setup_planet_view: Connected time_scale_changed -> tm.set_time_scale")
			else:
				_log_warn("setup_planet_view: _time_control_panel is NULL!")
		else:
			_log_error("setup_planet_view: FAILED to get time_manager - time controls will not work!")

		# Connect simulation_tick
		if tm and not tm.simulation_tick.is_connected(_on_simulation_tick):
			tm.simulation_tick.connect(_on_simulation_tick)

		# Connect village manager messages (also called from set_dialogue_manager if DM arrives first)
		_connect_village_messages()
	else:
		_log_info('Node not ready yet, deferring setup')

# === SIGNAL HANDLERS ===

func _on_tile_selected_by_system(tile: MapTile):
	if _info_panels:
		_info_panels.refresh_tile_panel(tile, planet_map_system)

func _on_tile_selected_by_input_handler(_tile: MapTile):
	# Input handler already called planet_map_system.select_tile()
	# System will emit tile_selected signal which calls _on_tile_selected_by_system
	pass

func _on_map_generated_by_system():
	_log_info("Map generated by planet_map_system")
	_update_subviewport_size()  # Ensure viewport is correct size after map generation
	_refresh_resources_panel()
	_map_loaded = true

	# Update search dialog with map size
	if _search_dialog and planet_map_system and planet_map_system.map_data:
		_search_dialog.set_map_size(planet_map_system.map_data.map_size)

	# Refresh tilemap cache and reconnect input handler (needed after dynamic region updates)
	_log_info("Checking input handler refresh: pms=%s, tm=%s, ih=%s", [planet_map_system != null, planet_map_system.tile_manager if planet_map_system else null, _input_handler != null])
	if planet_map_system and planet_map_system.tile_manager and _input_handler:
		layer_tilemaps.clear()
		for i in range(MAX_LAYERS):
			var tm = planet_map_system.tile_manager.ensure_layer_tilemap(i)
			if tm:
				if i >= layer_tilemaps.size():
					layer_tilemaps.resize(i + 1)
				layer_tilemaps[i] = tm
		# Reinitialize input handler with updated tilemap references
		_input_handler.initialize(map_viewport, planet_map_system, layer_tilemaps)
		_log_info("Input handler refreshed with %d tilemaps", [layer_tilemaps.size()])
	else:
		_log_warn("Cannot refresh input handler - missing components")

	# Wait for rendering to stabilize, then reveal map via loading overlay
	_wait_for_map_ready()


## Waits a short settle window after map_generated, then triggers the overlay reveal.
## For chunk planets: map_generated fires after visible chunks are loaded so minimal wait needed.
## For non-chunk planets: waits until the deferred sprite queue is drained.
func _wait_for_map_ready() -> void:
	if not _loading_overlay:
		# No overlay — legacy/test path
		if _dialogue_manager:
			await get_tree().create_timer(1.0).timeout
			_dialogue_manager.show_ai_message("Hello, world.", "friendly")
		return

	# Short settle: let Godot finish processing the final batch of render commands
	const SETTLE_FRAMES := 8
	const MAX_EXTRA_FRAMES := 60  # cap for non-chunk sprite queue drain
	var waited := 0

	while waited < MAX_EXTRA_FRAMES:
		await get_tree().process_frame
		waited += 1
		var queue_empty := true
		if planet_map_system and not planet_map_system.using_chunks:
			queue_empty = planet_map_system._pending_sprite_updates.is_empty()
		if waited >= SETTLE_FRAMES and queue_empty:
			break

	_log_info("Map settle complete after %d frames" % waited)
	_loading_overlay.begin_reveal()


## Relay chunk-loading progress to the overlay bar.
func _on_map_loading_progress(progress: float, status: String) -> void:
	if _loading_overlay and _loading_overlay.visible:
		_loading_overlay.set_progress(progress)
		_loading_overlay.set_status(status)


## Called when the loading overlay has fully faded out — map is now visible and stable.
func _on_loading_complete() -> void:
	_log_info("Loading overlay complete — map ready")
	if _dialogue_manager and not _intro_dialogue_fired:
		_intro_dialogue_fired = true
		_dialogue_manager.show_ai_message("Hello, world.", "friendly")

func _on_viewport_container_resized():
	_update_subviewport_size()

func _on_viewport_gui_input(event: InputEvent):
	# Only log clicks, not every input event
	if event is InputEventMouseButton and event.pressed:
		_log_info("Mouse click received at viewport: %s, handler=%s", [event.position, _input_handler != null])

	if _input_handler:
		var handled = _input_handler.handle_viewport_input(event, is_visible_in_tree())
		if handled:
			# Only log button presses, not releases or motion
			if event is InputEventMouseButton and event.pressed:
				_log_info("Input handled by input handler")
			if event.has_method("set_handled"):
				event.set_handled(true)
			get_viewport().set_input_as_handled()
		else:
			if event is InputEventMouseButton and event.pressed:
				_log_warn("Input handler did NOT handle click")
	else:
		if event is InputEventMouseButton and event.pressed:
			_log_warn("No input handler available!")

func _on_simulation_tick(_tick_number: int, _game_days: float):
	if _village_panel and _village_panel.visible:
		_village_panel.refresh()

func _on_planet_view_time_scale_changed(scale: float):
	if _day_night:
		_day_night.on_time_scale_changed(scale)

func _on_day_night_toggled(p_enabled: bool):
	if _day_night:
		_day_night.set_enabled(p_enabled)

func _on_map_left_clicked(viewport_point: Vector2) -> void:
	if not planet_map_system or not map_container or not map_viewport:
		return

	# Convert viewport point to map_container local space for hit-testing
	var canvas_tf := map_viewport.get_canvas_transform()
	var container_pos := canvas_tf.affine_inverse() * viewport_point

	# 1. Check for villager hit
	var vs := planet_map_system.villager_system
	if vs:
		var v = vs.get_villager_at_pos(container_pos)
		if v != null:
			_tracked_villager = v
			var person_name: String = v.person.name if v.person and v.person.name != "" else "Villager"
			_map_popup.show_tracking(
				func() -> Vector2: return v.container_pos,
				person_name,
				func() -> String: return vs.get_villager_body_text(v)
			)
			return

	# 2. Check for village camp (longhouse) — use sprite-space hit test so clicks on the
	#    tall sprite register, not just clicks on the ground tile underneath.
	if vs and planet_map_system.village_manager:
		var village_id := vs.get_camp_village_id_at_pos(container_pos)
		if village_id != "":
			var village: VillageInstance = planet_map_system.village_manager.get_village(village_id)
			if village and _village_panel:
				_tracked_villager = null
				_village_panel.show_for_village(village, planet_map_system.villager_system)


func _reset_cursor() -> void:
	Input.set_default_cursor_shape(Input.CURSOR_ARROW)


func _viewport_point_to_screen(viewport_point: Vector2) -> Vector2:
	var vp_size := Vector2(map_viewport.size)
	var container_rect := viewport_container.get_global_rect()
	return container_rect.position + viewport_point / vp_size * container_rect.size


func _village_popup_title(village: VillageInstance) -> String:
	return "Your Camp" if village.is_player_village else "Camp"


func _village_popup_body(village: VillageInstance) -> String:
	var firewood_pct := int(village.firewood_stored * 100)
	var food_pct := int(village.food_stored * 100)
	var fire_status := "dying" if village.firewood_stored < 0.10 else ("low" if village.firewood_stored < 0.30 else "burning")
	return "%s\nEra: %s\nPop: %d  Adults: %d\nAvg Age: %.0f  Health: %.0f%%\nFire: %s (%d%%)  Food stored: %d%%" % [
		village.village_id,
		village.era.replace("_", " ").capitalize(),
		village.get_population(),
		village.get_adult_count(),
		village.get_average_age(),
		village.get_average_health() * 100.0,
		fire_status, firewood_pct, food_pct,
	]


func _on_map_popup_closed() -> void:
	_tracked_villager = null
	_reset_cursor()


func _on_tile_search_requested(tile_pos: Vector2i):
	_log_info("Search requested for tile %s" % tile_pos)

	if not planet_map_system or not planet_map_system.camera_controller or not planet_map_system.selection_manager:
		return

	if not planet_map_system.tile_manager:
		_log_warn("tile_manager not initialized")
		return

	var target_pos: Vector2

	var tile = planet_map_system.get_tile_at(tile_pos)
	if tile:
		# Non-chunk mode: tile object exists, use selection manager for accurate position
		var local_pos = planet_map_system.selection_manager.calculate_tile_visual_center(tile)
		target_pos = planet_map_system.tile_manager.to_global(local_pos)
	elif planet_map_system.using_chunks:
		# Chunk mode: map_data tiles not populated — navigate via tilemap directly.
		# Look up actual elevation so the camera targets the visible tile surface,
		# not sea level (layer 0 is always at y=0; elevated tiles are offset upward).
		var layer := 0
		if planet_map_system.chunk_manager and planet_map_system.chunk_manager.terrain_source:
			var elev: float = planet_map_system.chunk_manager.terrain_source.get_elevation_at_tile(tile_pos)
			layer = PlanetMapTileConfig.get_render_layer(elev)
		var tilemap = planet_map_system.tile_manager.ensure_layer_tilemap(layer)
		if not tilemap:
			_log_warn("No tilemap available for chunk mode navigation")
			return
		var local_pos = tilemap.map_to_local(tile_pos) + tilemap.position
		target_pos = planet_map_system.tile_manager.to_global(local_pos)
	else:
		_log_warn("No tile found at %s" % tile_pos)
		return

	_log_info("Moving camera to tile %s, target=%s" % [tile_pos, target_pos])
	planet_map_system.camera_controller.move_to_position(target_pos, 0.6, Vector2.ZERO)

	# Select the tile after camera arrives
	await get_tree().create_timer(0.65).timeout
	planet_map_system.select_tile(tile)

func _open_search_dialog():
	if not _search_dialog:
		_log_warn("Search dialog not initialized")
		return

	# Update map size before showing
	if planet_map_system and planet_map_system.map_data:
		_search_dialog.set_map_size(planet_map_system.map_data.map_size)

	_log_info("Opening tile search dialog")
	_search_dialog.show_dialog()

func _on_focus_village_pressed() -> void:
	if not planet_map_system or not planet_map_system.village_manager:
		return
	var village: VillageInstance = planet_map_system.village_manager.get_player_village(planet_map_system.planet_id)
	if not village or village.camp_position == Vector2i(-1, -1):
		return

	# Move camera to camp tile
	if planet_map_system.tile_manager and planet_map_system.camera_controller:
		var layer := 0
		if planet_map_system.chunk_manager and planet_map_system.chunk_manager.terrain_source:
			var elev: float = planet_map_system.chunk_manager.terrain_source.get_elevation_at_tile(village.camp_position)
			layer = PlanetMapTileConfig.get_render_layer(elev)
		var tilemap = planet_map_system.tile_manager.ensure_layer_tilemap(layer)
		if tilemap:
			var local_pos: Vector2 = tilemap.map_to_local(village.camp_position) + tilemap.position
			var target_pos: Vector2 = planet_map_system.tile_manager.to_global(local_pos)
			planet_map_system.camera_controller.move_to_position(target_pos, 0.6, Vector2.ZERO)

	# Show village info panel
	if _village_panel:
		_village_panel.show_for_village(village, planet_map_system.villager_system if planet_map_system else null)

func _on_toggle_trees(show: bool) -> void:
	if not planet_map_system or not planet_map_system.chunk_manager:
		return
	planet_map_system.chunk_manager.set_trees_visible(show)

func _on_toggle_heatmap(enabled: bool) -> void:
	if not planet_map_system or not planet_map_system.chunk_manager:
		return
	planet_map_system.chunk_manager.set_heatmap_mode(enabled)

func _show_options_menu() -> void:
	if not ui_manager:
		_log_warn("Cannot show options menu: no ui_manager")
		return
	if ui_manager.is_options_open:
		return
	# Save planet state before showing menu (so save button captures current state)
	if planet_map_system:
		planet_map_system.save_ecosystem_state()
		planet_map_system.save_village_state()
	var menu = ui_manager.show_options_menu(false, 0, "")
	if menu:
		_log_info("Options menu opened from planet map")


func _on_back_pressed():
	_log_info('Back button pressed - returning to system view')

	# CRITICAL BUG FIX: Unpause the game before transitioning to prevent freeze
	var tm = _get_time_manager()
	if tm and tm.is_paused():
		_log_info("Game is paused - unpausing before transition to prevent freeze")
		tm.set_time_scale(1.0)

	# Save ecosystem and village state before returning
	if planet_map_system:
		planet_map_system.save_ecosystem_state()
		planet_map_system.save_village_state()

	# Save rotation state
	if current_planet and probe_system:
		var planet_data = probe_system.get_revealed_data(current_planet)
		if planet_data:
			planet_data["rotation_angle"] = current_planet.rotation_angle
			planet_data["rotation_period"] = current_planet.rotation_period
			_log_info("Saved rotation state: angle=%.2f period=%.2f", [
				current_planet.rotation_angle,
				current_planet.rotation_period
			])

	emit_signal("return_to_detail_view")

# === LASER TOOL ===

func _on_laser_toggled(pressed: bool):
	if _input_handler:
		_input_handler.laser_active = pressed
		if pressed:
			_input_handler.compiler_beam_active = false
			if _compiler_beam_button:
				_compiler_beam_button.set_pressed_no_signal(false)
				_compiler_beam_button.add_theme_color_override("font_color", Color(0.0, 0.85, 0.25))
	if _laser_button:
		var active_color = Color(1.0, 0.3, 0.1)
		var idle_color = Color(0.0, 0.85, 0.25)
		_laser_button.add_theme_color_override("font_color", active_color if pressed else idle_color)

func _on_laser_fired(tile: MapTile):
	if not planet_map_system:
		return

	# Check for tree at this tile (covers both static forest and simulation trees)
	if not planet_map_system.has_tree_at(tile.position):
		_play_laser_effect(tile, false)
		return

	# Destroy the tree
	planet_map_system.remove_tree_at(tile.position)

	# Award carbon
	if probe_system:
		probe_system.carbon += 10
		_refresh_resources_panel()

	_play_laser_effect(tile, true)

func _play_laser_effect(tile: MapTile, hit_tree: bool):
	if not planet_map_system or not planet_map_system.selection_manager or not planet_map_system.tile_manager:
		return

	# Get the tile's world position
	var local_pos = planet_map_system.selection_manager.calculate_tile_visual_center(tile)
	var world_pos = planet_map_system.tile_manager.to_global(local_pos)

	# Create a Line2D in the map_container (which uses the same coordinate space)
	var beam = Line2D.new()
	beam.width = 20.0
	beam.default_color = Color(1.0, 0.1, 0.0, 1.0) if hit_tree else Color(1.0, 0.5, 0.0, 0.5)
	beam.z_index = 4000

	# Convert world_pos to map_container local space
	var container_pos = map_container.to_local(world_pos)

	# Scale beam height by inverse camera zoom so it always extends off-screen.
	# At min zoom (0.0625), visible height ~= viewport_height / zoom.
	# Multiply by an extra factor to guarantee the top is never visible.
	var zoom_scale := 1.0
	if planet_map_system and planet_map_system.camera_controller and planet_map_system.camera_controller.camera:
		zoom_scale = 1.0 / planet_map_system.camera_controller.camera.zoom.y
	var beam_height := maxf(50000.0, map_viewport.size.y * zoom_scale * 10.0)

	beam.add_point(container_pos + Vector2(0, -beam_height))
	beam.add_point(container_pos)

	map_container.add_child(beam)

	# Fade and remove
	var tween = create_tween()
	tween.tween_property(beam, "modulate:a", 0.0, 0.25)
	tween.tween_callback(beam.queue_free)

# === COMPILER BEAM TOOL ===

func _on_compiler_beam_toggled(pressed: bool):
	if _input_handler:
		_input_handler.compiler_beam_active = pressed
		# Deactivate laser when compiler beam is enabled, and vice versa
		if pressed:
			_input_handler.laser_active = false
			if _laser_button:
				_laser_button.set_pressed_no_signal(false)
				_laser_button.add_theme_color_override("font_color", Color(0.0, 0.85, 0.25))
	if _compiler_beam_button:
		var active_color = Color(0.0, 0.6, 1.0)
		var idle_color = Color(0.0, 0.85, 0.25)
		_compiler_beam_button.add_theme_color_override("font_color", active_color if pressed else idle_color)

func _on_compiler_beam_fired(tile: MapTile):
	if not planet_map_system or not planet_map_system.harvester_manager:
		return

	# Only place on a tile with no tree
	if planet_map_system.has_tree_at(tile.position):
		_play_compiler_beam_effect(tile, false)
		return

	# Place the harvester — use planet_map_system.planet_id, not PlanetMapView.planet_id (always "")
	planet_map_system.harvester_manager.place_harvester(tile.position, planet_map_system.planet_id)
	_play_compiler_beam_effect(tile, true)

	# Deactivate compiler beam after placing (one-shot use)
	if _compiler_beam_button:
		_compiler_beam_button.set_pressed_no_signal(false)
		_compiler_beam_button.add_theme_color_override("font_color", Color(0.0, 0.85, 0.25))
	if _input_handler:
		_input_handler.compiler_beam_active = false

func _play_compiler_beam_effect(tile: MapTile, placed: bool):
	if not planet_map_system or not planet_map_system.selection_manager or not planet_map_system.tile_manager:
		return

	var local_pos = planet_map_system.selection_manager.calculate_tile_visual_center(tile)
	var world_pos = planet_map_system.tile_manager.to_global(local_pos)

	var beam = Line2D.new()
	beam.width = 20.0
	beam.default_color = Color(0.0, 0.5, 1.0, 1.0) if placed else Color(0.0, 0.3, 0.8, 0.4)
	beam.z_index = 4000

	var container_pos = map_container.to_local(world_pos)

	var zoom_scale := 1.0
	if planet_map_system.camera_controller and planet_map_system.camera_controller.camera:
		zoom_scale = 1.0 / planet_map_system.camera_controller.camera.zoom.y
	var beam_height := maxf(50000.0, map_viewport.size.y * zoom_scale * 10.0)

	beam.add_point(container_pos + Vector2(0, -beam_height))
	beam.add_point(container_pos)

	map_container.add_child(beam)

	var tween = create_tween()
	tween.tween_interval(1.2)
	tween.tween_property(beam, "modulate:a", 0.0, 0.6)
	tween.tween_callback(beam.queue_free)

# === UI UPDATE FUNCTIONS (delegate to components) ===

func _refresh_ecosystem_panel():
	if _info_panels:
		_info_panels.refresh_ecosystem_panel(planet_map_system, current_planet)

func _refresh_tile_panel(tile: MapTile):
	if _info_panels:
		_info_panels.refresh_tile_panel(tile, planet_map_system)

func _refresh_resources_panel():
	if _info_panels:
		_info_panels.refresh_resources_panel(probe_system)

func _refresh_day_label():
	if _day_night:
		_day_night.refresh_day_label()

func _update_header_labels():
	# Update planet name
	if _planet_name_label:
		if current_planet and current_planet.planet_name:
			_planet_name_label.text = current_planet.planet_name
		else:
			_planet_name_label.text = "Unknown Planet"

	# Update system name
	if _system_name_label:
		if star_system_provider and star_system_provider.is_valid():
			var star_system = star_system_provider.call()
			if star_system and "star_name" in star_system:
				_system_name_label.text = star_system.star_name
			else:
				_system_name_label.text = "Unknown System"
		else:
			_system_name_label.text = "Unknown System"

# === VIEWPORT SIZE MANAGEMENT ===

func _update_subviewport_size():
	if _ui_builder:
		_ui_builder.update_viewport_size(map_viewport, viewport_container)

# === TIME MANAGER ACCESS ===

func _get_time_manager() -> TimeManager:
	if time_manager:
		return time_manager
	if ui_manager and ui_manager.time_manager:
		time_manager = ui_manager.time_manager
		_log_info("_get_time_manager: found time_manager via ui_manager")
		return time_manager
	# Fallback: find the main node via group
	if get_tree():
		for node in get_tree().get_nodes_in_group("main"):
			if "time_manager" in node and node.time_manager is TimeManager:
				time_manager = node.time_manager
				_log_info("_get_time_manager: found time_manager via 'main' group fallback")
				return time_manager
	_log_error("_get_time_manager: FAILED to find time_manager via any path!")
	return null

# === LEGACY COMPATIBILITY SHIMS ===

func _clear_tileset_cache():
	tile_texture_cache.clear()
	placeholder_texture_cache.clear()
	tile_map_tileset = null
	tile_map_source_id = -1

func _create_card() -> Panel:
	if _ui_builder:
		return _ui_builder.create_card()
	var card = Panel.new()
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return card

func _make_panel_label(text: String, font_size: int = 11, color: Color = Color(0.0, 0.85, 0.25)) -> Label:
	if _ui_builder:
		return _ui_builder.make_panel_label(text, font_size, color)
	var label = Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	return label

func _get_tile_at(grid_pos: Vector2i) -> MapTile:
	if planet_map_system:
		return planet_map_system.get_tile_at(grid_pos)
	return null

func _apply_tile_selection(_tile: MapTile):
	pass

func _hide_selection_highlight():
	if selection_highlight and is_instance_valid(selection_highlight):
		selection_highlight.visible = false

func _hide_system_ui_fallback():
	pass

func _setup_camera_controller():
	pass

func _get_planet_camera() -> Camera2D:
	if planet_map_system and planet_map_system.camera_controller:
		return planet_map_system.camera_controller.camera
	return null

# === DEPRECATED FUNCTIONS (kept for backward compatibility) ===

func _make_tile_info_label(text: String, font_size: int = 11) -> Label:
	return _make_panel_label(text, font_size)

func _update_tile_info():
	if planet_map_system and planet_map_system.get_selected_tile():
		_refresh_tile_panel(planet_map_system.get_selected_tile())

func _update_info_panel():
	_refresh_ecosystem_panel()

func _get_tile_info_container() -> VBoxContainer:
	return _tile_info_section_new

func _update_selection_highlight():
	pass

func _ensure_map_content() -> Node2D:
	return map_content

func _ensure_tilemap_tileset():
	pass

func _ensure_tile_map() -> TileMap:
	return tile_map

func _ensure_layer_tilemap(_layer: int) -> TileMap:
	return null

func _ensure_surface_feature_layer_tilemap(_layer: int) -> TileMap:
	return null

func _ensure_surface_feature_layer() -> TileMap:
	return surface_feature_layer

func _ensure_overlay_layer() -> Node2D:
	return overlay_layer

func _ensure_feature_layer() -> Node2D:
	return feature_layer

func _ensure_selection_highlight(_target_parent: Node = null) -> Polygon2D:
	return selection_highlight

func _align_map_content_to_center():
	pass

func _cell_to_visual_position(cell: Vector2i) -> Vector2:
	var base := PlanetMapView.grid_to_world(cell)
	if tile_map and is_instance_valid(tile_map):
		base = tile_map.map_to_local(cell)
	return base

func _get_map_center_world_position() -> Vector2:
	return PlanetMapCoordinates.get_map_center_world_position(MAP_SIZE)

func _is_point_inside_tile_tilemap_space(point_local: Vector2, cell: Vector2i, tilemap: TileMap) -> bool:
	if _input_handler:
		return _input_handler._is_point_inside_tile_tilemap_space(point_local, cell, tilemap)
	return false

func _is_point_inside_tile(_point: Vector2, _cell: Vector2i) -> bool:
	return false

func _pick_tile_from_viewport_point(viewport_point: Vector2) -> Dictionary:
	if _input_handler:
		return _input_handler.pick_tile_from_viewport_point(viewport_point)
	return {"tile": null, "debug": {}}

func _select_tile_from_viewport_point(viewport_point: Vector2):
	if _input_handler:
		_input_handler.select_tile_from_viewport_point(viewport_point)

func _input(event: InputEvent):
	if event is InputEventKey and event.pressed and not event.is_echo():
		# ESC to open options menu
		if event.keycode == KEY_ESCAPE:
			_show_options_menu()
			get_viewport().set_input_as_handled()
			return
		# Ctrl+F to open tile search dialog
		if event.keycode == KEY_F and event.ctrl_pressed and not event.shift_pressed and not event.alt_pressed:
			_open_search_dialog()
			accept_event()

func _zoom_in(_accelerated: bool = false):
	pass

func _zoom_out(_accelerated: bool = false):
	pass

func _clamp_zoom(_zoom: Vector2) -> Vector2:
	return Vector2.ONE

# --- Foundation stats on planet map ---

func _setup_map_foundation(p_foundation: Foundation):
	foundation = p_foundation
	if not foundation or not _map_stats_panel:
		return
	_map_stats_panel.set_foundation(foundation)
	# Connect toast notifications for planet map
	if not foundation.credits_changed.is_connected(_on_map_credits_toast):
		foundation.credits_changed.connect(_on_map_credits_toast)
	if not foundation.rank_changed.is_connected(_on_map_rank_toast):
		foundation.rank_changed.connect(_on_map_rank_toast)
	# Add tool buttons for owned blueprints
	_sync_tool_buttons()
	# Listen for future purchases
	if not foundation.blueprint_unlocked.is_connected(_on_blueprint_unlocked):
		foundation.blueprint_unlocked.connect(_on_blueprint_unlocked)

func _sync_tool_buttons() -> void:
	if not foundation or not _ui_builder:
		return
	if foundation.has_blueprint("laser") and not _laser_button:
		_laser_button = _ui_builder.add_tool_button("laser")
		if _laser_button:
			_laser_button.toggled.connect(_on_laser_toggled)
	if foundation.has_blueprint("compiler_beam") and not _compiler_beam_button:
		_compiler_beam_button = _ui_builder.add_tool_button("compiler_beam")
		if _compiler_beam_button:
			_compiler_beam_button.toggled.connect(_on_compiler_beam_toggled)

func _on_blueprint_unlocked(blueprint_id: String) -> void:
	_sync_tool_buttons()
	if _map_stats_panel:
		var bp = Foundation.BLUEPRINTS.get(blueprint_id, {})
		var bp_name: String = bp.get("name", blueprint_id) if bp else blueprint_id
		_map_stats_panel.show_toast("Module online: %s" % bp_name, Color(0.0, 1.0, 0.3))

func _on_map_credits_toast(_balance: int, delta: int, reason: String = ""):
	if delta > 0 and _map_stats_panel:
		var msg := "+%d  %s" % [delta, reason] if reason != "" else "+%d credits" % delta
		_map_stats_panel.show_toast(msg, TerminalTheme.terminal_green)

func _on_map_rank_toast(new_rank: int, _old_rank: int):
	if _map_stats_panel:
		_map_stats_panel.show_toast("Rank up: %d" % new_rank, Color(0.9, 0.8, 0.2))
