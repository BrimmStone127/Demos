class_name VillageListPanel
extends Control

## Side panel listing all villages on the current planet with key stats.
## Toggle with F4. Clicking a village row emits village_selected.

signal village_selected(village_id: String)
signal village_focused(village_id: String)

var _content: VBoxContainer = null
var _header_label: Label = null


func _ready() -> void:
	_build_ui()
	visible = false


func _build_ui() -> void:
	# Right-anchored panel, 260px wide
	anchor_left = 1.0
	anchor_right = 1.0
	anchor_top = 0.0
	anchor_bottom = 1.0
	offset_left = -270
	offset_right = -10
	offset_top = 100
	offset_bottom = -100
	mouse_filter = Control.MOUSE_FILTER_STOP
	z_index = ZIndexLayers.UI_PANELS_ELEVATED

	var panel := Panel.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.02, 0.05, 0.02, 0.93)
	style.border_width_left = 1
	style.border_width_right = 1
	style.border_width_top = 1
	style.border_width_bottom = 1
	style.border_color = Color(0.0, 0.55, 0.15)
	panel.add_theme_stylebox_override("panel", style)
	panel.gui_input.connect(func(event: InputEvent) -> void:
		if event is InputEventMouseButton or event is InputEventMouseMotion:
			panel.accept_event()
	)
	add_child(panel)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 10)
	margin.add_theme_constant_override("margin_right", 10)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	panel.add_child(margin)

	var outer := VBoxContainer.new()
	outer.add_theme_constant_override("separation", 4)
	margin.add_child(outer)

	_header_label = _make_label("VILLAGES", 13, Color(0.0, 1.0, 0.3))
	outer.add_child(_header_label)
	outer.add_child(_make_separator(Color(0.0, 0.55, 0.15, 0.9)))

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	outer.add_child(scroll)

	_content = VBoxContainer.new()
	_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content.add_theme_constant_override("separation", 2)
	scroll.add_child(_content)


func refresh(villages: Array, current_year: int, collapsed: Array[VillageInstance] = []) -> void:
	for child in _content.get_children():
		_content.remove_child(child)
		child.free()

	var total := villages.size() + collapsed.size()
	if total == 0:
		_content.add_child(_make_label("No villages on this planet.", 10))
		_header_label.text = "VILLAGES (0)"
		return

	var total_pop := 0
	for village in villages:
		if village is VillageInstance:
			total_pop += village.get_population()
	_header_label.text = "VILLAGES (%d) - Pop: %d" % [total, total_pop]

	for village in villages:
		if village is VillageInstance:
			_content.add_child(_make_village_card(village, current_year))

	if not collapsed.is_empty():
		_content.add_child(_make_separator(Color(0.5, 0.15, 0.1, 0.8)))
		_content.add_child(_make_label("COLLAPSED", 10, Color(0.7, 0.25, 0.2)))
		for village in collapsed:
			_content.add_child(_make_collapsed_card(village))


func _make_village_card(village: VillageInstance, current_year: int) -> PanelContainer:
	var card := PanelContainer.new()
	var card_style := StyleBoxFlat.new()
	card_style.bg_color = Color(0.04, 0.08, 0.04, 0.8)
	card_style.border_width_bottom = 1
	card_style.border_color = Color(0.0, 0.35, 0.1, 0.5)
	card_style.content_margin_left = 6
	card_style.content_margin_right = 6
	card_style.content_margin_top = 4
	card_style.content_margin_bottom = 4
	card.add_theme_stylebox_override("panel", card_style)
	card.mouse_filter = Control.MOUSE_FILTER_STOP

	# Single click = pan camera, double click = open info panel
	var vid := village.village_id
	card.gui_input.connect(func(event: InputEvent) -> void:
		if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			if event.double_click:
				village_selected.emit(vid)
			else:
				village_focused.emit(vid)
			card.accept_event()
	)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 1)
	card.add_child(vbox)

	# Row 1: Village ID + population
	var row1 := HBoxContainer.new()
	row1.add_theme_constant_override("separation", 4)
	vbox.add_child(row1)

	var label_text := village.village_id
	if village.is_player_village:
		label_text = "* " + label_text
	var name_label := _make_label(label_text, 10, Color(1.0, 0.85, 0.4))
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.clip_text = true
	row1.add_child(name_label)

	var pop_label := _make_label("Pop: %d" % village.get_population(), 10)
	row1.add_child(pop_label)

	# Row 2: Longhouses + Era
	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 4)
	vbox.add_child(row2)

	var lh_count := village.longhouse_count()
	var lh_label := _make_label("LH: %d" % lh_count, 9, Color(0.6, 0.8, 0.6))
	lh_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row2.add_child(lh_label)

	var era_str := village.era.replace("_", " ").capitalize() if village.era != "" else "?"
	var era_label := _make_label(era_str, 9, Color(0.6, 0.8, 0.6))
	row2.add_child(era_label)

	# Row 3: Resources bar
	var row3 := HBoxContainer.new()
	row3.add_theme_constant_override("separation", 4)
	vbox.add_child(row3)

	row3.add_child(_make_label("F:%d%%" % int(village.food_stored * 100), 9, _resource_color(village.food_stored)))
	row3.add_child(_make_label("W:%d%%" % int(village.water_stored * 100), 9, _resource_color(village.water_stored)))
	row3.add_child(_make_label("Fw:%d%%" % int(village.firewood_stored * 100), 9, _resource_color(village.firewood_stored)))

	# Row 4: Site age + firewood pressure
	var row4 := HBoxContainer.new()
	row4.add_theme_constant_override("separation", 4)
	vbox.add_child(row4)

	var site_age := 0
	var fw_pressure := 0.0
	if village.active_site:
		site_age = current_year - village.active_site.established_year
		fw_pressure = village.active_site.get_average_firewood_distance()

	var age_label := _make_label("Site: %dy" % site_age, 9, Color(0.6, 0.8, 0.6))
	age_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row4.add_child(age_label)

	var pressure_color := Color(0.5, 0.85, 0.5)
	if fw_pressure > 30.0:
		pressure_color = Color(0.9, 0.7, 0.2)
	if fw_pressure > 40.0:
		pressure_color = Color(0.9, 0.2, 0.1)
	var pressure_label := _make_label("Fw dist: %.0f" % fw_pressure, 9, pressure_color)
	row4.add_child(pressure_label)

	return card


func _make_collapsed_card(village: VillageInstance) -> PanelContainer:
	var card := PanelContainer.new()
	var card_style := StyleBoxFlat.new()
	card_style.bg_color = Color(0.08, 0.03, 0.03, 0.8)
	card_style.border_width_bottom = 1
	card_style.border_color = Color(0.35, 0.1, 0.05, 0.5)
	card_style.content_margin_left = 6
	card_style.content_margin_right = 6
	card_style.content_margin_top = 4
	card_style.content_margin_bottom = 4
	card.add_theme_stylebox_override("panel", card_style)
	card.mouse_filter = Control.MOUSE_FILTER_STOP

	# Click opens info panel to view event log
	var vid := village.village_id
	card.gui_input.connect(func(event: InputEvent) -> void:
		if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			village_selected.emit(vid)
			card.accept_event()
	)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 1)
	card.add_child(vbox)

	var name_label := _make_label(village.village_id, 10, Color(0.7, 0.25, 0.2))
	name_label.clip_text = true
	vbox.add_child(name_label)

	var events_count := village.event_log.size()
	var detail := "Age: %dy | %d events" % [village.age_in_years, events_count]
	vbox.add_child(_make_label(detail, 9, Color(0.5, 0.35, 0.3)))

	return card


func _resource_color(level: float) -> Color:
	if level < 0.15:
		return Color(0.9, 0.2, 0.1)
	elif level < 0.35:
		return Color(0.9, 0.6, 0.1)
	return Color(0.35, 0.9, 0.3)


func _make_label(text: String, font_size: int = 11, color: Color = Color(0.0, 0.85, 0.25)) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label


func _make_separator(color: Color = Color(0.0, 0.4, 0.0, 0.6)) -> HSeparator:
	var sep := HSeparator.new()
	sep.add_theme_color_override("color", color)
	sep.add_theme_constant_override("separation", 4)
	return sep
