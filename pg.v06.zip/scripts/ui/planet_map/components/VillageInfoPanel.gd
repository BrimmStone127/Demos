class_name VillageInfoPanel
extends Control

## Modal overlay displaying village stats, villager roster, and event history.
## Call show_for_village(village, villager_system) to populate and show.
## 80% viewport width, centered, with two tabs: Info and Events.

signal closed()

const LOG_TAG := "VILLAGE_INFO_PANEL"

var _info_content: VBoxContainer = null
var _events_content: VBoxContainer = null
var _tab_container: TabContainer = null
var _village_ref: VillageInstance = null
var _villager_system: VillagerSystem = null

## Event type colors for the log display
const EVENT_COLORS := {
	"birth": Color(0.3, 0.9, 0.3),
	"death": Color(0.9, 0.25, 0.2),
	"era": Color(0.3, 0.85, 1.0),
	"split": Color(0.85, 0.6, 1.0),
	"founded": Color(0.85, 0.6, 1.0),
	"relocate": Color(0.9, 0.75, 0.2),
	"build": Color(0.6, 0.8, 0.4),
	"collapse": Color(1.0, 0.2, 0.1),
}


func _ready() -> void:
	_build_ui()
	visible = false


func _build_ui() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	z_index = ZIndexLayers.UI_PANELS_ELEVATED

	# Dark backdrop — clicks on backdrop close the panel
	var backdrop := ColorRect.new()
	backdrop.color = Color(0.0, 0.0, 0.0, 0.6)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	backdrop.mouse_filter = Control.MOUSE_FILTER_STOP
	backdrop.gui_input.connect(func(event: InputEvent) -> void:
		if event is InputEventMouseButton and event.pressed:
			_on_close()
			accept_event()
	)
	add_child(backdrop)

	# Main panel: 80% width, centered
	var panel := Panel.new()
	panel.anchor_left = 0.1
	panel.anchor_right = 0.9
	panel.anchor_top = 0.04
	panel.anchor_bottom = 0.96
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.02, 0.05, 0.02, 0.97)
	style.border_width_left = 1
	style.border_width_right = 1
	style.border_width_top = 1
	style.border_width_bottom = 1
	style.border_color = Color(0.0, 0.55, 0.15)
	panel.add_theme_stylebox_override("panel", style)
	panel.gui_input.connect(func(event: InputEvent) -> void:
		if event is InputEventMouseButton or event is InputEventMouseMotion:
			panel.accept_event()
	)
	add_child(panel)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 16)
	margin.add_theme_constant_override("margin_right", 16)
	margin.add_theme_constant_override("margin_top", 12)
	margin.add_theme_constant_override("margin_bottom", 12)
	panel.add_child(margin)

	var outer := VBoxContainer.new()
	outer.add_theme_constant_override("separation", 6)
	margin.add_child(outer)

	# Header row
	var header_row := HBoxContainer.new()
	outer.add_child(header_row)

	var title := _make_label("VILLAGE INFO", 15, Color(0.0, 1.0, 0.3))
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header_row.add_child(title)

	var close_btn := Button.new()
	close_btn.text = "[ CLOSE ]"
	TerminalTheme.apply_to_button(close_btn)
	close_btn.pressed.connect(_on_close)
	header_row.add_child(close_btn)

	outer.add_child(_make_separator(Color(0.0, 0.55, 0.15, 0.9)))

	# Tab container
	_tab_container = TabContainer.new()
	_tab_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_tab_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	# Style tabs to match terminal theme
	_tab_container.add_theme_color_override("font_selected_color", Color(0.0, 1.0, 0.3))
	_tab_container.add_theme_color_override("font_unselected_color", Color(0.0, 0.55, 0.15))
	var tab_panel_style := StyleBoxFlat.new()
	tab_panel_style.bg_color = Color(0.02, 0.05, 0.02, 0.0)
	_tab_container.add_theme_stylebox_override("panel", tab_panel_style)
	outer.add_child(_tab_container)

	# --- Info tab ---
	var info_scroll := ScrollContainer.new()
	info_scroll.name = "Info"
	info_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	info_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_tab_container.add_child(info_scroll)

	_info_content = VBoxContainer.new()
	_info_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_info_content.add_theme_constant_override("separation", 4)
	info_scroll.add_child(_info_content)

	# --- Events tab ---
	var events_scroll := ScrollContainer.new()
	events_scroll.name = "Events"
	events_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	events_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_tab_container.add_child(events_scroll)

	_events_content = VBoxContainer.new()
	_events_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_events_content.add_theme_constant_override("separation", 2)
	events_scroll.add_child(_events_content)


## Show and populate the panel for a given village.
func show_for_village(village: VillageInstance, villager_system: VillagerSystem = null) -> void:
	_village_ref = village
	_villager_system = villager_system
	_populate_info(village)
	_populate_events(village)
	visible = true


## Refresh content in-place (called on simulation tick while panel is visible).
func refresh() -> void:
	if visible and _village_ref:
		_populate_info(_village_ref)
		_populate_events(_village_ref)


func _populate_info(village: VillageInstance) -> void:
	for child in _info_content.get_children():
		child.queue_free()

	if not village:
		_info_content.add_child(_make_label("No village data.", 11))
		return

	# Build person_id -> VillagerData lookup from live system
	var vd_by_person_id: Dictionary = {}
	if _villager_system:
		for vd in _villager_system.get_villagers_for_village(village.village_id):
			var pid: String = vd.person.person_id if vd.person else ""
			if pid != "":
				vd_by_person_id[pid] = vd

	# --- Village header ---
	var village_label_text := "YOUR CAMP" if village.is_player_village else "NPC CAMP"
	_info_content.add_child(_make_label(village_label_text, 13, Color(1.0, 0.85, 0.4)))
	_info_content.add_child(_make_label(village.village_id, 11, Color(0.7, 0.6, 0.3)))
	_info_content.add_child(_make_label("Era: %s" % village.era.replace("_", " ").capitalize(), 11))

	_info_content.add_child(_make_separator())

	# --- Stored resources ---
	_info_content.add_child(_make_label("STORED RESOURCES", 12, Color(0.0, 1.0, 0.3)))
	_info_content.add_child(_make_label("Firewood : %d%%" % int(village.firewood_stored * 100), 11, _resource_color(village.firewood_stored)))
	_info_content.add_child(_make_label("Food     : %d%%" % int(village.food_stored * 100), 11, _resource_color(village.food_stored)))
	_info_content.add_child(_make_label("Water    : %d%%" % int(village.water_stored * 100), 11, _resource_color(village.water_stored)))

	_info_content.add_child(_make_separator())

	# --- Population stats ---
	_info_content.add_child(_make_label("POPULATION", 12, Color(0.0, 1.0, 0.3)))
	_info_content.add_child(_make_label("Total        : %d" % village.get_population(), 11))
	_info_content.add_child(_make_label("Adults (15+) : %d" % village.get_adult_count(), 11))
	_info_content.add_child(_make_label("Avg Age      : %.1f years" % village.get_average_age(), 11))
	_info_content.add_child(_make_label("Avg Health   : %d%%" % int(village.get_average_health() * 100.0), 11))
	_info_content.add_child(_make_label("Village Age  : %d years" % village.age_in_years, 11))

	# --- Group knowledge ---
	if village.group_knowledge.size() > 0:
		_info_content.add_child(_make_separator())
		_info_content.add_child(_make_label("GROUP KNOWLEDGE", 12, Color(0.0, 1.0, 0.3)))
		for skill_key in village.group_knowledge:
			_info_content.add_child(_make_label("  %s" % skill_key.replace("_", " ").capitalize(), 11))

	_info_content.add_child(_make_separator())

	# --- Villager roster or demographics ---
	if village.is_deflated and village.demographics:
		_populate_demographics(village)
	else:
		_info_content.add_child(_make_label("INDIVIDUALS  (%d)" % village.individuals.size(), 12, Color(0.0, 1.0, 0.3)))
		_info_content.add_child(_make_roster_header())

		var sorted := village.individuals.duplicate()
		sorted.sort_custom(func(a: PersonInstance, b: PersonInstance) -> bool: return a.age > b.age)

		for person in sorted:
			var vd = vd_by_person_id.get(person.person_id, null)
			_info_content.add_child(_make_person_row(person, vd))


func _populate_demographics(village: VillageInstance) -> void:
	var demo: VillageDemographics = village.demographics
	_info_content.add_child(_make_label("DEMOGRAPHICS", 12, Color(0.0, 1.0, 0.3)))
	_info_content.add_child(_make_label("  (individual data not available — village is distant)", 10, Color(0.5, 0.5, 0.5)))

	var dim := Color(0.0, 0.6, 0.18)
	_info_content.add_child(_make_label("Male     : %d" % demo.male_count, 11))
	_info_content.add_child(_make_label("Female   : %d" % demo.female_count, 11))

	_info_content.add_child(_make_separator())
	_info_content.add_child(_make_label("AGE DISTRIBUTION", 12, dim))
	_info_content.add_child(_make_label("  Children (0-14)  : %d" % demo.age_buckets[0], 11))
	_info_content.add_child(_make_label("  Adults   (15-44) : %d" % demo.age_buckets[1], 11))
	_info_content.add_child(_make_label("  Elders   (45+)   : %d" % demo.age_buckets[2], 11))

	if demo.pregnant_count > 0:
		_info_content.add_child(_make_label("  Pregnant         : %d" % demo.pregnant_count, 11, Color(0.9, 0.7, 0.9)))

	if not demo.avg_skills.is_empty():
		_info_content.add_child(_make_separator())
		_info_content.add_child(_make_label("AVERAGE SKILLS", 12, dim))
		for skill_key in demo.avg_skills:
			var level: float = demo.avg_skills[skill_key]
			_info_content.add_child(_make_label("  %s : %d" % [skill_key.replace("_", " ").capitalize(), int(level)], 11))


func _populate_events(village: VillageInstance) -> void:
	for child in _events_content.get_children():
		child.queue_free()

	if not village:
		_events_content.add_child(_make_label("No village data.", 11))
		return

	_events_content.add_child(_make_label("EVENT LOG", 12, Color(0.0, 1.0, 0.3)))
	_events_content.add_child(_make_separator())

	if village.event_log.is_empty():
		_events_content.add_child(_make_label("No events recorded yet.", 11, Color(0.5, 0.5, 0.5)))
		return

	# Show events in reverse chronological order (newest first)
	for i in range(village.event_log.size() - 1, -1, -1):
		var entry: Dictionary = village.event_log[i]
		var year: int = entry.get("year", 0)
		var type: String = entry.get("type", "")
		var text: String = entry.get("text", "")
		var color: Color = EVENT_COLORS.get(type, Color(0.6, 0.8, 0.6))

		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)

		# Year column
		var year_label := _make_label("Y%d" % year, 10, Color(0.4, 0.55, 0.4))
		year_label.custom_minimum_size.x = 48
		row.add_child(year_label)

		# Type tag
		var type_label := _make_label("[%s]" % type.to_upper(), 10, color)
		type_label.custom_minimum_size.x = 80
		row.add_child(type_label)

		# Event text
		var text_label := _make_label(text, 10, color)
		text_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(text_label)

		_events_content.add_child(row)


func _make_roster_header() -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var dim := Color(0.0, 0.6, 0.18)
	_col(row, "Name", 140, dim, 10)
	_col(row, "Age", 32, dim, 10)
	_col(row, "Sex", 28, dim, 10)
	_col(row, "Health", 52, dim, 10)
	_col(row, "Activity", 160, dim, 10)
	_col(row, "Hunger", 52, dim, 10)
	_col(row, "Thirst", 52, dim, 10)
	_col(row, "Rest", 0, dim, 10)
	return row


func _make_person_row(person: PersonInstance, vd: VillagerSystem.VillagerData) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)

	var name_color := Color(0.95, 0.85, 0.3) if person.is_hero else Color(0.65, 0.9, 0.65)
	var name_prefix := "* " if person.is_hero else "  "

	var health_pct := int(person.health * 100)
	var h_color := _health_color(health_pct)

	var sex_str := "M" if person.sex == PersonInstance.Sex.MALE else "F"

	# Activity from live VillagerData (or "--" if not yet spawned / asleep)
	var activity_str := "--"
	var hunger_str := "--"
	var thirst_str := "--"
	var rest_str := "--"
	if vd != null:
		activity_str = _villager_system.get_activity(vd)
		hunger_str = "%d%%" % int(vd.hunger * 100)
		thirst_str = "%d%%" % int(vd.thirst * 100)
		rest_str   = "%d%%" % int(vd.rest * 100)

	_col(row, name_prefix + person.name, 140, name_color, 11)
	_col(row, str(person.age), 32, Color(0.7, 0.7, 0.7), 11)
	_col(row, sex_str, 28, Color(0.7, 0.7, 0.7), 11)
	_col(row, "%d%%" % health_pct, 52, h_color, 11)
	_col(row, activity_str, 160, _activity_color(activity_str), 11)
	_col(row, hunger_str, 52, _need_color(vd.hunger if vd else 1.0), 11)
	_col(row, thirst_str, 52, _need_color(vd.thirst if vd else 1.0), 11)
	_col(row, rest_str, 0, _need_color(vd.rest if vd else 1.0), 11)
	return row


func _resource_color(level: float) -> Color:
	if level < 0.15:
		return Color(0.9, 0.2, 0.1)
	elif level < 0.35:
		return Color(0.9, 0.6, 0.1)
	return Color(0.35, 0.9, 0.3)


func _health_color(pct: int) -> Color:
	if pct > 70:
		return Color(0.3, 0.9, 0.3)
	elif pct > 40:
		return Color(0.9, 0.7, 0.2)
	return Color(0.9, 0.2, 0.2)


func _need_color(level: float) -> Color:
	# level is 0-1 where 1 = full/satisfied
	if level > 0.6:
		return Color(0.5, 0.85, 0.5)
	elif level > 0.3:
		return Color(0.9, 0.7, 0.2)
	return Color(0.9, 0.2, 0.1)


func _activity_color(activity: String) -> Color:
	if activity == "Sleeping":
		return Color(0.5, 0.5, 0.8)
	elif activity.begins_with("Gathering") or activity.begins_with("Returning"):
		return Color(0.4, 0.9, 0.6)
	elif activity.begins_with("Going"):
		return Color(0.7, 0.85, 0.5)
	elif activity == "Wandering":
		return Color(0.65, 0.65, 0.65)
	elif activity == "--":
		return Color(0.4, 0.4, 0.4)
	return Color(0.7, 0.85, 0.7)  # Idle / default


func _col(parent: HBoxContainer, text: String, min_width: int, color: Color, font_size: int = 10) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.clip_text = true
	if min_width > 0:
		label.custom_minimum_size.x = min_width
	else:
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(label)
	return label


func _make_label(text: String, font_size: int = 11, color: Color = Color(0.0, 0.85, 0.25)) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label


func _make_separator(color: Color = Color(0.0, 0.4, 0.0, 0.6)) -> HSeparator:
	var sep := HSeparator.new()
	sep.add_theme_color_override("color", color)
	sep.add_theme_constant_override("separation", 4)
	return sep


func _on_close() -> void:
	visible = false
	closed.emit()
