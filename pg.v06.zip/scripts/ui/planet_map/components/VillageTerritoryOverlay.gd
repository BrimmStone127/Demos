class_name VillageTerritoryOverlay
extends Node2D

## World-space overlay rendering village territory footprints.
## Shows colored diamonds on tiles that villagers have visited.
## Highlights known resource locations and villager positions.
## Must be child of tile_manager (same coordinate space as debug overlay).

const VILLAGE_COLORS := [
	Color(1.0, 0.2, 0.2, 0.18),   # red
	Color(1.0, 0.4, 0.2, 0.18),   # red-orange
	Color(0.9, 0.15, 0.15, 0.18), # darker red
	Color(1.0, 0.3, 0.1, 0.18),   # vermillion
	Color(0.8, 0.1, 0.1, 0.18),   # deep red
	Color(1.0, 0.25, 0.25, 0.18), # bright red
	Color(0.9, 0.2, 0.1, 0.18),   # scarlet
	Color(1.0, 0.35, 0.2, 0.18),  # red-orange
]

## Path overlay colors — bright yellow, drawn above territory diamonds
const F5_PATH_COLOR := Color(1.0, 1.0, 0.0, 0.8)         # bright yellow
const F5_PATH_COLOR_WORN := Color(1.0, 0.9, 0.2, 0.9)    # brighter yellow for worn paths
const F5_PATH_BASE_WIDTH := 2.5

## Resource marker colors (stronger alpha so they stand out)
const COLOR_CAMP     := Color(1.0, 1.0, 1.0, 0.9)
const COLOR_WATER    := Color(0.3, 0.5, 1.0, 0.8)
const COLOR_BERRY    := Color(0.9, 0.2, 0.4, 0.8)
const COLOR_FIREWOOD := Color(0.6, 0.4, 0.2, 0.8)
const COLOR_VILLAGER := Color(1.0, 0.5, 0.0, 0.7)

## Active target outline color — brighter to distinguish from known-but-not-targeted
const COLOR_ACTIVE_OUTLINE := Color(1.0, 1.0, 1.0, 0.9)

## Marker size relative to tile offset
const MARKER_SCALE := 0.5
const VILLAGER_MARKER_SCALE := 0.3

## Resource sprite icon size on overlay
const RESOURCE_ICON_SIZE := Vector2(32.0, 32.0)

var planet_map_system: PlanetMapSystem = null
var map_viewport: SubViewport = null

var _village_color_map: Dictionary = {}  # village_id -> Color
var _color_index: int = 0
var _berry_texture: Texture2D = null
var _firewood_texture: Texture2D = null
var _ref_tilemap: TileMap = null  # Cached reference tilemap for map_to_local


func _ready() -> void:
	z_index = 3500  # Above SURFACE_FEATURE_Z_INDEX (3200) but under Godot max (4096)
	z_as_relative = false
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_berry_texture = load("res://assets/berry_sprite.png")
	_firewood_texture = load("res://assets/firewood_sprite.png")


var _redraw_timer: float = 0.0
const REDRAW_INTERVAL := 0.25  # 4 redraws/sec max


func _process(delta: float) -> void:
	if not visible:
		return
	_redraw_timer += delta
	# Slow down redraws at zoomed-out view — territory changes slowly
	var camera := planet_map_system.get_camera() if planet_map_system else null
	var interval := REDRAW_INTERVAL
	if camera and is_instance_valid(camera) and camera.zoom.x < 0.1:
		interval = 0.5  # 2 Hz at extreme zoom
	elif camera and is_instance_valid(camera) and camera.zoom.x < 0.2:
		interval = 0.25  # 4 Hz at medium zoom
	if _redraw_timer >= interval:
		_redraw_timer = 0.0
		queue_redraw()


func _draw() -> void:
	if not planet_map_system or not planet_map_system.villager_system:
		return

	var camera := planet_map_system.get_camera()
	if not camera or not is_instance_valid(camera):
		return

	var zoom := camera.zoom
	if zoom.x <= 0.0:
		return

	var vs: VillagerSystem = planet_map_system.villager_system

	# Ensure reference tilemap for map_to_local coordinate conversion
	if not _ref_tilemap or not is_instance_valid(_ref_tilemap):
		if planet_map_system.tile_manager:
			_ref_tilemap = planet_map_system.tile_manager.ensure_layer_tilemap(0)

	# Collect trail data (tile -> traversal count) from path caches
	var all_trails: Dictionary = vs.get_all_trail_data()
	# Fall back to legacy visited tiles if no trail data yet
	if all_trails.is_empty():
		all_trails = vs.get_all_visited_tiles()
	if all_trails.is_empty():
		return

	var viewport_size := Vector2(1280.0, 720.0)
	if map_viewport and is_instance_valid(map_viewport):
		viewport_size = Vector2(map_viewport.size)

	var cam_local := to_local(camera.global_position)

	# Visible rect with padding
	var half_w := viewport_size.x * 0.5 / zoom.x + PlanetMapTileConfig.TILE_SIZE.x
	var half_h := viewport_size.y * 0.5 / zoom.y + PlanetMapTileConfig.TILE_SIZE.y * 2.0

	# Assign colors to villages
	for vid in all_trails:
		if not _village_color_map.has(vid):
			_village_color_map[vid] = VILLAGE_COLORS[_color_index % VILLAGE_COLORS.size()]
			_color_index += 1

	# Ultra-LOD mode — draw one circle per village center, skip per-tile iteration entirely
	if zoom.x < 0.03:
		for vid in all_trails:
			var base_color: Color = _village_color_map[vid]
			var bright := Color(base_color.r, base_color.g, base_color.b, 0.8)
			var village: VillageInstance = vs._villages_by_id.get(vid)
			if not village:
				continue
			var center := _tile_center_fast(village.camp_position)
			if absf(center.x - cam_local.x) > half_w or absf(center.y - cam_local.y) > half_h:
				continue
			var pop: int = village.get_population()
			var marker_radius := maxf(200.0, sqrt(float(pop)) * 40.0)
			draw_circle(center, marker_radius, bright)
		return

	# LOD mode — draw bright pixels for trails, intensity based on traversal count
	if zoom.x < 0.05:
		var pixel_size := 2.0 / zoom.x
		for vid in all_trails:
			var tiles: Dictionary = all_trails[vid]
			var base_color: Color = _village_color_map[vid]
			for tile: Vector2i in tiles:
				var center := _tile_center_fast(tile)
				if absf(center.x - cam_local.x) > half_w or absf(center.y - cam_local.y) > half_h:
					continue
				var count: int = tiles[tile] if tiles[tile] is int else 1
				var intensity: float = clampf(float(count) / 20.0, 0.2, 1.0)
				var c := Color(base_color.r, base_color.g, base_color.b, intensity)
				draw_rect(Rect2(center - Vector2(pixel_size, pixel_size) * 0.5, Vector2(pixel_size, pixel_size)), c)
		return

	var o := PlanetMapTileConfig.TILE_OFFSET

	# --- Trail tiles with intensity based on traversal count ---
	for vid in all_trails:
		var tiles: Dictionary = all_trails[vid]
		var base_color: Color = _village_color_map[vid]
		for tile: Vector2i in tiles:
			var count: int = tiles[tile] if tiles[tile] is int else 1
			# Skip faint trails below path threshold — only show established paths and light trails
			if count < 1:
				continue
			var center := _tile_center_fast(tile)
			if absf(center.x - cam_local.x) > half_w or absf(center.y - cam_local.y) > half_h:
				continue
			var intensity: float = clampf(float(count) / 20.0, 0.1, 1.0)
			var alpha: float = lerpf(0.05, 0.35, intensity)
			var trail_color := Color(base_color.r, base_color.g, base_color.b, alpha)
			_draw_diamond(center, o, trail_color)

	# --- Bright yellow path lines (above territory diamonds) ---
	var all_routes: Dictionary = vs.get_all_route_data()
	var path_width: float = F5_PATH_BASE_WIDTH / maxf(zoom.x, 0.05)
	var path_width_worn: float = path_width * 1.5

	for vid in all_routes:
		var routes: Array = all_routes[vid]
		for route_data in routes:
			var simplified: Array = route_data[0]  # Pre-simplified path
			var usage: int = route_data[1]
			var avg_count: float = route_data[2]   # Pre-computed traversal average
			if usage < 1 or simplified.size() < 2:
				continue
			var is_worn: bool = avg_count >= 30
			var seg_color: Color = F5_PATH_COLOR_WORN if is_worn else F5_PATH_COLOR
			var seg_width: float = path_width_worn if is_worn else path_width
			var points := PackedVector2Array()
			for pt in simplified:
				points.append(_tile_center_fast(pt))
			if points.size() >= 2:
				draw_polyline(points, seg_color, seg_width, true)

	# --- Resource markers from village knowledge ---
	for vid in all_trails:
		var village: VillageInstance = vs._villages_by_id.get(vid)
		if not village or not village.resource_memory:
			# Fallback: draw single markers from old dicts
			_draw_resource_marker(vs._camp_grid_positions.get(vid, Vector2i(-1, -1)), COLOR_CAMP, o, cam_local, half_w, half_h)
			_draw_resource_marker(vs._water_grid_positions.get(vid, Vector2i(-1, -1)), COLOR_WATER, o, cam_local, half_w, half_h)
			continue

		var mem: VillageResourceMemory = village.resource_memory

		# Camp — always single marker
		_draw_resource_marker(mem.camp_position, COLOR_CAMP, o, cam_local, half_w, half_h)

		# Water — single target marker
		_draw_resource_marker(mem.get_target(VillageResourceMemory.WATER), COLOR_WATER, o, cam_local, half_w, half_h)

		# Berry bushes — only show if currently harvestable (not depleted)
		var berry_target := mem.get_target(VillageResourceMemory.BERRY)
		for pos: Vector2i in mem.get_all_known(VillageResourceMemory.BERRY):
			if not planet_map_system or not planet_map_system.has_berry_at(pos):
				continue
			var center := _tile_center_fast(pos)
			if absf(center.x - cam_local.x) > half_w or absf(center.y - cam_local.y) > half_h:
				continue
			_draw_resource_icon(center, _berry_texture, COLOR_BERRY, pos == berry_target)

		# Firewood — show known, skip depleted (wood does not regenerate)
		# Skip if tile also has a known berry bush — berry icon takes priority
		var fw_target := mem.get_target(VillageResourceMemory.FIREWOOD)
		for pos: Vector2i in mem.get_all_known(VillageResourceMemory.FIREWOOD):
			if planet_map_system and not planet_map_system.has_dead_tree_at(pos):
				continue
			if mem.has_known(VillageResourceMemory.BERRY, pos):
				continue
			var center := _tile_center_fast(pos)
			if absf(center.x - cam_local.x) > half_w or absf(center.y - cam_local.y) > half_h:
				continue
			_draw_resource_icon(center, _firewood_texture, COLOR_FIREWOOD, pos == fw_target)

	# --- Villager positions ---
	var map_container: Node2D = vs.map_container
	if map_container and is_instance_valid(map_container):
		for v in vs._villagers:
			if v.state == VillagerSystem.STATE_SLEEPING:
				continue
			# Convert container_pos to tile_manager local space
			var world_pos: Vector2 = map_container.to_global(v.container_pos)
			var local_pos: Vector2 = to_local(world_pos)
			if absf(local_pos.x - cam_local.x) > half_w or absf(local_pos.y - cam_local.y) > half_h:
				continue
			_draw_diamond(local_pos, o * VILLAGER_MARKER_SCALE, COLOR_VILLAGER)


func _draw_diamond(center: Vector2, offset: Vector2, color: Color) -> void:
	if offset.x < 1.0 or offset.y < 1.0:
		return  # Skip degenerate diamonds (extreme zoom or zero offset)
	var top := center + Vector2(0.0, -offset.y)
	var right := center + Vector2(offset.x, 0.0)
	var bottom := center + Vector2(0.0, offset.y)
	var left := center + Vector2(-offset.x, 0.0)
	# Two triangles — avoids draw_colored_polygon triangulation errors
	var colors := PackedColorArray([color, color, color])
	draw_primitive(PackedVector2Array([top, right, bottom]), colors, PackedVector2Array())
	draw_primitive(PackedVector2Array([top, bottom, left]), colors, PackedVector2Array())


func _draw_resource_marker(grid_pos: Vector2i, color: Color, offset: Vector2, cam_local: Vector2, half_w: float, half_h: float, is_active_target: bool = false) -> void:
	if grid_pos.x < 0 or grid_pos.y < 0:
		return
	var center := _tile_center_fast(grid_pos)
	if absf(center.x - cam_local.x) > half_w or absf(center.y - cam_local.y) > half_h:
		return
	var mo := offset * MARKER_SCALE
	# Filled diamond
	_draw_diamond(center, mo, color)
	# Outline for visibility (skip if too small)
	if mo.x >= 0.5 and mo.y >= 0.5:
		var outline_color := COLOR_ACTIVE_OUTLINE if is_active_target else Color(1.0, 1.0, 1.0, 0.6)
		var outline_width := 2.5 if is_active_target else 1.5
		var outline_points := PackedVector2Array([
			center + Vector2(0.0, -mo.y),
			center + Vector2(mo.x, 0.0),
			center + Vector2(0.0, mo.y),
			center + Vector2(-mo.x, 0.0),
			center + Vector2(0.0, -mo.y),
		])
		draw_polyline(outline_points, outline_color, outline_width)


func _draw_resource_icon(center: Vector2, tex: Texture2D, fallback_color: Color, is_active_target: bool) -> void:
	if tex:
		var icon_rect := Rect2(center - RESOURCE_ICON_SIZE * 0.5, RESOURCE_ICON_SIZE)
		draw_texture_rect(tex, icon_rect, false)
	else:
		var mo := PlanetMapTileConfig.TILE_OFFSET * MARKER_SCALE
		_draw_diamond(center, mo, fallback_color)
	if is_active_target:
		var mo := PlanetMapTileConfig.TILE_OFFSET * MARKER_SCALE
		if mo.x >= 0.5 and mo.y >= 0.5:
			var outline_points := PackedVector2Array([
				center + Vector2(0.0, -mo.y),
				center + Vector2(mo.x, 0.0),
				center + Vector2(0.0, mo.y),
				center + Vector2(-mo.x, 0.0),
				center + Vector2(0.0, -mo.y),
			])
			draw_polyline(outline_points, COLOR_ACTIVE_OUTLINE, 2.5)


func _tile_center_fast(grid_pos: Vector2i) -> Vector2:
	# Use map_to_local for correct alignment (grid_to_world has offset mismatch — see gotcha #12)
	if _ref_tilemap and is_instance_valid(_ref_tilemap):
		var base := _ref_tilemap.map_to_local(grid_pos)
		if planet_map_system:
			var elevation_raw: float = planet_map_system.get_elevation_at(grid_pos)
			var layer: int = PlanetMapTileConfig.get_render_layer(elevation_raw)
			base.y -= layer * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET
		return base
	# Fallback to grid_to_world if no tilemap available
	var base := PlanetMapCoordinates.grid_to_world(grid_pos)
	if planet_map_system:
		var elevation_raw: float = planet_map_system.get_elevation_at(grid_pos)
		var layer: int = PlanetMapTileConfig.get_render_layer(elevation_raw)
		base.y -= layer * PlanetMapTileConfig.LAYER_HEIGHT_OFFSET
	return base
