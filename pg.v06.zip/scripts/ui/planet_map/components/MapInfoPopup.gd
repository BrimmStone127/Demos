class_name MapInfoPopup
extends Control

## Floating info popup that can be anchored to a fixed screen position
## or track a moving world-space position (e.g. a villager).
##
## Usage:
##   popup.show_at(screen_pos, "Name", "Body text")
##   popup.show_tracking(my_callable, "Name", body_callable)  # callables return Vector2/String

const LOG_TAG := "MAP_INFO_POPUP"

signal closed

var _panel: PanelContainer = null
var _title_label: Label = null
var _body_label: Label = null
var _close_button: Button = null

## If set, called each frame to get the current world position to track.
## Should return a Vector2 in map_container local space.
var _world_pos_fn: Callable = Callable()
## If set, called each frame to refresh body text (for live data).
var _body_fn: Callable = Callable()

## References needed for world-to-screen conversion.
var map_viewport: SubViewport = null
var viewport_container: SubViewportContainer = null


func _ready() -> void:
	_build_ui()
	hide()


func _build_ui() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)

	_panel = PanelContainer.new()
	_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_panel)

	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.08, 0.08, 0.10, 0.92)
	style.border_color = Color(0.55, 0.45, 0.25, 1.0)
	style.set_border_width_all(1)
	style.set_corner_radius_all(4)
	style.content_margin_left = 10.0
	style.content_margin_right = 10.0
	style.content_margin_top = 8.0
	style.content_margin_bottom = 8.0
	_panel.add_theme_stylebox_override("panel", style)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 4)
	_panel.add_child(vbox)

	# Header row
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 6)
	vbox.add_child(header)

	_title_label = Label.new()
	_title_label.add_theme_font_size_override("font_size", 13)
	_title_label.add_theme_color_override("font_color", Color(0.9, 0.8, 0.5, 1.0))
	_title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(_title_label)

	_close_button = Button.new()
	_close_button.text = "X"
	_close_button.flat = true
	_close_button.add_theme_font_size_override("font_size", 11)
	_close_button.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7, 1.0))
	_close_button.custom_minimum_size = Vector2(18, 18)
	_close_button.pressed.connect(_on_close_pressed)
	header.add_child(_close_button)

	# Separator
	var sep := HSeparator.new()
	sep.add_theme_color_override("color", Color(0.4, 0.35, 0.2, 0.6))
	vbox.add_child(sep)

	# Body
	_body_label = Label.new()
	_body_label.add_theme_font_size_override("font_size", 11)
	_body_label.add_theme_color_override("font_color", Color(0.85, 0.85, 0.85, 1.0))
	_body_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_body_label.custom_minimum_size = Vector2(160, 0)
	vbox.add_child(_body_label)


## Show popup at a fixed screen position.
func show_at(screen_pos: Vector2, title: String, body: String) -> void:
	_world_pos_fn = Callable()
	_body_fn = Callable()
	_title_label.text = title
	_body_label.text = body
	_reposition(screen_pos)
	show()


## Show popup tracking a moving world position.
## world_pos_fn: Callable() -> Vector2  (map_container local coords)
## body_fn: Callable() -> String        (refreshed each frame)
func show_tracking(world_pos_fn: Callable, title: String, body_fn: Callable) -> void:
	_world_pos_fn = world_pos_fn
	_body_fn = body_fn
	_title_label.text = title
	_body_label.text = body_fn.call() if body_fn.is_valid() else ""
	var screen_pos := _world_to_screen(_world_pos_fn.call())
	_reposition(screen_pos)
	show()


func set_title(title: String) -> void:
	if _title_label:
		_title_label.text = title


func _process(_delta: float) -> void:
	if not visible:
		return
	if not _world_pos_fn.is_valid():
		return

	var world_pos: Vector2 = _world_pos_fn.call()
	var screen_pos := _world_to_screen(world_pos)
	_reposition(screen_pos)

	if _body_fn.is_valid():
		_body_label.text = _body_fn.call()


func _reposition(screen_pos: Vector2) -> void:
	# Position popup centered above the target point
	_panel.reset_size()
	var panel_size := _panel.size
	var x := screen_pos.x - panel_size.x / 2.0
	var y := screen_pos.y - panel_size.y - 16.0  # 16px above target

	# Clamp to screen bounds
	var screen_size := get_viewport_rect().size
	x = clampf(x, 4.0, screen_size.x - panel_size.x - 4.0)
	y = clampf(y, 4.0, screen_size.y - panel_size.y - 4.0)

	_panel.position = Vector2(x, y)


## Convert map_container local position to outer UI screen position.
func _world_to_screen(world_pos: Vector2) -> Vector2:
	if not map_viewport or not viewport_container:
		return Vector2.ZERO
	var canvas_tf := map_viewport.get_canvas_transform()
	var vp_pos := canvas_tf * world_pos  # position within SubViewport pixel space
	var vp_size := Vector2(map_viewport.size)
	var container_rect := viewport_container.get_global_rect()
	return container_rect.position + vp_pos / vp_size * container_rect.size


func _on_close_pressed() -> void:
	_world_pos_fn = Callable()
	_body_fn = Callable()
	hide()
	closed.emit()
