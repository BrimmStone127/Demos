class_name PlanetMapLoadingOverlay
extends Control

## Full-screen loading overlay for planet map entry.
## Hides the incremental tile/sprite render that happens over the first several frames.
## Call show_loading() before generate_map(), then call begin_reveal() after map_generated.
## Emits loading_complete when the overlay has fully faded and the map is ready to interact with.

const LOG_TAG := "PLANET_MAP_LOADING"

signal loading_complete()

# Minimum frames to wait after map_generated before revealing the map.
const MIN_SETTLE_FRAMES := 20
# Hard cap so the screen doesn't stay black forever if something stalls.
const MAX_SETTLE_FRAMES := 120

var _bg: ColorRect = null
var _title_label: Label = null
var _progress_bar: ProgressBar = null
var _status_label: Label = null
var _scan_label: Label = null

var _scan_timer: float = 0.0
var _scan_index: int = 0
const _SCAN_FRAMES: Array[String] = [
	"[..........]",
	"[==........]",
	"[====......]",
	"[======....]",
	"[========..]",
	"[==========]",
	"[========..]",
	"[======....]",
	"[====......]",
	"[==........]",
]

var _revealing: bool = false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	z_index = 500
	visible = false

	_bg = ColorRect.new()
	_bg.color = Color(0.0, 0.0, 0.0, 1.0)
	_bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_bg)

	var center = CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center)

	var vbox = VBoxContainer.new()
	vbox.custom_minimum_size = Vector2(420, 0)
	vbox.add_theme_constant_override("separation", 8)
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(vbox)

	_title_label = _make_label("SURFACE SCAN IN PROGRESS", 14, Color(0.0, 1.0, 0.3))
	_title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(_title_label)

	_progress_bar = _create_progress_bar()
	vbox.add_child(_progress_bar)

	_status_label = _make_label("", 11, Color(0.0, 0.85, 0.25))
	_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(_status_label)

	_scan_label = _make_label(_SCAN_FRAMES[0], 10, Color(0.0, 0.5, 0.15))
	_scan_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(_scan_label)


func _process(delta: float) -> void:
	if not visible or _revealing:
		return
	_scan_timer += delta
	if _scan_timer >= 0.08:
		_scan_timer = 0.0
		_scan_index = (_scan_index + 1) % _SCAN_FRAMES.size()
		_scan_label.text = _SCAN_FRAMES[_scan_index]


## Show the overlay before map generation begins.
func show_loading(planet_name: String = "") -> void:
	_revealing = false
	modulate.a = 1.0
	visible = true
	_progress_bar.value = 0.0
	_status_label.text = ""
	if planet_name != "":
		_title_label.text = "SCANNING  %s" % planet_name.to_upper()
	else:
		_title_label.text = "SURFACE SCAN IN PROGRESS"


## Set progress 0.0 – 1.0.
func set_progress(p: float) -> void:
	_progress_bar.value = clamp(p, 0.0, 1.0) * 100.0


## Update the step description shown below the progress bar.
func set_status(text: String) -> void:
	if _status_label:
		_status_label.text = text


## Animate from current progress to 100%, show "SURFACE MAPPED", fade out, emit loading_complete.
func begin_reveal() -> void:
	if _revealing:
		return
	_revealing = true

	var tween := create_tween()
	tween.tween_method(set_progress, _progress_bar.value / 100.0, 1.0, 0.25)
	tween.tween_callback(func():
		_title_label.text = "SURFACE MAPPED"
		_status_label.text = "Ready"
		_scan_label.text = "[==========]"
	)
	tween.tween_interval(0.3)
	tween.tween_method(func(a: float): modulate.a = a, 1.0, 0.0, 0.35)
	tween.tween_callback(func():
		visible = false
		loading_complete.emit()
	)


func _create_progress_bar() -> ProgressBar:
	var bar := ProgressBar.new()
	bar.min_value = 0.0
	bar.max_value = 100.0
	bar.value = 0.0
	bar.custom_minimum_size = Vector2(420, 18)
	bar.show_percentage = false

	var bg_style := StyleBoxFlat.new()
	bg_style.bg_color = Color(0.05, 0.05, 0.05, 1.0)
	bg_style.border_color = Color(0.0, 0.5, 0.15, 1.0)
	bg_style.border_width_top = 1
	bg_style.border_width_bottom = 1
	bg_style.border_width_left = 1
	bg_style.border_width_right = 1
	bar.add_theme_stylebox_override("background", bg_style)

	var fill_style := StyleBoxFlat.new()
	fill_style.bg_color = Color(0.0, 0.75, 0.2, 1.0)
	bar.add_theme_stylebox_override("fill", fill_style)

	return bar


func _make_label(text: String, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	return label
