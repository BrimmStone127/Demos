class_name PlanetMapDayNight
extends RefCounted

## Manages day/night cycle visualization for PlanetMapView
## Uses CanvasModulate inside the SubViewport for flicker-free multiplicative lighting.
## Noon = white (full brightness), midnight = dark blue tint.

const LOG_TAG := "PLANET_MAP_DAY_NIGHT"

# Night color — applied at full darkness (midnight)
# Multiplied against all canvas content, so (0.3, 0.32, 0.4) means 30% red, 32% green, 40% blue
const NIGHT_COLOR := Color(0.3, 0.32, 0.44)

# References (set by PlanetMapView)
var enabled: bool = true
var day_night_modulate: CanvasModulate = null
var day_label: Label = null
var current_planet: Planet = null
var time_manager: TimeManager = null

# Smoothing state — lerp toward target to eliminate per-frame jitter
var _current_darkness: float = 0.0
var _initialized_darkness: bool = false  # Snap to correct value on first frame
const DARKNESS_LERP_SPEED := 8.0  # How fast lighting catches up (higher = faster)

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, message % values if values.size() > 0 else message)

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, message % values if values.size() > 0 else message)

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, message % values if values.size() > 0 else message)

## Initialize with required references
func initialize(p_day_night_modulate: CanvasModulate, p_day_label: Label, p_current_planet: Planet, p_time_manager: TimeManager):
	day_night_modulate = p_day_night_modulate
	day_label = p_day_label
	current_planet = p_current_planet
	time_manager = p_time_manager

## Update current planet reference (when planet changes)
func set_current_planet(planet: Planet):
	current_planet = planet
	_initialized_darkness = false  # Re-snap on next frame for new planet

## Update time manager reference
func set_time_manager(tm: TimeManager):
	time_manager = tm

## Enable or disable the day/night cycle
func set_enabled(p_enabled: bool) -> void:
	enabled = p_enabled
	if not enabled and day_night_modulate and is_instance_valid(day_night_modulate):
		day_night_modulate.color = Color.WHITE

## Update day/night lighting based on planet's local time of day
## Called every frame in _process() for smooth transitions
func update_day_night_lighting(delta: float) -> void:
	if not enabled:
		return

	if not current_planet:
		_log_warn("update_day_night_lighting: current_planet is null")
		return

	if not day_night_modulate or not is_instance_valid(day_night_modulate):
		_log_warn("update_day_night_lighting: day_night_modulate is null")
		return

	var time_of_day = current_planet.get_local_time_of_day()

	# Use smoothstep for perfectly smooth continuous transitions
	# Center around noon (0.5) for brightest point
	var t = clampf(abs(time_of_day - 0.5) * 2.0, 0.0, 1.0)  # 0.0 at noon, 1.0 at midnight

	# Make nights shorter by compressing the dark period
	t = pow(t, 0.8)

	# Triple smoothstep for ultra-smooth gradient
	t = t * t * t * (t * (t * 6.0 - 15.0) + 10.0)
	t = t * t * (3.0 - 2.0 * t)

	# t is now 0.0 (noon) to 1.0 (midnight)
	var target_darkness = t

	# First frame: snap to correct value so there's no visible ramp-up on load
	if not _initialized_darkness:
		_current_darkness = target_darkness
		_initialized_darkness = true
	else:
		_current_darkness = lerpf(_current_darkness, target_darkness, clampf(delta * DARKNESS_LERP_SPEED, 0.0, 1.0))

	# Lerp between white (noon) and NIGHT_COLOR (midnight)
	var modulate_color = Color.WHITE.lerp(NIGHT_COLOR, _current_darkness)
	day_night_modulate.color = modulate_color

## Refresh day label with current game day
func refresh_day_label():
	if not day_label:
		return
	if time_manager:
		day_label.text = "Day %.1f" % time_manager.game_days_elapsed
	else:
		day_label.text = "Day 0.0"

## Handle time scale change from UI
func on_time_scale_changed(scale: float):
	_log_info("on_time_scale_changed called with scale: %.2f", [scale])
	if time_manager:
		_log_info("Calling TimeManager.set_time_scale(%.2f)", [scale])
		time_manager.set_time_scale(scale)
	else:
		_log_error("on_time_scale_changed: time_manager is NULL, cannot change scale!")

## Handle simulation tick (for ecosystem panel refresh)
func on_simulation_tick(_tick_number: int, _game_days: float):
	# Day/night lighting is updated in _process() for smoothness
	pass
