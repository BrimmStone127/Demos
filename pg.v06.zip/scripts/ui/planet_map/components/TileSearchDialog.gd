class_name TileSearchDialog
extends CanvasLayer

## Minimal tile search overlay for Ctrl+F navigation
## Styled with TerminalTheme, appears in bottom-right corner
## Single text field with "X,Y" format (e.g., "32,45")
##
## Extends CanvasLayer to render above other UI elements (like SubViewportContainer)

signal tile_search_requested(tile_pos: Vector2i)

const LOG_TAG := "TILE_SEARCH_DIALOG"

var coord_input: LineEdit = null
var map_size: Vector2i = Vector2i(64, 64)  # Default, should be set by parent
var _panel: PanelContainer = null

func _ready():
	# Set layer above menus but below transitions
	layer = UILayers.MENUS + 50  # 550, above most UI but below transitions
	_build_ui()
	_setup_signals()
	hide()  # Start hidden, show only on Ctrl+F

func _build_ui():
	# Create a Control to fill the screen (for anchoring)
	var root_control = Control.new()
	root_control.set_anchors_preset(Control.PRESET_FULL_RECT)
	root_control.mouse_filter = Control.MOUSE_FILTER_IGNORE  # Let clicks through
	add_child(root_control)

	# Create panel container for the dialog
	_panel = PanelContainer.new()
	_panel.add_theme_stylebox_override("panel", TerminalTheme.get_panel_style())

	# Position in bottom-right corner with margin
	_panel.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	_panel.anchor_left = 1.0
	_panel.anchor_top = 1.0
	_panel.anchor_right = 1.0
	_panel.anchor_bottom = 1.0
	_panel.offset_left = -190   # 190px from right edge (180px wide + 10px margin)
	_panel.offset_right = -10   # 10px margin from right
	_panel.offset_top = -50     # 50px from bottom edge (40px tall + 10px margin)
	_panel.offset_bottom = -10  # 10px margin from bottom
	_panel.mouse_filter = Control.MOUSE_FILTER_STOP  # Capture mouse events

	root_control.add_child(_panel)

	# Just the input field - no labels
	coord_input = LineEdit.new()
	coord_input.placeholder_text = "X,Y or X.Y"
	coord_input.add_theme_font_size_override("font_size", 14)
	coord_input.custom_minimum_size = Vector2(160, 28)

	# Apply TerminalTheme colors to input
	coord_input.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	coord_input.add_theme_color_override("font_placeholder_color", Color(0.0, 0.4, 0.1))  # Dim green
	coord_input.add_theme_color_override("caret_color", TerminalTheme.terminal_green)
	coord_input.add_theme_color_override("selection_color", Color(0.0, 0.4, 0.1, 0.5))  # Dim green with transparency

	_panel.add_child(coord_input)

func _setup_signals():
	if coord_input:
		coord_input.text_submitted.connect(_on_input_submitted)

func set_map_size(new_size: Vector2i):
	map_size = new_size
	GameLog.info(LOG_TAG, "Map size set to %s" % map_size)

func _on_input_submitted(_text: String):
	var input_text = coord_input.text.strip_edges()

	if input_text.is_empty():
		_show_error("Enter coordinates")
		return

	# Parse "X,Y" or "X.Y" format (accept comma or period as separator)
	var parts: PackedStringArray
	if input_text.contains(","):
		parts = input_text.split(",")
	elif input_text.contains("."):
		parts = input_text.split(".")
	else:
		parts = PackedStringArray()

	if parts.size() != 2:
		_show_error("Format: X,Y or X.Y")
		return

	var x_text = parts[0].strip_edges()
	var y_text = parts[1].strip_edges()

	if not x_text.is_valid_int() or not y_text.is_valid_int():
		_show_error("Coordinates must be integers")
		return

	var x = x_text.to_int()
	var y = y_text.to_int()

	# Validate bounds
	if x < 0 or x >= map_size.x or y < 0 or y >= map_size.y:
		_show_error("Out of bounds (0-%d, 0-%d)" % [map_size.x - 1, map_size.y - 1])
		return

	# Valid coordinates - emit signal and close
	var tile_pos = Vector2i(x, y)
	GameLog.info(LOG_TAG, "Jumping to tile %s" % tile_pos)
	tile_search_requested.emit(tile_pos)
	_clear_and_hide()

func _show_error(message: String):
	# Flash red border to indicate error
	if coord_input:
		coord_input.modulate = Color(1.0, 0.5, 0.5)
		await get_tree().create_timer(0.3).timeout
		if coord_input and is_instance_valid(coord_input):
			coord_input.modulate = Color.WHITE
	GameLog.warn(LOG_TAG, "Input error: %s" % message)

func _clear_and_hide():
	if coord_input:
		coord_input.text = ""
		coord_input.modulate = Color.WHITE
	hide()

func _input(event: InputEvent):
	if not visible:
		return

	# Close on Escape
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		_clear_and_hide()
		get_viewport().set_input_as_handled()

func show_dialog():
	GameLog.info(LOG_TAG, "show_dialog() called - visible=%s, in_tree=%s" % [visible, is_inside_tree()])
	show()
	visible = true  # Explicitly set visible in case show() doesn't work
	GameLog.info(LOG_TAG, "After show() - visible=%s" % visible)

	# Focus input for immediate typing
	if coord_input:
		coord_input.grab_focus()
		coord_input.select_all()  # Select existing text if any
	else:
		GameLog.warn(LOG_TAG, "coord_input is null!")
