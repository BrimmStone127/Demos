class_name PlanetMapUIBuilder
extends RefCounted

## Handles UI layout and widget creation for PlanetMapView
## Responsible for creating cards, panels, labels, and viewport setup
## No game logic - pure UI construction

const LOG_TAG := "PLANET_MAP_UI_BUILDER"

const UI_MARGIN = 96  # Top and bottom margins (20% shorter for more map space)

signal back_button_pressed()
signal focus_village_pressed()
signal toggle_trees_pressed(show: bool)
signal toggle_heatmap_pressed(show: bool)

# UI References (returned to PlanetMapView after building)
var viewport_container: SubViewportContainer = null
var map_viewport: SubViewport = null
var map_container: Node2D = null
var map_background: ColorRect = null
var day_night_modulate: CanvasModulate = null
var back_button: Button = null
var day_label: Label = null
var planet_name_label: Label = null
var system_name_label: Label = null
var tile_info_section: VBoxContainer = null
var time_control_panel: TimeControlPanel = null
var resources_section: VBoxContainer = null
var map_stats_panel: StatsPanel = null
var tools_section: VBoxContainer = null
var laser_button: Button = null
var compiler_beam_button: Button = null
var foundation_ref: Foundation = null

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, message % values if values.size() > 0 else message)

## Build the complete UI and return references dictionary
func build_ui(parent: Control) -> Dictionary:
	_log_info("Building planet map UI...")

	_setup_parent_control(parent)
	_create_background(parent)
	_create_viewport_container(parent)
	_create_viewport(viewport_container)
	_create_day_night_modulate(map_viewport)
	_create_map_container(map_viewport)
	_create_top_margin_cards(parent)
	_create_bottom_margin_cards(parent)
	_create_day_refresh_timer(parent)

	_log_info("UI build complete - 6-card grid layout ready")

	return {
		"viewport_container": viewport_container,
		"map_viewport": map_viewport,
		"map_container": map_container,
		"map_background": map_background,
		"day_night_modulate": day_night_modulate,
		"back_button": back_button,
		"day_label": day_label,
		"planet_name_label": planet_name_label,
		"system_name_label": system_name_label,
		"tile_info_section": tile_info_section,
		"time_control_panel": time_control_panel,
		"resources_section": resources_section,
		"map_stats_panel": map_stats_panel,
		"tools_section": tools_section,
		"laser_button": laser_button,
		"compiler_beam_button": compiler_beam_button,
	}

func _setup_parent_control(parent: Control):
	parent.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	parent.position = Vector2.ZERO
	parent.mouse_filter = Control.MOUSE_FILTER_STOP
	parent.z_index = 100

func _create_background(parent: Control):
	var background = ColorRect.new()
	background.color = Color(0.0, 0.0, 0.0, 1.0)
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	background.z_index = -1
	parent.add_child(background)

func _create_viewport_container(parent: Control):
	viewport_container = SubViewportContainer.new()
	viewport_container.name = "PlanetMapViewportContainer"
	viewport_container.anchor_left = 0.0
	viewport_container.anchor_right = 1.0
	viewport_container.anchor_top = 0.0
	viewport_container.anchor_bottom = 1.0
	viewport_container.offset_left = 0
	viewport_container.offset_right = 0
	viewport_container.offset_top = UI_MARGIN
	viewport_container.offset_bottom = -UI_MARGIN
	viewport_container.stretch = true
	viewport_container.mouse_filter = Control.MOUSE_FILTER_STOP
	parent.add_child(viewport_container)

func _create_day_night_modulate(viewport: SubViewport):
	day_night_modulate = CanvasModulate.new()
	day_night_modulate.name = "DayNightModulate"
	day_night_modulate.color = Color.WHITE  # Start at full brightness (noon)
	viewport.add_child(day_night_modulate)

func _create_viewport(container: SubViewportContainer):
	map_viewport = SubViewport.new()
	map_viewport.name = "PlanetMapViewport"
	map_viewport.transparent_bg = false
	if map_viewport.has_method("set_physics_object_picking"):
		map_viewport.physics_object_picking = true
	map_viewport.gui_disable_input = false
	# CLEAR_MODE_ALWAYS — prevents black flash on heavy frames (LOD transitions,
	# chunk queue_free bursts) where CanvasLayer background might not repaint in time.
	map_viewport.render_target_clear_mode = SubViewport.CLEAR_MODE_ALWAYS

	# Pixel-perfect rendering settings
	if map_viewport.has_method("set_disable_3d"):
		map_viewport.disable_3d = true
	if map_viewport.has_method("set_canvas_item_default_texture_filter"):
		map_viewport.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST
	if map_viewport.has_method("set_canvas_item_default_texture_repeat"):
		map_viewport.canvas_item_default_texture_repeat = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_REPEAT_DISABLED
	# Pixel snapping DISABLED — causes +-1px tile shimmer at fractional zoom levels.
	# Individual nodes use texture_filter = NEAREST for crisp rendering instead.
	if map_viewport.has_method("set_snap_2d_transforms_to_pixel"):
		map_viewport.snap_2d_transforms_to_pixel = false
	if map_viewport.has_method("set_snap_2d_vertices_to_pixel"):
		map_viewport.snap_2d_vertices_to_pixel = false

	map_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	container.add_child(map_viewport)

	# Black background via CanvasLayer — unaffected by Camera2D, always behind everything
	var bg_layer = CanvasLayer.new()
	bg_layer.name = "BackgroundLayer"
	bg_layer.layer = -100
	map_viewport.add_child(bg_layer)
	map_background = ColorRect.new()
	map_background.name = "MapBackground"
	map_background.color = Color(0.03, 0.03, 0.12, 1.0)
	map_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	map_background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg_layer.add_child(map_background)

func _create_map_container(viewport: SubViewport):
	map_container = Node2D.new()
	map_container.name = "MapContainer"
	map_container.z_index = 1
	viewport.add_child(map_container)

func _create_top_margin_cards(parent: Control):
	var top_container = HBoxContainer.new()
	AnchorLayoutHelper.setup_top_margin_container(top_container, UI_MARGIN, 10, 10)
	top_container.add_theme_constant_override("separation", 10)
	top_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_container.z_index = ZIndexLayers.UI_PANELS
	parent.add_child(top_container)

	# TOP LEFT - Back button
	_create_top_left_card(top_container)

	# TOP CENTER - Planet/system name, day counter
	_create_top_center_card(top_container)

	# TOP RIGHT - Time controls
	_create_top_right_card(top_container)

func _create_top_left_card(container: HBoxContainer):
	var card = create_card()
	card.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	card.custom_minimum_size = Vector2(200, 0)
	container.add_child(card)

	var content = VBoxContainer.new()
	content.set_anchors_preset(Control.PRESET_FULL_RECT)
	content.offset_left = 8
	content.offset_right = -8
	content.offset_top = 8
	content.offset_bottom = -8
	card.add_child(content)

	back_button = Button.new()
	back_button.text = "< Back to System"
	back_button.pressed.connect(func(): back_button_pressed.emit())
	back_button.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	TerminalTheme.apply_to_button(back_button)
	content.add_child(back_button)

	var separator = HSeparator.new()
	separator.add_theme_color_override("color", Color(0.0, 0.5, 0.0, 0.5))
	separator.add_theme_constant_override("separation", 4)
	content.add_child(separator)

	# Compact Foundation stats panel (credits + rank + toast)
	map_stats_panel = StatsPanel.new(null, null, true)
	map_stats_panel.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	content.add_child(map_stats_panel)

	# Keep resources_section reference for compatibility
	resources_section = VBoxContainer.new()
	resources_section.add_theme_constant_override("separation", 2)
	resources_section.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.add_child(resources_section)

func _create_top_center_card(container: HBoxContainer):
	var card = create_card()
	container.add_child(card)

	var content = VBoxContainer.new()
	content.set_anchors_preset(Control.PRESET_FULL_RECT)
	content.offset_left = 10
	content.offset_right = -10
	content.offset_top = 8
	content.offset_bottom = -8
	content.add_theme_constant_override("separation", 1)
	content.alignment = BoxContainer.ALIGNMENT_CENTER
	card.add_child(content)

	# Planet name
	planet_name_label = Label.new()
	planet_name_label.text = "Loading..."
	planet_name_label.add_theme_font_size_override("font_size", 13)
	planet_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	TerminalTheme.apply_to_label(planet_name_label)
	content.add_child(planet_name_label)

	# System name
	system_name_label = Label.new()
	system_name_label.text = "Loading..."
	system_name_label.add_theme_font_size_override("font_size", 10)
	system_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	system_name_label.add_theme_color_override("font_color", Color(0.0, 0.7, 0.2))
	system_name_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	content.add_child(system_name_label)

	# Day counter
	day_label = Label.new()
	day_label.text = "Day 0.0"
	day_label.add_theme_font_size_override("font_size", 11)
	day_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	TerminalTheme.apply_to_label(day_label)
	content.add_child(day_label)

func _create_top_right_card(container: HBoxContainer):
	var card = create_card()
	card.size_flags_horizontal = Control.SIZE_SHRINK_END
	card.custom_minimum_size = Vector2(200, 0)
	container.add_child(card)

	var time_control_align = AnchorLayoutHelper.create_right_aligned_container(card, 5)

	time_control_panel = TimeControlPanel.new()
	time_control_align.add_child(time_control_panel)

func _create_bottom_margin_cards(parent: Control):
	var bottom_container = HBoxContainer.new()
	AnchorLayoutHelper.setup_bottom_margin_container(bottom_container, UI_MARGIN, 10, 10)
	bottom_container.add_theme_constant_override("separation", 10)
	bottom_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom_container.z_index = ZIndexLayers.UI_PANELS
	parent.add_child(bottom_container)

	# BOTTOM LEFT - Ecosystem stats
	_create_bottom_left_card(bottom_container)

	# BOTTOM CENTER - Tile info
	_create_bottom_center_card(bottom_container)

	# BOTTOM RIGHT - Empty (reserved)
	_create_bottom_right_card(bottom_container)

func _create_bottom_left_card(container: HBoxContainer):
	var card = create_card()
	card.clip_contents = true
	container.add_child(card)

	var button_section := VBoxContainer.new()
	button_section.set_anchors_preset(Control.PRESET_FULL_RECT)
	button_section.offset_left = 8
	button_section.offset_right = -8
	button_section.offset_top = 8
	button_section.offset_bottom = -8
	button_section.add_theme_constant_override("separation", 4)
	button_section.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(button_section)

	var focus_btn := Button.new()
	focus_btn.text = "[ FOCUS ]"
	focus_btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	TerminalTheme.apply_to_button(focus_btn)
	focus_btn.pressed.connect(func() -> void: focus_village_pressed.emit())
	button_section.add_child(focus_btn)

	var btn_row := HBoxContainer.new()
	btn_row.add_theme_constant_override("separation", 4)
	button_section.add_child(btn_row)

	var trees_btn := Button.new()
	trees_btn.text = "[ TREES ]"
	trees_btn.toggle_mode = true
	trees_btn.button_pressed = true
	trees_btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	TerminalTheme.apply_to_button(trees_btn)
	trees_btn.toggled.connect(func(pressed: bool) -> void:
		trees_btn.text = "[ TREES ]" if pressed else "[ NO TREES ]"
		toggle_trees_pressed.emit(pressed))
	btn_row.add_child(trees_btn)

	var heatmap_btn := Button.new()
	heatmap_btn.text = "[ ELEVATION ]"
	heatmap_btn.toggle_mode = true
	heatmap_btn.button_pressed = false
	heatmap_btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	TerminalTheme.apply_to_button(heatmap_btn)
	heatmap_btn.toggled.connect(func(pressed: bool) -> void:
		heatmap_btn.text = "[ ELEVATION ]" if pressed else "[ ELEVATION ]"
		toggle_heatmap_pressed.emit(pressed))
	btn_row.add_child(heatmap_btn)

func _create_bottom_center_card(container: HBoxContainer):
	var card = create_card()
	card.clip_contents = true
	container.add_child(card)

	tile_info_section = VBoxContainer.new()
	tile_info_section.set_anchors_preset(Control.PRESET_FULL_RECT)
	tile_info_section.offset_left = 10
	tile_info_section.offset_right = -10
	tile_info_section.offset_top = 10
	tile_info_section.offset_bottom = -10
	tile_info_section.add_theme_constant_override("separation", 2)
	tile_info_section.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(tile_info_section)

func _create_bottom_right_card(container: HBoxContainer):
	var card = create_card()
	container.add_child(card)

	var content = VBoxContainer.new()
	content.set_anchors_preset(Control.PRESET_FULL_RECT)
	content.offset_left = 8
	content.offset_right = -8
	content.offset_top = 8
	content.offset_bottom = -8
	content.add_theme_constant_override("separation", 4)
	card.add_child(content)

	var header = make_panel_label("TOOLS", 11, Color(0.0, 1.0, 0.3))
	content.add_child(header)

	tools_section = VBoxContainer.new()
	tools_section.add_theme_constant_override("separation", 4)
	content.add_child(tools_section)

	# Only create tool buttons for owned blueprints
	if foundation_ref and foundation_ref.has_blueprint("laser"):
		laser_button = _create_tool_button("[ LASER ]")
		tools_section.add_child(laser_button)

	if foundation_ref and foundation_ref.has_blueprint("compiler_beam"):
		compiler_beam_button = _create_tool_button("[ COMPILER BEAM ]")
		tools_section.add_child(compiler_beam_button)

	if not laser_button and not compiler_beam_button:
		var empty_label = make_panel_label("No modules installed", 10, Color(0.0, 0.5, 0.15))
		empty_label.name = "EmptyToolsLabel"
		tools_section.add_child(empty_label)

func _create_day_refresh_timer(parent: Control):
	var day_timer = Timer.new()
	day_timer.wait_time = 0.5
	day_timer.one_shot = false
	day_timer.autostart = true
	parent.add_child(day_timer)
	# Note: Timer callback will be connected by parent (PlanetMapView)

## Create a borderless black card panel (matching original PlanetMapView style)
func create_card() -> Panel:
	var card = Panel.new()
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card.size_flags_vertical = Control.SIZE_EXPAND_FILL
	card.mouse_filter = Control.MOUSE_FILTER_STOP

	# Black background, no border (matches original PlanetMapView styling)
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.0, 0.0, 0.0, 1.0)  # Pure black
	style.border_width_left = 0
	style.border_width_right = 0
	style.border_width_top = 0
	style.border_width_bottom = 0
	card.add_theme_stylebox_override("panel", style)

	# Consume input events to prevent click-through to viewport
	card.gui_input.connect(func(event):
		if event is InputEventMouseButton or event is InputEventMouseMotion:
			card.accept_event()
	)

	return card

## Create a terminal-themed label (matches original PlanetMapView style)
func make_panel_label(text: String, font_size: int = 11, color: Color = Color(0.0, 0.85, 0.25)) -> Label:
	var label = Label.new()
	label.text = text
	label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label

func _create_tool_button(text: String) -> Button:
	var btn = Button.new()
	btn.text = text
	btn.toggle_mode = true
	btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	TerminalTheme.apply_to_button(btn)
	return btn

## Add a tool button dynamically (after blueprint purchase).
## Returns the created Button so PlanetMapView can wire signals.
func add_tool_button(blueprint_id: String) -> Button:
	if not tools_section:
		return null
	# Remove "No modules" label if present
	var empty = tools_section.get_node_or_null("EmptyToolsLabel")
	if empty:
		empty.queue_free()
	match blueprint_id:
		"laser":
			if laser_button:
				return laser_button
			laser_button = _create_tool_button("[ LASER ]")
			tools_section.add_child(laser_button)
			return laser_button
		"compiler_beam":
			if compiler_beam_button:
				return compiler_beam_button
			compiler_beam_button = _create_tool_button("[ COMPILER BEAM ]")
			tools_section.add_child(compiler_beam_button)
			return compiler_beam_button
	return null

## Calculate target viewport size based on container size
func calculate_viewport_size(container: SubViewportContainer) -> Vector2i:
	if not container or not is_instance_valid(container):
		return Vector2i.ZERO
	var control_size = container.size
	var width = max(1, int(round(control_size.x)))
	var height = max(1, int(round(control_size.y)))
	return Vector2i(width, height)

## Update subviewport size to match container
func update_viewport_size(viewport: SubViewport, container: SubViewportContainer):
	if not viewport or not is_instance_valid(viewport):
		return
	var target_size = calculate_viewport_size(container)
	if target_size == Vector2i.ZERO:
		return
	if viewport.size != target_size:
		viewport.size = target_size
