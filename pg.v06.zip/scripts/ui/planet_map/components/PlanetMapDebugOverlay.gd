class_name PlanetMapDebugOverlay
extends Node2D

## In-world debug overlay for the planet map.
## Draws tile diamond outlines and chunk boundary outlines in world space.
## Must be added as a child of tile_manager so its local coordinate space
## matches the tilemaps (tile_manager local == grid_to_world output space).

# Visual style
const TILE_COLOR  := Color(0.0, 1.0, 0.5, 0.55)   # green, semi-opaque
const CHUNK_COLOR := Color(1.0, 0.65, 0.0, 1.0)   # solid orange
const TILE_WIDTH  := 1.0
const CHUNK_WIDTH := 2.0
const LABEL_SIZE  := 18

var show_tile_grid: bool  = false
var show_chunk_grid: bool = true

# Set by PlanetMapView after creation
var planet_map_system: PlanetMapSystem = null
var map_viewport: SubViewport = null

func _ready() -> void:
	# High but valid z-index — above all terrain (max 2800) and trees (3200)
	z_index = 4090
	z_as_relative = false
	queue_redraw()

func _process(_delta: float) -> void:
	if visible:
		queue_redraw()

func _draw() -> void:
	if not planet_map_system:
		return

	var camera := planet_map_system.get_camera()
	if not camera or not is_instance_valid(camera):
		return

	var zoom := camera.zoom
	if zoom.x <= 0.0:
		return

	var viewport_size := Vector2(1280.0, 720.0)
	if map_viewport and is_instance_valid(map_viewport):
		viewport_size = Vector2(map_viewport.size)

	# Camera center in this node's local space.
	# The overlay is a direct child of tile_manager with no offset,
	# so local space == tile_manager local space.
	var cam_local := to_local(camera.global_position)

	# Visible rect padded by one tile on each side
	var half_w := viewport_size.x * 0.5 / zoom.x + PlanetMapTileConfig.TILE_SIZE.x
	var half_h := viewport_size.y * 0.5 / zoom.y + PlanetMapTileConfig.TILE_SIZE.y * 2.0
	var rect_min := cam_local - Vector2(half_w, half_h)
	var rect_max := cam_local + Vector2(half_w, half_h)

	# Derive tile range from all four corners of the visible rect.
	var corners := [
		rect_min,
		Vector2(rect_max.x, rect_min.y),
		rect_max,
		Vector2(rect_min.x, rect_max.y),
	]
	var min_tx := 999999; var max_tx := -999999
	var min_ty := 999999; var max_ty := -999999
	for c: Vector2 in corners:
		var t := PlanetMapCoordinates.world_to_grid(c)
		if t.x - 1 < min_tx: min_tx = t.x - 1
		if t.x + 1 > max_tx: max_tx = t.x + 1
		if t.y - 1 < min_ty: min_ty = t.y - 1
		if t.y + 1 > max_ty: max_ty = t.y + 1

	# Clamp to map bounds
	var map_size := Vector2i(64, 64)
	if planet_map_system.using_chunks and planet_map_system.chunk_manager \
			and planet_map_system.chunk_manager.terrain_source:
		map_size = planet_map_system.chunk_manager.terrain_source.get_png_size()
	elif planet_map_system.map_data:
		map_size = planet_map_system.map_data.map_size
	min_tx = clampi(min_tx, 0, map_size.x - 1)
	max_tx = clampi(max_tx, 0, map_size.x - 1)
	min_ty = clampi(min_ty, 0, map_size.y - 1)
	max_ty = clampi(max_ty, 0, map_size.y - 1)

	if show_chunk_grid:
		_draw_chunk_grid(min_tx, max_tx, min_ty, max_ty, map_size)

	if show_tile_grid:
		_draw_tile_grid(min_tx, max_tx, min_ty, max_ty)


# --- Tile position helper -----------------------------------------------------

## Return the visual center of a tile in overlay local space (= tile_manager local space).
## Uses the same coordinate chain confirmed for harvester/runner placement:
##   get_elevation_at → get_render_layer → tilemap.map_to_local + tilemap.position
func _tile_center(grid_pos: Vector2i) -> Vector2:
	if not planet_map_system or not planet_map_system.tile_manager:
		return PlanetMapCoordinates.grid_to_world(grid_pos)
	var elevation_raw: float = planet_map_system.get_elevation_at(grid_pos)
	var layer: int = PlanetMapTileConfig.get_render_layer(elevation_raw)
	var tm: TileMap = planet_map_system.tile_manager.ensure_layer_tilemap(layer)
	if not tm or not is_instance_valid(tm):
		return PlanetMapCoordinates.grid_to_world(grid_pos)
	return tm.map_to_local(grid_pos) + tm.position


# --- Tile grid ----------------------------------------------------------------

func _draw_tile_grid(min_tx: int, max_tx: int, min_ty: int, max_ty: int) -> void:
	for tx in range(min_tx, max_tx + 1):
		for ty in range(min_ty, max_ty + 1):
			_draw_diamond(Vector2i(tx, ty), TILE_COLOR, TILE_WIDTH)


# --- Chunk grid ---------------------------------------------------------------

func _draw_chunk_grid(min_tx: int, max_tx: int, min_ty: int, max_ty: int,
		map_size: Vector2i) -> void:
	var cs     := ChunkTileData.CHUNK_SIZE
	var min_cx := min_tx / cs
	var max_cx := max_tx / cs
	var min_cy := min_ty / cs
	var max_cy := max_ty / cs

	for cx in range(min_cx, max_cx + 1):
		for cy in range(min_cy, max_cy + 1):
			var x0 := cx * cs
			var y0 := cy * cs
			var x1 := mini(x0 + cs - 1, map_size.x - 1)
			var y1 := mini(y0 + cs - 1, map_size.y - 1)
			_draw_chunk_outline(x0, y0, x1, y1, cx, cy)


# --- Primitives ---------------------------------------------------------------

func _draw_diamond(tile: Vector2i, color: Color, width: float) -> void:
	var o      := PlanetMapTileConfig.TILE_OFFSET
	var center := _tile_center(tile)
	draw_line(center + Vector2(0.0, -o.y), center + Vector2(o.x, 0.0),  color, width)
	draw_line(center + Vector2(o.x, 0.0), center + Vector2(0.0, o.y),   color, width)
	draw_line(center + Vector2(0.0,  o.y), center + Vector2(-o.x, 0.0), color, width)
	draw_line(center + Vector2(-o.x, 0.0), center + Vector2(0.0, -o.y), color, width)


func _draw_chunk_outline(x0: int, y0: int, x1: int, y1: int,
		cx: int, cy: int) -> void:
	var o := PlanetMapTileConfig.TILE_OFFSET
	var top    := _tile_center(Vector2i(x0, y0)) + Vector2(0.0,  -o.y)
	var right  := _tile_center(Vector2i(x1, y0)) + Vector2(o.x,   0.0)
	var bottom := _tile_center(Vector2i(x1, y1)) + Vector2(0.0,   o.y)
	var left   := _tile_center(Vector2i(x0, y1)) + Vector2(-o.x,  0.0)

	draw_line(top,    right,  CHUNK_COLOR, CHUNK_WIDTH)
	draw_line(right,  bottom, CHUNK_COLOR, CHUNK_WIDTH)
	draw_line(bottom, left,   CHUNK_COLOR, CHUNK_WIDTH)
	draw_line(left,   top,    CHUNK_COLOR, CHUNK_WIDTH)

	# Chunk label near the top-right edge midpoint
	var label_pos := (top + right) * 0.5
	draw_string(ThemeDB.fallback_font, label_pos,
			"(%d,%d)" % [cx, cy],
			HORIZONTAL_ALIGNMENT_CENTER, -1, LABEL_SIZE, CHUNK_COLOR)
