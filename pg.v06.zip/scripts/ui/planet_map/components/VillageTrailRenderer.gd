class_name VillageTrailRenderer
extends Node2D

## Always-visible trail path renderer. Draws brown dirt lines along established
## villager routes, underneath villagers and vegetation. Unlike VillageTerritoryOverlay
## (F5 toggle), this is always visible when villages exist.
##
## IMPORTANT: Uses VillagerSystem._get_resource_container_pos() for coordinate conversion
## to guarantee exact alignment with villager movement positions. Both the trail lines
## and villager sprites must use the identical coordinate pipeline:
##   grid_pos -> layer tilemap map_to_local + tm.position -> tile_manager.to_global
##   -> map_container.to_local (= container_pos used by villager sprites)
## The trail renderer is parented to map_container (same as villager sprites) so draw
## calls use the same coordinate space.

const PATH_THRESHOLD := 10           # traversals before path appears
const PATH_COLOR := Color(0.25, 0.15, 0.05, 0.55)       # dark dirt
const PATH_COLOR_WORN := Color(0.35, 0.22, 0.08, 0.75)  # well-worn
const PATH_WORN_THRESHOLD := 30      # traversals for well-worn appearance
const PATH_BASE_WIDTH := 2.0         # base line width at zoom 1.0

var planet_map_system: PlanetMapSystem = null

var _redraw_timer: float = 0.0
const REDRAW_INTERVAL := 0.2  # 5 Hz — trails change slowly


func _ready() -> void:
	z_index = 3100  # Below villagers (3150) and trees (3200)
	z_as_relative = false


func _process(delta: float) -> void:
	if not planet_map_system or not planet_map_system.villager_system:
		return
	_redraw_timer += delta
	var camera := planet_map_system.get_camera()
	var interval := REDRAW_INTERVAL
	if camera and is_instance_valid(camera) and camera.zoom.x < 0.1:
		interval = 1.0  # 1 Hz at extreme zoom
	elif camera and is_instance_valid(camera) and camera.zoom.x < 0.2:
		interval = 0.5
	if _redraw_timer >= interval:
		_redraw_timer = 0.0
		queue_redraw()


func _draw() -> void:
	if not planet_map_system or not planet_map_system.villager_system:
		return

	var camera := planet_map_system.get_camera()
	if not camera or not is_instance_valid(camera):
		return

	var zoom := camera.zoom
	if zoom.x <= 0.0:
		return

	var vs: VillagerSystem = planet_map_system.villager_system

	var all_routes: Dictionary = vs.get_all_route_data()

	var path_width: float = PATH_BASE_WIDTH / maxf(zoom.x, 0.05)
	var path_width_worn: float = path_width * 1.5

	for vid in all_routes:
		var routes: Array = all_routes[vid]
		for route_data in routes:
			var simplified: Array = route_data[0]  # Pre-simplified path
			var usage: int = route_data[1]
			var avg_count: float = route_data[2]   # Pre-computed traversal average
			if usage < 1 or simplified.size() < 2:
				continue
			if avg_count < PATH_THRESHOLD:
				continue
			var is_worn: bool = avg_count >= PATH_WORN_THRESHOLD
			var seg_color: Color = PATH_COLOR_WORN if is_worn else PATH_COLOR
			var seg_width: float = path_width_worn if is_worn else path_width
			var points := PackedVector2Array()
			for pt in simplified:
				# Use exact same coordinate conversion as villager movement
				points.append(vs._get_resource_container_pos(pt))
			if points.size() >= 2:
				draw_polyline(points, seg_color, seg_width, true)
