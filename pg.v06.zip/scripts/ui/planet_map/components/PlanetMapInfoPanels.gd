class_name PlanetMapInfoPanels
extends RefCounted

## Manages ecosystem panel and tile info panel content for PlanetMapView
## Reads from EcosystemManager and PlanetMapSystem, formats for display
## Handles all panel refresh logic and tree/ground cover counting

const LOG_TAG := "PLANET_MAP_INFO_PANELS"

var ecosystem_section: VBoxContainer = null
var tile_info_section: VBoxContainer = null
var resources_section: VBoxContainer = null
var ui_builder: PlanetMapUIBuilder = null

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, message % values if values.size() > 0 else message)

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, message % values if values.size() > 0 else message)

## Initialize with UI sections
func initialize(p_ecosystem_section: VBoxContainer, p_tile_info_section: VBoxContainer, p_ui_builder: PlanetMapUIBuilder, p_resources_section: VBoxContainer = null):
	ecosystem_section = p_ecosystem_section
	tile_info_section = p_tile_info_section
	resources_section = p_resources_section
	ui_builder = p_ui_builder

## Refresh resources panel with current player resource counts
func refresh_resources_panel(probe_system: ProbeSystem):
	if not resources_section:
		return

	for child in resources_section.get_children():
		child.queue_free()

	resources_section.add_child(_make_label("RESOURCES", 11, Color(0.0, 1.0, 0.3)))

	var carbon_val = probe_system.carbon if probe_system else 0
	resources_section.add_child(_make_label("Carbon: %d" % carbon_val, 11, Color(0.6, 1.0, 0.6)))

## Refresh ecosystem panel with current tree counts
func refresh_ecosystem_panel(planet_map_system: PlanetMapSystem, current_planet: Planet):
	if not ecosystem_section:
		return

	# Clear existing children
	for child in ecosystem_section.get_children():
		child.queue_free()

	# Header
	ecosystem_section.add_child(_make_label("ECOSYSTEM", 11, Color(0.0, 1.0, 0.3)))

	# Climate
	if current_planet:
		var climate = "TEMPERATE"
		if planet_map_system and planet_map_system.planet_data.has("revealed_data"):
			climate = planet_map_system.planet_data["revealed_data"].get("climate_type", "TEMPERATE")
		ecosystem_section.add_child(_make_label(climate))

	# Tree counts - ultra compact format
	if planet_map_system and planet_map_system.ecosystem_manager:
		var eid = planet_map_system.planet_id
		if eid == "" and planet_map_system.current_planet:
			eid = str(planet_map_system.current_planet.get_instance_id())

		var trees = planet_map_system.ecosystem_manager.get_trees_for_planet(eid)
		var seedlings := 0
		var saplings := 0
		var matures := 0
		var dormant := 0

		for tree in trees:
			match tree.growth_stage:
				TreeInstance.GrowthStage.SEEDLING:
					seedlings += 1
				TreeInstance.GrowthStage.YOUNG_SAPLING:
					saplings += 1
				TreeInstance.GrowthStage.SAPLING:
					saplings += 1
				TreeInstance.GrowthStage.YOUNG_MATURE:
					matures += 1
				TreeInstance.GrowthStage.MATURE:
					matures += 1
				TreeInstance.GrowthStage.VERY_MATURE:
					matures += 1
				TreeInstance.GrowthStage.DORMANT:
					dormant += 1

		ecosystem_section.add_child(_make_label("Trees: %d" % trees.size()))
		# Compact format: group young/mature stages together
		ecosystem_section.add_child(_make_label("Sdl:%d Sap:%d" % [seedlings, saplings]))
		ecosystem_section.add_child(_make_label("Mat:%d Dorm:%d" % [matures, dormant]))
	else:
		ecosystem_section.add_child(_make_label("Trees: --"))

## Refresh tile panel with selected tile info
func refresh_tile_panel(tile: MapTile, planet_map_system: PlanetMapSystem):
	if not tile_info_section:
		return

	# Clear existing children
	for child in tile_info_section.get_children():
		child.queue_free()

	if tile == null:
		return

	# Helper to create centered label
	var make_centered_label = func(text: String, font_size: int = 11, color: Color = Color(0.0, 0.85, 0.25)) -> Label:
		var label = _make_label(text, font_size, color)
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		return label

	# Harvester info takes priority — show only harvester content if present
	if planet_map_system and planet_map_system.harvester_manager:
		var hm: HarvesterManager = planet_map_system.harvester_manager
		var harvester: HarvesterInstance = hm.get_harvester_at(tile.position, planet_map_system.planet_id)
		if harvester:
			_add_harvester_info_to_panel(harvester, make_centered_label)
			return

	# Compact header
	tile_info_section.add_child(make_centered_label.call("SELECTED TILE", 11, Color(0.0, 1.0, 0.3)))

	# Terrain type (simplified)
	var terrain_name = PlanetMapTileConfig.TileType.keys()[tile.type].replace("_", " ").capitalize()
	tile_info_section.add_child(make_centered_label.call(terrain_name))

	# Coordinates and elevation
	tile_info_section.add_child(make_centered_label.call("X:%d Y:%d" % [tile.position.x, tile.position.y], 10, Color(0.0, 0.75, 0.9)))
	var render_layer = PlanetMapTileConfig.get_render_layer(tile.elevation)
	tile_info_section.add_child(make_centered_label.call("Elev: %.2f (L%d)" % [tile.elevation, render_layer], 10, Color(0.0, 0.75, 0.9)))

	# Village camp info takes priority over tree info
	if planet_map_system and planet_map_system.village_manager:
		var eid = planet_map_system.planet_id
		var village: VillageInstance = planet_map_system.village_manager.get_village_at_camp(eid, tile.position)
		if village:
			_add_village_camp_info_to_panel(village, make_centered_label)
			return

	# Tree and understory info
	if planet_map_system:
		var berry_info := planet_map_system.get_berry_info(tile.position)
		var tree = planet_map_system.get_tree_at(tile.position)
		if tree:
			_add_tree_info_to_panel(tree, make_centered_label, berry_info.has_bush)
		elif planet_map_system.has_tree_at(tile.position):
			_add_static_forest_info_to_panel(tile.position, planet_map_system, make_centered_label, berry_info.has_bush)
		if berry_info.has_bush:
			_add_berry_info_to_panel(berry_info, make_centered_label)

	# Village resource role (water source, berry bush, firewood tree)
	if planet_map_system and planet_map_system.villager_system:
		var role_info := planet_map_system.villager_system.get_resource_role_at(tile.position)
		if not role_info.is_empty():
			_add_resource_role_to_panel(role_info, planet_map_system, make_centered_label)

func _add_static_forest_info_to_panel(grid_pos: Vector2i, planet_map_system: PlanetMapSystem, make_centered_label: Callable, has_berry: bool = false) -> void:
	var tile_id: int = planet_map_system.get_static_forest_tile_id(grid_pos)
	var species_name := _species_name_for_tile(tile_id)
	var is_dead := ForestSpecies.is_dead_tree(tile_id)

	if is_dead:
		var supply: int = planet_map_system._deadwood_supply.get(grid_pos,
			ForestSpecies.wood_yield_for_tile(tile_id))
		if has_berry:
			# Condense to one line to leave room for berry info
			tile_info_section.add_child(make_centered_label.call(
				"%s (Dead)  W:%d" % [species_name, supply], 11, Color(0.75, 0.6, 0.4)
			))
		else:
			tile_info_section.add_child(make_centered_label.call(
				"%s (Dead)" % species_name, 11, Color(0.75, 0.6, 0.4)
			))
			tile_info_section.add_child(make_centered_label.call(
				"Wood: %d armloads" % supply, 10, Color(0.65, 0.5, 0.3)
			))
	else:
		tile_info_section.add_child(make_centered_label.call(
			species_name, 11, Color(0.5, 1.0, 0.5)
		))


func _species_name_for_tile(tile_id: int) -> String:
	if tile_id < 0:
		return "Tree"
	for t in ForestSpecies.MAPLE_VG:
		if tile_id == t:
			return "Maple"
	for t in ForestSpecies.MAPLE_DORM:
		if tile_id == t:
			return "Maple"
	if tile_id == ForestSpecies.OAK_VG or tile_id == ForestSpecies.OAK_DORM:
		return "Oak"
	if tile_id == ForestSpecies.BEECH_VG or tile_id == ForestSpecies.BEECH_DORM:
		return "Beech"
	if tile_id == ForestSpecies.BIRCH_VG or tile_id == ForestSpecies.BIRCH_DORM:
		return "Birch"
	return "Tree"


func _add_harvester_info_to_panel(harvester: HarvesterInstance, make_centered_label: Callable):
	tile_info_section.add_child(make_centered_label.call("SLIME MOLD", 12, Color(0.3, 0.9, 0.15)))

	tile_info_section.add_child(make_centered_label.call(
		"Logs: %d" % harvester.inventory_logs, 11, Color(0.8, 1.0, 0.6)
	))
	tile_info_section.add_child(make_centered_label.call(
		"Arteries: %d" % harvester.body_connections.size(), 11, Color(0.4, 0.85, 0.2)
	))

	var growing := 0
	var digesting := 0
	for f in harvester.feelers:
		var feeler: FeelerInstance = f as FeelerInstance
		if not feeler:
			continue
		match feeler.state:
			FeelerInstance.FeelerState.GROWING:
				growing += 1
			FeelerInstance.FeelerState.DIGESTING:
				digesting += 1

	tile_info_section.add_child(make_centered_label.call(
		"Feelers: %d" % harvester.feelers.size(), 11, Color(0.6, 0.95, 0.35)
	))
	tile_info_section.add_child(make_centered_label.call(
		"Growing:%d Digesting:%d" % [growing, digesting], 10, Color(0.5, 0.8, 0.3)
	))

func _add_tree_info_to_panel(tree: TreeInstance, make_centered_label: Callable, has_berry: bool = false):
	var stage_names = ["Seedling", "Young Sapling", "Sapling", "Young Mature", "Mature", "Very Mature", "Dormant"]
	var stage_name = stage_names[tree.growth_stage] if tree.growth_stage < stage_names.size() else "Unknown"

	var species_registry = PlantSpeciesRegistry.get_instance()
	var config = species_registry.get_species_config(tree.species)
	var species_name = config.species_name if config else "Tree"

	var tree_color = Color(0.5, 1.0, 0.5) if tree.is_alive() else Color(0.6, 0.6, 0.6)
	if has_berry:
		# Condense to one line to leave room for berry info
		tile_info_section.add_child(make_centered_label.call(
			"%s (%s)  H:%d%%" % [species_name, stage_name, int(tree.health * 100)], 11, tree_color
		))
	else:
		tile_info_section.add_child(make_centered_label.call("%s (%s)" % [species_name, stage_name], 11, tree_color))
		tile_info_section.add_child(make_centered_label.call("Health: %d%% | Age: %d ticks" % [int(tree.health * 100), tree.age_in_ticks], 10, tree_color))
		if tree.seed_production > 0.0:
			tile_info_section.add_child(make_centered_label.call("Seed Production: %.1f/tick" % tree.seed_production, 10, Color(0.8, 0.8, 0.3)))

func _add_berry_info_to_panel(berry_info: Dictionary, make_centered_label: Callable) -> void:
	if berry_info.regrowing:
		tile_info_section.add_child(make_centered_label.call(
			"Raspberry  (regrowing)", 11, Color(0.6, 0.3, 0.5)
		))
	else:
		tile_info_section.add_child(make_centered_label.call(
			"Raspberry  %d/%d picks" % [berry_info.picks_remaining, PlanetMapSystem.BERRY_MAX_PICKS],
			11, Color(0.9, 0.3, 0.5)
		))

func _add_village_camp_info_to_panel(village: VillageInstance, make_centered_label: Callable):
	var village_color = Color(1.0, 0.85, 0.4) if village.is_player_village else Color(0.9, 0.5, 0.3)
	var label = "YOUR CAMP" if village.is_player_village else "NPC CAMP"
	tile_info_section.add_child(make_centered_label.call(label, 12, village_color))
	tile_info_section.add_child(make_centered_label.call(village.village_id, 10, village_color))
	tile_info_section.add_child(make_centered_label.call("Era: %s" % village.era.replace("_", " ").capitalize(), 11, village_color))
	tile_info_section.add_child(make_centered_label.call("Pop: %d" % village.get_population(), 11, village_color))
	tile_info_section.add_child(make_centered_label.call(
		"Adults: %d | Avg Age: %.0f" % [village.get_adult_count(), village.get_average_age()], 10, village_color
	))
	tile_info_section.add_child(make_centered_label.call(
		"Health: %.0f%%" % [village.get_average_health() * 100.0], 10, village_color
	))

func _add_resource_role_to_panel(role_info: Dictionary, planet_map_system: PlanetMapSystem, make_centered_label: Callable) -> void:
	var vid: String = role_info.get("village_id", "")
	var role: String = role_info.get("role", "")
	if vid.is_empty() or role.is_empty():
		return

	var role_color := Color(0.7, 0.85, 1.0)
	var role_label := ""
	var detail := ""
	var village: VillageInstance = planet_map_system.village_manager.get_village(vid) if planet_map_system.village_manager else null

	match role:
		"water":
			role_color = Color(0.4, 0.7, 1.0)
			role_label = "WATER SOURCE"
			if village:
				detail = "Supply: %d%%" % int(village.water_stored * 100)
		"food":
			role_color = Color(0.9, 0.4, 0.5)
			role_label = "FORAGING SITE"
			if village:
				detail = "Food stored: %d%%" % int(village.food_stored * 100)
		"firewood":
			role_color = Color(0.8, 0.55, 0.3)
			role_label = "FIREWOOD SOURCE"
			if village:
				detail = "Firewood: %d%%" % int(village.firewood_stored * 100)
		"camp":
			return  # Camp already has its own panel via _add_village_camp_info_to_panel

	tile_info_section.add_child(make_centered_label.call(role_label, 11, role_color))
	tile_info_section.add_child(make_centered_label.call("Village: %s" % vid, 10, role_color))
	if not detail.is_empty():
		tile_info_section.add_child(make_centered_label.call(detail, 10, role_color))

	# Show gatherer count for this resource
	if planet_map_system.villager_system:
		var gatherers := planet_map_system.villager_system._count_gatherers(vid, role)
		if gatherers > 0:
			tile_info_section.add_child(make_centered_label.call(
				"Gatherers: %d" % gatherers, 10, role_color
			))


## Clear tile panel (when no tile selected)
func clear_tile_panel():
	if not tile_info_section:
		return
	for child in tile_info_section.get_children():
		child.queue_free()

## Helper: Create a terminal-themed label
func _make_label(text: String, font_size: int = 11, color: Color = Color(0.0, 0.85, 0.25)) -> Label:
	if ui_builder:
		return ui_builder.make_panel_label(text, font_size, color)
	else:
		# Fallback if ui_builder not available
		var label = Label.new()
		label.text = text
		label.add_theme_font_size_override("font_size", font_size)
		label.add_theme_color_override("font_color", color)
		label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
		return label
