class_name PlanetMapDebugHUD
extends Control

## Screen-space debug HUD for the planet map.
## Shows FPS, camera info, tile info, and chunk info.
## Also draws a centered crosshair.
## Toggle with F3 from PlanetMapView.

const CROSSHAIR_SIZE      := 10.0
const CROSSHAIR_GAP       := 5.0
const CROSSHAIR_COLOR     := Color(1.0, 1.0, 1.0, 0.85)
const CROSSHAIR_THICKNESS := 1.5
const HUD_TEXT_COLOR      := Color(0.0, 1.0, 0.35, 1.0)
const HUD_FONT_SIZE       := 11
const PANEL_WIDTH         := 270.0

# Set by PlanetMapView after creation
var planet_map_system: PlanetMapSystem = null
var map_viewport: SubViewport = null

var _hud_panel: PanelContainer = null
var _hud_label: Label = null

func initialize(pms: PlanetMapSystem, viewport: SubViewport) -> void:
	planet_map_system = pms
	map_viewport      = viewport

	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	z_index = 4090

	_build_panel()
	visible = false

func _build_panel() -> void:
	_hud_panel = PanelContainer.new()
	_hud_panel.name = "DebugHUDPanel"
	_hud_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE

	# Anchor to bottom-left; grow upward from that corner
	_hud_panel.anchor_left   = 0.0
	_hud_panel.anchor_top    = 1.0
	_hud_panel.anchor_right  = 0.0
	_hud_panel.anchor_bottom = 1.0
	_hud_panel.offset_left   = 10.0
	_hud_panel.offset_right  = 10.0 + PANEL_WIDTH
	_hud_panel.offset_bottom = -10.0
	_hud_panel.offset_top    = -10.0  # will be pushed up each frame by content minimum size
	_hud_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN

	var style := StyleBoxFlat.new()
	style.bg_color   = Color(0.0, 0.0, 0.0, 0.75)
	style.border_color = Color(0.0, 0.7, 0.0, 0.9)
	style.set_border_width_all(1)
	style.set_content_margin_all(8.0)
	_hud_panel.add_theme_stylebox_override("panel", style)

	add_child(_hud_panel)

	_hud_label = Label.new()
	_hud_label.name = "HUDLabel"
	_hud_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	_hud_label.add_theme_font_size_override("font_size", HUD_FONT_SIZE)
	_hud_label.add_theme_color_override("font_color", HUD_TEXT_COLOR)
	_hud_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	_hud_panel.add_child(_hud_label)

func _process(_delta: float) -> void:
	if not visible:
		return
	_update_text()
	queue_redraw()

func _update_text() -> void:
	if not _hud_label or not planet_map_system:
		return

	var camera := planet_map_system.get_camera()
	if not camera or not is_instance_valid(camera):
		_hud_label.text = "Camera: N/A"
		return

	var cam_global := camera.global_position
	var zoom       := camera.zoom

	var tile_manager := planet_map_system.tile_manager
	var cam_tm_local := tile_manager.to_local(cam_global) if tile_manager else cam_global
	var cam_tile     := PlanetMapCoordinates.world_to_grid(cam_tm_local)
	var cam_chunk    := Vector2i(cam_tile.x >> 6, cam_tile.y >> 6)

	var map_size_str := "N/A"
	if planet_map_system.map_data:
		var ms       := planet_map_system.map_data.map_size
		map_size_str  = "%d x %d" % [ms.x, ms.y]

	var mode_str     := "Chunks" if planet_map_system.using_chunks else "Tiles"
	var loaded_count := 0
	if planet_map_system.using_chunks and planet_map_system.chunk_manager:
		loaded_count = planet_map_system.chunk_manager.loaded_chunks.size()

	var sel_str  := "None"
	var sel_tile := planet_map_system.get_selected_tile()
	if sel_tile:
		var layer := sel_tile.get_render_layer()
		var keys: Array = PlanetMapTileConfig.TileType.keys()
		var type_key: String = keys[sel_tile.type] if sel_tile.type < keys.size() else "?"
		sel_str = "(%d, %d)  layer %d/%d\nelev %.3f  %s" % [
			sel_tile.position.x, sel_tile.position.y,
			layer, PlanetMapTileConfig.NUM_RENDER_LAYERS,
			sel_tile.elevation, type_key
		]

	_hud_label.text = (
		"--- DEBUG  F3 to hide ---\n"
		+ "FPS: %d\n"             % Engine.get_frames_per_second()
		+ "\n-- CAMERA --\n"
		+ "World  (%d, %d)\n"     % [int(cam_global.x), int(cam_global.y)]
		+ "Tile   (%d, %d)\n"     % [cam_tile.x, cam_tile.y]
		+ "Chunk  (%d, %d)\n"     % [cam_chunk.x, cam_chunk.y]
		+ "Zoom   %.2fx\n"        % zoom.x
		+ "\n-- SELECTION --\n"
		+ sel_str + "\n"
		+ "\n-- MAP --\n"
		+ "Mode    %s\n"          % mode_str
		+ "Size    %s\n"          % map_size_str
		+ "Chunks  %d loaded"     % loaded_count
	)

func _draw() -> void:
	if not visible:
		return
	_draw_crosshair()

func _draw_crosshair() -> void:
	var cx := size.x * 0.5
	var cy := size.y * 0.5
	var g  := CROSSHAIR_GAP
	var s  := CROSSHAIR_SIZE
	var c  := CROSSHAIR_COLOR
	var w  := CROSSHAIR_THICKNESS

	draw_line(Vector2(cx - g - s, cy), Vector2(cx - g,     cy), c, w)
	draw_line(Vector2(cx + g,     cy), Vector2(cx + g + s, cy), c, w)
	draw_line(Vector2(cx, cy - g - s), Vector2(cx, cy - g    ), c, w)
	draw_line(Vector2(cx, cy + g    ), Vector2(cx, cy + g + s), c, w)
	draw_circle(Vector2(cx, cy), 1.5, c)
