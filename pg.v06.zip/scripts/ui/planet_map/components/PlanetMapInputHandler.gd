class_name PlanetMapInputHandler
extends RefCounted

## Handles viewport input and tile selection for PlanetMapView
## Delegates to PlanetMapSystem for actual selection
## Manages mouse click detection and tile picking

const LOG_TAG := "PLANET_MAP_INPUT_HANDLER"

const MAP_SIZE = PlanetMapTileConfig.MAP_SIZE
const TILE_OFFSET = PlanetMapTileConfig.TILE_OFFSET
const MAX_LAYERS = PlanetMapTileConfig.NUM_RENDER_LAYERS  # Use NUM_RENDER_LAYERS for layer iteration

signal tile_selected(tile: MapTile)
signal laser_fired(tile: MapTile)
signal compiler_beam_fired(tile: MapTile)
signal map_left_clicked(viewport_point: Vector2)

# References (set by PlanetMapView)
var map_viewport: SubViewport = null
var planet_map_system: PlanetMapSystem = null
var layer_tilemaps: Array[TileMap] = []  # Legacy reference for tile picking

var laser_active: bool = false
var compiler_beam_active: bool = false

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, message % values if values.size() > 0 else message)

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, message % values if values.size() > 0 else message)

## Initialize with required references
func initialize(p_map_viewport: SubViewport, p_planet_map_system: PlanetMapSystem, p_layer_tilemaps: Array[TileMap]):
	map_viewport = p_map_viewport
	planet_map_system = p_planet_map_system
	layer_tilemaps = p_layer_tilemaps

## Handle viewport input events
func handle_viewport_input(event: InputEvent, parent_visible: bool) -> bool:
	if not parent_visible:
		return false

	# Handle left-click — laser mode fires laser, otherwise selects tile
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if not map_viewport or not is_instance_valid(map_viewport):
			return false
		var viewport_point := map_viewport.get_mouse_position()
		map_left_clicked.emit(viewport_point)
		if laser_active:
			_fire_laser_at_viewport_point(viewport_point)
		elif compiler_beam_active:
			_fire_compiler_beam_at_viewport_point(viewport_point)
		else:
			select_tile_from_viewport_point(viewport_point)
		return true

	# Pass scroll wheel events to camera for zooming
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP or event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			if planet_map_system and planet_map_system.handle_input_event(event):
				return true
			return false

	# Pass right-click and middle-click events to the camera system for drag
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_RIGHT or event.button_index == MOUSE_BUTTON_MIDDLE:
			if planet_map_system and planet_map_system.handle_input_event(event):
				return true
			return false

	# Pass mouse motion events to camera for dragging
	if event is InputEventMouseMotion:
		if planet_map_system and planet_map_system.handle_input_event(event):
			return true
		return false

	return false

## Select tile from viewport point
func select_tile_from_viewport_point(viewport_point: Vector2):
	var result = pick_tile_from_viewport_point(viewport_point)
	var tile = result.get("tile", null) as MapTile

	if tile:
		_log_debug("Tile selected at %s (elevation %d)", [tile.position, tile.elevation])
		tile_selected.emit(tile)
		if planet_map_system:
			planet_map_system.select_tile(tile)
	else:
		_log_debug("No tile at viewport point %s", [viewport_point])

## Fire compiler beam at the tile under the viewport point
func _fire_compiler_beam_at_viewport_point(viewport_point: Vector2):
	var result = pick_tile_from_viewport_point(viewport_point)
	var tile = result.get("tile", null) as MapTile
	if tile:
		compiler_beam_fired.emit(tile)

## Fire laser at the tile under the viewport point
func _fire_laser_at_viewport_point(viewport_point: Vector2):
	var result = pick_tile_from_viewport_point(viewport_point)
	var tile = result.get("tile", null) as MapTile
	if tile:
		laser_fired.emit(tile)

## Pick tile from viewport point.
## For chunk mode, uses system-level world-to-grid conversion against terrain source.
## For standard mode, delegates to selection_manager which iterates layer tilemaps.
func pick_tile_from_viewport_point(viewport_point: Vector2) -> Dictionary:
	if planet_map_system and planet_map_system.using_chunks:
		var tile = planet_map_system.pick_tile_chunk_mode(viewport_point)
		if tile:
			return {"tile": tile, "debug": {"chunk_mode": true, "tile_pos": tile.position}}
		return {"tile": null, "debug": {"error": "chunk_pick_failed"}}

	if planet_map_system and planet_map_system.selection_manager:
		return planet_map_system.selection_manager.pick_tile_from_viewport_point(viewport_point)

	return {"tile": null, "debug": {"error": "no_selection_manager"}}

## Old broken implementation - keeping for reference
func _pick_tile_from_viewport_point_OLD(viewport_point: Vector2) -> Dictionary:
	var debug: Dictionary = {}
	if not map_viewport or not is_instance_valid(map_viewport):
		debug["error"] = "viewport_missing"
		_log_info("ERROR: viewport_missing")
		return {"tile": null, "debug": debug}

	# Use Godot's canvas transform to properly convert viewport to world coordinates
	var canvas_transform := map_viewport.get_canvas_transform()
	var world_point := canvas_transform.affine_inverse() * viewport_point

	# Debug camera and transform
	if planet_map_system and planet_map_system.camera_controller and planet_map_system.camera_controller.camera:
		var cam = planet_map_system.camera_controller.camera
		_log_info("Pick tile: viewport=%s, world=%s", [viewport_point, world_point])
		_log_info("  Camera: pos=%s, global_pos=%s, zoom=%s", [cam.position, cam.global_position, cam.zoom])
		_log_info("  Canvas: transform=%s", [canvas_transform])
		_log_info("  Tilemaps: size=%d, planet_map_system.tile_manager.position=%s", [
			layer_tilemaps.size(),
			planet_map_system.tile_manager.position if planet_map_system.tile_manager else "null"
		])
	else:
		_log_info("Pick tile: viewport=%s, world=%s, canvas_transform=%s", [viewport_point, world_point, canvas_transform])
		_log_info("  layer_tilemaps.size=%d, planet_map_system=%s", [layer_tilemaps.size(), planet_map_system != null])

	# Check layers from highest to lowest (top to bottom) to find clicked tile
	# This makes elevated tiles clickable
	var checked_layers = 0
	for layer in range(MAX_LAYERS - 1, -1, -1):
		# Skip if no tilemap for this layer
		if layer >= layer_tilemaps.size() or not layer_tilemaps[layer] or not is_instance_valid(layer_tilemaps[layer]):
			continue

		var tile_map_node = layer_tilemaps[layer]
		checked_layers += 1

		# Convert from world space to tilemap local space
		var tilemap_global_transform := tile_map_node.get_global_transform()
		var tilemap_local := tilemap_global_transform.affine_inverse() * world_point

		if checked_layers == 1:  # Log first layer only
			_log_info("  Layer %d tilemap: pos=%s, global_pos=%s, parent=%s", [
				layer, tile_map_node.position, tile_map_node.global_position,
				tile_map_node.get_parent().name if tile_map_node.get_parent() else "null"
			])
			_log_info("    tilemap_local after transform: %s", [tilemap_local])

		var tilemap_cell := tile_map_node.local_to_map(tilemap_local)

		# For more precise hit detection, check neighboring cells
		var candidates: Array[Vector2i] = []

		# Add the primary cell and its neighbors
		for dx in range(-1, 2):
			for dy in range(-1, 2):
				var candidate := Vector2i(tilemap_cell.x + dx, tilemap_cell.y + dy)
				if candidate.x >= 0 and candidate.y >= 0 and candidate.x < MAP_SIZE.x and candidate.y < MAP_SIZE.y:
					candidates.append(candidate)

		# Find the best matching tile using polygon hit testing
		var cell := Vector2i(-1, -1)
		for candidate in candidates:
			if _is_point_inside_tile_tilemap_space(tilemap_local, candidate, tile_map_node):
				cell = candidate
				break

		# Fallback to the TileMap's primary result if no polygon match
		if cell == Vector2i(-1, -1):
			if tilemap_cell.x >= 0 and tilemap_cell.y >= 0 and tilemap_cell.x < MAP_SIZE.x and tilemap_cell.y < MAP_SIZE.y:
				cell = tilemap_cell

		# If we found a valid cell on this layer, check if it's the top layer for this tile
		if cell.x >= 0 and cell.y >= 0 and cell.x < MAP_SIZE.x and cell.y < MAP_SIZE.y:
			var tile := _get_tile_at(cell)
			if tile:
				# Only return the tile if we're on its top layer (tile.elevation == layer)
				# This ensures we click the visible top surface, not lower layers
				if tile.elevation == layer:
					debug["viewport_point"] = viewport_point
					debug["layer_clicked"] = layer
					debug["cell"] = cell
					debug["tile_elevation"] = tile.elevation
					return {"tile": tile, "debug": debug}
				# If tile exists but we're not on its top layer, skip and continue checking lower layers

	# No tile found on any layer
	debug["error"] = "no_tile_hit"
	_log_info("ERROR: No tile found on any layer!")
	return {"tile": null, "debug": debug}

## Check if a point (in TileMap local coordinates) is inside the given tile's diamond
func _is_point_inside_tile_tilemap_space(point_local: Vector2, cell: Vector2i, tilemap: TileMap) -> bool:
	if cell.x < 0 or cell.y < 0 or cell.x >= MAP_SIZE.x or cell.y >= MAP_SIZE.y:
		return false

	# Get tile center position from TileMap (this is in TileMap's local space)
	var center := tilemap.map_to_local(cell)

	# Define the diamond corners for an isometric tile
	var corners := PackedVector2Array([
		center + Vector2(0, -TILE_OFFSET.y),
		center + Vector2(TILE_OFFSET.x, 0),
		center + Vector2(0, TILE_OFFSET.y),
		center + Vector2(-TILE_OFFSET.x, 0),
	])

	return Geometry2D.is_point_in_polygon(point_local, corners)

## Get tile at grid position (delegates to planet_map_system)
func _get_tile_at(grid_pos: Vector2i) -> MapTile:
	if planet_map_system:
		return planet_map_system.get_tile_at(grid_pos)
	return null
