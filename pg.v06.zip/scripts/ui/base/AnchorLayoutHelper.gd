class_name AnchorLayoutHelper
extends RefCounted

## Helper functions for anchor-based responsive layouts.
## Use these to avoid manual position calculations and ensure consistent behavior.


## Set up a container that spans a margin area at the top of screen
## Both anchors are at top (0.0), height is set via offset_bottom
static func setup_top_margin_container(container: Control, margin_height: float, margin_left: float = 0, margin_right: float = 0) -> void:
	container.anchor_left = 0.0
	container.anchor_right = 1.0
	container.anchor_top = 0.0
	container.anchor_bottom = 0.0  # Both anchored to top
	container.offset_left = margin_left
	container.offset_right = -margin_right
	container.offset_top = 0
	container.offset_bottom = margin_height  # Height from top


## Set up a container that spans a margin area at the bottom of screen
## Both anchors are at bottom (1.0), height is set via offset_top
static func setup_bottom_margin_container(container: Control, margin_height: float, margin_left: float = 0, margin_right: float = 0) -> void:
	container.anchor_left = 0.0
	container.anchor_right = 1.0
	container.anchor_top = 1.0
	container.anchor_bottom = 1.0  # Both anchored to bottom
	container.offset_left = margin_left
	container.offset_right = -margin_right
	container.offset_top = -margin_height  # Height from bottom
	container.offset_bottom = 0


## Set up a control to fill its parent with optional margins
static func setup_full_rect_with_margins(control: Control, margin: float) -> void:
	control.set_anchors_preset(Control.PRESET_FULL_RECT)
	control.offset_left = margin
	control.offset_right = -margin
	control.offset_top = margin
	control.offset_bottom = -margin


## Create a right-aligned container within a parent panel
## Returns the HBoxContainer where content should be added
static func create_right_aligned_container(parent: Control, padding: float = 2) -> HBoxContainer:
	var margin_container = MarginContainer.new()
	margin_container.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin_container.add_theme_constant_override("margin_left", int(padding))
	margin_container.add_theme_constant_override("margin_right", int(padding))
	margin_container.add_theme_constant_override("margin_top", int(padding))
	margin_container.add_theme_constant_override("margin_bottom", int(padding))
	parent.add_child(margin_container)

	var align_container = HBoxContainer.new()
	align_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	align_container.alignment = BoxContainer.ALIGNMENT_END  # Right-align
	margin_container.add_child(align_container)

	return align_container


## Create a center-aligned container within a parent panel
## Returns the HBoxContainer where content should be added
static func create_center_aligned_container(parent: Control, padding: float = 2) -> HBoxContainer:
	var margin_container = MarginContainer.new()
	margin_container.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin_container.add_theme_constant_override("margin_left", int(padding))
	margin_container.add_theme_constant_override("margin_right", int(padding))
	margin_container.add_theme_constant_override("margin_top", int(padding))
	margin_container.add_theme_constant_override("margin_bottom", int(padding))
	parent.add_child(margin_container)

	var align_container = HBoxContainer.new()
	align_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	align_container.alignment = BoxContainer.ALIGNMENT_CENTER
	margin_container.add_child(align_container)

	return align_container
