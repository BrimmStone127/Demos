class_name ZIndexLayers
extends RefCounted

## Standardized z-index values for consistent layering across the UI.
## Use these constants instead of arbitrary z-index values.

# Background layers (-100 to -1)
const BACKGROUND_FAR = -100
const BACKGROUND_NEAR = -50
const BACKGROUND = -1

# Content layers (0 to 99)
const CONTENT_BACK = 0
const CONTENT_MIDDLE = 50
const CONTENT_FRONT = 99

# Overlay layers (100 to 499)
const OVERLAY_BACK = 100
const OVERLAY_MIDDLE = 250
const OVERLAY_FRONT = 499

# UI Panel layers (500 to 999)
const UI_PANELS = 500
const UI_PANELS_ELEVATED = 750
const UI_PANELS_TOP = 999

# Modal layers (1000 to 1999)
const MODAL_BACKDROP = 1000
const MODAL_CONTENT = 1500
const MODAL_TOP = 1999

# Debug layers (10000+)
const DEBUG = 10000
const DEBUG_OVERLAY = 50000


## Helper to get layer name for debugging
static func get_layer_name(z: int) -> String:
	if z >= DEBUG_OVERLAY: return "DEBUG_OVERLAY"
	if z >= DEBUG: return "DEBUG"
	if z >= MODAL_TOP: return "MODAL_TOP"
	if z >= MODAL_CONTENT: return "MODAL_CONTENT"
	if z >= MODAL_BACKDROP: return "MODAL_BACKDROP"
	if z >= UI_PANELS_TOP: return "UI_PANELS_TOP"
	if z >= UI_PANELS_ELEVATED: return "UI_PANELS_ELEVATED"
	if z >= UI_PANELS: return "UI_PANELS"
	if z >= OVERLAY_FRONT: return "OVERLAY_FRONT"
	if z >= OVERLAY_MIDDLE: return "OVERLAY_MIDDLE"
	if z >= OVERLAY_BACK: return "OVERLAY_BACK"
	if z >= CONTENT_FRONT: return "CONTENT_FRONT"
	if z >= CONTENT_MIDDLE: return "CONTENT_MIDDLE"
	if z >= CONTENT_BACK: return "CONTENT_BACK"
	if z >= BACKGROUND: return "BACKGROUND"
	if z >= BACKGROUND_NEAR: return "BACKGROUND_NEAR"
	return "BACKGROUND_FAR"
