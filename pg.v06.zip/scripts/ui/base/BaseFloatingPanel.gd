class_name BaseFloatingPanel
extends Panel

## Base class for floating UI panels with automatic positioning and input handling.
## Eliminates the need for manual viewport size tracking and position calculations.
##
## Usage:
##   class_name MyPanel extends BaseFloatingPanel
##   func _ready():
##       screen_region = ScreenRegion.TOP_RIGHT
##       super._ready()

enum ScreenRegion {
	TOP_LEFT,
	TOP_CENTER,
	TOP_RIGHT,
	MIDDLE_LEFT,
	MIDDLE_CENTER,
	MIDDLE_RIGHT,
	BOTTOM_LEFT,
	BOTTOM_CENTER,
	BOTTOM_RIGHT,
	CUSTOM  # For manual positioning
}

@export var screen_region: ScreenRegion = ScreenRegion.TOP_RIGHT
@export var margin: Vector2 = Vector2(20, 20)
@export var blocks_input: bool = true  # Auto-setup input blocking


func _ready() -> void:
	if blocks_input:
		_setup_input_blocking()

	z_index = ZIndexLayers.UI_PANELS

	# Apply terminal theme by default
	if has_method("_skip_terminal_theme") and call("_skip_terminal_theme"):
		pass
	else:
		TerminalTheme.apply_to_panel(self)

	_update_position()
	get_viewport().size_changed.connect(_update_position)


func _setup_input_blocking() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	gui_input.connect(_on_gui_input)


func _on_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton or event is InputEventMouseMotion:
		accept_event()


func _update_position() -> void:
	if screen_region == ScreenRegion.CUSTOM:
		return  # Let subclass handle custom positioning

	# Wait for size to be calculated
	await get_tree().process_frame

	var viewport_size = get_viewport_rect().size

	match screen_region:
		ScreenRegion.TOP_LEFT:
			position = Vector2(margin.x, margin.y)
		ScreenRegion.TOP_CENTER:
			position = Vector2((viewport_size.x - size.x) / 2, margin.y)
		ScreenRegion.TOP_RIGHT:
			position = Vector2(viewport_size.x - size.x - margin.x, margin.y)
		ScreenRegion.MIDDLE_LEFT:
			position = Vector2(margin.x, (viewport_size.y - size.y) / 2)
		ScreenRegion.MIDDLE_CENTER:
			position = Vector2((viewport_size.x - size.x) / 2, (viewport_size.y - size.y) / 2)
		ScreenRegion.MIDDLE_RIGHT:
			position = Vector2(viewport_size.x - size.x - margin.x, (viewport_size.y - size.y) / 2)
		ScreenRegion.BOTTOM_LEFT:
			position = Vector2(margin.x, viewport_size.y - size.y - margin.y)
		ScreenRegion.BOTTOM_CENTER:
			position = Vector2((viewport_size.x - size.x) / 2, viewport_size.y - size.y - margin.y)
		ScreenRegion.BOTTOM_RIGHT:
			position = Vector2(viewport_size.x - size.x - margin.x, viewport_size.y - size.y - margin.y)


## Force position update (call after changing size or screen_region)
func refresh_position() -> void:
	_update_position()
