class_name SaveListDialog
extends CanvasLayer

## Modal dialog displaying a scrollable list of save slots.
## Supports MODE_SAVE (save to new or overwrite) and MODE_LOAD (load existing).

const LOG_TAG := "SAVE_LIST_DIALOG"

enum Mode { SAVE, LOAD }

signal save_selected(slot_id: String, is_new: bool)
signal load_selected(slot_id: String)
signal closed

var _mode: int
var _save_manager: SaveGameManager
var _panel: Panel
var _content_panel: Panel
var _scroll_container: ScrollContainer
var _slot_list: VBoxContainer
var _confirm_overlay: Panel
var _pending_action_slot: String = ""
var _pending_action_type: String = ""


func _init(mode: int, save_manager: SaveGameManager):
	_mode = mode
	_save_manager = save_manager
	name = "SaveListDialog"
	layer = 100
	_build_ui()


func _build_ui():
	# Full-screen dark overlay
	_panel = Panel.new()
	_panel.size_flags_horizontal = Control.SIZE_FILL
	_panel.size_flags_vertical = Control.SIZE_FILL
	_panel.anchor_right = 1.0
	_panel.anchor_bottom = 1.0
	var bg_style = StyleBoxFlat.new()
	bg_style.bg_color = Color(0.0, 0.0, 0.0, 0.75)
	_panel.add_theme_stylebox_override("panel", bg_style)
	_panel.gui_input.connect(_on_bg_input)
	add_child(_panel)

	# Centered content panel
	_content_panel = Panel.new()
	_content_panel.name = "ContentPanel"
	_content_panel.anchors_preset = Control.PRESET_CENTER
	_content_panel.anchor_left = 0.5
	_content_panel.anchor_top = 0.5
	_content_panel.anchor_right = 0.5
	_content_panel.anchor_bottom = 0.5
	_content_panel.offset_left = -350
	_content_panel.offset_top = -250
	_content_panel.offset_right = 350
	_content_panel.offset_bottom = 250
	_panel.add_child(_content_panel)

	var main_vbox = VBoxContainer.new()
	main_vbox.position = Vector2(20, 16)
	main_vbox.custom_minimum_size = Vector2(660, 468)
	main_vbox.add_theme_constant_override("separation", 10)
	_content_panel.add_child(main_vbox)

	# Header
	var header = HBoxContainer.new()
	header.size_flags_horizontal = Control.SIZE_FILL
	main_vbox.add_child(header)

	var title_label = Label.new()
	title_label.text = "SAVE GAME" if _mode == Mode.SAVE else "LOAD GAME"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_label.add_theme_font_size_override("font_size", 22)
	title_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	title_label.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	header.add_child(title_label)

	var close_button = Button.new()
	close_button.text = "X"
	close_button.custom_minimum_size = Vector2(32, 32)
	TerminalTheme.apply_to_button(close_button)
	close_button.pressed.connect(_close)
	header.add_child(close_button)

	# Separator
	var sep = HSeparator.new()
	sep.add_theme_color_override("separator", Color(0.0, 0.4, 0.1))
	main_vbox.add_child(sep)

	# New save button (save mode only)
	if _mode == Mode.SAVE:
		var new_save_btn = Button.new()
		new_save_btn.text = "+ NEW SAVE"
		new_save_btn.custom_minimum_size = Vector2(0, 36)
		new_save_btn.size_flags_horizontal = Control.SIZE_FILL
		TerminalTheme.apply_to_button(new_save_btn)
		new_save_btn.add_theme_font_size_override("font_size", 14)
		new_save_btn.pressed.connect(_on_new_save_pressed)
		main_vbox.add_child(new_save_btn)

	# Scroll container with save list
	_scroll_container = ScrollContainer.new()
	_scroll_container.size_flags_horizontal = Control.SIZE_FILL
	_scroll_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll_container.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_scroll_container.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	main_vbox.add_child(_scroll_container)

	_slot_list = VBoxContainer.new()
	_slot_list.size_flags_horizontal = Control.SIZE_FILL
	_slot_list.add_theme_constant_override("separation", 6)
	_scroll_container.add_child(_slot_list)

	_populate_list()


func _populate_list():
	# Clear existing
	for child in _slot_list.get_children():
		child.queue_free()

	var saves := _save_manager.list_saves()

	if saves.size() == 0:
		var empty_label = Label.new()
		empty_label.text = "No saved games" if _mode == Mode.LOAD else "No existing saves"
		empty_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		empty_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
		empty_label.add_theme_font_size_override("font_size", 14)
		empty_label.add_theme_color_override("font_color", Color(0.4, 0.4, 0.4))
		_slot_list.add_child(empty_label)
		return

	for save_data in saves:
		var slot_panel := SaveSlotPanel.new(save_data, _save_manager)
		slot_panel.slot_selected.connect(_on_slot_selected)
		slot_panel.slot_deleted.connect(_on_slot_delete_requested)
		slot_panel.slot_renamed.connect(_on_slot_renamed)
		_slot_list.add_child(slot_panel)


func _on_new_save_pressed():
	var new_slot_id := _save_manager.get_next_slot_id()
	save_selected.emit(new_slot_id, true)
	_close()


func _on_slot_selected(slot_id: String):
	if _mode == Mode.LOAD:
		load_selected.emit(slot_id)
		_close()
	else:
		# Save mode: confirm overwrite
		_show_confirm("Overwrite this save?", "overwrite", slot_id)


func _on_slot_delete_requested(slot_id: String):
	_show_confirm("Delete this save?", "delete", slot_id)


func _on_slot_renamed(slot_id: String, new_name: String):
	if _save_manager:
		_save_manager.rename_slot(slot_id, new_name)


func _show_confirm(message: String, action_type: String, slot_id: String):
	_pending_action_type = action_type
	_pending_action_slot = slot_id

	if _confirm_overlay and is_instance_valid(_confirm_overlay):
		_confirm_overlay.queue_free()

	_confirm_overlay = Panel.new()
	_confirm_overlay.anchor_right = 1.0
	_confirm_overlay.anchor_bottom = 1.0
	var overlay_style = StyleBoxFlat.new()
	overlay_style.bg_color = Color(0.0, 0.0, 0.0, 0.85)
	_confirm_overlay.add_theme_stylebox_override("panel", overlay_style)
	_confirm_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	_content_panel.add_child(_confirm_overlay)

	var confirm_vbox = VBoxContainer.new()
	confirm_vbox.anchors_preset = Control.PRESET_CENTER
	confirm_vbox.anchor_left = 0.5
	confirm_vbox.anchor_top = 0.5
	confirm_vbox.anchor_right = 0.5
	confirm_vbox.anchor_bottom = 0.5
	confirm_vbox.offset_left = -120
	confirm_vbox.offset_top = -50
	confirm_vbox.offset_right = 120
	confirm_vbox.offset_bottom = 50
	confirm_vbox.add_theme_constant_override("separation", 16)
	_confirm_overlay.add_child(confirm_vbox)

	var msg_label = Label.new()
	msg_label.text = message
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	msg_label.add_theme_font_size_override("font_size", 16)
	msg_label.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	confirm_vbox.add_child(msg_label)

	var btn_hbox = HBoxContainer.new()
	btn_hbox.alignment = BoxContainer.ALIGNMENT_CENTER
	btn_hbox.add_theme_constant_override("separation", 20)
	confirm_vbox.add_child(btn_hbox)

	var yes_btn = Button.new()
	yes_btn.text = "YES"
	yes_btn.custom_minimum_size = Vector2(80, 32)
	TerminalTheme.apply_to_button(yes_btn)
	yes_btn.pressed.connect(_on_confirm_yes)
	btn_hbox.add_child(yes_btn)

	var no_btn = Button.new()
	no_btn.text = "NO"
	no_btn.custom_minimum_size = Vector2(80, 32)
	TerminalTheme.apply_to_button(no_btn)
	no_btn.pressed.connect(_on_confirm_no)
	btn_hbox.add_child(no_btn)


func _on_confirm_yes():
	var slot_id := _pending_action_slot
	var action := _pending_action_type
	_dismiss_confirm()

	if action == "overwrite":
		save_selected.emit(slot_id, false)
		_close()
	elif action == "delete":
		if _save_manager:
			_save_manager.delete_slot(slot_id)
		_populate_list()


func _on_confirm_no():
	_dismiss_confirm()


func _dismiss_confirm():
	_pending_action_slot = ""
	_pending_action_type = ""
	if _confirm_overlay and is_instance_valid(_confirm_overlay):
		_confirm_overlay.queue_free()
		_confirm_overlay = null


func _on_bg_input(event: InputEvent):
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		# Only close if click is outside content panel
		var local_pos := _content_panel.get_local_mouse_position()
		var rect := Rect2(Vector2.ZERO, _content_panel.size)
		if not rect.has_point(local_pos):
			_close()
			get_viewport().set_input_as_handled()


func _unhandled_key_input(event: InputEvent):
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		if _confirm_overlay and is_instance_valid(_confirm_overlay):
			_dismiss_confirm()
		else:
			_close()
		get_viewport().set_input_as_handled()


func _close():
	closed.emit()
	queue_free()
