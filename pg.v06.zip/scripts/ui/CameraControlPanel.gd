class_name CameraControlPanel
extends Panel

signal celestial_body_clicked(body: Node2D)
signal reset_camera_requested
signal stop_tracking_requested

const MIN_ICON_SIZE := 8
const MAX_ICON_SIZE := 18
const STAR_ICON_SIZE := 28
const ICON_SPACING := 4
const PANEL_PADDING := 6
const SELECTION_COLOR := Color(0.0, 1.0, 0.3, 1.0)  # Terminal green

var sun_texture: Texture2D = preload("res://assets/sun1.png")

var icon_container: HBoxContainer
var celestial_bodies: Array = []
var body_buttons: Array[Button] = []
var selected_body: Node2D = null

func _init():
	name = "CameraControlPanel"
	custom_minimum_size = Vector2(50, 40)

	# Black background to match other panels
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.0, 0.0, 0.0, 1.0)
	style.border_width_left = 0
	style.border_width_right = 0
	style.border_width_top = 0
	style.border_width_bottom = 0
	add_theme_stylebox_override("panel", style)

	# Container for celestial body icons
	icon_container = HBoxContainer.new()
	icon_container.position = Vector2(PANEL_PADDING, PANEL_PADDING)
	icon_container.add_theme_constant_override("separation", ICON_SPACING)
	icon_container.alignment = BoxContainer.ALIGNMENT_CENTER
	add_child(icon_container)

	# Consume input to prevent click-through
	mouse_filter = Control.MOUSE_FILTER_STOP
	gui_input.connect(_on_gui_input)

func _ready():
	_update_position()
	get_viewport().size_changed.connect(_on_viewport_size_changed)

func _on_gui_input(event: InputEvent):
	if event is InputEventMouseButton or event is InputEventMouseMotion:
		accept_event()

func _update_position():
	_update_panel_size()
	var viewport_size = get_viewport_rect().size
	var margin = 20
	position = Vector2(margin, viewport_size.y - size.y - margin)

func _on_viewport_size_changed():
	_update_position()

func set_star_system(star_system: Node2D):
	"""Populate the panel with icons for the star and planets"""
	_clear_icons()
	celestial_bodies.clear()
	selected_body = null

	if not star_system or not is_instance_valid(star_system):
		visible = false
		return

	# Add star first - use actual star texture
	var star_color := Color.YELLOW
	if "star_color" in star_system:
		star_color = star_system.star_color
	else:
		# Try to get color from first Sprite2D child
		for child in star_system.get_children():
			if child is Sprite2D:
				star_color = child.modulate
				break

	celestial_bodies.append(star_system)
	_add_star_icon(star_system, star_color)

	# Collect planets and find size range for normalization
	var planets: Array = []
	if star_system.has_method("get_planets_array"):
		planets = star_system.get_planets_array()

	if planets.size() > 0:
		# Find min/max planet sizes for normalization
		var min_size := 999.0
		var max_size := 0.0
		for planet in planets:
			if "planet_size" in planet:
				min_size = min(min_size, planet.planet_size)
				max_size = max(max_size, planet.planet_size)

		# Normalize and add planet icons
		for planet in planets:
			celestial_bodies.append(planet)
			var planet_color = planet.base_color if planet.base_color else Color.GRAY
			var icon_size = _calculate_icon_size(planet.planet_size if "planet_size" in planet else 0.05, min_size, max_size)
			var tooltip = planet.planet_name if planet.planet_name else "Planet"
			_add_planet_icon(planet, planet_color, icon_size, tooltip)

	_update_panel_size()
	_update_position()
	visible = celestial_bodies.size() > 0

func set_selected_body(body: Node2D):
	"""Update which celestial body is shown as selected"""
	selected_body = body
	_update_selection_visuals()

func _update_selection_visuals():
	"""Update visual state of all icons based on selection"""
	for i in range(celestial_bodies.size()):
		if i >= body_buttons.size():
			break
		var button = body_buttons[i]
		var body = celestial_bodies[i]
		var is_selected = (body == selected_body) or (selected_body and body is StarSystem and selected_body == body)

		# Find the icon within the button's CenterContainer
		var center = button.get_child(0) if button.get_child_count() > 0 else null
		if center and center.get_child_count() > 0:
			var icon = center.get_child(0)
			if icon is CircleIcon:
				icon.selected = is_selected
				icon.queue_redraw()
			elif icon is TextureRect:
				# For star texture, add/update selection indicator
				_update_star_selection(button, is_selected)

func _update_star_selection(button: Button, is_selected: bool):
	"""Update star icon selection state"""
	# Look for existing selection ring or create one
	var ring_name = "SelectionRing"
	var existing_ring = button.get_node_or_null(ring_name)

	if is_selected:
		if not existing_ring:
			var ring = SelectionRing.new()
			ring.name = ring_name
			ring.set_anchors_preset(Control.PRESET_FULL_RECT)
			ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
			button.add_child(ring)
	else:
		if existing_ring:
			existing_ring.queue_free()

func _calculate_icon_size(body_size: float, min_size: float, max_size: float) -> int:
	"""Normalize body size to icon size range"""
	if max_size <= min_size:
		return (MIN_ICON_SIZE + MAX_ICON_SIZE) >> 1

	var normalized = (body_size - min_size) / (max_size - min_size)
	return int(MIN_ICON_SIZE + normalized * (MAX_ICON_SIZE - MIN_ICON_SIZE))

func _add_star_icon(star_system: Node2D, color: Color):
	var button = _create_icon_button(STAR_ICON_SIZE)

	# Use CenterContainer to vertically center the star
	var center = CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	button.add_child(center)

	# Use actual star texture
	var star_sprite = TextureRect.new()
	star_sprite.texture = sun_texture
	star_sprite.custom_minimum_size = Vector2(STAR_ICON_SIZE, STAR_ICON_SIZE)
	star_sprite.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	star_sprite.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	star_sprite.modulate = color
	star_sprite.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(star_sprite)

	var tooltip = star_system.star_name if "star_name" in star_system else "Star"
	button.tooltip_text = tooltip
	button.pressed.connect(_on_body_clicked.bind(star_system))

	icon_container.add_child(button)
	body_buttons.append(button)

func _add_planet_icon(planet: Node2D, color: Color, icon_size: int, tooltip: String):
	var button = _create_icon_button(icon_size)

	# Use CenterContainer to vertically center the planet
	var center = CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	button.add_child(center)

	# Create circular icon for planet
	var circle = CircleIcon.new()
	circle.color = color
	circle.custom_minimum_size = Vector2(icon_size, icon_size)
	circle.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(circle)

	button.tooltip_text = tooltip
	button.pressed.connect(_on_body_clicked.bind(planet))

	icon_container.add_child(button)
	body_buttons.append(button)

func _create_icon_button(icon_size: int) -> Button:
	var button = Button.new()
	# All buttons same height (star size) for vertical centering alignment
	button.custom_minimum_size = Vector2(icon_size + 2, STAR_ICON_SIZE + 2)
	button.focus_mode = Control.FOCUS_NONE

	# Minimal button style
	var empty_style = StyleBoxEmpty.new()
	button.add_theme_stylebox_override("normal", empty_style)
	button.add_theme_stylebox_override("hover", empty_style)
	button.add_theme_stylebox_override("pressed", empty_style)
	button.add_theme_stylebox_override("focus", empty_style)

	return button

func _on_body_clicked(body: Node2D):
	set_selected_body(body)
	emit_signal("celestial_body_clicked", body)

func _clear_icons():
	for button in body_buttons:
		if is_instance_valid(button):
			icon_container.remove_child(button)
			button.queue_free()
	body_buttons.clear()

func _update_panel_size():
	var num_icons = body_buttons.size()
	if num_icons == 0:
		custom_minimum_size = Vector2(50, 40)
		return

	var total_width = PANEL_PADDING * 2
	for button in body_buttons:
		total_width += int(button.custom_minimum_size.x)
	total_width += (num_icons - 1) * ICON_SPACING

	var height = (PANEL_PADDING * 2) + STAR_ICON_SIZE + 2
	custom_minimum_size = Vector2(total_width, height)
	size = custom_minimum_size

# Legacy methods for compatibility
func set_tracking(_tracking: bool):
	pass

func set_camera_moved(_moved: bool):
	pass


# Inner class for drawing planet circles with selection ring
class CircleIcon extends Control:
	var color: Color = Color.WHITE
	var selected: bool = false

	func _draw():
		var center_pos = size / 2
		var radius = min(size.x, size.y) / 2

		# Draw selection ring if selected
		if selected:
			var ring_radius = radius + 2
			draw_arc(center_pos, ring_radius, 0, TAU, 32, Color(0.0, 1.0, 0.3), 2.0, true)

		# Draw the planet circle
		draw_circle(center_pos, radius, color)


# Inner class for drawing selection ring around star
class SelectionRing extends Control:
	func _draw():
		var center_pos = size / 2
		var radius = min(size.x, size.y) / 2 - 1
		draw_arc(center_pos, radius, 0, TAU, 32, Color(0.0, 1.0, 0.3), 2.0, true)
