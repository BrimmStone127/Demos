class_name ThemeSelectorPanel
extends PanelContainer

## Reusable UI component for selecting visual themes
##
## Displays a dropdown with all available themes from VariantManager.
## Auto-syncs selection with VariantManager and emits signal on change.
##
## Usage:
##   var selector = ThemeSelectorPanel.new()
##   add_child(selector)
##   selector.theme_selected.connect(_on_theme_selected)

const LOG_TAG := "THEME_SELECTOR"

## Signal emitted when user selects a theme
signal theme_selected(theme_name: String)

## UI elements
var _vbox: VBoxContainer
var _label: Label
var _dropdown: OptionButton
var _description_label: Label

## Reference to variant manager
var _variant_manager: VariantManager = null


func _ready():
	_setup_ui()
	_connect_to_variant_manager()
	_populate_dropdown()


func _setup_ui():
	# Apply terminal theme styling (PanelContainer uses same stylebox as Panel)
	add_theme_stylebox_override("panel", TerminalTheme.get_panel_style())

	# Main container
	_vbox = VBoxContainer.new()
	_vbox.add_theme_constant_override("separation", 4)
	add_child(_vbox)

	# Title label
	_label = Label.new()
	_label.text = "Theme"
	_label.add_theme_font_size_override("font_size", 12)
	_label.add_theme_color_override("font_color", Color(0.6, 0.8, 0.6))
	_vbox.add_child(_label)

	# Dropdown
	_dropdown = OptionButton.new()
	_dropdown.custom_minimum_size = Vector2(120, 24)
	_dropdown.item_selected.connect(_on_dropdown_selected)
	_vbox.add_child(_dropdown)

	# Description label
	_description_label = Label.new()
	_description_label.text = ""
	_description_label.add_theme_font_size_override("font_size", 10)
	_description_label.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
	_description_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	_description_label.custom_minimum_size = Vector2(120, 0)
	_vbox.add_child(_description_label)


func _connect_to_variant_manager():
	_variant_manager = VariantManager.get_instance()
	_variant_manager.theme_changed.connect(_on_external_theme_change)


func _populate_dropdown():
	_dropdown.clear()

	var theme_names = _variant_manager.get_all_theme_names()
	var current_name = _variant_manager.get_current_theme_name()
	var current_index := 0

	for i in range(theme_names.size()):
		var theme_name = theme_names[i]
		_dropdown.add_item(theme_name.capitalize(), i)
		if theme_name == current_name:
			current_index = i

	_dropdown.select(current_index)
	_update_description()


func _on_dropdown_selected(index: int):
	var theme_names = _variant_manager.get_all_theme_names()
	if index < 0 or index >= theme_names.size():
		return

	var selected_name = theme_names[index]
	if _variant_manager.set_theme(selected_name):
		_update_description()
		theme_selected.emit(selected_name)
		GameLog.info(LOG_TAG, "User selected theme: '%s'" % selected_name)


func _on_external_theme_change(theme_name: String):
	# External code changed the theme - update dropdown to match
	var theme_names = _variant_manager.get_all_theme_names()
	for i in range(theme_names.size()):
		if theme_names[i] == theme_name:
			if _dropdown.selected != i:
				_dropdown.select(i)
			break
	_update_description()


func _update_description():
	var current_theme = _variant_manager.get_current_theme()
	if current_theme:
		_description_label.text = current_theme.description
	else:
		_description_label.text = ""


## Refresh the dropdown (call after adding/removing themes)
func refresh():
	_populate_dropdown()


## Get currently selected theme name
func get_selected_theme() -> String:
	return _variant_manager.get_current_theme_name()


## Set the selected theme programmatically
func set_selected_theme(theme_name: String) -> bool:
	return _variant_manager.set_theme(theme_name)
