class_name SaveSlotPanel
extends PanelContainer

## Displays a single save slot with thumbnail, metadata, and action buttons.
##
## Usage:
##   var panel = SaveSlotPanel.new(save_summary, save_manager)
##   add_child(panel)
##   panel.slot_selected.connect(_on_slot_selected)

const LOG_TAG := "SAVE_SLOT_PANEL"

signal slot_selected(slot_id: String)
signal slot_deleted(slot_id: String)
signal slot_renamed(slot_id: String, new_name: String)

var _slot_id: String
var _save_data: Dictionary
var _save_manager: SaveGameManager

var _hbox: HBoxContainer
var _thumbnail_rect: TextureRect
var _info_vbox: VBoxContainer
var _name_label: Label
var _name_edit: LineEdit
var _detail_label: Label
var _timestamp_label: Label
var _action_vbox: VBoxContainer
var _rename_button: Button
var _delete_button: Button
var _is_editing_name := false

var _style_normal: StyleBoxFlat
var _style_hover: StyleBoxFlat


func _init(save_data: Dictionary, save_manager: SaveGameManager = null):
	_save_data = save_data
	_save_manager = save_manager
	_slot_id = str(save_data.get("slot_id", ""))


func _ready():
	_setup_styles()
	_setup_ui()
	_load_thumbnail()


func get_slot_id() -> String:
	return _slot_id


func _setup_styles():
	_style_normal = StyleBoxFlat.new()
	_style_normal.bg_color = Color(0.08, 0.08, 0.08, 0.95)
	_style_normal.border_color = Color(0.0, 0.4, 0.1)
	_style_normal.set_border_width_all(1)
	_style_normal.set_content_margin_all(8)

	_style_hover = StyleBoxFlat.new()
	_style_hover.bg_color = Color(0.12, 0.15, 0.12, 0.95)
	_style_hover.border_color = TerminalTheme.terminal_green
	_style_hover.set_border_width_all(1)
	_style_hover.set_content_margin_all(8)

	add_theme_stylebox_override("panel", _style_normal)
	custom_minimum_size = Vector2(0, 80)
	mouse_filter = Control.MOUSE_FILTER_STOP


func _setup_ui():
	_hbox = HBoxContainer.new()
	_hbox.add_theme_constant_override("separation", 12)
	add_child(_hbox)

	# Thumbnail
	_thumbnail_rect = TextureRect.new()
	_thumbnail_rect.custom_minimum_size = Vector2(120, 68)
	_thumbnail_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_thumbnail_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	_thumbnail_rect.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_hbox.add_child(_thumbnail_rect)

	# Placeholder for no thumbnail
	var placeholder_style := StyleBoxFlat.new()
	placeholder_style.bg_color = Color(0.05, 0.05, 0.05)
	placeholder_style.border_color = Color(0.0, 0.3, 0.1)
	placeholder_style.set_border_width_all(1)
	var placeholder := Panel.new()
	placeholder.custom_minimum_size = Vector2(120, 68)
	placeholder.size = Vector2(120, 68)
	placeholder.add_theme_stylebox_override("panel", placeholder_style)
	_thumbnail_rect.add_child(placeholder)

	# Info column
	_info_vbox = VBoxContainer.new()
	_info_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_info_vbox.add_theme_constant_override("separation", 2)
	_hbox.add_child(_info_vbox)

	# Save name (display)
	_name_label = Label.new()
	_name_label.text = str(_save_data.get("save_name", "Unnamed Save"))
	_name_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	_name_label.add_theme_font_size_override("font_size", 16)
	_name_label.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	_info_vbox.add_child(_name_label)

	# Save name (edit)
	_name_edit = LineEdit.new()
	_name_edit.text = _name_label.text
	_name_edit.visible = false
	_name_edit.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	_name_edit.add_theme_font_size_override("font_size", 16)
	_name_edit.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	TerminalTheme.apply_to_line_edit(_name_edit)
	_name_edit.text_submitted.connect(_on_name_submitted)
	_name_edit.focus_exited.connect(_on_name_edit_focus_lost)
	_info_vbox.add_child(_name_edit)

	# Detail line (day + seed)
	_detail_label = Label.new()
	var day := int(_save_data.get("game_days_elapsed", 0))
	var seed_val := int(_save_data.get("current_seed", 0))
	_detail_label.text = "Day %d  |  Seed %d" % [day, seed_val]
	_detail_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	_detail_label.add_theme_font_size_override("font_size", 12)
	_detail_label.add_theme_color_override("font_color", Color(0.0, 0.6, 0.15))
	_info_vbox.add_child(_detail_label)

	# Timestamp
	_timestamp_label = Label.new()
	_timestamp_label.text = _format_timestamp(float(_save_data.get("timestamp", 0.0)))
	_timestamp_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	_timestamp_label.add_theme_font_size_override("font_size", 11)
	_timestamp_label.add_theme_color_override("font_color", Color(0.4, 0.4, 0.4))
	_info_vbox.add_child(_timestamp_label)

	# Action buttons column
	_action_vbox = VBoxContainer.new()
	_action_vbox.add_theme_constant_override("separation", 4)
	_action_vbox.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_hbox.add_child(_action_vbox)

	_rename_button = Button.new()
	_rename_button.text = "REN"
	_rename_button.custom_minimum_size = Vector2(50, 28)
	_rename_button.add_theme_font_size_override("font_size", 11)
	TerminalTheme.apply_to_button(_rename_button)
	_rename_button.pressed.connect(_on_rename_pressed)
	_action_vbox.add_child(_rename_button)

	_delete_button = Button.new()
	_delete_button.text = "DEL"
	_delete_button.custom_minimum_size = Vector2(50, 28)
	_delete_button.add_theme_font_size_override("font_size", 11)
	TerminalTheme.apply_to_button(_delete_button)
	_delete_button.add_theme_color_override("font_color", Color(0.8, 0.2, 0.2))
	_delete_button.pressed.connect(_on_delete_pressed)
	_action_vbox.add_child(_delete_button)


func _load_thumbnail():
	if _save_manager == null:
		return
	var image := _save_manager.load_thumbnail(_slot_id)
	if image == null:
		return
	var tex := ImageTexture.create_from_image(image)
	_thumbnail_rect.texture = tex
	# Remove placeholder when thumbnail loaded
	for child in _thumbnail_rect.get_children():
		child.queue_free()


func _on_rename_pressed():
	if _is_editing_name:
		return
	_is_editing_name = true
	_name_label.visible = false
	_name_edit.visible = true
	_name_edit.text = _name_label.text
	_name_edit.grab_focus()
	_name_edit.select_all()


func _on_name_submitted(new_name: String):
	_finish_rename(new_name)


func _on_name_edit_focus_lost():
	if _is_editing_name:
		_finish_rename(_name_edit.text)


func _finish_rename(new_name: String):
	_is_editing_name = false
	_name_edit.visible = false
	_name_label.visible = true
	new_name = new_name.strip_edges()
	if new_name.is_empty():
		return
	if new_name != _name_label.text:
		_name_label.text = new_name
		slot_renamed.emit(_slot_id, new_name)


func _on_delete_pressed():
	slot_deleted.emit(_slot_id)


func _gui_input(event: InputEvent):
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if not _is_editing_name:
			slot_selected.emit(_slot_id)
			get_viewport().set_input_as_handled()


func _notification(what: int):
	if what == NOTIFICATION_MOUSE_ENTER:
		add_theme_stylebox_override("panel", _style_hover)
	elif what == NOTIFICATION_MOUSE_EXIT:
		add_theme_stylebox_override("panel", _style_normal)


func _format_timestamp(unix_time: float) -> String:
	if unix_time <= 0.0:
		return "Unknown date"
	var dt := Time.get_datetime_dict_from_unix_time(int(unix_time))
	return "%04d-%02d-%02d %02d:%02d" % [dt.year, dt.month, dt.day, dt.hour, dt.minute]
