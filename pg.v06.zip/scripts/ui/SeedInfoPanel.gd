class_name SeedInfoPanel
extends Panel

signal seed_loaded(seed_value: int)
signal panel_closed

var seed_label: Label
var seed_input: LineEdit
var copy_button: Button
var current_seed: int = 0

func _apply_terminal_font(label: Label) -> void:
	label.add_theme_font_override("font", TerminalTheme.get_terminal_font())

func _init(initial_seed: int = 0):
	current_seed = initial_seed
	name = "SeedInfoPanel"
	custom_minimum_size = Vector2(220, 85)
	size_flags_horizontal = Control.SIZE_SHRINK_END

	_build_ui()
	_update_seed_display(current_seed)

func _ready():
	# Position panel at bottom right after scene is ready
	call_deferred("_adjust_position")

func _build_ui():
	# Container for seed info
	var seed_vbox = VBoxContainer.new()
	seed_vbox.size_flags_vertical = Control.SIZE_FILL
	seed_vbox.size_flags_horizontal = Control.SIZE_FILL
	seed_vbox.position = Vector2(8, 8)
	seed_vbox.custom_minimum_size = Vector2(204, 69)
	add_child(seed_vbox)

	# Container for seed info and copy button
	var seed_info_container = HBoxContainer.new()
	seed_info_container.size_flags_horizontal = Control.SIZE_FILL
	seed_vbox.add_child(seed_info_container)

	# Seed info label
	seed_label = Label.new()
	seed_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	seed_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	_apply_terminal_font(seed_label)
	seed_info_container.add_child(seed_label)

	# Copy seed button
	copy_button = Button.new()
	copy_button.name = "CopyButton"
	copy_button.text = "Copy"
	copy_button.tooltip_text = "Copy seed to clipboard"
	copy_button.custom_minimum_size.x = 45
	copy_button.pressed.connect(_on_copy_pressed)
	seed_info_container.add_child(copy_button)

	# Small spacer
	var spacer = Control.new()
	spacer.custom_minimum_size.y = 5
	seed_vbox.add_child(spacer)

	# Container for input and button
	var input_container = HBoxContainer.new()
	input_container.size_flags_horizontal = Control.SIZE_FILL
	seed_vbox.add_child(input_container)

	# Seed input field
	seed_input = LineEdit.new()
	seed_input.placeholder_text = "Enter seed number..."
	seed_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	input_container.add_child(seed_input)

	# Load seed button
	var load_button = Button.new()
	load_button.text = "Load"
	load_button.pressed.connect(_on_load_pressed)
	input_container.add_child(load_button)

func _adjust_position():
	await get_tree().process_frame
	var viewport_size = get_viewport_rect().size
	
	var margin = 10
	
	var x_pos = min(viewport_size.x - size.x - margin,
					viewport_size.x - custom_minimum_size.x - margin)
	var y_pos = min(viewport_size.y - size.y - margin,
					viewport_size.y - custom_minimum_size.y - margin)
	
	x_pos = max(margin, x_pos)
	y_pos = max(margin, y_pos)
	
	position = Vector2(x_pos, y_pos)
	
	# Connect to window resize events to keep position updated
	if not get_viewport().size_changed.is_connected(_on_viewport_size_changed):
		get_viewport().size_changed.connect(_on_viewport_size_changed)

func _on_viewport_size_changed():
	var viewport_size = get_viewport_rect().size
	
	var margin = 10
	
	var x_pos = min(viewport_size.x - size.x - margin,
					viewport_size.x - custom_minimum_size.x - margin)
	var y_pos = min(viewport_size.y - size.y - margin,
					viewport_size.y - custom_minimum_size.y - margin)
	
	x_pos = max(margin, x_pos)
	y_pos = max(margin, y_pos)
	
	position = Vector2(x_pos, y_pos)

func _on_copy_pressed():
	# Copy the current seed to the clipboard
	if OS.has_feature("web"):
		JavaScriptBridge.eval("navigator.clipboard.writeText('%s').catch(e => {})" % str(current_seed))
	else:
		DisplayServer.clipboard_set(str(current_seed))

	# Provide visual feedback by temporarily changing the button text
	var original_text = copy_button.text
	copy_button.text = "✓"
	copy_button.add_theme_color_override("font_color", Color(0.2, 1.0, 0.2))
	
	# Restore after a short delay
	var timer = get_tree().create_timer(1.0)
	await timer.timeout
	if copy_button and is_instance_valid(copy_button):
		copy_button.text = original_text
		copy_button.remove_theme_color_override("font_color")

func _on_load_pressed():
	var input_text = seed_input.text.strip_edges()
	if input_text.is_valid_int():
		var seed_value = input_text.to_int()
		current_seed = seed_value
		emit_signal("seed_loaded", seed_value)
	else:
		# Provide feedback for invalid input
		seed_input.text = ""
		seed_input.placeholder_text = "Invalid! Enter a number"

func update_seed_info(seed_value: int, star_type: String):
	current_seed = seed_value
	_update_seed_display(seed_value, star_type)

func _update_seed_display(seed_value: int, star_type: String = ""):
	if star_type.is_empty():
		seed_label.text = "Seed: " + str(seed_value)
	else:
		seed_label.text = "Seed: " + str(seed_value) + " | Type: " + star_type
