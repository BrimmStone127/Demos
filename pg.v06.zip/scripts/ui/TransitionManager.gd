class_name TransitionManager
extends CanvasLayer

signal transition_completed

var transition_overlay: ColorRect
var is_transitioning: bool = false
var time_manager: TimeManager = null

func _init():
	name = "TransitionManager"
	# Screen transitions - narrative sequences render above this
	layer = UILayers.TRANSITIONS

func _ready():
	# Create the transition overlay
	transition_overlay = ColorRect.new()
	transition_overlay.color = Color(0, 0, 0, 0)  # Start transparent
	transition_overlay.anchor_right = 1.0
	transition_overlay.anchor_bottom = 1.0
	transition_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(transition_overlay)
	
	# Initially hide the overlay
	transition_overlay.visible = false

func set_time_manager(manager: TimeManager):
	time_manager = manager

func _scaled_duration(duration: float) -> float:
	var time_scale = time_manager.get_time_scale() if time_manager else Engine.time_scale
	if time_scale < 0.01:
		time_scale = 1.0
	return duration * time_scale

# Fade to black, then fade to transparent after delay
func fade_transition(fade_out_duration: float = 0.5, black_duration: float = 2.0, fade_in_duration: float = 1.0):
	if is_transitioning:
		return
		
	is_transitioning = true
	transition_overlay.visible = true
	transition_overlay.mouse_filter = Control.MOUSE_FILTER_STOP  # Block input during transition
	
	# Create the transition tween
	var tween = create_tween()
	
	# Phase 1: Fade to black
	tween.tween_property(transition_overlay, "color:a", 1.0, _scaled_duration(fade_out_duration))
	tween.tween_property(transition_overlay, "color:a", 1.0, _scaled_duration(black_duration))  # Stay black
	tween.tween_property(transition_overlay, "color:a", 0.0, _scaled_duration(fade_in_duration))  # Fade in game
	
	# When transition is complete
	await tween.finished
	
	transition_overlay.visible = false
	transition_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	is_transitioning = false
	
	emit_signal("transition_completed")

# Simple fade to black (for start screen exit)
func fade_to_black(duration: float = 0.5):
	if is_transitioning:
		return
		
	is_transitioning = true
	transition_overlay.visible = true
	transition_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	transition_overlay.color.a = 0.0  # Start transparent
	
	var tween = create_tween()
	var adjusted = _scaled_duration(duration)
	tween.tween_property(transition_overlay, "color:a", 1.0, adjusted)
	
	await tween.finished
	# Don't hide overlay or reset transitioning state - let caller handle it

# Simple fade from black (for game start)
func fade_from_black(duration: float = 1.0):
	# Make sure we're set up properly
	transition_overlay.visible = true
	transition_overlay.color = Color(0, 0, 0, 1.0)  # Start black
	transition_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	is_transitioning = true
	
	var tween = create_tween()
	var adjusted = _scaled_duration(duration)
	tween.tween_property(transition_overlay, "color:a", 0.0, adjusted)
	
	await tween.finished
	
	transition_overlay.visible = false
	transition_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	is_transitioning = false
	
	emit_signal("transition_completed")

# Set black screen (useful for instant transitions)
func set_black():
	transition_overlay.visible = true
	transition_overlay.color.a = 1.0
	transition_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	is_transitioning = true

# Set transparent (clear screen)
func set_transparent():
	transition_overlay.visible = false
	transition_overlay.color.a = 0.0
	transition_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	is_transitioning = false
