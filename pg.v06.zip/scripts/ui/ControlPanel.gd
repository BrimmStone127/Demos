class_name ControlPanel
extends Panel

signal new_system_requested
signal options_requested  # Keep the options signal for the ESC key fallback
signal ai_toggle_requested

var ai_button: Button
var ai_active: bool = false

func _init():
	name = "ControlPanel"
	custom_minimum_size = Vector2(120, 60)  # Compact size

	# Pure black background
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.0, 0.0, 0.0, 1.0)
	style.border_width_left = 0
	style.border_width_right = 0
	style.border_width_top = 0
	style.border_width_bottom = 0
	add_theme_stylebox_override("panel", style)

	# Use a VBoxContainer to stack buttons vertically
	var container = VBoxContainer.new()
	container.size_flags_horizontal = Control.SIZE_FILL
	container.size_flags_vertical = Control.SIZE_FILL
	container.anchor_right = 1.0
	container.anchor_bottom = 1.0
	container.add_theme_constant_override("separation", 4)
	add_child(container)

	# Add some top margin
	var top_margin = Control.new()
	top_margin.custom_minimum_size = Vector2(0, 6)
	container.add_child(top_margin)

	# Center container for buttons
	var button_container = HBoxContainer.new()
	button_container.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	button_container.add_theme_constant_override("separation", 4)
	container.add_child(button_container)

	# AI Explorer button (SEARCH)
	ai_button = Button.new()
	ai_button.text = "SEARCH"
	ai_button.custom_minimum_size = Vector2(52, 22)
	ai_button.focus_mode = Control.FOCUS_NONE
	ai_button.pressed.connect(_on_ai_button_pressed)
	button_container.add_child(ai_button)

	# New System button (JUMP)
	var new_button = Button.new()
	new_button.text = "JUMP"
	new_button.custom_minimum_size = Vector2(44, 22)
	new_button.focus_mode = Control.FOCUS_NONE
	new_button.pressed.connect(func(): emit_signal("new_system_requested"))
	button_container.add_child(new_button)

func _ready():
	# Position at top right after scene is ready
	call_deferred("_adjust_position")

func _adjust_position():
	await get_tree().process_frame

	var viewport_size = get_viewport_rect().size
	var margin = 20  # Margin from screen edges

	# Position in bottom right with margin
	position = Vector2(
		viewport_size.x - size.x - margin,
		viewport_size.y - size.y - margin
	)

	# Connect to window resize events
	get_viewport().size_changed.connect(_on_viewport_size_changed)

func _on_viewport_size_changed():
	var viewport_size = get_viewport_rect().size
	var margin = 20  # Margin from screen edges

	# Position in bottom right with margin
	position = Vector2(
		viewport_size.x - size.x - margin,
		viewport_size.y - size.y - margin
	)

func _on_ai_button_pressed():
	emit_signal("ai_toggle_requested")

func set_ai_active(active: bool):
	ai_active = active

	if active:
		# Red style when active
		var active_style = StyleBoxFlat.new()
		active_style.bg_color = Color(0.6, 0.0, 0.0, 0.9)  # Dark red
		active_style.border_color = Color(1.0, 0.0, 0.0)   # Bright red border
		active_style.border_width_top = 2
		active_style.border_width_bottom = 2
		active_style.border_width_left = 2
		active_style.border_width_right = 2

		var active_hover = StyleBoxFlat.new()
		active_hover.bg_color = Color(0.7, 0.0, 0.0, 0.9)
		active_hover.border_color = Color(1.0, 0.0, 0.0)
		active_hover.border_width_top = 2
		active_hover.border_width_bottom = 2
		active_hover.border_width_left = 2
		active_hover.border_width_right = 2

		ai_button.add_theme_stylebox_override("normal", active_style)
		ai_button.add_theme_stylebox_override("hover", active_hover)
		ai_button.add_theme_stylebox_override("pressed", active_style)
		ai_button.text = "STOP"
	else:
		# Reset to default terminal theme
		ai_button.add_theme_stylebox_override("normal", TerminalTheme.get_button_style())
		ai_button.add_theme_stylebox_override("hover", TerminalTheme.get_button_hover_style())
		ai_button.add_theme_stylebox_override("pressed", TerminalTheme.get_button_pressed_style())
		ai_button.text = "SEARCH"
