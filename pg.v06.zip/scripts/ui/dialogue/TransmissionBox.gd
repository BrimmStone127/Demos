class_name TransmissionBox
extends DialogueBox

func _init():
	super._init()
	
	# Customize for transmissions
	box_width = 650
	box_height = 240
	custom_minimum_size = Vector2(box_width, box_height)

func _customize_appearance():
	# Set transmission-specific styling
	var transmission_style = StyleBoxFlat.new()
	transmission_style.bg_color = Color(0.05, 0.05, 0.05, 0.95)
	transmission_style.border_color = Color(1.0, 0.6, 0.0)  # Orange border
	transmission_style.border_width_top = 2
	transmission_style.border_width_bottom = 2
	transmission_style.border_width_left = 2
	transmission_style.border_width_right = 2
	transmission_style.corner_radius_top_left = 4
	transmission_style.corner_radius_top_right = 4
	transmission_style.corner_radius_bottom_left = 4
	transmission_style.corner_radius_bottom_right = 4
	add_theme_stylebox_override("panel", transmission_style)

# Override the _ready function to increase font size
func _ready():
	super._ready()
	
	# Double the font size for the text label
	if text_label:
		text_label.add_theme_font_size_override("font_size", 24)  # Default is 12, so 24 is double
	
	# Also customize the speaker label font size
	if speaker_label:
		speaker_label.add_theme_font_size_override("font_size", 22)  # A bit larger and bold-looking
