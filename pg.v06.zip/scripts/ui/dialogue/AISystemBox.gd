class_name AISystemBox
extends DialogueBox

# Additional UI elements for AI system
var ai_header: HBoxContainer
var ai_status_label: Label
var ai_personality_indicator: TextureRect

func _init():
	super._init()
	
	# Customize for AI system
	box_width = 600
	box_height = 220
	custom_minimum_size = Vector2(box_width, box_height)

func _create_ui():
	super._create_ui()
	
	# Insert AI-specific header before speaker
	ai_header = HBoxContainer.new()
	ai_header.size_flags_horizontal = Control.SIZE_FILL
	main_container.add_child(ai_header)
	main_container.move_child(ai_header, 1)  # After margin container
	
	# AI System label with icon
	var ai_label = Label.new()
	ai_label.text = "◉ SHIP AI SYSTEM"
	ai_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	ai_label.add_theme_font_size_override("font_size", 12)
	ai_label.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	ai_header.add_child(ai_label)
	
	# Spacer
	var spacer = Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ai_header.add_child(spacer)
	
	# AI Status
	ai_status_label = Label.new()
	ai_status_label.text = "ONLINE"
	ai_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ai_status_label.add_theme_font_size_override("font_size", 10)
	ai_status_label.add_theme_color_override("font_color", Color(0.0, 1.0, 0.0))
	ai_header.add_child(ai_status_label)
	
	# Add separator
	var separator = HSeparator.new()
	separator.add_theme_color_override("separator", TerminalTheme.terminal_green)
	main_container.add_child(separator)
	main_container.move_child(separator, 2)

func _customize_appearance():
	# Set AI-specific styling
	var ai_style = StyleBoxFlat.new()
	ai_style.bg_color = Color(0.02, 0.08, 0.02, 0.95)  # Slightly green tint
	ai_style.border_color = TerminalTheme.terminal_green
	ai_style.border_width_top = 2
	ai_style.border_width_bottom = 2
	ai_style.border_width_left = 2
	ai_style.border_width_right = 2
	ai_style.corner_radius_top_left = 4
	ai_style.corner_radius_top_right = 4
	ai_style.corner_radius_bottom_left = 4
	ai_style.corner_radius_bottom_right = 4
	add_theme_stylebox_override("panel", ai_style)
	
	# Customize based on AI personality
	if dialogue_data and dialogue_data.metadata.has("ai_personality"):
		_apply_personality_styling()
	
	# Add subtle AI processing effect
	_add_ai_processing_effect()

func _apply_personality_styling():
	var personality = dialogue_data.metadata.get("ai_personality", "neutral")
	
	match personality:
		"friendly":
			speaker_label.add_theme_color_override("font_color", Color(0.3, 1.0, 0.3))
		"concerned":
			speaker_label.add_theme_color_override("font_color", Color(1.0, 0.8, 0.0))
			ai_status_label.text = "ANALYZING"
			ai_status_label.add_theme_color_override("font_color", Color(1.0, 0.8, 0.0))
		"alert":
			speaker_label.add_theme_color_override("font_color", Color(1.0, 0.5, 0.0))
			ai_status_label.text = "ALERT"
			ai_status_label.add_theme_color_override("font_color", Color(1.0, 0.5, 0.0))
		"warning":
			speaker_label.add_theme_color_override("font_color", Color(1.0, 0.3, 0.3))
			ai_status_label.text = "WARNING"
			ai_status_label.add_theme_color_override("font_color", Color(1.0, 0.3, 0.3))
		"critical":
			speaker_label.add_theme_color_override("font_color", Color(1.0, 0.0, 0.0))
			ai_status_label.text = "CRITICAL"
			ai_status_label.add_theme_color_override("font_color", Color(1.0, 0.0, 0.0))
			_add_critical_effects()

func _add_critical_effects():
	# Add blinking effect for critical messages
	var blink_tween = create_tween()
	blink_tween.set_loops()
	blink_tween.tween_property(ai_header, "modulate", Color(1.0, 0.5, 0.5), 0.3)
	blink_tween.tween_property(ai_header, "modulate", Color.WHITE, 0.3)

func _add_ai_processing_effect():
	# Add subtle pulsing effect to indicate AI processing
	var pulse_tween = create_tween()
	pulse_tween.set_loops()
	pulse_tween.tween_property(self, "modulate", Color(1.1, 1.1, 1.1), 1.5)
	pulse_tween.tween_property(self, "modulate", Color(1.0, 1.0, 1.0), 1.5)

# Override typewriter effect for AI-specific behavior
func _on_type_timer_timeout():
	super._on_type_timer_timeout()
	
	# Add occasional pauses to simulate AI processing
	if randf() < 0.05:  # 5% chance per character
		type_timer.stop()
		await get_tree().create_timer(randf_range(0.1, 0.3)).timeout
		if is_typing:  # Check if still typing
			type_timer.start()

# Override text completion for AI-specific behavior
func _on_text_complete():
	super._on_text_complete()
	
	# Add AI completion indicator
	if not dialogue_data.has_choices():
		_add_ai_completion_indicator()

func _add_ai_completion_indicator():
	# Add a green dot to indicate AI has finished speaking
	var completion_indicator = Label.new()
	completion_indicator.text = "●"
	completion_indicator.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	completion_indicator.add_theme_font_size_override("font_size", 12)
	text_label.get_parent().add_child(completion_indicator)
	
	# Make it fade in
	completion_indicator.modulate.a = 0.0
	var fade_tween = create_tween()
	fade_tween.tween_property(completion_indicator, "modulate:a", 1.0, 0.3)

# Override choice selection for AI-specific feedback
func _on_choice_pressed(choice_index: int):
	# Add confirmation feedback
	var feedback_label = Label.new()
	feedback_label.text = "Choice registered..."
	feedback_label.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	feedback_label.add_theme_font_size_override("font_size", 10)
	choices_container.add_child(feedback_label)
	
	# Briefly show feedback before closing
	await get_tree().create_timer(0.5).timeout
	
	super._on_choice_pressed(choice_index)
