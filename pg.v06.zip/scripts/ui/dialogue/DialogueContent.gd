class_name DialogueContent
extends Resource

# Static arrays for different types of dialogue content

# AI System Messages organized by category
const AI_SYSTEM_MESSAGES = {
	"routine": [
		"All systems are operating within normal parameters.",
		"Navigation systems have been updated with new stellar cartography data.",
		"Life support systems are functioning optimally.",
		"Energy reserves are at maximum capacity.",
		"Quantum drive efficiency is at 97.3%",
		"Initiating automatic system diagnostics...",
		"Stellar classification algorithms have been upgraded."
	],
	
	"analysis": [
		"Detecting unusual stellar activity in the current sector.",
		"Analyzing atmospheric composition of nearby celestial bodies...",
		"Detecting gravitational anomalies in the vicinity.",
		"Scanning for potentially habitable worlds...",
		"Temporal displacement sensors are picking up chronometer fluctuations."
	],
	
	"warnings": [
		"Warning: Cosmic radiation levels are approaching threshold.",
		"Recommending course correction to avoid asteroid field.",
		"Caution: Hull stress indicators showing minor fluctuations.",
		"Alert: Unknown energy signature detected in long-range sensors."
	],
	
	"communications": [
		"Communications array is receiving faint signals from unknown origin.",
		"Signal strength improving - attempting to decode transmission.",
		"Long-range communications system performing routine maintenance.",
		"Establishing quantum entanglement link with nearest relay station."
	],
	
	"navigation": [
		"Calculating optimal trajectory for next system jump.",
		"Updating star charts with recent gravitational survey data.",
		"Course correction complete - maintaining optimal heading.",
		"Hyperspace jump coordinates have been verified and locked."
	]
}

# AI Personalities that affect message delivery
const AI_PERSONALITIES = {
	"neutral": {
		"weight": 40,  # How often this personality appears (percentage)
		"description": "Standard operational mode"
	},
	"friendly": {
		"weight": 25,
		"description": "Helpful and reassuring tone"
	},
	"concerned": {
		"weight": 15,
		"description": "Cautious and analytical"
	},
	"alert": {
		"weight": 12,
		"description": "Heightened awareness mode"
	},
	"warning": {
		"weight": 8,
		"description": "Critical situation protocols"
	}
}

# Transmission Sources and their typical message types
const TRANSMISSION_SOURCES = {
	"stations": [
		{
			"name": "Space Station Alpha-7",
			"location": "Alpha Centauri System",
			"type": "civilian"
		},
		{
			"name": "Deep Space Observatory",
			"location": "Observation Post Gamma",
			"type": "scientific"
		},
		{
			"name": "Mining Platform Delta-9",
			"location": "Belt Mining Sector",
			"type": "industrial"
		},
		{
			"name": "Research Outpost Zeta",
			"location": "Frontier Zone",
			"type": "scientific"
		}
	],
	
	"ships": [
		{
			"name": "Merchant Vessel 'Star Trader'",
			"location": "Trading Route Nexus",
			"type": "commercial"
		},
		{
			"name": "Colony Ship 'New Horizon'",
			"location": "Kepler-442 System",
			"type": "civilian"
		},
		{
			"name": "Research Vessel 'Discovery'",
			"location": "Unknown System",
			"type": "scientific"
		},
		{
			"name": "Patrol Cruiser 'Vigilant'",
			"location": "Sector Patrol",
			"type": "military"
		},
		{
			"name": "Cargo Freighter 'Heavy Lifter'",
			"location": "Industrial Corridor",
			"type": "commercial"
		}
	],
	
	"emergency": [
		{
			"name": "Emergency Beacon",
			"location": "Automated System",
			"type": "emergency"
		},
		{
			"name": "Distress Signal",
			"location": "Unknown",
			"type": "emergency"
		},
		{
			"name": "SOS Transmitter",
			"location": "Deep Space",
			"type": "emergency"
		}
	],
	
	"mysterious": [
		{
			"name": "Unknown Vessel",
			"location": "Deep Space - Origin Unknown",
			"type": "unknown"
		},
		{
			"name": "Unidentified Signal",
			"location": "Galactic Edge",
			"type": "unknown"
		},
		{
			"name": "Encrypted Transmission",
			"location": "Source Masked",
			"type": "unknown"
		}
	]
}

# Message templates organized by source type
const TRANSMISSION_MESSAGES = {
	"civilian": [
		"This is {source} to all vessels in the sector. We are experiencing technical difficulties and request immediate assistance.",
		"Attention nearby ships: We have supplies available for trade. Docking bay 7 is open for business.",
		"Warning to all vessels: Space weather conditions are deteriorating. Seek shelter immediately.",
		"This is {source}. Our life support systems are failing. Please send help!",
		"To any vessel receiving this: We have refugees aboard and are running low on supplies."
	],
	
	"commercial": [
		"Warning to all ships: pirates have been spotted in the outer asteroid belt. Exercise extreme caution.",
		"Attention traders: New trade routes have opened through the Centauri corridor.",
		"Commercial vessels be advised: cargo inspections are now mandatory at checkpoint Delta.",
		"This is {source}. We're hauling volatile materials - please maintain safe distance.",
		"Alert: Market prices for rare minerals have increased 200% at the next port."
	],
	
	"scientific": [
		"Attention: We are detecting unusual gravitational waves emanating from the galactic core. Stay alert.",
		"Fascinating! We've discovered what appears to be artificial structures orbiting the third planet.",
		"Research teams, please note: We've identified a new species of space-dwelling organisms.",
		"Warning: Our experiments have created a temporary spatial anomaly. Keep your distance.",
		"This is {source}. We're releasing a probe - please avoid coordinates X-127, Y-443."
	],
	
	"military": [
		"All civilian vessels, please maintain minimum safe distance from the quarantine zone.",
		"This is military patrol requesting identification from vessel bearing 127 mark 4.",
		"Attention all ships: Military exercises in progress. Navigation hazard in effect.",
		"Civilian traffic advisory: Secure corridor Alpha-7 is temporarily restricted.",
		"This is {source}. Scanning all vessels for contraband. Prepare for inspection."
	],
	
	"industrial": [
		"Heads up, space farers. We've struck a rich vein of rare minerals. Expecting increased traffic.",
		"Industrial warning: We're venting super-heated gases. Maintain 50km clearance.",
		"This is {source}. Heavy machinery operation in progress. Navigation hazard zone established.",
		"Attention: We're deploying mining drones in sector 7-G. Please adjust course accordingly.",
		"Notice: Scheduled maintenance on fusion reactor. Expect power fluctuations in local grid."
	],
	
	"emergency": [
		"Mayday! Mayday! We are losing life support and need immediate evacuation assistance!",
		"SOS! Hull breach detected! Requesting immediate assistance!",
		"Emergency! Emergency! We're caught in a gravity well and engines are failing!",
		"This is an automated distress signal. Life support critical. Medical assistance required.",
		"Catastrophic system failure! All hands abandon ship! Repeat, all hands abandon ship!"
	],
	
	"unknown": [
		"...transmission heavily distorted... can anyone hear this... something is following us...",
		"[ENCRYPTED] ...cannot decode... partial signal... warning... they are not what they seem...",
		"Static interference... coordinates [CORRUPTED]... do not approach... repeat, do not...",
		"Unknown signal pattern detected... translation algorithms failing... origin impossible...",
		"[SIGNAL FRAGMENTING] ...beyond the rim... ancient... they're coming back..."
	]
}

# Response options for different contexts
const AI_RESPONSE_OPTIONS = [
	["Acknowledged", "Run diagnostics", "More details"],
	["Understood", "Elaborate", "Dismiss"],
	["Copy that", "Investigation required", "File report"],
	["Confirmed", "Begin analysis", "Ignore for now"],
	["Received", "Priority assessment", "Standard protocol"]
]

const TRANSMISSION_RESPONSE_OPTIONS = [
	["Acknowledge transmission", "Request more information", "Decline to respond"],
	["Copy, standing by", "Offer assistance", "Report to authorities"],
	["Message received", "Respond with position", "Maintain radio silence"],
	["Understood", "Request clarification", "End transmission"],
	["Roger that", "Provide aid if possible", "Avoid engagement"]
]

# Static methods for generating dialogue

# Get a random AI message with specified category preference
static func get_random_ai_message(category_preference: String = "") -> Dictionary:
	var category: String
	var message: String
	
	if category_preference.is_empty() or not AI_SYSTEM_MESSAGES.has(category_preference):
		# Pick random category
		var categories = AI_SYSTEM_MESSAGES.keys()
		category = categories[randi() % categories.size()]
	else:
		category = category_preference
	
	var messages = AI_SYSTEM_MESSAGES[category]
	message = messages[randi() % messages.size()]
	
	return {
		"message": message,
		"category": category
	}

# Get a random AI personality based on weights
static func get_random_ai_personality() -> String:
	var total_weight = 0
	for personality in AI_PERSONALITIES:
		total_weight += AI_PERSONALITIES[personality].weight
	
	var random_value = randi() % total_weight
	var current_weight = 0
	
	for personality in AI_PERSONALITIES:
		current_weight += AI_PERSONALITIES[personality].weight
		if random_value < current_weight:
			return personality
	
	return "neutral"  # Fallback

# Get a random transmission source and message
static func get_random_transmission() -> Dictionary:
	# First, pick a source category
	var source_categories = TRANSMISSION_SOURCES.keys()
	var category = source_categories[randi() % source_categories.size()]
	
	# Then pick a specific source from that category
	var sources = TRANSMISSION_SOURCES[category]
	var source = sources[randi() % sources.size()]
	
	# Get messages for this source type
	var source_type = source.type
	var messages = TRANSMISSION_MESSAGES[source_type]
	var message_template = messages[randi() % messages.size()]
	
	# Replace {source} placeholder with actual source name
	var message = message_template.replace("{source}", source.name)
	
	return {
		"sender": source.name,
		"message": message,
		"origin": source.location,
		"type": source_type
	}

# Get random response options for AI
static func get_random_ai_responses() -> Array:
	return AI_RESPONSE_OPTIONS[randi() % AI_RESPONSE_OPTIONS.size()]

# Get random response options for transmissions
static func get_random_transmission_responses() -> Array:
	return TRANSMISSION_RESPONSE_OPTIONS[randi() % TRANSMISSION_RESPONSE_OPTIONS.size()]

# Check if a message should have choices based on type and randomness
static func should_have_choices(dialogue_type: String) -> bool:
	match dialogue_type:
		"ai":
			return randf() < 0.3  # 30% chance for AI
		"transmission":
			return randf() < 0.4  # 40% chance for transmissions
		_:
			return false
