class_name DialogueChoice
extends Resource

## Rich dialogue choice with optional stat requirements.
## Can be used alongside simple string choices for backward compatibility.
##
## Example usage:
##   # Simple choice (no requirements)
##   var choice1 = DialogueChoice.create("Tell me more.")
##
##   # Choice with stat requirement
##   var choice2 = DialogueChoice.create_with_requirement(
##       "I can fix that for you.",
##       "technical", 5
##   )
##
##   # Choice with success chance (for future use)
##   var choice3 = DialogueChoice.new()
##   choice3.text = "[Persuade] Let me through."
##   choice3.stat_name = "charisma"
##   choice3.stat_minimum = 3
##   choice3.success_chance = 0.65  # 65% chance

# What the player sees in the dialogue UI
@export var text: String = ""

# Where this choice leads (dialogue ID or empty for end)
@export var next_dialogue_id: String = ""

# Stat requirement (optional)
@export var stat_name: String = ""        # Empty = no requirement
@export var stat_minimum: int = 0         # Minimum stat value needed

# Success probability (1.0 = always succeeds when requirements met)
@export var success_chance: float = 1.0

# Alternative path if check fails
@export var failure_dialogue_id: String = ""

# Optional: text to show if requirement not met (greyed out option)
@export var locked_text: String = ""

# Optional metadata for game logic
@export var metadata: Dictionary = {}

# Tags for filtering/categorization (e.g., "aggressive", "peaceful", "lie")
@export var tags: Array[String] = []


func has_requirement() -> bool:
	return stat_name != ""


func has_success_chance() -> bool:
	return success_chance < 1.0


func has_failure_branch() -> bool:
	return failure_dialogue_id != ""


# Check if player can select this choice (meets stat requirement)
func can_select(player_stats: CharacterStats) -> bool:
	if not has_requirement():
		return true
	if not player_stats:
		return false
	return player_stats.meets_requirement(stat_name, stat_minimum)


# Roll for success (call after can_select returns true)
func roll_success() -> bool:
	if success_chance >= 1.0:
		return true
	return randf() <= success_chance


# Get the dialogue ID based on success/failure
func get_result_dialogue_id(success: bool) -> String:
	if success:
		return next_dialogue_id
	return failure_dialogue_id if failure_dialogue_id else next_dialogue_id


# Get display text (shows locked_text if player can't select)
func get_display_text(player_stats: CharacterStats = null) -> String:
	if player_stats and not can_select(player_stats) and locked_text:
		return locked_text
	return text


# Format text with stat info for display (e.g., "[Charisma 5] ...")
func get_formatted_text(player_stats: CharacterStats = null, show_chance: bool = false) -> String:
	var display = text

	if has_requirement():
		var player_value = player_stats.get_stat(stat_name) if player_stats else 0
		var _req_met = can_select(player_stats) if player_stats else false

		# Format: [StatName X/Y] or [StatName X]
		var stat_display = stat_name.capitalize()
		if player_stats:
			display = "[%s %d/%d] %s" % [stat_display, player_value, stat_minimum, text]
		else:
			display = "[%s %d] %s" % [stat_display, stat_minimum, text]

		if show_chance and has_success_chance():
			display = "[%d%%] %s" % [int(success_chance * 100), display]

	return display


# Serialization
func to_dict() -> Dictionary:
	return {
		"text": text,
		"next_dialogue_id": next_dialogue_id,
		"stat_name": stat_name,
		"stat_minimum": stat_minimum,
		"success_chance": success_chance,
		"failure_dialogue_id": failure_dialogue_id,
		"locked_text": locked_text,
		"metadata": metadata,
		"tags": tags
	}


static func from_dict(data: Dictionary) -> DialogueChoice:
	var choice = DialogueChoice.new()
	choice.text = data.get("text", "")
	choice.next_dialogue_id = data.get("next_dialogue_id", "")
	choice.stat_name = data.get("stat_name", "")
	choice.stat_minimum = data.get("stat_minimum", 0)
	choice.success_chance = data.get("success_chance", 1.0)
	choice.failure_dialogue_id = data.get("failure_dialogue_id", "")
	choice.locked_text = data.get("locked_text", "")
	choice.metadata = data.get("metadata", {})
	var tag_array = data.get("tags", [])
	choice.tags.assign(tag_array)
	return choice


# Factory methods
static func create(choice_text: String, next_id: String = "") -> DialogueChoice:
	var choice = DialogueChoice.new()
	choice.text = choice_text
	choice.next_dialogue_id = next_id
	return choice


static func create_with_requirement(choice_text: String, required_stat: String, min_value: int, next_id: String = "") -> DialogueChoice:
	var choice = DialogueChoice.new()
	choice.text = choice_text
	choice.stat_name = required_stat
	choice.stat_minimum = min_value
	choice.next_dialogue_id = next_id
	return choice
