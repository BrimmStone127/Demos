class_name Conversation
extends RefCounted

## A dialogue tree - multiple dialogue nodes connected by choices.
##
## Example usage:
##   var convo = Conversation.new()
##   convo.add_dialogue("start", "Hello traveler.", ["Who are you?", "Goodbye."])
##   convo.add_dialogue("who", "I am the keeper of this place.")
##   convo.add_dialogue("bye", "Safe travels.")
##
##   # Link choices to next dialogues
##   convo.link_choice("start", 0, "who")   # "Who are you?" -> "who"
##   convo.link_choice("start", 1, "bye")   # "Goodbye." -> "bye"
##
##   convo.start()
##   print(convo.get_current_text())  # "Hello traveler."
##   convo.select_choice(0)           # Player picks "Who are you?"
##   print(convo.get_current_text())  # "I am the keeper of this place."

signal dialogue_changed(dialogue_id: String)
signal conversation_ended

# All dialogues in this conversation, keyed by ID
var _dialogues: Dictionary = {}  # dialogue_id -> DialogueData

# Current position in the conversation
var _current_id: String = ""
var _start_id: String = ""

# Is the conversation active?
var is_active: bool = false


# Add a dialogue node
func add_dialogue(id: String, speaker: String, text: String, choices: Array = []) -> DialogueData:
	var data = DialogueData.new()
	data.dialogue_id = id
	data.speaker = speaker
	data.text = text

	# Convert simple string choices to DialogueChoice objects
	for choice in choices:
		if choice is String:
			data.add_dialogue_choice(DialogueChoice.create(choice))
		elif choice is DialogueChoice:
			data.add_dialogue_choice(choice)

	_dialogues[id] = data

	# First dialogue added becomes the start
	if _start_id == "":
		_start_id = id

	return data


# Add a pre-built DialogueData
func add_dialogue_data(data: DialogueData):
	if data.dialogue_id == "":
		push_warning("DialogueData has no dialogue_id, cannot add to conversation")
		return
	_dialogues[data.dialogue_id] = data
	if _start_id == "":
		_start_id = data.dialogue_id


# Link a choice to the next dialogue
func link_choice(from_id: String, choice_index: int, to_id: String):
	var dialogue = _dialogues.get(from_id)
	if not dialogue:
		push_warning("Dialogue '%s' not found" % from_id)
		return

	if choice_index < 0 or choice_index >= dialogue.choices.size():
		push_warning("Choice index %d out of range for dialogue '%s'" % [choice_index, from_id])
		return

	var choice = dialogue.choices[choice_index]
	if choice is DialogueChoice:
		choice.next_dialogue_id = to_id
	elif choice is String:
		# Convert to DialogueChoice
		var dc = DialogueChoice.create(choice, to_id)
		dialogue.choices[choice_index] = dc


# Set which dialogue to start from
func set_start(dialogue_id: String):
	_start_id = dialogue_id


# Start the conversation
func start(from_id: String = ""):
	if from_id != "":
		_current_id = from_id
	else:
		_current_id = _start_id

	if _current_id == "" or not _dialogues.has(_current_id):
		push_warning("Cannot start conversation: invalid start dialogue")
		return

	is_active = true
	dialogue_changed.emit(_current_id)


# Get current dialogue data
func get_current() -> DialogueData:
	return _dialogues.get(_current_id)


# Get current dialogue text
func get_current_text() -> String:
	var current = get_current()
	return current.text if current else ""


# Get current speaker
func get_current_speaker() -> String:
	var current = get_current()
	return current.speaker if current else ""


# Get available choices for current dialogue
func get_choices() -> Array:
	var current = get_current()
	if not current:
		return []

	var choice_texts: Array = []
	for i in range(current.choices.size()):
		choice_texts.append(current.get_choice(i))
	return choice_texts


# Get number of choices
func get_choice_count() -> int:
	var current = get_current()
	return current.get_choice_count() if current else 0


# Select a choice and advance
func select_choice(index: int):
	var current = get_current()
	if not current:
		return

	if index < 0 or index >= current.choices.size():
		push_warning("Choice index %d out of range" % index)
		return

	var choice_data = current.get_choice_data(index)
	if choice_data and choice_data.next_dialogue_id != "":
		_current_id = choice_data.next_dialogue_id
		dialogue_changed.emit(_current_id)
	else:
		# No next dialogue - end conversation
		end()


# Advance to next dialogue (for dialogues without choices)
func advance():
	if get_choice_count() > 0:
		# Has choices, don't auto-advance
		return
	end()


# End the conversation
func end():
	is_active = false
	_current_id = ""
	conversation_ended.emit()


# Check if conversation has a dialogue
func has_dialogue(id: String) -> bool:
	return _dialogues.has(id)


# Get all dialogue IDs
func get_dialogue_ids() -> Array:
	return _dialogues.keys()


# Jump directly to a dialogue (useful for game logic)
func go_to(dialogue_id: String):
	if not _dialogues.has(dialogue_id):
		push_warning("Dialogue '%s' not found" % dialogue_id)
		return
	_current_id = dialogue_id
	dialogue_changed.emit(_current_id)
