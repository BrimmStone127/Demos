class_name DialogueData
extends Resource

## Dialogue data container supporting both simple and stat-based choices.
## Choices can be plain strings (backward compatible) or DialogueChoice objects.

@export var speaker: String = ""
@export var text: String = ""
@export var choices: Array = []  # Can contain String or DialogueChoice

# Unique ID for this dialogue (for branching/referencing)
@export var dialogue_id: String = ""

var dialogue_type: int = -1

@export var metadata: Dictionary = {}

@export var auto_close_time: float = 0.0
@export var typing_speed: float = 0.05
@export var allow_skip: bool = true

@export var speaker_voice: AudioStream = null
@export var sound_effects: Dictionary = {}

func _init():
	metadata = {
		"origin": "",
		"priority": 0,
		"encrypted": false,
		"timestamp": "",
		"ai_personality": "neutral"
	}

func has_choices() -> bool:
	return choices.size() > 0

func get_choice_count() -> int:
	return choices.size()

# Get choice text (works with both String and DialogueChoice)
func get_choice(index: int) -> String:
	if index >= 0 and index < choices.size():
		var choice = choices[index]
		if choice is String:
			return choice
		elif choice is DialogueChoice:
			return choice.text
	return ""

# Get the full DialogueChoice object (returns null for simple strings)
func get_choice_data(index: int) -> DialogueChoice:
	if index >= 0 and index < choices.size():
		var choice = choices[index]
		if choice is DialogueChoice:
			return choice
		# Wrap simple string in DialogueChoice for uniform handling
		elif choice is String:
			return DialogueChoice.create(choice)
	return null

# Check if a choice has stat requirements
func choice_has_requirement(index: int) -> bool:
	var choice_data = get_choice_data(index)
	return choice_data != null and choice_data.has_requirement()

# Get available choices for a player (filters out locked options if hide_locked=true)
func get_available_choices(player_stats: CharacterStats = null, hide_locked: bool = false) -> Array[int]:
	var available: Array[int] = []
	for i in range(choices.size()):
		var choice_data = get_choice_data(i)
		if choice_data:
			if not hide_locked or choice_data.can_select(player_stats):
				available.append(i)
		else:
			available.append(i)
	return available

# Add a simple text choice
func add_choice(choice_text: String):
	choices.append(choice_text)

# Add a rich DialogueChoice
func add_dialogue_choice(choice: DialogueChoice):
	choices.append(choice)

# Add a choice with stat requirement (convenience method)
func add_stat_choice(choice_text: String, stat_name: String, min_value: int, next_id: String = ""):
	var choice = DialogueChoice.create_with_requirement(choice_text, stat_name, min_value, next_id)
	choices.append(choice)

func set_choices(choice_array: Array):
	choices = choice_array
	
func set_origin(origin: String):
	metadata["origin"] = origin
	
func set_ai_personality(personality: String):
	metadata["ai_personality"] = personality

func set_priority(priority: int):
	metadata["priority"] = priority

func set_encrypted(encrypted: bool):
	metadata["encrypted"] = encrypted

static func create_text(p_speaker: String, p_text: String) -> DialogueData:
	var data = DialogueData.new()
	data.speaker = p_speaker
	data.text = p_text
	return data

static func create_choice(p_speaker: String, p_text: String, p_choices: Array) -> DialogueData:
	var data = DialogueData.new()
	data.speaker = p_speaker
	data.text = p_text
	data.choices = p_choices
	return data

static func create_transmission(sender: String, message: String, origin: String = "") -> DialogueData:
	var data = DialogueData.new()
	data.speaker = sender
	data.text = message
	data.set_origin(origin)
	return data

static func create_ai_message(message: String, ai_name: String = "Ship AI", personality: String = "neutral") -> DialogueData:
	var data = DialogueData.new()
	data.speaker = ai_name
	data.text = message
	data.set_ai_personality(personality)
	return data
