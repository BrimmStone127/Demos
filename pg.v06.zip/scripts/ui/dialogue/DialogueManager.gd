class_name DialogueManager
extends Node

const LOG_TAG := "DIALOGUE_MANAGER"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


signal dialogue_requested(type: DialogueSystem.DialogueType, data: DialogueData)
signal conversation_started(conversation_id: String)
signal conversation_ended(conversation_id: String)

var dialogue_system: DialogueSystem
var dialogue_content: DialogueContent

# Conversation support
var _active_conversation: Conversation = null
var _active_conversation_id: String = ""
var _pending_conversation_choice: int = -1

# Statistics tracking (optional)
var dialogue_stats = {
	"ai_messages_shown": 0,
	"transmissions_shown": 0,
	"choices_made": 0
}

func _init(p_dialogue_system: DialogueSystem):
	dialogue_system = p_dialogue_system
	dialogue_content = DialogueContent.new()
	
	# Connect to dialogue system signals for tracking
	dialogue_system.dialogue_finished.connect(_on_dialogue_finished)
	dialogue_system.dialogue_choice_selected.connect(_on_choice_selected)

# Generate and show a random AI system message
func generate_random_ai_message(category_hint: String = ""):
	if not dialogue_system:
		_log_error('Error: Dialogue system not available')
		return
	
	# Get random message and personality
	var ai_data = DialogueContent.get_random_ai_message(category_hint)
	var personality = DialogueContent.get_random_ai_personality()
	
	# Create dialogue data
	var dialogue_data = DialogueData.new()
	dialogue_data.speaker = "Ship AI"
	dialogue_data.text = ai_data.message
	dialogue_data.set_ai_personality(personality)
	
	# Add metadata for context
	dialogue_data.metadata["category"] = ai_data.category
	dialogue_data.metadata["generated"] = true
	
	# Maybe add choices
	if DialogueContent.should_have_choices("ai"):
		dialogue_data.choices = DialogueContent.get_random_ai_responses()
	
	# Show the dialogue
	dialogue_system.show_dialogue(DialogueSystem.DialogueType.AI_SYSTEM, dialogue_data)
	dialogue_stats.ai_messages_shown += 1

# Generate and show a random transmission
func generate_random_transmission():
	if not dialogue_system:
		_log_error('Error: Dialogue system not available')
		return
	
	# Get random transmission data
	var transmission_data = DialogueContent.get_random_transmission()
	
	# Create dialogue data
	var dialogue_data = DialogueData.new()
	dialogue_data.speaker = transmission_data.sender
	dialogue_data.text = transmission_data.message
	dialogue_data.set_origin(transmission_data.origin)
	
	# Add metadata
	dialogue_data.metadata["source_type"] = transmission_data.type
	dialogue_data.metadata["generated"] = true
	
	# Maybe add choices
	if DialogueContent.should_have_choices("transmission"):
		dialogue_data.choices = DialogueContent.get_random_transmission_responses()
	
	# Show the dialogue
	dialogue_system.show_dialogue(DialogueSystem.DialogueType.TRANSMISSION, dialogue_data)
	dialogue_stats.transmissions_shown += 1

# Generate context-aware AI message based on game state
func generate_contextual_ai_message(context: Dictionary = {}):
	var category_hint = ""
	
	# Determine category based on context
	if context.has("system_generated"):
		category_hint = "analysis"
	elif context.has("player_exploring"):
		category_hint = "navigation"
	elif context.has("anomaly_detected"):
		category_hint = "warnings"
	elif context.has("routine_check"):
		category_hint = "routine"
	
	generate_random_ai_message(category_hint)

# Generate thematic transmission based on game state
func generate_contextual_transmission(_context: Dictionary = {}):
	# For now, just generate random transmission
	# Later this could be expanded to choose transmission type based on context
	generate_random_transmission()

# Show a specific AI message (for scripted events)
func show_ai_message(message: String, personality: String = "neutral", choices: Array[String] = []):
	var dialogue_data = DialogueData.new()
	dialogue_data.speaker = "Ship AI"
	dialogue_data.text = message
	dialogue_data.set_ai_personality(personality)
	dialogue_data.choices = choices
	dialogue_data.metadata["generated"] = false
	
	dialogue_system.show_dialogue(DialogueSystem.DialogueType.AI_SYSTEM, dialogue_data)

# Show a specific transmission (for scripted events)
func show_transmission(sender: String, message: String, origin: String = "", choices: Array[String] = []):
	var dialogue_data = DialogueData.new()
	dialogue_data.speaker = sender
	dialogue_data.text = message
	dialogue_data.set_origin(origin)
	dialogue_data.choices = choices
	dialogue_data.metadata["generated"] = false
	
	dialogue_system.show_dialogue(DialogueSystem.DialogueType.TRANSMISSION, dialogue_data)

# Handle input for dialogue generation (can be called from Main)
func handle_dialogue_input(event: InputEvent):
	if not event.is_pressed():
		return false
	
	match event.keycode:
		KEY_H:
			generate_random_ai_message()
			return true
		KEY_M:
			generate_random_transmission()
			return true
		_:
			return false

# Get dialogue statistics
func get_stats() -> Dictionary:
	return dialogue_stats.duplicate()

# Reset statistics
func reset_stats():
	dialogue_stats = {
		"ai_messages_shown": 0,
		"transmissions_shown": 0,
		"choices_made": 0
	}

# ============================================
# Conversation Support
# ============================================

# Start a conversation from a file
func start_conversation_from_file(file_path: String, conversation_id: String = "") -> bool:
	var convo = ConversationLoader.load_from_file(file_path)
	if not convo:
		_log_error("Failed to load conversation from: %s", [file_path])
		return false
	return start_conversation(convo, conversation_id if conversation_id else file_path)

# Start a conversation object
func start_conversation(conversation: Conversation, conversation_id: String = "") -> bool:
	if _active_conversation:
		_log_warn("Conversation already active, ending previous")
		end_conversation()

	_active_conversation = conversation
	_active_conversation_id = conversation_id

	_active_conversation.dialogue_changed.connect(_on_conversation_dialogue_changed)
	_active_conversation.conversation_ended.connect(_on_conversation_ended)

	_log_info("Starting conversation: %s", [conversation_id])
	emit_signal("conversation_started", conversation_id)

	_active_conversation.start()
	return true

# Check if a conversation is active
func is_conversation_active() -> bool:
	return _active_conversation != null

# End the current conversation
func end_conversation():
	if not _active_conversation:
		return

	var convo_id = _active_conversation_id

	if _active_conversation.dialogue_changed.is_connected(_on_conversation_dialogue_changed):
		_active_conversation.dialogue_changed.disconnect(_on_conversation_dialogue_changed)
	if _active_conversation.conversation_ended.is_connected(_on_conversation_ended):
		_active_conversation.conversation_ended.disconnect(_on_conversation_ended)

	_active_conversation = null
	_active_conversation_id = ""

	_log_info("Conversation ended: %s", [convo_id])
	emit_signal("conversation_ended", convo_id)

func _on_conversation_dialogue_changed(_dialogue_id: String):
	_show_current_conversation_dialogue()

func _on_conversation_ended():
	end_conversation()

func _show_current_conversation_dialogue():
	if not _active_conversation:
		return

	var dialogue_data = _active_conversation.get_current()
	if not dialogue_data:
		return

	# Show through dialogue system as AI message
	dialogue_system.show_dialogue(DialogueSystem.DialogueType.AI_SYSTEM, dialogue_data)

# Override choice handler for conversations
func _on_choice_selected(choice_index: int):
	dialogue_stats.choices_made += 1

	# Handle conversation choice
	if _active_conversation:
		_log_info("Conversation choice selected: %d", [choice_index])
		# Store choice, will be used when dialogue finishes
		_pending_conversation_choice = choice_index
		return

	# Handle one-off dialogue choice
	if dialogue_system.current_dialogue_box and dialogue_system.current_dialogue_box.dialogue_data:
		var dialogue_data = dialogue_system.current_dialogue_box.dialogue_data
		_log_info('Player selected choice %s: %s', [choice_index, dialogue_data.choices[choice_index]])

# Dialogue finished handler - handles both conversations and one-off dialogues
func _on_dialogue_finished(type: DialogueSystem.DialogueType):
	# Handle conversation flow
	if _active_conversation:
		if _pending_conversation_choice >= 0:
			_active_conversation.select_choice(_pending_conversation_choice)
			_pending_conversation_choice = -1
		elif _active_conversation.get_choice_count() == 0:
			_active_conversation.end()
		return

	# Normal one-off dialogue handling
	match type:
		DialogueSystem.DialogueType.AI_SYSTEM:
			_log_info('AI dialogue completed')
		DialogueSystem.DialogueType.TRANSMISSION:
			_log_info('Transmission dialogue completed')
