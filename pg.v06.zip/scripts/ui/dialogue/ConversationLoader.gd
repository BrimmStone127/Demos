class_name ConversationLoader
extends RefCounted

## Loads conversations from JSON files.
##
## JSON Format:
## {
##   "id": "merchant_greeting",
##   "start": "hello",
##   "dialogues": {
##     "hello": {
##       "speaker": "Merchant",
##       "text": "Welcome to my shop!",
##       "choices": [
##         {"text": "What do you sell?", "next": "inventory"},
##         {"text": "Just looking.", "next": "browse"},
##         {"text": "Goodbye."}
##       ]
##     },
##     "inventory": {
##       "speaker": "Merchant",
##       "text": "I have supplies, tools, and some rare items.",
##       "choices": [
##         {"text": "Tell me about the rare items.", "next": "rare"},
##         {"text": "Back to greeting.", "next": "hello"}
##       ]
##     },
##     "browse": {
##       "speaker": "Merchant",
##       "text": "Take your time."
##     },
##     "rare": {
##       "speaker": "Merchant",
##       "text": "Ah, you have good taste..."
##     }
##   }
## }

const LOG_TAG := "CONVO_LOADER"


static func load_from_file(path: String) -> Conversation:
	if not FileAccess.file_exists(path):
		push_error("Conversation file not found: %s" % path)
		return null

	var file = FileAccess.open(path, FileAccess.READ)
	if not file:
		push_error("Failed to open conversation file: %s" % path)
		return null

	var json_text = file.get_as_text()
	file.close()

	return load_from_string(json_text)


static func load_from_string(json_text: String) -> Conversation:
	var json = JSON.new()
	var parse_result = json.parse(json_text)

	if parse_result != OK:
		push_error("Failed to parse conversation JSON: %s" % json.get_error_message())
		return null

	var data = json.get_data()
	return load_from_dict(data)


static func load_from_dict(data: Dictionary) -> Conversation:
	var convo = Conversation.new()

	var dialogues = data.get("dialogues", {})

	for dialogue_id in dialogues:
		var d = dialogues[dialogue_id]

		var speaker = d.get("speaker", "")
		var text = d.get("text", "")
		var raw_choices = d.get("choices", [])

		# Build choice list
		var choices: Array = []
		for c in raw_choices:
			if c is String:
				choices.append(DialogueChoice.create(c))
			elif c is Dictionary:
				var choice = DialogueChoice.new()
				choice.text = c.get("text", "")
				choice.next_dialogue_id = c.get("next", "")

				# Optional fields
				if c.has("stat"):
					choice.stat_name = c.get("stat", "")
					choice.stat_minimum = c.get("min", 0)
				if c.has("chance"):
					choice.success_chance = c.get("chance", 1.0)
				if c.has("locked_text"):
					choice.locked_text = c.get("locked_text", "")
				if c.has("tags"):
					choice.tags.assign(c.get("tags", []))

				choices.append(choice)

		var dialogue_data = convo.add_dialogue(dialogue_id, speaker, text, choices)

		# Optional dialogue metadata
		if d.has("typing_speed"):
			dialogue_data.typing_speed = d.get("typing_speed")
		if d.has("auto_close"):
			dialogue_data.auto_close_time = d.get("auto_close")

	# Set start dialogue
	var start_id = data.get("start", "")
	if start_id != "":
		convo.set_start(start_id)

	return convo


# Save a conversation to JSON (for tooling/debugging)
static func save_to_dict(convo: Conversation) -> Dictionary:
	var data = {
		"dialogues": {}
	}

	for dialogue_id in convo.get_dialogue_ids():
		var dialogue = convo._dialogues[dialogue_id]
		var d = {
			"speaker": dialogue.speaker,
			"text": dialogue.text
		}

		if dialogue.choices.size() > 0:
			var choices_arr = []
			for choice in dialogue.choices:
				if choice is DialogueChoice:
					var c = {"text": choice.text}
					if choice.next_dialogue_id != "":
						c["next"] = choice.next_dialogue_id
					if choice.stat_name != "":
						c["stat"] = choice.stat_name
						c["min"] = choice.stat_minimum
					choices_arr.append(c)
				elif choice is String:
					choices_arr.append({"text": choice})
			d["choices"] = choices_arr

		data["dialogues"][dialogue_id] = d

	return data
