class_name DialogueBox
extends Panel

signal dialogue_finished
signal choice_selected(choice_index: int)

# UI Components
var main_container: VBoxContainer
var speaker_label: Label
var text_label: Label  # Back to Label
var choices_container: VBoxContainer
var choice_buttons: Array[Button] = []

# Dialogue state
var dialogue_data: DialogueData
var is_typing: bool = false
var type_timer: Timer
var current_text_index: int = 0
var full_text: String = ""
var displayed_text: String = ""

# Configuration
var box_width: float = 600
var box_height: float = 200
var margin_bottom: float = 80

func _init():
	# Set up the panel with bottom-center positioning
	custom_minimum_size = Vector2(box_width, box_height)
	size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	size_flags_vertical = Control.SIZE_SHRINK_END
	
	# Make sure panel captures input while visible
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_process_input(true)  # Enable input processing
	set_process_unhandled_input(true)  # Also handle unhandled input
	
	_create_ui()
	_setup_positioning()

func _ready():
	# Apply terminal theme
	TerminalTheme.apply_to_panel(self)
	TerminalTheme.apply_recursive(self)
	
	# Set up typewriter timer
	type_timer = Timer.new()
	type_timer.wait_time = 0.05  # Default typing speed
	type_timer.timeout.connect(_on_type_timer_timeout)
	add_child(type_timer)
	
	# Connect mouse click
	gui_input.connect(_on_gui_input)

func _create_ui():
	# Main container
	main_container = VBoxContainer.new()
	main_container.size_flags_horizontal = Control.SIZE_FILL
	main_container.size_flags_vertical = Control.SIZE_FILL
	add_child(main_container)
	
	# Margin container for padding
	var margin_container = MarginContainer.new()
	margin_container.add_theme_constant_override("margin_left", 15)
	margin_container.add_theme_constant_override("margin_right", 15)
	margin_container.add_theme_constant_override("margin_top", 10)
	margin_container.add_theme_constant_override("margin_bottom", 10)
	margin_container.size_flags_horizontal = Control.SIZE_FILL
	margin_container.size_flags_vertical = Control.SIZE_FILL
	main_container.add_child(margin_container)
	
	# Content container
	var content_container = VBoxContainer.new()
	content_container.size_flags_horizontal = Control.SIZE_FILL
	content_container.size_flags_vertical = Control.SIZE_FILL
	margin_container.add_child(content_container)
	
	# Speaker label
	speaker_label = Label.new()
	speaker_label.text = ""
	speaker_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	speaker_label.add_theme_font_size_override("font_size", 18)
	speaker_label.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	content_container.add_child(speaker_label)
	
	# Text label that fills the space properly
	text_label = Label.new()
	text_label.size_flags_horizontal = Control.SIZE_FILL
	text_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
	text_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text_label.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	text_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	# Set minimum size to ensure it takes up space
	text_label.custom_minimum_size = Vector2(550, 150)
	content_container.add_child(text_label)
	
	# Choices container (initially hidden)
	choices_container = VBoxContainer.new()
	choices_container.visible = false
	choices_container.size_flags_horizontal = Control.SIZE_FILL
	content_container.add_child(choices_container)

func _setup_positioning():
	# This will be called in _ready to position at bottom center
	call_deferred("_position_at_bottom_center")

func _position_at_bottom_center():
	# Wait for viewport to be ready
	await get_tree().process_frame

	var viewport_size = get_viewport_rect().size
	# Use get_combined_minimum_size() which is more reliable than size
	# before layout fully completes
	var box_size = get_combined_minimum_size()
	if box_size.x <= 0 or box_size.y <= 0:
		box_size = custom_minimum_size

	# Position at bottom center with margin
	position = Vector2(
		(viewport_size.x - box_size.x) / 2.0,
		viewport_size.y - box_size.y - margin_bottom
	)
	
	# Connect to viewport resize to maintain position
	get_viewport().size_changed.connect(_on_viewport_resized)

func _on_viewport_resized():
	_position_at_bottom_center()

# Display dialogue data
func display_dialogue(data: DialogueData):
	dialogue_data = data
	
	# Set speaker
	speaker_label.text = data.speaker
	
	# Customize appearance based on dialogue type
	_customize_appearance()
	
	# Set up text
	full_text = data.text
	displayed_text = ""
	current_text_index = 0
	
	# Start typing effect
	if data.typing_speed > 0:
		type_timer.wait_time = data.typing_speed
		is_typing = true
		text_label.text = ""
		type_timer.start()
	else:
		# Show all text immediately
		text_label.text = full_text
		_on_text_complete()

# Customize appearance based on dialogue type (override in subclasses)
func _customize_appearance():
	pass

# Handle typewriter effect
func _on_type_timer_timeout():
	if current_text_index >= full_text.length():
		type_timer.stop()
		is_typing = false
		_on_text_complete()
		return
	
	# Add next character
	displayed_text += full_text[current_text_index]
	text_label.text = displayed_text
	current_text_index += 1

# Called when text is fully displayed
func _on_text_complete():
	# Add blinking cursor to indicate dialogue is complete
	_add_blinking_cursor()
	
	# Show choices if any
	if dialogue_data.has_choices():
		_show_choices()
	else:
		# Auto-close if specified
		if dialogue_data.auto_close_time > 0:
			await get_tree().create_timer(dialogue_data.auto_close_time).timeout
			close_dialogue()

# Add blinking cursor
func _add_blinking_cursor():
	var cursor = Label.new()
	cursor.text = "_"
	TerminalTheme.apply_to_label(cursor)
	text_label.get_parent().add_child(cursor)
	
	# Make it blink
	var blink_tween = create_tween()
	blink_tween.set_loops()
	blink_tween.tween_property(cursor, "modulate:a", 0.0, 0.5)
	blink_tween.tween_property(cursor, "modulate:a", 1.0, 0.5)

# Optional: player stats for stat-based choice display
var player_stats: CharacterStats = null

# Show choice buttons
func _show_choices():
	choices_container.visible = true

	# Clear existing choice buttons
	for button in choice_buttons:
		button.queue_free()
	choice_buttons.clear()

	# Create choice buttons
	for i in range(dialogue_data.choices.size()):
		var choice = dialogue_data.choices[i]
		var button = Button.new()

		# Handle both String and DialogueChoice
		if choice is String:
			button.text = choice
		elif choice is DialogueChoice:
			# Use formatted text if we have player stats, otherwise plain text
			if player_stats:
				button.text = choice.get_formatted_text(player_stats)
				# Disable if player can't select this choice
				if not choice.can_select(player_stats):
					button.disabled = true
					button.modulate = Color(0.5, 0.5, 0.5, 1.0)
			else:
				button.text = choice.text
		else:
			button.text = str(choice)

		button.size_flags_horizontal = Control.SIZE_FILL
		button.pressed.connect(func(): _on_choice_pressed(i))

		choices_container.add_child(button)
		choice_buttons.append(button)

		# Apply terminal theme to button
		TerminalTheme.apply_to_button(button)

# Handle choice selection
func _on_choice_pressed(choice_index: int):
	emit_signal("choice_selected", choice_index)
	close_dialogue()

# Handle input (for skipping, etc.)
func _handle_input(event):
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_SPACE, KEY_ENTER:
				if is_typing and dialogue_data.allow_skip:
					# Skip to end of text
					type_timer.stop()
					is_typing = false
					text_label.text = full_text
					displayed_text = full_text
					current_text_index = full_text.length()
					_on_text_complete()
				elif not dialogue_data.has_choices():
					# Close dialogue if no choices
					close_dialogue()
			KEY_ESCAPE:
				# Always allow ESC to close
				close_dialogue()

# Override _input to catch all input
func _input(event):
	_handle_input(event)

# Also override _unhandled_input to catch missed input
func _unhandled_input(event):
	_handle_input(event)

# Handle mouse clicks
func _on_gui_input(event):
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			if is_typing and dialogue_data and dialogue_data.allow_skip:
				# Skip to end of text
				type_timer.stop()
				is_typing = false
				text_label.text = full_text
				displayed_text = full_text
				current_text_index = full_text.length()
				_on_text_complete()
			elif not dialogue_data or not dialogue_data.has_choices():
				# Close dialogue if no choices
				close_dialogue()

# Close the dialogue box
func close_dialogue():
	# Fade out animation (optional)
	var tween = create_tween()
	tween.tween_property(self, "modulate", Color(1, 1, 1, 0), 0.2)
	await tween.finished
	
	emit_signal("dialogue_finished")

# Clean up
func _exit_tree():
	if type_timer and is_instance_valid(type_timer):
		type_timer.queue_free()
