class_name ConversationUI
extends CanvasLayer

## Plays a Conversation using DialogueBox for display.
## Handles the full conversation flow: showing dialogues, handling choices, advancing.
##
## Example usage:
##   var convo_ui = ConversationUI.new()
##   add_child(convo_ui)
##
##   var convo = ConversationLoader.load_from_file("res://assets/narrative/conversations/example.json")
##   convo_ui.start_conversation(convo)
##
##   # Listen for completion
##   convo_ui.conversation_finished.connect(func(): print("Done!"))

signal conversation_started
signal conversation_finished
signal dialogue_shown(dialogue_id: String)
signal choice_made(choice_index: int, choice_text: String)

var _conversation: Conversation
var _dialogue_box: DialogueBox
var _container: Control

var is_active: bool = false

# Optional: player stats for stat-based choices (can be set before starting)
var player_stats: CharacterStats = null


func _init():
	name = "ConversationUI"
	layer = UILayers.DIALOGUE_SYSTEM


func _ready():
	_create_container()


func _create_container():
	_container = Control.new()
	_container.set_anchors_preset(Control.PRESET_FULL_RECT)
	_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_container)


# Start playing a conversation
func start_conversation(conversation: Conversation):
	if is_active:
		push_warning("Conversation already active, ending previous")
		end_conversation()

	_conversation = conversation
	is_active = true

	# Connect to conversation signals
	_conversation.dialogue_changed.connect(_on_dialogue_changed)
	_conversation.conversation_ended.connect(_on_conversation_ended)

	emit_signal("conversation_started")

	# Start the conversation
	_conversation.start()


# End the current conversation
func end_conversation():
	if not is_active:
		return

	is_active = false

	# Cleanup dialogue box
	if _dialogue_box and is_instance_valid(_dialogue_box):
		_dialogue_box.queue_free()
		_dialogue_box = null

	# Disconnect signals
	if _conversation:
		if _conversation.dialogue_changed.is_connected(_on_dialogue_changed):
			_conversation.dialogue_changed.disconnect(_on_dialogue_changed)
		if _conversation.conversation_ended.is_connected(_on_conversation_ended):
			_conversation.conversation_ended.disconnect(_on_conversation_ended)
		_conversation = null

	emit_signal("conversation_finished")


func _on_dialogue_changed(dialogue_id: String):
	_show_current_dialogue()
	emit_signal("dialogue_shown", dialogue_id)


func _on_conversation_ended():
	end_conversation()


func _show_current_dialogue():
	# Remove old dialogue box
	if _dialogue_box and is_instance_valid(_dialogue_box):
		# Wait for close animation
		_dialogue_box.dialogue_finished.disconnect(_on_dialogue_finished)
		_dialogue_box.choice_selected.disconnect(_on_choice_selected)
		_dialogue_box.queue_free()
		_dialogue_box = null

	var dialogue_data = _conversation.get_current()
	if not dialogue_data:
		return

	# Create new dialogue box
	_dialogue_box = DialogueBox.new()
	_container.add_child(_dialogue_box)

	# Wait for ready
	await get_tree().process_frame

	# Apply theme
	TerminalTheme.apply_recursive(_dialogue_box)

	# Connect signals
	_dialogue_box.dialogue_finished.connect(_on_dialogue_finished)
	_dialogue_box.choice_selected.connect(_on_choice_selected)

	# Show dialogue
	_dialogue_box.display_dialogue(dialogue_data)


func _on_dialogue_finished():
	# Dialogue closed without selecting a choice
	if _conversation and _conversation.get_choice_count() == 0:
		# No choices - end conversation
		_conversation.end()


func _on_choice_selected(choice_index: int):
	if not _conversation:
		return

	var choice_text = _conversation.get_choices()[choice_index] if choice_index < _conversation.get_choices().size() else ""
	emit_signal("choice_made", choice_index, choice_text)

	# Advance conversation
	_conversation.select_choice(choice_index)


# Skip current dialogue (show all text immediately)
func skip_typing():
	if _dialogue_box and _dialogue_box.is_typing:
		_dialogue_box.type_timer.stop()
		_dialogue_box.is_typing = false
		_dialogue_box.text_label.text = _dialogue_box.full_text
		_dialogue_box._on_text_complete()


# Get current conversation
func get_conversation() -> Conversation:
	return _conversation


# Quick way to play a conversation from a file
static func play_from_file(parent: Node, file_path: String) -> ConversationUI:
	var convo = ConversationLoader.load_from_file(file_path)
	if not convo:
		return null

	var ui = ConversationUI.new()
	parent.add_child(ui)
	ui.start_conversation(convo)
	return ui
