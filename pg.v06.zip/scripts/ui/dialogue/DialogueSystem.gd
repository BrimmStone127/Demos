class_name DialogueSystem
extends CanvasLayer

const LOG_TAG := "DIALOGUE_SYSTEM"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


signal dialogue_started(type: DialogueType)
signal dialogue_finished(type: DialogueType)
signal dialogue_choice_selected(choice_index: int)

enum DialogueType {
	TRANSMISSION,
	AI_SYSTEM,
	# Future types could include: CREW_MEMBER, ALIEN_CONTACT, etc.
}

var current_dialogue_box: DialogueBox = null
var dialogue_queue: Array[DialogueData] = []
var is_dialogue_active: bool = false

# References to the dialogue box scripts
const DialogueBoxScript = preload("res://scripts/ui/dialogue/DialogueBox.gd")
const TransmissionBoxScript = preload("res://scripts/ui/dialogue/TransmissionBox.gd")
const AISystemBoxScript = preload("res://scripts/ui/dialogue/AISystemBox.gd")

func _init():
	name = "DialogueSystem"
	# Make sure dialogue system processes input
	process_mode = Node.PROCESS_MODE_ALWAYS

func _ready():
	# Position the dialogue system above other UI elements
	layer = UILayers.DIALOGUE_SYSTEM

# Show a dialogue with specified type and data
func show_dialogue(type: DialogueType, dialogue_data: DialogueData):
	# Queue dialogue if one is already active
	if is_dialogue_active:
		dialogue_queue.append(dialogue_data)
		dialogue_data.dialogue_type = type
		return
	
	# Create appropriate dialogue box based on type
	match type:
		DialogueType.TRANSMISSION:
			current_dialogue_box = TransmissionBoxScript.new()
		DialogueType.AI_SYSTEM:
			current_dialogue_box = AISystemBoxScript.new()
		_:
			_log_error('Error: Unknown dialogue type: %s', [type])
			return
	
	# Set up the dialogue box
	current_dialogue_box.dialogue_finished.connect(_on_dialogue_finished)
	current_dialogue_box.choice_selected.connect(_on_choice_selected)
	add_child(current_dialogue_box)
	
	# Apply terminal theme
	TerminalTheme.apply_recursive(current_dialogue_box)
	
	# Start the dialogue
	current_dialogue_box.display_dialogue(dialogue_data)
	is_dialogue_active = true
	
	# Emit signal
	emit_signal("dialogue_started", type)

# Show a simple text dialogue (convenience method)
func show_text_dialogue(type: DialogueType, speaker: String, text: String):
	var data = DialogueData.new()
	data.speaker = speaker
	data.text = text
	data.dialogue_type = type
	show_dialogue(type, data)

# Show a dialogue with choices (convenience method)
func show_choice_dialogue(type: DialogueType, speaker: String, text: String, choices: Array[String]):
	var data = DialogueData.new()
	data.speaker = speaker
	data.text = text
	data.choices = choices
	data.dialogue_type = type
	show_dialogue(type, data)

# Show an incoming transmission (convenience method)
func show_transmission(sender: String, message: String, origin: String = ""):
	var data = DialogueData.new()
	data.speaker = sender
	data.text = message
	data.metadata["origin"] = origin
	data.dialogue_type = DialogueType.TRANSMISSION
	show_dialogue(DialogueType.TRANSMISSION, data)

# Show AI system message (convenience method)
func show_ai_message(message: String, ai_name: String = "Ship AI"):
	var data = DialogueData.new()
	data.speaker = ai_name
	data.text = message
	data.dialogue_type = DialogueType.AI_SYSTEM
	show_dialogue(DialogueType.AI_SYSTEM, data)

# Show AI system message with choices (convenience method)
func show_ai_choice(message: String, choices: Array[String], ai_name: String = "Ship AI"):
	var data = DialogueData.new()
	data.speaker = ai_name
	data.text = message
	data.choices = choices
	data.dialogue_type = DialogueType.AI_SYSTEM
	show_dialogue(DialogueType.AI_SYSTEM, data)

# Close current dialogue (if any)
func close_current_dialogue():
	if current_dialogue_box and is_instance_valid(current_dialogue_box):
		current_dialogue_box.close_dialogue()

# Check if dialogue is currently active
func is_showing_dialogue() -> bool:
	return is_dialogue_active

# Handle input (mainly for skipping/advancing dialogue)
func _unhandled_input(event):
	if not is_dialogue_active:
		return
		
	if current_dialogue_box and is_instance_valid(current_dialogue_box):
		# Let the dialogue box handle the input first
		current_dialogue_box._handle_input(event)

# Called when dialogue is finished
func _on_dialogue_finished():
	if not current_dialogue_box:
		return
		
	var dialogue_type = current_dialogue_box.dialogue_data.dialogue_type
	
	# Clean up current dialogue
	current_dialogue_box.queue_free()
	current_dialogue_box = null
	is_dialogue_active = false
	
	# Emit signal
	emit_signal("dialogue_finished", dialogue_type)
	
	# Process queue if there are waiting dialogues
	if dialogue_queue.size() > 0:
		var next_dialogue = dialogue_queue.pop_front()
		show_dialogue(next_dialogue.dialogue_type, next_dialogue)

# Called when player selects a choice
func _on_choice_selected(choice_index: int):
	emit_signal("dialogue_choice_selected", choice_index)

# Clear all queued dialogues
func clear_dialogue_queue():
	dialogue_queue.clear()

# Get the number of queued dialogues
func get_queue_size() -> int:
	return dialogue_queue.size()
