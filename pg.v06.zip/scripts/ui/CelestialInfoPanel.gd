# Deprecated

class_name CelestialInfoPanel
extends Panel

const LOG_TAG := "CELESTIAL_INFO_PANEL"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


signal panel_closed

enum ViewMode {
	STAR_SYSTEMS,    # List of discovered star systems
	SOLAR_SYSTEM,    # View of a specific star system with its planets
	PLANET           # Detailed view of a specific planet
}

var current_view: int = ViewMode.STAR_SYSTEMS
var panel_width: float = 400
var panel_height: float = 600

# Navigation state
var current_system_history = []  # List of discovered star systems
var current_system: StarSystem = null
var current_planet: Planet = null

# UI Components
var main_container: VBoxContainer
var header_container: HBoxContainer
var content_container: VBoxContainer
var scroll_container: ScrollContainer
var back_button: Button
var title_label: Label
var close_button: Button

# Reference to SystemHistory
var system_history_ref: StarSystemHistory = null

# Store pending timer reference so we can clean it up if freed
var _pending_system_timer: Timer = null
var _pending_seed_value: int = 0

func _notification(what):
	if what == NOTIFICATION_PREDELETE:
		# Clean up any pending timer to avoid lambda capture errors
		if _pending_system_timer and is_instance_valid(_pending_system_timer):
			_pending_system_timer.timeout.disconnect(_on_system_timer_timeout)
			_pending_system_timer.queue_free()
			_pending_system_timer = null

func _on_system_timer_timeout():
	var timer = _pending_system_timer
	var seed_value = _pending_seed_value
	_pending_system_timer = null
	_pending_seed_value = 0

	if timer and is_instance_valid(timer):
		timer.queue_free()

	if not is_instance_valid(self):
		return

	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if is_instance_valid(main_node) and main_node.has_method("get_current_star_system"):
		var star_system = main_node.get_current_star_system()
		if star_system:
			if main_node.has_method("_on_reset_camera_requested"):
				main_node._on_reset_camera_requested()
			current_system = star_system
			_show_solar_system_view(star_system)

func _init(p_system_history: StarSystemHistory = null):
	name = "CelestialInfoPanel"
	set_custom_minimum_size(Vector2(panel_width, panel_height))
	
	# Store reference to system history if provided
	system_history_ref = p_system_history
	
	# Create main layout
	_create_layout()
	
	# Initialize with star systems view
	_show_star_systems_view()

func _create_layout():
	# Main container
	main_container = VBoxContainer.new()
	main_container.size_flags_horizontal = Control.SIZE_FILL
	main_container.size_flags_vertical = Control.SIZE_FILL
	main_container.position = Vector2(10, 10)
	main_container.set_custom_minimum_size(Vector2(panel_width - 20, panel_height - 20))
	add_child(main_container)
	
	# Header with title, back button, and close button
	header_container = HBoxContainer.new()
	header_container.size_flags_horizontal = Control.SIZE_FILL
	main_container.add_child(header_container)
	
	# Title (left-aligned)
	title_label = Label.new()
	title_label.text = "Star Systems"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_label.add_theme_font_size_override("font_size", 18)
	TerminalTheme.apply_to_label(title_label)
	header_container.add_child(title_label)
	
	# Back button (positioned in the middle)
	back_button = Button.new()
	back_button.text = "Back"
	back_button.visible = false
	back_button.pressed.connect(_on_back_pressed)
	TerminalTheme.apply_to_button(back_button)
	header_container.add_child(back_button)
	
	# Close button (right-aligned)
	close_button = Button.new()
	close_button.text = "X"
	close_button.pressed.connect(_on_close_button_pressed)
	TerminalTheme.apply_to_button(close_button)
	header_container.add_child(close_button)
	
	# Separator
	var separator = HSeparator.new()
	main_container.add_child(separator)
	
	# Scrollable content container
	scroll_container = ScrollContainer.new()
	scroll_container.size_flags_horizontal = Control.SIZE_FILL
	scroll_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll_container.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	main_container.add_child(scroll_container)
	
	# Content container inside scroll container
	content_container = VBoxContainer.new()
	content_container.size_flags_horizontal = Control.SIZE_FILL
	content_container.size_flags_vertical = Control.SIZE_FILL
	content_container.set_custom_minimum_size(Vector2(panel_width - 40, 0))  # Account for padding and scrollbar
	scroll_container.add_child(content_container)

func _ready():
	# Position panel on the right side of the screen
	call_deferred("_adjust_position")
	
	# Apply terminal theme styling to all elements
	TerminalTheme.apply_recursive(self)
	
	# Reapply style to buttons to ensure they're properly styled
	TerminalTheme.apply_to_button(back_button)
	TerminalTheme.apply_to_button(close_button)
	
func _adjust_position():
	# Use Engine.get_main_loop() instead of get_tree() to be safer
	await Engine.get_main_loop().process_frame
	
	var viewport_size = get_viewport_rect().size
	var margin = 20
	
	# Position on right side of screen with margin
	position = Vector2(viewport_size.x - size.x - margin, margin)
	
	# Connect to window resize events
	get_viewport().size_changed.connect(_on_viewport_size_changed)

func _on_viewport_size_changed():
	var viewport_size = get_viewport_rect().size
	var margin = 20
	position = Vector2(viewport_size.x - size.x - margin, margin)

func _on_close_button_pressed():
	emit_signal("panel_closed")
	queue_free()

func _on_back_pressed():
	match current_view:
		ViewMode.SOLAR_SYSTEM:
			_show_star_systems_view()
		ViewMode.PLANET:
			if current_system and is_instance_valid(current_system):
				# Reset camera to focus on star when going back to solar system view
				var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
				if main_node and main_node.has_method("_on_reset_camera_requested"):
					main_node._on_reset_camera_requested()
				
				_show_solar_system_view(current_system)
			else:
				# If system is not valid, go back to star systems view
				_show_star_systems_view()

# View: Star Systems List
func _show_star_systems_view():
	current_view = ViewMode.STAR_SYSTEMS
	current_system = null
	current_planet = null
	
	# Update header
	title_label.text = "Star Systems"
	back_button.visible = false
	
	# Ensure buttons in correct order
	_fix_header_button_order(false)
	
	# Clear current content
	_clear_content()
	
	# Get history data
	var history_data = []
	if system_history_ref:
		history_data = system_history_ref.get_history()
	
	if history_data.size() == 0:
		var empty_label = Label.new()
		empty_label.text = "No star systems discovered yet.\nExplore the universe!"
		empty_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		empty_label.set_custom_minimum_size(Vector2(0, 100))
		empty_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		content_container.add_child(empty_label)
		TerminalTheme.apply_to_label(empty_label)
		return
	
	# Add each star system as a clickable item
	for system_data in history_data:
		var item = _create_star_system_item(system_data)
		content_container.add_child(item)
		
		# Add spacing between items
		var spacer = Control.new()
		spacer.set_custom_minimum_size(Vector2(0, 5))
		content_container.add_child(spacer)

# View: Solar System
func _show_solar_system_view(star_system: StarSystem):
	if not is_instance_valid(star_system):
		_log_warn('Warning: Invalid star system')
		_show_star_systems_view()
		return
	
	current_view = ViewMode.SOLAR_SYSTEM
	current_system = star_system
	current_planet = null
	
	# Update header
	title_label.text = star_system.star_name
	back_button.visible = true
	back_button.text = "Back to Systems"
	
	# Ensure buttons in correct order
	_fix_header_button_order(true)
	
	# Clear current content
	_clear_content()
	
	# Star information section with proper padding and separation
	var info_container = VBoxContainer.new()
	info_container.size_flags_horizontal = Control.SIZE_FILL
	info_container.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	content_container.add_child(info_container)
	
	# Star properties
	var star_type_label = Label.new()
	star_type_label.text = "Type: " + star_system.get_star_type_name()
	info_container.add_child(star_type_label)
	TerminalTheme.apply_to_label(star_type_label)
	
	var seed_label = Label.new()
	seed_label.text = "Seed: " + str(star_system.current_seed)
	info_container.add_child(seed_label)
	TerminalTheme.apply_to_label(seed_label)
	
	# Add spacer between info and planets list
	var spacer = Control.new()
	spacer.set_custom_minimum_size(Vector2(0, 20))
	content_container.add_child(spacer)
	
	# Planets header
	var planets_header = Label.new()
	planets_header.text = "Planets"
	planets_header.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	planets_header.add_theme_font_size_override("font_size", 16)
	content_container.add_child(planets_header)
	TerminalTheme.apply_to_label(planets_header)
	
	# Add small spacer
	var small_spacer = Control.new()
	small_spacer.set_custom_minimum_size(Vector2(0, 10))
	content_container.add_child(small_spacer)
	
	# Count planets
	var planets = []
	for child in star_system.get_children():
		if child is Planet:
			planets.append(child)
	
	if planets.size() == 0:
		var no_planets_label = Label.new()
		no_planets_label.text = "No planets in this system."
		no_planets_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		content_container.add_child(no_planets_label)
		TerminalTheme.apply_to_label(no_planets_label)
		return
	
	# Add each planet as a clickable item
	for planet in planets:
		if is_instance_valid(planet):
			var planet_item = _create_planet_item(planet)
			content_container.add_child(planet_item)
			
			# Add spacing between items
			var item_spacer = Control.new()
			item_spacer.set_custom_minimum_size(Vector2(0, 5))
			content_container.add_child(item_spacer)

# View: Planet details
func _show_planet_view(planet: Planet):
	if not is_instance_valid(planet):
		_log_warn('Warning: Invalid planet')
		if current_system:
			_show_solar_system_view(current_system)
		else:
			_show_star_systems_view()
		return
	
	current_view = ViewMode.PLANET
	current_planet = planet
	
	# Update header
	title_label.text = planet.planet_name
	back_button.visible = true
	back_button.text = "Back to Star"
	
	# Ensure buttons in correct order
	_fix_header_button_order(true)
	
	# Clear current content
	_clear_content()
	
	# Planet image container
	var image_container = CenterContainer.new()
	image_container.size_flags_horizontal = Control.SIZE_FILL
	image_container.set_custom_minimum_size(Vector2(0, 120))  # Fixed height for the image area
	content_container.add_child(image_container)
	
	# Create TextureRect for planet (TextureRect works better than Sprite2D for UI)
	var planet_image = TextureRect.new()
	if planet.planet_sprite and planet.planet_sprite.texture:
		planet_image.texture = planet.planet_sprite.texture
		planet_image.modulate = planet.planet_sprite.modulate
		
		# Use compatible TextureRect properties
		planet_image.expand = true
		planet_image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		
		# Scale down to fit within the panel (75% of original size)
		var texture_size = planet.planet_sprite.texture.get_size()
		var scale_factor = min(100.0 / texture_size.x, 100.0 / texture_size.y) * 0.75
		planet_image.set_custom_minimum_size(texture_size * scale_factor)
	image_container.add_child(planet_image)
	
	# Planet name
	var name_label = Label.new()
	name_label.text = planet.planet_name
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_label.add_theme_font_size_override("font_size", 16)
	content_container.add_child(name_label)
	TerminalTheme.apply_to_label(name_label)
	
	# Separator
	var separator = HSeparator.new()
	content_container.add_child(separator)
	
	# Planet information
	var info = planet.get_info()
	
	add_property("Planet Type", info.type)
	add_property("Relative Size", str(snapped(info.size, 0.01)))
	add_property("Distance", str(snapped(info.distance, 0.1)) + " units")
	add_property("Eccentricity", str(snapped(planet.eccentricity, 0.01)))
	add_property("Orbit Speed", str(snapped(planet.orbit_speed * 100, 0.1)) + " units/s")
	add_property("Atmosphere", "Yes" if info.atmosphere else "No")
	
	# Additional info based on planet type name
	var planet_type_name = info.type
	
	match planet_type_name:
		"ROCKY_SMALL":
			add_property("Surface", "Cratered, minimal atmosphere")
		"ROCKY_MEDIUM":
			add_property("Surface", "Variable terrain, moderate atmosphere")
		"SUPER_EARTH":
			add_property("Surface", "High gravity, thick atmosphere")
		"ICE_GIANT":
			add_property("Composition", "Hydrogen, helium, methane ice")
		"GAS_GIANT":
			add_property("Composition", "Hydrogen, helium, dense core")
		"SUPER_JUPITER":
			add_property("Composition", "Massive gas layers, extreme pressure")

# Helper function to fix button order in header
func _fix_header_button_order(show_back: bool):
	# To ensure the back button is always on the right, we'll rearrange the header
	
	# First, remove buttons if they exist
	if back_button.get_parent() == header_container:
		header_container.remove_child(back_button)
	if close_button.get_parent() == header_container:
		header_container.remove_child(close_button)
	
	# Keep title on the left
	if title_label.get_parent() != header_container:
		header_container.add_child(title_label)
	
	# Add back button in the middle if required
	if show_back:
		header_container.add_child(back_button)
	
	# Close button always at the end (right)
	header_container.add_child(close_button)

# Helper: Create star system list item
func _create_star_system_item(system_data: Dictionary) -> Control:
	var item = PanelContainer.new()
	item.size_flags_horizontal = Control.SIZE_FILL
	
	# Make the panel look like a button with terminal theme styling
	var stylebox = StyleBoxFlat.new()
	stylebox.bg_color = Color(0.15, 0.15, 0.15)  # Darker background
	stylebox.border_color = TerminalTheme.terminal_green
	stylebox.border_width_top = 1
	stylebox.border_width_bottom = 1
	stylebox.border_width_left = 1
	stylebox.border_width_right = 1
	item.add_theme_stylebox_override("panel", stylebox)
	
	# Button to make the whole item clickable
	var button = Button.new()
	button.flat = true
	button.size_flags_horizontal = Control.SIZE_FILL
	button.size_flags_vertical = Control.SIZE_FILL
	button.set_custom_minimum_size(Vector2(0, 60))
	TerminalTheme.apply_to_button(button)
	
	# Create a direct reference to the seed value for the closure
	var seed_value = system_data.seed
	
	# IMPORTANT: Capture a reference to this instance of CelestialInfoPanel
	var self_ref = self
	
	button.pressed.connect(func():
		# Reference the parent node directly using Engine.get_main_loop()
		var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
		if main_node and main_node.has_method("generate_star_system"):
			# This will regenerate the system
			main_node.generate_star_system(seed_value)

			# Clean up any existing pending timer
			if is_instance_valid(self_ref):
				if self_ref._pending_system_timer and is_instance_valid(self_ref._pending_system_timer):
					self_ref._pending_system_timer.timeout.disconnect(self_ref._on_system_timer_timeout)
					self_ref._pending_system_timer.queue_free()

				# Use named method callback instead of lambda to avoid capture issues
				self_ref._pending_seed_value = seed_value
				self_ref._pending_system_timer = Timer.new()
				Engine.get_main_loop().get_root().add_child(self_ref._pending_system_timer)
				self_ref._pending_system_timer.wait_time = 0.2
				self_ref._pending_system_timer.one_shot = true
				self_ref._pending_system_timer.timeout.connect(self_ref._on_system_timer_timeout)
				self_ref._pending_system_timer.start()
	)
	
	item.add_child(button)
	
	# Content layout
	var content = HBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_FILL
	content.size_flags_vertical = Control.SIZE_FILL
	content.mouse_filter = Control.MOUSE_FILTER_IGNORE  # Pass events to parent
	content.set_custom_minimum_size(Vector2(0, 50))
	item.add_child(content)
	
	# Star icon as small TextureRect
	var star_icon = TextureRect.new()
	
	# Use compatible TextureRect properties
	star_icon.expand = true
	star_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	
	# Set size using set_custom_minimum_size instead of custom_minimum_size
	star_icon.set_custom_minimum_size(Vector2(25, 25))
	star_icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	
	# Use color modulation to represent star type
	var color = _get_star_type_color(system_data.star_type)
	star_icon.modulate = color
	
	# Try to get a reference to the sun texture from the main scene
	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if main_node and "sun_texture" in main_node:
		star_icon.texture = main_node.sun_texture
	
	content.add_child(star_icon)
	
	# Spacer
	var spacer = Control.new()
	spacer.set_custom_minimum_size(Vector2(10, 0))
	content.add_child(spacer)
	
	# Info container
	var info_container = VBoxContainer.new()
	info_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info_container.size_flags_vertical = Control.SIZE_FILL
	info_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.add_child(info_container)
	
	# System name/ID
	var name_label = Label.new()
	if "name" in system_data:
		name_label.text = system_data.name
	else:
		name_label.text = "System #" + str(system_data.seed)
	name_label.clip_text = true
	info_container.add_child(name_label)
	TerminalTheme.apply_to_label(name_label)
	
	# Star type and planet count
	var details_label = Label.new()
	details_label.text = "Type: " + system_data.star_type + " | Planets: " + str(system_data.planet_count)
	details_label.add_theme_font_size_override("font_size", 12)
	info_container.add_child(details_label)
	TerminalTheme.apply_to_label(details_label)
	
	# Fix hover effects
	var hover_stylebox = stylebox.duplicate()
	hover_stylebox.bg_color = Color(0.25, 0.25, 0.25)

	var item_ref = item
	item.mouse_entered.connect(func():
		if is_instance_valid(item_ref):
			item_ref.add_theme_stylebox_override("panel", hover_stylebox)
	)
	
	item.mouse_exited.connect(func():
		if is_instance_valid(item_ref):
			item_ref.add_theme_stylebox_override("panel", stylebox)
	)
	
	return item

# Helper: Create planet list item
func _create_planet_item(planet: Planet) -> Control:
	var item = PanelContainer.new()
	item.size_flags_horizontal = Control.SIZE_FILL
	
	# Make the panel look like a button with terminal theme styling
	var stylebox = StyleBoxFlat.new()
	stylebox.bg_color = Color(0.15, 0.15, 0.15)
	stylebox.border_color = TerminalTheme.terminal_green
	stylebox.border_width_top = 1
	stylebox.border_width_bottom = 1
	stylebox.border_width_left = 1
	stylebox.border_width_right = 1
	item.add_theme_stylebox_override("panel", stylebox)
	
	# Button to make the whole item clickable
	var button = Button.new()
	button.flat = true
	button.size_flags_horizontal = Control.SIZE_FILL
	button.size_flags_vertical = Control.SIZE_FILL
	button.set_custom_minimum_size(Vector2(0, 50))
	TerminalTheme.apply_to_button(button)
	
	# Store reference to planet for closure
	var planet_ref = planet
	# IMPORTANT: Capture a reference to this instance of CelestialInfoPanel
	var self_ref = self
	
	button.pressed.connect(func():
		if is_instance_valid(planet_ref) and is_instance_valid(self_ref):
			self_ref._show_planet_view(planet_ref)
	)
	
	item.add_child(button)
	
	# Content layout
	var content = HBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_FILL
	content.size_flags_vertical = Control.SIZE_FILL
	content.mouse_filter = Control.MOUSE_FILTER_IGNORE  # Pass events to parent
	item.add_child(content)
	
	# Planet icon as TextureRect
	var planet_icon = TextureRect.new()
	
	# Use compatible TextureRect properties
	planet_icon.expand = true
	planet_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	
	if planet.planet_sprite and planet.planet_sprite.texture:
		planet_icon.texture = planet.planet_sprite.texture
		planet_icon.modulate = planet.planet_sprite.modulate
		
		# Scale down the icon (25x25 pixels or less)
		planet_icon.set_custom_minimum_size(Vector2(20, 20))
	
	planet_icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	content.add_child(planet_icon)
	
	# Spacer
	var spacer = Control.new()
	spacer.set_custom_minimum_size(Vector2(10, 0))
	content.add_child(spacer)
	
	# Info container
	var info_container = VBoxContainer.new()
	info_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info_container.size_flags_vertical = Control.SIZE_FILL
	info_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.add_child(info_container)
	
	# Planet name
	var name_label = Label.new()
	name_label.text = planet.planet_name
	name_label.clip_text = true
	info_container.add_child(name_label)
	TerminalTheme.apply_to_label(name_label)
	
	# Planet type
	var type_label = Label.new()
	type_label.text = planet.get_planet_type_name()
	type_label.add_theme_font_size_override("font_size", 12)
	info_container.add_child(type_label)
	TerminalTheme.apply_to_label(type_label)
	
	# Fix hover effects
	var hover_stylebox = stylebox.duplicate()
	hover_stylebox.bg_color = Color(0.25, 0.25, 0.25)
	
	var item_ref = item
	item.mouse_entered.connect(func():
		if is_instance_valid(item_ref):
			item_ref.add_theme_stylebox_override("panel", hover_stylebox)
	)
	
	item.mouse_exited.connect(func():
		if is_instance_valid(item_ref):
			item_ref.add_theme_stylebox_override("panel", stylebox)
	)
	
	return item

# Helper: Add a property row to the content
func add_property(p_name: String, value: String):
	var property = HBoxContainer.new()
	property.size_flags_horizontal = Control.SIZE_FILL

	var name_label = Label.new()
	name_label.text = p_name + ":"
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	name_label.clip_text = true  # Prevent text from going out of bounds
	property.add_child(name_label)
	TerminalTheme.apply_to_label(name_label)
	
	var value_label = Label.new()
	value_label.text = value
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	value_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	value_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART  # Enable word wrapping
	property.add_child(value_label)
	TerminalTheme.apply_to_label(value_label)
	
	content_container.add_child(property)

# Helper: Clear all content
func _clear_content():
	for child in content_container.get_children():
		child.queue_free()

# Helper: Get color for star type
func _get_star_type_color(type_name: String) -> Color:
	match type_name:
		"M": return Color(1.0, 0.5, 0.5)   # Red dwarf
		"K": return Color(1.0, 0.7, 0.3)   # Orange dwarf
		"G": return Color(1.0, 1.0, 0.3)   # Yellow (Sun-like)
		"F": return Color(1.0, 1.0, 0.8)   # Yellow-white
		"A": return Color(1.0, 1.0, 1.0)   # White
		"B": return Color(0.8, 0.8, 1.0)   # Blue-white
		"O": return Color(0.6, 0.6, 1.0)   # Blue
		_: return Color(1.0, 1.0, 1.0)     # Default white
