﻿class_name TimeControlPanel
extends Panel

signal time_scale_changed(scale: float)
signal day_night_toggled(enabled: bool)

# Time scale presets (simplified: pause, >, >>, >>>)
const TIME_SCALES = {
	"pause": 0.0,
	"normal": 4.0,   # >
	"fast": 16.0,    # >>
	"faster": 64.0   # >>>
}

const POSITION_MARGIN := 20.0
const PANEL_GAP := 12.0
const BUTTON_HIGHLIGHT := Color(1.2, 1.2, 1.2)

var time_manager: TimeManager = null
var time_scale: float = 1.0
var is_paused: bool = false
var pre_pause_time_scale: float = 1.0

var time_scale_label: Label
var game_time_label: Label
var normal_button: Button
var fast_button: Button
var faster_button: Button
var pause_button: Button
var day_night_button: CheckButton
var time_update_timer: Timer

func _init():
	name = "TimeControlPanel"
	custom_minimum_size = Vector2(220, 100)

	# Black background to match card UI - no border
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.0, 0.0, 0.0, 1.0)  # Pure black
	style.border_width_left = 0
	style.border_width_right = 0
	style.border_width_top = 0
	style.border_width_bottom = 0
	add_theme_stylebox_override("panel", style)

	var main_container = VBoxContainer.new()
	main_container.size_flags_horizontal = Control.SIZE_FILL
	main_container.size_flags_vertical = Control.SIZE_FILL
	main_container.position = Vector2(6, 6)
	main_container.custom_minimum_size = Vector2(208, 88)
	add_child(main_container)

	time_scale_label = Label.new()
	time_scale_label.text = "Speed: >"
	time_scale_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	time_scale_label.add_theme_font_size_override("font_size", 11)
	TerminalTheme.apply_to_label(time_scale_label)
	main_container.add_child(time_scale_label)

	game_time_label = Label.new()
	game_time_label.text = "Game Time: 00:00"
	game_time_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	game_time_label.add_theme_font_size_override("font_size", 11)
	TerminalTheme.apply_to_label(game_time_label)
	main_container.add_child(game_time_label)

	var button_container = HBoxContainer.new()
	button_container.size_flags_horizontal = Control.SIZE_FILL
	button_container.alignment = BoxContainer.ALIGNMENT_CENTER
	main_container.add_child(button_container)

	pause_button = _create_button("||", Vector2(28, 22))
	pause_button.tooltip_text = "Pause/Resume (Spacebar)"
	pause_button.pressed.connect(_on_pause_pressed)
	button_container.add_child(pause_button)

	button_container.add_child(_create_spacer(2))

	normal_button = _create_button(">", Vector2(28, 22))
	normal_button.tooltip_text = "4x - Normal speed"
	normal_button.pressed.connect(func(): set_time_scale(TIME_SCALES.normal))
	button_container.add_child(normal_button)

	fast_button = _create_button(">>", Vector2(32, 22))
	fast_button.tooltip_text = "16x - Fast speed"
	fast_button.pressed.connect(func(): set_time_scale(TIME_SCALES.fast))
	button_container.add_child(fast_button)

	faster_button = _create_button(">>>", Vector2(36, 22))
	faster_button.tooltip_text = "64x - Fastest speed"
	faster_button.pressed.connect(func(): set_time_scale(TIME_SCALES.faster))
	button_container.add_child(faster_button)

	var toggle_container = HBoxContainer.new()
	toggle_container.size_flags_horizontal = Control.SIZE_FILL
	toggle_container.alignment = BoxContainer.ALIGNMENT_CENTER
	main_container.add_child(toggle_container)

	day_night_button = CheckButton.new()
	day_night_button.text = "Day/Night"
	day_night_button.button_pressed = true
	day_night_button.focus_mode = Control.FOCUS_NONE
	day_night_button.add_theme_font_size_override("font_size", 11)
	TerminalTheme.apply_to_button(day_night_button)
	day_night_button.toggled.connect(_on_day_night_toggled)
	toggle_container.add_child(day_night_button)

	_update_button_states()

func _ready():
	set_process_unhandled_key_input(true)
	gui_input.connect(_on_gui_input)  # Consume all input in panel area
	# Only auto-position if we're not inside a container (i.e., added directly to root)
	call_deferred("_check_and_adjust_position")
	_create_time_update_timer()
	_update_game_time_label()

func _check_and_adjust_position():
	await get_tree().process_frame
	# Skip auto-positioning if we're inside a container (like CenterContainer)
	if get_parent() is Container:
		return
	_update_panel_position()
	if get_viewport() and not get_viewport().size_changed.is_connected(_on_viewport_size_changed):
		get_viewport().size_changed.connect(_on_viewport_size_changed)

func _exit_tree():
	# Cleanup: disconnect signals to prevent leaks
	if time_manager:
		if time_manager.is_connected("time_scale_changed", Callable(self, "_on_time_manager_time_scale_changed")):
			time_manager.time_scale_changed.disconnect(_on_time_manager_time_scale_changed)
		if time_manager.has_signal("game_time_reset") and time_manager.is_connected("game_time_reset", Callable(self, "_on_time_manager_time_reset")):
			time_manager.game_time_reset.disconnect(_on_time_manager_time_reset)
	if get_viewport() and get_viewport().size_changed.is_connected(_on_viewport_size_changed):
		get_viewport().size_changed.disconnect(_on_viewport_size_changed)

func _adjust_position():
	await get_tree().process_frame
	_update_panel_position()
	get_viewport().size_changed.connect(_on_viewport_size_changed)

func _watch_control_panel():
	var panel = _find_control_panel()
	if panel and not panel.is_connected("resized", Callable(self, "_on_control_panel_resized")):
		panel.resized.connect(_on_control_panel_resized)

func _on_control_panel_resized():
	_update_panel_position()

func _on_viewport_size_changed():
	_update_panel_position()

func _update_panel_position():
	var viewport_size = get_viewport_rect().size
	var x_pos = viewport_size.x - size.x - POSITION_MARGIN
	var y_pos = POSITION_MARGIN

	# Position at top right
	position = Vector2(x_pos, y_pos)

func _find_control_panel() -> Control:
	if not get_parent():
		return null
	var panel = get_parent().get_node_or_null("ControlPanel")
	return panel if panel is Control else null

func _create_spacer(width: float) -> Control:
	var spacer = Control.new()
	spacer.custom_minimum_size.x = width
	return spacer

func _create_button(text: String, min_size: Vector2) -> Button:
	var button = Button.new()
	button.text = text
	button.custom_minimum_size = min_size
	button.focus_mode = Control.FOCUS_NONE
	# Apply consistent black background styling
	TerminalTheme.apply_to_button(button)
	return button

func _create_time_update_timer():
	time_update_timer = Timer.new()
	time_update_timer.wait_time = 0.5
	time_update_timer.one_shot = false
	time_update_timer.autostart = true
	time_update_timer.timeout.connect(_on_time_update_timer_timeout)
	add_child(time_update_timer)

func _on_time_update_timer_timeout():
	_update_game_time_label()

func set_time_manager(p_time_manager: TimeManager):
	time_manager = p_time_manager
	if time_manager:
		if not time_manager.is_connected("time_scale_changed", Callable(self, "_on_time_manager_time_scale_changed")):
			time_manager.time_scale_changed.connect(_on_time_manager_time_scale_changed)
		if time_manager.has_signal("game_time_reset") and not time_manager.is_connected("game_time_reset", Callable(self, "_on_time_manager_time_reset")):
			time_manager.game_time_reset.connect(_on_time_manager_time_reset)
		sync_time_scale(time_manager.get_time_scale())
	_update_game_time_label()

func _on_time_manager_time_scale_changed(new_scale: float):
	sync_time_scale(new_scale)

func _on_time_manager_time_reset():
	_update_game_time_label()

func set_time_scale(new_scale: float):
	_apply_time_scale(new_scale, true)

func sync_time_scale(new_scale: float):
	_apply_time_scale(new_scale, false)

func _apply_time_scale(new_scale: float, should_emit: bool):
	var snapped_scale = snappedf(new_scale, 0.01)
	if should_emit and is_equal_approx(snapped_scale, time_scale):
		return

	time_scale = snapped_scale
	is_paused = is_zero_approx(time_scale)

	if time_scale_label:
		if is_paused:
			time_scale_label.text = "Speed: PAUSED"
		else:
			var symbol = ">"
			if is_equal_approx(time_scale, TIME_SCALES.fast):
				symbol = ">>"
			elif is_equal_approx(time_scale, TIME_SCALES.faster):
				symbol = ">>>"
			time_scale_label.text = "Speed: " + symbol

	if pause_button:
		pause_button.text = ">" if is_paused else "||"

	_update_button_states()

	if should_emit:
		emit_signal("time_scale_changed", time_scale)

func _on_pause_pressed():
	if is_paused:
		set_time_scale(pre_pause_time_scale)
	else:
		pre_pause_time_scale = time_scale if time_scale > 0.0 else TIME_SCALES.normal
		set_time_scale(TIME_SCALES.pause)

func _update_button_states():
	var buttons = [normal_button, fast_button, faster_button]
	for button in buttons:
		if button:
			button.add_theme_color_override("font_color", TerminalTheme.terminal_green)
			button.modulate = Color(1.0, 1.0, 1.0)

	var current_button: Button = null
	if is_equal_approx(time_scale, TIME_SCALES.normal):
		current_button = normal_button
	elif is_equal_approx(time_scale, TIME_SCALES.fast):
		current_button = fast_button
	elif is_equal_approx(time_scale, TIME_SCALES.faster):
		current_button = faster_button

	if current_button:
		current_button.add_theme_color_override("font_color", Color(0.0, 1.0, 0.0))
		current_button.modulate = BUTTON_HIGHLIGHT

	if pause_button:
		if is_paused:
			pause_button.add_theme_color_override("font_color", Color(1.0, 0.5, 0.0))
			pause_button.modulate = BUTTON_HIGHLIGHT
		else:
			pause_button.add_theme_color_override("font_color", TerminalTheme.terminal_green)
			pause_button.modulate = Color(1.0, 1.0, 1.0)

func handle_input(event: InputEvent) -> bool:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_SPACE:
				_on_pause_pressed()
				return true
			KEY_1:
				set_time_scale(TIME_SCALES.normal)
				return true
			KEY_2:
				set_time_scale(TIME_SCALES.fast)
				return true
			KEY_3:
				set_time_scale(TIME_SCALES.faster)
				return true
	return false

func _on_day_night_toggled(pressed: bool):
	emit_signal("day_night_toggled", pressed)

func _on_gui_input(event: InputEvent):
	# Consume ALL input events in the panel area to prevent click-through
	if event is InputEventMouseButton or event is InputEventMouseMotion:
		accept_event()

func _unhandled_key_input(event: InputEvent):
	if not is_visible_in_tree():
		return
	if handle_input(event):
		get_viewport().set_input_as_handled()

func get_current_time_scale() -> float:
	return time_scale

func _update_game_time_label():
	if not game_time_label:
		return
	if time_manager:
		var days_str = "Day %.1f" % time_manager.game_days_elapsed
		game_time_label.text = days_str + " | " + time_manager.get_formatted_game_time()
	else:
		game_time_label.text = "Day -- | --:--"

