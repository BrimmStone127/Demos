class_name StartScreen
extends Control

signal start_game_requested
signal multiplayer_requested
signal load_game_requested
signal sandbox_requested

var start_button: Button
var load_button: Button
var multiplayer_button: Button
var sandbox_button: Button
var title_label: Label
var subtitle_label: Label
var version_label: Label
var background_panel: Panel
var _has_saves: bool = false

func _init():
	name = "StartScreen"
	anchor_right = 1.0
	anchor_bottom = 1.0
	size_flags_horizontal = Control.SIZE_FILL
	size_flags_vertical = Control.SIZE_FILL

func _ready():
	_create_ui()
	_apply_styling()
	_update_load_button()
	set_process_input(true)

func set_has_saves(has_saves: bool):
	_has_saves = has_saves
	_update_load_button()

func _create_ui():
	background_panel = Panel.new()
	background_panel.anchor_right = 1.0
	background_panel.anchor_bottom = 1.0
	add_child(background_panel)

	var main_container = CenterContainer.new()
	main_container.anchor_right = 1.0
	main_container.anchor_bottom = 1.0
	add_child(main_container)

	var content_container = VBoxContainer.new()
	content_container.custom_minimum_size = Vector2(600, 420)
	main_container.add_child(content_container)

	var top_spacer = Control.new()
	top_spacer.custom_minimum_size.y = 50
	content_container.add_child(top_spacer)

	title_label = Label.new()
	title_label.text = "STAR EXPLORER"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title_label.add_theme_font_size_override("font_size", 48)
	content_container.add_child(title_label)

	subtitle_label = Label.new()
	subtitle_label.text = "v%s" % Version.SHORT
	subtitle_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle_label.add_theme_font_size_override("font_size", 18)
	content_container.add_child(subtitle_label)

	var middle_spacer = Control.new()
	middle_spacer.custom_minimum_size.y = 60
	content_container.add_child(middle_spacer)

	var button_container = VBoxContainer.new()
	button_container.alignment = BoxContainer.ALIGNMENT_CENTER
	button_container.add_theme_constant_override("separation", 15)
	content_container.add_child(button_container)

	start_button = Button.new()
	start_button.text = "SINGLE PLAYER"
	start_button.custom_minimum_size = Vector2(250, 50)
	start_button.pressed.connect(_on_start_pressed)
	button_container.add_child(start_button)

	load_button = Button.new()
	load_button.text = "LOAD GAME"
	load_button.custom_minimum_size = Vector2(250, 50)
	load_button.pressed.connect(func(): emit_signal("load_game_requested"))
	button_container.add_child(load_button)

	# Only show multiplayer button on native platforms (not on web)
	if OS.get_name() != "Web":
		multiplayer_button = Button.new()
		multiplayer_button.text = "MULTIPLAYER"
		multiplayer_button.custom_minimum_size = Vector2(250, 50)
		multiplayer_button.pressed.connect(func(): emit_signal("multiplayer_requested"))
		button_container.add_child(multiplayer_button)

	sandbox_button = Button.new()
	sandbox_button.text = "SANDBOX"
	sandbox_button.custom_minimum_size = Vector2(250, 50)
	sandbox_button.pressed.connect(func(): emit_signal("sandbox_requested"))
	button_container.add_child(sandbox_button)

	var bottom_spacer = Control.new()
	bottom_spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content_container.add_child(bottom_spacer)

	version_label = Label.new()
	version_label.text = "By Clay Brimm"
	version_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	version_label.add_theme_font_size_override("font_size", 12)
	content_container.add_child(version_label)

	var final_spacer = Control.new()
	final_spacer.custom_minimum_size.y = 30
	content_container.add_child(final_spacer)

func _apply_styling():
	TerminalTheme.apply_recursive(self)

	var bg_style = StyleBoxFlat.new()
	bg_style.bg_color = Color(0.02, 0.02, 0.02, 1.0)
	background_panel.add_theme_stylebox_override("panel", bg_style)

	title_label.add_theme_color_override("font_color", Color(0.0, 1.0, 0.3))
	title_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	subtitle_label.add_theme_color_override("font_color", Color(0.0, 0.7, 0.2))
	subtitle_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	version_label.add_theme_color_override("font_color", Color(0.0, 0.5, 0.15))
	version_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())

	var buttons = [start_button, load_button, sandbox_button]
	if multiplayer_button:
		buttons.insert(2, multiplayer_button)
	var button_style = StyleBoxFlat.new()
	button_style.bg_color = Color(0.1, 0.1, 0.1, 0.9)
	button_style.border_color = TerminalTheme.terminal_green
	button_style.border_width_left = 2
	button_style.border_width_right = 2
	button_style.border_width_top = 2
	button_style.border_width_bottom = 2
	button_style.corner_radius_top_left = 4
	button_style.corner_radius_top_right = 4
	button_style.corner_radius_bottom_left = 4
	button_style.corner_radius_bottom_right = 4

	var button_hover_style = button_style.duplicate()
	button_hover_style.bg_color = Color(0.15, 0.15, 0.15, 0.9)

	var button_pressed_style = button_style.duplicate()
	button_pressed_style.bg_color = Color(0.05, 0.25, 0.05, 0.9)

	for button in buttons:
		if button:
			button.add_theme_stylebox_override("normal", button_style)
			button.add_theme_stylebox_override("hover", button_hover_style)
			button.add_theme_stylebox_override("pressed", button_pressed_style)
			button.add_theme_color_override("font_color", TerminalTheme.terminal_green)
			button.add_theme_font_override("font", TerminalTheme.get_terminal_font())

	_add_pulse_effect()

func _update_load_button():
	if load_button:
		load_button.disabled = not _has_saves

func _add_pulse_effect():
	if not start_button:
		return
	var pulse_tween = create_tween()
	pulse_tween.set_loops()
	pulse_tween.tween_property(start_button, "modulate", Color(1.2, 1.2, 1.2), 1.5)
	pulse_tween.tween_property(start_button, "modulate", Color(1.0, 1.0, 1.0), 1.5)

func _on_start_pressed():
	if start_button:
		start_button.disabled = true
	emit_signal("start_game_requested")

func _input(event):
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_ENTER or event.keycode == KEY_SPACE:
			if start_button and not start_button.disabled:
				_on_start_pressed()
