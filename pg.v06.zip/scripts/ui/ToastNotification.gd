class_name ToastNotification
extends Control

## Lightweight toast notification system.
## Shows small popups below the StatsPanel that fade out.

const TOAST_DURATION := 1.5
const FADE_IN_TIME := 0.15
const FADE_OUT_TIME := 0.4
const TOAST_SPACING := 2
const FONT_SIZE := 11
const PADDING_H := 8
const PADDING_V := 3

var _container: VBoxContainer

func _init():
	name = "ToastNotification"
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _ready():
	_container = VBoxContainer.new()
	_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_container.add_theme_constant_override("separation", TOAST_SPACING)
	add_child(_container)
	add_to_group("toast_notification")

func show_credits(amount: int, reason: String = "") -> void:
	var sign_str = "+" if amount > 0 else ""
	var text = sign_str + str(amount) + " credits"
	if reason != "":
		text += "  " + reason
	_show_toast(text, TerminalTheme.terminal_green)

func show_rank(new_rank: int) -> void:
	_show_toast("Rank up: " + str(new_rank), Color(0.9, 0.8, 0.2))

func _show_toast(message: String, color: Color) -> void:
	var panel = _create_toast(message, color)
	_container.add_child(panel)
	_animate_toast(panel)

func _create_toast(message: String, color: Color) -> PanelContainer:
	var panel = PanelContainer.new()
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.0, 0.0, 0.0, 0.0)
	style.content_margin_left = PADDING_H
	style.content_margin_right = PADDING_H
	style.content_margin_top = PADDING_V
	style.content_margin_bottom = PADDING_V
	panel.add_theme_stylebox_override("panel", style)

	var label = Label.new()
	label.text = message
	label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	label.add_theme_font_size_override("font_size", FONT_SIZE)
	label.add_theme_color_override("font_color", color)
	panel.add_child(label)

	panel.modulate.a = 0.0
	return panel

func _animate_toast(toast: Control) -> void:
	var tween = create_tween()
	tween.tween_property(toast, "modulate:a", 1.0, FADE_IN_TIME)
	tween.tween_interval(TOAST_DURATION)
	tween.tween_property(toast, "modulate:a", 0.0, FADE_OUT_TIME)
	tween.tween_callback(func():
		toast.queue_free()
	)
