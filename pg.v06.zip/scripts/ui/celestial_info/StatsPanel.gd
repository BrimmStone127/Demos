class_name StatsPanel
extends PanelContainer

## Top-left Foundation stats panel with integrated toast area and blueprint shop.

signal stats_panel_clicked

var total_systems: int = 0
var total_planets: int = 0

# Labels
var credits_value: Label
var rank_value: Label
var systems_value: Label
var planets_value: Label
var observation_value: Label

# Toast area lives inside the panel content
var _toast_container: VBoxContainer

# Shop view
var _stats_content: VBoxContainer
var _shop_content: VBoxContainer
var _shop_items_container: VBoxContainer
var _in_shop: bool = false

# MVC Integration
var system_history_ref: StarSystemHistory
var foundation_ref: Foundation
var celestial_info_controller: CelestialInfoController

const FONT_SIZE := 12
const LABEL_FONT_SIZE := 11
const HEADER_FONT_SIZE := 13
const PANEL_WIDTH := 200
const PANEL_PADDING := 6

var _compact: bool = false

func _init(p_system_history: StarSystemHistory = null, p_foundation: Foundation = null, p_compact: bool = false):
	name = "StatsPanel"
	system_history_ref = p_system_history
	foundation_ref = p_foundation
	_compact = p_compact

	mouse_filter = Control.MOUSE_FILTER_STOP
	custom_minimum_size = Vector2(PANEL_WIDTH, 0)

	# PanelContainer auto-sizes to child content
	var margin_c = MarginContainer.new()
	margin_c.add_theme_constant_override("margin_left", PANEL_PADDING)
	margin_c.add_theme_constant_override("margin_right", PANEL_PADDING)
	margin_c.add_theme_constant_override("margin_top", PANEL_PADDING)
	margin_c.add_theme_constant_override("margin_bottom", PANEL_PADDING)
	add_child(margin_c)

	var content = VBoxContainer.new()
	content.add_theme_constant_override("separation", 1)
	margin_c.add_child(content)

	# --- Stats view ---
	_stats_content = VBoxContainer.new()
	_stats_content.add_theme_constant_override("separation", 1)
	content.add_child(_stats_content)

	var header = Label.new()
	header.text = "FOUNDATION"
	header.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	header.add_theme_font_size_override("font_size", HEADER_FONT_SIZE)
	_stats_content.add_child(header)

	var sep = HSeparator.new()
	_stats_content.add_child(sep)

	credits_value = _add_stat_row(_stats_content, "CREDITS")
	rank_value = _add_stat_row(_stats_content, "RANK")

	if not _compact:
		var spacer = HSeparator.new()
		spacer.add_theme_constant_override("separation", 2)
		_stats_content.add_child(spacer)

		systems_value = _add_stat_row(_stats_content, "SYSTEMS")
		planets_value = _add_stat_row(_stats_content, "PLANETS")
		observation_value = _add_stat_row(_stats_content, "STATUS")

	# Shop button
	var shop_sep = HSeparator.new()
	shop_sep.add_theme_constant_override("separation", 4)
	_stats_content.add_child(shop_sep)

	var shop_btn = Button.new()
	shop_btn.text = "[ SHOP ]"
	shop_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	TerminalTheme.apply_to_button(shop_btn)
	shop_btn.pressed.connect(_show_shop)
	_stats_content.add_child(shop_btn)

	# --- Shop view (hidden by default) ---
	_shop_content = VBoxContainer.new()
	_shop_content.add_theme_constant_override("separation", 2)
	_shop_content.visible = false
	content.add_child(_shop_content)

	var shop_header = Label.new()
	shop_header.text = "BLUEPRINTS"
	shop_header.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	shop_header.add_theme_font_size_override("font_size", HEADER_FONT_SIZE)
	_shop_content.add_child(shop_header)

	var shop_sep2 = HSeparator.new()
	_shop_content.add_child(shop_sep2)

	_shop_items_container = VBoxContainer.new()
	_shop_items_container.add_theme_constant_override("separation", 6)
	_shop_content.add_child(_shop_items_container)

	var back_sep = HSeparator.new()
	back_sep.add_theme_constant_override("separation", 4)
	_shop_content.add_child(back_sep)

	var back_btn = Button.new()
	back_btn.text = "< BACK"
	back_btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	TerminalTheme.apply_to_button(back_btn)
	back_btn.pressed.connect(_show_stats)
	_shop_content.add_child(back_btn)

	# Toast container — inside content, below both views
	_toast_container = VBoxContainer.new()
	_toast_container.add_theme_constant_override("separation", 2)
	_toast_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.add_child(_toast_container)

	# Connect data sources
	if system_history_ref:
		system_history_ref.history_updated.connect(_on_history_updated)
		_update_from_history()

	if foundation_ref:
		foundation_ref.credits_changed.connect(_on_credits_changed)
		foundation_ref.rank_changed.connect(_on_rank_changed)
		_update_from_foundation()

func _add_stat_row(parent: VBoxContainer, label_text: String) -> Label:
	var row = HBoxContainer.new()
	row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(row)

	var label = Label.new()
	label.text = label_text
	label.add_theme_font_size_override("font_size", LABEL_FONT_SIZE)
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.add_theme_color_override("font_color", Color(0.0, 0.5, 0.15))
	row.add_child(label)

	var value = Label.new()
	value.text = "0"
	value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	value.add_theme_font_size_override("font_size", FONT_SIZE)
	value.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(value)

	return value

func _ready():
	TerminalTheme.apply_to_panel(self)
	TerminalTheme.apply_recursive(self)
	position = Vector2(12, 12)

	gui_input.connect(_on_panel_clicked)
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)

func _on_panel_clicked(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		emit_signal("stats_panel_clicked")

func _on_mouse_entered():
	modulate = Color(1.1, 1.1, 1.1)
	Input.set_default_cursor_shape(Input.CURSOR_POINTING_HAND)

func _on_mouse_exited():
	modulate = Color(1.0, 1.0, 1.0)
	Input.set_default_cursor_shape(Input.CURSOR_ARROW)

# --- Shop ---

func _show_shop() -> void:
	_in_shop = true
	_stats_content.visible = false
	_shop_content.visible = true
	_rebuild_shop_items()

func _show_stats() -> void:
	_in_shop = false
	_shop_content.visible = false
	_stats_content.visible = true

func _rebuild_shop_items() -> void:
	for child in _shop_items_container.get_children():
		child.queue_free()

	if not foundation_ref:
		return

	for bp_id in Foundation.BLUEPRINTS:
		var bp: Dictionary = Foundation.BLUEPRINTS[bp_id]
		var owned := foundation_ref.has_blueprint(bp_id)

		var item_box = VBoxContainer.new()
		item_box.add_theme_constant_override("separation", 1)
		_shop_items_container.add_child(item_box)

		# Name
		var name_label = Label.new()
		name_label.text = bp.name
		name_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
		name_label.add_theme_font_size_override("font_size", 11)
		name_label.add_theme_color_override("font_color", Color(0.0, 1.0, 0.3) if owned else Color(0.0, 0.85, 0.25))
		item_box.add_child(name_label)

		# Description
		var desc_label = Label.new()
		desc_label.text = bp.description
		desc_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
		desc_label.add_theme_font_size_override("font_size", 9)
		desc_label.add_theme_color_override("font_color", Color(0.0, 0.5, 0.15))
		desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD
		item_box.add_child(desc_label)

		if owned:
			var owned_label = Label.new()
			owned_label.text = "OWNED"
			owned_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
			owned_label.add_theme_font_size_override("font_size", 10)
			owned_label.add_theme_color_override("font_color", Color(0.0, 0.6, 0.15))
			item_box.add_child(owned_label)
		else:
			var buy_btn = Button.new()
			buy_btn.text = "[ BUY %d cr ]" % bp.cost
			buy_btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
			TerminalTheme.apply_to_button(buy_btn)
			if not foundation_ref.can_afford(bp.cost):
				buy_btn.add_theme_color_override("font_color", Color(0.5, 0.2, 0.2))
			buy_btn.pressed.connect(_on_buy_pressed.bind(bp_id))
			item_box.add_child(buy_btn)

func _on_buy_pressed(bp_id: String) -> void:
	if not foundation_ref:
		return
	if foundation_ref.purchase_blueprint(bp_id):
		show_toast("Blueprint acquired", Color(0.0, 1.0, 0.3))
		_rebuild_shop_items()
	else:
		show_toast("Insufficient credits", Color(1.0, 0.3, 0.1))

# --- Toast ---

func show_toast(message: String, color: Color = Color.WHITE) -> void:
	var label = Label.new()
	label.text = message
	label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	label.add_theme_font_size_override("font_size", 11)
	label.add_theme_color_override("font_color", color)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.modulate.a = 0.0
	_toast_container.add_child(label)

	var tween = create_tween()
	tween.tween_property(label, "modulate:a", 1.0, 0.15)
	tween.tween_interval(1.5)
	tween.tween_property(label, "modulate:a", 0.0, 0.4)
	tween.tween_callback(label.queue_free)

# --- Data updates ---

func _on_history_updated():
	_update_from_history()

func _on_credits_changed(balance: int, _delta: int, _reason: String = ""):
	_animate_value(credits_value, balance)
	# Update other foundation stats too
	if foundation_ref and not _compact:
		var observed_count := foundation_ref.observed_systems.size()
		observation_value.text = str(observed_count) + " observed"
	# Refresh shop if open (affordability may have changed)
	if _in_shop:
		_rebuild_shop_items()

func _on_rank_changed(new_rank: int, _old_rank: int):
	_animate_value(rank_value, new_rank, Color(0.9, 0.8, 0.2))

func _update_from_history():
	if not system_history_ref or not systems_value:
		return
	var history_data = system_history_ref.get_history()
	total_systems = history_data.size()
	total_planets = 0
	for system_data in history_data:
		total_planets += system_data.planet_count
	systems_value.text = str(total_systems)
	planets_value.text = str(total_planets)

func _update_from_foundation():
	if not foundation_ref:
		return
	credits_value.text = str(foundation_ref.credits)
	rank_value.text = str(foundation_ref.rank)
	if not _compact:
		var observed_count := foundation_ref.observed_systems.size()
		observation_value.text = str(observed_count) + " observed"

func _animate_value(label: Label, new_value: int, flash_color: Color = Color(0.0, 1.0, 0.3)) -> void:
	var old_value := int(label.text) if label.text.is_valid_int() else 0
	label.text = str(new_value)
	# Brief color flash then back to white
	label.add_theme_color_override("font_color", flash_color)
	var tween = create_tween()
	if old_value != new_value:
		# Count-up effect: briefly show old value rolling to new
		var count_data := {"label": label, "value": old_value}
		tween.tween_method(func(v: int): count_data.label.text = str(v), old_value, new_value, 0.3)
	tween.tween_interval(0.2)
	tween.tween_property(label, "theme_override_colors/font_color", Color.WHITE, 0.4)

func set_foundation(p_foundation: Foundation):
	foundation_ref = p_foundation
	if foundation_ref:
		if not foundation_ref.credits_changed.is_connected(_on_credits_changed):
			foundation_ref.credits_changed.connect(_on_credits_changed)
		if not foundation_ref.rank_changed.is_connected(_on_rank_changed):
			foundation_ref.rank_changed.connect(_on_rank_changed)
		_update_from_foundation()

func update_stats(systems_count: int, planets_count: int):
	total_systems = systems_count
	total_planets = planets_count
	if systems_value:
		systems_value.text = str(total_systems)
	if planets_value:
		planets_value.text = str(total_planets)

func increment_system(planet_count: int = 0):
	total_systems += 1
	total_planets += planet_count
	if systems_value:
		systems_value.text = str(total_systems)
	if planets_value:
		planets_value.text = str(total_planets)

func get_stats() -> Dictionary:
	return {
		"systems": total_systems,
		"planets": total_planets
	}

func set_celestial_info_controller(controller: CelestialInfoController):
	celestial_info_controller = controller

func open_systems_list():
	if celestial_info_controller:
		celestial_info_controller.show_systems_list()
	else:
		emit_signal("stats_panel_clicked")
