class_name BaseCelestialView
extends Control

signal back_requested
signal item_selected(data)
signal view_closed

# Fixed dimensions to match original
var panel_width: float = 400
var panel_height: float = 800  # INCREASED from 600 to 800

# UI Components common to all views
var main_container: VBoxContainer
var header_container: HBoxContainer
var content_container: VBoxContainer
var scroll_container: ScrollContainer
var back_button: Button
var title_label: Label
var close_button: Button

func _init():
	# Common initialization
	size_flags_horizontal = Control.SIZE_FILL
	size_flags_vertical = Control.SIZE_FILL
	
	# Create the basic layout shared by all views
	_create_base_layout()
	
func _create_base_layout():
	# Main container
	main_container = VBoxContainer.new()
	main_container.size_flags_horizontal = Control.SIZE_FILL
	main_container.size_flags_vertical = Control.SIZE_FILL
	main_container.position = Vector2(10, 10)
	main_container.set_custom_minimum_size(Vector2(panel_width - 20, panel_height - 20))
	add_child(main_container)
	
	# Header with title, back button, and close button
	header_container = HBoxContainer.new()
	header_container.size_flags_horizontal = Control.SIZE_FILL
	main_container.add_child(header_container)
	
	# Title (left-aligned)
	title_label = Label.new()
	title_label.text = "Star Systems"  # Default title
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_label.add_theme_font_size_override("font_size", 18)
	header_container.add_child(title_label)
	
	# Back button (positioned in the middle)
	back_button = Button.new()
	back_button.text = "Back"
	back_button.visible = false
	back_button.pressed.connect(func(): emit_signal("back_requested"))
	header_container.add_child(back_button)
	
	# Close button (right-aligned)
	close_button = Button.new()
	close_button.text = "X"
	close_button.pressed.connect(func(): emit_signal("view_closed"))
	header_container.add_child(close_button)
	
	# Separator
	var separator = HSeparator.new()
	main_container.add_child(separator)
	
	# FIXED: Scrollable content container with proper scrolling
	scroll_container = ScrollContainer.new()
	scroll_container.size_flags_horizontal = Control.SIZE_FILL
	scroll_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll_container.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll_container.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO  # ADDED: Enable vertical scrolling
	main_container.add_child(scroll_container)
	
	# FIXED: Content container inside scroll container
	content_container = VBoxContainer.new()
	content_container.size_flags_horizontal = Control.SIZE_FILL
	content_container.size_flags_vertical = Control.SIZE_SHRINK_BEGIN  # CHANGED: from SIZE_FILL to SIZE_SHRINK_BEGIN
	content_container.set_custom_minimum_size(Vector2(panel_width - 40, 0))  # CHANGED: height from fixed to 0
	scroll_container.add_child(content_container)
	
	# Apply terminal theme styling to all elements
	TerminalTheme.apply_recursive(self)
	
	# Ensure buttons are styled properly
	TerminalTheme.apply_to_button(back_button)
	TerminalTheme.apply_to_button(close_button)
	
func update_view(_data):
	# Virtual method to be overridden
	pass
	
func clear_content():
	# Clear all children from content container
	for child in content_container.get_children():
		child.queue_free()
		
func set_title(title_text: String):
	title_label.text = title_text
	
func show_back_button(p_visible: bool, button_text: String = "Back"):
	back_button.visible = p_visible
	back_button.text = button_text

	# Fix button order
	_fix_header_button_order(p_visible)
	
# Helper function to fix button order in header - exactly as in original
func _fix_header_button_order(show_back: bool):
	# To ensure the back button is always on the right, we'll rearrange the header
	
	# First, remove buttons if they exist
	if back_button.get_parent() == header_container:
		header_container.remove_child(back_button)
	if close_button.get_parent() == header_container:
		header_container.remove_child(close_button)
	
	# Keep title on the left
	if title_label.get_parent() != header_container:
		header_container.add_child(title_label)
	
	# Add back button in the middle if required
	if show_back:
		header_container.add_child(back_button)
	
	# Close button always at the end (right)
	header_container.add_child(close_button)

# Helper function to add a property row - copied exactly from original
func add_property(p_name: String, value: String):
	var property = HBoxContainer.new()
	property.size_flags_horizontal = Control.SIZE_FILL

	var name_label = Label.new()
	name_label.text = p_name + ":"
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	name_label.clip_text = true  # Prevent text from going out of bounds
	property.add_child(name_label)
	TerminalTheme.apply_to_label(name_label)
	
	var value_label = Label.new()
	value_label.text = value
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	value_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	value_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART  # Enable word wrapping
	property.add_child(value_label)
	TerminalTheme.apply_to_label(value_label)
	
	content_container.add_child(property)
