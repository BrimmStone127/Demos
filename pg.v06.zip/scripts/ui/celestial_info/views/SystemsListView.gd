class_name SystemsListView
extends BaseCelestialView

# Constructor
func _init():
    super._init()
    
func update_view(systems_data: Array):
    # Clear the content
    clear_content()
    
    # Set up view
    set_title("Star Systems")
    show_back_button(false)
    
    # Check if systems list is empty
    if systems_data.size() == 0:
        var empty_label = Label.new()
        empty_label.text = "No star systems discovered yet.\nExplore the universe!"
        empty_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        empty_label.set_custom_minimum_size(Vector2(0, 100))
        empty_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        content_container.add_child(empty_label)
        TerminalTheme.apply_to_label(empty_label)
        return
    
    # Add each star system as a clickable item
    for system_data in systems_data:
        var item = _create_star_system_item(system_data)
        content_container.add_child(item)
        
        # Add spacing between items
        var spacer = Control.new()
        spacer.set_custom_minimum_size(Vector2(0, 5))
        content_container.add_child(spacer)
        
# Helper: Create star system list item - copied exactly from original
func _create_star_system_item(system_data: StarSystemModel) -> Control:
    var item = PanelContainer.new()
    item.size_flags_horizontal = Control.SIZE_FILL
    
    # Make the panel look like a button with terminal theme styling
    var stylebox = StyleBoxFlat.new()
    stylebox.bg_color = Color(0.15, 0.15, 0.15)  # Darker background
    stylebox.border_color = TerminalTheme.terminal_green
    stylebox.border_width_top = 1
    stylebox.border_width_bottom = 1
    stylebox.border_width_left = 1
    stylebox.border_width_right = 1
    item.add_theme_stylebox_override("panel", stylebox)
    
    # Button to make the whole item clickable
    var button = Button.new()
    button.flat = true
    button.size_flags_horizontal = Control.SIZE_FILL
    button.size_flags_vertical = Control.SIZE_FILL
    button.set_custom_minimum_size(Vector2(0, 60))
    TerminalTheme.apply_to_button(button)
    
    # Connect signal
    button.pressed.connect(func(): emit_signal("item_selected", system_data))
    
    item.add_child(button)
    
    # Content layout
    var content = HBoxContainer.new()
    content.size_flags_horizontal = Control.SIZE_FILL
    content.size_flags_vertical = Control.SIZE_FILL
    content.mouse_filter = Control.MOUSE_FILTER_IGNORE  # Pass events to parent
    content.set_custom_minimum_size(Vector2(0, 50))
    item.add_child(content)
    
    # Star icon as small TextureRect
    var star_icon = TextureRect.new()
    
    # Use compatible TextureRect properties
    star_icon.expand = true
    star_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    
    # Set size using set_custom_minimum_size instead of custom_minimum_size
    star_icon.set_custom_minimum_size(Vector2(25, 25))
    star_icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    
    # Use color modulation to represent star type
    var color = _get_star_type_color(system_data.star_type)
    star_icon.modulate = color
    
    # Try to get a reference to the sun texture from the main scene
    var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
    if main_node and "sun_texture" in main_node:
        star_icon.texture = main_node.sun_texture
    
    content.add_child(star_icon)
    
    # Spacer
    var spacer = Control.new()
    spacer.set_custom_minimum_size(Vector2(10, 0))
    content.add_child(spacer)
    
    # Info container
    var info_container = VBoxContainer.new()
    info_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    info_container.size_flags_vertical = Control.SIZE_FILL
    info_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
    content.add_child(info_container)
    
    # System name/ID
    var name_label = Label.new()
    name_label.text = system_data.name if not system_data.name.is_empty() else "System #" + str(system_data.unique_id)
    name_label.clip_text = true
    info_container.add_child(name_label)
    TerminalTheme.apply_to_label(name_label)
    
    # Star type and planet count
    var details_label = Label.new()
    details_label.text = "Type: " + system_data.star_type + " | Planets: " + str(system_data.planet_count)
    details_label.add_theme_font_size_override("font_size", 12)
    info_container.add_child(details_label)
    TerminalTheme.apply_to_label(details_label)
    
    # Fix hover effects
    var hover_stylebox = stylebox.duplicate()
    hover_stylebox.bg_color = Color(0.25, 0.25, 0.25)

    var item_ref = item
    item.mouse_entered.connect(func():
        if is_instance_valid(item_ref):
            item_ref.add_theme_stylebox_override("panel", hover_stylebox)
    )
    
    item.mouse_exited.connect(func():
        if is_instance_valid(item_ref):
            item_ref.add_theme_stylebox_override("panel", stylebox)
    )
    
    return item

# Helper: Get color for star type - copied exactly from original
func _get_star_type_color(type_name: String) -> Color:
    match type_name:
        "M": return Color(1.0, 0.5, 0.5)   # Red dwarf
        "K": return Color(1.0, 0.7, 0.3)   # Orange dwarf
        "G": return Color(1.0, 1.0, 0.3)   # Yellow (Sun-like)
        "F": return Color(1.0, 1.0, 0.8)   # Yellow-white
        "A": return Color(1.0, 1.0, 1.0)   # White
        "B": return Color(0.8, 0.8, 1.0)   # Blue-white
        "O": return Color(0.6, 0.6, 1.0)   # Blue
        _: return Color(1.0, 1.0, 1.0)     # Default white