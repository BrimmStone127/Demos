class_name PlanetDetailView
extends BaseCelestialView

const LOG_TAG := "PLANET_DETAIL_VIEW"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


signal open_planet_map(planet: Planet)
signal planet_name_updated(old_name: String, new_name: String, planet: PlanetModel)
signal previous_planet_requested()
signal next_planet_requested()

var current_planet: PlanetModel
var name_edit: LineEdit = null

# Probe system properties
var probe_system: ProbeSystem
var probe_buttons_container: VBoxContainer
var detailed_info_container: VBoxContainer
var prev_planet_button: Button = null
var next_planet_button: Button = null

func _init():
	super._init()

func _ready():
	set_process_unhandled_key_input(true)

func _notification(what: int) -> void:
	if what == NOTIFICATION_PREDELETE:
		_disconnect_probe_signals()

func _disconnect_probe_signals() -> void:
	if probe_system:
		if probe_system.probe_arrived.is_connected(_on_probe_completed):
			probe_system.probe_arrived.disconnect(_on_probe_completed)
		if probe_system.discovery_made.is_connected(_on_discovery_made):
			probe_system.discovery_made.disconnect(_on_discovery_made)

# Set probe system method
func set_probe_system(p_probe_system: ProbeSystem):
	# Disconnect from old probe system if any
	_disconnect_probe_signals()

	probe_system = p_probe_system
	if probe_system:
		probe_system.probe_arrived.connect(_on_probe_completed)
		probe_system.discovery_made.connect(_on_discovery_made)

func update_view(planet_data: PlanetModel):
	# Save reference to planet
	current_planet = planet_data
	name_edit = null
	
	# Clear the content
	clear_content()
	
	# Set up view
	set_title(planet_data.name)
	show_back_button(true, "Back to Star")
	
	# Planet image row with navigation buttons
	var image_row = HBoxContainer.new()
	image_row.size_flags_horizontal = Control.SIZE_FILL
	image_row.alignment = BoxContainer.ALIGNMENT_CENTER
	image_row.add_theme_constant_override("separation", 12)
	content_container.add_child(image_row)

	prev_planet_button = _create_navigation_button("<")
	prev_planet_button.pressed.connect(func(): emit_signal("previous_planet_requested"))
	image_row.add_child(prev_planet_button)

	var image_container = CenterContainer.new()
	image_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	image_container.set_custom_minimum_size(Vector2(0, 100))
	image_row.add_child(image_container)

	next_planet_button = _create_navigation_button(">")
	next_planet_button.pressed.connect(func(): emit_signal("next_planet_requested"))
	image_row.add_child(next_planet_button)

	# Create TextureRect for planet
	var planet_image = TextureRect.new()

	# Find texture for the planet
	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if main_node and "planet_texture" in main_node:
		planet_image.texture = main_node.planet_texture
		planet_image.modulate = planet_data.color
		
		# Use compatible TextureRect properties
		planet_image.expand = true
		planet_image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		
		# Scale down to fit within the panel
		var texture_size = planet_image.texture.get_size()
		var scale_factor = min(80.0 / texture_size.x, 80.0 / texture_size.y) * 0.75
		planet_image.set_custom_minimum_size(texture_size * scale_factor)

	image_container.add_child(planet_image)

	# Planet name
	name_edit = LineEdit.new()
	name_edit.text = planet_data.name
	name_edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_edit.select_all_on_focus = true
	name_edit.size_flags_horizontal = Control.SIZE_FILL
	name_edit.add_theme_font_size_override("font_size", 16)
	name_edit.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	name_edit.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	var borderless_style = StyleBoxFlat.new()
	borderless_style.bg_color = Color(0, 0, 0, 0)
	name_edit.add_theme_stylebox_override("normal", borderless_style)
	name_edit.add_theme_stylebox_override("focus", borderless_style)
	name_edit.text_submitted.connect(_on_planet_name_submitted)
	name_edit.focus_exited.connect(func(): _commit_planet_name(name_edit.text))
	content_container.add_child(name_edit)
	_update_name_edit_state()
	
	# Separator
	var separator = HSeparator.new()
	content_container.add_child(separator)
	
	# --- PHYSICAL PROPERTIES ---
	var phys_header = Label.new()
	phys_header.text = "Physical Characteristics"
	phys_header.add_theme_font_size_override("font_size", 13)
	phys_header.add_theme_color_override("font_color", Color(0.6, 0.8, 1.0))
	content_container.add_child(phys_header)
	TerminalTheme.apply_to_label(phys_header)

	add_property("Planet Type", planet_data.planet_type)
	if planet_data.data and "mass" in planet_data.data:
		add_property("Mass", str(snapped(planet_data.data.mass, 0.01)) + " M⊕")
		add_property("Radius", str(snapped(planet_data.data.radius, 0.01)) + " R⊕")
		add_property("Surface Gravity", str(snapped(planet_data.data.surface_gravity, 0.01)) + " g")
		add_property("Axial Tilt", str(snapped(planet_data.data.axial_tilt, 0.1)) + "°")
	else:
		add_property("Relative Size", str(snapped(planet_data.size, 0.01)))
	
	# --- ORBITAL PROPERTIES ---
	var orb_header = Label.new()
	orb_header.text = "Orbital Dynamics"
	orb_header.add_theme_font_size_override("font_size", 13)
	orb_header.add_theme_color_override("font_color", Color(1.0, 0.8, 0.4))
	content_container.add_child(orb_header)
	TerminalTheme.apply_to_label(orb_header)

	add_property("Distance", str(snapped(planet_data.distance, 0.1)) + " units")
	add_property("Eccentricity", str(snapped(planet_data.eccentricity, 0.01)))
	add_property("Orbit Speed", str(snapped(planet_data.orbit_speed * 100, 0.1)) + " units/s")
	
	if planet_data.data:
		var lock_status = "Yes" if planet_data.data.is_tidally_locked else "No"
		add_property("Tidally Locked", lock_status)
	
	# Check discovery level and show appropriate information
	_show_planet_information()

	_update_name_edit_state()

func _on_planet_name_submitted(new_text: String):
	_commit_planet_name(new_text)

func _commit_planet_name(raw_name: String):
	if not current_planet:
		return
	var sanitized = raw_name.strip_edges()
	if sanitized == "":
		if name_edit and is_instance_valid(name_edit):
			name_edit.text = current_planet.name
			name_edit.release_focus()
		return
	var old_name = current_planet.name
	if sanitized == old_name:
		if name_edit and is_instance_valid(name_edit):
			name_edit.text = current_planet.name
			name_edit.release_focus()
		return
	if not _apply_planet_rename(old_name, sanitized):
		_log_warn('Failed to rename planet from %s to %s', [old_name, sanitized])
		_show_probe_required_feedback()
		if name_edit and is_instance_valid(name_edit):
			name_edit.text = current_planet.name
			name_edit.release_focus()
		return
	current_planet.name = sanitized
	set_title(sanitized)
	if name_edit and is_instance_valid(name_edit):
		name_edit.text = sanitized
		name_edit.release_focus()
	_update_name_edit_state()
	emit_signal("planet_name_updated", old_name, sanitized, current_planet)

func _update_name_edit_state():
	if not name_edit or not is_instance_valid(name_edit):
		return
	var rename_allowed = _can_rename_current_planet()
	name_edit.editable = rename_allowed
	name_edit.modulate = Color(1, 1, 1, 1) if rename_allowed else Color(1, 1, 1, 0.6)
	name_edit.tooltip_text = "" if rename_allowed else "Analyze planet before renaming."

func _can_rename_current_planet() -> bool:
	var actual_planet = _find_actual_planet()
	if not actual_planet:
		return false
	if probe_system:
		return probe_system.can_rename_planet(actual_planet)
	return actual_planet.probed_by != ""

func _show_probe_required_feedback():
	if name_edit and is_instance_valid(name_edit):
		name_edit.tooltip_text = "Analyze planet before renaming."
		name_edit.modulate = Color(1, 1, 1, 0.6)

func _apply_planet_rename(old_name: String, new_name: String) -> bool:
	var actual_planet = _find_actual_planet(old_name)
	if not actual_planet:
		_log_warn('Could not find actual planet for rename: %s', [old_name])
		return false
	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if main_node and main_node.has_method("rename_planet"):
		var rename_result = main_node.rename_planet(actual_planet, new_name, old_name)
		if not rename_result:
			_show_probe_required_feedback()
		return rename_result
	actual_planet.planet_name = new_name
	if actual_planet.has_method("_update_name_label"):
		actual_planet._update_name_label()
	return true

# FIXED: Show planet information based on discovery level
func _show_planet_information():
	var discovery_level = ProbeSystem.DiscoveryLevel.BASIC
	var revealed_data = {}
	
	if probe_system:
		var actual_planet = _find_actual_planet()
		if actual_planet:
			discovery_level = probe_system.get_discovery_level(actual_planet)
			revealed_data = probe_system.get_revealed_data(actual_planet)
	
	# FIXED: Clear any existing probe/detailed content first
	_clear_dynamic_content()
	
	# Always show basic information first
	_show_basic_information()
	
	# Show probe interface if probe system exists
	if probe_system:
		_show_probe_interface()
	
	# Show detailed information if discovered
	if discovery_level > ProbeSystem.DiscoveryLevel.BASIC:
		_show_detailed_information(revealed_data)

# NEW: Clear dynamic content (everything except basic planet info)
func _clear_dynamic_content():
	# Find and remove dynamic content (everything after the basic planet properties)
	var children_to_remove = []
	var found_basic_observations = false
	
	for child in content_container.get_children():
		if child is Label and child.text == "Basic Observations":
			found_basic_observations = true
			children_to_remove.append(child)  # Remove this too
		elif found_basic_observations:
			children_to_remove.append(child)
	
	# Remove the dynamic content
	for child in children_to_remove:
		child.queue_free()

# Show basic observations header
func _show_basic_information():
	var basic_header = Label.new()
	basic_header.text = "Basic Observations"
	basic_header.add_theme_font_size_override("font_size", 14)
	basic_header.add_theme_color_override("font_color", Color(0.8, 0.8, 0.8))
	content_container.add_child(basic_header)
	TerminalTheme.apply_to_label(basic_header)
	
	# Add small spacing
	var spacer = Control.new()
	spacer.set_custom_minimum_size(Vector2(0, 8))
	content_container.add_child(spacer)

# FIXED: Show probe interface with compact layout
func _show_probe_interface():
	var probe_header = Label.new()
	probe_header.text = "Planetary Exploration"
	probe_header.add_theme_font_size_override("font_size", 14)
	probe_header.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	content_container.add_child(probe_header)
	TerminalTheme.apply_to_label(probe_header)
	
	# Resources display
	var resources_label = Label.new()
	resources_label.text = "Resources: " + str(probe_system.player_resources)
	resources_label.add_theme_font_size_override("font_size", 11)
	content_container.add_child(resources_label)
	TerminalTheme.apply_to_label(resources_label)
	
	# Probe buttons container
	probe_buttons_container = VBoxContainer.new()
	probe_buttons_container.size_flags_horizontal = Control.SIZE_FILL
	content_container.add_child(probe_buttons_container)
	
	_update_probe_buttons()
	_show_active_probes()
	
	# Add small spacing
	var spacer = Control.new()
	spacer.set_custom_minimum_size(Vector2(0, 8))
	content_container.add_child(spacer)
	
	_add_surface_mapping_button()

func _add_surface_mapping_button():
	# Only show if we have orbital survey data
	var actual_planet = _find_actual_planet()
	if not actual_planet:
		return
	
	var completed_probes = probe_system.get_completed_probes(actual_planet)
	if ProbeSystem.ProbeType.PRIMITIVE_ORBITAL not in completed_probes:
		return
	
	# Add spacing before mapping section
	var spacer = Control.new()
	spacer.set_custom_minimum_size(Vector2(0, 10))
	probe_buttons_container.add_child(spacer)
	
	# Surface mapping header
	var mapping_header = Label.new()
	mapping_header.text = "Surface Analysis"
	mapping_header.add_theme_font_size_override("font_size", 12)
	mapping_header.add_theme_color_override("font_color", Color(0.0, 0.9, 0.3))
	probe_buttons_container.add_child(mapping_header)
	TerminalTheme.apply_to_label(mapping_header)
	
	# Surface map button
	var map_button = Button.new()
	map_button.text = "View Surface Map"
	map_button.size_flags_horizontal = Control.SIZE_FILL
	map_button.custom_minimum_size.y = 26
	map_button.add_theme_font_size_override("font_size", 11)
	map_button.pressed.connect(_open_surface_map)
	probe_buttons_container.add_child(map_button)
	TerminalTheme.apply_to_button(map_button)

func _open_surface_map():
	var actual_planet = _find_actual_planet()
	if actual_planet:
		emit_signal("open_planet_map", actual_planet)

# FIXED: Very compact probe buttons
func _update_probe_buttons():
	# Clear existing buttons
	for child in probe_buttons_container.get_children():
		child.queue_free()
	
	var actual_planet = _find_actual_planet()
	if not actual_planet:
		return
	
	var available_probes = probe_system.get_available_probes(actual_planet)
	var completed_probes = probe_system.get_completed_probes(actual_planet)
	
	for probe_type in ProbeSystem.ProbeType.values():
		var spec = ProbeSystem.PROBE_SPECS[probe_type]
		
		var button = Button.new()
		button.size_flags_horizontal = Control.SIZE_FILL
		button.custom_minimum_size.y = 22
		button.add_theme_font_size_override("font_size", 11)
		
		if probe_type in completed_probes:
			button.text = spec.name + " ✓"
			button.disabled = true
			button.add_theme_color_override("font_color", Color(0.0, 1.0, 0.0))
		elif probe_type in available_probes:
			button.text = spec.name + " (" + str(spec.cost) + ")"
			button.disabled = false
			button.pressed.connect(func(): _launch_probe(probe_type))
		else:
			button.text = spec.name + " (Locked)"
			button.disabled = true
			button.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
		
		probe_buttons_container.add_child(button)
		TerminalTheme.apply_to_button(button)
		
		# Tiny spacing between buttons
		var tiny_spacer = Control.new()
		tiny_spacer.set_custom_minimum_size(Vector2(0, 2))
		probe_buttons_container.add_child(tiny_spacer)

# FIXED: Compact active probes display
func _show_active_probes():
	var actual_planet = _find_actual_planet()
	if not actual_planet:
		return
	
	var active_probes = []
	for probe in probe_system.active_probes:
		if probe.target == actual_planet:
			active_probes.append(probe)
	
	if active_probes.size() > 0:
		var active_header = Label.new()
		active_header.text = "Active Missions:"
		active_header.add_theme_font_size_override("font_size", 11)
		active_header.add_theme_color_override("font_color", Color(0.0, 0.8, 1.0))
		probe_buttons_container.add_child(active_header)
		TerminalTheme.apply_to_label(active_header)
		
		for probe in active_probes:
			var spec = ProbeSystem.PROBE_SPECS[probe.probe_type]
			var probe_label = Label.new()
			probe_label.text = "• " + spec.name + " - " + str(int(probe.remaining_time)) + "s"
			probe_label.add_theme_font_size_override("font_size", 10)
			probe_label.add_theme_color_override("font_color", Color(0.0, 0.8, 1.0))
			probe_buttons_container.add_child(probe_label)
			TerminalTheme.apply_to_label(probe_label)

# Show detailed information from probe data
func _show_detailed_information(revealed_data: Dictionary):
	detailed_info_container = VBoxContainer.new()
	detailed_info_container.size_flags_horizontal = Control.SIZE_FILL
	content_container.add_child(detailed_info_container)
	
	# --- ATMOSPHERIC ANALYSIS ---
	if revealed_data.has("atmosphere_type"):
		var atmo_header = Label.new()
		atmo_header.text = "Atmospheric Analysis"
		atmo_header.add_theme_font_size_override("font_size", 13)
		atmo_header.add_theme_color_override("font_color", Color(0.4, 0.9, 0.9))
		detailed_info_container.add_child(atmo_header)
		TerminalTheme.apply_to_label(atmo_header)

		_add_detailed_property("Atmosphere Type", revealed_data.atmosphere_type)
		if revealed_data.has("atmosphere_pressure"):
			_add_detailed_property("Pressure", str(snapped(revealed_data.atmosphere_pressure, 0.01)) + " atm")
		if revealed_data.has("climate_type"):
			_add_detailed_property("Climate", revealed_data.climate_type)
		if revealed_data.has("surface_temperature"):
			_add_detailed_property("Surface Temp", str(int(revealed_data.surface_temperature)) + " K")
		if revealed_data.has("temperature_variation"):
			_add_detailed_property("Variation", "±" + str(int(revealed_data.temperature_variation)) + " K")

	# --- GEOLOGICAL ANALYSIS ---
	if revealed_data.has("geological_activity"):
		var geo_header = Label.new()
		geo_header.text = "Geological Analysis"
		geo_header.add_theme_font_size_override("font_size", 13)
		geo_header.add_theme_color_override("font_color", Color(1.0, 0.6, 0.4))
		detailed_info_container.add_child(geo_header)
		TerminalTheme.apply_to_label(geo_header)

		_add_detailed_property("Activity Level", revealed_data.geological_activity)
		if revealed_data.has("magnetosphere"):
			_add_detailed_property("Magnetosphere", revealed_data.magnetosphere)
		if revealed_data.has("tectonic_plates"):
			_add_detailed_property("Tectonic Plates", str(revealed_data.tectonic_plates))
		
		if revealed_data.has("surface_composition"):
			var comp_parts = []
			for mat in revealed_data.surface_composition:
				comp_parts.append(mat.capitalize() + " (" + str(int(revealed_data.surface_composition[mat]*100)) + "%)")
			_add_detailed_property("Composition", ", ".join(comp_parts))

	# --- HABITABILITY & BIOLOGY ---
	if revealed_data.has("habitability_score") or revealed_data.has("biosignatures"):
		var hab_header = Label.new()
		hab_header.text = "Habitability & Biology"
		hab_header.add_theme_font_size_override("font_size", 13)
		hab_header.add_theme_color_override("font_color", Color(0.4, 1.0, 0.4))
		detailed_info_container.add_child(hab_header)
		TerminalTheme.apply_to_label(hab_header)

		if revealed_data.has("habitability_score"):
			var score = revealed_data.habitability_score
			var rating = "Uninhabitable"
			if score > 0.8: rating = "Highly Habitable"
			elif score > 0.6: rating = "Habitable" 
			elif score > 0.3: rating = "Marginally Habitable"
			_add_detailed_property("Habitability", str(snapped(score, 0.01)) + " (" + rating + ")")
		
		if revealed_data.has("biosignatures"):
			var biosigs = revealed_data.biosignatures
			if biosigs.detected:
				_add_detailed_property("Biosignatures", "DETECTED (" + str(int(biosigs.confidence * 100)) + "%)")
			else:
				_add_detailed_property("Biosignatures", "None detected")

func _unhandled_key_input(event):
	if not is_visible_in_tree():
		return

	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_LEFT:
				if prev_planet_button and not prev_planet_button.disabled:
					emit_signal("previous_planet_requested")
					get_viewport().set_input_as_handled()
			KEY_RIGHT:
				if next_planet_button and not next_planet_button.disabled:
					emit_signal("next_planet_requested")
					get_viewport().set_input_as_handled()

func set_navigation_state(has_previous: bool, has_next: bool):
	if prev_planet_button:
		prev_planet_button.disabled = not has_previous
	if next_planet_button:
		next_planet_button.disabled = not has_next

func _create_navigation_button(symbol: String) -> Button:
	var button = Button.new()
	button.text = symbol
	button.focus_mode = Control.FOCUS_NONE
	button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	button.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	button.custom_minimum_size = Vector2(28, 28)
	TerminalTheme.apply_to_button(button)
	return button

# Add detailed property with green styling
func _add_detailed_property(p_name: String, value: String):
	var property = HBoxContainer.new()
	property.size_flags_horizontal = Control.SIZE_FILL

	var name_label = Label.new()
	name_label.text = p_name + ":"
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	name_label.clip_text = true
	name_label.add_theme_color_override("font_color", Color(0.0, 0.9, 0.3))
	name_label.add_theme_font_size_override("font_size", 11)
	property.add_child(name_label)
	TerminalTheme.apply_to_label(name_label)
	
	var value_label = Label.new()
	value_label.text = value
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	value_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	value_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	value_label.add_theme_color_override("font_color", Color(0.0, 0.9, 0.3))
	value_label.add_theme_font_size_override("font_size", 11)
	property.add_child(value_label)
	TerminalTheme.apply_to_label(value_label)
	
	detailed_info_container.add_child(property)

# Launch probe
func _launch_probe(probe_type: ProbeSystem.ProbeType):
	var actual_planet = _find_actual_planet()
	if not actual_planet:
		_log_error('Error: Could not find actual planet object')
		return
	
	if probe_system.launch_probe(probe_type, actual_planet):
		_update_probe_buttons()
		_show_active_probes()
		
		var spec = ProbeSystem.PROBE_SPECS[probe_type]
		_log_info('Successfully launched %s to %s', [spec.name, current_planet.name])

# Find actual planet object in game world
func _find_actual_planet(fallback_name: String = "") -> Planet:
	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if not main_node or not main_node.has_method("get_current_star_system"):
		return null
	
	var star_system = main_node.get_current_star_system()
	if not star_system:
		return null
	
	for child in star_system.get_children():
		if child is Planet:
			if current_planet and child.get_instance_id() == current_planet.unique_id:
				return child
			if current_planet and child.planet_name == current_planet.name:
				return child
			if fallback_name != "" and child.planet_name == fallback_name:
				return child
	
	return null

# Handle probe completion
func _on_probe_completed(target, probe_type, _data):
	var actual_planet = _find_actual_planet()
	if actual_planet == target:
		_show_planet_information()
		_update_name_edit_state()
		var spec = ProbeSystem.PROBE_SPECS[probe_type]
		_log_info('Probe mission completed: %s has finished analyzing %s', [spec.name, current_planet.name])

# Handle discovery events
func _on_discovery_made(discovery_type: String, target, _data):
	var actual_planet = _find_actual_planet()
	if actual_planet == target:
		match discovery_type:
			"habitable_world":
				_log_info('DISCOVERY: %s shows strong signs of habitability!', [current_planet.name])
			"biosignatures":
				_log_info('MAJOR DISCOVERY: Potential biosignatures detected on %s!', [current_planet.name])
			"extreme_geology":
				_log_info('DISCOVERY: Extreme geological activity detected on %s', [current_planet.name])
			"unusual_atmosphere":
				_log_info('DISCOVERY: Unusual atmospheric composition found on %s', [current_planet.name])
		
		_show_planet_information()
		_update_name_edit_state()
