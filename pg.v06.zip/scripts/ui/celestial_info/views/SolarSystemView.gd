class_name SolarSystemView
extends BaseCelestialView

var current_system: StarSystemModel

func _init():
	super._init()

func update_view(system_data: StarSystemModel):
	# Save reference to the system
	current_system = system_data
	
	# Clear the content
	clear_content()
	
	# Set up view
	set_title(system_data.name)
	show_back_button(true, "Back to Systems")
	
	# Star information section with proper padding and separation
	var info_container = VBoxContainer.new()
	info_container.size_flags_horizontal = Control.SIZE_FILL
	info_container.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	content_container.add_child(info_container)
	
	# Star properties
	var star_type_label = Label.new()
	star_type_label.text = "Type: " + system_data.star_type
	info_container.add_child(star_type_label)
	TerminalTheme.apply_to_label(star_type_label)
	
	var seed_label = Label.new()
	seed_label.text = "Seed: " + str(system_data.seed_value)
	info_container.add_child(seed_label)
	TerminalTheme.apply_to_label(seed_label)

	var location_label = Label.new()
	location_label.text = "Sector %d  |  Star %d" % [system_data.sector_index, system_data.star_index]
	info_container.add_child(location_label)
	TerminalTheme.apply_to_label(location_label)
	
	# Add spacer between info and planets list
	var spacer = Control.new()
	spacer.set_custom_minimum_size(Vector2(0, 20))
	content_container.add_child(spacer)
	
	# Planets header
	var planets_header = Label.new()
	planets_header.text = "Planets"
	planets_header.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	planets_header.add_theme_font_size_override("font_size", 16)
	content_container.add_child(planets_header)
	TerminalTheme.apply_to_label(planets_header)
	
	# Add small spacer
	var small_spacer = Control.new()
	small_spacer.set_custom_minimum_size(Vector2(0, 10))
	content_container.add_child(small_spacer)
	
	# Check if there are any planets
	if system_data.planets.size() == 0:
		var no_planets_label = Label.new()
		no_planets_label.text = "No planets in this system."
		no_planets_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		content_container.add_child(no_planets_label)
		TerminalTheme.apply_to_label(no_planets_label)
		return
	
	# Add each planet as a clickable item
	for planet in system_data.planets:
		if planet is PlanetModel:
			var planet_item = _create_planet_item(planet)
			content_container.add_child(planet_item)
			
			# Add spacing between items
			var item_spacer = Control.new()
			item_spacer.set_custom_minimum_size(Vector2(0, 5))
			content_container.add_child(item_spacer)
	
# Helper: Create planet list item - structured exactly like original
func _create_planet_item(planet: PlanetModel) -> Control:
	var item = PanelContainer.new()
	item.size_flags_horizontal = Control.SIZE_FILL
	
	# Make the panel look like a button with terminal theme styling
	var stylebox = StyleBoxFlat.new()
	stylebox.bg_color = Color(0.15, 0.15, 0.15)
	stylebox.border_color = TerminalTheme.terminal_green
	stylebox.border_width_top = 1
	stylebox.border_width_bottom = 1
	stylebox.border_width_left = 1
	stylebox.border_width_right = 1
	item.add_theme_stylebox_override("panel", stylebox)
	
	# Button to make the whole item clickable
	var button = Button.new()
	button.flat = true
	button.size_flags_horizontal = Control.SIZE_FILL
	button.size_flags_vertical = Control.SIZE_FILL
	button.set_custom_minimum_size(Vector2(0, 50))
	TerminalTheme.apply_to_button(button)
	
	# Connect signal
	button.pressed.connect(func(): emit_signal("item_selected", planet))
	
	item.add_child(button)
	
	# Content layout
	var content = HBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_FILL
	content.size_flags_vertical = Control.SIZE_FILL
	content.mouse_filter = Control.MOUSE_FILTER_IGNORE  # Pass events to parent
	item.add_child(content)
	
	# Planet icon as TextureRect
	var planet_icon = TextureRect.new()
	
	# Use compatible TextureRect properties
	planet_icon.expand = true
	planet_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	
	# Find texture for the planet
	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if main_node and "planet_texture" in main_node:
		planet_icon.texture = main_node.planet_texture
		planet_icon.modulate = planet.color
		
		# Scale down the icon (20x20 pixels)
		planet_icon.set_custom_minimum_size(Vector2(20, 20))
	
	planet_icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	content.add_child(planet_icon)
	
	# Spacer
	var spacer = Control.new()
	spacer.set_custom_minimum_size(Vector2(10, 0))
	content.add_child(spacer)
	
	# Info container
	var info_container = VBoxContainer.new()
	info_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info_container.size_flags_vertical = Control.SIZE_FILL
	info_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.add_child(info_container)
	
	# Planet name
	var name_label = Label.new()
	name_label.text = planet.name
	name_label.clip_text = true
	info_container.add_child(name_label)
	TerminalTheme.apply_to_label(name_label)
	
	# Planet type
	var type_label = Label.new()
	type_label.text = planet.planet_type
	type_label.add_theme_font_size_override("font_size", 12)
	info_container.add_child(type_label)
	TerminalTheme.apply_to_label(type_label)
	
	# Fix hover effects
	var hover_stylebox = stylebox.duplicate()
	hover_stylebox.bg_color = Color(0.25, 0.25, 0.25)
	
	var item_ref = item
	item.mouse_entered.connect(func():
		if is_instance_valid(item_ref):
			item_ref.add_theme_stylebox_override("panel", hover_stylebox)
	)
	
	item.mouse_exited.connect(func():
		if is_instance_valid(item_ref):
			item_ref.add_theme_stylebox_override("panel", stylebox)
	)
	
	return item
