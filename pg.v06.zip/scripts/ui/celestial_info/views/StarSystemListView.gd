class_name StarSystemListView
extends BaseCelestialView

func _init():
	super._init()
	
func update_view(systems_data: Array):
	clear_content()
	
	# Create header
	var header = Label.new()
	header.text = "Star Systems"
	add_child(header)
	
	# Check if array is empty - Fixed from .empty()
	if systems_data.size() == 0:
		var empty_label = Label.new()
		empty_label.text = "No star systems discovered yet."
		add_child(empty_label)
		return
		
	# Create scrollable container
	var scroll = ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(scroll)
	
	var list = VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_FILL
	list.size_flags_vertical = Control.SIZE_FILL
	scroll.add_child(list)
	
	# Add each system as an item
	for system in systems_data:
		var item = _create_system_item(system)
		list.add_child(item)
		
func _create_system_item(system: StarSystemModel) -> Control:
	var item = Button.new()
	item.text = system.name
	item.size_flags_horizontal = Control.SIZE_FILL
	
	# Connect signals with metadata
	item.pressed.connect(func(): emit_signal("item_selected", system))
	
	return item
