class_name CelestialInfoController
extends Node

const LOG_TAG := "CELESTIAL_INFO_CTRL"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


signal view_changed(view_type)
signal panel_closed

enum ViewType {
	SYSTEMS_LIST,
	SOLAR_SYSTEM,
	PLANET_DETAIL
}

var view_container: Control
var current_view: BaseCelestialView
var current_view_type: int = -1

var navigation_history = []
var system_history_ref: StarSystemHistory

# Data references
var current_system: StarSystemModel
var current_planet: PlanetModel
var current_planet_index: int = -1

var probe_system: ProbeSystem

func set_probe_system(p_probe_system: ProbeSystem):
	probe_system = p_probe_system

func _init(p_container: Control, p_system_history: StarSystemHistory):
	view_container = p_container
	system_history_ref = p_system_history

func show_systems_list():
	# Clean up current view
	if current_view:
		current_view.queue_free()

	current_planet = null
	current_planet_index = -1
	
	# Create view
	current_view = SystemsListView.new()
	view_container.add_child(current_view)
	
	# Connect signals properly
	current_view.item_selected.connect(func(data): _on_system_selected(data))
	current_view.view_closed.connect(func(): _on_view_closed())
	current_view.back_requested.connect(func(): _on_back_requested())
	
	# Get data from system history
	var systems_data = []
	if system_history_ref:
		for history_item in system_history_ref.get_history():
			systems_data.append(StarSystemModel.from_history_data(history_item))
	
	# Update view with data
	current_view.update_view(systems_data)
	
	# Update state
	current_view_type = ViewType.SYSTEMS_LIST
	emit_signal("view_changed", current_view_type)

func show_solar_system(system: StarSystemModel):
	# Clean up current view
	if current_view:
		current_view.queue_free()

	current_planet = null
	current_planet_index = -1
	
	current_system = system
	_ensure_system_planets_loaded(current_system)
	
	# Create view
	current_view = SolarSystemView.new()
	view_container.add_child(current_view)
	
	# Connect signals properly
	current_view.back_requested.connect(func(): _on_back_requested())
	current_view.item_selected.connect(func(data): _on_planet_selected(data))
	current_view.view_closed.connect(func(): _on_view_closed())
	
	# Update planet models if needed
	refresh_planets_in_system(system)
	
	# Update view with data
	current_view.update_view(system)
	
	# Update state
	current_view_type = ViewType.SOLAR_SYSTEM
	emit_signal("view_changed", current_view_type)
	
func show_planet_detail(planet: PlanetModel, planet_index: int = -1):
	# Clean up current view
	if current_view:
		current_view.queue_free()
	
	var normalized_planet = _ensure_planet_context(planet)
	current_planet = normalized_planet

	if planet_index == -1:
		planet_index = _get_planet_index(current_planet)
	current_planet_index = planet_index

	
	# Create view
	current_view = PlanetDetailView.new()
	
	# IMPORTANT: Set probe system BEFORE adding to scene tree
	if probe_system and current_view.has_method("set_probe_system"):
		current_view.set_probe_system(probe_system)
		_log_info('Set probe system on PlanetDetailView for: %s', [current_planet.name])
	else:
		_log_warn('WARNING: Could not set probe system on PlanetDetailView')
	
	view_container.add_child(current_view)
	
	# Connect signals
	current_view.back_requested.connect(func(): _on_back_requested())
	current_view.view_closed.connect(func(): _on_view_closed())
	current_view.planet_name_updated.connect(_on_planet_name_updated)
	if current_view.has_signal("previous_planet_requested"):
		current_view.previous_planet_requested.connect(func(): _show_adjacent_planet(-1))
	if current_view.has_signal("next_planet_requested"):
		current_view.next_planet_requested.connect(func(): _show_adjacent_planet(1))
	
	# Update view with data
	current_view.update_view(current_planet)
	_update_planet_navigation_state()
	_focus_camera_on_planet(current_planet)
	
	current_view_type = ViewType.PLANET_DETAIL
	emit_signal("view_changed", current_view_type)
	
func _show_adjacent_planet(direction: int):
	if not current_system or not current_planet:
		return

	var index = current_planet_index
	if index == -1:
		index = _get_planet_index(current_planet)
	if index == -1:
		return

	var target_index = index + direction
	if target_index < 0 or target_index >= current_system.planets.size():
		return

	var target_planet = current_system.planets[target_index]
	if target_planet is PlanetModel:
		current_planet_index = target_index
		show_planet_detail(target_planet, target_index)

func _get_planet_index(planet: PlanetModel) -> int:
	if not current_system or not planet:
		return -1

	for i in range(current_system.planets.size()):
		var candidate = current_system.planets[i]
		if candidate is PlanetModel:
			if candidate == planet:
				return i
			if planet.unique_id != 0 and candidate.unique_id == planet.unique_id:
				return i
			if candidate.name == planet.name:
				return i

	return -1

func _ensure_planet_context(planet: PlanetModel) -> PlanetModel:
	if not planet:
		return null

	if planet.parent_system and planet.parent_system is StarSystemModel:
		if not current_system or current_system.seed_value != planet.parent_system.seed_value:
			current_system = planet.parent_system
		_ensure_system_planets_loaded(current_system)
		var matched = _find_matching_planet(current_system, planet)
		if matched:
			return matched

	if current_system:
		_ensure_system_planets_loaded(current_system)
		var existing = _find_matching_planet(current_system, planet)
		if existing:
			return existing

	var system_from_game = _build_system_model_from_game()
	if system_from_game:
		current_system = system_from_game
		var from_game = _find_matching_planet(current_system, planet)
		if from_game:
			return from_game

	if current_system:
		planet.parent_system = current_system
		var fallback = _find_matching_planet(current_system, planet)
		if fallback:
			return fallback
		current_system.planets.append(planet)
		current_system.planet_count = current_system.planets.size()
		return planet

	return planet

func _ensure_system_planets_loaded(system: StarSystemModel):
	if not system:
		return
	if system.planets.is_empty() and system.planet_count > 0:
		refresh_planets_in_system(system)

func _build_system_model_from_game() -> StarSystemModel:
	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if not main_node or not main_node.has_method("get_current_star_system"):
		return null

	var star_system = main_node.get_current_star_system()
	if not star_system:
		return null

	var system_model = StarSystemModel.new(star_system.star_name, star_system.current_seed, star_system.get_star_type_name())
	if main_node and main_node.has_method("_apply_sector_to_model"):
		main_node._apply_sector_to_model(system_model)
	var planets: Array = []
	for child in star_system.get_children():
		if child is Planet:
			var planet_model = PlanetModel.from_planet(child)
			planet_model.parent_system = system_model
			planets.append(planet_model)

	system_model.planets = planets
	system_model.planet_count = planets.size()
	return system_model

func _find_matching_planet(system: StarSystemModel, planet: PlanetModel) -> PlanetModel:
	if not system or not planet:
		return null

	for candidate in system.planets:
		if candidate is PlanetModel:
			if candidate == planet:
				candidate.parent_system = system
				return candidate
			if planet.unique_id != 0 and candidate.unique_id == planet.unique_id:
				candidate.parent_system = system
				return candidate
			if candidate.name == planet.name:
				candidate.parent_system = system
				return candidate

	return null

func _focus_camera_on_planet(planet: PlanetModel):
	var planet_node = _find_planet_node(planet)
	if not planet_node:
		return

	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if not main_node:
		return

	if "camera_manager" in main_node:
		var camera_manager = main_node.camera_manager
		if camera_manager and camera_manager.has_method("track_object"):
			camera_manager.track_object(planet_node)

func _find_planet_node(planet: PlanetModel) -> Planet:
	if not planet:
		return null

	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if not main_node or not main_node.has_method("get_current_star_system"):
		return null

	var star_system = main_node.get_current_star_system()
	if not star_system:
		return null

	for child in star_system.get_children():
		if child is Planet:
			if planet.unique_id != 0 and child.get_instance_id() == planet.unique_id:
				return child
			if child.planet_name == planet.name:
				return child

	return null

func _update_planet_navigation_state():
	if not current_view or not current_view.has_method("set_navigation_state"):
		return

	var has_prev := false
	var has_next := false
	var index = current_planet_index
	if index == -1 and current_planet:
		index = _get_planet_index(current_planet)
		current_planet_index = index
	if index != -1 and current_system:
		has_prev = index > 0
		has_next = index < current_system.planets.size() - 1

	current_view.set_navigation_state(has_prev, has_next)

func navigate_back():
	if navigation_history.size() > 0:
		var prev_view = navigation_history.pop_back()
		
		match prev_view.type:
			ViewType.SYSTEMS_LIST:
				show_systems_list()
			ViewType.SOLAR_SYSTEM:
				if prev_view.data and prev_view.data is StarSystemModel:
					show_solar_system(prev_view.data)
				elif current_system:
					# Fallback to current system
					show_solar_system(current_system)
				else:
					show_systems_list()
	else:
		show_systems_list()

func refresh_planets_in_system(system: StarSystemModel):
	# This would connect to the actual game data to get fresh planet data
	# For now, we'll just create placeholder data if needed
	if system.planets.size() == 0 and system.planet_count > 0:
		# Get planets from game world if possible
		var game_system = find_star_system_in_game(system.seed_value)
		
		if game_system:
			for planet in game_system.get_children():
				if planet is Planet:
					var planet_model = PlanetModel.from_planet(planet)
					planet_model.parent_system = system
					system.planets.append(planet_model)
		else:
			# Create placeholder planets if can't access game data
			for i in range(system.planet_count):
				var planet_model = PlanetModel.new("Planet " + system.name + " " + char(97+i), i)
				planet_model.parent_system = system
				system.planets.append(planet_model)
				
func find_star_system_in_game(seed_value: int):
	# Try to find an actual star system in the game world
	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if main_node and main_node.has_method("get_current_star_system"):
		var star_system = main_node.get_current_star_system()
		if star_system and star_system.current_seed == seed_value:
			return star_system
	return null
		
# Store pending timer reference so we can clean it up if freed
var _pending_system_timer: Timer = null
var _pending_system_data: StarSystemModel = null

func _notification(what):
	if what == NOTIFICATION_PREDELETE:
		# Clean up any pending timer to avoid lambda capture errors
		if _pending_system_timer and is_instance_valid(_pending_system_timer):
			_pending_system_timer.timeout.disconnect(_on_system_timer_timeout)
			_pending_system_timer.queue_free()
			_pending_system_timer = null

func _on_system_timer_timeout():
	var timer = _pending_system_timer
	var system = _pending_system_data
	_pending_system_timer = null
	_pending_system_data = null

	if timer and is_instance_valid(timer):
		timer.queue_free()

	if not is_instance_valid(self):
		return

	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if main_node and main_node.has_method("_on_reset_camera_requested"):
		main_node._on_reset_camera_requested()

	if system:
		show_solar_system(system)

func _on_system_selected(system: StarSystemModel):
	# Save current view to history
	navigation_history.push_back({
		"type": current_view_type,
		"data": null  # We don't need to store previous systems list state
	})

	# FIXED: Regenerate the actual star system in the game world
	var main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	if main_node and main_node.has_method("generate_star_system"):
		# Regenerate the system with the selected seed
		main_node.generate_star_system(system.seed_value)

		# Clean up any existing pending timer
		if _pending_system_timer and is_instance_valid(_pending_system_timer):
			_pending_system_timer.timeout.disconnect(_on_system_timer_timeout)
			_pending_system_timer.queue_free()

		# Wait for the system to be generated, then show the view
		# Use a named method callback instead of lambda to avoid capture issues
		_pending_system_data = system
		_pending_system_timer = Timer.new()
		Engine.get_main_loop().get_root().add_child(_pending_system_timer)
		_pending_system_timer.wait_time = 0.2
		_pending_system_timer.one_shot = true
		_pending_system_timer.timeout.connect(_on_system_timer_timeout)
		_pending_system_timer.start()
	else:
		# Fallback: just show the system view with existing data
		show_solar_system(system)
	
func _on_planet_selected(planet: PlanetModel):
	# Save current view to history
	navigation_history.push_back({
		"type": current_view_type,
		"data": current_system  # Save system to return to
	})
	
	# Show selected planet
	var planet_index = _get_planet_index(planet)
	show_planet_detail(planet, planet_index)
	
func _on_planet_name_updated(old_name: String, new_name: String, planet: PlanetModel):
	if not planet:
		return
	_log_info('Planet renamed from %s to %s', [old_name, new_name])
	planet.name = new_name
	if current_planet and current_planet.unique_id == planet.unique_id:
		current_planet.name = new_name
	if current_system:
		for i in range(current_system.planets.size()):
			var system_planet = current_system.planets[i]
			if system_planet is PlanetModel and system_planet.unique_id == planet.unique_id:
				current_system.planets[i].name = new_name
				break
	
func _on_back_requested():
	navigate_back()
	
func _on_view_closed():
	# Signal that the panel should be closed
	emit_signal("panel_closed")
