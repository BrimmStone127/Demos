class_name CelestialInfoPanelMVC
extends Panel

signal panel_closed

var controller: CelestialInfoController
var view_container: Control

# CHANGED: Make the panel taller
var panel_width: float = 400
var panel_height: float = 800  # INCREASED from 600 to 800

func _init(system_history: StarSystemHistory = null):
	name = "CelestialInfoPanel"
	set_custom_minimum_size(Vector2(panel_width, panel_height))
	
	# Create margin container for proper padding
	var margin_container = MarginContainer.new()
	margin_container.size_flags_horizontal = Control.SIZE_FILL
	margin_container.size_flags_vertical = Control.SIZE_FILL
	margin_container.add_theme_constant_override("margin_left", 0)
	margin_container.add_theme_constant_override("margin_right", 0)
	margin_container.add_theme_constant_override("margin_top", 0)
	margin_container.add_theme_constant_override("margin_bottom", 0)
	add_child(margin_container)
	
	# Create view container
	view_container = Control.new()
	view_container.size_flags_horizontal = Control.SIZE_FILL
	view_container.size_flags_vertical = Control.SIZE_FILL
	margin_container.add_child(view_container)
	
	# Create controller
	controller = CelestialInfoController.new(view_container, system_history)
	controller.panel_closed.connect(_on_panel_closed)
	controller.view_changed.connect(_on_view_changed)
	add_child(controller)
	
	# Add panel styling
	TerminalTheme.apply_to_panel(self)
	
	# Start with systems list view
	controller.show_systems_list()
	
	# Position panel
	call_deferred("_adjust_position")

func _adjust_position():
	# Wait one frame to ensure we have the proper viewport size
	await get_tree().process_frame
	
	var viewport_size = get_viewport_rect().size
	var margin = 20
	
	# Position on right side of screen with margin
	position = Vector2(viewport_size.x - size.x - margin, margin)
	
	# Connect to window resize events
	get_viewport().size_changed.connect(_on_viewport_size_changed)

func _on_viewport_size_changed():
	var viewport_size = get_viewport_rect().size
	var margin = 20
	position = Vector2(viewport_size.x - size.x - margin, margin)

func _on_panel_closed():
	emit_signal("panel_closed")
	queue_free()
	
func _on_view_changed(_view_type: int):
	# Apply terminal theme to ensure consistent styling
	if controller.current_view:
		TerminalTheme.apply_recursive(controller.current_view)
