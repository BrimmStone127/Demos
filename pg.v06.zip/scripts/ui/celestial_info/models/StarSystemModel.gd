class_name StarSystemModel
extends Resource

var name: String
var unique_id: int  # Used for ID
var seed_value: int  # Same as unique_id for star systems
var star_type: String
var planet_count: int
var planets: Array = []  # Array of PlanetModel references
var discovery_timestamp: int  # When system was discovered
var sector_index: int = 0
var star_index: int = 0

func _init(p_name: String = "", p_seed: int = 0, p_type: String = ""):
	name = p_name
	unique_id = p_seed
	seed_value = p_seed
	star_type = p_type
	
# Convert from history data dictionary to model
static func from_history_data(data: Dictionary) -> StarSystemModel:
	var model = StarSystemModel.new(
		data.get("name", "System #" + str(data.seed)),
		data.seed,
		data.star_type
	)
	model.planet_count = data.planet_count
	model.discovery_timestamp = data.get("timestamp", 0)
	return model
