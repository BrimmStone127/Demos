class_name PlanetModel
extends Resource

var name: String
var unique_id: int
var planet_type: String
var distance: float
var size: float
var eccentricity: float
var orbit_angle: float
var orbit_speed: float
var has_atmosphere: bool
var color: Color
var parent_system: StarSystemModel

# Data resource reference
var data: PlanetData

func _init(p_name: String = "", p_id: int = 0):
	name = p_name
	unique_id = p_id
	
# Create from Planet object
static func from_planet(planet: Planet) -> PlanetModel:
	var model = PlanetModel.new(planet.planet_name, planet.get_instance_id())
	
	model.data = planet.data
	model.planet_type = planet.get_planet_type_name()
	model.distance = planet.semi_major_axis
	model.size = planet.planet_size
	model.eccentricity = planet.eccentricity
	model.orbit_angle = planet.orbit_angle
	model.orbit_speed = planet.orbit_speed
	model.has_atmosphere = planet.has_atmosphere
	
	# Get color from sprite if available
	if planet.planet_sprite:
		model.color = planet.planet_sprite.modulate
		
	return model
