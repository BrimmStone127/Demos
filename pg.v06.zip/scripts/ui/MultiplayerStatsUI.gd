# MultiplayerStatsUI.gd - Fixed to properly update player names
class_name MultiplayerStatsUI
extends Panel

const LOG_TAG := "UI_MULTIPLAYER_STATS"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))


var network_manager: NetworkManager
var player_labels: Dictionary = {}  # id -> labels

func _init(p_network_manager: NetworkManager):
	network_manager = p_network_manager
	custom_minimum_size = Vector2(200, 100)
	position = Vector2(20, 100)  # Below normal stats
	
	network_manager.stats_updated.connect(_on_stats_updated)
	network_manager.player_joined.connect(_on_player_joined)
	network_manager.player_left.connect(_on_player_left)

func _ready():
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0, 0, 0, 0.8)
	add_theme_stylebox_override("panel", style)
	
	var vbox = VBoxContainer.new()
	vbox.position = Vector2(10, 10)
	add_child(vbox)
	
	var title = Label.new()
	title.text = "■ Players ■"
	title.add_theme_font_size_override("font_size", 14)
	vbox.add_child(title)
	
	_refresh_display()

func _refresh_display():
	_log_info('Refreshing multiplayer stats display...')
	
	# Clear existing labels
	for id in player_labels:
		for label in player_labels[id]:
			if is_instance_valid(label):
				label.queue_free()
	player_labels.clear()
	
	# Get the vbox container
	var vbox = get_child(0)
	
	# Remove all children except the title (first child)
	while vbox.get_child_count() > 1:
		var child = vbox.get_child(1)
		vbox.remove_child(child)
		child.queue_free()
	
	# Add players from current stats
	var all_stats = network_manager.get_all_stats()
	_log_info('Displaying %s players', [all_stats.size()])
	
	for stats_dict in all_stats:
		_add_player_display(vbox, stats_dict)

func _add_player_display(container: VBoxContainer, stats: Dictionary):
	var id = stats["id"]
	var is_local = (id == network_manager.get_local_player_id())
	
	_log_info('Adding player display for ID=%s Name=%s', [id, stats["name"]])
	
	var name_label = Label.new()
	name_label.text = stats["name"]
	if is_local:
		name_label.text = "▶ " + name_label.text + " (You)"
		name_label.add_theme_color_override("font_color", Color.GREEN)
	else:
		name_label.add_theme_color_override("font_color", Color.CYAN)
	container.add_child(name_label)
	
	var stats_label = Label.new()
	stats_label.text = "  S:%d P:%d H:%d" % [
		stats["systems"],
		stats["planets"], 
		stats["habitable"]
	]
	stats_label.add_theme_font_size_override("font_size", 12)
	container.add_child(stats_label)
	
	player_labels[id] = [name_label, stats_label]

func _on_stats_updated(id: int, stats: Dictionary):
	_log_info('Stats updated for player %s name: %s', [id, stats.get("name", "Unknown")])
	
	# Check if this player's display exists
	if player_labels.has(id):
		# Update the stats label
		var labels = player_labels[id]
		if labels.size() >= 2 and is_instance_valid(labels[1]):
			labels[1].text = "  S:%d P:%d H:%d" % [
				stats["systems"],
				stats["planets"],
				stats["habitable"]
			]
		
		# Update the name label too (in case name changed)
		var is_local = (id == network_manager.get_local_player_id())
		if labels.size() >= 1 and is_instance_valid(labels[0]):
			var name_text = stats.get("name", "Unknown")
			if is_local:
				name_text = "▶ " + name_text + " (You)"
			labels[0].text = name_text
	else:
		# Player doesn't exist in UI yet, refresh everything
		_log_info('Player %s not in display, refreshing...', [id])
		_refresh_display()

func _on_player_joined(id: int, p_name: String):
	_log_info('Player joined: ID=%s Name=%s', [id, p_name])
	_refresh_display()

func _on_player_left(id: int):
	_log_info('Player left: %s', [id])
	if player_labels.has(id):
		for label in player_labels[id]:
			if is_instance_valid(label):
				label.queue_free()
		player_labels.erase(id)
