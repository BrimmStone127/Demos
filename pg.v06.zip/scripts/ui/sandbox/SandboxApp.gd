class_name SandboxApp
extends Control

# Main sandbox application controller
# Manages page navigation and shared state

signal closed()

const LOG_TAG := "SANDBOX_APP"

var sandbox_core: SandboxCore
var time_manager: TimeManager = null

var _tab_bar: PageTabBar
var _page_container: Control
var _current_page: BasePage
var _pages: Array[BasePage] = []

func _ready():
	_log_debug("Initializing Sandbox App")

	# Initialize shared core
	sandbox_core = SandboxCore.new()

	# Initialize time manager for ecosystem simulation
	time_manager = TimeManager.new()
	time_manager.name = "SandboxTimeManager"
	add_child(time_manager)
	sandbox_core.time_manager = time_manager
	_log_debug("TimeManager initialized")

	_build_ui()
	_create_pages()
	_show_page(0)

	# Apply terminal theme styling
	TerminalTheme.apply_recursive(self)

func _build_ui() -> void:
	# Use full screen
	set_anchors_preset(Control.PRESET_FULL_RECT)

	# Add margin for breathing room
	var margin = MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 20)
	margin.add_theme_constant_override("margin_top", 20)
	margin.add_theme_constant_override("margin_right", 20)
	margin.add_theme_constant_override("margin_bottom", 20)
	add_child(margin)

	# Main VBox layout
	var vbox = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	# Top bar with tabs and close button
	var top_bar = HBoxContainer.new()
	top_bar.add_theme_constant_override("separation", 8)
	vbox.add_child(top_bar)

	# Tab navigation
	_tab_bar = PageTabBar.new()
	_tab_bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_tab_bar.tab_changed.connect(_on_tab_changed)
	top_bar.add_child(_tab_bar)

	# Close button
	var close_button = Button.new()
	close_button.text = "✕ Close"
	close_button.custom_minimum_size.x = 100
	close_button.pressed.connect(_on_close_pressed)
	top_bar.add_child(close_button)

	# Page container (expands to fill remaining space)
	_page_container = Control.new()
	_page_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_page_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_page_container.clip_contents = true
	vbox.add_child(_page_container)

func _create_pages() -> void:
	"""Instantiate all sandbox pages."""
	# Page 1: Map Maker (with Paint Tools tab) - Primary tool
	var map_maker = MapMakerPage.new(sandbox_core)
	_add_page(map_maker)

	# Page 2: Asset Browser
	var asset_browser = AssetBrowserPage.new(sandbox_core)
	_add_page(asset_browser)

	# Page 3: Games (minigames)
	var games = MinigamePage.new(sandbox_core)
	_add_page(games)

func _add_page(page: BasePage) -> void:
	"""Add a page to the sandbox."""
	_pages.append(page)
	_tab_bar.add_tab(page.get_page_name(), page.get_page_icon())

	# Add to page container but hide initially
	page.visible = false
	page.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	page.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_page_container.add_child(page)

func _show_page(index: int) -> void:
	"""Switch to a different page."""
	if index < 0 or index >= _pages.size():
		_log_warn("Invalid page index: %d", [index])
		return

	# Deactivate current page
	if _current_page:
		_current_page.visible = false
		_current_page.on_page_deactivated()

	# Activate new page
	_current_page = _pages[index]
	_current_page.visible = true
	_current_page.on_page_activated()

	_log_debug("Switched to page: %s", [_current_page.get_page_name()])

func show_page_by_name(page_name: String) -> void:
	"""Switch to the first page whose get_page_name() matches page_name."""
	for i in range(_pages.size()):
		if _pages[i].get_page_name() == page_name:
			_tab_bar.set_current_tab(i)
			_show_page(i)
			return
	_log_warn("show_page_by_name: no page named '%s'", [page_name])

func _on_tab_changed(tab_index: int) -> void:
	_show_page(tab_index)

func _on_close_pressed() -> void:
	_log_info("Closing Sandbox App")
	closed.emit()
	queue_free()

# ===== LOGGING =====

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, message % values if values.size() > 0 else message)

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, message % values if values.size() > 0 else message)

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, message % values if values.size() > 0 else message)

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, message % values if values.size() > 0 else message)
