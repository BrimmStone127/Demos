class_name MinigamePage
extends BasePage

# Games tab — shows a game picker on load.
# Only instantiates a game when the player selects it; Back returns to the picker.
# Neither game runs while sitting on this tab looking at the menu.

var _selector: Control
var _active_game: Control = null


func get_page_name() -> String:
	return "Games"


func setup_ui() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_build_selector()


func on_page_deactivated() -> void:
	# Tear down any running game when the user switches tabs
	if _active_game:
		_active_game.queue_free()
		_active_game = null
		_selector.visible = true


# ── Selector screen ────────────────────────────────────────────────────────────

func _build_selector() -> void:
	var star_bg := ProceduralStarBackground.new()
	star_bg.star_texture = preload("res://assets/star_particle.png")
	star_bg.star_density = 3.0
	add_child(star_bg)

	_selector = VBoxContainer.new()
	_selector.set_anchors_preset(Control.PRESET_CENTER)
	_selector.add_theme_constant_override("separation", 16)
	add_child(_selector)

	var title := Label.new()
	title.text = "SELECT GAME"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_selector.add_child(title)

	_add_game_button("Matching", _launch_matching)
	_add_game_button("Baseball", _launch_baseball)


func _add_game_button(label: String, callback: Callable) -> void:
	var btn := Button.new()
	btn.text = label
	btn.custom_minimum_size = Vector2(200, 48)
	btn.pressed.connect(callback)
	_selector.add_child(btn)


# ── Launchers ──────────────────────────────────────────────────────────────────

func _launch_matching() -> void:
	_selector.visible = false

	var container := Control.new()
	container.set_anchors_preset(Control.PRESET_FULL_RECT)

	var star_bg := ProceduralStarBackground.new()
	star_bg.star_texture = preload("res://assets/star_particle.png")
	star_bg.star_density = 3.0
	container.add_child(star_bg)

	var vbox := VBoxContainer.new()
	vbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	vbox.add_theme_constant_override("separation", 8)
	container.add_child(vbox)

	# Header
	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 16)
	vbox.add_child(hbox)

	var back_btn := Button.new()
	back_btn.text = "Back"
	back_btn.pressed.connect(_on_back_pressed)
	hbox.add_child(back_btn)

	var status_lbl := Label.new()
	status_lbl.text = ""
	hbox.add_child(status_lbl)

	var score_lbl := Label.new()
	score_lbl.text = "SCORE: 0"
	score_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	score_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hbox.add_child(score_lbl)

	var new_game_btn := Button.new()
	new_game_btn.text = "New Game"
	hbox.add_child(new_game_btn)

	var center := CenterContainer.new()
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(center)

	var game := MatchingGame.new()
	game.score_changed.connect(func(s: int): score_lbl.text = "SCORE: %d" % s)
	game.combo_achieved.connect(func(c: int, t: int):
		status_lbl.text = "x%d COMBO  (%d tiles)" % [c, t]
		get_tree().create_timer(1.5).timeout.connect(func(): status_lbl.text = "")
	)
	new_game_btn.pressed.connect(func():
		game.reset()
		score_lbl.text = "SCORE: 0"
		status_lbl.text = ""
	)
	center.add_child(game)

	_active_game = container
	add_child(container)


func _launch_baseball() -> void:
	_selector.visible = false

	var game := BaseballGame.new()
	game.set_anchors_preset(Control.PRESET_FULL_RECT)
	game.back_pressed.connect(_on_back_pressed)

	_active_game = game
	add_child(game)


# ── Shared back handler ────────────────────────────────────────────────────────

func _on_back_pressed() -> void:
	if _active_game:
		_active_game.queue_free()
		_active_game = null
	_selector.visible = true
