class_name AssetBrowserPage
extends BasePage

# Page 1: Visual catalog of all tiles, textures, and game assets
# Shows ALL 200 tiles from tileset with custom alias support

var _tile_palette: TilePalette
var _info_panel: VBoxContainer
var _selected_tile_info: RichTextLabel
var _export_button: Button
var _alias_manager: TileAliasManager = null
var _selected_tile: TileAliasData = null
var _alias_edit_field: LineEdit = null
var _color_panel: VBoxContainer = null  # Panel for color swatches
var _color_pickers: Array = []  # Array of {swatch: ColorRect, picker: ColorPickerButton, original: Color}
var _preview_sprite: TextureRect = null  # Live preview with color changes
var _current_swapper: PaletteSwapper = null  # Current color swapper for preview

func get_page_name() -> String:
	return "Asset Browser"

func setup_ui() -> void:
	# Load tile catalog
	_alias_manager = TileAliasManager.new()
	if not _alias_manager.load_catalog():
		push_error("AssetBrowserPage: Failed to load tile catalog!")

	# Use full available space
	set_anchors_preset(Control.PRESET_FULL_RECT)

	# Main layout: palette on left, info panel on right (no top bar)
	var hsplit = HSplitContainer.new()
	hsplit.set_anchors_preset(Control.PRESET_FULL_RECT)
	hsplit.size_flags_vertical = Control.SIZE_EXPAND_FILL
	hsplit.split_offset = 650  # Balanced split for larger preview
	add_child(hsplit)

	# Left side: Tile palette (wrapped in panel for visual separation)
	var left_panel = Panel.new()  # Use Panel instead of PanelContainer
	left_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	hsplit.add_child(left_panel)

	# Add margin inside left panel
	var left_margin = MarginContainer.new()
	left_margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	left_margin.add_theme_constant_override("margin_left", 5)
	left_margin.add_theme_constant_override("margin_top", 5)
	left_margin.add_theme_constant_override("margin_right", 5)
	left_margin.add_theme_constant_override("margin_bottom", 5)
	left_panel.add_child(left_margin)

	_tile_palette = TilePalette.new()
	_tile_palette.selectable = false  # Just for browsing, not selecting
	_tile_palette.columns = 6  # Fewer columns for larger tiles
	_tile_palette.use_alias_manager = true  # Load from alias manager
	_tile_palette.alias_manager = _alias_manager  # Pass the manager
	left_margin.add_child(_tile_palette)

	# Right side: Info panel (wrapped in panel with scrolling)
	var right_panel = Panel.new()
	right_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right_panel.custom_minimum_size.x = 480  # Wide enough for 400px preview + margins
	hsplit.add_child(right_panel)

	var right_margin = MarginContainer.new()
	right_margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	right_margin.add_theme_constant_override("margin_left", 10)
	right_margin.add_theme_constant_override("margin_top", 10)
	right_margin.add_theme_constant_override("margin_right", 10)
	right_margin.add_theme_constant_override("margin_bottom", 10)
	right_panel.add_child(right_margin)

	# Scrollable container for all info content
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right_margin.add_child(scroll)

	_info_panel = VBoxContainer.new()
	_info_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_info_panel.add_theme_constant_override("separation", 10)
	scroll.add_child(_info_panel)

	var info_label = Label.new()
	info_label.text = "Tile Information"
	info_label.add_theme_font_size_override("font_size", 18)
	_info_panel.add_child(info_label)

	# Alias editing section
	var alias_section = VBoxContainer.new()
	alias_section.add_theme_constant_override("separation", 5)
	_info_panel.add_child(alias_section)

	var alias_label = Label.new()
	alias_label.text = "Tile Alias:"
	alias_label.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	alias_section.add_child(alias_label)

	var alias_hbox = HBoxContainer.new()
	alias_hbox.add_theme_constant_override("separation", 5)
	alias_section.add_child(alias_hbox)

	_alias_edit_field = LineEdit.new()
	_alias_edit_field.placeholder_text = "Enter custom name..."
	_alias_edit_field.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_alias_edit_field.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	_alias_edit_field.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	alias_hbox.add_child(_alias_edit_field)

	var save_alias_button = Button.new()
	save_alias_button.text = "Save Alias"
	save_alias_button.pressed.connect(_on_save_alias_pressed)
	alias_hbox.add_child(save_alias_button)

	var separator = HSeparator.new()
	separator.add_theme_constant_override("separation", 10)
	_info_panel.add_child(separator)

	# Color editing section
	_setup_color_panel()

	var separator2 = HSeparator.new()
	separator2.add_theme_constant_override("separation", 10)
	_info_panel.add_child(separator2)

	# Tile detail info (no inner scroll - parent scroll handles it)
	_selected_tile_info = RichTextLabel.new()
	_selected_tile_info.bbcode_enabled = true
	_selected_tile_info.fit_content = true
	_selected_tile_info.scroll_active = false
	_selected_tile_info.text = "[i]Click a tile to see details[/i]"
	_selected_tile_info.add_theme_color_override("default_color", TerminalTheme.terminal_green)
	_selected_tile_info.add_theme_font_override("normal_font", TerminalTheme.get_terminal_font())
	_selected_tile_info.add_theme_font_override("bold_font", TerminalTheme.get_terminal_font())
	_selected_tile_info.add_theme_font_override("italics_font", TerminalTheme.get_terminal_font())
	_info_panel.add_child(_selected_tile_info)

	var separator3 = HSeparator.new()
	_info_panel.add_child(separator3)

	# Export button
	_export_button = Button.new()
	_export_button.text = "Export Tileset Catalog (JSON)"
	_export_button.pressed.connect(_on_export_pressed)
	_info_panel.add_child(_export_button)

func _populate_colors(atlas_coords: Vector2i) -> void:
	"""Extract colors from tile and create color picker UI."""
	# Clear existing color pickers
	_color_pickers.clear()

	# Remove old color picker UI (if any)
	for child in _color_panel.get_children():
		if child.has_meta("color_picker_row"):
			child.queue_free()

	# Extract colors from tile
	var colors = TileColorExtractor.extract_colors(atlas_coords, 8)
	print("Extracted %d colors from tile at %s" % [colors.size(), atlas_coords])
	if colors.size() == 0:
		push_warning("No colors extracted from tile!")
		return

	# Create color picker for each color
	var insert_index = 3  # After label, help text, and preview
	for color_data in colors:
		var color: Color = color_data.color
		var percent: float = color_data.percent

		var row = HBoxContainer.new()
		row.set_meta("color_picker_row", true)
		row.add_theme_constant_override("separation", 5)
		_color_panel.add_child(row)
		_color_panel.move_child(row, insert_index)
		insert_index += 1

		# Color swatch (shows current color) - wrapped in clickable panel
		var swatch_container = PanelContainer.new()
		swatch_container.custom_minimum_size = Vector2(24, 24)
		swatch_container.mouse_filter = Control.MOUSE_FILTER_STOP
		swatch_container.tooltip_text = "Right-click to copy hex value"
		row.add_child(swatch_container)

		var swatch = ColorRect.new()
		swatch.color = color
		swatch.mouse_filter = Control.MOUSE_FILTER_IGNORE  # Let parent handle input
		swatch_container.add_child(swatch)

		# Handle right-click on the container
		swatch_container.gui_input.connect(func(event: InputEvent):
			if event is InputEventMouseButton:
				if event.pressed and event.button_index == MOUSE_BUTTON_RIGHT:
					var hex = TileColorExtractor.color_to_hex(swatch.color)
					DisplayServer.clipboard_set(hex)
					print("Copied to clipboard: %s" % hex)
					# Show brief feedback
					swatch_container.modulate = Color(1.5, 1.5, 1.5)
					await get_tree().create_timer(0.1).timeout
					swatch_container.modulate = Color(1, 1, 1)
					get_viewport().set_input_as_handled()
		)

		# Color picker button
		var picker = ColorPickerButton.new()
		picker.custom_minimum_size = Vector2(60, 24)
		picker.color = color
		picker.edit_alpha = true
		picker.color_changed.connect(_on_color_changed.bind(color, swatch))
		row.add_child(picker)

		# Hex label
		var hex_label = Label.new()
		hex_label.text = TileColorExtractor.color_to_hex(color)
		hex_label.add_theme_color_override("font_color", TerminalTheme.terminal_green)
		hex_label.add_theme_font_size_override("font_size", 10)
		hex_label.custom_minimum_size.x = 80
		row.add_child(hex_label)

		# Percentage label
		var percent_label = Label.new()
		percent_label.text = "%.1f%%" % percent
		percent_label.add_theme_color_override("font_color", TerminalTheme.terminal_green.darkened(0.3))
		percent_label.add_theme_font_size_override("font_size", 10)
		row.add_child(percent_label)

		# Store reference (note: swatch is inside swatch_container)
		_color_pickers.append({
			"swatch": swatch,
			"swatch_container": swatch_container,
			"picker": picker,
			"original": color,
			"hex_label": hex_label
		})

func _update_preview_sprite(atlas_coords: Vector2i) -> void:
	"""Update the preview sprite texture."""
	if not _preview_sprite:
		return

	var tile_size = PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	var atlas_tex = AtlasTexture.new()
	atlas_tex.atlas = PlanetMapTileConfig.TILESET_TEXTURE
	atlas_tex.region = Rect2(atlas_coords * tile_size, tile_size)

	_preview_sprite.texture = atlas_tex
	_preview_sprite.material = null  # Reset material

func _on_color_changed(new_color: Color, original_color: Color, swatch: ColorRect) -> void:
	"""Called when user changes a color in the picker."""
	print("Color changed! Original: %s, New: %s" % [original_color, new_color])

	# Update swatch
	swatch.color = new_color

	# Update hex label
	for picker_data in _color_pickers:
		if picker_data.swatch == swatch:
			picker_data.hex_label.text = TileColorExtractor.color_to_hex(new_color)
			print("Updated hex label to: %s" % picker_data.hex_label.text)
			break

	# Apply color swaps to preview
	print("Applying color swaps to preview...")
	_apply_preview_swaps()
	print("Color swaps applied!")

func _apply_preview_swaps() -> void:
	"""Apply current color swaps to the preview sprite."""
	if not _preview_sprite:
		return

	# Create swapper with all color changes
	_current_swapper = PaletteSwapper.new()

	var has_changes = false
	for picker_data in _color_pickers:
		var original: Color = picker_data.original
		var current: Color = picker_data.picker.color

		# Only add swap if color actually changed
		if not original.is_equal_approx(current):
			_current_swapper.add_color_swap(original, current)
			has_changes = true

	# Apply to preview
	if has_changes:
		# CRITICAL: Must configure shader before applying material
		_current_swapper._configure_shader()
		_preview_sprite.material = _current_swapper.material
		print("Applied %d color swaps to preview" % _current_swapper._color_pairs.size())
	else:
		_preview_sprite.material = null  # No changes, use original

func _on_reset_colors_pressed() -> void:
	"""Reset all colors to their original values."""
	if _color_pickers.size() == 0:
		return

	print("Resetting all colors to original values")

	# Reset each color picker to its original color
	for picker_data in _color_pickers:
		var original: Color = picker_data.original
		picker_data.picker.color = original
		picker_data.swatch.color = original
		picker_data.hex_label.text = TileColorExtractor.color_to_hex(original)

	# Remove material from preview (show original)
	_preview_sprite.material = null
	_current_swapper = null

	print("Colors reset to original")

func _on_save_alias_pressed() -> void:
	"""Save the custom alias for the selected tile."""
	if not _selected_tile:
		push_warning("No tile selected")
		return

	var new_alias = _alias_edit_field.text.strip_edges()

	if new_alias.length() == 0:
		# Clear custom alias (revert to default)
		_selected_tile.custom_alias = ""
	else:
		# Set custom alias
		_selected_tile.custom_alias = new_alias

	# Save catalog to user directory
	if _alias_manager.save_catalog():
		print("AssetBrowserPage: Saved alias for tile %d: '%s'" % [_selected_tile.id, new_alias])

		# Refresh the tile preview to show new name
		if _tile_palette:
			_tile_palette.refresh_tile_names()

		# Refresh info panel
		_on_tile_clicked(_selected_tile.id)
	else:
		push_error("Failed to save catalog")

func _setup_color_panel() -> void:
	"""Create the color editing panel UI."""
	_color_panel = VBoxContainer.new()
	_color_panel.add_theme_constant_override("separation", 5)
	_info_panel.add_child(_color_panel)

	var color_label = Label.new()
	color_label.text = "Tile Colors:"
	color_label.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	_color_panel.add_child(color_label)

	var help_label = Label.new()
	help_label.text = "Click color swatches to edit. Changes preview in real-time."
	help_label.add_theme_color_override("font_color", TerminalTheme.terminal_green.darkened(0.3))
	help_label.add_theme_font_size_override("font_size", 10)
	help_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_color_panel.add_child(help_label)

	# Preview sprite (shows tile with modified colors) - 4x larger
	var preview_container = CenterContainer.new()
	_color_panel.add_child(preview_container)

	_preview_sprite = TextureRect.new()
	_preview_sprite.custom_minimum_size = Vector2(400, 400)  # 4x larger
	_preview_sprite.expand_mode = TextureRect.EXPAND_FIT_WIDTH_PROPORTIONAL
	_preview_sprite.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_preview_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST  # Pixel-perfect
	preview_container.add_child(_preview_sprite)

	# Color list will be populated when tile is selected
	# (created dynamically in _populate_colors)

	var separator_apply = HSeparator.new()
	_color_panel.add_child(separator_apply)

	var apply_label = Label.new()
	apply_label.text = "Apply to Forest:"
	apply_label.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	_color_panel.add_child(apply_label)

	var apply_help = Label.new()
	apply_help.text = "Saves current color changes to the tree palette and updates the planet map live."
	apply_help.add_theme_color_override("font_color", TerminalTheme.terminal_green.darkened(0.3))
	apply_help.add_theme_font_size_override("font_size", 10)
	apply_help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_color_panel.add_child(apply_help)

	var apply_hbox = HBoxContainer.new()
	apply_hbox.add_theme_constant_override("separation", 5)
	_color_panel.add_child(apply_hbox)

	var apply_button = Button.new()
	apply_button.text = "Apply to Forest"
	apply_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	apply_button.pressed.connect(_on_apply_to_forest_pressed)
	apply_hbox.add_child(apply_button)

	var reset_button = Button.new()
	reset_button.text = "Reset"
	reset_button.tooltip_text = "Reset colors to original tile values"
	reset_button.pressed.connect(_on_reset_colors_pressed)
	apply_hbox.add_child(reset_button)

	var clear_palette_button = Button.new()
	clear_palette_button.text = "Clear Palette"
	clear_palette_button.tooltip_text = "Remove all saved tree color swaps and revert to default"
	clear_palette_button.pressed.connect(_on_clear_forest_palette_pressed)
	apply_hbox.add_child(clear_palette_button)

func connect_signals() -> void:
	if _tile_palette:
		_tile_palette.tile_clicked.connect(_on_tile_clicked)

func _on_tile_clicked(tile_id: int) -> void:
	"""Display detailed information about the clicked tile."""
	_selected_tile = _alias_manager.get_tile_by_id(tile_id)
	if not _selected_tile:
		_selected_tile_info.text = "[color=red]Error: Tile not found![/color]"
		return

	var coords = _selected_tile.atlas_coords
	var info_text = "[b]Tile Information[/b]\n\n"
	info_text += "[b]ID:[/b] %d\n" % _selected_tile.id
	info_text += "[b]Position:[/b] Row %d, Col %d\n" % [_selected_tile.row, _selected_tile.col]
	info_text += "[b]Atlas Coords:[/b] (%d, %d)\n" % [coords.x, coords.y]

	var pixel_x = coords.x * PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE.x
	var pixel_y = coords.y * PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE.y
	info_text += "[b]Pixel Region:[/b] (%d, %d, %d, %d)\n\n" % [
		pixel_x, pixel_y,
		PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE.x,
		PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE.y
	]

	# Alias info
	info_text += "[b]Default Name:[/b] %s\n" % _selected_tile.default_alias
	if _selected_tile.has_custom_alias():
		info_text += "[b]Custom Alias:[/b] %s\n" % _selected_tile.custom_alias
	else:
		info_text += "[color=gray][i](No custom alias set)[/i][/color]\n"

	# Category
	info_text += "[b]Category:[/b] %s\n\n" % _selected_tile.category

	info_text += "\n[color=gray][i]Tip: Edit the alias above and click 'Save Alias' to rename this tile[/i][/color]\n"
	info_text += "[color=gray][font_size=10]Extract colors: python3 tools/extract_palette.py --tile %d,%d[/font_size][/color]\n" % [coords.y, coords.x]

	_selected_tile_info.text = info_text

	# Update alias edit field
	if _alias_edit_field:
		_alias_edit_field.text = _selected_tile.get_display_name()

	# Extract and display colors
	_populate_colors(_selected_tile.atlas_coords)

	# Update preview sprite
	_update_preview_sprite(_selected_tile.atlas_coords)

func _on_apply_to_forest_pressed() -> void:
	if _color_pickers.is_empty():
		push_warning("No tile selected — click a tree tile first")
		return

	var new_swaps: Array[Dictionary] = []
	for picker_data in _color_pickers:
		var original: Color = picker_data.original
		var current: Color = picker_data.picker.color
		if original.is_equal_approx(current):
			continue
		new_swaps.append({
			"src": [original.r, original.g, original.b, original.a],
			"tgt": [current.r, current.g, current.b, current.a]
		})

	if new_swaps.is_empty():
		push_warning("No color changes to apply — adjust some colors first")
		return

	if VariantManager.get_instance().save_tree_palette(new_swaps):
		print("AssetBrowserPage: Applied %d color swaps to forest palette" % new_swaps.size())
	else:
		push_error("Failed to save tree palette")


func _on_clear_forest_palette_pressed() -> void:
	var path := VariantManager.TREE_PALETTE_PATH
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(path)
	# Invalidate cached material and revert to built-in preset
	var vm := VariantManager.get_instance()
	vm._shared_tree_material = null
	vm.theme_changed.emit(vm.get_current_theme_name())
	print("AssetBrowserPage: Cleared tree palette — reverted to built-in verdant preset")


func _on_export_pressed() -> void:
	"""Export current catalog with all aliases and variants to JSON."""
	if not _alias_manager:
		_selected_tile_info.text = "[b][color=red]Export failed![/color][/b]\n\nAlias manager not initialized."
		return

	# Save catalog to user directory (includes all custom aliases and variants)
	if _alias_manager.save_catalog():
		var path = TileAliasManager.USER_CATALOG_PATH
		_selected_tile_info.text = "[b][color=green]Export successful![/color][/b]\n\n"
		_selected_tile_info.text += "Saved complete catalog to:\n%s\n\n" % path
		_selected_tile_info.text += "Includes:\n"
		_selected_tile_info.text += "• %d tiles\n" % _alias_manager.total_tiles
		_selected_tile_info.text += "• Custom aliases\n"
		_selected_tile_info.text += "• Color variants\n"
		_selected_tile_info.text += "• Categories and tags"
		print("AssetBrowserPage: Exported catalog to %s" % path)
	else:
		_selected_tile_info.text = "[b][color=red]Export failed![/color][/b]\n\nCould not write to file."
