class_name MapMakerPage
extends BasePage

# Page 2: Map Maker - Map creation and editing

var _map_viewport: MapViewport
var _columns_spin: SpinBox
var _rows_spin: SpinBox
var _tool_selector: ToolSelector
var _layer_selector: LayerSelector
var _tile_palette: TilePalette
var _elevation_controls: ElevationControls
var _csv_path_edit: LineEdit
var _csv_downsample_spin: SpinBox
var _file_dialog: FileDialog
var _time_control_panel: TimeControlPanel
var _ecosystem_stats_label: RichTextLabel  # Shows tree counts and ecosystem stats
var _tile_data_label: RichTextLabel  # Shows live data for selected tile
var _selected_tile_pos: Vector2i = Vector2i(-1, -1)  # Currently selected tile
var _tile_data_timer: Timer  # Updates tile data display
var _tree_placement_mode: bool = false  # Toggle for manual tree placement
var _place_tree_button: Button  # Reference for toggle state visual
var _theme_selector: ThemeSelectorPanel  # Visual theme selector
var _search_dialog: TileSearchDialog  # Ctrl+F tile search
var _village_list: VillageListPanel = null
var _village_list_refresh_timer: Timer = null
var _territory_overlay: VillageTerritoryOverlay = null

func get_page_name() -> String:
	return "Map Maker"

func setup_ui() -> void:
	# Use full available space
	set_anchors_preset(Control.PRESET_FULL_RECT)

	# Main HBox: Left panel (320px) | Viewport (expand) | Right panel (320px)
	var hbox = HBoxContainer.new()
	hbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	hbox.add_theme_constant_override("separation", 8)
	add_child(hbox)

	# Left panel - Map creation and painting controls
	_build_left_panel(hbox)

	# Center viewport - TAKES UP MOST OF SCREEN
	_build_viewport(hbox)

	# Right panel - Time and ecosystem controls
	_build_right_panel(hbox)

func _build_left_panel(parent: HBoxContainer) -> void:
	# Control panel - 320px wide with tabs
	var panel = Panel.new()
	panel.custom_minimum_size.x = 320
	panel.size_flags_horizontal = Control.SIZE_FILL
	TerminalTheme.apply_to_panel(panel)
	parent.add_child(panel)

	var margin = MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 8)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_right", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	panel.add_child(margin)

	# TabContainer for switching between Map and Paint tools
	var tab_container = TabContainer.new()
	tab_container.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_child(tab_container)

	# Tab 1: Map Controls
	_build_map_tab(tab_container)

	# Tab 2: Paint Tools
	_build_paint_tab(tab_container)

func _build_map_tab(tab_container: TabContainer) -> void:
	# Scrollable for all map controls
	var scroll = ScrollContainer.new()
	scroll.name = "Map"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	tab_container.add_child(scroll)

	var vbox = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(vbox)

	# === MAP SIZE SECTION ===
	_add_section_header(vbox, "Map Size")

	_columns_spin = SpinBox.new()
	_columns_spin.min_value = 1
	_columns_spin.max_value = 999999  # No artificial limits!
	_columns_spin.value = 32
	_columns_spin.prefix = "W: "
	_columns_spin.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	vbox.add_child(_columns_spin)

	_rows_spin = SpinBox.new()
	_rows_spin.min_value = 1
	_rows_spin.max_value = 999999  # No artificial limits!
	_rows_spin.value = 32
	_rows_spin.prefix = "H: "
	_rows_spin.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	vbox.add_child(_rows_spin)

	var new_button = Button.new()
	new_button.text = "New Map"
	new_button.pressed.connect(_on_new_map_pressed)
	TerminalTheme.apply_to_button(new_button)
	vbox.add_child(new_button)

	_add_separator(vbox)

	# === CSV TERRAIN IMPORT SECTION ===
	_add_section_header(vbox, "CSV Terrain Import")

	# File path input
	var path_row = HBoxContainer.new()
	path_row.add_theme_constant_override("separation", 4)
	vbox.add_child(path_row)

	_csv_path_edit = LineEdit.new()
	_csv_path_edit.placeholder_text = "user://terrain.csv"
	_csv_path_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_csv_path_edit.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	path_row.add_child(_csv_path_edit)

	var browse_button = Button.new()
	browse_button.text = "..."
	browse_button.custom_minimum_size.x = 40
	browse_button.pressed.connect(_on_browse_csv_pressed)
	TerminalTheme.apply_to_button(browse_button)
	path_row.add_child(browse_button)

	# Downsample control
	var downsample_row = HBoxContainer.new()
	downsample_row.add_theme_constant_override("separation", 8)
	vbox.add_child(downsample_row)

	var downsample_label = Label.new()
	downsample_label.text = "Downsample:"
	TerminalTheme.apply_to_label(downsample_label)
	downsample_row.add_child(downsample_label)

	_csv_downsample_spin = SpinBox.new()
	_csv_downsample_spin.min_value = 1
	_csv_downsample_spin.max_value = 10
	_csv_downsample_spin.value = 1
	_csv_downsample_spin.tooltip_text = "1=no downsampling, 2=every other row/col, etc."
	_csv_downsample_spin.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	downsample_row.add_child(_csv_downsample_spin)

	# Import button
	var import_button = Button.new()
	import_button.text = "Import CSV Terrain"
	import_button.pressed.connect(_on_import_csv_pressed)
	TerminalTheme.apply_to_button(import_button)
	vbox.add_child(import_button)

	_add_separator(vbox)

	# === LAYER SELECTION SECTION ===
	_add_section_header(vbox, "Layer")

	_layer_selector = LayerSelector.new()
	vbox.add_child(_layer_selector)

	_add_separator(vbox)

	# === ELEVATION GENERATION SECTION ===
	_add_section_header(vbox, "Elevation")

	_elevation_controls = ElevationControls.new()
	vbox.add_child(_elevation_controls)

	_add_separator(vbox)

	# === PLANET GENERATION SECTION ===
	_add_section_header(vbox, "Planet Generation")

	var planet_button = Button.new()
	planet_button.text = "Generate Planet Map [G]"
	planet_button.tooltip_text = "Creates realistic planet terrain using PlanetMapGenerator\nShortcut: G key"
	planet_button.pressed.connect(_on_generate_planet_pressed)
	TerminalTheme.apply_to_button(planet_button)
	vbox.add_child(planet_button)

	_add_separator(vbox)

	# === SURFACE FEATURES SECTION ===
	_add_section_header(vbox, "Surface Features")

	var tree_button = Button.new()
	tree_button.text = "Add Trees (8% density)"
	tree_button.tooltip_text = "Places trees on suitable terrain"
	tree_button.pressed.connect(_on_add_trees_pressed)
	TerminalTheme.apply_to_button(tree_button)
	vbox.add_child(tree_button)

	_place_tree_button = Button.new()
	_place_tree_button.text = "Place Single Tree (OFF)"
	_place_tree_button.tooltip_text = "Toggle: Click tiles to manually place trees for testing"
	_place_tree_button.toggle_mode = true
	_place_tree_button.toggled.connect(_on_place_tree_toggled)
	TerminalTheme.apply_to_button(_place_tree_button)
	vbox.add_child(_place_tree_button)

	_add_separator(vbox)

	# === FILE OPERATIONS SECTION ===
	_add_section_header(vbox, "File Operations")

	var save_button = Button.new()
	save_button.text = "Save Map"
	save_button.pressed.connect(_on_save_map_pressed)
	TerminalTheme.apply_to_button(save_button)
	vbox.add_child(save_button)

	var load_button = Button.new()
	load_button.text = "Load Map"
	load_button.pressed.connect(_on_load_map_pressed)
	TerminalTheme.apply_to_button(load_button)
	vbox.add_child(load_button)

func _build_paint_tab(tab_container: TabContainer) -> void:
	# Scrollable container for paint tools and tiles
	var scroll = ScrollContainer.new()
	scroll.name = "Paint"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	tab_container.add_child(scroll)

	var vbox = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(vbox)

	# === PAINTING TOOLS SECTION ===
	_add_section_header(vbox, "Tools")

	_tool_selector = ToolSelector.new()
	vbox.add_child(_tool_selector)

	_add_separator(vbox)

	# === TILE PALETTE SECTION ===
	_add_section_header(vbox, "Tiles")

	_tile_palette = TilePalette.new()
	_tile_palette.custom_minimum_size.y = 400  # More space for tiles
	_tile_palette.columns = 3  # 3 columns to fit in 320px panel
	vbox.add_child(_tile_palette)

func _add_section_header(parent: VBoxContainer, text: String) -> void:
	var label = Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", 12)
	TerminalTheme.apply_to_label(label)
	parent.add_child(label)

func _add_separator(parent: VBoxContainer) -> void:
	var sep = HSeparator.new()
	sep.add_theme_constant_override("separation", 8)
	parent.add_child(sep)

func _build_viewport(parent: HBoxContainer) -> void:
	# Viewport takes remaining space (expand to fill)
	_map_viewport = MapViewport.new()
	_map_viewport.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_map_viewport.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_map_viewport.tile_clicked.connect(_on_tile_clicked)
	_map_viewport.tile_dragged.connect(_on_tile_dragged)
	parent.add_child(_map_viewport)

func _build_right_panel(parent: HBoxContainer) -> void:
	# Right panel - 320px wide with ecosystem toggle + stats
	var panel = Panel.new()
	panel.custom_minimum_size.x = 320
	panel.size_flags_horizontal = Control.SIZE_FILL
	TerminalTheme.apply_to_panel(panel)
	parent.add_child(panel)

	var margin = MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 8)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_right", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	panel.add_child(margin)

	# Scrollable VBox for controls
	var scroll = ScrollContainer.new()
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	margin.add_child(scroll)

	var vbox = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(vbox)

	# === ECOSYSTEM SIMULATION SECTION ===
	_add_section_header(vbox, "Ecosystem Simulation")

	var info_label = Label.new()
	info_label.text = "Control time to watch trees grow, spread, and interact with their environment."
	info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info_label.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	vbox.add_child(info_label)

	# Ecosystem toggle - OFF by default for terrain viewing
	var ecosystem_toggle = CheckButton.new()
	ecosystem_toggle.text = "Enable Ecosystem"
	ecosystem_toggle.button_pressed = false  # OFF by default
	ecosystem_toggle.toggled.connect(_on_ecosystem_toggled)
	ecosystem_toggle.tooltip_text = "Toggle tree/plant simulation\n(Turn OFF for pure terrain viewing)"
	TerminalTheme.apply_to_button(ecosystem_toggle)
	vbox.add_child(ecosystem_toggle)

	_add_separator(vbox)

	# === TIME CONTROLS ===
	_add_section_header(vbox, "Time Controls")

	_time_control_panel = TimeControlPanel.new()
	_time_control_panel.custom_minimum_size.y = 120
	vbox.add_child(_time_control_panel)

	# Connect time control to time manager
	if sandbox_core and sandbox_core.time_manager:
		_log_info("Setting TimeManager on TimeControlPanel (current_time_scale=%s)" % sandbox_core.time_manager.current_time_scale)
		_time_control_panel.set_time_manager(sandbox_core.time_manager)

		# CRITICAL: Connect time_scale_changed signal to TimeManager.set_time_scale
		# This makes the buttons actually change the time speed!
		if not _time_control_panel.time_scale_changed.is_connected(sandbox_core.time_manager.set_time_scale):
			_time_control_panel.time_scale_changed.connect(sandbox_core.time_manager.set_time_scale)
			_log_info("Connected TimeControlPanel.time_scale_changed -> TimeManager.set_time_scale")
	else:
		_log_warn("Cannot set TimeManager - sandbox_core or time_manager is null")

	_add_separator(vbox)

	# === VISUAL THEME SECTION ===
	_add_section_header(vbox, "Visual Theme")

	_theme_selector = ThemeSelectorPanel.new()
	_theme_selector.custom_minimum_size.y = 80
	_theme_selector.theme_selected.connect(_on_theme_selected)
	vbox.add_child(_theme_selector)

	_add_separator(vbox)

	# === TILE DATA (Live Inspector) ===
	_add_section_header(vbox, "Selected Tile Data")

	_tile_data_label = RichTextLabel.new()
	_tile_data_label.bbcode_enabled = true
	_tile_data_label.fit_content = true
	_tile_data_label.scroll_active = false
	_tile_data_label.custom_minimum_size.y = 150
	_tile_data_label.add_theme_color_override("default_color", TerminalTheme.terminal_green)
	_tile_data_label.add_theme_font_override("normal_font", TerminalTheme.get_terminal_font())
	_tile_data_label.add_theme_font_size_override("normal_font_size", 10)
	_tile_data_label.text = "[i]Click a tile to inspect[/i]"
	vbox.add_child(_tile_data_label)

	# Create timer for live tile data updates
	_tile_data_timer = Timer.new()
	_tile_data_timer.wait_time = 0.5  # Update twice per second
	_tile_data_timer.timeout.connect(_update_selected_tile_data)
	_tile_data_timer.autostart = true
	add_child(_tile_data_timer)

	_add_separator(vbox)

	# === ECOSYSTEM STATS ===
	_add_section_header(vbox, "Ecosystem Stats")

	_ecosystem_stats_label = RichTextLabel.new()
	_ecosystem_stats_label.bbcode_enabled = true
	_ecosystem_stats_label.fit_content = true
	_ecosystem_stats_label.scroll_active = false
	_ecosystem_stats_label.custom_minimum_size.y = 120
	_ecosystem_stats_label.add_theme_color_override("default_color", TerminalTheme.terminal_green)
	_ecosystem_stats_label.add_theme_font_override("normal_font", TerminalTheme.get_terminal_font())
	_ecosystem_stats_label.add_theme_font_size_override("normal_font_size", 11)
	vbox.add_child(_ecosystem_stats_label)

	# Update stats initially
	_update_ecosystem_stats()

func connect_signals() -> void:
	if sandbox_core:
		sandbox_core.map_changed.connect(_on_map_changed)
		# Listen for picker tool updates
		sandbox_core.tile_selection_changed.connect(_on_core_tile_selection_changed)
		sandbox_core.current_layer_changed.connect(_on_core_layer_changed)

	# Connect paint tool components
	if _tool_selector:
		_tool_selector.tool_changed.connect(_on_tool_changed)
	if _layer_selector:
		_layer_selector.layer_changed.connect(_on_layer_changed)
	if _tile_palette:
		_tile_palette.selection_changed.connect(_on_tile_selection_changed)
	if _elevation_controls:
		_elevation_controls.generate_requested.connect(_on_generate_elevation)

func on_page_activated() -> void:
	# Initialize with empty map if needed
	if sandbox_core.current_map_tiles.is_empty():
		sandbox_core.initialize_empty_map()

	# Render the current map
	_refresh_viewport()

	# Check for auto-generate flag
	_check_auto_generate()

	# Setup village UI components (deferred so PlanetMapSystem is ready)
	call_deferred("_setup_village_ui")

func _setup_village_ui() -> void:
	if _village_list:
		return
	var pms = _map_viewport._planet_map_system if _map_viewport else null
	if not pms or not pms.tile_manager:
		return

	# Territory overlay (world-space, child of tile_manager)
	_territory_overlay = VillageTerritoryOverlay.new()
	_territory_overlay.name = "TerritoryOverlay"
	_territory_overlay.planet_map_system = pms
	_territory_overlay.map_viewport = _map_viewport._viewport if _map_viewport else null
	pms.tile_manager.add_child(_territory_overlay)
	_territory_overlay.visible = false

	# Village list panel (screen-space, child of this page)
	_village_list = VillageListPanel.new()
	_village_list.name = "VillageListPanel"
	add_child(_village_list)
	_village_list.village_selected.connect(_on_village_list_selected)

	# Refresh timer
	_village_list_refresh_timer = Timer.new()
	_village_list_refresh_timer.wait_time = 0.5
	_village_list_refresh_timer.timeout.connect(_refresh_village_list)
	_village_list_refresh_timer.autostart = false
	add_child(_village_list_refresh_timer)

func _toggle_village_list() -> void:
	if not _village_list:
		return
	_village_list.visible = not _village_list.visible
	if _village_list.visible:
		_refresh_village_list()
		_village_list_refresh_timer.start()
	else:
		_village_list_refresh_timer.stop()

func _toggle_territory_overlay() -> void:
	if _territory_overlay:
		_territory_overlay.visible = not _territory_overlay.visible

func _on_village_list_selected(village_id: String) -> void:
	var pms = _map_viewport._planet_map_system if _map_viewport else null
	if not pms or not pms.village_manager:
		return
	var village = pms.village_manager.get_village(village_id)
	if village and pms.camera_controller:
		var world_pos = PlanetMapCoordinates.grid_to_world(village.camp_position)
		pms.camera_controller.move_to_position(world_pos)

func _refresh_village_list() -> void:
	if not _village_list or not _village_list.visible:
		return
	var pms = _map_viewport._planet_map_system if _map_viewport else null
	if not pms or not pms.village_manager:
		return
	var planet_id: String = pms.planet_id
	var villages: Array = pms.village_manager.get_villages_on_planet(planet_id)
	var current_year := int(pms.time_manager.game_days_elapsed / 365.0) if pms.time_manager else 0
	_village_list.refresh(villages, current_year)

func _unhandled_input(event: InputEvent) -> void:
	"""Handle keyboard shortcuts."""
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_G:
			_log_info("G key pressed - generating planet")
			_on_generate_planet_pressed()
			get_viewport().set_input_as_handled()
		elif event.keycode == KEY_F and event.ctrl_pressed and not event.shift_pressed and not event.alt_pressed:
			_log_info("Ctrl+F pressed - opening tile search")
			_open_search_dialog()
			get_viewport().set_input_as_handled()
		elif event.keycode == KEY_F4:
			_toggle_village_list()
			get_viewport().set_input_as_handled()
		elif event.keycode == KEY_F5:
			_toggle_territory_overlay()
			get_viewport().set_input_as_handled()

func _check_auto_generate() -> void:
	"""Check for --generate, --png, --csv, or --ecosystem flags and auto-load if present."""
	var args = OS.get_cmdline_user_args()
	var auto_enable_ecosystem = false

	# Check for --ecosystem flag
	for arg in args:
		if arg == "--ecosystem" or arg == "-ecosystem":
			auto_enable_ecosystem = true

	# Check for map generation flags
	for arg in args:
		if arg == "--generate" or arg == "-generate":
			await get_tree().process_frame
			_on_generate_planet_pressed()
			if auto_enable_ecosystem:
				_auto_enable_ecosystem()
			break
		elif arg == "--png" or arg == "-png":
			await get_tree().process_frame
			await _auto_load_png()
			if auto_enable_ecosystem:
				_auto_enable_ecosystem()
			break
		elif arg == "--csv" or arg == "-csv" or arg == "--stlouis" or arg == "-stlouis":
			await get_tree().process_frame
			await _auto_load_csv()
			if auto_enable_ecosystem:
				_auto_enable_ecosystem()
			break

func _auto_enable_ecosystem() -> void:
	"""Auto-enable ecosystem from command-line flag."""
	if not _map_viewport:
		_log_warn("Cannot auto-enable ecosystem: no viewport")
		return

	_log_info("Auto-enabling ecosystem from --ecosystem flag")
	_map_viewport.ecosystem_enabled = true
	# Refresh viewport to apply ecosystem state
	_refresh_viewport()

func _get_downsample_from_args() -> int:
	"""Parse --downsample=N from command-line args."""
	var downsample = 4  # Default
	var args = OS.get_cmdline_user_args()
	for arg in args:
		if arg.begins_with("--downsample=") or arg.begins_with("-downsample="):
			var parts = arg.split("=")
			if parts.size() == 2:
				downsample = int(parts[1])
				_log_info("Using downsample=%d from command-line flag" % downsample)
	return downsample


func _auto_load_png() -> void:
	"""Load terrain from PNG heightmap (async)."""
	# Prefer 8-bit (3.4 MB) over 16-bit (18 MB) - 256 levels is plenty for terrain
	var png_path = "res://assets/terrain/reference/full_map_8bit.png"
	if not FileAccess.file_exists(png_path):
		png_path = "res://assets/terrain/reference/full_map.png"  # Fallback to 16-bit

	if not FileAccess.file_exists(png_path):
		_log_error("PNG not found: %s" % png_path)
		return

	var downsample = _get_downsample_from_args()
	var loader = PNGTerrainLoader.new()
	var result = loader.load_png(png_path, downsample)

	if result.success:
		await _apply_elevation_map(result.elevation_map, result.grid_size)
	else:
		_log_error("PNG load failed: %s" % result.error)


func _auto_load_csv() -> void:
	"""Load terrain from CSV file (async)."""
	var csv_path = "user://USGS_stlouis.csv"

	if not FileAccess.file_exists(csv_path):
		_log_error("CSV not found: %s" % csv_path)
		_log_error("Place USGS_stlouis.csv in: %s" % OS.get_user_data_dir())
		return

	var downsample = _get_downsample_from_args()
	var loader = StLouisTerrainLoader.new()
	var result = loader.load_csv(csv_path, downsample)

	if result.success:
		await _apply_elevation_map(result.elevation_map, result.grid_size)
	else:
		_log_error("CSV load failed: %s" % result.error)

func _apply_elevation_map(elevation_map: Dictionary, grid_size: Vector2i) -> void:
	"""Apply elevation map to sandbox core (async to prevent freeze)."""
	if not sandbox_core:
		_log_error("SandboxCore not initialized")
		return

	# Set map size and update UI
	sandbox_core.set_map_size(grid_size.x, grid_size.y)
	_columns_spin.value = grid_size.x
	_rows_spin.value = grid_size.y

	# Clear existing map
	sandbox_core.current_map_tiles.clear()
	var tile_type = PlanetMapTileConfig.TileType.GRASS_0

	# Convert to array for indexed access
	var positions = elevation_map.keys()
	var total_tiles = positions.size()
	var batch_size = 10000  # Tiles per frame (prevents freeze)
	var created_count = 0

	_log_info("Loading %dx%d terrain..." % [grid_size.x, grid_size.y])

	# Process in batches (async)
	for batch_start in range(0, total_tiles, batch_size):
		var batch_end = mini(batch_start + batch_size, total_tiles)

		# Create tiles for this batch
		for i in range(batch_start, batch_end):
			var pos = positions[i]
			var tile = MapTile.new(pos)
			tile.type = tile_type
			tile.elevation = elevation_map[pos]
			sandbox_core.current_map_tiles[pos] = tile
			created_count += 1

		# Yield to prevent freeze + update progress
		if batch_end < total_tiles:
			var progress = int((float(created_count) / total_tiles) * 100)
			_log_info("  Loading... %d%% (%d/%d tiles)" % [progress, created_count, total_tiles])
			await get_tree().process_frame

	# Notify map changed (single signal at end)
	sandbox_core.notify_map_changed()

	_log_info("Loaded %d tiles" % created_count)

# ===== SIGNAL HANDLERS =====

func _on_new_map_pressed() -> void:
	var cols = int(_columns_spin.value)
	var rows = int(_rows_spin.value)
	sandbox_core.set_map_size(cols, rows)
	sandbox_core.initialize_empty_map()
	_log_info("Created new %dx%d map" % [cols, rows])
	# Map will refresh automatically via map_changed signal

func _on_map_changed() -> void:
	_refresh_viewport()

func _on_tile_clicked(tile_pos: Vector2i, _button_index: int) -> void:
	# Store selected tile for live inspection
	_selected_tile_pos = tile_pos
	_update_selected_tile_data()

	# Handle tree placement mode
	if _tree_placement_mode:
		_place_tree_at_position(tile_pos)

func _on_tile_clicked_old(tile_pos: Vector2i, _button_index: int) -> void:
	if not sandbox_core:
		return

	var selected_tiles = sandbox_core.selected_tile_types

	# Check for modifier keys (override tool mode)
	var input = Input
	if input.is_key_pressed(KEY_CTRL):
		# Ctrl+Click = Picker mode
		_pick_tile(tile_pos)
		return
	elif input.is_key_pressed(KEY_SHIFT):
		# Shift+Click = Fill mode
		_flood_fill(tile_pos, selected_tiles)
		return

	# Handle painting based on current tool mode
	var tool = sandbox_core.current_tool_mode

	if tool == SandboxConfig.ToolMode.PLACE:
		_paint_tile(tile_pos, selected_tiles)
	elif tool == SandboxConfig.ToolMode.ERASE:
		_erase_tile(tile_pos)
	elif tool == SandboxConfig.ToolMode.PICKER:
		_pick_tile(tile_pos)
	elif tool == SandboxConfig.ToolMode.FILL:
		_flood_fill(tile_pos, selected_tiles)
	elif tool == SandboxConfig.ToolMode.BRUSH:
		# Brush also works on click
		_paint_tile(tile_pos, selected_tiles)

func _on_tile_dragged(tile_pos: Vector2i) -> void:
	"""Handle continuous painting while dragging (brush mode)."""
	if not sandbox_core:
		return

	var selected_tiles = sandbox_core.selected_tile_types

	# Brush mode: paint while dragging with Alt held
	if sandbox_core.current_tool_mode == SandboxConfig.ToolMode.BRUSH:
		_paint_tile(tile_pos, selected_tiles)
	# Also allow erasing while dragging
	elif sandbox_core.current_tool_mode == SandboxConfig.ToolMode.ERASE:
		_erase_tile(tile_pos)

func _on_tool_changed(tool_mode: SandboxConfig.ToolMode) -> void:
	if sandbox_core:
		sandbox_core.set_tool_mode(tool_mode)
		_log_info("Tool changed to: %s" % [tool_mode])

func _on_layer_changed(layer: int) -> void:
	if sandbox_core:
		sandbox_core.set_current_layer(layer)
		_log_info("Layer changed to: %d" % [layer])

func _on_tile_selection_changed(selected_types: Array[int]) -> void:
	if sandbox_core:
		sandbox_core.set_selected_tiles(selected_types)
		_log_info("Selected %d tile types" % [selected_types.size()])

func _on_generate_elevation(pattern: ElevationGenerator.Pattern, max_height: int) -> void:
	if not sandbox_core:
		return

	_log_info("Generating elevation: pattern=%s, max_height=%d" % [pattern, max_height])

	var generator = ElevationGenerator.new()
	var columns = sandbox_core.map_columns
	var rows = sandbox_core.map_rows

	var elevation_map = generator.generate_elevation_map(columns, rows, pattern, max_height)

	# Apply elevation to existing tiles
	for pos in elevation_map:
		if sandbox_core.current_map_tiles.has(pos):
			var tile: MapTile = sandbox_core.current_map_tiles[pos]
			tile.elevation = elevation_map[pos]

	sandbox_core.notify_map_changed()
	_log_info("Applied elevation to %d tiles" % [elevation_map.size()])

func _on_core_tile_selection_changed(selected_types: Array[int]) -> void:
	"""Update UI when tile selection changes externally (e.g., picker tool)."""
	if _tile_palette:
		_tile_palette.set_selected_tiles(selected_types)

func _on_core_layer_changed(layer: int) -> void:
	"""Update UI when layer changes externally (e.g., picker tool)."""
	if _layer_selector:
		_layer_selector.set_current_layer(layer)

func _on_save_map_pressed() -> void:
	if sandbox_core:
		var success = sandbox_core.save_map_to_file()
		if success:
			_log_info("Map saved successfully")
		else:
			_log_error("Failed to save map")

func _on_load_map_pressed() -> void:
	if sandbox_core:
		var success = sandbox_core.load_map_from_file()
		if success:
			_log_info("Map loaded successfully")
			_refresh_viewport()
		else:
			_log_error("Failed to load map")

func _on_browse_csv_pressed() -> void:
	"""Open file dialog to select CSV file."""
	if not _file_dialog:
		_file_dialog = FileDialog.new()
		_file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
		_file_dialog.access = FileDialog.ACCESS_FILESYSTEM
		_file_dialog.add_filter("*.csv", "CSV Files")
		_file_dialog.file_selected.connect(_on_csv_file_selected)
		add_child(_file_dialog)

	_file_dialog.popup_centered(Vector2(800, 600))

func _on_csv_file_selected(path: String) -> void:
	"""Handle CSV file selection from dialog."""
	_csv_path_edit.text = path
	_log_info("Selected CSV file: %s" % path)

func _on_import_csv_pressed() -> void:
	"""Import terrain data from CSV file."""
	if not sandbox_core:
		return

	var path = _csv_path_edit.text.strip_edges()
	if path.is_empty():
		_log_error("No CSV file path specified")
		return

	var downsample = int(_csv_downsample_spin.value)

	_log_info("Importing CSV terrain from: %s (downsample=%d)" % [path, downsample])

	# Load CSV data
	var loader = CSVTerrainLoader.new()
	var result = loader.load_csv(path, downsample)

	if not result["success"]:
		_log_error("CSV import failed: %s" % result["error"])
		return

	# Normalize elevation data to layers (0-7)
	var elevation_data = result["elevation_data"]
	var min_elev = result["min_elevation"]
	var max_elev = result["max_elevation"]
	var rows = result["rows"]
	var cols = result["columns"]

	_log_info("Loaded CSV: %dx%d, elevation range: %.2f to %.2f" % [cols, rows, min_elev, max_elev])

	# Update map size to match CSV dimensions
	sandbox_core.set_map_size(cols, rows)
	_columns_spin.value = cols
	_rows_spin.value = rows

	# Create or update map tiles
	sandbox_core.current_map_tiles.clear()

	for y in range(rows):
		for x in range(cols):
			var pos = Vector2i(x, y)
			var raw_elevation = elevation_data[y][x]

			# Normalize to 0-7 layers
			var normalized = 0
			if max_elev > min_elev:
				var t = (raw_elevation - min_elev) / (max_elev - min_elev)
				normalized = int(t * 7.0)

			var tile = MapTile.new(pos)
			tile.type = PlanetMapTileConfig.TileType.ROCK  # Use rock for terrain
			tile.elevation = normalized
			sandbox_core.current_map_tiles[pos] = tile

	sandbox_core.notify_map_changed()
	_log_info("CSV terrain applied to %d tiles" % sandbox_core.current_map_tiles.size())

func _on_generate_planet_pressed() -> void:
	"""Generate a realistic planet map using PlanetMapGenerator."""
	if not sandbox_core:
		return

	_log_info("Generating planet map...")

	# Create a test planet (Super Earth, temperate)
	var props = {
		"scale_range": Vector2(0.062, 0.074),
		"colors": [Color(0.3, 0.6, 0.7)]
	}
	var planet = Planet.new(null, 100.0, 0.02, PlanetEnums.PlanetType.SUPER_EARTH, props, true)
	planet.habitability_score = 0.8
	planet.surface_liquids = {"water": 0.6}
	planet.atmosphere_type = PlanetEnums.AtmosphereType.MODERATE
	planet.climate_type = PlanetEnums.ClimateType.TEMPERATE
	planet.geological_activity = PlanetEnums.GeologicalActivity.MODERATE

	# Create probe data
	var probe_data = {
		"habitability_score": 0.8,
		"atmosphere_type": "MODERATE",
		"surface_temperature": 288.0,
		"geological_activity": "MODERATE",
		"climate_type": "TEMPERATE",
		"surface_liquids": {"water": 0.6},
		"surface_composition": {"silicates": 0.5, "metals": 0.2}
	}

	# Generate map using PlanetMapGenerator
	var generator = PlanetMapGenerator.new()
	var seed_value = randi() % 100000
	var tiles_2d = generator.generate_map(planet, probe_data, seed_value)

	# Convert 2D array to dictionary
	sandbox_core.current_map_tiles.clear()
	var tile_count = 0

	# IMPORTANT: Generator creates tiles[x][y], so we must iterate x first, then y
	var tree_positions = []  # Track where trees are
	for x in range(tiles_2d.size()):
		var row = tiles_2d[x]
		for y in range(row.size()):
			var tile: MapTile = row[y]
			if tile:
				sandbox_core.current_map_tiles[tile.position] = tile
				tile_count += 1
				# Debug: Track trees
				if tile.surface_feature_type != null:
					tree_positions.append(tile.position)
					if tree_positions.size() <= 10:
						_log_info("Tree found at: %s (species=%d)" % [tile.position, tile.surface_feature_type])

	if tree_positions.size() > 0:
		_log_info("Total trees in generated map: %d" % tree_positions.size())
		_log_info("First tree: %s, Last tree: %s" % [tree_positions[0], tree_positions[tree_positions.size() - 1]])

	# Update map size
	if tiles_2d.size() > 0 and tiles_2d[0].size() > 0:
		var rows = tiles_2d.size()
		var cols = tiles_2d[0].size()
		sandbox_core.set_map_size(cols, rows)
		_columns_spin.value = cols
		_rows_spin.value = rows

	sandbox_core.notify_map_changed()
	_log_info("Generated planet map with %d tiles (seed=%d)" % [tile_count, seed_value])

func _on_add_trees_pressed() -> void:
	"""Add trees to suitable terrain using SurfaceFeaturePlacer."""
	if not sandbox_core:
		return

	if sandbox_core.current_map_tiles.is_empty():
		_log_error("No map to add trees to - create a map first")
		return

	_log_info("Placing trees...")

	# Convert dictionary to array for SurfaceFeaturePlacer
	var tiles_array: Array = []
	for pos in sandbox_core.current_map_tiles:
		tiles_array.append(sandbox_core.current_map_tiles[pos])

	# Place trees
	var placer = SurfaceFeaturePlacer.new()
	var density = 0.08  # 8% density
	var species_list = [
		PlanetMapTileConfig.TileType.SF_TREE_1,
		PlanetMapTileConfig.TileType.SF_TREE_2,
		PlanetMapTileConfig.TileType.SF_TREE_3
	]
	var seed_value = randi() % 100000

	var tree_placements = placer.place_trees(tiles_array, density, species_list, seed_value)

	# Apply tree placements
	var tree_count = 0
	for placement in tree_placements:
		var pos: Vector2i = placement["position"]
		var species: int = placement["species"]

		if sandbox_core.current_map_tiles.has(pos):
			var tile: MapTile = sandbox_core.current_map_tiles[pos]
			tile.surface_feature_type = species
			tree_count += 1

	sandbox_core.notify_map_changed()
	_log_info("Placed %d trees" % tree_count)

func _on_place_tree_toggled(pressed: bool) -> void:
	"""Toggle manual tree placement mode."""
	_tree_placement_mode = pressed
	if _place_tree_button:
		_place_tree_button.text = "Place Single Tree (ON)" if pressed else "Place Single Tree (OFF)"
	_log_info("Tree placement mode: %s" % ("ON" if pressed else "OFF"))

func _on_ecosystem_toggled(enabled: bool) -> void:
	"""Toggle ecosystem simulation on/off."""
	# Note: Ecosystem is always enabled in sandbox mode
	# The toggle UI exists but ecosystem_enabled property is not yet implemented
	_log_info("Ecosystem toggle: %s (note: ecosystem always runs in sandbox)" % ("ENABLED" if enabled else "DISABLED"))

func _place_tree_at_position(tile_pos: Vector2i) -> void:
	"""Place a single tree at the clicked position."""
	if not _map_viewport:
		_log_error("Cannot place tree: no viewport")
		return

	# Try to place tree using MapViewport
	var success = _map_viewport.manually_place_tree(tile_pos)
	if success:
		_log_info("Placed tree at %s" % tile_pos)
		# Update ecosystem stats immediately
		_update_ecosystem_stats()
		# Update tile data display to show the new tree
		_update_selected_tile_data()
	else:
		_log_warn("Failed to place tree at %s (check tile type and existing trees)" % position)

func _refresh_viewport() -> void:
	"""Update the viewport to show current map tiles."""
	if _map_viewport and sandbox_core:
		# Connect time manager to ecosystem (idempotent)
		if sandbox_core.time_manager:
			_map_viewport.connect_time_manager(sandbox_core.time_manager)

			# Connect simulation tick to update ecosystem stats
			if not sandbox_core.time_manager.simulation_tick.is_connected(_on_simulation_tick):
				sandbox_core.time_manager.simulation_tick.connect(_on_simulation_tick)
				_log_info("Connected TimeManager.simulation_tick -> _on_simulation_tick")

		_map_viewport.render_tiles(sandbox_core.current_map_tiles)
		_log_debug("Rendered %d tiles to viewport" % sandbox_core.current_map_tiles.size())

		# Update stats after rendering
		call_deferred("_update_ecosystem_stats")

# ===== PAINTING LOGIC =====

func _paint_tile(pos: Vector2i, tile_types: Array[int]) -> void:
	"""Paint a tile at the given position with the selected tile type."""
	if not sandbox_core or tile_types.is_empty():
		return

	# Use first selected tile type
	var tile_type = tile_types[0]
	var current_layer = sandbox_core.current_layer

	# Get or create tile
	var tile: MapTile
	if sandbox_core.current_map_tiles.has(pos):
		tile = sandbox_core.current_map_tiles[pos]
	else:
		tile = MapTile.new(pos)
		sandbox_core.current_map_tiles[pos] = tile

	# Update tile
	tile.type = tile_type
	tile.elevation = current_layer

	sandbox_core.notify_map_changed()

func _erase_tile(pos: Vector2i) -> void:
	"""Erase a tile at the given position."""
	if not sandbox_core:
		return

	if sandbox_core.current_map_tiles.has(pos):
		sandbox_core.current_map_tiles.erase(pos)
		sandbox_core.notify_map_changed()

func _pick_tile(pos: Vector2i) -> void:
	"""Pick the tile type at the given position."""
	if not sandbox_core:
		return

	if sandbox_core.current_map_tiles.has(pos):
		var tile: MapTile = sandbox_core.current_map_tiles[pos]
		# Update SandboxCore state - Paint Tools page will react to signals
		sandbox_core.set_selected_tiles([tile.type])
		sandbox_core.set_current_layer(tile.elevation)
		_log_info("Picked tile: type=%d, layer=%d" % [tile.type, tile.elevation])

func _flood_fill(start_pos: Vector2i, tile_types: Array[int]) -> void:
	"""Flood fill from the starting position with the selected tile type."""
	if not sandbox_core or tile_types.is_empty():
		return

	var new_type = tile_types[0]
	var current_layer = sandbox_core.current_layer

	# Get target type (what we're replacing)
	var target_type = -1
	if sandbox_core.current_map_tiles.has(start_pos):
		target_type = sandbox_core.current_map_tiles[start_pos].type
	else:
		# Filling empty space
		target_type = -1

	# Don't fill if already the same type
	if target_type == new_type:
		return

	var filled_count = 0
	var to_fill: Array[Vector2i] = [start_pos]
	var visited: Dictionary = {}

	while not to_fill.is_empty():
		var pos = to_fill.pop_back()

		if visited.has(pos):
			continue

		visited[pos] = true

		# Check if this tile matches the target type
		var current_type = -1
		if sandbox_core.current_map_tiles.has(pos):
			current_type = sandbox_core.current_map_tiles[pos].type

		if current_type != target_type:
			continue

		# Check bounds
		if pos.x < 0 or pos.x >= sandbox_core.map_columns:
			continue
		if pos.y < 0 or pos.y >= sandbox_core.map_rows:
			continue

		# Paint this tile
		var tile: MapTile
		if sandbox_core.current_map_tiles.has(pos):
			tile = sandbox_core.current_map_tiles[pos]
		else:
			tile = MapTile.new(pos)
			sandbox_core.current_map_tiles[pos] = tile

		tile.type = new_type
		tile.elevation = current_layer
		filled_count += 1

		# Add neighbors
		to_fill.append(pos + Vector2i(1, 0))
		to_fill.append(pos + Vector2i(-1, 0))
		to_fill.append(pos + Vector2i(0, 1))
		to_fill.append(pos + Vector2i(0, -1))

	sandbox_core.notify_map_changed()
	_log_info("Flood filled %d tiles" % [filled_count])

func _on_simulation_tick(_tick_number: int, _game_days: float) -> void:
	"""Called every simulation tick to update ecosystem stats."""
	_update_ecosystem_stats()

func _on_theme_selected(theme_name: String) -> void:
	"""Handle theme selection - map will update via VariantManager signal."""
	_log_info("Visual theme changed to: %s" % theme_name)

func _update_selected_tile_data() -> void:
	"""Update the live tile data display for the selected tile."""
	if not _tile_data_label:
		return

	if _selected_tile_pos == Vector2i(-1, -1):
		_tile_data_label.text = "[i]Click a tile to inspect[/i]"
		return

	# Get tile from map
	var tile: MapTile = null
	if sandbox_core and sandbox_core.current_map_tiles.has(_selected_tile_pos):
		tile = sandbox_core.current_map_tiles[_selected_tile_pos]

	if not tile:
		_tile_data_label.text = "[b]Position:[/b] %s\n[i]No tile data[/i]" % _selected_tile_pos
		return

	# Get tree data from ecosystem
	var tree: TreeInstance = null
	if _map_viewport and _map_viewport._planet_map_system:
		tree = _map_viewport._planet_map_system.get_tree_at(_selected_tile_pos)

	# Format tile data
	var data_text = ""
	data_text += "[b]Position:[/b] %d, %d\n" % [_selected_tile_pos.x, _selected_tile_pos.y]
	data_text += "[b]Elevation:[/b] %d\n" % tile.elevation
	data_text += "[b]Terrain Type:[/b] %d\n" % tile.type

	# Surface feature data
	if tile.surface_feature_type != null:
		data_text += "[b]Surface Feature:[/b] %d\n" % tile.surface_feature_type

		# Show which tree type this is
		var feat_id = tile.surface_feature_type
		if feat_id >= 93 and feat_id <= 98:
			var names = ["VG_1", "VG_2", "VG_3", "VG_4", "VG_5", "VG_6"]
			data_text += "[b]Tree Asset:[/b] %s\n" % names[feat_id - 93]
		elif feat_id >= 73 and feat_id <= 78:
			var names = ["DORM_1", "DORM_2", "DORM_3", "DORM_4", "DORM_5", "DORM_6"]
			data_text += "[b]Tree Asset:[/b] %s\n" % names[feat_id - 73]
	else:
		data_text += "[color=gray]No surface feature[/color]\n"

	# Tree lifecycle data
	if tree:
		data_text += "\n[b]== TREE DATA ==[/b]\n"
		var stage_names = ["SEEDLING", "YOUNG_SAPLING", "SAPLING", "YOUNG_MATURE", "MATURE", "VERY_MATURE", "DORMANT"]
		data_text += "[b]Stage:[/b] %s\n" % stage_names[tree.growth_stage]
		data_text += "[b]Age:[/b] %d ticks (%.1f days)\n" % [tree.age_in_ticks, tree.age_in_ticks / 4.0]
		data_text += "[b]Health:[/b] %.1f%%\n" % (tree.health * 100.0)
		data_text += "[b]Seed Prod:[/b] %.2f\n" % tree.seed_production
		data_text += "[b]Alive:[/b] %s" % ("Yes" if tree.is_alive() else "No")

	_tile_data_label.text = data_text

func _update_ecosystem_stats() -> void:
	"""Update the ecosystem stats display with current tree counts."""
	if not _ecosystem_stats_label:
		return

	# Get ecosystem manager from map viewport
	var ecosystem = null
	if _map_viewport and _map_viewport._planet_map_system:
		ecosystem = _map_viewport._planet_map_system.ecosystem_manager

	if not ecosystem:
		_ecosystem_stats_label.text = "[i]No ecosystem active[/i]"
		return

	# Get tree counts by stage from ecosystem
	var planet_id = "sandbox_planet"
	var trees = ecosystem.get_trees_for_planet(planet_id)

	var total_trees = trees.size()
	var by_stage = {
		TreeInstance.GrowthStage.SEEDLING: 0,
		TreeInstance.GrowthStage.YOUNG_SAPLING: 0,
		TreeInstance.GrowthStage.SAPLING: 0,
		TreeInstance.GrowthStage.YOUNG_MATURE: 0,
		TreeInstance.GrowthStage.MATURE: 0,
		TreeInstance.GrowthStage.VERY_MATURE: 0,
		TreeInstance.GrowthStage.DORMANT: 0
	}

	for tree in trees:
		if tree.is_alive():
			by_stage[tree.growth_stage] += 1

	# Format stats - compact display
	var stats_text = ""
	stats_text += "[b]Total Trees:[/b] %d\n\n" % total_trees
	stats_text += "[b]Growth Stages:[/b]\n"
	stats_text += "  Seedling: %d\n" % by_stage[TreeInstance.GrowthStage.SEEDLING]
	stats_text += "  Y.Sapling: %d\n" % by_stage[TreeInstance.GrowthStage.YOUNG_SAPLING]
	stats_text += "  Sapling: %d\n" % by_stage[TreeInstance.GrowthStage.SAPLING]
	stats_text += "  Y.Mature: %d\n" % by_stage[TreeInstance.GrowthStage.YOUNG_MATURE]
	stats_text += "  Mature: %d\n" % by_stage[TreeInstance.GrowthStage.MATURE]
	stats_text += "  V.Mature: %d\n" % by_stage[TreeInstance.GrowthStage.VERY_MATURE]
	stats_text += "  Dormant: %d\n" % by_stage[TreeInstance.GrowthStage.DORMANT]

	_ecosystem_stats_label.text = stats_text

# ===== TILE SEARCH (Ctrl+F) =====

func _setup_search_dialog() -> void:
	"""Create tile search dialog for Ctrl+F navigation."""
	_search_dialog = TileSearchDialog.new()
	add_child(_search_dialog)
	_search_dialog.tile_search_requested.connect(_on_tile_search_requested)
	# Set initial map size
	if sandbox_core:
		_search_dialog.set_map_size(Vector2i(sandbox_core.map_columns, sandbox_core.map_rows))
	_log_info("Tile search dialog created")

func _open_search_dialog() -> void:
	"""Open the tile search dialog."""
	if not _search_dialog:
		_setup_search_dialog()

	# Update map size before showing
	if sandbox_core:
		_search_dialog.set_map_size(Vector2i(sandbox_core.map_columns, sandbox_core.map_rows))

	_log_info("Opening tile search dialog")
	_search_dialog.show_dialog()

func _on_tile_search_requested(tile_pos: Vector2i) -> void:
	"""Handle tile search request - pan camera to tile."""
	_log_info("Search requested for tile %s" % tile_pos)

	if not _map_viewport or not _map_viewport._planet_map_system:
		_log_warn("Cannot navigate: no map viewport or planet map system")
		return

	var pms = _map_viewport._planet_map_system
	if not pms.camera_controller or not pms.selection_manager or not pms.tile_manager:
		_log_warn("Cannot navigate: missing camera, selection, or tile manager")
		return

	# Get the tile object
	var tile = pms.selection_manager.get_tile_at(tile_pos)
	if not tile:
		_log_warn("No tile found at %s" % tile_pos)
		return

	# calculate_tile_visual_center returns position in tile_manager's LOCAL space
	var local_pos = pms.selection_manager.calculate_tile_visual_center(tile)

	# Convert to GLOBAL coordinates for the camera
	var target_pos = pms.tile_manager.to_global(local_pos)

	_log_info("Moving camera to tile %s, local=%s, global=%s" % [tile_pos, local_pos, target_pos])

	# Move camera to the calculated position (Vector2.ZERO = don't change zoom)
	pms.camera_controller.move_to_position(target_pos, 0.6, Vector2.ZERO)

	# Select the tile after camera arrives
	await get_tree().create_timer(0.65).timeout
	pms.selection_manager.apply_tile_selection(tile)

	# Update our selected tile position for tile data display
	_selected_tile_pos = tile_pos
	_update_selected_tile_data()
