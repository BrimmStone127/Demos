class_name BasePage
extends Control

# Abstract base class for sandbox pages
# Each page should extend this and implement the virtual methods

const LOG_TAG := "SANDBOX_PAGE"

# Reference to shared sandbox state
var sandbox_core: SandboxCore

signal page_ready()

func _init(p_core: SandboxCore = null):
	sandbox_core = p_core

func _ready():
	if not sandbox_core:
		GameLog.warn(LOG_TAG, "Page created without SandboxCore reference")
	setup_ui()
	connect_signals()
	page_ready.emit()

# ===== VIRTUAL METHODS (override in subclasses) =====

func setup_ui() -> void:
	"""Override to create UI elements."""
	pass

func connect_signals() -> void:
	"""Override to connect signals to sandbox_core and UI elements."""
	pass

func on_page_activated() -> void:
	"""Called when this page becomes active (tab switched to)."""
	pass

func on_page_deactivated() -> void:
	"""Called when this page becomes inactive (tab switched away)."""
	pass

func get_page_name() -> String:
	"""Override to return the display name for this page."""
	return "Unnamed Page"

func get_page_icon() -> Texture2D:
	"""Override to return an icon for this page (optional)."""
	return null

# ===== HELPER METHODS =====

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, message % values if values.size() > 0 else message)

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, message % values if values.size() > 0 else message)

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, message % values if values.size() > 0 else message)

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, message % values if values.size() > 0 else message)
