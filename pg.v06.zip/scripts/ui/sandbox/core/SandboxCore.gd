class_name SandboxCore
extends RefCounted

# Shared state and services for the sandbox application
# This acts as a dependency injection container and state manager

# ===== SHARED SERVICES =====
var time_manager: TimeManager = null  # Ecosystem simulation time

# ===== SHARED STATE =====
var selected_tile_types: Array[int] = []  # Currently selected tiles in palette
var current_tool_mode: SandboxConfig.ToolMode = SandboxConfig.ToolMode.PLACE
var current_layer: int = 0  # Current elevation layer (0-7)
var current_map_tiles: Dictionary = {}  # Vector2i -> MapTile

# ===== MAP METADATA =====
var map_columns: int = SandboxConfig.DEFAULT_MAP_COLUMNS
var map_rows: int = SandboxConfig.DEFAULT_MAP_ROWS
var map_seed: int = 0

# ===== SIGNALS =====
signal tile_selection_changed(selected_types: Array[int])
signal tool_mode_changed(new_mode: SandboxConfig.ToolMode)
signal current_layer_changed(layer: int)
signal map_changed()
signal map_size_changed(columns: int, rows: int)

# ===== METHODS =====

func set_selected_tiles(types: Array[int]) -> void:
	selected_tile_types = types
	tile_selection_changed.emit(types)

func add_selected_tile(type: int) -> void:
	if type not in selected_tile_types:
		selected_tile_types.append(type)
		tile_selection_changed.emit(selected_tile_types)

func remove_selected_tile(type: int) -> void:
	var idx = selected_tile_types.find(type)
	if idx >= 0:
		selected_tile_types.remove_at(idx)
		tile_selection_changed.emit(selected_tile_types)

func clear_selected_tiles() -> void:
	selected_tile_types.clear()
	tile_selection_changed.emit(selected_tile_types)

func set_tool_mode(mode: SandboxConfig.ToolMode) -> void:
	current_tool_mode = mode
	tool_mode_changed.emit(mode)

func set_current_layer(layer: int) -> void:
	layer = clampi(layer, 0, SandboxConfig.MAX_LAYERS - 1)
	current_layer = layer
	current_layer_changed.emit(layer)

func increment_layer() -> void:
	set_current_layer(current_layer + 1)

func decrement_layer() -> void:
	set_current_layer(current_layer - 1)

func set_map_size(columns: int, rows: int) -> void:
	# No artificial limit - use what's requested
	# If it's too big, we'll find out from memory/performance, not arbitrary constants
	map_columns = maxi(1, columns)
	map_rows = maxi(1, rows)
	map_size_changed.emit(map_columns, map_rows)

func get_tile_at(pos: Vector2i) -> MapTile:
	return current_map_tiles.get(pos)

func set_tile_at(pos: Vector2i, tile: MapTile) -> void:
	if tile:
		current_map_tiles[pos] = tile
	else:
		current_map_tiles.erase(pos)
	map_changed.emit()

func clear_map() -> void:
	current_map_tiles.clear()
	map_changed.emit()

func get_random_selected_tile() -> int:
	if selected_tile_types.is_empty():
		return PlanetMapTileConfig.TileType.GRASS_0
	return selected_tile_types[randi() % selected_tile_types.size()]

func initialize_empty_map() -> void:
	"""Create an empty map with default grass tiles."""
	current_map_tiles.clear()
	for x in range(map_columns):
		for y in range(map_rows):
			var pos = Vector2i(x, y)
			var tile = MapTile.new(pos)
			tile.type = PlanetMapTileConfig.TileType.GRASS_0
			tile.elevation = 0
			current_map_tiles[pos] = tile
	map_changed.emit()

func notify_map_changed() -> void:
	"""Emit map_changed signal without modifying data."""
	map_changed.emit()

func save_map_to_file(path: String = "user://sandbox_map.json") -> bool:
	"""Save current map to a JSON file. Returns true on success."""
	var data = {
		"version": 1,
		"columns": map_columns,
		"rows": map_rows,
		"seed": map_seed,
		"tiles": []
	}

	for pos in current_map_tiles:
		var tile: MapTile = current_map_tiles[pos]
		data["tiles"].append({
			"x": pos.x,
			"y": pos.y,
			"type": tile.type,
			"elevation": tile.elevation,
			"surface_feature": tile.surface_feature_type
		})

	var json_string = JSON.stringify(data, "\t")
	var file = FileAccess.open(path, FileAccess.WRITE)
	if file:
		file.store_string(json_string)
		file.close()
		print("SandboxCore: Map saved to %s" % path)
		return true
	else:
		var error = FileAccess.get_open_error()
		push_error("SandboxCore: Failed to save map: %s" % str(error))
		return false

func load_map_from_file(path: String = "user://sandbox_map.json") -> bool:
	"""Load map from JSON file. Returns true on success."""
	var file = FileAccess.open(path, FileAccess.READ)
	if not file:
		var error = FileAccess.get_open_error()
		push_error("SandboxCore: Failed to open file: %s" % str(error))
		return false

	var json_string = file.get_as_text()
	file.close()

	var json = JSON.new()
	var parse_result = json.parse(json_string)
	if parse_result != OK:
		push_error("SandboxCore: Failed to parse JSON: %s" % json.get_error_message())
		return false

	var data = json.data
	if typeof(data) != TYPE_DICTIONARY:
		push_error("SandboxCore: Invalid JSON structure")
		return false

	# Validate required fields
	if not data.has("columns") or not data.has("rows") or not data.has("tiles"):
		push_error("SandboxCore: Missing required fields")
		return false

	# Load the map
	map_columns = data["columns"]
	map_rows = data["rows"]
	map_seed = data.get("seed", 0)

	current_map_tiles.clear()
	for tile_data in data["tiles"]:
		var pos = Vector2i(tile_data["x"], tile_data["y"])
		var tile = MapTile.new(pos)
		tile.type = tile_data["type"]
		tile.elevation = tile_data["elevation"]
		tile.surface_feature_type = tile_data.get("surface_feature", PlanetMapTileConfig.TileType.UNKNOWN)
		current_map_tiles[pos] = tile

	map_size_changed.emit(map_columns, map_rows)
	map_changed.emit()

	print("SandboxCore: Map loaded from %s (%d tiles)" % [path, current_map_tiles.size()])
	return true
