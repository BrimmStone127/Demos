class_name SandboxConfig
extends RefCounted

# Sandbox-wide configuration constants and enums

# ===== VISUAL CONSTANTS =====
const TILE_PREVIEW_SIZE := Vector2(80, 80)
const PREVIEW_COLUMNS := 18
const PREVIEW_ROWS := 12

# ===== MAP CONSTANTS =====
const DEFAULT_MAP_COLUMNS := 32
const DEFAULT_MAP_ROWS := 32
const MAX_MAP_SIZE := 999999  # Effectively unlimited - let physics/memory be the limit, not arbitrary constants!

# ===== ELEVATION CONSTANTS =====
const MAX_LAYERS := 8  # 0-7 elevation layers
const LAYER_HEIGHT_OFFSET := 20.0  # 1/4 height for shorter grass tiles
const DEFAULT_ELEVATION_HEIGHT := 4

# ===== CAMERA/VIEWPORT CONSTANTS =====
const ZOOM_MIN := 0.5
const ZOOM_MAX := 4.0
const ZOOM_STEP := 1.2
const PAN_SPEED := 450.0

# ===== TOOL MODES =====
enum ToolMode {
	PLACE,      # Place random tiles from palette
	ERASE,      # Erase tiles
	PICKER,     # Pick tile type from existing tile (Ctrl+Click)
	BRUSH,      # Paint tiles by dragging (Alt+Drag)
	FILL        # Flood fill (Shift+Click)
}

# ===== ELEVATION PATTERNS =====
enum ElevationPattern {
	FLAT,       # All tiles at layer 0
	RANDOM,     # Random elevation per tile
	NOISE,      # Perlin-like noise terrain
	HILLS,      # Smooth rolling hills
	MOUNTAIN,   # Peak in center
	CRATER,     # Depression in center
	ISLAND,     # High center with low edges
	RIDGES      # Mountain ridge patterns
}

# ===== TILE CATEGORIES =====
enum TileCategory {
	ALL,
	TERRAIN,
	WATER,
	VEGETATION,
	SURFACE_FEATURES,
	SLOPES,
	FLIR,
	GRAYSCALE,
	OTHER
}

# Map TileType to category
static func get_tile_category(tile_type: int) -> TileCategory:
	const TT = PlanetMapTileConfig.TileType

	# FLIR tiles
	if tile_type >= TT.FLIR_0 and tile_type <= TT.FLIR_14:
		return TileCategory.FLIR

	# Water tiles
	if tile_type in [TT.FRESH_WATER, TT.ICE, TT.POLAR_ICE, TT.FROZEN_SURFACE]:
		return TileCategory.WATER

	# Vegetation
	if tile_type in [TT.GRASS_0, TT.GRASS_1, TT.GRASS_2, TT.SF_GRASS, TT.SF_GRASS_2]:
		return TileCategory.VEGETATION

	# Surface features
	if tile_type >= TT.SF_GRASS and tile_type <= TT.SF_LONG_HOUSE:
		return TileCategory.SURFACE_FEATURES

	# Slopes
	if tile_type >= TT.SLOPE_2TILE_LEFT_LOWER and tile_type <= TT.SLOPE_1TILE_PYRAMID:
		return TileCategory.SLOPES

	# Grayscale
	if tile_type >= TT.GRAYSCALE_0 and tile_type <= TT.GRAYSCALE_7:
		return TileCategory.GRAYSCALE

	# Terrain (everything else that's not in other categories)
	if tile_type in [TT.ROCK, TT.MOUNTAIN, TT.VOLCANIC, TT.CRATER, TT.DESERT, TT.RIFT,
					 TT.PLAINS, TT.HIGHLANDS, TT.LOWLANDS, TT.IMPACT_SITE, TT.GEOTHERMAL,
					 TT.CRATER_0, TT.STONE_0]:
		return TileCategory.TERRAIN

	return TileCategory.OTHER

static func get_category_name(category: TileCategory) -> String:
	match category:
		TileCategory.ALL: return "All Tiles"
		TileCategory.TERRAIN: return "Terrain"
		TileCategory.WATER: return "Water"
		TileCategory.VEGETATION: return "Vegetation"
		TileCategory.SURFACE_FEATURES: return "Surface Features"
		TileCategory.SLOPES: return "Slopes"
		TileCategory.FLIR: return "FLIR"
		TileCategory.GRAYSCALE: return "Grayscale"
		TileCategory.OTHER: return "Other"
		_: return "Unknown"

static func get_tile_name(tile_type: int) -> String:
	# Convert enum value to string name
	for key in PlanetMapTileConfig.TileType.keys():
		if PlanetMapTileConfig.TileType[key] == tile_type:
			return key
	return "UNKNOWN"
