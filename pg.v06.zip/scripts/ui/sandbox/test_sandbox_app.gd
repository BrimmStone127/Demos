extends SceneTree
## Quick test launcher for SandboxApp
## Run with: "$GODOT" --path "$(wslpath -w /home/clay/projects/PlanetGame)" -s scripts/ui/sandbox/test_sandbox_app.gd

func _initialize():
	print("Loading SandboxApp...")

	# Load the scene
	var packed_scene = load("res://scenes/SandboxApp.tscn") as PackedScene
	if not packed_scene:
		print("ERROR: Failed to load SandboxApp scene")
		quit(1)
		return

	print("Instantiating SandboxApp...")
	var sandbox = packed_scene.instantiate()
	if not sandbox:
		print("ERROR: Failed to instantiate SandboxApp")
		quit(1)
		return

	# Add to scene tree
	root.add_child(sandbox)

	print("SandboxApp loaded successfully!")
	print("Type: ", sandbox.get_class())
	print("Has sandbox_core: ", sandbox.sandbox_core != null)

	# Wait a bit then quit
	await create_timer(2.0).timeout

	print("Test complete - SandboxApp is functional!")
	quit(0)
