extends Control
class_name Sandbox

## Sandbox for testing planet map generation and terrain editing
## Refactored 2026-03-14: Extracted into focused components for better maintainability
##
## Components:
## - SandboxUIBuilder: UI creation and layout
## - SandboxInputHandler: Mouse/keyboard input and tile manipulation
## - SandboxPlanetGenerator: Planet/terrain generation orchestration
## - SandboxVisualFeedback: Visual overlays and indicators
## - SandboxScenarioManager: Preset scenarios and state export

signal closed

const LOG_TAG := "SANDBOX"

# Constants
const PREVIEW_COLUMNS := 18
const PREVIEW_ROWS := 12
const INVALID_ATLAS_COORDS := Vector2i(-1, -1)
const MIN_PALETTE_WIDTH := 250
const MAX_LAYERS := 8

# Enums are now defined in components:
# - ToolMode: SandboxVisualFeedback.ToolMode
# - ElevationPattern: SandboxPlanetGenerator.ElevationPattern

# Scene references
@onready var split_container: HSplitContainer = %Split
@onready var palette_panel: VBoxContainer = %PalettePanel
@onready var palette_list: VBoxContainer = %PaletteList
@onready var select_all_button: Button = %SelectAllButton
@onready var clear_button: Button = %ClearButton
@onready var regenerate_button: Button = %RegenerateButton
@onready var close_button: Button = %CloseButton
@onready var map_viewport_container: SubViewportContainer = %MapViewportContainer
@onready var map_viewport: SubViewport = %MapViewport
@onready var map_root: Node2D = %MapRoot
@onready var columns_spin: SpinBox = %ColumnsSpin
@onready var rows_spin: SpinBox = %RowsSpin

# State variables
var palette_checks: Array[CheckBox] = []
var selected_tiles: Dictionary = {}
var rng := RandomNumberGenerator.new()
var map_columns: int = PREVIEW_COLUMNS
var map_rows: int = PREVIEW_ROWS
var map_content: Node2D = null
var enable_visual_debug := false

# Planet map components
var tile_manager: PlanetMapTileManager = null
var camera_controller: PlanetMapCamera = null
var selection_manager: PlanetMapSelection = null

# Chunk rendering system (for large maps)
var chunk_manager: ChunkVisibilityManager = null
var using_chunks: bool = false

# Tilemap data
var layer_tilemaps: Array[TileMap] = []
var surface_feature_layers: Array[TileMap] = []
var preview_tileset: TileSet = null
var preview_tileset_source_id: int = -1
var tile_types_by_cell: Dictionary = {}  # {Vector3i(x,y,z): tile_type}
var current_layer: int = 0
var current_tool: SandboxVisualFeedback.ToolMode = SandboxVisualFeedback.ToolMode.PLACE

# Extracted components (initialized in _ready)
var _ui_builder: SandboxUIBuilder = null
var _input_handler: SandboxInputHandler = null
var _planet_generator: SandboxPlanetGenerator = null
var _visual_feedback: SandboxVisualFeedback = null
var _scenario_manager: SandboxScenarioManager = null
var _search_dialog: TileSearchDialog = null

# UI element references (created by components)
var layer_spin: SpinBox = null
var elevation_pattern_option: OptionButton = null
var elevation_amplitude_spin: SpinBox = null
var generate_elevation_button: Button = null
var planet_type_option: OptionButton = null
var geological_activity_option: OptionButton = null
var climate_type_option: OptionButton = null
var atmosphere_type_option: OptionButton = null
var water_slider: HSlider = null
var ice_slider: HSlider = null
var lava_slider: HSlider = null
var planet_seed_spin: SpinBox = null
var generate_planet_button: Button = null
var water_value_label: Label = null
var ice_value_label: Label = null
var lava_value_label: Label = null
var clear_layer_button: Button = null
var debug_toggle_button: CheckButton = null
var layer_indicator_label: Label = null
var preview_sprite: Sprite2D = null
var tile_inspector_panel: PanelContainer = null
var hover_highlight: Polygon2D = null

func _ready():
	TerminalTheme.apply_recursive(self)

	# Add version label to header
	_add_version_label()

	map_viewport_container.stretch = false
	set_process(true)
	set_process_input(true)

	rng.randomize()

	# Initialize components
	_initialize_components()

	# Setup UI and map
	_setup_ui()
	_ensure_map_nodes()
	_setup_visual_feedback()
	_setup_input_handler()
	_setup_search_dialog()
	_populate_palette()

	# Enable chunk rendering if PNG terrain is available
	if FileAccess.file_exists("res://assets/terrain/reference/full_map_8bit.png"):
		enable_chunk_rendering()
	else:
		_regenerate_map()

	_on_map_container_resized()

# ============================================================================
# COMPONENT INITIALIZATION
# ============================================================================

func _initialize_components():
	_ui_builder = SandboxUIBuilder.new()
	_input_handler = SandboxInputHandler.new()
	_planet_generator = SandboxPlanetGenerator.new()
	_visual_feedback = SandboxVisualFeedback.new()
	_scenario_manager = SandboxScenarioManager.new()

func _setup_ui():
	"""Build all UI elements using SandboxUIBuilder"""
	var ui_refs = _ui_builder.build_ui(
		palette_panel,
		close_button,
		select_all_button,
		clear_button,
		regenerate_button,
		split_container,
		map_viewport_container,
		columns_spin,
		rows_spin,
		rng,
		# Callbacks
		_on_close_pressed,
		_set_all_palette,
		_regenerate_map,
		_on_clear_layer_pressed,
		_on_debug_toggle,
		_on_columns_spin_changed,
		_on_rows_spin_changed,
		_on_layer_spin_changed,
		_on_generate_elevation_pressed,
		_on_load_csv_pressed,
		_on_add_surface_features_pressed,
		_on_water_slider_changed,
		_on_ice_slider_changed,
		_on_lava_slider_changed,
		_on_earth_preset_pressed,
		_on_generate_planet_pressed,
		_update_split_offset,
		_on_map_container_resized,
		_on_viewport_gui_input
	)

	# Store UI element references
	layer_spin = ui_refs.get("layer_spin")
	elevation_pattern_option = ui_refs.get("elevation_pattern_option")
	elevation_amplitude_spin = ui_refs.get("elevation_amplitude_spin")
	generate_elevation_button = ui_refs.get("generate_elevation_button")
	planet_type_option = ui_refs.get("planet_type_option")
	geological_activity_option = ui_refs.get("geological_activity_option")
	climate_type_option = ui_refs.get("climate_type_option")
	atmosphere_type_option = ui_refs.get("atmosphere_type_option")
	water_slider = ui_refs.get("water_slider")
	ice_slider = ui_refs.get("ice_slider")
	lava_slider = ui_refs.get("lava_slider")
	planet_seed_spin = ui_refs.get("planet_seed_spin")
	generate_planet_button = ui_refs.get("generate_planet_button")
	water_value_label = ui_refs.get("water_value_label")
	ice_value_label = ui_refs.get("ice_value_label")
	lava_value_label = ui_refs.get("lava_value_label")
	clear_layer_button = ui_refs.get("clear_layer_button")
	debug_toggle_button = ui_refs.get("debug_toggle_button")

	_log_debug("UI built successfully")

func _setup_visual_feedback():
	"""Create all visual feedback elements"""
	layer_indicator_label = _visual_feedback.create_layer_indicator(map_viewport_container)
	preview_sprite = _visual_feedback.create_preview_sprite(map_content)
	tile_inspector_panel = _visual_feedback.create_tile_inspector(map_viewport_container)
	hover_highlight = _visual_feedback.create_hover_highlight(map_content)

	_update_layer_indicator()
	_log_debug("Visual feedback elements created")

func _setup_search_dialog():
	"""Create tile search dialog for Ctrl+F navigation"""
	_search_dialog = TileSearchDialog.new()
	add_child(_search_dialog)
	_search_dialog.tile_search_requested.connect(_on_tile_search_requested)
	_search_dialog.set_map_size(Vector2i(map_columns, map_rows))
	_log_info("Tile search dialog created and added to tree: %s, parent: %s" % [_search_dialog, _search_dialog.get_parent()])

# ============================================================================
# INPUT HANDLING
# ============================================================================

func _input(event):
	if not is_visible_in_tree():
		return

	# Ctrl+F to open tile search dialog
	if event is InputEventKey and event.pressed and not event.is_echo():
		if event.keycode == KEY_F and event.ctrl_pressed and not event.shift_pressed and not event.alt_pressed:
			_log_info("Ctrl+F detected, opening search dialog")
			_open_search_dialog()
			accept_event()
			return

	if _input_handler:
		_input_handler.handle_input_event(event, is_visible_in_tree())

func _on_viewport_gui_input(event: InputEvent):
	if _input_handler:
		_input_handler.handle_viewport_gui_input(event)

func _unhandled_key_input(event):
	if _input_handler:
		var handled = _input_handler.handle_unhandled_key_input(event)
		if handled:
			get_viewport().set_input_as_handled()
		elif event.is_pressed() and event.keycode == KEY_ESCAPE:
			_on_close_pressed()
			get_viewport().set_input_as_handled()

func _process(_delta):
	# Update chunk visibility based on camera position
	if using_chunks and chunk_manager and camera_controller and camera_controller.camera:
		# Convert camera global position to map_content local space (where chunks live)
		var camera_local_pos = map_content.to_local(camera_controller.camera.global_position)
		chunk_manager.update_camera_position(camera_local_pos)

# ============================================================================
# MAP MANAGEMENT
# ============================================================================

func _ensure_map_nodes():
	"""Create or get essential map nodes (tile manager, camera, selection manager)"""
	if not map_root or not is_instance_valid(map_root):
		return

	# Find or create map_content
	map_content = map_root.get_node_or_null("MapContent")
	if not map_content:
		map_content = Node2D.new()
		map_content.name = "MapContent"
		map_root.add_child(map_content)

	# Create or get tile manager
	if not tile_manager or not is_instance_valid(tile_manager):
		tile_manager = PlanetMapTileManager.new()
		tile_manager.name = "TileManager"
		map_content.add_child(tile_manager)

		# Center the tile manager content
		var map_size = Vector2i(map_columns, map_rows)
		var world_center := PlanetMapCoordinates.get_map_center_world_position(map_size)
		tile_manager.position = -world_center

		_log_info("Created PlanetMapTileManager for Sandbox")

	# Create or get camera controller
	if not camera_controller or not is_instance_valid(camera_controller):
		camera_controller = PlanetMapCamera.new()
		camera_controller.name = "CameraController"
		map_viewport.add_child(camera_controller)
		_log_info("Created PlanetMapCamera for Sandbox")

	# Create or get selection manager
	if not selection_manager or not is_instance_valid(selection_manager):
		selection_manager = PlanetMapSelection.new()
		selection_manager.name = "SelectionManager"
		tile_manager.ensure_overlay_layer().add_child(selection_manager)
		selection_manager.map_viewport = map_viewport
		_log_info("Created PlanetMapSelection for Sandbox")

func _ensure_tileset():
	"""Ensure the tileset is loaded and configured"""
	# Tileset is now managed by PlanetMapTileManager
	# Update legacy references for compatibility
	if tile_manager:
		preview_tileset_source_id = tile_manager.tile_map_source_id

func _ensure_layer_tilemap(layer: int) -> TileMap:
	"""Get or create a TileMap for the specified z-layer using PlanetMapTileManager"""
	if not tile_manager:
		_log_error("Cannot create layer tilemap: tile_manager not initialized")
		return null

	var tilemap = tile_manager.ensure_layer_tilemap(layer)

	if tilemap:
		_ensure_tileset()
		tilemap.tile_set = preview_tileset
		tilemap.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

		# Update layer_tilemaps array
		while layer_tilemaps.size() <= layer:
			layer_tilemaps.append(null)
		layer_tilemaps[layer] = tilemap

	return tilemap

func _regenerate_map():
	"""Generate a random map"""
	_log_info("Regenerating map with %dx%d cells", [map_columns, map_rows])

	# Clear existing data
	for tilemap in layer_tilemaps:
		if tilemap and is_instance_valid(tilemap):
			tilemap.clear()
	tile_types_by_cell.clear()

	# Get active tile types from palette selection
	var active_tiles := _gather_active_tile_types()
	if active_tiles.is_empty():
		active_tiles = _default_tile_types()

	# Ensure we have at least one tile type
	if active_tiles.is_empty():
		_log_error("No tile types available to generate")
		return

	# Generate tiles on layer 0
	var tilemap = _ensure_layer_tilemap(0)
	if not tilemap:
		_log_error("Failed to create tilemap for layer 0")
		return

	rng.randomize()

	# Fill the entire map with random tiles from active selection
	_ensure_tileset()
	for x in range(map_columns):
		for y in range(map_rows):
			var tile_type: int = int(active_tiles[rng.randi_range(0, active_tiles.size() - 1)])
			var atlas_coords: Vector2i = PlanetMapTileConfig.TILESET_REGION_MAP.get(tile_type, INVALID_ATLAS_COORDS)

			if atlas_coords != INVALID_ATLAS_COORDS and preview_tileset_source_id != -1:
				tilemap.set_cell(0, Vector2i(x, y), preview_tileset_source_id, atlas_coords)
				var cell_3d = Vector3i(x, y, 0)
				tile_types_by_cell[cell_3d] = tile_type

	_update_layer_indicator()
	_log_info("Map regenerated with %d tiles", [tile_types_by_cell.size()])

	# Update search dialog with new map size
	if _search_dialog:
		_search_dialog.set_map_size(Vector2i(map_columns, map_rows))

func _generate_grass_base_map():
	"""Generate a grass-only base map for CSV terrain import"""
	_log_info("Generating grass base map with %dx%d cells", [map_columns, map_rows])

	# Clear existing data
	for tilemap in layer_tilemaps:
		if tilemap and is_instance_valid(tilemap):
			tilemap.clear()
	tile_types_by_cell.clear()

	# Generate grass tiles on layer 0 (use new 1/4-height grass)
	var tilemap = _ensure_layer_tilemap(0)
	if not tilemap:
		_log_error("Failed to create tilemap for layer 0")
		return

	_ensure_tileset()
	# Use GRAYSCALE_4 (mid-tone) for CSV terrain since grass tile not yet in tileset
	var terrain_tile = PlanetMapTileConfig.TileType.GRAYSCALE_4
	var atlas_coords: Vector2i = PlanetMapTileConfig.TILESET_REGION_MAP.get(terrain_tile, INVALID_ATLAS_COORDS)

	_log_info("Using GRAYSCALE_4 (ID: %d) at atlas coords: %s for CSV terrain", [terrain_tile, atlas_coords])

	if atlas_coords == INVALID_ATLAS_COORDS or preview_tileset_source_id == -1:
		_log_error("Failed to get grass tile atlas coordinates (coords=%s, source_id=%d)", [atlas_coords, preview_tileset_source_id])
		return

	# Fill entire map with grass
	for x in range(map_columns):
		for y in range(map_rows):
			tilemap.set_cell(0, Vector2i(x, y), preview_tileset_source_id, atlas_coords)
			var cell_3d = Vector3i(x, y, 0)
			tile_types_by_cell[cell_3d] = terrain_tile

	_update_layer_indicator()
	_log_info("Grass base map generated with %d tiles", [tile_types_by_cell.size()])

# ============================================================================
# ELEVATION GENERATION
# ============================================================================

func _on_generate_elevation_pressed():
	"""Generate elevation pattern using SandboxPlanetGenerator"""
	if not elevation_pattern_option or not elevation_amplitude_spin:
		return

	var pattern: SandboxPlanetGenerator.ElevationPattern = elevation_pattern_option.get_selected_id() as SandboxPlanetGenerator.ElevationPattern
	var max_height: int = int(elevation_amplitude_spin.value)

	_log_info("Generating elevation pattern: %s with max height %d", [
		elevation_pattern_option.get_item_text(elevation_pattern_option.selected),
		max_height
	])

	# Generate elevation map using component
	var elevation_map = _planet_generator.generate_elevation_map(
		map_columns,
		map_rows,
		pattern,
		max_height,
		rng.randi()
	)

	# Apply elevation to tiles
	_apply_elevation_map(elevation_map)

func _apply_elevation_map(elevation_map: Dictionary):
	"""Apply elevation map to existing tiles"""
	for cell_2d in elevation_map.keys():
		var target_elevation = elevation_map[cell_2d]

		# Find existing tile at this position (check all layers)
		var tile_type = -1
		for layer in range(MAX_LAYERS):
			var cell_3d = Vector3i(cell_2d.x, cell_2d.y, layer)
			if tile_types_by_cell.has(cell_3d):
				tile_type = tile_types_by_cell[cell_3d]
				# Erase from old layer
				if layer < layer_tilemaps.size() and layer_tilemaps[layer]:
					layer_tilemaps[layer].erase_cell(0, cell_2d)
				tile_types_by_cell.erase(cell_3d)
				break

		# If no tile found, skip
		if tile_type == -1:
			continue

		# Place tile at target elevation
		# Fill in all layers from 0 to target_elevation to create columns
		for layer in range(target_elevation + 1):
			var tilemap = _ensure_layer_tilemap(layer)
			if not tilemap:
				continue

			var atlas_coords: Vector2i = PlanetMapTileConfig.TILESET_REGION_MAP.get(tile_type, INVALID_ATLAS_COORDS)
			if atlas_coords != INVALID_ATLAS_COORDS and preview_tileset_source_id != -1:
				tilemap.set_cell(0, cell_2d, preview_tileset_source_id, atlas_coords)
				var cell_3d = Vector3i(cell_2d.x, cell_2d.y, layer)
				tile_types_by_cell[cell_3d] = tile_type

	# Update selection manager with new elevation data
	if selection_manager:
		var map_tiles: Array = []
		for x in range(map_columns):
			var column: Array = []
			for y in range(map_rows):
				var cell = Vector2i(x, y)
				var elevation = elevation_map.get(cell, 0)
				var tile_type = tile_types_by_cell.get(Vector3i(x, y, elevation), PlanetMapView.TileType.GRASS_0)

				var map_tile = MapTile.new(cell, tile_type)
				map_tile.world_position = PlanetMapCoordinates.grid_to_world(cell)
				map_tile.elevation = elevation
				column.append(map_tile)
			map_tiles.append(column)

		selection_manager.map_tiles = map_tiles
		selection_manager.layer_tilemaps = tile_manager.get_all_layer_tilemaps()

	_update_layer_indicator()

	# Recreate debug overlay if enabled
	if enable_visual_debug:
		_visual_feedback.create_debug_overlay(
			map_content,
			current_layer,
			map_columns,
			map_rows,
			layer_tilemaps,
			_ensure_layer_tilemap
		)

# ============================================================================
# CSV LOADING
# ============================================================================

func _on_load_csv_pressed(csv_path: String, downsample: int, start_x: int, start_y: int, chunk_width: int, chunk_height: int):
	"""Load CSV elevation data using SandboxPlanetGenerator"""
	var elevation_map = _planet_generator.load_csv_terrain(
		csv_path,
		downsample,
		start_x,
		start_y,
		chunk_width,
		chunk_height
	)

	if elevation_map.is_empty():
		_log_error("Failed to load CSV terrain")
		return

	# Update map size to match loaded data
	var max_x = 0
	var max_y = 0
	for cell in elevation_map.keys():
		if cell.x > max_x:
			max_x = cell.x
		if cell.y > max_y:
			max_y = cell.y

	map_columns = max_x + 1
	map_rows = max_y + 1
	columns_spin.value = map_columns
	rows_spin.value = map_rows

	# Generate base grass tiles for CSV terrain (use new 1/4-height grass)
	_generate_grass_base_map()

	# Apply elevation from CSV data
	_apply_elevation_map(elevation_map)

# ============================================================================
# PLANET GENERATION
# ============================================================================

func _on_generate_planet_pressed():
	"""Generate planet map using SandboxPlanetGenerator"""
	if not planet_type_option:
		return

	var generated_tiles = _planet_generator.generate_planet_map(
		planet_type_option.get_selected_id(),
		atmosphere_type_option.get_selected_id() if atmosphere_type_option else 0,
		water_slider.value / 100.0 if water_slider else 0.3,
		ice_slider.value / 100.0 if ice_slider else 0.1,
		lava_slider.value / 100.0 if lava_slider else 0.0,
		geological_activity_option.get_selected_id() if geological_activity_option else 0,
		climate_type_option.get_selected_id() if climate_type_option else 0,
		int(planet_seed_spin.value) if planet_seed_spin else 0
	)

	if generated_tiles.is_empty():
		return

	# Load generated tiles
	_load_generated_tiles(generated_tiles)

func _load_generated_tiles(generated_tiles: Array):
	"""Load generated tiles into the sandbox canvas"""
	if generated_tiles.is_empty():
		return

	var tile_width = generated_tiles.size()
	var tile_height = generated_tiles[0].size() if tile_width > 0 else 0

	_log_info("Loading %dx%d generated tiles into sandbox", [tile_width, tile_height])

	# Update map size
	map_columns = tile_width
	map_rows = tile_height
	columns_spin.value = map_columns
	rows_spin.value = map_rows

	# Clear existing tiles
	for tilemap in layer_tilemaps:
		if tilemap and is_instance_valid(tilemap):
			tilemap.clear()
	tile_types_by_cell.clear()

	# Load tiles
	_ensure_tileset()
	var tiles_loaded = 0

	for x in range(tile_width):
		for y in range(tile_height):
			if x >= generated_tiles.size() or y >= generated_tiles[x].size():
				continue

			var map_tile: MapTile = generated_tiles[x][y]
			if not map_tile:
				continue

			var elevation = map_tile.elevation
			var tile_type = map_tile.type

			# Fill in all layers from 0 to elevation
			for layer in range(elevation + 1):
				var tilemap = _ensure_layer_tilemap(layer)
				if tilemap:
					var atlas_coords = PlanetMapTileConfig.TILESET_REGION_MAP.get(tile_type, INVALID_ATLAS_COORDS)
					if atlas_coords != INVALID_ATLAS_COORDS and preview_tileset_source_id != -1:
						tilemap.set_cell(0, Vector2i(x, y), preview_tileset_source_id, atlas_coords)
						var cell_3d = Vector3i(x, y, layer)
						tile_types_by_cell[cell_3d] = tile_type
						tiles_loaded += 1

	_log_info("Loaded %d tiles into sandbox", [tiles_loaded])

	# Update selection manager
	if selection_manager:
		selection_manager.map_tiles = generated_tiles
		selection_manager.layer_tilemaps = tile_manager.get_all_layer_tilemaps()
		selection_manager.map_viewport = map_viewport

	_update_layer_indicator()

func _on_add_surface_features_pressed():
	"""Add surface features (trees) to terrain"""
	_planet_generator.add_surface_features(
		layer_tilemaps,
		tile_types_by_cell,
		map_columns,
		map_rows,
		rng.randi()
	)
	_update_layer_indicator()

# ============================================================================
# UI CALLBACKS
# ============================================================================

func _on_columns_spin_changed(value: float):
	map_columns = max(1, int(value))
	if _search_dialog:
		_search_dialog.set_map_size(Vector2i(map_columns, map_rows))

func _on_rows_spin_changed(value: float):
	map_rows = max(1, int(value))
	if _search_dialog:
		_search_dialog.set_map_size(Vector2i(map_columns, map_rows))

func _on_layer_spin_changed(value: float):
	current_layer = clampi(int(value), 0, MAX_LAYERS - 1)
	_update_layer_indicator()

func _on_water_slider_changed(value: float):
	if water_value_label:
		water_value_label.text = "%d%%" % int(value)

func _on_ice_slider_changed(value: float):
	if ice_value_label:
		ice_value_label.text = "%d%%" % int(value)

func _on_lava_slider_changed(value: float):
	if lava_value_label:
		lava_value_label.text = "%d%%" % int(value)

func _on_earth_preset_pressed():
	"""Apply Earth-like preset values"""
	if planet_type_option:
		planet_type_option.selected = 1  # Rocky Medium
	if geological_activity_option:
		geological_activity_option.selected = 2  # Moderate
	if climate_type_option:
		climate_type_option.selected = 2  # Temperate
	if atmosphere_type_option:
		atmosphere_type_option.selected = 2  # Moderate
	if water_slider:
		water_slider.value = 71
	if ice_slider:
		ice_slider.value = 3
	if lava_slider:
		lava_slider.value = 0

	_log_info("Earth-like preset applied")

func _on_clear_layer_pressed():
	"""Clear all tiles on the current layer"""
	var tilemap = _ensure_layer_tilemap(current_layer)
	if not tilemap or not is_instance_valid(tilemap):
		return

	tilemap.clear()

	# Remove all tiles from this layer in the dictionary
	var keys_to_remove = []
	for key in tile_types_by_cell.keys():
		if key is Vector3i and key.z == current_layer:
			keys_to_remove.append(key)

	for key in keys_to_remove:
		tile_types_by_cell.erase(key)

	_update_layer_indicator()
	_log_info("Cleared layer %d", [current_layer])

func _on_debug_toggle(enabled: bool):
	"""Toggle debug overlay showing click areas"""
	enable_visual_debug = enabled
	if enabled:
		_visual_feedback.create_debug_overlay(
			map_content,
			current_layer,
			map_columns,
			map_rows,
			layer_tilemaps,
			_ensure_layer_tilemap
		)
	else:
		_visual_feedback.clear_debug_overlay()

func _on_map_container_resized():
	"""Update viewport size when container is resized"""
	if not map_viewport_container or not map_viewport:
		return
	var container_size := map_viewport_container.get_size()
	map_viewport.size = Vector2i(max(int(container_size.x), 1), max(int(container_size.y), 1))

func _update_split_offset(_unused = null):
	"""Update split container offset (no-op for now)"""
	pass

func _on_close_pressed():
	"""Close the sandbox and return to previous scene"""
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	emit_signal("closed")
	queue_free()

func _on_tile_search_requested(tile_pos: Vector2i):
	"""Handle tile search request from search dialog"""
	_log_info("Search requested for tile %s" % tile_pos)

	if not camera_controller or not selection_manager or not tile_manager:
		return

	# Get the tile object
	var tile = selection_manager.get_tile_at(tile_pos)
	if not tile:
		_log_warn("No tile found at %s" % tile_pos)
		return

	# calculate_tile_visual_center returns position in tile_manager's LOCAL space
	# (tilemap.map_to_local + tilemap.position, where tilemap is a child of tile_manager)
	var local_pos = selection_manager.calculate_tile_visual_center(tile)

	# Convert to GLOBAL coordinates for the camera
	# The camera is NOT inside tile_manager's hierarchy, so it needs global coords
	# tile_manager.position = -world_center, which offsets all its children
	var target_pos = tile_manager.to_global(local_pos)

	_log_info("Moving camera to tile %s, local=%s, global=%s" % [tile_pos, local_pos, target_pos])

	# Move camera to the calculated position
	camera_controller.move_to_position(target_pos, 0.6, Vector2(2.5, 2.5))

	# Select the tile after camera arrives
	await get_tree().create_timer(0.65).timeout
	selection_manager.apply_tile_selection(tile)

func _open_search_dialog():
	"""Open the tile search dialog"""
	_log_info("_open_search_dialog() called - dialog exists: %s, in_tree: %s" % [
		_search_dialog != null,
		_search_dialog.is_inside_tree() if _search_dialog else false
	])

	if not _search_dialog:
		_log_warn("Search dialog not initialized")
		return

	# Update map size before showing
	_search_dialog.set_map_size(Vector2i(map_columns, map_rows))

	_log_info("Calling show_dialog() on search dialog (layer=%d)" % _search_dialog.layer)
	_search_dialog.show_dialog()
	_log_info("After show_dialog() - dialog visible: %s" % _search_dialog.visible)

# ============================================================================
# PALETTE MANAGEMENT
# ============================================================================

func _populate_palette():
	"""Populate the tile palette with checkboxes"""
	_log_debug("Populating sandbox palette")
	palette_checks.clear()

	for child in palette_list.get_children():
		child.queue_free()

	var keys: PackedStringArray = PlanetMapView.TileType.keys()
	keys.sort()

	for key in keys:
		var tile_type: int = PlanetMapView.TileType[key]
		var check := CheckBox.new()
		check.text = _prettify_name(key)
		check.button_pressed = false
		selected_tiles[tile_type] = false
		check.toggled.connect(func(pressed): selected_tiles[tile_type] = pressed)
		palette_list.add_child(check)
		palette_checks.append(check)

func _set_all_palette(enabled: bool):
	"""Enable or disable all palette items"""
	for check in palette_checks:
		check.button_pressed = enabled

func _gather_active_tile_types() -> Array:
	"""Get list of active tile types from palette"""
	var active: Array = []
	for tile_type in selected_tiles.keys():
		if selected_tiles[tile_type]:
			active.append(tile_type)
	return active

func _default_tile_types() -> Array:
	"""Get default tile types when none selected"""
	var out: Array = []
	var keys: PackedStringArray = PlanetMapView.TileType.keys()
	keys.sort()
	for key in keys:
		out.append(PlanetMapView.TileType[key])
	return out

func _prettify_name(raw: String) -> String:
	"""Convert enum name to readable format"""
	return raw.replace("_", " ").capitalize()

# ============================================================================
# VISUAL FEEDBACK UPDATES
# ============================================================================

func _update_layer_indicator():
	"""Update the layer indicator text"""
	if _visual_feedback:
		_visual_feedback.update_layer_indicator(
			current_layer,
			tile_types_by_cell,
			map_columns,
			map_rows,
			current_tool
		)

# ============================================================================
# INPUT HANDLER INITIALIZATION
# ============================================================================

func _setup_input_handler():
	"""Initialize the input handler with required dependencies"""
	if not _input_handler:
		return

	_input_handler.initialize(
		camera_controller,
		tile_manager,
		selection_manager,
		map_viewport,
		layer_tilemaps,
		surface_feature_layers,
		map_columns,
		map_rows,
		tile_types_by_cell,
		preview_tileset_source_id,
		rng
	)

	# Set UI elements
	if preview_sprite and tile_inspector_panel and hover_highlight and layer_spin:
		_input_handler.set_ui_elements(preview_sprite, tile_inspector_panel, hover_highlight, layer_spin)

	# Set callbacks
	_input_handler.gather_active_tiles_callback = _gather_active_tile_types
	_input_handler.default_tiles_callback = _default_tile_types
	_input_handler.ensure_layer_tilemap_callback = _ensure_layer_tilemap

	# Connect signals
	_input_handler.layer_indicator_update_requested.connect(_update_layer_indicator)

	_log_info("Input handler initialized")

# ============================================================================
# CLI API - Programmatic scenario loading and state export
# ============================================================================

## Get list of available predefined scenarios
static func get_available_scenarios() -> Array:
	return SandboxScenarioManager.get_available_scenarios()

## Load a predefined scenario by name
## Returns true if successful, false if scenario not found
func load_scenario(scenario_name: String) -> bool:
	if not _scenario_manager:
		_log_error("Cannot load scenario: scenario manager not initialized")
		return false

	var config = _scenario_manager.load_scenario(scenario_name)
	if config.is_empty():
		_log_warn("Scenario not found: %s", [scenario_name])
		return false

	var ui_refs = _get_scenario_ui_refs()

	var success = _scenario_manager.apply_scenario_config(config, ui_refs)
	if success:
		_log_info("Loaded scenario: %s", [scenario_name])
		# Trigger map regeneration
		_on_generate_planet_pressed()
	return success

## Get current scenario configuration
func get_scenario_config() -> Dictionary:
	if not _scenario_manager:
		return {}
	return _scenario_manager.get_scenario_config(_get_scenario_ui_refs())

## Set scenario configuration directly
func set_scenario_config(config: Dictionary) -> bool:
	if not _scenario_manager:
		return false

	var ui_refs = _get_scenario_ui_refs()

	var success = _scenario_manager.apply_scenario_config(config, ui_refs)
	if success:
		_log_info("Applied custom scenario config")
		# Trigger map regeneration
		_on_generate_planet_pressed()
	return success

## Export current state including configuration and statistics
func export_state() -> Dictionary:
	if not _scenario_manager:
		return {}
	return _scenario_manager.export_state(_get_scenario_ui_refs(), tile_types_by_cell, map_columns, map_rows)

## Build complete UI refs dictionary for scenario manager
func _get_scenario_ui_refs() -> Dictionary:
	return {
		"planet_type_option": planet_type_option,
		"geological_activity_option": geological_activity_option,
		"climate_type_option": climate_type_option,
		"atmosphere_type_option": atmosphere_type_option,
		"water_slider": water_slider,
		"ice_slider": ice_slider,
		"lava_slider": lava_slider,
		"planet_seed_spin": planet_seed_spin
	}

# ============================================================================
# CHUNK RENDERING SYSTEM
# ============================================================================

## Enable chunk-based rendering for large maps
func enable_chunk_rendering():
	_log_info("Enabling chunk-based rendering...")

	# Clear existing traditional rendering
	if tile_manager:
		for tilemap in layer_tilemaps:
			if tilemap and is_instance_valid(tilemap):
				tilemap.queue_free()
		layer_tilemaps.clear()

	# Create PNG terrain source
	var png_path = "res://assets/terrain/reference/full_map_8bit.png"
	var terrain_source = PNGTerrainSource.new(png_path)

	if not terrain_source.is_loaded():
		_log_error("Failed to load PNG terrain from %s" % png_path)
		return

	_log_info("PNG terrain loaded: %dx%d pixels" % [terrain_source.get_png_size().x, terrain_source.get_png_size().y])

	# Create chunk manager
	chunk_manager = ChunkVisibilityManager.new()
	chunk_manager.name = "ChunkManager"
	chunk_manager.set_terrain_source(terrain_source)
	map_content.add_child(chunk_manager)

	# Enable chunk mode
	using_chunks = true

	# Position camera at start of map
	if camera_controller and camera_controller.camera:
		var start_pos = PlanetMapCoordinates.grid_to_world(Vector2i(64, 64))  # Start at chunk (1, 1)
		camera_controller.camera.position = start_pos
		_log_info("Camera positioned at %s" % start_pos)

	# Force initial chunk load
	if camera_controller and camera_controller.camera:
		# Convert camera global position to map_content local space (where chunks live)
		var camera_local_pos = map_content.to_local(camera_controller.camera.global_position)
		chunk_manager.update_camera_position(camera_local_pos)

	_log_info("Chunk rendering enabled - navigate with WASD or arrow keys")
	_log_info("Map size: %s chunks (%s tiles)" % [
		terrain_source.get_bounds().size,
		terrain_source.get_tile_size()
	])

	# Debug: Print chunk stats after initial load
	await get_tree().process_frame
	await get_tree().process_frame
	var stats = chunk_manager.get_stats()
	_log_info("Chunks loaded: %d visible, %d hidden, %d total" % [
		stats["visible_chunks"],
		stats["hidden_chunks"],
		stats["loaded_chunks"]
	])

# ============================================================================
# LOGGING
# ============================================================================

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, message % values if values.size() > 0 else message)

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, message % values if values.size() > 0 else message)

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, message % values if values.size() > 0 else message)

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, message % values if values.size() > 0 else message)

func _debug_log_state():
	"""Debug logging for state verification"""
	if camera_controller:
		var cam = camera_controller.get_camera()
		if cam:
			_log_info("Camera state: pos=%s, zoom=%s, enabled=%s, current=%s", [
				cam.position, cam.zoom, cam.enabled, cam.is_current()
			])

	if map_root:
		_log_info("map_root: pos=%s, visible=%s", [map_root.position, map_root.visible])

	if tile_manager:
		var tilemaps = tile_manager.get_all_layer_tilemaps()
		_log_info("tile_manager: pos=%s, tilemaps=%d", [tile_manager.position, tilemaps.size()])
		if tilemaps.size() > 0 and tilemaps[0]:
			var tm = tilemaps[0]
			_log_info("tilemap[0]: pos=%s, visible=%s, used_cells=%d", [
				tm.position, tm.visible, tm.get_used_cells(0).size()
			])

# ============================================================================
# VERSION DISPLAY
# ============================================================================

func _add_version_label():
	"""Add version label to header"""
	# Find the header container
	var header = find_child("Header")
	if not header:
		_log_warn("Could not find Header container for version label")
		return

	# Create version label
	var version_label = Label.new()
	version_label.text = "v%s" % Version.SHORT
	version_label.size_flags_horizontal = Control.SIZE_SHRINK_END
	version_label.add_theme_font_size_override("font_size", 12)
	version_label.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))

	# Add before close button (so it's Title | Version | Close)
	var close_button_idx = -1
	for i in header.get_child_count():
		if header.get_child(i) == close_button:
			close_button_idx = i
			break

	if close_button_idx >= 0:
		header.add_child(version_label)
		header.move_child(version_label, close_button_idx)
	else:
		header.add_child(version_label)
