class_name TerrainRegionSelector
extends RefCounted

## Static utility for selecting terrain regions from St. Louis heightmap PNG
## Provides deterministic, seed-based region selection for habitable planet maps

# St. Louis heightmap dimensions
const FULL_MAP_SIZE := Vector2i(3612, 3612)  # Full PNG dimensions
const REGION_SIZE := Vector2i(64, 64)        # Standard planet map size

# Calculate how many non-overlapping regions fit in the full map
const REGIONS_PER_AXIS := Vector2i(
	FULL_MAP_SIZE.x / REGION_SIZE.x,  # 56 regions horizontally
	FULL_MAP_SIZE.y / REGION_SIZE.y   # 56 regions vertically
)
const TOTAL_REGIONS := REGIONS_PER_AXIS.x * REGIONS_PER_AXIS.y  # 3,136 unique regions

## Get a deterministic region from the St. Louis heightmap based on planet seed
##
## Args:
##   planet_seed: Planet's seed value for deterministic selection
##
## Returns:
##   Dictionary with:
##     - region_index: Vector2i(rx, ry) - grid position (0-55, 0-55)
##     - pixel_offset: Vector2i(x, y) - top-left pixel in full PNG
##     - bounds: Dictionary for PNGTerrainLoader.load_png() region param
static func get_region_for_seed(planet_seed: int) -> Dictionary:
	# Use seed to pick one of 3,136 regions deterministically
	var rng = RandomNumberGenerator.new()
	rng.seed = abs(planet_seed)  # Ensure positive seed

	# Pick region coordinates (0-55 for both x and y)
	var region_x = rng.randi_range(0, REGIONS_PER_AXIS.x - 1)
	var region_y = rng.randi_range(0, REGIONS_PER_AXIS.y - 1)

	# Calculate pixel offset in the full PNG
	var pixel_x = region_x * REGION_SIZE.x
	var pixel_y = region_y * REGION_SIZE.y

	return {
		"region_index": Vector2i(region_x, region_y),
		"pixel_offset": Vector2i(pixel_x, pixel_y),
		"bounds": {
			"x": pixel_x,
			"y": pixel_y,
			"width": REGION_SIZE.x,
			"height": REGION_SIZE.y
		}
	}

## Get just the region grid index (useful for logging/debugging)
static func get_region_index(planet_seed: int) -> Vector2i:
	var region_data = get_region_for_seed(planet_seed)
	return region_data["region_index"]

## Check if PNG heightmap exists
static func png_exists() -> bool:
	return FileAccess.file_exists("res://assets/terrain/reference/full_map_8bit.png")

## Get the full PNG path
static func get_png_path() -> String:
	return "res://assets/terrain/reference/full_map_8bit.png"

## Get region info string for logging
static func get_region_info(planet_seed: int) -> String:
	var region_data = get_region_for_seed(planet_seed)
	var idx = region_data["region_index"]
	var offset = region_data["pixel_offset"]
	return "Region [%d,%d] (pixels %d-%d, %d-%d)" % [
		idx.x, idx.y,
		offset.x, offset.x + REGION_SIZE.x - 1,
		offset.y, offset.y + REGION_SIZE.y - 1
	]
