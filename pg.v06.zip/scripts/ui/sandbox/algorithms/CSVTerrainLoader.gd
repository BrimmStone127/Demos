class_name CSVTerrainLoader
extends RefCounted

# Pure algorithm class for loading terrain data from CSV files
# Supports USGS elevation data with downsampling and chunking
# Extracted from Sandbox.gd for modularity and testing

signal progress_updated(percent: float, message: String)

const MAX_LAYERS := 8

func load_csv(path: String, downsample: int = 1, chunk_params: Dictionary = {}) -> Dictionary:
	"""
	Load elevation data from CSV file with optional downsampling and chunking.

	Args:
		path: File path (supports res://, user://, and absolute paths)
		downsample: Downsample factor (1 = no downsampling, 2 = every other row/col, etc.)
		chunk_params: Optional chunking parameters:
			- start_x: Starting column (default 0)
			- start_y: Starting row (default 0)
			- chunk_width: Width of chunk (0 = all remaining)
			- chunk_height: Height of chunk (0 = all remaining)

	Returns:
		Dictionary with:
		- success: bool
		- error: String (empty if success)
		- elevation_data: Array[Array] of float values
		- min_elevation: float
		- max_elevation: float
		- rows: int
		- columns: int
	"""
	var start_x = chunk_params.get("start_x", 0)
	var start_y = chunk_params.get("start_y", 0)
	var chunk_width = chunk_params.get("chunk_width", 0)
	var chunk_height = chunk_params.get("chunk_height", 0)

	# Normalize path
	var normalized_path = path.strip_edges()

	# Check if file exists
	if not FileAccess.file_exists(normalized_path):
		var error_msg = "CSV file not found: " + normalized_path
		if normalized_path.begins_with("user://"):
			error_msg += "\nFor user:// paths, place file in: " + OS.get_user_data_dir()
		return {"success": false, "error": error_msg}

	# Open file
	var file = FileAccess.open(normalized_path, FileAccess.READ)
	if not file:
		var error = FileAccess.get_open_error()
		return {"success": false, "error": "Failed to open CSV file (Error: %d)" % error}

	var elevation_data: Array[Array] = []
	var csv_row_index = 0
	var loaded_row_index = 0

	# Calculate end bounds for chunking
	var end_y = start_y + chunk_height if chunk_height > 0 else 999999
	var end_x = start_x + chunk_width if chunk_width > 0 else 999999

	# Read CSV line by line with downsampling and chunking
	while not file.eof_reached():
		var line = file.get_line().strip_edges()

		# Skip rows before start_y
		if csv_row_index < start_y:
			csv_row_index += 1
			continue

		# Stop if we've reached end_y
		if csv_row_index >= end_y:
			break

		# Skip rows based on downsample factor
		if downsample > 1 and ((csv_row_index - start_y) % downsample != 0):
			csv_row_index += 1
			continue

		if line.is_empty():
			csv_row_index += 1
			continue

		var values = line.split(",")
		var row: Array = []  # Keep as generic array to support floats
		var csv_col_index = 0

		for value_str in values:
			# Skip columns before start_x
			if csv_col_index < start_x:
				csv_col_index += 1
				continue

			# Stop if we've reached end_x
			if csv_col_index >= end_x:
				break

			# Skip columns based on downsample factor
			if downsample > 1 and ((csv_col_index - start_x) % downsample != 0):
				csv_col_index += 1
				continue

			value_str = value_str.strip_edges()
			if value_str.is_empty():
				csv_col_index += 1
				continue

			# Parse elevation value - keep as float for proper normalization
			var elevation: float = 0.0
			if value_str.is_valid_float():
				elevation = float(value_str)
			elif value_str.is_valid_int():
				elevation = float(value_str)

			row.append(elevation)
			csv_col_index += 1

		if not row.is_empty():
			elevation_data.append(row)
			loaded_row_index += 1

		csv_row_index += 1

		# Emit progress every 100 rows
		if loaded_row_index % 100 == 0:
			progress_updated.emit(0.0, "Loading row %d..." % loaded_row_index)

	file.close()

	if elevation_data.is_empty():
		return {"success": false, "error": "No elevation data found in CSV"}

	# Find dimensions
	var csv_rows = elevation_data.size()
	var csv_cols = elevation_data[0].size() if csv_rows > 0 else 0
	var total_cells = csv_rows * csv_cols

	# Check size constraints
	if total_cells > 1000000:  # 1 million cells
		var recommended_downsample = int(ceil(sqrt(float(total_cells) / 250000.0)))
		return {
			"success": false,
			"error": "Map too large! %d cells will crash the engine. Use downsample factor of at least %d" % [total_cells, recommended_downsample]
		}

	# Find min/max elevations for normalization
	var min_elev: float = 999999.0
	var max_elev: float = -999999.0

	for row in elevation_data:
		for elev in row:
			min_elev = min(min_elev, elev)
			max_elev = max(max_elev, elev)

	return {
		"success": true,
		"error": "",
		"elevation_data": elevation_data,
		"min_elevation": min_elev,
		"max_elevation": max_elev,
		"rows": csv_rows,
		"columns": csv_cols
	}

func normalize_to_layers(elevation_data: Array, min_elev: float, max_elev: float, max_layers: int = MAX_LAYERS) -> Dictionary:
	"""
	Normalize raw elevation data to discrete layer system (0 to max_layers-1).

	Args:
		elevation_data: Array[Array] of float elevation values
		min_elev: Minimum elevation value
		max_elev: Maximum elevation value
		max_layers: Number of elevation layers (default 8)

	Returns:
		Dictionary mapping Vector2i(x,y) to int layer (0 to max_layers-1)
	"""
	var elevation_map: Dictionary = {}
	var elev_range = max(0.000001, max_elev - min_elev)  # Avoid division by zero

	var rows = elevation_data.size()
	for y in range(rows):
		var row = elevation_data[y]
		var cols = row.size()
		for x in range(cols):
			var raw_elev = row[x]
			# Normalize to 0-(max_layers-1) range for discrete layer system
			var normalized = int((raw_elev - min_elev) / elev_range * float(max_layers - 1))
			normalized = clampi(normalized, 0, max_layers - 1)
			elevation_map[Vector2i(x, y)] = normalized

	return elevation_map
