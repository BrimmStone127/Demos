class_name PNGTerrainLoader
extends RefCounted

## Simple PNG heightmap loader - drop-in replacement for StLouisTerrainLoader
## Loads 16-bit or 8-bit grayscale PNG and returns elevation data in identical format

signal progress_updated(percent: float, message: String)

## Load elevation data from a PNG heightmap
##
## Args:
##   png_path: Path to PNG file (res://, user://, or absolute)
##   downsample: Downsample factor (1 = full res, 2 = half, etc.)
##   region: Optional {x, y, width, height} to load a subset
##   skip_remapping: If true, skip automatic percentile remapping (for manual global remapping)
##
## Returns same format as StLouisTerrainLoader.load_csv():
##   {
##     "success": bool,
##     "error": String,
##     "elevation_map": Dictionary {Vector2i(x,y): float(0.0-1.0)},
##     "grid_size": Vector2i(cols, rows),
##     "source_size": Vector2i,
##     "stats": {min, max, avg, percentile_min, percentile_max}
##   }
func load_png(png_path: String, downsample: int = 1, region: Dictionary = {}, skip_remapping: bool = false) -> Dictionary:
	# Load image
	var img = Image.new()
	var err = img.load(png_path)
	if err != OK:
		return _error("Failed to load PNG: %s (error %d)" % [png_path, err])

	var source_width = img.get_width()
	var source_height = img.get_height()

	# Parse region parameters (default: full image)
	var region_x = region.get("x", 0)
	var region_y = region.get("y", 0)
	var region_width = region.get("width", source_width - region_x)
	var region_height = region.get("height", source_height - region_y)

	# Clamp region to image bounds
	region_x = clampi(region_x, 0, source_width - 1)
	region_y = clampi(region_y, 0, source_height - 1)
	region_width = clampi(region_width, 1, source_width - region_x)
	region_height = clampi(region_height, 1, source_height - region_y)

	var ds = maxi(1, downsample)

	var elevation_map: Dictionary = {}
	var stats = {"min": 1.0, "max": 0.0, "sum": 0.0, "count": 0}

	var grid_x = 0
	var grid_y = 0

	# Read pixels row by row (top to bottom, same as CSV)
	for src_y in range(region_y, region_y + region_height, ds):
		grid_x = 0
		for src_x in range(region_x, region_x + region_width, ds):
			# Read pixel directly - no Y flip needed to match CSV behavior
			var pixel = img.get_pixel(src_x, src_y)

			# Grayscale: R=G=B, use red channel (0.0-1.0)
			var elevation = pixel.r

			elevation_map[Vector2i(grid_x, grid_y)] = elevation

			stats.min = minf(stats.min, elevation)
			stats.max = maxf(stats.max, elevation)
			stats.sum += elevation
			stats.count += 1

			grid_x += 1

		grid_y += 1

		if grid_y % 100 == 0:
			emit_signal("progress_updated", float(grid_y) / (region_height / ds), "Row %d..." % grid_y)

	if elevation_map.is_empty():
		return _error("No elevation data loaded")

	var grid_width = grid_x
	var grid_height = grid_y

	stats["avg"] = stats.sum / float(stats.count) if stats.count > 0 else 0.0

	# Calculate percentiles for smart remapping
	var elevations_sorted = elevation_map.values().duplicate()
	elevations_sorted.sort()

	var p10_idx = int(elevations_sorted.size() * PlanetMapTileConfig.ELEVATION_PERCENTILE_MIN)
	var p95_idx = int(elevations_sorted.size() * PlanetMapTileConfig.ELEVATION_PERCENTILE_MAX)
	stats["percentile_min"] = elevations_sorted[p10_idx] if p10_idx < elevations_sorted.size() else stats.min
	stats["percentile_max"] = elevations_sorted[p95_idx] if p95_idx < elevations_sorted.size() else stats.max

	# Apply remapping if enabled (unless explicitly skipped for manual global remapping)
	if PlanetMapTileConfig.ELEVATION_REMAP_ENABLED and not skip_remapping:
		var remap_min = stats.percentile_min
		var remap_max = stats.percentile_max
		for pos in elevation_map.keys():
			var old_elev = elevation_map[pos]
			elevation_map[pos] = PlanetMapTileConfig.remap_elevation(old_elev, remap_min, remap_max)

	return {
		"success": true,
		"error": "",
		"elevation_map": elevation_map,
		"grid_size": Vector2i(grid_width, grid_height),
		"source_size": Vector2i(source_width, source_height),
		"stats": stats
	}


func _error(msg: String) -> Dictionary:
	push_error("[PNGLoader] " + msg)
	return {
		"success": false,
		"error": msg,
		"elevation_map": {},
		"grid_size": Vector2i.ZERO,
		"source_size": Vector2i.ZERO,
		"stats": {}
	}
