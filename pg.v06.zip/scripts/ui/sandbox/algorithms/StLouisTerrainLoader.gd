class_name StLouisTerrainLoader
extends RefCounted

## Flexible loader for St. Louis USGS elevation data (3612x3612)
## NO ARTIFICIAL LIMITS - supports any target resolution
## Let's find out what Godot can actually handle!

signal progress_updated(percent: float, message: String)

const MAX_LAYERS := 8  # Elevation layers 0-7

## Load St. Louis CSV with flexible resolution
##
## Args:
##   csv_path: Path to CSV file
##   downsample: Downsample factor (1 = full res, 2 = half, 4 = quarter, etc.)
##               Use 0 or negative for NO downsampling (full 3612x3612!)
##   region: Optional Dictionary for loading a specific region:
##           {x: int, y: int, width: int, height: int}
##           If provided, only loads this chunk of the source data
##
## Returns Dictionary:
##   {
##     "success": bool,
##     "error": String,
##     "elevation_map": Dictionary {Vector2i(x,y): float(0.0-1.0)},  # PRECISE FLOAT!
##     "grid_size": Vector2i(cols, rows),
##     "source_size": Vector2i(source_cols, source_rows),
##     "stats": Dictionary {min, max, avg}
##   }
func load_csv(csv_path: String, downsample: int = 1, region: Dictionary = {}) -> Dictionary:

	# Validate file exists
	if not FileAccess.file_exists(csv_path):
		return _error("CSV file not found: %s" % csv_path)

	# Open file
	var file = FileAccess.open(csv_path, FileAccess.READ)
	if not file:
		return _error("Failed to open CSV: Error %d" % FileAccess.get_open_error())

	# Parse region parameters
	var region_x = region.get("x", 0)
	var region_y = region.get("y", 0)
	var region_width = region.get("width", 0)  # 0 = all
	var region_height = region.get("height", 0)  # 0 = all

	# Determine actual downsample (1 = no downsample)
	var ds = maxi(1, downsample)

	var elevation_map: Dictionary = {}
	var stats = {
		"min": 1.0,
		"max": 0.0,
		"sum": 0.0,
		"count": 0
	}

	var source_row_idx = 0
	var loaded_rows = 0
	var grid_y = 0
	var source_cols = 0

	# Read CSV line by line
	while not file.eof_reached():
		var line = file.get_line().strip_edges()

		# Skip empty lines
		if line.is_empty():
			source_row_idx += 1
			continue

		# Check if this row is in our region (if specified)
		if region_height > 0:
			if source_row_idx < region_y:
				source_row_idx += 1
				continue
			if source_row_idx >= region_y + region_height:
				break

		# Apply downsampling (skip rows not at downsample intervals)
		var relative_row = source_row_idx - region_y
		if ds > 1 and (relative_row % ds) != 0:
			source_row_idx += 1
			continue

		# Parse row
		var values = line.split(",")
		if source_cols == 0:
			source_cols = values.size()

		# Process columns
		var grid_x = 0
		for col_idx in range(values.size()):
			# Check if this column is in our region
			if region_width > 0:
				if col_idx < region_x:
					continue
				if col_idx >= region_x + region_width:
					break

			# Apply downsampling (skip columns not at downsample intervals)
			var relative_col = col_idx - region_x
			if ds > 1 and (relative_col % ds) != 0:
				continue

			# Parse elevation value (0.0-1.0)
			var val_str = values[col_idx].strip_edges()
			if val_str.is_empty():
				grid_x += 1
				continue

			var elevation = float(val_str)

			# Store PRECISE float elevation (0.0-1.0)
			# Quantization to layers happens at render time only!
			elevation_map[Vector2i(grid_x, grid_y)] = elevation

			# Update stats
			stats.min = minf(stats.min, elevation)
			stats.max = maxf(stats.max, elevation)
			stats.sum += elevation
			stats.count += 1

			grid_x += 1

		loaded_rows += 1
		grid_y += 1
		source_row_idx += 1

		# Progress update every 50 rows
		if loaded_rows % 50 == 0:
			emit_signal("progress_updated", 0.0, "Loaded %d rows..." % loaded_rows)

	file.close()

	if elevation_map.is_empty():
		return _error("No elevation data loaded")

	# Calculate final grid size
	var grid_width = 0
	var grid_height = grid_y
	for pos in elevation_map.keys():
		grid_width = maxi(grid_width, pos.x + 1)

	stats["avg"] = stats.sum / float(stats.count) if stats.count > 0 else 0.0

	# Calculate percentiles for smart remapping
	var elevations_sorted = []
	for elev in elevation_map.values():
		elevations_sorted.append(elev)
	elevations_sorted.sort()

	var p10_idx = int(elevations_sorted.size() * PlanetMapTileConfig.ELEVATION_PERCENTILE_MIN)
	var p95_idx = int(elevations_sorted.size() * PlanetMapTileConfig.ELEVATION_PERCENTILE_MAX)
	stats["percentile_min"] = elevations_sorted[p10_idx] if p10_idx < elevations_sorted.size() else stats.min
	stats["percentile_max"] = elevations_sorted[p95_idx] if p95_idx < elevations_sorted.size() else stats.max

	# Apply remapping to focus on interesting elevation range
	if PlanetMapTileConfig.ELEVATION_REMAP_ENABLED:
		var remap_min = stats.percentile_min
		var remap_max = stats.percentile_max
		for pos in elevation_map.keys():
			var old_elev = elevation_map[pos]
			elevation_map[pos] = PlanetMapTileConfig.remap_elevation(old_elev, remap_min, remap_max)

	return {
		"success": true,
		"error": "",
		"elevation_map": elevation_map,
		"grid_size": Vector2i(grid_width, grid_height),
		"source_size": Vector2i(source_cols, source_row_idx),
		"stats": stats
	}

## Helper: Create error result
func _error(message: String) -> Dictionary:
	return {
		"success": false,
		"error": message,
		"elevation_map": {},
		"grid_size": Vector2i(0, 0),
		"source_size": Vector2i(0, 0),
		"stats": {}
	}
