class_name ElevationGenerator
extends RefCounted

# Pure algorithm class for generating elevation maps
# Extracted from Sandbox.gd for modularity and testing

# Elevation pattern types (matches SandboxConfig.ElevationPattern)
enum Pattern {
	FLAT,       # All tiles at layer 0
	RANDOM,     # Random elevation per tile
	NOISE,      # Perlin-like noise terrain
	HILLS,      # Smooth rolling hills
	MOUNTAIN,   # Peak in center
	CRATER,     # Depression in center
	ISLAND,     # High center with low edges
	RIDGES      # Mountain ridge patterns
}

var _rng: RandomNumberGenerator

func _init(p_seed: int = 0):
	_rng = RandomNumberGenerator.new()
	if p_seed > 0:
		_rng.seed = p_seed
	else:
		_rng.randomize()

func generate_elevation_map(columns: int, rows: int, pattern: Pattern, max_height: int) -> Dictionary:
	"""
	Generate an elevation map for a grid.

	Args:
		columns: Number of columns in the grid
		rows: Number of rows in the grid
		pattern: Elevation pattern to use
		max_height: Maximum elevation (0-7 for 8 layers)

	Returns:
		Dictionary mapping Vector2i(x,y) to int elevation (0 to max_height)
	"""
	var elevation_map: Dictionary = {}  # {Vector2i(x,y): int elevation}

	for x in range(columns):
		for y in range(rows):
			var cell := Vector2i(x, y)
			var elevation := _calculate_elevation_for_cell(cell, columns, rows, pattern, max_height)
			elevation_map[cell] = elevation

	return elevation_map

func _calculate_elevation_for_cell(cell: Vector2i, columns: int, rows: int, pattern: Pattern, max_height: int) -> int:
	"""Calculate elevation for a single cell based on pattern type."""
	var elevation: int = 0

	# Normalized coordinates (0.0 to 1.0)
	var nx: float = float(cell.x) / float(max(columns - 1, 1))
	var ny: float = float(cell.y) / float(max(rows - 1, 1))

	# Centered coordinates (-0.5 to 0.5)
	var cx: float = nx - 0.5
	var cy: float = ny - 0.5

	match pattern:
		Pattern.FLAT:
			elevation = 0

		Pattern.RANDOM:
			elevation = _rng.randi_range(0, max_height)

		Pattern.NOISE:
			# Perlin-like noise using sine waves at multiple frequencies
			var noise_value: float = 0.0
			noise_value += sin(nx * PI * 4.0 + ny * PI * 3.0) * 0.5
			noise_value += sin(nx * PI * 8.0 - ny * PI * 6.0) * 0.25
			noise_value += sin(nx * PI * 16.0 + ny * PI * 12.0) * 0.125
			noise_value = (noise_value + 0.875) / 1.75  # Normalize to 0-1
			elevation = int(noise_value * float(max_height))

		Pattern.HILLS:
			# Smooth rolling hills
			var hill_value: float = sin(nx * PI * 3.0) * cos(ny * PI * 2.5)
			hill_value = (hill_value + 1.0) * 0.5  # Normalize to 0-1
			elevation = int(hill_value * float(max_height))

		Pattern.MOUNTAIN:
			# Peak in center, falls off with distance
			var dist: float = sqrt(cx * cx + cy * cy)
			var mountain_value: float = 1.0 - (dist / 0.707)  # 0.707 is max dist to corner
			mountain_value = clamp(mountain_value, 0.0, 1.0)
			elevation = int(mountain_value * float(max_height))

		Pattern.CRATER:
			# Depression in center
			var dist: float = sqrt(cx * cx + cy * cy)
			var crater_value: float = dist / 0.707
			crater_value = clamp(crater_value, 0.0, 1.0)
			elevation = int(crater_value * float(max_height))

		Pattern.ISLAND:
			# High center with low edges (more dramatic than mountain)
			var dist: float = sqrt(cx * cx + cy * cy)
			var island_value: float = 1.0 - (dist / 0.5)  # Falls off faster
			island_value = clamp(island_value, 0.0, 1.0)
			island_value = pow(island_value, 1.5)  # Make it steeper
			elevation = int(island_value * float(max_height))

		Pattern.RIDGES:
			# Mountain ridges using absolute sine waves
			var ridge_value: float = abs(sin(nx * PI * 6.0 + ny * PI * 2.0))
			ridge_value = pow(ridge_value, 0.7)  # Make ridges sharper
			elevation = int(ridge_value * float(max_height))

	return clampi(elevation, 0, max_height)
