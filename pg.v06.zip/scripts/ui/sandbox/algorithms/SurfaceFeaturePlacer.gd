class_name SurfaceFeaturePlacer
extends RefCounted

# Pure algorithm class for placing surface features (trees, vegetation) on maps
# Extracted from Sandbox.gd for modularity and testing

const DEFAULT_TREE_DENSITY := 0.08  # 8% of eligible tiles

# Tile types that can support trees
const GRASS_TILES := [
	PlanetMapTileConfig.TileType.GRASS_0,
	PlanetMapTileConfig.TileType.GRASS_1,
	PlanetMapTileConfig.TileType.GRASS_2
]

# Available tree species
const TREE_SPECIES := [
	PlanetMapTileConfig.TileType.SF_TREE_1,
	PlanetMapTileConfig.TileType.SF_TREE_2,
	PlanetMapTileConfig.TileType.SF_TREE_3
]

var _rng: RandomNumberGenerator

func _init(p_seed: int = 0):
	_rng = RandomNumberGenerator.new()
	if p_seed > 0:
		_rng.seed = p_seed
	else:
		_rng.randomize()

func place_trees_on_tiles(tiles: Dictionary, density: float = DEFAULT_TREE_DENSITY, species_list: Array[int] = []) -> Array[Dictionary]:
	"""
	Place trees on eligible tiles.

	Args:
		tiles: Dictionary mapping Vector2i -> MapTile
		density: Probability (0.0-1.0) of placing a tree on each eligible tile
		species_list: Array of tree species to use (defaults to all 3 species)

	Returns:
		Array of Dictionaries with:
		- position: Vector2i
		- species: int (TileType enum value)
		- elevation: int (from tile)
	"""
	if species_list.is_empty():
		species_list = TREE_SPECIES.duplicate()

	var placed_trees: Array[Dictionary] = []

	for pos in tiles:
		var tile: MapTile = tiles[pos]

		# Only place on grass tiles
		if tile.type not in GRASS_TILES:
			continue

		# Random chance based on density
		if _rng.randf() < density:
			var species = species_list[_rng.randi_range(0, species_list.size() - 1)]

			placed_trees.append({
				"position": pos,
				"species": species,
				"elevation": tile.elevation
			})

	return placed_trees

func place_trees_simple(columns: int, rows: int, density: float = DEFAULT_TREE_DENSITY) -> Array[Dictionary]:
	"""
	Simplified version: Place trees on a grid without tile data.
	Useful for quick generation.

	Args:
		columns: Map width
		rows: Map height
		density: Probability of placing a tree at each position

	Returns:
		Array of Dictionaries with:
		- position: Vector2i
		- species: int (randomly chosen from TREE_SPECIES)
	"""
	var placed_trees: Array[Dictionary] = []

	for x in range(columns):
		for y in range(rows):
			if _rng.randf() < density:
				var species = TREE_SPECIES[_rng.randi_range(0, TREE_SPECIES.size() - 1)]

				placed_trees.append({
					"position": Vector2i(x, y),
					"species": species
				})

	return placed_trees
