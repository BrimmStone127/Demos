extends RefCounted
class_name SandboxScenarioManager

## Manages scenario loading and state export for the Sandbox
## Provides programmatic API for automated testing and presets
## Extracted from Sandbox.gd for better code organization

const LOG_TAG := "SANDBOX_SCENARIO"

# Predefined scenarios
const SCENARIOS = {
	"tropical": {
		"planet_type": 2, "geological_activity": 2, "climate": 3, "atmosphere": 3,
		"water": 65, "ice": 0, "lava": 0, "seed": 12345
	},
	"frozen": {
		"planet_type": 1, "geological_activity": 0, "climate": 0, "atmosphere": 1,
		"water": 5, "ice": 80, "lava": 0, "seed": 54321
	},
	"desert": {
		"planet_type": 0, "geological_activity": 1, "climate": 4, "atmosphere": 1,
		"water": 2, "ice": 0, "lava": 0, "seed": 99999
	},
	"ocean": {
		"planet_type": 2, "geological_activity": 2, "climate": 2, "atmosphere": 2,
		"water": 95, "ice": 3, "lava": 0, "seed": 77777
	},
	"volcanic": {
		"planet_type": 1, "geological_activity": 4, "climate": 4, "atmosphere": 3,
		"water": 10, "ice": 0, "lava": 25, "seed": 66666
	},
	"earthlike": {
		"planet_type": 1, "geological_activity": 2, "climate": 2, "atmosphere": 2,
		"water": 71, "ice": 3, "lava": 0, "seed": 11111
	},
	"icegiant": {
		"planet_type": 3, "geological_activity": 0, "climate": 0, "atmosphere": 3,
		"water": 0, "ice": 95, "lava": 0, "seed": 33333
	}
}

## Get list of available scenario names
static func get_available_scenarios() -> Array[String]:
	var scenarios: Array[String] = []
	scenarios.append_array(SCENARIOS.keys())
	return scenarios

## Load a predefined scenario by name
## Returns the scenario config dictionary if found, empty dictionary if not found
func load_scenario(scenario_name: String) -> Dictionary:
	if not SCENARIOS.has(scenario_name):
		_log_error("Unknown scenario: %s", [scenario_name])
		return {}

	_log_info("Loading scenario: %s", [scenario_name])
	return SCENARIOS[scenario_name]

## Apply scenario configuration to UI controls
## config: Dictionary with keys planet_type, geological_activity, climate, atmosphere, water, ice, lava, seed
## ui_refs: Dictionary containing UI control references
func apply_scenario_config(config: Dictionary, ui_refs: Dictionary) -> bool:
	if config.is_empty():
		_log_error("Cannot apply empty config")
		return false

	var planet_type_option = ui_refs.get("planet_type_option")
	var geological_activity_option = ui_refs.get("geological_activity_option")
	var climate_type_option = ui_refs.get("climate_type_option")
	var atmosphere_type_option = ui_refs.get("atmosphere_type_option")
	var water_slider = ui_refs.get("water_slider")
	var ice_slider = ui_refs.get("ice_slider")
	var lava_slider = ui_refs.get("lava_slider")
	var planet_seed_spin = ui_refs.get("planet_seed_spin")

	if not planet_type_option:
		_log_error("UI controls not provided - cannot apply scenario config")
		return false

	# Apply each config value
	if config.has("planet_type") and planet_type_option:
		planet_type_option.selected = config.planet_type
	if config.has("geological_activity") and geological_activity_option:
		geological_activity_option.selected = config.geological_activity
	if config.has("climate") and climate_type_option:
		climate_type_option.selected = config.climate
	if config.has("atmosphere") and atmosphere_type_option:
		atmosphere_type_option.selected = config.atmosphere
	if config.has("water") and water_slider:
		water_slider.value = config.water
	if config.has("ice") and ice_slider:
		ice_slider.value = config.ice
	if config.has("lava") and lava_slider:
		lava_slider.value = config.lava
	if config.has("seed") and planet_seed_spin:
		planet_seed_spin.value = config.seed

	_log_info("Scenario config applied")
	return true

## Get current scenario configuration from UI controls
## ui_refs: Dictionary containing UI control references
## Returns Dictionary with all current UI values
func get_scenario_config(ui_refs: Dictionary) -> Dictionary:
	var planet_type_option = ui_refs.get("planet_type_option")
	var geological_activity_option = ui_refs.get("geological_activity_option")
	var climate_type_option = ui_refs.get("climate_type_option")
	var atmosphere_type_option = ui_refs.get("atmosphere_type_option")
	var water_slider = ui_refs.get("water_slider")
	var ice_slider = ui_refs.get("ice_slider")
	var lava_slider = ui_refs.get("lava_slider")
	var planet_seed_spin = ui_refs.get("planet_seed_spin")

	if not planet_type_option:
		_log_error("UI controls not provided")
		return {}

	return {
		"planet_type": planet_type_option.selected if planet_type_option else 0,
		"geological_activity": geological_activity_option.selected if geological_activity_option else 0,
		"climate": climate_type_option.selected if climate_type_option else 0,
		"atmosphere": atmosphere_type_option.selected if atmosphere_type_option else 0,
		"water": int(water_slider.value) if water_slider else 0,
		"ice": int(ice_slider.value) if ice_slider else 0,
		"lava": int(lava_slider.value) if lava_slider else 0,
		"seed": int(planet_seed_spin.value) if planet_seed_spin else 0
	}

## Export current state as JSON-compatible dictionary
## Includes configuration, statistics, and metadata
func export_state(
	ui_refs: Dictionary,
	tile_types_by_cell: Dictionary,
	map_columns: int,
	map_rows: int
) -> Dictionary:
	var stats = collect_tile_statistics(tile_types_by_cell)

	return {
		"config": get_scenario_config(ui_refs),
		"timestamp": Time.get_datetime_string_from_system(),
		"statistics": stats,
		"map_size": {
			"columns": map_columns,
			"rows": map_rows
		}
	}

## Collect statistics about current tile distribution
func collect_tile_statistics(tile_types_by_cell: Dictionary) -> Dictionary:
	var stats = {
		"total_tiles": 0,
		"tiles_by_type": {},
		"tiles_by_layer": {},
		"unique_types": 0,
		"layers_used": 0
	}

	if tile_types_by_cell.size() == 0:
		return stats

	var type_set = {}
	var layer_set = {}

	for cell_3d in tile_types_by_cell.keys():
		if not (cell_3d is Vector3i):
			continue

		var tile_type = tile_types_by_cell[cell_3d]
		var layer = cell_3d.z

		stats.total_tiles += 1

		# Count by type
		if not stats.tiles_by_type.has(tile_type):
			stats.tiles_by_type[tile_type] = 0
		stats.tiles_by_type[tile_type] += 1
		type_set[tile_type] = true

		# Count by layer
		if not stats.tiles_by_layer.has(layer):
			stats.tiles_by_layer[layer] = 0
		stats.tiles_by_layer[layer] += 1
		layer_set[layer] = true

	stats.unique_types = type_set.size()
	stats.layers_used = layer_set.size()

	return stats

# ============================================================================
# LOGGING
# ============================================================================

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, message % values if values.size() > 0 else message)

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, message % values if values.size() > 0 else message)
