class_name ToolSelector
extends HBoxContainer

# Tool mode selection buttons for map painting

signal tool_changed(tool_mode: SandboxConfig.ToolMode)

var _buttons: Dictionary = {}  # ToolMode -> Button
var _button_group: ButtonGroup

func _ready():
	_build_ui()

func _build_ui() -> void:
	add_theme_constant_override("separation", 4)

	_button_group = ButtonGroup.new()

	# Create button for each tool mode
	_add_tool_button(SandboxConfig.ToolMode.PLACE, "Place", "Click to place tiles")
	_add_tool_button(SandboxConfig.ToolMode.ERASE, "Erase", "Click to erase tiles")
	_add_tool_button(SandboxConfig.ToolMode.PICKER, "Picker", "Ctrl+Click to pick tile")
	_add_tool_button(SandboxConfig.ToolMode.BRUSH, "Brush", "Alt+Drag to paint")
	_add_tool_button(SandboxConfig.ToolMode.FILL, "Fill", "Shift+Click to flood fill")

	# Select PLACE by default
	if _buttons.has(SandboxConfig.ToolMode.PLACE):
		_buttons[SandboxConfig.ToolMode.PLACE].button_pressed = true

func _add_tool_button(mode: SandboxConfig.ToolMode, text: String, tooltip: String) -> void:
	var button = Button.new()
	button.text = text
	button.tooltip_text = tooltip
	button.toggle_mode = true
	button.button_group = _button_group
	button.pressed.connect(func(): _on_tool_selected(mode))

	add_child(button)
	_buttons[mode] = button

	# Apply terminal theme
	TerminalTheme.apply_to_button(button)

func _on_tool_selected(mode: SandboxConfig.ToolMode) -> void:
	tool_changed.emit(mode)

func set_current_tool(mode: SandboxConfig.ToolMode) -> void:
	"""Programmatically set the current tool."""
	if _buttons.has(mode):
		_buttons[mode].button_pressed = true
