class_name TilePalette
extends VBoxContainer

# Visual grid of tile previews with search and filter
# Displays all available tiles with their sprites and names
# Supports loading from TileAliasManager to show all 200 tiles with custom aliases

signal selection_changed(selected_types: Array[int])
signal tile_clicked(tile_id: int)  # Now emits tile ID instead of enum value

var selectable: bool = true  # Allow multi-select with checkboxes
var columns: int = 8  # Grid columns
var use_alias_manager: bool = false  # If true, load from alias manager instead of enum
var alias_manager: TileAliasManager = null  # Optional alias manager reference

var _search_field: LineEdit
var _category_filter: OptionButton
var _scroll_container: ScrollContainer
var _grid_container: GridContainer
var _select_all_button: Button
var _clear_button: Button

var _tile_previews: Array[TilePreview] = []
var _current_filter_category: SandboxConfig.TileCategory = SandboxConfig.TileCategory.ALL
var _current_search_text: String = ""

func _ready():
	_build_ui()
	_populate_tiles()

func _build_ui() -> void:
	# Use full available space
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL

	# Top controls: search, filter, buttons (wrap to multiple rows if needed)
	var controls_margin = MarginContainer.new()
	controls_margin.add_theme_constant_override("margin_left", 8)
	controls_margin.add_theme_constant_override("margin_top", 8)
	controls_margin.add_theme_constant_override("margin_right", 8)
	controls_margin.add_theme_constant_override("margin_bottom", 8)
	add_child(controls_margin)

	var controls_vbox = VBoxContainer.new()
	controls_vbox.add_theme_constant_override("separation", 6)
	controls_margin.add_child(controls_vbox)

	# First row: search and category
	var row1 = HBoxContainer.new()
	row1.add_theme_constant_override("separation", 8)
	controls_vbox.add_child(row1)

	var search_label = Label.new()
	search_label.text = "Search:"
	row1.add_child(search_label)

	_search_field = LineEdit.new()
	_search_field.placeholder_text = "Filter by name..."
	_search_field.custom_minimum_size.x = 200
	_search_field.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_search_field.text_changed.connect(_on_search_changed)
	row1.add_child(_search_field)

	var filter_label = Label.new()
	filter_label.text = "Category:"
	row1.add_child(filter_label)

	_category_filter = OptionButton.new()
	_category_filter.custom_minimum_size.x = 150
	for category in SandboxConfig.TileCategory.values():
		_category_filter.add_item(SandboxConfig.get_category_name(category), category)
	_category_filter.item_selected.connect(_on_category_selected)
	# Apply terminal theme to OptionButton
	_category_filter.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	_category_filter.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	row1.add_child(_category_filter)

	# Second row: buttons (only show if selectable)
	if selectable:
		var row2 = HBoxContainer.new()
		row2.add_theme_constant_override("separation", 8)
		controls_vbox.add_child(row2)

		_select_all_button = Button.new()
		_select_all_button.text = "Select All"
		_select_all_button.pressed.connect(_on_select_all_pressed)
		row2.add_child(_select_all_button)

		_clear_button = Button.new()
		_clear_button.text = "Clear"
		_clear_button.pressed.connect(_on_clear_pressed)
		row2.add_child(_clear_button)

		var spacer = Control.new()
		spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row2.add_child(spacer)

	# Scroll container with grid (takes remaining space)
	_scroll_container = ScrollContainer.new()
	_scroll_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	add_child(_scroll_container)

	_grid_container = GridContainer.new()
	_grid_container.columns = columns
	_grid_container.add_theme_constant_override("h_separation", 4)
	_grid_container.add_theme_constant_override("v_separation", 4)
	_grid_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll_container.add_child(_grid_container)

func _populate_tiles() -> void:
	"""Create TilePreview for all tile types."""
	_clear_grid()

	if use_alias_manager and alias_manager:
		# Load all 200 tiles from alias manager
		var all_tiles = alias_manager.get_all_tiles()

		for tile_data in all_tiles:
			var preview = TilePreview.new()
			preview.setup_from_alias(tile_data, selectable)
			preview.clicked.connect(_on_tile_clicked)
			preview.toggled.connect(_on_tile_toggled)

			_grid_container.add_child(preview)
			_tile_previews.append(preview)

	else:
		# Legacy: Load from enum (old behavior)
		var tile_types: Array[int] = []
		for tile_type in PlanetMapTileConfig.TileType.values():
			tile_types.append(tile_type)

		tile_types.sort()

		for tile_type in tile_types:
			var preview = TilePreview.new()
			preview.setup(tile_type, selectable)
			preview.clicked.connect(_on_tile_clicked)
			preview.toggled.connect(_on_tile_toggled)

			_grid_container.add_child(preview)
			_tile_previews.append(preview)

	_apply_filters()

func _clear_grid() -> void:
	"""Remove all tile previews."""
	for preview in _tile_previews:
		preview.queue_free()
	_tile_previews.clear()

func _apply_filters() -> void:
	"""Show/hide tiles based on current search and category filter."""
	for preview in _tile_previews:
		var should_show = _should_show_tile(preview.tile_id, preview.tile_name, preview.tile_category)
		preview.visible = should_show

func _should_show_tile(tile_id: int, tile_name: String, _tile_category: String) -> bool:
	"""Check if a tile matches current filters."""
	# Category filter (only for legacy enum-based mode)
	if not use_alias_manager and _current_filter_category != SandboxConfig.TileCategory.ALL:
		var enum_category = SandboxConfig.get_tile_category(tile_id)
		if enum_category != _current_filter_category:
			return false

	# Search filter
	if _current_search_text.length() > 0:
		if not tile_name.to_lower().contains(_current_search_text.to_lower()):
			return false

	return true

func refresh_tile_names() -> void:
	"""Refresh tile names from alias manager (after alias changes)."""
	if not use_alias_manager or not alias_manager:
		return

	for preview in _tile_previews:
		if preview.tile_alias_data:
			preview.update_from_alias(preview.tile_alias_data)

func _on_search_changed(text: String) -> void:
	_current_search_text = text
	_apply_filters()

func _on_category_selected(index: int) -> void:
	_current_filter_category = _category_filter.get_item_id(index) as SandboxConfig.TileCategory
	_apply_filters()

func _on_tile_clicked(tile_type: int) -> void:
	tile_clicked.emit(tile_type)

func _on_tile_toggled(_tile_type: int, _selected: bool) -> void:
	_emit_selection_changed()

func _on_select_all_pressed() -> void:
	for preview in _tile_previews:
		if preview.visible:
			preview.set_selected(true)
	_emit_selection_changed()

func _on_clear_pressed() -> void:
	for preview in _tile_previews:
		preview.set_selected(false)
	_emit_selection_changed()

func _emit_selection_changed() -> void:
	var selected_types: Array[int] = []
	for preview in _tile_previews:
		if preview.selected:
			selected_types.append(preview.tile_type)
	selection_changed.emit(selected_types)

func get_selected_tiles() -> Array[int]:
	"""Get list of currently selected tile types."""
	var selected: Array[int] = []
	for preview in _tile_previews:
		if preview.selected:
			selected.append(preview.tile_type)
	return selected

func set_selected_tiles(types: Array[int]) -> void:
	"""Programmatically set which tiles are selected."""
	for preview in _tile_previews:
		preview.set_selected(preview.tile_type in types)

func select_tile(tile_type: int) -> void:
	"""Select a single tile (convenience method for picker tool)."""
	set_selected_tiles([tile_type])
