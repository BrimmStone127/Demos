class_name MapViewport
extends SubViewportContainer

# MapViewport - Sandbox map rendering component
#
# Architecture: Wrapper around PlanetMapSystem (production rendering code)
# - Reuses: PlanetMapTileManager (multi-layer TileMaps)
#           PlanetMapSelection (coordinate conversion, tile picking)
#           PlanetMapCamera (zoom, pan controls)
# - Adds: Painting state tracking, brush tool (Alt+drag), tile_dragged signal
#
# This ensures sandbox uses the same rendering as planet maps in-game.

signal tile_clicked(position: Vector2i, button_index: int)
signal tile_dragged(position: Vector2i)  # For brush tool

var _viewport: SubViewport
var _planet_map_system: PlanetMapSystem = null
var _camera: Camera2D  # Reference to PlanetMapSystem's camera
var _tilemap: TileMap  # Reference to layer 0 for compatibility

# Painting controls
var _is_painting: bool = false
var _last_painted_pos: Vector2i

# Current tiles for elevation rendering
var _current_tiles: Dictionary = {}

func _ready():
	# Disable stretch to allow manual size control of SubViewport
	stretch = false
	_build_viewport()
	_connect_signals()

func _build_viewport() -> void:
	# Create SubViewport
	_viewport = SubViewport.new()
	_viewport.size = size
	_viewport.transparent_bg = false
	_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS

	# Pixel-perfect rendering for isometric tiles
	# Note: Global pixel snapping is disabled to allow smooth vector graphics in system view
	# These settings apply only to this viewport
	# Pixel snapping DISABLED — causes tile shimmer at fractional zoom levels.
	if _viewport.has_method("set_snap_2d_transforms_to_pixel"):
		_viewport.snap_2d_transforms_to_pixel = false
	if _viewport.has_method("set_snap_2d_vertices_to_pixel"):
		_viewport.snap_2d_vertices_to_pixel = false
	if ClassDB.class_has_integer_constant("Viewport", "DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST"):
		_viewport.canvas_item_default_texture_filter = ClassDB.class_get_integer_constant(
			"Viewport", "DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST"
		)

	add_child(_viewport)

	# Create PlanetMapSystem (handles all rendering, camera, selection)
	_planet_map_system = PlanetMapSystem.new()
	_planet_map_system.name = "PlanetMapSystem"
	_viewport.add_child(_planet_map_system)

	# Set viewport reference for selection (needed for coordinate conversion)
	_planet_map_system.map_viewport = _viewport

	# Get references to components for compatibility
	# Note: camera_controller initializes camera in its _ready()
	# We'll get the reference after the scene tree is ready
	call_deferred("_setup_component_references")

	# Connect PlanetMapSystem signals to sandbox signals
	_planet_map_system.tile_selected.connect(_on_planet_tile_selected)

func _setup_component_references() -> void:
	"""Called after scene tree is ready to get component references."""
	if _planet_map_system and _planet_map_system.camera_controller:
		_camera = _planet_map_system.camera_controller.camera
		# Set initial zoom to 1.0 (sandbox default, lower than production's 2.0)
		if _camera:
			_camera.zoom = Vector2(1.0, 1.0)

	if _planet_map_system and _planet_map_system.tile_manager:
		# Get reference to layer 0 tilemap for compatibility
		if _planet_map_system.tile_manager.layer_tilemaps.size() > 0:
			_tilemap = _planet_map_system.tile_manager.layer_tilemaps[0]

func _on_planet_tile_selected(tile: MapTile) -> void:
	"""Translate PlanetMapSystem tile_selected to sandbox tile_clicked signal."""
	if tile:
		tile_clicked.emit(tile.position, MOUSE_BUTTON_LEFT)

func _connect_signals() -> void:
	gui_input.connect(_on_gui_input)
	resized.connect(_on_resized)

func _on_gui_input(event: InputEvent) -> void:
	# Forward camera controls to PlanetMapCamera
	if _planet_map_system and _planet_map_system.camera_controller:
		# Let camera controller handle zoom/pan events
		var handled = _planet_map_system.camera_controller.handle_input_event(event)
		if handled:
			accept_event()
			return

	if event is InputEventMouseButton:
		var mb = event as InputEventMouseButton

		# Tile click/painting with left mouse button
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				# Use PlanetMapSelection for coordinate conversion
				if _planet_map_system and _planet_map_system.selection_manager:
					var result = _planet_map_system.selection_manager.pick_tile_from_viewport_point(mb.position)
					var selected_tile = result.get("tile")
					GameLog.info("MAP_VIEWPORT", "Click at %s -> tile=%s, debug=%s" % [mb.position, selected_tile.position if selected_tile else "null", result.get("debug", {})])
					if selected_tile:
						_is_painting = true
						_last_painted_pos = selected_tile.position
						# Apply selection to show highlight
						_planet_map_system.selection_manager.apply_tile_selection(selected_tile)
						tile_clicked.emit(selected_tile.position, mb.button_index)
				else:
					GameLog.warn("MAP_VIEWPORT", "Click ignored: no planet_map_system or selection_manager")
			else:
				# Stop painting
				_is_painting = false

			accept_event()

	elif event is InputEventMouseMotion:
		var mm = event as InputEventMouseMotion

		if _is_painting and mm.alt_pressed:
			# Brush mode: continuous painting while dragging with Alt held
			# Use PlanetMapSelection for coordinate conversion
			if _planet_map_system and _planet_map_system.selection_manager:
				var result = _planet_map_system.selection_manager.pick_tile_from_viewport_point(mm.position)
				var tile = result.get("tile")
				if tile and tile.position != _last_painted_pos:
					_last_painted_pos = tile.position
					tile_dragged.emit(tile.position)

			accept_event()

func _on_resized() -> void:
	if _viewport:
		_viewport.size = size

# ===== PUBLIC API =====

func get_tilemap() -> TileMap:
	return _tilemap

func get_camera() -> Camera2D:
	return _camera

func center_camera(world_pos: Vector2) -> void:
	if _camera:
		_camera.position = world_pos

func reset_zoom() -> void:
	if _camera:
		_camera.zoom = Vector2(1.0, 1.0)

func connect_time_manager(tm: TimeManager) -> void:
	"""Connect the time manager to the ecosystem for simulation."""
	if not _planet_map_system:
		GameLog.warn("MAP_VIEWPORT", "Cannot connect TimeManager - no PlanetMapSystem")
		return
	if not tm:
		GameLog.warn("MAP_VIEWPORT", "Cannot connect TimeManager - TimeManager is null")
		return

	_planet_map_system.connect_time_manager(tm)
	GameLog.info("MAP_VIEWPORT", "TimeManager connected to PlanetMapSystem (time_scale=%s)" % tm.current_time_scale)

func manually_place_tree(tile_pos: Vector2i, species: int = -1) -> bool:
	"""Manually place a single tree at the specified position.
	Returns true if successful, false if position is invalid."""
	if not _planet_map_system:
		GameLog.warn("MAP_VIEWPORT", "Cannot place tree - no PlanetMapSystem")
		return false

	return _planet_map_system.manually_place_tree(tile_pos, species)

func _setup_ecosystem_from_tiles() -> void:
	"""Extract trees from tiles and register with ecosystem manager."""
	if not _planet_map_system or not _planet_map_system.ecosystem_manager:
		GameLog.warn("MAP_VIEWPORT", "Cannot setup ecosystem - missing planet_map_system or ecosystem_manager")
		return

	# Extract trees from tile surface features
	var trees: Array[TreeInstance] = _planet_map_system._extract_trees_from_tiles(_planet_map_system.map_tiles)


	# Use a simple planet ID for sandbox
	var planet_id = "sandbox_planet"

	# Register with ecosystem (no probe results needed for sandbox)
	var probe_results = {}
	_planet_map_system.ecosystem_manager.register_planet(planet_id, trees, _planet_map_system.map_tiles, probe_results)


func render_tiles(tiles: Dictionary) -> void:
	"""Render tiles using PlanetMapSystem (production rendering code).
	Converts sandbox Dictionary format to 2D array format expected by PlanetMapSystem.
	"""

	# Store tiles for click detection
	_current_tiles = tiles

	if not _planet_map_system or not _planet_map_system.tile_manager:
		return

	# Set planet_id for ecosystem (required for ecosystem tracking)
	if _planet_map_system.planet_id == "":
		_planet_map_system.planet_id = "sandbox_planet"

	# Convert Dictionary to 2D array format
	# Calculate actual map bounds from tiles dictionary (supports any size, not just 64x64)
	var max_x = 0
	var max_y = 0
	for pos in tiles.keys():
		max_x = maxi(max_x, pos.x)
		max_y = maxi(max_y, pos.y)

	var actual_width = max_x + 1
	var actual_height = max_y + 1

	# Create tiles_2d with actual size
	var tiles_2d: Array = []
	for x in range(actual_width):
		var column: Array = []
		for y in range(actual_height):
			var pos = Vector2i(x, y)
			var tile = tiles.get(pos)  # Will be null if no tile at this position
			column.append(tile)
		tiles_2d.append(column)

	# Store in PlanetMapSystem
	_planet_map_system.map_tiles = tiles_2d

	# Use PlanetMapSystem's rendering (reuses production code)
	# _create_tile_visuals() is the method that actually renders tiles
	_planet_map_system._create_tile_visuals()

	# Set up ecosystem from tiles (extract trees and register them)
	# Setup ecosystem from tiles
	_setup_ecosystem_from_tiles()

	# Initialize chunking system (Minecraft-style optimization)
	# Initialize chunking system
	if _planet_map_system.ecosystem_manager:
		var map_center = Vector2i(actual_width >> 1, actual_height >> 1)

		# For sandbox, use small chunk radius for good performance on large CSV maps
		# radius=1 -> 3x3=9 chunks = 36,864 tiles (192x192) simulated at once
		# Good balance: reasonable performance + natural ecosystem spread
		_planet_map_system.ecosystem_manager.set_chunk_radius("sandbox_planet", 1)

		_planet_map_system.ecosystem_manager.update_active_chunks("sandbox_planet", map_center)
		_planet_map_system.ecosystem_manager.rebuild_tree_chunks("sandbox_planet")

	# Update selection manager with new tiles and viewport reference
	if _planet_map_system.selection_manager:
		_planet_map_system.selection_manager.map_tiles = tiles_2d
		var tilemaps = _planet_map_system.tile_manager.get_all_layer_tilemaps()
		_planet_map_system.selection_manager.layer_tilemaps = tilemaps
		_planet_map_system.selection_manager.map_viewport = _viewport

	# Center camera on map center
	if not tiles.is_empty() and _tilemap:
		# Calculate center of the map (actual_width / 2, actual_height / 2)
		var center_tile = Vector2i(actual_width >> 1, actual_height >> 1)
		# Convert to world coordinates using tilemap's map_to_local
		var center_world = _tilemap.map_to_local(center_tile)
		center_camera(center_world)


func _process(_delta):
	# Sync chunks with camera position (Minecraft-style chunking)
	if _planet_map_system and _planet_map_system.ecosystem_manager:
		if _camera:
			_planet_map_system.ecosystem_manager.sync_chunks_with_camera("sandbox_planet", _camera)
