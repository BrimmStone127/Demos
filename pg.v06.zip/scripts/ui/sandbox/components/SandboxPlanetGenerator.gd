extends RefCounted
class_name SandboxPlanetGenerator

## Orchestrates planet and terrain generation for the Sandbox
## Uses algorithm classes (ElevationGenerator, CSVTerrainLoader, SurfaceFeaturePlacer)
## Extracted from Sandbox.gd for better code organization

# Signals
signal generation_started()
signal generation_progress(percent: float, message: String)
signal generation_complete()

# Constants
const MAX_LAYERS = 8
const INVALID_ATLAS_COORDS = Vector2i(-1, -1)
const LOG_TAG := "SANDBOX_GENERATOR"

# Enum for elevation patterns (matches ElevationGenerator)
enum ElevationPattern {
	FLAT,
	RANDOM,
	NOISE,
	HILLS,
	MOUNTAIN,
	CRATER,
	ISLAND,
	RIDGES
}

## Generate elevation map using a pattern
func generate_elevation_map(
	columns: int,
	rows: int,
	pattern: ElevationPattern,
	max_height: int,
	generation_seed: int = 0
) -> Dictionary:
	_log_info("Generating %dx%d elevation map with pattern %s", [columns, rows, ElevationPattern.keys()[pattern]])

	var generator = ElevationGenerator.new(generation_seed)
	var elevation_map = generator.generate_elevation_map(
		columns,
		rows,
		pattern as ElevationGenerator.Pattern,
		max_height
	)

	_log_info("Generated %d elevation values", [elevation_map.size()])
	return elevation_map

## Load CSV terrain data
func load_csv_terrain(
	csv_path: String,
	downsample: int = 1,
	start_x: int = 0,
	start_y: int = 0,
	chunk_width: int = 0,
	chunk_height: int = 0
) -> Dictionary:
	_log_info("Loading CSV terrain from: %s", [csv_path])
	_log_info("Downsample: %d, Region: (%d,%d) size (%d,%d)", [downsample, start_x, start_y, chunk_width, chunk_height])

	var loader = CSVTerrainLoader.new()
	loader.progress_updated.connect(func(percent, msg):
		emit_signal("generation_progress", percent, msg)
	)

	var chunk_params = {
		"start_x": start_x,
		"start_y": start_y,
		"chunk_width": chunk_width,
		"chunk_height": chunk_height
	}

	var result = loader.load_csv(csv_path, downsample, chunk_params)

	if not result.success:
		_log_error("CSV loading failed: %s", [result.error])
		return {}

	_log_info("Loaded %dx%d elevation grid", [result.columns, result.rows])
	_log_info("Elevation range: %.1f to %.1f", [result.min_elevation, result.max_elevation])

	# Convert elevation data to map format (normalize to 0-7 layers)
	return _normalize_elevation_data(result)

## Generate planet map from UI parameters
func generate_planet_map(
	planet_type: int,
	atmosphere_type: int,
	water_pct: float,
	ice_pct: float,
	lava_pct: float,
	geological_activity_idx: int,
	climate_idx: int,
	seed_value: int
) -> Array:
	emit_signal("generation_started")

	# Convert indices to enum names
	var geo_activity_names = ["DEAD", "LOW", "MODERATE", "HIGH", "EXTREME"]
	var climate_names = ["FROZEN", "COLD", "TEMPERATE", "HOT", "SCORCHING", "VARIABLE"]
	var atmo_names = PlanetEnums.AtmosphereType.keys()

	var geo_activity = geo_activity_names[geological_activity_idx]
	var climate = climate_names[climate_idx]
	var atmo_name = atmo_names[atmosphere_type]

	_log_info("=== GENERATING PLANET ===")
	_log_info("Planet Type: %s", [PlanetEnums.PlanetType.keys()[planet_type]])
	_log_info("Geological Activity: %s", [geo_activity])
	_log_info("Climate: %s", [climate])
	_log_info("Atmosphere: %s", [atmo_name])
	_log_info("Surface Liquids - Water: %.1f%%, Ice: %.1f%%, Lava: %.1f%%", [water_pct * 100, ice_pct * 100, lava_pct * 100])
	_log_info("Seed: %d", [seed_value])

	# Create mock planet object
	var mock_planet = create_mock_planet(planet_type, atmosphere_type)

	# Create mock probe data
	var probe_data = {
		"surface_liquids": {
			"water": water_pct,
			"ice": ice_pct,
			"lava": lava_pct
		},
		"surface_composition": generate_surface_composition(planet_type, water_pct, ice_pct),
		"geological_activity": geo_activity,
		"climate_type": climate,
		"atmosphere_type": atmo_name,
		"surface_temperature": calculate_temperature_from_climate(climate),
		"tectonic_plates": calculate_tectonic_plates(geo_activity),
		"magnetosphere": "MODERATE",
		"moons": [],
		"atmosphere_composition": get_atmosphere_composition(atmosphere_type)
	}

	# Generate the map using PlanetMapGenerator
	var generator = PlanetMapGenerator.new()
	var generated_tiles = generator.generate_map(mock_planet, probe_data, seed_value)

	if generated_tiles.is_empty():
		_log_error("Planet map generation failed!")
		emit_signal("generation_complete")
		return []

	_log_info("Planet map generated successfully with %d columns", [generated_tiles.size()])
	emit_signal("generation_complete")

	return generated_tiles

## Create a minimal mock Planet object for generation
func create_mock_planet(planet_type: int, atmo_type: int) -> Planet:
	# We need a texture - just use a placeholder
	var placeholder_texture = PlaceholderTexture2D.new()
	placeholder_texture.size = Vector2(128, 128)

	# Create planet with minimal required parameters
	var props = {
		"colors": [Color.WHITE],
		"scale_range": Vector2(0.5, 0.5)
	}

	var planet = Planet.new(placeholder_texture, 100.0, 0.1, planet_type, props, atmo_type != PlanetEnums.AtmosphereType.NONE)
	planet.planet_type = planet_type
	planet.planet_size = 0.5

	# Set habitability based on atmosphere type
	# Earth-like planets with moderate atmosphere should have high habitability for grass tiles
	if atmo_type == PlanetEnums.AtmosphereType.MODERATE and planet_type == PlanetEnums.PlanetType.ROCKY_MEDIUM:
		planet.habitability_score = 0.8  # High habitability for Earth-like planets
		_log_info("Creating Earth-like planet with high habitability (0.8) for grass tiles")
	else:
		planet.habitability_score = 0.5  # Default moderate habitability

	return planet

## Generate surface composition based on planet type
func generate_surface_composition(planet_type: int, water_pct: float, ice_pct: float) -> Dictionary:
	var composition = {}

	match planet_type:
		PlanetEnums.PlanetType.GAS_GIANT, PlanetEnums.PlanetType.ICE_GIANT, PlanetEnums.PlanetType.SUPER_JUPITER:
			composition["gas"] = 1.0
		_:
			var liquid_total = water_pct + ice_pct
			var rock_pct = max(0.0, 1.0 - liquid_total)
			composition["rock"] = rock_pct
			composition["ice"] = ice_pct
			composition["water"] = water_pct

	return composition

## Convert climate type to approximate temperature in Kelvin
func calculate_temperature_from_climate(climate: String) -> float:
	match climate:
		"FROZEN": return 150.0
		"COLD": return 240.0
		"TEMPERATE": return 288.0
		"HOT": return 350.0
		"SCORCHING": return 500.0
		"VARIABLE": return 270.0
		_: return 273.0

## Calculate number of tectonic plates from activity level
func calculate_tectonic_plates(geo_activity: String) -> int:
	match geo_activity:
		"DEAD": return 0
		"LOW": return randi_range(0, 3)
		"MODERATE": return randi_range(3, 12)
		"HIGH": return randi_range(8, 20)
		"EXTREME": return randi_range(15, 50)
		_: return 5

## Get atmosphere composition preset
func get_atmosphere_composition(atmo_type: int) -> Dictionary:
	return Planet.ATMOSPHERE_PRESETS.get(atmo_type, {}).duplicate()

## Add surface features (trees) to existing terrain
func add_surface_features(
	layer_tilemaps: Array,
	tile_types_by_cell: Dictionary,
	map_columns: int,
	map_rows: int,
	generation_seed: int = 0
) -> int:
	_log_info("Adding surface features with seed %d", [generation_seed])

	var placer = SurfaceFeaturePlacer.new(generation_seed)

	# Count existing grass tiles across all layers
	var grass_positions: Array[Vector2i] = []
	for cell_3d in tile_types_by_cell.keys():
		if not (cell_3d is Vector3i):
			continue
		var tile_type = tile_types_by_cell[cell_3d]
		# Check if it's a grass tile
		if tile_type >= PlanetMapView.TileType.GRASS_0 and tile_type <= PlanetMapView.TileType.GRASS_2:
			grass_positions.append(Vector2i(cell_3d.x, cell_3d.y))

	_log_info("Found %d grass tiles for tree placement", [grass_positions.size()])

	# Place trees on a subset of grass tiles
	var features_placed = 0
	for pos in grass_positions:
		# Place tree with some probability (e.g., 10% chance)
		if randf() < 0.1:
			# Find the layer for this position
			var layer = -1
			for z in range(MAX_LAYERS - 1, -1, -1):
				var check_cell = Vector3i(pos.x, pos.y, z)
				if tile_types_by_cell.has(check_cell):
					layer = z
					break

			if layer >= 0 and layer < layer_tilemaps.size():
				# Place a tree (using placer logic would go here)
				# For now, this is a placeholder
				features_placed += 1

	_log_info("Placed %d surface features", [features_placed])
	return features_placed

# ============================================================================
# PRIVATE: Helper Methods
# ============================================================================

func _normalize_elevation_data(csv_result: Dictionary) -> Dictionary:
	"""Convert CSV elevation data to normalized 0-7 layer format"""
	var elevation_data = csv_result.elevation_data
	var min_elev = csv_result.min_elevation
	var max_elev = csv_result.max_elevation
	var rows = csv_result.rows
	var columns = csv_result.columns

	var normalized_map = {}
	var elevation_range = max_elev - min_elev

	if elevation_range == 0:
		elevation_range = 1.0  # Prevent division by zero

	for y in range(rows):
		for x in range(columns):
			if y < elevation_data.size() and x < elevation_data[y].size():
				var raw_elevation = elevation_data[y][x]
				# Normalize to 0-1, then scale to 0-(MAX_LAYERS-1)
				var normalized = (raw_elevation - min_elev) / elevation_range
				var layer = int(normalized * float(MAX_LAYERS - 1))
				layer = clampi(layer, 0, MAX_LAYERS - 1)
				normalized_map[Vector2i(x, y)] = layer

	return normalized_map

# ============================================================================
# LOGGING
# ============================================================================

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, message % values if values.size() > 0 else message)

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, message % values if values.size() > 0 else message)

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, message % values if values.size() > 0 else message)
