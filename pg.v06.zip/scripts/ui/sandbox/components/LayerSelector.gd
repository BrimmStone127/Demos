class_name LayerSelector
extends HBoxContainer

# Elevation layer selection controls (0-7)
# Supports Q/E keyboard shortcuts

signal layer_changed(layer: int)

var _current_layer: int = 0
var _layer_label: Label
var _dec_button: Button
var _inc_button: Button

func _ready():
	_build_ui()

func _build_ui() -> void:
	add_theme_constant_override("separation", 4)

	# Label
	var label = Label.new()
	label.text = "Layer:"
	TerminalTheme.apply_to_label(label)
	add_child(label)

	# Decrease button
	_dec_button = Button.new()
	_dec_button.text = "Q (-)"
	_dec_button.tooltip_text = "Decrease layer (Q key)"
	_dec_button.pressed.connect(_on_decrease_pressed)
	TerminalTheme.apply_to_button(_dec_button)
	add_child(_dec_button)

	# Current layer label
	_layer_label = Label.new()
	_layer_label.text = "0"
	_layer_label.custom_minimum_size.x = 30
	_layer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	TerminalTheme.apply_to_label(_layer_label)
	add_child(_layer_label)

	# Increase button
	_inc_button = Button.new()
	_inc_button.text = "E (+)"
	_inc_button.tooltip_text = "Increase layer (E key)"
	_inc_button.pressed.connect(_on_increase_pressed)
	TerminalTheme.apply_to_button(_inc_button)
	add_child(_inc_button)

	_update_ui()

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_Q:
			_on_decrease_pressed()
			accept_event()
		elif event.keycode == KEY_E:
			_on_increase_pressed()
			accept_event()

func _on_decrease_pressed() -> void:
	set_current_layer(_current_layer - 1)

func _on_increase_pressed() -> void:
	set_current_layer(_current_layer + 1)

func set_current_layer(layer: int) -> void:
	"""Set the current layer (clamped to 0-7)."""
	var old_layer = _current_layer
	_current_layer = clampi(layer, 0, SandboxConfig.MAX_LAYERS - 1)

	if _current_layer != old_layer:
		_update_ui()
		layer_changed.emit(_current_layer)

func get_current_layer() -> int:
	return _current_layer

func _update_ui() -> void:
	if _layer_label:
		_layer_label.text = str(_current_layer)

	# Disable buttons at limits
	if _dec_button:
		_dec_button.disabled = (_current_layer <= 0)
	if _inc_button:
		_inc_button.disabled = (_current_layer >= SandboxConfig.MAX_LAYERS - 1)
