extends RefCounted
class_name SandboxInputHandler

## Handles all input and tile manipulation in the Sandbox
## Extracted from Sandbox.gd for better code organization

# Signals for component communication
signal tile_placed(cell: Vector2i, layer: int, tile_type: int)
signal tile_erased(cell: Vector2i, layer: int)
signal tile_picked(tile_type: int)
signal layer_changed(new_layer: int)
signal layer_indicator_update_requested()

# References (set via initialize)
var camera_controller = null
var tile_manager = null
var selection_manager = null
var map_viewport: SubViewport = null
var layer_tilemaps: Array = []
var surface_feature_layers: Array = []
var map_columns: int = 64
var map_rows: int = 64
var tile_types_by_cell: Dictionary = {}
var preview_tileset_source_id: int = -1
var rng: RandomNumberGenerator = null

# UI elements
var preview_sprite: Sprite2D = null
var tile_inspector_panel: PanelContainer = null
var hover_highlight: Polygon2D = null
var layer_spin: SpinBox = null

# State variables
var current_layer: int = 0
var selected_tile_type: int = -1
var painting: bool = false
var last_paint_cell: Vector2i = Vector2i(-999, -999)

# Constants
const MAX_LAYERS = 8
const INVALID_ATLAS_COORDS = Vector2i(-1, -1)
const LOG_TAG := "SANDBOX_INPUT"

# Callbacks (set by parent)
var gather_active_tiles_callback: Callable
var default_tiles_callback: Callable
var ensure_layer_tilemap_callback: Callable

## Initialize the input handler with required dependencies
func initialize(
	p_camera_controller,
	p_tile_manager,
	p_selection_manager,
	p_map_viewport: SubViewport,
	p_layer_tilemaps: Array,
	p_surface_feature_layers: Array,
	p_map_columns: int,
	p_map_rows: int,
	p_tile_types_by_cell: Dictionary,
	p_preview_tileset_source_id: int,
	p_rng: RandomNumberGenerator
):
	camera_controller = p_camera_controller
	tile_manager = p_tile_manager
	selection_manager = p_selection_manager
	map_viewport = p_map_viewport
	layer_tilemaps = p_layer_tilemaps
	surface_feature_layers = p_surface_feature_layers
	map_columns = p_map_columns
	map_rows = p_map_rows
	tile_types_by_cell = p_tile_types_by_cell
	preview_tileset_source_id = p_preview_tileset_source_id
	rng = p_rng

## Set UI element references
func set_ui_elements(p_preview_sprite: Sprite2D, p_tile_inspector: PanelContainer, p_hover_highlight: Polygon2D, p_layer_spin: SpinBox):
	preview_sprite = p_preview_sprite
	tile_inspector_panel = p_tile_inspector
	hover_highlight = p_hover_highlight
	layer_spin = p_layer_spin

## Handle main input events (keyboard routing to camera)
func handle_input_event(event: InputEvent, is_visible: bool) -> bool:
	if not is_visible:
		return false

	# Route input to camera controller
	if camera_controller:
		camera_controller.handle_input_event(event)

	return false

## Handle viewport GUI input (mouse clicks, painting, etc.)
func handle_viewport_gui_input(event: InputEvent) -> bool:
	# Route camera controls to camera controller
	if camera_controller:
		camera_controller.handle_input_event(event)

	if event is InputEventMouseButton:
		return _handle_mouse_button(event)
	elif event is InputEventMouseMotion:
		return _handle_mouse_motion(event)

	return false

## Handle unhandled key input (layer switching, ESC)
func handle_unhandled_key_input(event: InputEvent) -> bool:
	if not event.is_pressed():
		return false

	# Layer switching with Q/E (only if UI didn't consume the key)
	if event.keycode == KEY_Q and not event.ctrl_pressed:
		if current_layer > 0:
			current_layer -= 1
			if layer_spin:
				layer_spin.value = current_layer
			emit_signal("layer_changed", current_layer)
			emit_signal("layer_indicator_update_requested")
			return true
	elif event.keycode == KEY_E and not event.ctrl_pressed:
		if current_layer < MAX_LAYERS - 1:
			current_layer += 1
			if layer_spin:
				layer_spin.value = current_layer
			emit_signal("layer_changed", current_layer)
			emit_signal("layer_indicator_update_requested")
			return true
	elif event.keycode == KEY_ESCAPE:
		# Let parent handle close
		return false

	return false

# ============================================================================
# PRIVATE: Mouse Input Handling
# ============================================================================

func _handle_mouse_button(event: InputEventMouseButton) -> bool:
	# Handle tile editing inputs
	if event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			# Select tile with blue polygon (like planet map)
			if selection_manager:
				_log_info("Attempting tile selection at viewport point: %v", [event.position])
				_log_info("Selection manager has %d map_tiles columns, %d layer_tilemaps", [
					selection_manager.map_tiles.size() if selection_manager.map_tiles else 0,
					selection_manager.layer_tilemaps.size() if selection_manager.layer_tilemaps else 0
				])
				selection_manager.select_tile_from_viewport_point(event.position)
				if selection_manager.selected_tile:
					_log_info("Selected tile at %v with elevation %d", [
						selection_manager.selected_tile.position,
						selection_manager.selected_tile.elevation
					])
				else:
					_log_info("No tile selected")
			else:
				_log_error("Selection manager not initialized")

			if event.ctrl_pressed:
				# Ctrl+Click - Pick tile type
				_pick_tile_at_mouse(event.position)
			elif event.shift_pressed:
				# Shift+Click - Fill tool
				_fill_at_mouse(event.position)
			elif event.alt_pressed:
				# Alt+Click - Brush mode start
				painting = true
				last_paint_cell = Vector2i(-999, -999)
				_paint_tile_at_mouse(event.position)
			else:
				# Normal click - Place single tile
				_place_tile_at_mouse(event.position)
				painting = false
		else:
			# Release - stop painting
			painting = false
			last_paint_cell = Vector2i(-999, -999)
		return true
	elif event.button_index == MOUSE_BUTTON_RIGHT:
		if event.pressed:
			# Right click - Toggle tile inspection
			if tile_inspector_panel and tile_inspector_panel.visible:
				tile_inspector_panel.visible = false
			else:
				_inspect_tile_at_mouse(event.position)
		return true

	return false

func _handle_mouse_motion(event: InputEventMouseMotion) -> bool:
	if painting:
		# Continue painting with brush tool
		_paint_tile_at_mouse(event.position)
	else:
		# Update preview sprite position
		_update_preview_at_mouse(event.position)

	return true

# ============================================================================
# TILE MANIPULATION METHODS
# ============================================================================

func _place_tile_at_mouse(viewport_point: Vector2):
	"""Place a tile at the mouse click position on the current layer"""
	if not ensure_layer_tilemap_callback or not ensure_layer_tilemap_callback.is_valid():
		_log_error("ensure_layer_tilemap_callback not set")
		return

	var tilemap = ensure_layer_tilemap_callback.call(current_layer)
	if not tilemap or not is_instance_valid(tilemap):
		return

	if not camera_controller:
		return

	# Get world position from viewport point
	var canvas_transform = map_viewport.get_canvas_transform()
	var world_point = canvas_transform.affine_inverse() * viewport_point

	# Adjust for the tile manager's position offset
	world_point -= tile_manager.position

	# Adjust for the layer's position offset
	world_point -= tilemap.position

	# Convert to tile coordinates
	var cell = tilemap.local_to_map(world_point)

	# Check if cell is within bounds
	if cell.x < 0 or cell.y < 0 or cell.x >= map_columns or cell.y >= map_rows:
		_log_debug("Click outside map bounds: %s" % [cell])
		return

	# Determine tile type to place
	var tile_type: int
	if selected_tile_type != -1:
		# Use picked tile type
		tile_type = selected_tile_type
	else:
		# Get a random tile from active selection
		var active_tiles = _gather_active_tile_types()
		if active_tiles.is_empty():
			active_tiles = _default_tile_types()
		tile_type = int(active_tiles[rng.randi_range(0, active_tiles.size() - 1)])

	var atlas_coords: Vector2i = PlanetMapView.TILESET_REGION_MAP.get(tile_type, INVALID_ATLAS_COORDS)

	if atlas_coords != INVALID_ATLAS_COORDS and preview_tileset_source_id != -1:
		tilemap.set_cell(0, cell, preview_tileset_source_id, atlas_coords)
		var cell_3d = Vector3i(cell.x, cell.y, current_layer)
		tile_types_by_cell[cell_3d] = tile_type
		emit_signal("tile_placed", cell, current_layer, tile_type)
		emit_signal("layer_indicator_update_requested")
		_log_info("Placed tile at %s on layer %d" % [cell, current_layer])

func _erase_tile_at_mouse(viewport_point: Vector2):
	"""Erase a tile at the mouse position (finds topmost tile)"""
	var cell_result = _get_cell_from_viewport(viewport_point)
	if cell_result == null:
		return

	var cell: Vector2i = cell_result["cell"]
	var tilemap: TileMap = cell_result["tilemap"]
	var layer: int = cell_result["layer"]

	tilemap.erase_cell(0, cell)
	var cell_3d = Vector3i(cell.x, cell.y, layer)
	tile_types_by_cell.erase(cell_3d)
	emit_signal("tile_erased", cell, layer)
	emit_signal("layer_indicator_update_requested")
	_log_info("Erased tile at %s on layer %d" % [cell, layer])

func _pick_tile_at_mouse(viewport_point: Vector2):
	"""Pick the tile type at the mouse position (finds topmost tile)"""
	var cell_result = _get_cell_from_viewport(viewport_point)
	if cell_result == null:
		return

	var cell: Vector2i = cell_result["cell"]
	var layer: int = cell_result["layer"]
	var cell_3d = Vector3i(cell.x, cell.y, layer)

	if tile_types_by_cell.has(cell_3d):
		selected_tile_type = tile_types_by_cell[cell_3d]
		emit_signal("tile_picked", selected_tile_type)
		emit_signal("layer_indicator_update_requested")
		_log_info("Picked tile type %d from %s layer %d" % [selected_tile_type, cell, layer])
	else:
		_log_debug("No tile to pick at %s layer %d" % [cell, layer])

func _inspect_tile_at_mouse(viewport_point: Vector2):
	"""Inspect and display detailed information about tiles at mouse position"""
	if not tile_inspector_panel:
		return

	# Get the cell coordinates (checks all layers to find topmost tile)
	var cell_result = _get_cell_from_viewport(viewport_point)
	if cell_result == null:
		tile_inspector_panel.visible = false
		return

	var cell: Vector2i = cell_result["cell"]

	# Clear previous content
	for child in tile_inspector_panel.get_children():
		child.queue_free()

	# Create container for inspection info with padding
	var margin_container = MarginContainer.new()
	margin_container.add_theme_constant_override("margin_left", 10)
	margin_container.add_theme_constant_override("margin_right", 10)
	margin_container.add_theme_constant_override("margin_top", 8)
	margin_container.add_theme_constant_override("margin_bottom", 8)
	tile_inspector_panel.add_child(margin_container)

	var info_container = VBoxContainer.new()
	info_container.add_theme_constant_override("separation", 4)
	margin_container.add_child(info_container)

	# Header
	var header = Label.new()
	header.text = "Tile Inspector"
	header.add_theme_font_size_override("font_size", 18)
	header.add_theme_color_override("font_color", Color(0, 1, 0.3))
	header.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	info_container.add_child(header)

	# Grid coordinates
	var coords_label = Label.new()
	coords_label.text = "Grid: (%d, %d)" % [cell.x, cell.y]
	coords_label.add_theme_font_size_override("font_size", 14)
	coords_label.add_theme_color_override("font_color", Color(0, 0.85, 0.25))
	coords_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
	info_container.add_child(coords_label)

	# Separator
	var separator1 = HSeparator.new()
	info_container.add_child(separator1)

	# Find topmost layer with a tile at this position
	var topmost_layer = -1
	var topmost_tile_type = -1
	for layer in range(MAX_LAYERS - 1, -1, -1):
		var top_cell_3d = Vector3i(cell.x, cell.y, layer)
		if tile_types_by_cell.has(top_cell_3d):
			topmost_layer = layer
			topmost_tile_type = tile_types_by_cell[top_cell_3d]
			break

	# Display topmost tile info
	if topmost_layer >= 0:
		var top_header = Label.new()
		top_header.text = "Visible Surface:"
		top_header.add_theme_font_size_override("font_size", 15)
		top_header.add_theme_color_override("font_color", Color(1, 1, 0))
		top_header.add_theme_font_override("font", TerminalTheme.get_terminal_font())
		info_container.add_child(top_header)

		var elevation_label = Label.new()
		elevation_label.text = "  Elevation: %d" % topmost_layer
		elevation_label.add_theme_font_size_override("font_size", 13)
		elevation_label.add_theme_color_override("font_color", Color(0, 0.85, 0.25))
		elevation_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
		info_container.add_child(elevation_label)

		var tile_name = PlanetMapView.TileType.keys()[topmost_tile_type] if topmost_tile_type < PlanetMapView.TileType.size() else "UNKNOWN"
		var tile_label = Label.new()
		tile_label.text = "  Type: %s" % tile_name.replace("_", " ")
		tile_label.add_theme_font_size_override("font_size", 13)
		tile_label.add_theme_color_override("font_color", Color(0, 0.85, 0.25))
		tile_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
		info_container.add_child(tile_label)

		# Check for surface features at topmost layer
		if topmost_layer < surface_feature_layers.size():
			var sf_layer = surface_feature_layers[topmost_layer]
			if sf_layer and is_instance_valid(sf_layer):
				var sf_atlas_coords = sf_layer.get_cell_atlas_coords(0, cell)
				if sf_atlas_coords != Vector2i(-1, -1):
					# Find which surface feature this is
					var sf_type_name = "UNKNOWN"
					for tile_type in PlanetMapView.TILESET_REGION_MAP:
						if PlanetMapView.TILESET_REGION_MAP[tile_type] == sf_atlas_coords:
							if PlanetMapView.is_surface_feature(tile_type):
								sf_type_name = PlanetMapView.TileType.keys()[tile_type].replace("SF_", "").replace("_", " ")
								break

					var sf_label = Label.new()
					sf_label.text = "  Feature: %s" % sf_type_name
					sf_label.add_theme_font_size_override("font_size", 13)
					sf_label.add_theme_color_override("font_color", Color(0.3, 1, 0.3))
					sf_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
					info_container.add_child(sf_label)
	else:
		var no_tile_label = Label.new()
		no_tile_label.text = "No tile at this position"
		no_tile_label.add_theme_font_size_override("font_size", 14)
		no_tile_label.add_theme_color_override("font_color", Color(1, 0.5, 0))
		no_tile_label.add_theme_font_override("font", TerminalTheme.get_terminal_font())
		info_container.add_child(no_tile_label)

	tile_inspector_panel.visible = true

func _paint_tile_at_mouse(viewport_point: Vector2):
	"""Paint tiles with brush tool (click and drag)"""
	var cell_result = _get_cell_from_viewport(viewport_point)
	if cell_result == null:
		return

	var cell: Vector2i = cell_result["cell"]

	# Don't paint the same cell twice in one stroke
	if cell == last_paint_cell:
		return

	last_paint_cell = cell
	_place_tile_at_mouse(viewport_point)

func _fill_at_mouse(viewport_point: Vector2):
	"""Flood fill starting from mouse position (finds topmost tile)"""
	var cell_result = _get_cell_from_viewport(viewport_point)
	if cell_result == null:
		return

	var start_cell: Vector2i = cell_result["cell"]
	var tilemap: TileMap = cell_result["tilemap"]
	var layer: int = cell_result["layer"]
	var start_cell_3d = Vector3i(start_cell.x, start_cell.y, layer)

	# Get the tile type to replace (or -1 for empty)
	var replace_type = tile_types_by_cell.get(start_cell_3d, -1)

	# Determine fill type
	var fill_type: int
	if selected_tile_type != -1:
		fill_type = selected_tile_type
	else:
		var active_tiles = _gather_active_tile_types()
		if active_tiles.is_empty():
			active_tiles = _default_tile_types()
		fill_type = int(active_tiles[rng.randi_range(0, active_tiles.size() - 1)])

	# Don't fill if same type
	if replace_type == fill_type:
		return

	# Flood fill algorithm (iterative with queue)
	var queue: Array[Vector2i] = [start_cell]
	var visited: Dictionary = {start_cell: true}
	var fill_count = 0

	while queue.size() > 0 and fill_count < 1000:  # Safety limit
		var cell = queue.pop_front()
		var cell_3d = Vector3i(cell.x, cell.y, layer)
		var current_type = tile_types_by_cell.get(cell_3d, -1)

		# Check if this cell matches the replace type
		if current_type != replace_type:
			continue

		# Fill this cell
		var atlas_coords: Vector2i = PlanetMapView.TILESET_REGION_MAP.get(fill_type, INVALID_ATLAS_COORDS)
		if atlas_coords != INVALID_ATLAS_COORDS and preview_tileset_source_id != -1:
			tilemap.set_cell(0, cell, preview_tileset_source_id, atlas_coords)
			tile_types_by_cell[cell_3d] = fill_type
			fill_count += 1

			# Add adjacent cells to queue
			var neighbors = [
				Vector2i(cell.x + 1, cell.y),
				Vector2i(cell.x - 1, cell.y),
				Vector2i(cell.x, cell.y + 1),
				Vector2i(cell.x, cell.y - 1)
			]

			for neighbor in neighbors:
				if neighbor.x >= 0 and neighbor.y >= 0 and neighbor.x < map_columns and neighbor.y < map_rows:
					if not visited.has(neighbor):
						visited[neighbor] = true
						queue.append(neighbor)

	emit_signal("layer_indicator_update_requested")
	_log_info("Filled %d tiles starting from %s on layer %d" % [fill_count, start_cell, layer])

# ============================================================================
# VISUAL FEEDBACK METHODS
# ============================================================================

func _update_preview_at_mouse(viewport_point: Vector2):
	"""Update the ghost preview sprite at mouse position"""
	if not preview_sprite or not is_instance_valid(preview_sprite):
		return

	var cell_result = _get_cell_from_viewport(viewport_point)
	if cell_result == null:
		preview_sprite.visible = false
		return

	var tilemap: TileMap = cell_result["tilemap"]
	var cell: Vector2i = cell_result["cell"]

	# Determine what tile type we would place
	var tile_type: int
	if selected_tile_type != -1:
		tile_type = selected_tile_type
	else:
		var active_tiles = _gather_active_tile_types()
		if active_tiles.is_empty():
			active_tiles = _default_tile_types()
		if active_tiles.size() > 0:
			tile_type = int(active_tiles[0])  # Show first tile as preview
		else:
			preview_sprite.visible = false
			return

	# Get texture for this tile type from the tileset
	var atlas_coords: Vector2i = PlanetMapView.TILESET_REGION_MAP.get(tile_type, INVALID_ATLAS_COORDS)
	if atlas_coords != INVALID_ATLAS_COORDS:
		# Create an AtlasTexture from the main tileset
		var atlas_texture = AtlasTexture.new()
		atlas_texture.atlas = PlanetMapView.TILESET_TEXTURE
		atlas_texture.region = Rect2(
			atlas_coords.x * PlanetMapView.TILESET_SOURCE_TILE_SIZE.x,
			atlas_coords.y * PlanetMapView.TILESET_SOURCE_TILE_SIZE.y,
			PlanetMapView.TILESET_SOURCE_TILE_SIZE.x,
			PlanetMapView.TILESET_SOURCE_TILE_SIZE.y
		)

		preview_sprite.texture = atlas_texture
		# Position at the same location as the tile would appear
		# Get the base position from the tilemap
		var center = tilemap.map_to_local(cell)
		# The preview sprite should be in the same coordinate space as the tilemap
		# Since preview_sprite is a child of map_content (same as tilemap),
		# we need to account for the tilemap's local position offset
		center.y += tilemap.position.y  # Only add Y offset (layer height)
		preview_sprite.position = center
		preview_sprite.visible = true
	else:
		preview_sprite.visible = false

func update_hover_highlight(viewport_point: Vector2):
	"""Update the hover highlight to show which tile the mouse is over"""
	if not hover_highlight or not is_instance_valid(hover_highlight):
		return

	var cell_result = _get_cell_from_viewport(viewport_point)
	if cell_result == null:
		hover_highlight.visible = false
		return

	var cell: Vector2i = cell_result["cell"]
	var tilemap: TileMap = cell_result["tilemap"]
	var layer: int = cell_result["layer"]

	# Get the center position of the cell
	var center := tilemap.map_to_local(cell)

	# Adjust for layer position
	center += tilemap.position

	# Create the isometric diamond polygon points (same as click detection)
	var polygon_points := PackedVector2Array([
		center + Vector2(0, -PlanetMapView.TILE_OFFSET.y),      # Top
		center + Vector2(PlanetMapView.TILE_OFFSET.x, 0),       # Right
		center + Vector2(0, PlanetMapView.TILE_OFFSET.y),       # Bottom
		center + Vector2(-PlanetMapView.TILE_OFFSET.x, 0),      # Left
	])

	hover_highlight.polygon = polygon_points
	# Set z-index to be on top of tiles for the detected layer
	# Using 90-unit spacing to fit 32 layers (max: 31*90+50 = 2840)
	hover_highlight.z_index = layer * 90 + 50
	hover_highlight.visible = true

# ============================================================================
# COORDINATE CONVERSION
# ============================================================================

func _get_cell_from_viewport(viewport_point: Vector2):
	"""Helper to convert viewport point to cell coordinates using proper transform chain.
	Checks all layers from top to bottom to find the topmost tile under the mouse.
	Returns {cell: Vector2i, tilemap: TileMap, layer: int} or null"""

	if not map_viewport or not is_instance_valid(map_viewport):
		return null

	# Use Godot's canvas transform to properly convert viewport to world coordinates
	var canvas_transform := map_viewport.get_canvas_transform()
	var world_point := canvas_transform.affine_inverse() * viewport_point

	# Check layers from highest to lowest (top to bottom) to find clicked tile
	# This makes elevated tiles clickable and matches PlanetMapView behavior
	for layer in range(MAX_LAYERS - 1, -1, -1):
		# Skip if no tilemap for this layer
		if layer >= layer_tilemaps.size() or not layer_tilemaps[layer] or not is_instance_valid(layer_tilemaps[layer]):
			continue

		var tilemap = layer_tilemaps[layer]

		# Convert from world space to tilemap local space using proper transform chain
		var tilemap_global_transform: Transform2D = tilemap.get_global_transform()
		var tilemap_local: Vector2 = tilemap_global_transform.affine_inverse() * world_point

		var tilemap_cell: Vector2i = tilemap.local_to_map(tilemap_local)

		# For more precise hit detection, check neighboring cells
		var candidates: Array[Vector2i] = []

		# Add the primary cell and its neighbors
		for dx in range(-1, 2):
			for dy in range(-1, 2):
				var candidate := Vector2i(tilemap_cell.x + dx, tilemap_cell.y + dy)
				if candidate.x >= 0 and candidate.y >= 0 and candidate.x < map_columns and candidate.y < map_rows:
					candidates.append(candidate)

		# Find the best matching tile using polygon hit testing
		var cell := Vector2i(-1, -1)
		for candidate in candidates:
			if _is_point_inside_tile_tilemap_space(tilemap_local, candidate, tilemap):
				cell = candidate
				break

		# Fallback to the TileMap's primary result if no polygon match
		if cell == Vector2i(-1, -1):
			if tilemap_cell.x >= 0 and tilemap_cell.y >= 0 and tilemap_cell.x < map_columns and tilemap_cell.y < map_rows:
				cell = tilemap_cell

		# If we found a valid cell on this layer, check if there's actually a tile there
		if cell.x >= 0 and cell.y >= 0 and cell.x < map_columns and cell.y < map_rows:
			var cell_3d = Vector3i(cell.x, cell.y, layer)
			# Check if this cell has a tile
			if tile_types_by_cell.has(cell_3d):
				# Found a tile! Return it with the layer info
				return {"cell": cell, "tilemap": tilemap, "layer": layer}

	# No tile found on any layer - return the current layer as fallback for placing tiles
	if not ensure_layer_tilemap_callback or not ensure_layer_tilemap_callback.is_valid():
		return null

	var current_tilemap = ensure_layer_tilemap_callback.call(current_layer)
	if not current_tilemap or not is_instance_valid(current_tilemap):
		return null

	# Convert from world space to tilemap local space
	var tilemap_global_transform: Transform2D = current_tilemap.get_global_transform()
	var tilemap_local: Vector2 = tilemap_global_transform.affine_inverse() * world_point
	var cell: Vector2i = current_tilemap.local_to_map(tilemap_local)

	if cell.x >= 0 and cell.y >= 0 and cell.x < map_columns and cell.y < map_rows:
		return {"cell": cell, "tilemap": current_tilemap, "layer": current_layer}

	return null

func _is_point_inside_tile_tilemap_space(point_local: Vector2, cell: Vector2i, tilemap: TileMap) -> bool:
	"""Check if a point (in TileMap local coordinates) is inside the given tile's diamond."""
	if cell.x < 0 or cell.y < 0 or cell.x >= map_columns or cell.y >= map_rows:
		return false

	# Get tile center position from TileMap (this is in TileMap's local space)
	var center := tilemap.map_to_local(cell)

	# Define the diamond corners for an isometric tile
	var corners := PackedVector2Array([
		center + Vector2(0, -PlanetMapView.TILE_OFFSET.y),
		center + Vector2(PlanetMapView.TILE_OFFSET.x, 0),
		center + Vector2(0, PlanetMapView.TILE_OFFSET.y),
		center + Vector2(-PlanetMapView.TILE_OFFSET.x, 0),
	])

	return Geometry2D.is_point_in_polygon(point_local, corners)

# ============================================================================
# HELPER METHODS (delegate to callbacks)
# ============================================================================

func _gather_active_tile_types() -> Array:
	if gather_active_tiles_callback and gather_active_tiles_callback.is_valid():
		return gather_active_tiles_callback.call()
	return []

func _default_tile_types() -> Array:
	if default_tiles_callback and default_tiles_callback.is_valid():
		return default_tiles_callback.call()
	return []

# ============================================================================
# LOGGING
# ============================================================================

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, message % values if values.size() > 0 else message)

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, message % values if values.size() > 0 else message)

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, message % values if values.size() > 0 else message)
