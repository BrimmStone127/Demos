extends RefCounted
class_name SandboxVisualFeedback

## Manages visual feedback elements in the Sandbox
## (layer indicator, preview sprite, tile inspector, hover highlight, debug overlay)
## Extracted from Sandbox.gd for better code organization

# Constants
const MAX_LAYERS = 8
const LOG_TAG := "SANDBOX_VISUAL"

# Enum for tool modes (matches Sandbox)
enum ToolMode {
	PLACE,
	ERASE,
	PICKER,
	BRUSH,
	FILL
}

# UI element references (created by this component)
var layer_indicator_label: Label = null
var preview_sprite: Sprite2D = null
var tile_inspector_panel: PanelContainer = null
var hover_highlight: Polygon2D = null
var debug_overlay: Node2D = null

## Create the layer indicator label
func create_layer_indicator(parent: Control) -> Label:
	if not parent:
		return null

	layer_indicator_label = Label.new()
	layer_indicator_label.name = "LayerIndicator"
	layer_indicator_label.add_theme_font_size_override("font_size", 24)
	layer_indicator_label.add_theme_color_override("font_color", Color(1, 1, 0, 0.9))
	layer_indicator_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	layer_indicator_label.add_theme_constant_override("outline_size", 4)
	layer_indicator_label.position = Vector2(20, 20)
	layer_indicator_label.z_index = 2000
	layer_indicator_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(layer_indicator_label)

	return layer_indicator_label

## Create the ghost preview sprite
func create_preview_sprite(parent: Node2D) -> Sprite2D:
	if not parent or not is_instance_valid(parent):
		return null

	preview_sprite = Sprite2D.new()
	preview_sprite.name = "PreviewSprite"
	preview_sprite.centered = true
	preview_sprite.modulate = Color(1, 1, 1, 0.5)  # Semi-transparent
	preview_sprite.z_index = 4000  # Always on top (near Godot's z_index max: 4096)
	preview_sprite.visible = false
	preview_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	parent.add_child(preview_sprite)

	return preview_sprite

## Create the tile inspection panel
func create_tile_inspector(parent: Control) -> PanelContainer:
	if not parent:
		return null

	tile_inspector_panel = PanelContainer.new()
	tile_inspector_panel.name = "TileInspectorPanel"
	tile_inspector_panel.visible = false
	tile_inspector_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tile_inspector_panel.z_index = 3000

	# Style the panel with a semi-transparent black background
	var style_box = StyleBoxFlat.new()
	style_box.bg_color = Color(0, 0, 0, 0.85)
	style_box.border_width_left = 2
	style_box.border_width_right = 2
	style_box.border_width_top = 2
	style_box.border_width_bottom = 2
	style_box.border_color = Color(0, 1, 0.3, 1)
	style_box.corner_radius_top_left = 4
	style_box.corner_radius_top_right = 4
	style_box.corner_radius_bottom_left = 4
	style_box.corner_radius_bottom_right = 4
	tile_inspector_panel.add_theme_stylebox_override("panel", style_box)

	parent.add_child(tile_inspector_panel)

	return tile_inspector_panel

## Create the hover highlight polygon
func create_hover_highlight(parent: Node2D) -> Polygon2D:
	if not parent or not is_instance_valid(parent):
		return null

	hover_highlight = Polygon2D.new()
	hover_highlight.name = "HoverHighlight"
	hover_highlight.z_as_relative = false
	hover_highlight.visible = false
	hover_highlight.color = Color(1.0, 1.0, 0.0, 0.4)  # Yellow with transparency
	hover_highlight.z_index = 4000  # High z-index to always be visible on top (near Godot's max: 4096)

	parent.add_child(hover_highlight)

	return hover_highlight

## Update the layer indicator text
func update_layer_indicator(
	current_layer: int,
	tile_types_by_cell: Dictionary,
	map_columns: int,
	map_rows: int,
	current_tool: ToolMode
):
	if not layer_indicator_label:
		return

	var tile_count = 0
	for x in range(map_columns):
		for y in range(map_rows):
			var cell_3d = Vector3i(x, y, current_layer)
			if tile_types_by_cell.has(cell_3d):
				tile_count += 1

	var tool_name = ""
	match current_tool:
		ToolMode.PLACE: tool_name = "PLACE"
		ToolMode.ERASE: tool_name = "ERASE"
		ToolMode.PICKER: tool_name = "PICKER"
		ToolMode.BRUSH: tool_name = "BRUSH"
		ToolMode.FILL: tool_name = "FILL"

	layer_indicator_label.text = "Layer %d (%d tiles) | Tool: %s" % [current_layer, tile_count, tool_name]

## Create debug overlay showing click areas for current layer
func create_debug_overlay(
	parent: Node2D,
	current_layer: int,
	map_columns: int,
	map_rows: int,
	layer_tilemaps: Array,
	ensure_layer_callback: Callable
) -> Node2D:
	clear_debug_overlay()

	if not parent or not is_instance_valid(parent):
		return null

	# Safety check: prevent crash on very large maps
	var estimated_nodes = map_columns * map_rows * 2  # 2 nodes per cell (polygon + label)
	if estimated_nodes > 10000:
		_log_warn("Debug overlay disabled: map too large (%d columns x %d rows = %d nodes). Would crash the game." % [map_columns, map_rows, estimated_nodes])
		return null

	debug_overlay = Node2D.new()
	debug_overlay.name = "DebugClickAreas"
	debug_overlay.z_index = 2000
	parent.add_child(debug_overlay)

	var total_polygons = 0

	# Get tilemap for current layer
	var tilemap: TileMap = null
	if ensure_layer_callback and ensure_layer_callback.is_valid():
		tilemap = ensure_layer_callback.call(current_layer)
	if not tilemap or not is_instance_valid(tilemap):
		_log_warn("Cannot create debug overlay: tilemap not available for layer %d" % current_layer)
		return debug_overlay

	# Color for current layer
	var layer_color = Color.from_hsv(float(current_layer) / float(MAX_LAYERS), 0.8, 1.0, 0.3)

	for x in range(map_columns):
		for y in range(map_rows):
			var cell := Vector2i(x, y)
			var center := tilemap.map_to_local(cell)

			# Apply layer offset
			center += tilemap.position

			# Create polygon shape matching the click detection
			var polygon := Polygon2D.new()
			polygon.polygon = PackedVector2Array([
				center + Vector2(0, -PlanetMapView.TILE_OFFSET.y),
				center + Vector2(PlanetMapView.TILE_OFFSET.x, 0),
				center + Vector2(0, PlanetMapView.TILE_OFFSET.y),
				center + Vector2(-PlanetMapView.TILE_OFFSET.x, 0),
			])
			polygon.color = layer_color
			polygon.z_index = tilemap.z_index + 1
			debug_overlay.add_child(polygon)

			# Add cell coordinate label with layer info
			var label := Label.new()
			label.text = "%d,%d,L%d" % [x, y, current_layer]
			label.position = center - Vector2(20, 10)
			label.add_theme_font_size_override("font_size", 9)
			label.add_theme_color_override("font_color", Color(1, 1, 0, 0.9))
			label.z_index = tilemap.z_index + 2
			debug_overlay.add_child(label)

			total_polygons += 1

	_log_info("Debug overlay created with %d click area polygons for layer %d (limited to current layer)" % [total_polygons, current_layer])

	return debug_overlay

## Clear the debug overlay
func clear_debug_overlay():
	if debug_overlay and is_instance_valid(debug_overlay):
		debug_overlay.queue_free()
		debug_overlay = null

## Clean up all visual feedback elements
func cleanup():
	if layer_indicator_label and is_instance_valid(layer_indicator_label):
		layer_indicator_label.queue_free()
		layer_indicator_label = null

	if preview_sprite and is_instance_valid(preview_sprite):
		preview_sprite.queue_free()
		preview_sprite = null

	if tile_inspector_panel and is_instance_valid(tile_inspector_panel):
		tile_inspector_panel.queue_free()
		tile_inspector_panel = null

	if hover_highlight and is_instance_valid(hover_highlight):
		hover_highlight.queue_free()
		hover_highlight = null

	clear_debug_overlay()

# ============================================================================
# LOGGING
# ============================================================================

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, message % values if values.size() > 0 else message)

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, message % values if values.size() > 0 else message)
