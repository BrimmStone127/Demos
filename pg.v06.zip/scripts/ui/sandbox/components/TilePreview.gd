class_name TilePreview
extends PanelContainer

# Displays a single tile type with sprite and label
# Used in the visual tile palette and asset browser
# Supports both enum-based tiles and TileAliasData

signal clicked(tile_id: int)  # Emits tile_id (can be enum value or catalog ID)
signal toggled(tile_id: int, selected: bool)

var tile_id: int = -1  # Tile ID (enum value for legacy, or catalog ID for alias system)
var tile_type: int = -1  # For legacy compatibility (same as tile_id)
var tile_name: String = ""
var tile_category: String = "Uncategorized"
var tile_alias_data: TileAliasData = null  # If using alias system
var selected: bool = false
var selectable: bool = false  # If true, shows checkbox for multi-select

const PREVIEW_SIZE := Vector2(128, 128)  # Increased from 80x80 for larger tiles
const SELECTED_COLOR := Color(0.0, 0.8, 0.2, 0.3)  # Terminal green tint when selected
const NORMAL_COLOR := Color(0.15, 0.15, 0.15, 0.9)  # Medium dark background for visibility

var _sprite: TextureRect
var _label: Label
var _checkbox: CheckBox

func _init():
	custom_minimum_size = PREVIEW_SIZE
	mouse_filter = Control.MOUSE_FILTER_STOP
	_build_ui()  # Build UI immediately so setup() can configure it

func setup(p_tile_type: int, p_selectable: bool = false) -> void:
	"""Configure this preview with a tile type (legacy enum-based system)."""
	tile_id = p_tile_type
	tile_type = p_tile_type  # For compatibility
	tile_name = SandboxConfig.get_tile_name(tile_type)
	tile_category = SandboxConfig.get_category_name(SandboxConfig.get_tile_category(tile_type))
	selectable = p_selectable
	tile_alias_data = null

	if not _sprite or not _label:
		push_error("TilePreview.setup() called but UI not built! _sprite=%s _label=%s" % [_sprite != null, _label != null])
		return

	_update_sprite_from_enum()
	_label.text = tile_name
	if _checkbox:
		_checkbox.visible = selectable

func setup_from_alias(p_tile_data: TileAliasData, p_selectable: bool = false) -> void:
	"""Configure this preview with TileAliasData (new alias system)."""
	tile_alias_data = p_tile_data
	tile_id = p_tile_data.id
	tile_type = p_tile_data.id  # For compatibility
	tile_name = p_tile_data.get_display_name()
	tile_category = p_tile_data.category
	selectable = p_selectable

	if not _sprite or not _label:
		push_error("TilePreview.setup_from_alias() called but UI not built!")
		return

	_update_sprite_from_coords(p_tile_data.atlas_coords)
	_label.text = tile_name
	if _checkbox:
		_checkbox.visible = selectable

func update_from_alias(p_tile_data: TileAliasData) -> void:
	"""Update display name from alias data (for refreshing after alias changes)."""
	tile_alias_data = p_tile_data
	tile_name = p_tile_data.get_display_name()
	if _label:
		_label.text = tile_name

func set_selected(p_selected: bool) -> void:
	"""Highlight this tile as selected."""
	selected = p_selected
	_update_appearance()
	if _checkbox and _checkbox.button_pressed != selected:
		_checkbox.button_pressed = selected

func _build_ui() -> void:
	# VBox container for sprite + label
	var vbox = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(vbox)

	# Sprite display (larger for better visibility)
	_sprite = TextureRect.new()
	_sprite.custom_minimum_size = Vector2(100, 100)  # Increased from 64x64
	_sprite.expand_mode = TextureRect.EXPAND_FIT_WIDTH_PROPORTIONAL
	_sprite.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	vbox.add_child(_sprite)

	# Label with terminal theme color
	_label = Label.new()
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	_label.custom_minimum_size.y = 16
	_label.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	_label.add_theme_font_size_override("font_size", 10)
	vbox.add_child(_label)

	# Optional checkbox overlay
	_checkbox = CheckBox.new()
	_checkbox.visible = false
	_checkbox.position = Vector2(2, 2)
	_checkbox.toggled.connect(_on_checkbox_toggled)
	add_child(_checkbox)

	# Click handling
	gui_input.connect(_on_gui_input)

	_update_appearance()

func _update_sprite_from_enum() -> void:
	"""Load and display the tile sprite from the atlas using enum value."""
	if not _sprite:
		push_warning("TilePreview: _sprite not created yet for tile type %d" % tile_type)
		return

	# Check if atlas coords exist for this tile type
	var has_coords = PlanetMapTileConfig.TILESET_REGION_MAP.has(tile_type)
	var atlas_coords = PlanetMapTileConfig.TILESET_REGION_MAP.get(tile_type)

	if not has_coords or atlas_coords == null:
		push_warning("TilePreview: No atlas coords for tile type %d (%s) - has_key=%s, value=%s" % [tile_type, tile_name, has_coords, atlas_coords])
		_sprite.texture = null
		return

	_update_sprite_from_coords(atlas_coords)

func _update_sprite_from_coords(atlas_coords: Vector2i) -> void:
	"""Load and display the tile sprite from the atlas using direct coordinates."""
	if not _sprite:
		push_warning("TilePreview: _sprite not created yet")
		return

	# Create AtlasTexture to extract this tile from the tileset
	var atlas_tex = AtlasTexture.new()
	atlas_tex.atlas = PlanetMapTileConfig.TILESET_TEXTURE

	if not atlas_tex.atlas:
		push_error("TilePreview: Failed to load tileset texture!")
		return

	var tile_size = PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	atlas_tex.region = Rect2(atlas_coords * tile_size, tile_size)

	_sprite.texture = atlas_tex

func _update_appearance() -> void:
	"""Update visual appearance based on selection state."""
	if selected:
		add_theme_stylebox_override("panel", _create_selected_stylebox())
	else:
		add_theme_stylebox_override("panel", _create_normal_stylebox())

func _create_selected_stylebox() -> StyleBox:
	var style = StyleBoxFlat.new()
	style.bg_color = SELECTED_COLOR
	style.border_width_left = 2
	style.border_width_right = 2
	style.border_width_top = 2
	style.border_width_bottom = 2
	style.border_color = TerminalTheme.terminal_green
	return style

func _create_normal_stylebox() -> StyleBox:
	var style = StyleBoxFlat.new()
	style.bg_color = NORMAL_COLOR
	style.border_width_left = 1
	style.border_width_right = 1
	style.border_width_top = 1
	style.border_width_bottom = 1
	style.border_color = Color(0.0, 0.4, 0.1)  # Darker terminal green
	return style

func _on_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			accept_event()
			clicked.emit(tile_id)

			if selectable:
				set_selected(not selected)
				toggled.emit(tile_id, selected)

func _on_checkbox_toggled(button_pressed: bool) -> void:
	set_selected(button_pressed)
	toggled.emit(tile_id, selected)
