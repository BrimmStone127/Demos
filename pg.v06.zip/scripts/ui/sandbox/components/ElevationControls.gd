class_name ElevationControls
extends VBoxContainer

# Elevation pattern generation controls

signal generate_requested(pattern: ElevationGenerator.Pattern, max_height: int)

var _pattern_option: OptionButton
var _height_spin: SpinBox
var _generate_button: Button

func _ready():
	_build_ui()

func _build_ui() -> void:
	add_theme_constant_override("separation", 6)

	# Header
	var header = Label.new()
	header.text = "Elevation Generation"
	header.add_theme_font_size_override("font_size", 14)
	TerminalTheme.apply_to_label(header)
	add_child(header)

	# Pattern selection row
	var pattern_row = HBoxContainer.new()
	pattern_row.add_theme_constant_override("separation", 8)
	add_child(pattern_row)

	var pattern_label = Label.new()
	pattern_label.text = "Pattern:"
	TerminalTheme.apply_to_label(pattern_label)
	pattern_row.add_child(pattern_label)

	_pattern_option = OptionButton.new()
	_pattern_option.custom_minimum_size.x = 150
	_pattern_option.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	_pattern_option.add_theme_font_override("font", TerminalTheme.get_terminal_font())

	# Add all patterns
	_pattern_option.add_item("Flat", ElevationGenerator.Pattern.FLAT)
	_pattern_option.add_item("Random", ElevationGenerator.Pattern.RANDOM)
	_pattern_option.add_item("Noise", ElevationGenerator.Pattern.NOISE)
	_pattern_option.add_item("Hills", ElevationGenerator.Pattern.HILLS)
	_pattern_option.add_item("Mountain", ElevationGenerator.Pattern.MOUNTAIN)
	_pattern_option.add_item("Crater", ElevationGenerator.Pattern.CRATER)
	_pattern_option.add_item("Island", ElevationGenerator.Pattern.ISLAND)
	_pattern_option.add_item("Ridges", ElevationGenerator.Pattern.RIDGES)

	pattern_row.add_child(_pattern_option)

	# Height selection row
	var height_row = HBoxContainer.new()
	height_row.add_theme_constant_override("separation", 8)
	add_child(height_row)

	var height_label = Label.new()
	height_label.text = "Max Height:"
	TerminalTheme.apply_to_label(height_label)
	height_row.add_child(height_label)

	_height_spin = SpinBox.new()
	_height_spin.min_value = 1
	_height_spin.max_value = SandboxConfig.MAX_LAYERS - 1
	_height_spin.value = SandboxConfig.DEFAULT_ELEVATION_HEIGHT
	_height_spin.step = 1
	_height_spin.custom_minimum_size.x = 80
	_height_spin.add_theme_color_override("font_color", TerminalTheme.terminal_green)
	height_row.add_child(_height_spin)

	# Generate button
	_generate_button = Button.new()
	_generate_button.text = "Generate Elevation"
	_generate_button.pressed.connect(_on_generate_pressed)
	TerminalTheme.apply_to_button(_generate_button)
	add_child(_generate_button)

func _on_generate_pressed() -> void:
	var pattern = _pattern_option.get_selected_id() as ElevationGenerator.Pattern
	var max_height = int(_height_spin.value)
	generate_requested.emit(pattern, max_height)
