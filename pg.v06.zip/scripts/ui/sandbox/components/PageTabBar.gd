class_name PageTabBar
extends HBoxContainer

# Tab navigation for switching between sandbox pages

signal tab_changed(tab_index: int)

var _buttons: Array[Button] = []
var _current_tab: int = 0

func add_tab(tab_name: String, icon: Texture2D = null) -> void:
	"""Add a new tab button."""
	var button = Button.new()
	button.text = tab_name
	if icon:
		button.icon = icon
	button.toggle_mode = true
	button.button_group = _get_or_create_button_group()

	var tab_index = _buttons.size()
	button.pressed.connect(func(): _on_tab_pressed(tab_index))

	add_child(button)
	_buttons.append(button)

	# Select first tab by default
	if _buttons.size() == 1:
		button.button_pressed = true

func set_current_tab(index: int) -> void:
	"""Programmatically switch to a tab."""
	if index >= 0 and index < _buttons.size():
		_buttons[index].button_pressed = true
		_on_tab_pressed(index)

func get_current_tab() -> int:
	return _current_tab

func _on_tab_pressed(index: int) -> void:
	if _current_tab != index:
		_current_tab = index
		tab_changed.emit(index)

func _get_or_create_button_group() -> ButtonGroup:
	# Use a shared button group for all tabs
	if not has_meta("button_group"):
		var group = ButtonGroup.new()
		set_meta("button_group", group)
	return get_meta("button_group")

func clear_tabs() -> void:
	"""Remove all tabs."""
	for button in _buttons:
		button.queue_free()
	_buttons.clear()
	_current_tab = 0
