extends RefCounted
class_name SandboxUIBuilder

## Builds all UI elements for the Sandbox
## Extracted from Sandbox.gd for better code organization

# Constants
const MIN_PALETTE_WIDTH = 250
const MAX_LAYERS = 8

# Enum for elevation patterns (duplicate from Sandbox for self-containment)
enum ElevationPattern {
	FLAT,
	RANDOM,
	NOISE,
	HILLS,
	MOUNTAIN,
	CRATER,
	ISLAND,
	RIDGES
}

## Build all UI elements and return references
## @param palette_panel: The left panel for tile palette
## @param close_button: Existing close button to connect
## @param select_all_button: Existing select all button
## @param clear_button: Existing clear button
## @param regenerate_button: Existing regenerate button
## @param split_container: The HSplitContainer
## @param map_viewport_container: The viewport container
## @param columns_spin: Columns spinbox
## @param rows_spin: Rows spinbox
## @param rng: Random number generator for seed
## @returns Dictionary with all UI element references
func build_ui(
	palette_panel: VBoxContainer,
	close_button: Button,
	select_all_button: Button,
	clear_button: Button,
	regenerate_button: Button,
	split_container: HSplitContainer,
	map_viewport_container: SubViewportContainer,
	columns_spin: SpinBox,
	rows_spin: SpinBox,
	rng: RandomNumberGenerator,
	# Callbacks for signal connections
	on_close_callback: Callable,
	on_set_all_palette_callback: Callable,
	on_regenerate_map_callback: Callable,
	on_clear_layer_callback: Callable,
	on_debug_toggle_callback: Callable,
	on_columns_changed_callback: Callable,
	on_rows_changed_callback: Callable,
	on_layer_spin_changed_callback: Callable,
	on_generate_elevation_callback: Callable,
	on_load_csv_callback: Callable,
	on_add_surface_features_callback: Callable,
	on_water_slider_callback: Callable,
	on_ice_slider_callback: Callable,
	on_lava_slider_callback: Callable,
	on_earth_preset_callback: Callable,
	on_generate_planet_callback: Callable,
	on_split_resized_callback: Callable,
	on_map_container_resized_callback: Callable,
	on_viewport_gui_input_callback: Callable
) -> Dictionary:
	var refs = {}

	# Configure palette panel
	if palette_panel:
		palette_panel.custom_minimum_size = Vector2(MIN_PALETTE_WIDTH, 0)
		palette_panel.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN

	# Connect existing buttons
	close_button.pressed.connect(on_close_callback)
	select_all_button.pressed.connect(func(): on_set_all_palette_callback.call(true))
	clear_button.pressed.connect(func(): on_set_all_palette_callback.call(false))
	regenerate_button.pressed.connect(on_regenerate_map_callback)

	# Create clear layer button and debug toggle
	var clear_layer_button: Button = null
	var debug_toggle_button: CheckButton = null
	if regenerate_button and regenerate_button.get_parent():
		var parent = regenerate_button.get_parent()

		# Clear Layer button
		clear_layer_button = Button.new()
		clear_layer_button.text = "Clear Layer"
		clear_layer_button.size_flags_horizontal = Control.SIZE_FILL
		clear_layer_button.pressed.connect(on_clear_layer_callback)
		parent.add_child(clear_layer_button)
		parent.move_child(clear_layer_button, regenerate_button.get_index() + 1)

		# Debug toggle
		debug_toggle_button = CheckButton.new()
		debug_toggle_button.text = "Show Click Areas"
		debug_toggle_button.button_pressed = false
		debug_toggle_button.toggled.connect(on_debug_toggle_callback)
		parent.add_child(debug_toggle_button)
		parent.move_child(debug_toggle_button, regenerate_button.get_index() + 2)

	refs["clear_layer_button"] = clear_layer_button
	refs["debug_toggle_button"] = debug_toggle_button

	# Connect split container and viewport
	split_container.resized.connect(on_split_resized_callback)
	map_viewport_container.resized.connect(on_map_container_resized_callback)
	map_viewport_container.mouse_filter = Control.MOUSE_FILTER_STOP
	if map_viewport_container.has_signal("gui_input"):
		map_viewport_container.gui_input.connect(on_viewport_gui_input_callback)

	# Configure map size spinboxes
	if columns_spin:
		columns_spin.min_value = 1
		columns_spin.allow_greater = true
		columns_spin.value_changed.connect(on_columns_changed_callback)
	if rows_spin:
		rows_spin.min_value = 1
		rows_spin.allow_greater = true
		rows_spin.value_changed.connect(on_rows_changed_callback)

	# Create layer selector
	var layer_spin: SpinBox = null
	if rows_spin and rows_spin.get_parent():
		var parent = rows_spin.get_parent().get_parent()  # MapSizeControls VBoxContainer
		if parent:
			var layer_row = HBoxContainer.new()
			layer_row.size_flags_horizontal = Control.SIZE_FILL
			layer_row.size_flags_vertical = Control.SIZE_SHRINK_CENTER

			var layer_label = Label.new()
			layer_label.text = "Current Layer"
			layer_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			layer_row.add_child(layer_label)

			layer_spin = SpinBox.new()
			layer_spin.custom_minimum_size = Vector2(80, 0)
			layer_spin.min_value = 0
			layer_spin.max_value = MAX_LAYERS - 1
			layer_spin.step = 1
			layer_spin.value = 0
			layer_spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			layer_spin.value_changed.connect(on_layer_spin_changed_callback)
			layer_row.add_child(layer_spin)

			parent.add_child(layer_row)

	refs["layer_spin"] = layer_spin

	# Create elevation pattern controls
	var elevation_pattern_option: OptionButton = null
	var elevation_amplitude_spin: SpinBox = null
	var generate_elevation_button: Button = null

	if rows_spin and rows_spin.get_parent():
		var parent = rows_spin.get_parent().get_parent()  # MapSizeControls VBoxContainer
		if parent:
			# Separator
			var separator = HSeparator.new()
			parent.add_child(separator)

			# Title label
			var title_label = Label.new()
			title_label.text = "Elevation Pattern"
			title_label.size_flags_horizontal = Control.SIZE_FILL
			parent.add_child(title_label)

			# Pattern type dropdown
			elevation_pattern_option = OptionButton.new()
			elevation_pattern_option.size_flags_horizontal = Control.SIZE_FILL
			elevation_pattern_option.add_item("Flat", ElevationPattern.FLAT)
			elevation_pattern_option.add_item("Random", ElevationPattern.RANDOM)
			elevation_pattern_option.add_item("Noise", ElevationPattern.NOISE)
			elevation_pattern_option.add_item("Hills", ElevationPattern.HILLS)
			elevation_pattern_option.add_item("Mountain", ElevationPattern.MOUNTAIN)
			elevation_pattern_option.add_item("Crater", ElevationPattern.CRATER)
			elevation_pattern_option.add_item("Island", ElevationPattern.ISLAND)
			elevation_pattern_option.add_item("Ridges", ElevationPattern.RIDGES)
			parent.add_child(elevation_pattern_option)

			# Amplitude control
			var amplitude_row = HBoxContainer.new()
			amplitude_row.size_flags_horizontal = Control.SIZE_FILL

			var amplitude_label = Label.new()
			amplitude_label.text = "Height"
			amplitude_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			amplitude_row.add_child(amplitude_label)

			elevation_amplitude_spin = SpinBox.new()
			elevation_amplitude_spin.custom_minimum_size = Vector2(80, 0)
			elevation_amplitude_spin.min_value = 1
			elevation_amplitude_spin.max_value = MAX_LAYERS - 1
			elevation_amplitude_spin.step = 1
			elevation_amplitude_spin.value = MAX_LAYERS - 1
			elevation_amplitude_spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			amplitude_row.add_child(elevation_amplitude_spin)

			parent.add_child(amplitude_row)

			# Generate button
			generate_elevation_button = Button.new()
			generate_elevation_button.text = "Generate Elevation"
			generate_elevation_button.size_flags_horizontal = Control.SIZE_FILL
			generate_elevation_button.pressed.connect(on_generate_elevation_callback)
			parent.add_child(generate_elevation_button)

			# === CSV ELEVATION IMPORT ===
			_create_csv_elevation_import_ui(parent, on_load_csv_callback)

			# === SURFACE FEATURES ===
			_create_surface_features_ui(parent, on_add_surface_features_callback)

			# === PLANET GENERATION CONTROLS ===
			var planet_ui_refs = _create_planet_generation_ui(
				parent,
				rng,
				on_water_slider_callback,
				on_ice_slider_callback,
				on_lava_slider_callback,
				on_earth_preset_callback,
				on_generate_planet_callback
			)
			refs.merge(planet_ui_refs)

	refs["elevation_pattern_option"] = elevation_pattern_option
	refs["elevation_amplitude_spin"] = elevation_amplitude_spin
	refs["generate_elevation_button"] = generate_elevation_button

	return refs

# ============================================================================
# PRIVATE: CSV Elevation Import UI
# ============================================================================

func _create_csv_elevation_import_ui(parent: Control, on_load_csv_callback: Callable):
	var csv_separator = HSeparator.new()
	parent.add_child(csv_separator)

	var csv_title = Label.new()
	csv_title.text = "Import Real Terrain (CSV)"
	csv_title.size_flags_horizontal = Control.SIZE_FILL
	parent.add_child(csv_title)

	# CSV file path input
	var csv_path_row = HBoxContainer.new()
	csv_path_row.size_flags_horizontal = Control.SIZE_FILL

	var csv_path_label = Label.new()
	csv_path_label.text = "Path:"
	csv_path_label.custom_minimum_size.x = 40
	csv_path_row.add_child(csv_path_label)

	var csv_path_input = LineEdit.new()
	csv_path_input.placeholder_text = "user://USGS_stlouis.csv or /absolute/path/to/file.csv"
	csv_path_input.text = "user://USGS_stlouis.csv"
	csv_path_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	csv_path_row.add_child(csv_path_input)

	parent.add_child(csv_path_row)

	# Downsample control
	var downsample_row = HBoxContainer.new()
	downsample_row.size_flags_horizontal = Control.SIZE_FILL

	var downsample_label = Label.new()
	downsample_label.text = "Downsample:"
	downsample_label.custom_minimum_size.x = 80
	downsample_row.add_child(downsample_label)

	var downsample_spin = SpinBox.new()
	downsample_spin.min_value = 1
	downsample_spin.max_value = 50
	downsample_spin.step = 1
	downsample_spin.value = 8
	downsample_spin.tooltip_text = "Skip every N rows/cols (1=full resolution, 2=half, 8=1/8th)"
	downsample_spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	downsample_row.add_child(downsample_spin)

	parent.add_child(downsample_row)

	# Chunk/Window controls
	var chunk_label = Label.new()
	chunk_label.text = "Load Region (for large CSVs):"
	chunk_label.size_flags_horizontal = Control.SIZE_FILL
	parent.add_child(chunk_label)

	# Start X,Y row
	var start_row = HBoxContainer.new()
	start_row.size_flags_horizontal = Control.SIZE_FILL

	var start_x_label = Label.new()
	start_x_label.text = "Start X:"
	start_x_label.custom_minimum_size.x = 60
	start_row.add_child(start_x_label)

	var start_x_spin = SpinBox.new()
	start_x_spin.min_value = 0
	start_x_spin.max_value = 10000
	start_x_spin.value = 0
	start_x_spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	start_row.add_child(start_x_spin)

	var start_y_label = Label.new()
	start_y_label.text = "Y:"
	start_y_label.custom_minimum_size.x = 20
	start_row.add_child(start_y_label)

	var start_y_spin = SpinBox.new()
	start_y_spin.min_value = 0
	start_y_spin.max_value = 10000
	start_y_spin.value = 0
	start_y_spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	start_row.add_child(start_y_spin)

	parent.add_child(start_row)

	# Width/Height row
	var size_row = HBoxContainer.new()
	size_row.size_flags_horizontal = Control.SIZE_FILL

	var width_label = Label.new()
	width_label.text = "Width:"
	width_label.custom_minimum_size.x = 60
	size_row.add_child(width_label)

	var width_spin = SpinBox.new()
	width_spin.min_value = 0
	width_spin.max_value = 10000
	width_spin.value = 0
	width_spin.tooltip_text = "0 = load all from start point to end"
	width_spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_row.add_child(width_spin)

	var height_label = Label.new()
	height_label.text = "H:"
	height_label.custom_minimum_size.x = 20
	size_row.add_child(height_label)

	var height_spin = SpinBox.new()
	height_spin.min_value = 0
	height_spin.max_value = 10000
	height_spin.value = 0
	height_spin.tooltip_text = "0 = load all from start point to end"
	height_spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_row.add_child(height_spin)

	parent.add_child(size_row)

	# Load CSV button
	var load_csv_button = Button.new()
	load_csv_button.text = "Load CSV Elevation"
	load_csv_button.size_flags_horizontal = Control.SIZE_FILL
	load_csv_button.pressed.connect(func(): on_load_csv_callback.call(
		csv_path_input.text,
		int(downsample_spin.value),
		int(start_x_spin.value),
		int(start_y_spin.value),
		int(width_spin.value),
		int(height_spin.value)
	))
	parent.add_child(load_csv_button)

# ============================================================================
# PRIVATE: Surface Features UI
# ============================================================================

func _create_surface_features_ui(parent: Control, on_add_surface_features_callback: Callable):
	var sf_separator = HSeparator.new()
	parent.add_child(sf_separator)

	var sf_title = Label.new()
	sf_title.text = "Surface Features"
	sf_title.size_flags_horizontal = Control.SIZE_FILL
	parent.add_child(sf_title)

	# Add Surface Features button
	var add_surface_features_button = Button.new()
	add_surface_features_button.text = "Add Trees"
	add_surface_features_button.size_flags_horizontal = Control.SIZE_FILL
	add_surface_features_button.pressed.connect(on_add_surface_features_callback)
	parent.add_child(add_surface_features_button)

# ============================================================================
# PRIVATE: Planet Generation UI
# ============================================================================

func _create_planet_generation_ui(
	parent: Control,
	rng: RandomNumberGenerator,
	on_water_slider_callback: Callable,
	on_ice_slider_callback: Callable,
	on_lava_slider_callback: Callable,
	on_earth_preset_callback: Callable,
	on_generate_planet_callback: Callable
) -> Dictionary:
	var refs = {}

	var planet_separator = HSeparator.new()
	parent.add_child(planet_separator)

	var planet_title = Label.new()
	planet_title.text = "Planet Generation"
	planet_title.size_flags_horizontal = Control.SIZE_FILL
	parent.add_child(planet_title)

	# Planet Type
	var planet_type_label = Label.new()
	planet_type_label.text = "Planet Type"
	planet_type_label.size_flags_horizontal = Control.SIZE_FILL
	parent.add_child(planet_type_label)

	var planet_type_option = OptionButton.new()
	planet_type_option.size_flags_horizontal = Control.SIZE_FILL
	planet_type_option.add_item("Rocky Small", PlanetEnums.PlanetType.ROCKY_SMALL)
	planet_type_option.add_item("Rocky Medium", PlanetEnums.PlanetType.ROCKY_MEDIUM)
	planet_type_option.add_item("Super Earth", PlanetEnums.PlanetType.SUPER_EARTH)
	planet_type_option.add_item("Ice Giant", PlanetEnums.PlanetType.ICE_GIANT)
	planet_type_option.add_item("Gas Giant", PlanetEnums.PlanetType.GAS_GIANT)
	planet_type_option.add_item("Super Jupiter", PlanetEnums.PlanetType.SUPER_JUPITER)
	planet_type_option.selected = 1  # Default to Rocky Medium
	parent.add_child(planet_type_option)
	refs["planet_type_option"] = planet_type_option

	# Surface Liquids
	var liquids_label = Label.new()
	liquids_label.text = "Surface Liquids"
	liquids_label.size_flags_horizontal = Control.SIZE_FILL
	parent.add_child(liquids_label)

	# Water slider
	var water_row = HBoxContainer.new()
	water_row.size_flags_horizontal = Control.SIZE_FILL
	var water_label = Label.new()
	water_label.text = "Water"
	water_label.custom_minimum_size.x = 60
	water_row.add_child(water_label)
	var water_slider = HSlider.new()
	water_slider.min_value = 0
	water_slider.max_value = 100
	water_slider.step = 1
	water_slider.value = 30
	water_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	water_slider.value_changed.connect(on_water_slider_callback)
	water_row.add_child(water_slider)
	var water_value_label = Label.new()
	water_value_label.text = "30%"
	water_value_label.custom_minimum_size.x = 40
	water_row.add_child(water_value_label)
	parent.add_child(water_row)
	refs["water_slider"] = water_slider
	refs["water_value_label"] = water_value_label

	# Ice slider
	var ice_row = HBoxContainer.new()
	ice_row.size_flags_horizontal = Control.SIZE_FILL
	var ice_label = Label.new()
	ice_label.text = "Ice"
	ice_label.custom_minimum_size.x = 60
	ice_row.add_child(ice_label)
	var ice_slider = HSlider.new()
	ice_slider.min_value = 0
	ice_slider.max_value = 100
	ice_slider.step = 1
	ice_slider.value = 10
	ice_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ice_slider.value_changed.connect(on_ice_slider_callback)
	ice_row.add_child(ice_slider)
	var ice_value_label = Label.new()
	ice_value_label.text = "10%"
	ice_value_label.custom_minimum_size.x = 40
	ice_row.add_child(ice_value_label)
	parent.add_child(ice_row)
	refs["ice_slider"] = ice_slider
	refs["ice_value_label"] = ice_value_label

	# Lava slider
	var lava_row = HBoxContainer.new()
	lava_row.size_flags_horizontal = Control.SIZE_FILL
	var lava_label = Label.new()
	lava_label.text = "Lava"
	lava_label.custom_minimum_size.x = 60
	lava_row.add_child(lava_label)
	var lava_slider = HSlider.new()
	lava_slider.min_value = 0
	lava_slider.max_value = 100
	lava_slider.step = 1
	lava_slider.value = 0
	lava_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lava_slider.value_changed.connect(on_lava_slider_callback)
	lava_row.add_child(lava_slider)
	var lava_value_label = Label.new()
	lava_value_label.text = "0%"
	lava_value_label.custom_minimum_size.x = 40
	lava_row.add_child(lava_value_label)
	parent.add_child(lava_row)
	refs["lava_slider"] = lava_slider
	refs["lava_value_label"] = lava_value_label

	# Geological Activity
	var geo_label = Label.new()
	geo_label.text = "Geological Activity"
	geo_label.size_flags_horizontal = Control.SIZE_FILL
	parent.add_child(geo_label)

	var geological_activity_option = OptionButton.new()
	geological_activity_option.size_flags_horizontal = Control.SIZE_FILL
	geological_activity_option.add_item("Dead", 0)
	geological_activity_option.add_item("Low", 1)
	geological_activity_option.add_item("Moderate", 2)
	geological_activity_option.add_item("High", 3)
	geological_activity_option.add_item("Extreme", 4)
	geological_activity_option.selected = 2  # Default to Moderate
	parent.add_child(geological_activity_option)
	refs["geological_activity_option"] = geological_activity_option

	# Climate Type
	var climate_label = Label.new()
	climate_label.text = "Climate Type"
	climate_label.size_flags_horizontal = Control.SIZE_FILL
	parent.add_child(climate_label)

	var climate_type_option = OptionButton.new()
	climate_type_option.size_flags_horizontal = Control.SIZE_FILL
	climate_type_option.add_item("Frozen", 0)
	climate_type_option.add_item("Cold", 1)
	climate_type_option.add_item("Temperate", 2)
	climate_type_option.add_item("Hot", 3)
	climate_type_option.add_item("Scorching", 4)
	climate_type_option.add_item("Variable", 5)
	climate_type_option.selected = 2  # Default to Temperate
	parent.add_child(climate_type_option)
	refs["climate_type_option"] = climate_type_option

	# Atmosphere Type
	var atmo_label = Label.new()
	atmo_label.text = "Atmosphere Type"
	atmo_label.size_flags_horizontal = Control.SIZE_FILL
	parent.add_child(atmo_label)

	var atmosphere_type_option = OptionButton.new()
	atmosphere_type_option.size_flags_horizontal = Control.SIZE_FILL
	atmosphere_type_option.add_item("None", PlanetEnums.AtmosphereType.NONE)
	atmosphere_type_option.add_item("Thin", PlanetEnums.AtmosphereType.THIN)
	atmosphere_type_option.add_item("Moderate", PlanetEnums.AtmosphereType.MODERATE)
	atmosphere_type_option.add_item("Thick", PlanetEnums.AtmosphereType.THICK)
	atmosphere_type_option.add_item("Dense", PlanetEnums.AtmosphereType.DENSE)
	atmosphere_type_option.add_item("Gas Giant", PlanetEnums.AtmosphereType.GAS_GIANT)
	atmosphere_type_option.selected = 2  # Default to Moderate
	parent.add_child(atmosphere_type_option)
	refs["atmosphere_type_option"] = atmosphere_type_option

	# Seed control
	var seed_row = HBoxContainer.new()
	seed_row.size_flags_horizontal = Control.SIZE_FILL
	var seed_label = Label.new()
	seed_label.text = "Seed"
	seed_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	seed_row.add_child(seed_label)

	var planet_seed_spin = SpinBox.new()
	planet_seed_spin.custom_minimum_size = Vector2(80, 0)
	planet_seed_spin.min_value = 0
	planet_seed_spin.max_value = 999999
	planet_seed_spin.step = 1
	planet_seed_spin.value = rng.randi() % 10000 if rng else randi() % 10000
	planet_seed_spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	seed_row.add_child(planet_seed_spin)
	parent.add_child(seed_row)
	refs["planet_seed_spin"] = planet_seed_spin

	# Earth-like preset button
	var earth_preset_button = Button.new()
	earth_preset_button.text = "Earth-like Preset"
	earth_preset_button.size_flags_horizontal = Control.SIZE_FILL
	earth_preset_button.pressed.connect(on_earth_preset_callback)
	parent.add_child(earth_preset_button)

	# Generate button
	var generate_planet_button = Button.new()
	generate_planet_button.text = "Generate Planet"
	generate_planet_button.size_flags_horizontal = Control.SIZE_FILL
	generate_planet_button.pressed.connect(on_generate_planet_callback)
	parent.add_child(generate_planet_button)
	refs["generate_planet_button"] = generate_planet_button

	return refs
