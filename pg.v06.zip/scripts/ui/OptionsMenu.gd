class_name OptionsMenu
extends CanvasLayer

signal closed
signal toggle_orbits_requested(show_orbits: bool)
signal open_asset_test_requested
signal seed_loaded(seed_value: int)
signal save_game_requested
signal load_game_requested
signal main_menu_requested
signal quit_requested

var panel: Panel
var orbits_button: CheckBox
var show_orbits: bool = false
var current_seed: int = 0
var seed_label: Label
var seed_input: LineEdit
var copy_button: Button

func _apply_terminal_font(label: Label) -> void:
	label.add_theme_font_override("font", TerminalTheme.get_terminal_font())

func _init(p_show_orbits: bool = false, p_current_seed: int = 0, p_star_type: String = ""):
	name = "OptionsMenu"
	show_orbits = p_show_orbits
	current_seed = p_current_seed

	panel = Panel.new()
	panel.size_flags_horizontal = Control.SIZE_FILL
	panel.size_flags_vertical = Control.SIZE_FILL
	panel.anchor_right = 1.0
	panel.anchor_bottom = 1.0

	var bg_stylebox = StyleBoxFlat.new()
	bg_stylebox.bg_color = Color(0.0, 0.0, 0.0, 0.7)
	panel.add_theme_stylebox_override("panel", bg_stylebox)
	add_child(panel)

	var content_panel = Panel.new()
	content_panel.name = "ContentPanel"
	content_panel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	content_panel.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	content_panel.custom_minimum_size = Vector2(500, 560)
	content_panel.anchors_preset = Control.PRESET_CENTER
	content_panel.anchor_left = 0.5
	content_panel.anchor_top = 0.5
	content_panel.anchor_right = 0.5
	content_panel.anchor_bottom = 0.5
	content_panel.offset_left = -250
	content_panel.offset_top = -280
	content_panel.offset_right = 250
	content_panel.offset_bottom = 280
	panel.add_child(content_panel)

	var main_container = VBoxContainer.new()
	main_container.position = Vector2(20, 20)
	main_container.size_flags_horizontal = Control.SIZE_FILL
	main_container.size_flags_vertical = Control.SIZE_FILL
	main_container.custom_minimum_size = Vector2(460, 520)
	content_panel.add_child(main_container)

	var header = HBoxContainer.new()
	header.size_flags_horizontal = Control.SIZE_FILL
	main_container.add_child(header)

	var title_label = Label.new()
	title_label.text = "Options"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	title_label.size_flags_horizontal = Control.SIZE_FILL
	title_label.add_theme_font_size_override("font_size", 24)
	_apply_terminal_font(title_label)
	header.add_child(title_label)

	var close_button = Button.new()
	close_button.text = "X"
	close_button.custom_minimum_size = Vector2(30, 30)
	close_button.pressed.connect(_on_close_button_pressed)
	header.add_child(close_button)

	var separator = HSeparator.new()
	main_container.add_child(separator)

	var options_container = VBoxContainer.new()
	options_container.size_flags_horizontal = Control.SIZE_FILL
	options_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_container.add_child(options_container)

	# --- Seed Controls ---
	var seed_label_header = Label.new()
	seed_label_header.text = "Seed Controls"
	seed_label_header.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	seed_label_header.add_theme_font_size_override("font_size", 18)
	_apply_terminal_font(seed_label_header)
	options_container.add_child(seed_label_header)

	var seed_spacer = Control.new()
	seed_spacer.custom_minimum_size.y = 10
	options_container.add_child(seed_spacer)

	var seed_display_container = HBoxContainer.new()
	seed_display_container.size_flags_horizontal = Control.SIZE_FILL
	options_container.add_child(seed_display_container)

	var current_seed_label = Label.new()
	current_seed_label.text = "Current Seed:"
	current_seed_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_apply_terminal_font(current_seed_label)
	seed_display_container.add_child(current_seed_label)

	seed_label = Label.new()
	if p_star_type.is_empty():
		seed_label.text = str(current_seed)
	else:
		seed_label.text = str(current_seed) + " | Type: " + p_star_type
	seed_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	seed_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_apply_terminal_font(seed_label)
	seed_display_container.add_child(seed_label)

	copy_button = Button.new()
	copy_button.text = "Copy"
	copy_button.tooltip_text = "Copy seed to clipboard"
	copy_button.custom_minimum_size.x = 60
	copy_button.pressed.connect(_on_copy_pressed)
	seed_display_container.add_child(copy_button)

	var seed_input_container = HBoxContainer.new()
	seed_input_container.size_flags_horizontal = Control.SIZE_FILL
	options_container.add_child(seed_input_container)

	var new_seed_label = Label.new()
	new_seed_label.text = "New Seed:"
	new_seed_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_apply_terminal_font(new_seed_label)
	seed_input_container.add_child(new_seed_label)

	seed_input = LineEdit.new()
	seed_input.placeholder_text = "Enter seed number..."
	seed_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	seed_input_container.add_child(seed_input)

	var seed_load_button = Button.new()
	seed_load_button.text = "Load"
	seed_load_button.pressed.connect(_on_seed_load_pressed)
	seed_input_container.add_child(seed_load_button)

	var random_button = Button.new()
	random_button.text = "Random"
	random_button.pressed.connect(_on_random_pressed)
	seed_input_container.add_child(random_button)

	# --- Save/Load ---
	var spacer_seed_to_save = Control.new()
	spacer_seed_to_save.custom_minimum_size.y = 20
	options_container.add_child(spacer_seed_to_save)

	var save_section_header = Label.new()
	save_section_header.text = "Game Save"
	save_section_header.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	save_section_header.add_theme_font_size_override("font_size", 18)
	_apply_terminal_font(save_section_header)
	options_container.add_child(save_section_header)

	var save_spacer = Control.new()
	save_spacer.custom_minimum_size.y = 10
	options_container.add_child(save_spacer)

	var save_buttons_row = HBoxContainer.new()
	save_buttons_row.size_flags_horizontal = Control.SIZE_FILL
	save_buttons_row.add_theme_constant_override("separation", 10)
	options_container.add_child(save_buttons_row)

	var save_button = Button.new()
	save_button.text = "Save Game"
	save_button.custom_minimum_size = Vector2(160, 36)
	save_button.pressed.connect(_on_save_game_pressed)
	save_buttons_row.add_child(save_button)

	var load_button = Button.new()
	load_button.text = "Load Game"
	load_button.custom_minimum_size = Vector2(160, 36)
	load_button.pressed.connect(_on_load_game_pressed)
	save_buttons_row.add_child(load_button)

	# --- Visual Settings ---
	var spacer2 = Control.new()
	spacer2.custom_minimum_size.y = 20
	options_container.add_child(spacer2)

	var visual_label = Label.new()
	visual_label.text = "Visual Settings"
	visual_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	visual_label.add_theme_font_size_override("font_size", 18)
	_apply_terminal_font(visual_label)
	options_container.add_child(visual_label)

	var spacer = Control.new()
	spacer.custom_minimum_size.y = 10
	options_container.add_child(spacer)

	var orbit_container = HBoxContainer.new()
	orbit_container.size_flags_horizontal = Control.SIZE_FILL
	options_container.add_child(orbit_container)

	var orbit_label = Label.new()
	orbit_label.text = "Show Orbital Paths"
	orbit_label.size_flags_horizontal = Control.SIZE_FILL
	_apply_terminal_font(orbit_label)
	orbit_container.add_child(orbit_label)

	orbits_button = CheckBox.new()
	orbits_button.button_pressed = show_orbits
	orbits_button.toggled.connect(_on_orbits_toggle)
	orbit_container.add_child(orbits_button)

	# --- Version ---
	var spacer3 = Control.new()
	spacer3.custom_minimum_size.y = 20
	options_container.add_child(spacer3)

	var version_section_header = Label.new()
	version_section_header.text = "Game Version"
	version_section_header.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	version_section_header.add_theme_font_size_override("font_size", 18)
	_apply_terminal_font(version_section_header)
	options_container.add_child(version_section_header)

	var version_spacer1 = Control.new()
	version_spacer1.custom_minimum_size.y = 10
	options_container.add_child(version_spacer1)

	var version_label = Label.new()
	version_label.text = "v%s" % Version.SHORT
	version_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	version_label.add_theme_font_size_override("font_size", 16)
	_apply_terminal_font(version_label)
	options_container.add_child(version_label)

	# --- Dev Tools ---
	var version_spacer2 = Control.new()
	version_spacer2.custom_minimum_size.y = 20
	options_container.add_child(version_spacer2)

	var dev_label = Label.new()
	dev_label.text = "Development Tools"
	dev_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	dev_label.add_theme_font_size_override("font_size", 18)
	_apply_terminal_font(dev_label)
	options_container.add_child(dev_label)

	var dev_spacer = Control.new()
	dev_spacer.custom_minimum_size.y = 10
	options_container.add_child(dev_spacer)

	var asset_test_button = Button.new()
	asset_test_button.text = "Open Sandbox"
	asset_test_button.size_flags_horizontal = Control.SIZE_FILL
	asset_test_button.custom_minimum_size = Vector2(460, 40)
	asset_test_button.pressed.connect(_on_asset_test_pressed)
	options_container.add_child(asset_test_button)

	var spacer4 = Control.new()
	spacer4.custom_minimum_size.y = 20
	options_container.add_child(spacer4)

	# --- Bottom buttons ---
	var bottom_container = HBoxContainer.new()
	bottom_container.size_flags_horizontal = Control.SIZE_FILL
	bottom_container.size_flags_vertical = Control.SIZE_SHRINK_END
	main_container.add_child(bottom_container)

	var main_menu_button = Button.new()
	main_menu_button.text = "Main Menu"
	main_menu_button.custom_minimum_size = Vector2(120, 40)
	main_menu_button.pressed.connect(_on_main_menu_pressed)
	bottom_container.add_child(main_menu_button)

	var spacer_left = Control.new()
	spacer_left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom_container.add_child(spacer_left)

	var quit_button = Button.new()
	quit_button.text = "Quit"
	quit_button.custom_minimum_size = Vector2(100, 40)
	quit_button.pressed.connect(_on_quit_pressed)
	bottom_container.add_child(quit_button)

	var btn_gap = Control.new()
	btn_gap.custom_minimum_size.x = 8
	bottom_container.add_child(btn_gap)

	var done_button = Button.new()
	done_button.text = "Done"
	done_button.custom_minimum_size = Vector2(100, 40)
	done_button.pressed.connect(_on_close_button_pressed)
	bottom_container.add_child(done_button)

	process_mode = Node.PROCESS_MODE_ALWAYS
	set_process_unhandled_key_input(true)

func _unhandled_key_input(event):
	if event.is_pressed() and event.keycode == KEY_ESCAPE:
		_on_close_button_pressed()
		get_viewport().set_input_as_handled()

func _on_close_button_pressed():
	emit_signal("closed")
	queue_free()

func _on_orbits_toggle(button_pressed: bool):
	show_orbits = button_pressed
	emit_signal("toggle_orbits_requested", show_orbits)

func _on_asset_test_pressed():
	emit_signal("open_asset_test_requested")
	_on_close_button_pressed()

func _on_copy_pressed():
	if OS.has_feature("web"):
		JavaScriptBridge.eval("navigator.clipboard.writeText('%s').catch(e => {})" % str(current_seed))
	else:
		DisplayServer.clipboard_set(str(current_seed))
	var original_text = copy_button.text
	copy_button.text = "Copied!"
	copy_button.add_theme_color_override("font_color", Color(0.2, 1.0, 0.2))
	var timer = get_tree().create_timer(1.0)
	await timer.timeout
	if copy_button and is_instance_valid(copy_button):
		copy_button.text = original_text
		copy_button.remove_theme_color_override("font_color")

func _on_seed_load_pressed():
	var input_text = seed_input.text.strip_edges()
	if input_text.is_valid_int():
		var seed_value = input_text.to_int()
		current_seed = seed_value
		emit_signal("seed_loaded", seed_value)
		_on_close_button_pressed()
	else:
		seed_input.text = ""
		seed_input.placeholder_text = "Invalid! Enter a number"

func _on_random_pressed():
	var new_seed = randi()
	emit_signal("seed_loaded", new_seed)
	_on_close_button_pressed()

func update_seed_info(seed_value: int, star_type: String = ""):
	current_seed = seed_value
	if star_type.is_empty():
		seed_label.text = str(seed_value)
	else:
		seed_label.text = str(seed_value) + " | Type: " + star_type

func _on_save_game_pressed():
	emit_signal("save_game_requested")

func _on_load_game_pressed():
	emit_signal("load_game_requested")

func _on_main_menu_pressed():
	emit_signal("main_menu_requested")
	queue_free()

func _on_quit_pressed():
	emit_signal("quit_requested")
	queue_free()
