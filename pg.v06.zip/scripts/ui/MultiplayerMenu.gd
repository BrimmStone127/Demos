# MultiplayerMenu.gd
class_name MultiplayerMenu
extends Control

signal host_selected(player_name: String)
signal join_selected(address: String, player_name: String)
signal back_selected()

func _apply_terminal_font(label: Label) -> void:
	label.add_theme_font_override("font", TerminalTheme.get_terminal_font())

func _ready():

	anchor_right = 1.0
	anchor_bottom = 1.0
	
	var bg = ColorRect.new()
	bg.color = Color(0, 0, 0, 0.9)
	bg.anchor_right = 1.0
	bg.anchor_bottom = 1.0
	add_child(bg)
	
	# Center panel
	var panel = Panel.new()
	panel.custom_minimum_size = Vector2(400, 300)
	panel.anchor_left = 0.5
	panel.anchor_top = 0.5
	panel.anchor_right = 0.5
	panel.anchor_bottom = 0.5
	panel.offset_left = -200
	panel.offset_top = -150
	panel.offset_right = 200
	panel.offset_bottom = 150
	add_child(panel)
	
	var vbox = VBoxContainer.new()
	vbox.position = Vector2(20, 20)
	vbox.custom_minimum_size = Vector2(360, 260)
	panel.add_child(vbox)
	
	var title = Label.new()
	title.text = "MULTIPLAYER SETUP"
	title.add_theme_font_size_override("font_size", 24)
	_apply_terminal_font(title)
	vbox.add_child(title)

	vbox.add_child(HSeparator.new())

	var name_label = Label.new()
	name_label.text = "Your Name:"
	_apply_terminal_font(name_label)
	vbox.add_child(name_label)
	
	var name_input = LineEdit.new()
	name_input.text = "Explorer" + str(randi() % 1000)
	name_input.name = "NameInput"
	vbox.add_child(name_input)
	
	vbox.add_child(Control.new())
	
	var host_btn = Button.new()
	host_btn.text = "HOST GAME"
	host_btn.custom_minimum_size.y = 40
	host_btn.pressed.connect(func():
		var player_name = name_input.text.strip_edges()
		if player_name == "":
			player_name = "Host"
		emit_signal("host_selected", player_name)
		queue_free()
	)
	vbox.add_child(host_btn)
	
	var join_label = Label.new()
	join_label.text = "Join Game:"
	_apply_terminal_font(join_label)
	vbox.add_child(join_label)
	
	var addr_input = LineEdit.new()
	addr_input.text = "127.0.0.1"
	addr_input.placeholder_text = "Host IP Address"
	vbox.add_child(addr_input)
	
	var join_btn = Button.new()
	join_btn.text = "JOIN GAME"
	join_btn.custom_minimum_size.y = 40
	join_btn.pressed.connect(func():
		var player_name = name_input.text.strip_edges()
		if player_name == "":
			player_name = "Guest"
		var address = addr_input.text.strip_edges()
		if address == "":
			address = "127.0.0.1"
		emit_signal("join_selected", address, player_name)
		queue_free()
	)
	vbox.add_child(join_btn)
	
	var back_btn = Button.new()
	back_btn.text = "BACK"
	back_btn.pressed.connect(func():
		emit_signal("back_selected")
		queue_free()
	)
	vbox.add_child(back_btn)
