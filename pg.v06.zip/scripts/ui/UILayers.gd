class_name UILayers
extends RefCounted

## Centralized CanvasLayer constants for UI rendering order.
## Higher numbers render on top of lower numbers.
##
## Layer ranges:
##   0-99:     Game world, backgrounds
##   100-499:  In-game UI (dialogue, HUD)
##   500-999:  Menus, panels
##   1000:     Transitions (fade to/from black)
##   1100+:    Cutscenes, narrative sequences (must be above transitions)

# In-game dialogue (shows during gameplay)
const DIALOGUE_SYSTEM := 100

# Menus and panels
const MENUS := 500

# Screen transitions (fade to black, etc.)
const TRANSITIONS := 1000

# Narrative sequences (intro, cutscenes - must be above transitions)
const NARRATIVE := 1100
