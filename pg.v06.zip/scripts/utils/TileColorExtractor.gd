class_name TileColorExtractor
extends RefCounted

## Extracts unique colors from tileset tiles
##
## Analyzes tile regions and returns most common colors sorted by frequency.
## Similar to tools/extract_palette.py but implemented in GDScript.

## Extract colors from a tile at given atlas coordinates
static func extract_colors(atlas_coords: Vector2i, max_colors: int = 8) -> Array[Dictionary]:
	"""
	Extract unique colors from a tile.

	Returns Array of {color: Color, count: int, percent: float}
	sorted by frequency (most common first).
	"""
	var tileset = PlanetMapTileConfig.TILESET_TEXTURE
	if not tileset:
		push_error("TileColorExtractor: Failed to load tileset texture")
		return []

	var tile_size = PlanetMapTileConfig.TILESET_SOURCE_TILE_SIZE
	var region = Rect2(atlas_coords * tile_size, tile_size)

	# Get the texture image
	var image = tileset.get_image()
	if not image:
		push_error("TileColorExtractor: Failed to get image from texture")
		return []

	# Count color frequency
	var color_counts: Dictionary = {}  # Color -> int
	var total_pixels = 0

	for y in range(region.position.y, region.position.y + region.size.y):
		for x in range(region.position.x, region.position.x + region.size.x):
			var color = image.get_pixel(x, y)

			# Skip fully transparent pixels
			if color.a < 0.01:
				continue

			total_pixels += 1

			# Round color channels slightly to group similar colors
			var rounded = Color(
				snappedf(color.r, 0.001),
				snappedf(color.g, 0.001),
				snappedf(color.b, 0.001),
				snappedf(color.a, 0.001)
			)

			if color_counts.has(rounded):
				color_counts[rounded] += 1
			else:
				color_counts[rounded] = 1

	# Convert to array and sort by frequency
	var color_array: Array[Dictionary] = []
	for color in color_counts:
		var count = color_counts[color]
		var percent = (float(count) / float(total_pixels)) * 100.0 if total_pixels > 0 else 0.0

		color_array.append({
			"color": color,
			"count": count,
			"percent": percent
		})

	# Sort by count (descending)
	color_array.sort_custom(func(a, b): return a.count > b.count)

	# Return top N colors
	var result: Array[Dictionary] = []
	for i in range(min(max_colors, color_array.size())):
		result.append(color_array[i])

	return result

## Convert Color to hex string
static func color_to_hex(color: Color) -> String:
	return "#%02x%02x%02x%02x" % [
		int(color.r * 255),
		int(color.g * 255),
		int(color.b * 255),
		int(color.a * 255)
	]

## Convert Color to RGB string
static func color_to_rgb(color: Color) -> String:
	return "RGB(%d, %d, %d)" % [
		int(color.r * 255),
		int(color.g * 255),
		int(color.b * 255)
	]

## Convert Color to GDScript code
static func color_to_gdscript(color: Color) -> String:
	return "Color(%.3f, %.3f, %.3f, %.3f)" % [color.r, color.g, color.b, color.a]
