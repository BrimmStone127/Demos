class_name PaletteSwapper
extends RefCounted

## Helper for applying color palette swaps to TileMaps
##
## Usage:
##   var swapper = PaletteSwapper.new()
##   swapper.add_color_swap(Color(0.122, 0.086, 0.0), Color(0.2, 0.2, 0.4))  # Brown -> Blue
##   swapper.apply_to_tilemap(my_tilemap)
##
## Or use the colorblind-friendly presets:
##   PaletteSwapper.apply_deuteranopia_friendly(my_tilemap)

## The shader material being configured
var material: ShaderMaterial

## Color pairs to swap (source -> target)
var _color_pairs: Array[Dictionary] = []

func _init():
	var shader = load("res://shaders/palette_swap.gdshader")
	material = ShaderMaterial.new()
	material.shader = shader
	material.set_shader_parameter("enabled", true)
	material.set_shader_parameter("color_tolerance", 0.01)

## Add a color swap from source to target
func add_color_swap(source_color: Color, target_color: Color) -> void:
	_color_pairs.append({"source": source_color, "target": target_color})

## Apply all configured swaps to a TileMap
func apply_to_tilemap(tilemap: TileMap) -> void:
	_configure_shader()
	tilemap.material = material

## Apply all configured swaps to a Sprite2D
## brightness: elevation brightness multiplier (0.6 to 1.0)
func apply_to_sprite(sprite: Sprite2D, brightness: float = 1.0) -> void:
	_configure_shader()
	# CRITICAL: Duplicate material for each sprite so they can have independent brightness values
	var sprite_material = material.duplicate()
	# Set elevation brightness as a shader uniform
	var modulate_color = Color(brightness, brightness, brightness, 1.0)
	sprite_material.set_shader_parameter("modulate_color", modulate_color)
	sprite.material = sprite_material

## Configure the shader and return the material without assigning it anywhere.
## Use this to get a shared material instance that can be applied to many sprites.
## When sharing, apply brightness via sprite.modulate instead of the shader uniform.
func get_material() -> ShaderMaterial:
	_configure_shader()
	return material

## Clear all color swaps
func clear_swaps() -> void:
	_color_pairs.clear()

## Set color matching tolerance (default 0.01)
func set_tolerance(tolerance: float) -> void:
	material.set_shader_parameter("color_tolerance", tolerance)

## Enable or disable the shader
func set_enabled(enabled: bool) -> void:
	material.set_shader_parameter("enabled", enabled)

func _configure_shader() -> void:
	for i in range(min(_color_pairs.size(), 8)):  # Max 8 color pairs
		var pair = _color_pairs[i]
		var param_index = i + 1
		material.set_shader_parameter("color_source_%d" % param_index, pair.source)
		material.set_shader_parameter("color_target_%d" % param_index, pair.target)

## Static helper: Extract colors from a specific tile in the tileset
static func get_tile_colors(_tile_row: int, _tile_col: int) -> Dictionary:
	## Returns a dictionary with common tree colors for the dormant and veg trees
	## This is a reference - use tools/extract_palette.py for exact colors

	# Dormant tree colors (Row 3, Cols 13-18)
	var dormant_colors = {
		"trunk_dark": Color(0.122, 0.086, 0.0, 1.0),    # #1f1600
		"trunk_light": Color(0.267, 0.102, 0.027, 1.0),  # #441a07
		"leaf_1": Color(0.047, 0.298, 0.098, 1.0),       # #0c4c19
		"leaf_2": Color(0.106, 0.345, 0.082, 1.0),       # #1b5815
		"leaf_3": Color(0.133, 0.420, 0.086, 1.0),       # #226b16
		"leaf_4": Color(0.024, 0.231, 0.067, 1.0),       # #063b11
	}

	return dormant_colors

## Preset: Deuteranopia-friendly palette (red-green colorblind)
static func create_deuteranopia_friendly() -> PaletteSwapper:
	var swapper = PaletteSwapper.new()
	var colors = get_tile_colors(3, 13)

	# Make greens more distinguishable using blue channel
	swapper.add_color_swap(colors.leaf_1, Color(0.05, 0.35, 0.45, 1.0))  # Add blue
	swapper.add_color_swap(colors.leaf_2, Color(0.08, 0.40, 0.50, 1.0))
	swapper.add_color_swap(colors.leaf_3, Color(0.10, 0.48, 0.55, 1.0))
	swapper.add_color_swap(colors.leaf_4, Color(0.02, 0.28, 0.40, 1.0))

	return swapper

## Preset: Protanopia-friendly palette (red colorblind)
static func create_protanopia_friendly() -> PaletteSwapper:
	var swapper = PaletteSwapper.new()
	var colors = get_tile_colors(3, 13)

	# Boost greens and blues, reduce reds
	swapper.add_color_swap(colors.trunk_dark, Color(0.08, 0.10, 0.0, 1.0))
	swapper.add_color_swap(colors.trunk_light, Color(0.16, 0.14, 0.03, 1.0))
	swapper.add_color_swap(colors.leaf_1, Color(0.03, 0.36, 0.12, 1.0))
	swapper.add_color_swap(colors.leaf_2, Color(0.06, 0.41, 0.10, 1.0))

	return swapper

## Preset: Tritanopia-friendly palette (blue-yellow colorblind)
static func create_tritanopia_friendly() -> PaletteSwapper:
	var swapper = PaletteSwapper.new()
	var colors = get_tile_colors(3, 13)

	# Emphasize reds and greens, reduce blues
	swapper.add_color_swap(colors.trunk_dark, Color(0.15, 0.09, 0.0, 1.0))
	swapper.add_color_swap(colors.trunk_light, Color(0.32, 0.11, 0.01, 1.0))
	swapper.add_color_swap(colors.leaf_1, Color(0.06, 0.33, 0.07, 1.0))
	swapper.add_color_swap(colors.leaf_2, Color(0.12, 0.38, 0.06, 1.0))

	return swapper

## Example: Custom palette with higher contrast
static func create_high_contrast() -> PaletteSwapper:
	var swapper = PaletteSwapper.new()
	var colors = get_tile_colors(3, 13)

	# Make colors more vibrant and distinct
	swapper.add_color_swap(colors.trunk_dark, Color(0.25, 0.15, 0.0, 1.0))    # Brighter brown
	swapper.add_color_swap(colors.trunk_light, Color(0.45, 0.20, 0.05, 1.0))  # Much lighter brown
	swapper.add_color_swap(colors.leaf_1, Color(0.1, 0.5, 0.2, 1.0))          # Brighter greens
	swapper.add_color_swap(colors.leaf_2, Color(0.15, 0.6, 0.15, 1.0))
	swapper.add_color_swap(colors.leaf_3, Color(0.2, 0.7, 0.2, 1.0))
	swapper.add_color_swap(colors.leaf_4, Color(0.05, 0.4, 0.1, 1.0))

	return swapper

## Preset: Verdant variant for vegetative maple trees
## Shifts olive/yellow-greens to lush, vibrant emerald greens
static func create_verdant() -> PaletteSwapper:
	var swapper = PaletteSwapper.new()

	# Vegetative tree colors (Row 4, Cols 13-18) - extracted from tileset
	# Original colors are olive/yellow-greens, shift to vibrant emerald greens
	swapper.add_color_swap(
		Color(0.361, 0.447, 0.055, 1.0),  # #5c720e - Olive green
		Color(0.20, 0.60, 0.20, 1.0)      # Vibrant emerald green
	)
	swapper.add_color_swap(
		Color(0.267, 0.333, 0.035, 1.0),  # #445509 - Dark olive
		Color(0.12, 0.45, 0.12, 1.0)      # Dark emerald green
	)
	swapper.add_color_swap(
		Color(0.278, 0.235, 0.008, 1.0),  # #473c02 - Dark brown-olive
		Color(0.08, 0.30, 0.08, 1.0)      # Very dark green
	)

	return swapper
