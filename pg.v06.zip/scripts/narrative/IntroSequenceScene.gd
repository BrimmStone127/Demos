class_name IntroSequenceScene
extends CanvasLayer

const LOG_TAG := "INTRO_SCENE"

signal sequence_finished

var intro_manager: IntroSequenceManager
var is_playing: bool = false

# UI elements
var black_background: ColorRect
var ui_container: Control
var current_dialogue_box: DialogueBox

# For branching conversations
var conversation: Conversation

func _init():
	name = "IntroSequenceScene"
	# Must be above TransitionManager since fade_to_black keeps
	# the overlay visible during intro sequence
	layer = UILayers.NARRATIVE

func _ready():
	_create_ui_container()
	_create_black_background()

func _create_ui_container():
	ui_container = Control.new()
	ui_container.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(ui_container)

func _create_black_background():
	black_background = ColorRect.new()
	black_background.color = Color(0, 0, 0, 1)
	black_background.set_anchors_preset(Control.PRESET_FULL_RECT)
	black_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_container.add_child(black_background)

func start_sequence(manager: IntroSequenceManager, seed_value: int):
	intro_manager = manager
	var sequence = intro_manager.start_sequence(seed_value)

	if sequence.is_empty():
		GameLog.error(LOG_TAG, "Failed to start intro sequence")
		_finish_sequence()
		return

	is_playing = true

	# Check if this intro uses branching conversations
	if intro_manager.has_conversation():
		conversation = intro_manager.get_conversation()
		if not conversation:
			GameLog.error(LOG_TAG, "Failed to load conversation")
			_finish_sequence()
			return

		GameLog.info(LOG_TAG, "Starting branching conversation")
		conversation.conversation_ended.connect(_on_conversation_ended)
		conversation.start()
		_show_current_dialogue()
	else:
		GameLog.warn(LOG_TAG, "No conversation found in intro sequence")
		_finish_sequence()

func _show_current_dialogue():
	if not is_playing or not conversation:
		return

	var dialogue_data = conversation.get_current()
	if not dialogue_data:
		_finish_sequence()
		return

	GameLog.info(LOG_TAG, "Showing dialogue: %s" % dialogue_data.text)

	# Create new dialogue box
	current_dialogue_box = DialogueBox.new()
	ui_container.add_child(current_dialogue_box)

	# Wait for ready
	await get_tree().process_frame

	# Apply theme
	TerminalTheme.apply_recursive(current_dialogue_box)

	# Connect signals
	current_dialogue_box.dialogue_finished.connect(_on_dialogue_finished)
	current_dialogue_box.choice_selected.connect(_on_choice_selected)

	# Display dialogue
	current_dialogue_box.display_dialogue(dialogue_data)

var _pending_choice_index: int = -1

func _on_choice_selected(choice_index: int):
	GameLog.info(LOG_TAG, "Choice selected: %d" % choice_index)
	_pending_choice_index = choice_index

func _on_dialogue_finished():
	if not conversation or not is_playing:
		return

	# Clean up current dialogue box reference
	if current_dialogue_box and is_instance_valid(current_dialogue_box):
		current_dialogue_box.queue_free()
		current_dialogue_box = null

	# Check if a choice was made
	if _pending_choice_index >= 0:
		conversation.select_choice(_pending_choice_index)
		_pending_choice_index = -1

		if conversation and conversation.is_active:
			_show_current_dialogue()
	elif conversation.get_choice_count() == 0:
		# No choices available - end conversation
		conversation.end()

func _on_conversation_ended():
	_finish_sequence()

func _finish_sequence():
	is_playing = false

	# Clean up dialogue box
	if current_dialogue_box and is_instance_valid(current_dialogue_box):
		current_dialogue_box.queue_free()
		current_dialogue_box = null

	# Clean up conversation
	if conversation:
		if conversation.conversation_ended.is_connected(_on_conversation_ended):
			conversation.conversation_ended.disconnect(_on_conversation_ended)
		conversation = null

	if intro_manager:
		intro_manager.complete_sequence()

	GameLog.info(LOG_TAG, "Intro sequence finished")
	emit_signal("sequence_finished")

func skip_sequence():
	if not is_playing:
		return

	GameLog.info(LOG_TAG, "Skipping intro sequence")

	if current_dialogue_box and is_instance_valid(current_dialogue_box):
		current_dialogue_box.close_dialogue()

	_finish_sequence()

func _input(event):
	if not is_playing:
		return

	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_ESCAPE:
			skip_sequence()
			get_viewport().set_input_as_handled()
