class_name IntroSequenceManager
extends Node

const LOG_TAG := "INTRO_SEQUENCE"

signal sequence_started(intro_id: String)
signal sequence_completed(intro_id: String)
signal sequence_failed(error_message: String)

var intro_data: Dictionary = {}
var current_sequence: Dictionary = {}
var game_seed: int = 0

const INTRO_DATA_PATH = "res://assets/narrative/intro_sequences.json"

func _ready():
	_load_intro_data()

func _load_intro_data() -> bool:
	if not FileAccess.file_exists(INTRO_DATA_PATH):
		GameLog.error(LOG_TAG, "Intro sequences file not found: %s" % INTRO_DATA_PATH)
		return false

	var file = FileAccess.open(INTRO_DATA_PATH, FileAccess.READ)
	if not file:
		GameLog.error(LOG_TAG, "Failed to open intro sequences file")
		return false

	var json_text = file.get_as_text()
	file.close()

	var json = JSON.new()
	var parse_result = json.parse(json_text)

	if parse_result != OK:
		GameLog.error(LOG_TAG, "Failed to parse intro sequences JSON: %s" % json.get_error_message())
		return false

	intro_data = json.get_data()

	if not intro_data.has("intro_sequences"):
		GameLog.error(LOG_TAG, "Invalid intro data format: missing 'intro_sequences' key")
		return false

	GameLog.info(LOG_TAG, "Loaded %d intro sequences" % intro_data.intro_sequences.size())
	return true

func select_intro_for_seed(seed_value: int) -> Dictionary:
	if not intro_data.has("intro_sequences"):
		GameLog.error(LOG_TAG, "No intro sequences loaded")
		return {}

	var sequences = intro_data.intro_sequences

	for sequence in sequences:
		if not sequence.has("seed_range"):
			continue

		var seed_range = sequence.seed_range
		if seed_range.size() < 2:
			continue

		var min_seed = seed_range[0]
		var max_seed = seed_range[1]

		if seed_value >= min_seed and seed_value <= max_seed:
			GameLog.info(LOG_TAG, "Selected intro '%s' for seed %d" % [sequence.id, seed_value])
			return sequence

	GameLog.warn(LOG_TAG, "No intro found for seed %d, using first sequence" % seed_value)
	return sequences[0] if sequences.size() > 0 else {}

func start_sequence(seed_value: int) -> Dictionary:
	game_seed = seed_value
	current_sequence = select_intro_for_seed(seed_value)

	if current_sequence.is_empty():
		GameLog.error(LOG_TAG, "Failed to select intro sequence")
		emit_signal("sequence_failed", "No intro sequence available")
		return {}

	GameLog.info(LOG_TAG, "Starting intro sequence: %s" % current_sequence.id)
	emit_signal("sequence_started", current_sequence.id)
	return current_sequence

func get_dialogues() -> Array:
	# Legacy support for linear dialogues
	if current_sequence.is_empty() or not current_sequence.has("dialogues"):
		return []
	return current_sequence.dialogues

func get_conversation() -> Conversation:
	# New branching conversation support
	if current_sequence.is_empty() or not current_sequence.has("conversation"):
		return null
	return ConversationLoader.load_from_dict(current_sequence.conversation)

func has_conversation() -> bool:
	return current_sequence.has("conversation")

func convert_to_dialogue_data(dialogue_dict: Dictionary) -> DialogueData:
	var data = DialogueData.new()
	data.speaker = dialogue_dict.get("speaker", "")
	data.text = dialogue_dict.get("text", "")
	data.typing_speed = dialogue_dict.get("typing_speed", 0.05)
	data.auto_close_time = dialogue_dict.get("auto_close_time", 0.0)

	if dialogue_dict.has("choices") and dialogue_dict.choices is Array:
		data.choices = dialogue_dict.choices

	return data

func complete_sequence():
	if current_sequence.is_empty():
		return

	var intro_id = current_sequence.id
	GameLog.info(LOG_TAG, "Completed intro sequence: %s" % intro_id)
	emit_signal("sequence_completed", intro_id)
	current_sequence = {}
