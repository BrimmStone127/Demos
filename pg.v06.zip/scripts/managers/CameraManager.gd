class_name CameraManager
extends Node

const LOG_TAG := "CAMERA_MANAGER"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))

# Signals for communication with other systems
signal camera_panned
signal camera_state_changed(is_tracking: bool, is_moved: bool)

# Camera reference
var game_camera: GameCamera

# State tracking
var currently_tracking_planet: Planet = null
var has_panned: bool = false
var is_tracking: bool = false

func _init():
	name = "CameraManager"

func setup_camera():
	"""Initialize the game camera"""
	game_camera = GameCamera.new()
	add_child(game_camera)
	game_camera.make_current()
	
	# Add camera manager to a group so other systems can find it
	add_to_group("camera_manager")
	
	# Connect camera signals
	game_camera.camera_panned.connect(_on_camera_panned)
	
	_log_info('Camera system initialized')

func track_object(object: Node2D, custom_zoom: float = -1):
	"""Start tracking a specific object"""
	if not object or not is_instance_valid(object):
		_log_warn('Warning: Attempted to track an invalid object')
		return
	
	if not game_camera or not is_instance_valid(game_camera):
		_log_warn('Warning: Camera not available for tracking')
		return
	
	var current_zoom = game_camera.zoom_level if custom_zoom <= 0 else custom_zoom
	game_camera.track_object(object, Vector2.ZERO, current_zoom)
	
	currently_tracking_planet = object if object is Planet else null
	is_tracking = true
	has_panned = true
	
	_emit_state_change()
	_log_info('Now tracking: %s', [_get_object_name(object)])

func stop_tracking():
	"""Stop tracking the current object"""
	if game_camera and is_instance_valid(game_camera):
		game_camera.stop_tracking()
	
	currently_tracking_planet = null
	is_tracking = false
	
	_emit_state_change()
	_log_info('Stopped tracking')

func reset_camera():
	"""Reset camera to center position"""
	if not game_camera or not is_instance_valid(game_camera):
		_log_warn('Warning: Camera not available for reset')
		return
	
	var current_zoom = game_camera.zoom_level
	game_camera.reset_position()
	game_camera.zoom_level = current_zoom
	game_camera.zoom = Vector2(current_zoom, current_zoom)
	
	# Stop any tracking
	stop_tracking()
	has_panned = false
	
	_emit_state_change()
	_log_info('Camera reset to center')

func focus_on_star_system():
	"""Focus camera on the star system center"""
	if not game_camera or not is_instance_valid(game_camera):
		_log_warn('Warning: Camera not available for focusing')
		return
	
	var current_zoom = game_camera.zoom_level
	game_camera.reset_position()
	game_camera.zoom_level = current_zoom
	game_camera.zoom = Vector2(current_zoom, current_zoom)
	
	stop_tracking()
	
	_log_info('Camera focused on star system')

func make_camera_current():
	"""Ensure the game camera is the current active camera"""
	if game_camera and is_instance_valid(game_camera):
		game_camera.make_current()

func get_camera_state() -> Dictionary:
	"""Get current camera state information"""
	if not game_camera or not is_instance_valid(game_camera):
		return {
			"valid": false,
			"position": Vector2.ZERO,
			"zoom": 1.0,
			"is_tracking": false,
			"has_panned": false
		}
	
	return {
		"valid": true,
		"position": game_camera.position,
		"zoom": game_camera.zoom_level,
		"is_tracking": is_tracking,
		"has_panned": has_panned,
		"tracking_target": _get_object_name(currently_tracking_planet) if currently_tracking_planet else ""
	}

func cleanup():
	"""Clean up camera resources"""
	stop_tracking()
	
	if game_camera and is_instance_valid(game_camera):
		game_camera.queue_free()
		game_camera = null
	
	currently_tracking_planet = null

# Private helper methods
func _on_camera_panned():
	"""Handle camera panned signal"""
	if not has_panned:
		has_panned = true
		_emit_state_change()
	
	emit_signal("camera_panned")

func _emit_state_change():
	"""Emit camera state change signal"""
	emit_signal("camera_state_changed", is_tracking, has_panned)

func _get_object_name(object) -> String:
	"""Get display name for an object"""
	if not object or not is_instance_valid(object):
		return "None"
	
	if object.has_method("get") and "planet_name" in object:
		return object.planet_name
	elif object.has_method("get") and "star_name" in object:
		return object.star_name
	elif object.has_method("get_name"):
		return object.get_name()
	else:
		return object.get_class()
