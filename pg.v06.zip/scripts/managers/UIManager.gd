# UIManager.gd - Centralized UI management
class_name UIManager
extends Node

const LOG_TAG := "UI_MANAGER"
const SandboxScene = preload("res://scenes/SandboxApp.tscn")  # New modular sandbox

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))

# Signals for UI events
signal control_panel_new_system_requested()
signal control_panel_options_requested()
signal control_panel_ai_toggle_requested()
signal camera_reset_requested()
signal camera_stop_tracking_requested()
signal celestial_body_selected(body: Node2D)
signal stats_panel_clicked()
signal info_panel_closed()
signal options_menu_closed()
signal options_toggle_orbits_requested(enabled: bool)
signal options_seed_loaded(seed_value: int)
signal asset_test_requested()
signal save_game_requested()
signal load_game_requested()
signal save_to_slot_requested(slot_id: String, is_new: bool)
signal load_from_slot_requested(slot_id: String)
signal asset_test_closed()
signal info_panel_restore_requested
signal main_menu_requested
signal quit_requested

# UI References
var ui_state_before_planet_view: Dictionary = {}
var canvas_layer: CanvasLayer
var control_panel: ControlPanel
var time_control_panel: TimeControlPanel
var camera_control_panel: CameraControlPanel
var stats_panel: StatsPanel
var current_info_panel: CelestialInfoPanelMVC = null
var options_menu: OptionsMenu = null
var sandbox_scene: SandboxApp = null
var loading_indicator: Control = null
var start_screen: StartScreen = null
var save_list_dialog: SaveListDialog = null
var save_game_manager: SaveGameManager = null

# Dependencies
var system_history: StarSystemHistory
var time_manager: TimeManager
var foundation: Foundation

# State tracking
var is_options_open: bool = false
var was_showing_info_panel: bool = false

func _init():
	name = "UIManager"

func initialize(p_canvas_layer: CanvasLayer, p_system_history: StarSystemHistory, p_time_manager: TimeManager = null):
	canvas_layer = p_canvas_layer
	system_history = p_system_history
	time_manager = p_time_manager
	_create_loading_indicator()

func setup_game_ui():
	"""Setup all game UI components after game starts"""
	_setup_control_panel()
	_setup_time_control_panel()
	_setup_camera_control_panel()
	_setup_stats_panel()

func _setup_control_panel():
	control_panel = ControlPanel.new()
	control_panel.new_system_requested.connect(func(): emit_signal("control_panel_new_system_requested"))
	control_panel.options_requested.connect(func(): emit_signal("control_panel_options_requested"))
	control_panel.ai_toggle_requested.connect(func(): emit_signal("control_panel_ai_toggle_requested"))
	canvas_layer.add_child(control_panel)
	TerminalTheme.apply_recursive(control_panel)

func _setup_time_control_panel():
	if not canvas_layer:
		return
	if time_control_panel and is_instance_valid(time_control_panel):
		return
	time_control_panel = TimeControlPanel.new()
	if time_manager:
		time_control_panel.set_time_manager(time_manager)
	time_control_panel.time_scale_changed.connect(_on_time_control_scale_changed)
	canvas_layer.add_child(time_control_panel)
	TerminalTheme.apply_recursive(time_control_panel)

func _setup_camera_control_panel():
	camera_control_panel = CameraControlPanel.new()
	camera_control_panel.reset_camera_requested.connect(func(): emit_signal("camera_reset_requested"))
	camera_control_panel.stop_tracking_requested.connect(func(): emit_signal("camera_stop_tracking_requested"))
	camera_control_panel.celestial_body_clicked.connect(func(body): emit_signal("celestial_body_selected", body))
	canvas_layer.add_child(camera_control_panel)
	TerminalTheme.apply_recursive(camera_control_panel)

func set_star_system(star_system: Node2D):
	"""Update the camera control panel with the current star system"""
	if camera_control_panel and is_instance_valid(camera_control_panel):
		camera_control_panel.set_star_system(star_system)

func set_selected_celestial_body(body: Node2D):
	"""Update which celestial body is shown as selected in the camera control panel"""
	if camera_control_panel and is_instance_valid(camera_control_panel):
		camera_control_panel.set_selected_body(body)

func _setup_stats_panel():
	stats_panel = StatsPanel.new(system_history, foundation)
	stats_panel.stats_panel_clicked.connect(func(): emit_signal("stats_panel_clicked"))
	canvas_layer.add_child(stats_panel)
	TerminalTheme.apply_recursive(stats_panel)

func _on_time_control_scale_changed(scale: float):
	if time_manager:
		time_manager.set_time_scale(scale)
	else:
		_log_warn('TimeManager missing, cannot apply time scale change', [])

func _create_loading_indicator():
	loading_indicator = Control.new()
	loading_indicator.visible = false
	loading_indicator.anchor_right = 1.0
	loading_indicator.anchor_bottom = 1.0
	canvas_layer.add_child(loading_indicator)
	
	var panel = Panel.new()
	panel.anchor_right = 1.0
	panel.anchor_bottom = 1.0
	panel.modulate = Color(0, 0, 0, 0.7)
	loading_indicator.add_child(panel)
	
	var label = Label.new()
	label.text = "Generating Star System..."
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.anchor_right = 1.0
	label.anchor_bottom = 1.0
	label.add_theme_font_size_override("font_size", 24)
	loading_indicator.add_child(label)
	
	TerminalTheme.apply_to_label(label)


func debug_ui_state():
	"""Debug function to print current UI state"""
	_log_debug('=== UI STATE DEBUG ===')
	_log_info('ControlPanel: %s valid: %s visible: %s', [control_panel != null, is_instance_valid(control_panel) if control_panel else false, str(control_panel.visible) if (control_panel and is_instance_valid(control_panel)) else "N/A"])
	_log_info('TimeControlPanel: %s valid: %s visible: %s', [time_control_panel != null, is_instance_valid(time_control_panel) if time_control_panel else false, str(time_control_panel.visible) if (time_control_panel and is_instance_valid(time_control_panel)) else "N/A"])
	_log_info('CameraControlPanel: %s valid: %s visible: %s', [camera_control_panel != null, is_instance_valid(camera_control_panel) if camera_control_panel else false, str(camera_control_panel.visible) if (camera_control_panel and is_instance_valid(camera_control_panel)) else "N/A"])
	_log_info('StatsPanel: %s valid: %s visible: %s', [stats_panel != null, is_instance_valid(stats_panel) if stats_panel else false, str(stats_panel.visible) if (stats_panel and is_instance_valid(stats_panel)) else "N/A"])
	_log_info('InfoPanel: %s valid: %s visible: %s', [current_info_panel != null, is_instance_valid(current_info_panel) if current_info_panel else false, str(current_info_panel.visible) if (current_info_panel and is_instance_valid(current_info_panel)) else "N/A"])
	_log_info('Canvas Layer children: %s', [str(canvas_layer.get_child_count()) if canvas_layer else "No canvas layer"])
	_log_debug('=====================')

func _ensure_ui_elements_exist():
	"""Ensure all UI elements still exist, recreate if necessary"""
	_log_info('UIManager: Checking if UI elements need recreation...')
	
	# Check control panel
	if not control_panel or not is_instance_valid(control_panel):
		_log_info('  Recreating ControlPanel...')
		_setup_control_panel()
	
	# Check time control panel
	if not time_control_panel or not is_instance_valid(time_control_panel):
		_log_info('  Recreating TimeControlPanel...')
		_setup_time_control_panel()
	
	# Check camera control panel
	if not camera_control_panel or not is_instance_valid(camera_control_panel):
		_log_info('  Recreating CameraControlPanel...')
		_setup_camera_control_panel()
	
	# Check stats panel
	if not stats_panel or not is_instance_valid(stats_panel):
		_log_info('  Recreating StatsPanel...')
		_setup_stats_panel()
	
	_log_info('UIManager: UI elements verification complete')

func restore_system_ui():
	"""Restore system UI elements when returning from planet view"""
	_log_info('UIManager: Restoring system UI elements...')
	_log_info('  Restoring from state: %s', [ui_state_before_planet_view])
	
	# Check if we have a valid state to restore
	if ui_state_before_planet_view.is_empty():
		_log_warn('  Warning: No UI state stored, using default visibility')
		# Default to showing main UI elements
		ui_state_before_planet_view = {
			"control_panel_visible": true,
			"time_control_panel_visible": true,
			"camera_control_panel_visible": true,
			"stats_panel_visible": true,
			"info_panel_visible": false,  # Info panel should only show if it was showing before
			"options_menu_visible": false
		}
	
	# Check if we need to recreate any UI elements that might have been destroyed
	_ensure_ui_elements_exist()
	
	# Restore visibility based on stored state
	if control_panel and is_instance_valid(control_panel):
		var should_show = ui_state_before_planet_view.get("control_panel_visible", true)
		control_panel.visible = should_show
		_log_info('  Restored: ControlPanel (%s)', [should_show])
	else:
		_log_info('  ControlPanel not valid for restoration')
	
	if time_control_panel and is_instance_valid(time_control_panel):
		var should_show = ui_state_before_planet_view.get("time_control_panel_visible", true)
		time_control_panel.visible = should_show
		_log_info('  Restored: TimeControlPanel (%s)', [should_show])
	else:
		_log_info('  TimeControlPanel not valid for restoration')
	
	if camera_control_panel and is_instance_valid(camera_control_panel):
		var should_show = ui_state_before_planet_view.get("camera_control_panel_visible", true)
		camera_control_panel.visible = should_show
		_log_info('  Restored: CameraControlPanel (%s)', [should_show])
	else:
		_log_info('  CameraControlPanel not valid for restoration')
	
	if stats_panel and is_instance_valid(stats_panel):
		var should_show = ui_state_before_planet_view.get("stats_panel_visible", true)
		stats_panel.visible = should_show
		_log_info('  Restored: StatsPanel (%s)', [should_show])
	else:
		_log_info('  StatsPanel not valid for restoration')
	
	if current_info_panel and is_instance_valid(current_info_panel):
		var should_show = ui_state_before_planet_view.get("info_panel_visible", false)
		current_info_panel.visible = should_show
		_log_info('  Restored: CelestialInfoPanel (%s)', [should_show])
	else:
		_log_info('  CelestialInfoPanel not valid for restoration')
	
	# Clear the stored state
	ui_state_before_planet_view.clear()
	
	_log_info('UIManager: System UI restored successfully')

func reset_ui_state():
	"""Reset stored UI state - useful for debugging or if state gets corrupted"""
	_log_info('UIManager: Resetting stored UI state')
	ui_state_before_planet_view.clear()

# Add a method to check if UI state is stored
func has_stored_ui_state() -> bool:
	"""Check if UI state is currently stored"""
	return not ui_state_before_planet_view.is_empty()

func hide_all_system_ui():
	"""Hide all system UI elements when transitioning to planet view - IMPROVED WITH STATE PROTECTION"""
	_log_info('UIManager: Hiding all system UI elements...')
	
	# Only store state if we don't already have it (prevent overwriting correct state)
	if ui_state_before_planet_view.is_empty():
		# Store current visibility state BEFORE hiding
		ui_state_before_planet_view = {
			"control_panel_visible": control_panel.visible if (control_panel and is_instance_valid(control_panel)) else false,
			"time_control_panel_visible": time_control_panel.visible if (time_control_panel and is_instance_valid(time_control_panel)) else false,
			"camera_control_panel_visible": camera_control_panel.visible if (camera_control_panel and is_instance_valid(camera_control_panel)) else false,
			"stats_panel_visible": stats_panel.visible if (stats_panel and is_instance_valid(stats_panel)) else false,
			"info_panel_visible": current_info_panel.visible if (current_info_panel and is_instance_valid(current_info_panel)) else false,
			"options_menu_visible": options_menu.visible if (options_menu and is_instance_valid(options_menu)) else false
		}
		
		_log_info('  Stored UI state: %s', [ui_state_before_planet_view])
	else:
		_log_info('  UI state already stored, not overwriting: %s', [ui_state_before_planet_view])
	
	# Hide all panels
	if control_panel and is_instance_valid(control_panel):
		control_panel.visible = false
		_log_info('  Hidden: ControlPanel')
	else:
		_log_info('  ControlPanel not valid for hiding')
	
	if time_control_panel and is_instance_valid(time_control_panel):
		time_control_panel.visible = false
		_log_info('  Hidden: TimeControlPanel')
	else:
		_log_info('  TimeControlPanel not valid for hiding')
	
	if camera_control_panel and is_instance_valid(camera_control_panel):
		camera_control_panel.visible = false
		_log_info('  Hidden: CameraControlPanel')
	else:
		_log_info('  CameraControlPanel not valid for hiding')
	
	if stats_panel and is_instance_valid(stats_panel):
		stats_panel.visible = false
		_log_info('  Hidden: StatsPanel')
	else:
		_log_info('  StatsPanel not valid for hiding')
	
	if current_info_panel and is_instance_valid(current_info_panel):
		current_info_panel.visible = false
		_log_info('  Hidden: CelestialInfoPanel')
	else:
		_log_info('  CelestialInfoPanel not valid for hiding')
	
	if options_menu and is_instance_valid(options_menu):
		options_menu.visible = false
		_log_info('  Hidden: OptionsMenu')
	
	_log_info('UIManager: System UI hidden successfully')
	
# Loading indicator control
func show_loading():
	if loading_indicator:
		loading_indicator.visible = true
		await get_tree().process_frame

func hide_loading():
	if loading_indicator:
		loading_indicator.visible = false

# Start screen management
func show_start_screen(save_summary: Dictionary = {}) -> StartScreen:
	start_screen = StartScreen.new()
	var has_saves := save_game_manager.has_saves() if save_game_manager else not save_summary.is_empty()
	start_screen.set_has_saves(has_saves)
	canvas_layer.add_child(start_screen)
	TerminalTheme.apply_recursive(start_screen)
	return start_screen

func hide_start_screen():
	if start_screen:
		start_screen.queue_free()
		start_screen = null

func update_start_screen_save_info(summary: Dictionary):
	if start_screen and is_instance_valid(start_screen):
		var has_saves := save_game_manager.has_saves() if save_game_manager else not summary.is_empty()
		start_screen.set_has_saves(has_saves)

# Celestial info panel management
func show_celestial_info() -> CelestialInfoPanelMVC:
	if current_info_panel:
		current_info_panel.queue_free()
	
	current_info_panel = CelestialInfoPanelMVC.new(system_history)
	current_info_panel.panel_closed.connect(_on_info_panel_closed)
	canvas_layer.add_child(current_info_panel)
	
	if stats_panel and current_info_panel.controller:
		stats_panel.set_celestial_info_controller(current_info_panel.controller)
	
	TerminalTheme.apply_recursive(current_info_panel)
	
	return current_info_panel

func get_current_info_panel():
	return current_info_panel

func close_info_panel():
	if current_info_panel:
		current_info_panel.queue_free()
		current_info_panel = null

func _on_info_panel_closed():
	current_info_panel = null
	emit_signal("info_panel_closed")

# Options menu management
func show_options_menu(show_orbits: bool, current_seed: int, star_type: String, save_summary: Dictionary = {}) -> OptionsMenu:
	if is_options_open:
		return null
		
	is_options_open = true
	
	options_menu = OptionsMenu.new(show_orbits, current_seed, star_type)
	options_menu.closed.connect(_on_options_menu_closed)
	options_menu.toggle_orbits_requested.connect(func(val): emit_signal("options_toggle_orbits_requested", val))
	options_menu.open_asset_test_requested.connect(func(): emit_signal("asset_test_requested"))
	options_menu.seed_loaded.connect(func(loaded_seed): emit_signal("options_seed_loaded", loaded_seed))
	options_menu.save_game_requested.connect(func(): emit_signal("save_game_requested"))
	options_menu.load_game_requested.connect(func(): emit_signal("load_game_requested"))
	options_menu.main_menu_requested.connect(func(): emit_signal("main_menu_requested"))
	options_menu.quit_requested.connect(func(): emit_signal("quit_requested"))
	
	# Add to parent node instead of canvas layer for proper layering
	get_parent().add_child(options_menu)
	
	TerminalTheme.apply_recursive(options_menu)
	
	return options_menu

func update_options_seed_info(seed_value: int, star_type: String):
	if options_menu and is_instance_valid(options_menu):
		options_menu.update_seed_info(seed_value, star_type)

func update_options_save_info(_summary: Dictionary):
	pass

func show_save_list_dialog(mode: int) -> SaveListDialog:
	if save_list_dialog and is_instance_valid(save_list_dialog):
		return save_list_dialog
	if save_game_manager == null:
		_log_error("Cannot show save list: SaveGameManager not set")
		return null
	save_list_dialog = SaveListDialog.new(mode, save_game_manager)
	save_list_dialog.closed.connect(_on_save_list_dialog_closed)
	save_list_dialog.save_selected.connect(func(slot_id: String, is_new: bool):
		save_to_slot_requested.emit(slot_id, is_new)
	)
	save_list_dialog.load_selected.connect(func(slot_id: String):
		load_from_slot_requested.emit(slot_id)
	)
	get_parent().add_child(save_list_dialog)
	TerminalTheme.apply_recursive(save_list_dialog)
	return save_list_dialog

func _on_save_list_dialog_closed():
	save_list_dialog = null

func _on_options_menu_closed():
	options_menu = null
	is_options_open = false
	emit_signal("options_menu_closed")

# Sandbox management
func show_asset_test(_sun_texture: Texture2D, _planet_texture: Texture2D) -> SandboxApp:
	_log_info('Sandbox request received')
	if sandbox_scene and is_instance_valid(sandbox_scene):
		_log_info('Sandbox already open')
		return sandbox_scene

	var packed: PackedScene = SandboxScene
	if not packed:
		_log_error('ERROR: Sandbox scene resource missing')
		return null
	_log_info('Sandbox packed scene ready')

	var instance: Node = null
	if packed.has_method('instantiate'):
		instance = packed.instantiate()
	else:
		instance = packed.instance()
	_log_info('Sandbox scene instance created: %s', [instance])
	if instance == null:
		_log_error('ERROR: Failed to create sandbox scene instance')
		return null
	sandbox_scene = instance as SandboxApp
	_log_info('SandboxApp scene cast successful')
	if sandbox_scene == null:
		_log_error('ERROR: Sandbox scene lacks SandboxApp script')
		instance.queue_free()
		return null

	sandbox_scene.closed.connect(_on_asset_test_closed)
	var target_parent: Node = canvas_layer if canvas_layer else get_parent()
	if target_parent:
		_log_info('Sandbox target parent (primary): %s', [target_parent])
	if not target_parent and get_tree().current_scene:
		target_parent = get_tree().current_scene
		_log_info('Sandbox target parent (fallback current_scene): %s', [target_parent])
	if not target_parent:
		_log_error('ERROR: Unable to find parent for sandbox scene')
		instance.queue_free()
		return null
	target_parent.add_child(sandbox_scene)
	if target_parent.is_inside_tree():
		_log_info('Sandbox scene added under: %s', [target_parent.get_path()])
	else:
		_log_info('Sandbox scene added under node not yet in tree: %s', [target_parent])
	if sandbox_scene is Control:
		sandbox_scene.visible = true
		sandbox_scene.set_anchors_preset(Control.PRESET_FULL_RECT)
		sandbox_scene.z_index = 1024
		sandbox_scene.move_to_front()
		sandbox_scene.grab_focus()
		TerminalTheme.apply_recursive(sandbox_scene)
	_log_info('Sandbox scene instantiated and added to scene tree')
	return sandbox_scene

func _on_asset_test_closed():
	_log_info('Sandbox scene closed')
	sandbox_scene = null
	emit_signal("asset_test_closed")

# Camera control panel updates
func update_camera_state(is_tracking: bool, is_moved: bool):
	if camera_control_panel and is_instance_valid(camera_control_panel):
		camera_control_panel.set_tracking(is_tracking)
		camera_control_panel.set_camera_moved(is_moved)

# UI state management
func save_ui_state():
	was_showing_info_panel = current_info_panel != null

func restore_ui_state():
	if was_showing_info_panel:
		# Don't create the panel here - let main.gd handle it with proper probe system setup
		# Just emit a signal that main.gd can listen to
		emit_signal("info_panel_restore_requested")

func is_any_menu_open() -> bool:
	return is_options_open or current_info_panel != null

# Utility functions
func ensure_terminal_styling(node: Node):
	"""Recursively apply terminal styling to a node and its children"""
	for child in node.get_children():
		if child is Label:
			TerminalTheme.apply_to_label(child)
		elif child is Button:
			TerminalTheme.apply_to_button(child)
		elif child is LineEdit:
			TerminalTheme.apply_to_line_edit(child)
		elif child is Panel:
			TerminalTheme.apply_to_panel(child)
		
		if child.get_child_count() > 0:
			ensure_terminal_styling(child)

# AI Control Panel Updates
func set_ai_explorer_active(active: bool):
	"""Update the AI Explorer button state"""
	if control_panel and is_instance_valid(control_panel):
		control_panel.set_ai_active(active)

# Cleanup
func cleanup():
	if current_info_panel:
		current_info_panel.queue_free()
		current_info_panel = null
	if options_menu:
		options_menu.queue_free()
		options_menu = null
	if sandbox_scene:
		sandbox_scene.queue_free()
		sandbox_scene = null
	if time_control_panel:
		time_control_panel.queue_free()
		time_control_panel = null
	if start_screen:
		start_screen.queue_free()
		start_screen = null
	if save_list_dialog:
		save_list_dialog.queue_free()
		save_list_dialog = null
