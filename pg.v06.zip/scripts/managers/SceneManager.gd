# SceneManager.gd - Proper scene management system
class_name SceneManager
extends Node

signal scene_changed(scene_name: String)
signal planet_map_options_requested()

const LOG_TAG := "SCENE_MANAGER"

func _log_info(message: String, values: Array = []):
	var formatted = message.format(values) if values.size() > 0 else message
	GameLog.info(LOG_TAG, formatted)

func _log_debug(message: String, values: Array = []):
	var formatted = message.format(values) if values.size() > 0 else message
	GameLog.debug(LOG_TAG, formatted)

func _log_warn(message: String, values: Array = []):
	var formatted = message.format(values) if values.size() > 0 else message
	GameLog.warn(LOG_TAG, formatted)

func _log_error(message: String, values: Array = []):
	var formatted = message.format(values) if values.size() > 0 else message
	GameLog.error(LOG_TAG, formatted)

enum SceneType {
	STAR_SYSTEM,
	PLANET_MAP,
	MENU,
	DIALOGUE
}

class GameSceneState:
	var scene_node: Node
	var scene_type: SceneType
	var data: Dictionary
	var previous_scene: GameSceneState
	
	func _init(p_node: Node, p_type: SceneType, p_data: Dictionary = {}):
		scene_node = p_node
		scene_type = p_type
		data = p_data

var current_scene: GameSceneState = null
var scene_stack: Array = []
var main_viewport: Viewport
var main_node: Node2D  # Reference to Main.gd node
var camera_manager: CameraManager
var input_manager: InputManager
var ui_manager: UIManager

func _init():
	name = "SceneManager"

func initialize(p_viewport: Viewport, p_camera_manager: CameraManager, p_input_manager: InputManager, p_main_node: Node2D = null):
	main_viewport = p_viewport
	camera_manager = p_camera_manager
	input_manager = p_input_manager
	main_node = p_main_node if p_main_node else (p_viewport.get_parent() if p_viewport.get_parent() is Node2D else null)

	_log_info("SceneManager initializing...")

	# Get reference to UIManager - it's a child of main_node
	if main_node:
		# Method 1: Try by name
		ui_manager = main_node.get_node_or_null("UIManager")
		if not ui_manager:
			# Method 2: Try by type
			for child in main_node.get_children():
				if child is UIManager:
					ui_manager = child
					break

	_log_info("SceneManager initialized with ui_manager: {0}", [ui_manager])

func change_scene(new_scene: Node, scene_type: SceneType, data: Dictionary = {}) -> void:
	"""Replace current scene completely"""
	
	# Store previous scene if needed
	var previous_scene = current_scene
	
	# Clean up current scene
	if current_scene:
		_cleanup_scene(current_scene)
	
	# Setup new scene
	var new_scene_state = GameSceneState.new(new_scene, scene_type, data)
	new_scene_state.previous_scene = previous_scene
	
	# Add to main node for star system scenes, viewport for others
	if scene_type == SceneType.STAR_SYSTEM and main_node:
		main_node.add_child(new_scene)
	else:
		main_viewport.add_child(new_scene)
	
	# Configure scene based on type
	_configure_scene(new_scene_state)
	
	current_scene = new_scene_state
	emit_signal("scene_changed", new_scene.name)
	
	_log_info("Scene changed to: {0}", [new_scene.name])

func push_scene(new_scene: Node, scene_type: SceneType, data: Dictionary = {}) -> void:
	"""Push new scene onto stack, preserving current scene"""
	
	if current_scene:
		scene_stack.push_back(current_scene)
		_suspend_scene(current_scene)
	
	var new_scene_state = GameSceneState.new(new_scene, scene_type, data)
	main_viewport.add_child(new_scene)
	
	_configure_scene(new_scene_state)
	current_scene = new_scene_state
	
	emit_signal("scene_changed", new_scene.name)
	_log_info("Scene pushed: {0}", [new_scene.name])

func pop_scene() -> bool:
	"""Return to previous scene from stack"""
	
	if scene_stack.is_empty():
		_log_info("No scene to pop to")
		return false
	
	# Clean up current scene
	if current_scene:
		_cleanup_scene(current_scene)
	
	# Restore previous scene
	var previous_scene = scene_stack.pop_back()
	_resume_scene(previous_scene)
	
	current_scene = previous_scene
	emit_signal("scene_changed", previous_scene.scene_node.name)
	
	_log_info("Scene popped to: {0}", [previous_scene.scene_node.name])
	return true

func get_current_scene_type() -> SceneType:
	return current_scene.scene_type if current_scene else SceneType.MENU

func get_current_scene_data() -> Dictionary:
	return current_scene.data if current_scene else {}

func get_current_scene_node() -> Node:
	"""Get the current scene node - ADDED METHOD"""
	return current_scene.scene_node if current_scene else null

func _configure_scene(scene_state: GameSceneState) -> void:
	"""Configure scene based on its type"""
	
	var scene_node = scene_state.scene_node
	
	match scene_state.scene_type:
		SceneType.STAR_SYSTEM:
			_configure_star_system_scene(scene_node, scene_state.data)
		
		SceneType.PLANET_MAP:
			_configure_planet_map_scene(scene_node, scene_state.data)
		
		SceneType.MENU:
			_configure_menu_scene(scene_node, scene_state.data)
		
		SceneType.DIALOGUE:
			_configure_dialogue_scene(scene_node, scene_state.data)

func _configure_star_system_scene(scene_node: Node, _data: Dictionary) -> void:
	"""Configure star system scene with proper input/camera"""
	
	# Ensure camera manager has control
	if camera_manager:
		camera_manager.make_camera_current()
		camera_manager.set_process_input(true)
		camera_manager.set_process_unhandled_input(true)
	
	# Enable input manager
	if input_manager:
		input_manager.set_process_unhandled_key_input(true)
	
	# Connect scene-specific signals recursively
	_connect_clickable_areas(scene_node)

func _connect_clickable_areas(node: Node):
	"""Recursively connect clickable area signals"""
	if node.has_signal("object_clicked"):
		if not node.object_clicked.is_connected(_on_star_system_object_clicked):
			node.object_clicked.connect(_on_star_system_object_clicked)
	
	for child in node.get_children():
		_connect_clickable_areas(child)

func _fallback_hide_ui():
	"""Fallback method to hide UI when UIManager is not available"""
	_log_warn("UIManager missing hide_all_system_ui; skipping unsafe fallback hide")

func _configure_planet_map_scene(scene_node: Node, data: Dictionary) -> void:
	"""Configure planet map scene with proper UI hiding"""
	_log_info("Configuring planet map scene")
	
	# Hide system UI using UIManager
	if ui_manager and ui_manager.has_method("hide_all_system_ui"):
		ui_manager.hide_all_system_ui()
		_log_debug("System UI hidden via UIManager")
	else:
		_log_warn("UIManager {0} missing hide_all_system_ui; planet map will leave existing UI visible", [ui_manager])
	
	# Rest of the configuration stays the same...
	# Disable main camera manager completely
	if camera_manager:
		_log_debug("Disabling camera manager")
		camera_manager.set_process(false)
		camera_manager.set_process_input(false)
		camera_manager.set_process_unhandled_input(false)
		if camera_manager.has_method("set_enabled"):
			camera_manager.set_enabled(false)
	
	# Disable input manager to prevent WASD movement
	if input_manager:
		_log_debug("Disabling input manager")
		input_manager.set_process(false)
		input_manager.set_process_input(false)
		input_manager.set_process_unhandled_input(false)
		input_manager.set_process_unhandled_key_input(false)
	
	# CRITICAL: Disable the GameCamera completely
	var game_camera = get_tree().get_nodes_in_group("cameras")
	for cam in game_camera:
		if cam is GameCamera:
			_log_debug("Disabling GameCamera: {0}", [cam.name])
			cam.set_process(false)
			cam.set_process_input(false)
			cam.set_process_unhandled_input(false)
			cam.enabled = false
	
	# Hide ALL star system related nodes
	if main_node:
		for child in main_node.get_children():
			if child.name == "StarSystem" or child is StarSystem:
				_log_debug("Hiding star system: {0}", [child.name])
				child.visible = false
				child.set_process(false)
				child.set_process_input(false)
	
	# Set planet map as full screen overlay
	if scene_node is Control:
		scene_node.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		scene_node.mouse_filter = Control.MOUSE_FILTER_STOP
		scene_node.z_index = 1000  # Ensure it's on top of everything
		scene_node.visible = true
		scene_node.position = Vector2.ZERO
	
	# Setup planet map with data
	var star_provider = data.get("star_system_provider", Callable())
	var tm = data.get("time_manager", null)  # Get time_manager from scene_data if available

	# Fallback to main_node.time_manager if not in scene_data
	if not tm and main_node and "time_manager" in main_node:
		tm = main_node.time_manager
		_log_debug("Using time_manager from main_node fallback")

	if scene_node.has_method("configure_dependencies"):
		scene_node.configure_dependencies(ui_manager, self, star_provider)
	if data.has("world_scenario") and scene_node.has_method("set_world_scenario"):
		scene_node.set_world_scenario(data.get("world_scenario", ""))
	if scene_node.has_method("setup_planet_view") and data.has("planet"):
		scene_node.setup_planet_view(data.planet, data.get("probe_system"), ui_manager, star_provider, tm)
	if scene_node.has_method("set_dialogue_manager") and data.has("dialogue_manager"):
		scene_node.set_dialogue_manager(data.get("dialogue_manager"))
	
	# Connect return signal
	if scene_node.has_signal("return_to_detail_view"):
		if not scene_node.return_to_detail_view.is_connected(_on_planet_map_return):
			scene_node.return_to_detail_view.connect(_on_planet_map_return)

	# Connect options menu signal (ESC key on planet map)
	if scene_node.has_signal("options_requested"):
		if not scene_node.options_requested.is_connected(_on_planet_map_options_requested):
			scene_node.options_requested.connect(_on_planet_map_options_requested)

	_log_info("Planet map configuration complete")

func set_ui_manager(p_ui_manager: UIManager):
	"""Manually set UIManager reference if auto-detection fails"""
	ui_manager = p_ui_manager
	_log_info("UIManager manually set to: {0}", [ui_manager])

func _configure_menu_scene(scene_node: Node, _data: Dictionary) -> void:
	"""Configure menu scenes"""
	if scene_node is Control:
		scene_node.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _configure_dialogue_scene(scene_node: Node, _data: Dictionary) -> void:
	"""Configure dialogue scenes"""
	if scene_node is Control:
		scene_node.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _suspend_scene(scene_state: GameSceneState) -> void:
	"""Suspend scene (pause, hide, disable input)"""
	
	var scene_node = scene_state.scene_node
	
	_log_debug("Suspending scene: {0}", [scene_node.name if scene_node else "Unknown"])
	
	match scene_state.scene_type:
		SceneType.STAR_SYSTEM:
			# Completely disable the star system
			scene_node.visible = false
			scene_node.set_process(false)
			scene_node.set_process_input(false)
			scene_node.set_process_unhandled_input(false)
			
			# Also disable the game camera
			var game_camera = get_tree().get_nodes_in_group("cameras")
			for cam in game_camera:
				if cam is GameCamera:
					cam.set_process(false)
					cam.set_process_input(false)
					cam.set_process_unhandled_input(false)
			
			# Disable camera manager
			if camera_manager:
				camera_manager.set_process(false)
				camera_manager.set_process_input(false)
				camera_manager.set_process_unhandled_input(false)
			
			# Disable input manager
			if input_manager:
				input_manager.set_process(false)
				input_manager.set_process_input(false)
				input_manager.set_process_unhandled_input(false)
				input_manager.set_process_unhandled_key_input(false)
		
		SceneType.PLANET_MAP:
			scene_node.visible = false
			scene_node.set_process(false)
			scene_node.set_process_input(false)
			scene_node.set_process_unhandled_input(false)

func _resume_scene(scene_state: GameSceneState) -> void:
	"""Resume suspended scene with proper UI restoration"""
	
	var scene_node = scene_state.scene_node
	
	_log_debug("Resuming scene: {0}", [scene_node.name if scene_node else "Unknown"])
	
	scene_node.visible = true
	
	match scene_state.scene_type:
		SceneType.STAR_SYSTEM:
			# Re-enable star system processing
			scene_node.set_process(true)
			scene_node.set_process_input(true)
			scene_node.set_process_unhandled_input(true)
			
			# Re-enable the game camera
			var game_camera = get_tree().get_nodes_in_group("cameras")
			for cam in game_camera:
				if cam is GameCamera:
					cam.set_process(true)
					cam.set_process_input(true)
					cam.set_process_unhandled_input(true)
					cam.enabled = true
			
			# Restore camera control
			if camera_manager:
				camera_manager.make_camera_current()
				camera_manager.set_process(true)
				camera_manager.set_process_input(true)
				camera_manager.set_process_unhandled_input(true)
				if camera_manager.has_method("set_enabled"):
					camera_manager.set_enabled(true)
			
			# Restore input manager
			if input_manager:
				input_manager.set_process(true)
				input_manager.set_process_input(true)
				input_manager.set_process_unhandled_input(true)
				input_manager.set_process_unhandled_key_input(true)
			
			# Restore system UI using UIManager
			if ui_manager and ui_manager.has_method("restore_system_ui"):
				ui_manager.restore_system_ui()
				_log_debug("System UI restored via UIManager")
			else:
				_log_warn("UIManager {0} missing restore_system_ui method", [ui_manager])
				# Fallback: show UI manually
				_fallback_show_ui()
		
		SceneType.PLANET_MAP:
			scene_node.set_process(true)
			scene_node.set_process_input(true)
			scene_node.set_process_unhandled_input(true)

func _fallback_show_ui():
	"""Fallback method to show UI when UIManager is not available"""
	_log_debug("Using fallback method to show UI")
	if main_node:
		var canvas_layer = main_node.get_node_or_null("CanvasLayer")
		if canvas_layer:
			for child in canvas_layer.get_children():
				if child is Control:
					child.visible = true
					_log_debug("Shown: {0}", [child.name])

func _cleanup_scene(scene_state: GameSceneState) -> void:
	"""Properly clean up scene"""
	
	var scene_node = scene_state.scene_node
	
	# Disconnect signals
	_disconnect_scene_signals(scene_node)
	
	# Remove from scene tree
	if scene_node and is_instance_valid(scene_node):
		if scene_node.get_parent():
			scene_node.get_parent().remove_child(scene_node)
		scene_node.queue_free()

func _disconnect_scene_signals(scene_node: Node) -> void:
	"""Disconnect all scene-specific signals"""
	
	# Disconnect clickable area signals recursively
	_disconnect_clickable_areas(scene_node)
	
	# Disconnect planet map signals
	if scene_node.has_signal("return_to_detail_view"):
		if scene_node.return_to_detail_view.is_connected(_on_planet_map_return):
			scene_node.return_to_detail_view.disconnect(_on_planet_map_return)
	if scene_node.has_signal("options_requested"):
		if scene_node.options_requested.is_connected(_on_planet_map_options_requested):
			scene_node.options_requested.disconnect(_on_planet_map_options_requested)

func _disconnect_clickable_areas(node: Node):
	"""Recursively disconnect clickable area signals"""
	if node.has_signal("object_clicked"):
		if node.object_clicked.is_connected(_on_star_system_object_clicked):
			node.object_clicked.disconnect(_on_star_system_object_clicked)
	
	for child in node.get_children():
		_disconnect_clickable_areas(child)

# Signal handlers
func _on_star_system_object_clicked(object):
	"""Handle object clicks in star system - forward to main"""
	if main_node and main_node.has_method("_on_object_clicked"):
		main_node._on_object_clicked(object)

func _on_planet_map_return():
	"""Handle return from planet map to system view"""
	_log_info("Planet map return requested")
	
	# Debug UI state before popping
	if ui_manager and ui_manager.has_method("debug_ui_state"):
		_log_debug("Before pop_scene")
		ui_manager.debug_ui_state()
	
	pop_scene()
	
	# Debug UI state after popping
	if ui_manager and ui_manager.has_method("debug_ui_state"):
		_log_debug("After pop_scene")
		ui_manager.debug_ui_state()

func _on_planet_map_options_requested():
	emit_signal("planet_map_options_requested")


func debug_node_structure():
	"""Debug method to print the node structure and find UIManager"""
	_log_debug("=== SCENE MANAGER DEBUG ===")
	_log_debug("main_viewport: {0}", [main_viewport])
	_log_debug("main_node: {0}", [main_node])
	_log_debug("ui_manager: {0}", [ui_manager])
	
	if main_node:
		_log_debug("main_node children:")
		for child in main_node.get_children():
			_log_debug("  - {0} ({1})", [child.name, child.get_class()])
			if child.name == "UIManager" or child is UIManager:
				_log_debug("    ^ This is UIManager!")
				ui_manager = child  # Set it here if we find it
		
		var canvas_layer = main_node.get_node_or_null("CanvasLayer")
		if canvas_layer:
			_log_debug("CanvasLayer children:")
			for child in canvas_layer.get_children():
				_log_debug("  - {0} ({1})", [child.name, child.get_class()])
	
	_log_debug("========================")

func cleanup():
	"""Clean up scene manager"""
	
	_log_info("SceneManager cleaning up")
	
	# Clean up current scene
	if current_scene:
		_cleanup_scene(current_scene)
	
	# Clean up scene stack
	for scene_state in scene_stack:
		_cleanup_scene(scene_state)
	
	scene_stack.clear()
	current_scene = null
