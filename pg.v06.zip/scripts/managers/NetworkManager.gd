# NetworkManager.gd - Fixed player name display issues
class_name NetworkManager
extends Node

const LOG_TAG := "NETWORK"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))

signal stats_updated(player_id: int, stats: Dictionary)
signal player_joined(player_id: int, player_name: String)
signal player_left(player_id: int)

# Player stats tracking
class PlayerStats:
	var id: int
	var name: String
	var systems_explored: int = 0
	var planets_discovered: int = 0  
	var habitable_planets_found: int = 0
	var explored_seeds: Array = []
	
	func to_dict() -> Dictionary:
		return {
			"id": id,
			"name": name,
			"systems": systems_explored,
			"planets": planets_discovered,
			"habitable": habitable_planets_found,
			"seeds": explored_seeds
		}

const DEFAULT_PORT = 7000
const CONNECTION_COOLDOWN = 1.5  # Minimum time between connections

var peer = null
var is_multiplayer: bool = false
var is_host: bool = false
var player_stats: Dictionary = {}  # id -> PlayerStats
var local_player_id: int = 1

# Connection management to prevent crashes
var connection_state: String = "disconnected"
var last_connection_time: float = 0.0
var pending_rpcs: Array = []

func _ready():
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	
	set_process(true)
	_log_info('NetworkManager initialized with crash prevention')

func _process(_delta):
	# Debug with Page Up
	if Input.is_action_just_pressed("ui_page_up"):
		debug_print_players()
	
	# Process pending RPCs if ready
	if connection_state == "ready" and pending_rpcs.size() > 0:
		var rpc_data = pending_rpcs.pop_front()
		_execute_rpc_safely(rpc_data)

# Safe RPC execution
func _execute_rpc_safely(rpc_data: Dictionary):
	var method = rpc_data["method"]
	var args = rpc_data["args"]
	
	if not multiplayer.multiplayer_peer or multiplayer.multiplayer_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		_log_warn('WARNING: Cannot execute RPC, not connected: %s', [method])
		return
	
	if rpc_data["type"] == "rpc_id":
		var peer_id = rpc_data["peer_id"]
		if peer_id not in multiplayer.get_peers() and peer_id != 1:
			_log_warn('WARNING: Peer not connected: %s', [peer_id])
			return
		
		match args.size():
			0: rpc_id(peer_id, method)
			1: rpc_id(peer_id, method, args[0])
			2: rpc_id(peer_id, method, args[0], args[1])
			3: rpc_id(peer_id, method, args[0], args[1], args[2])
	else:
		match args.size():
			0: rpc(method)
			1: rpc(method, args[0])
			2: rpc(method, args[0], args[1])
			3: rpc(method, args[0], args[1], args[2])

# Safe RPC wrapper
func safe_rpc(method: String, args: Array = []):
	if not is_multiplayer:
		return
	
	if connection_state != "ready":
		_log_info('Queueing RPC: %s', [method])
		pending_rpcs.append({"type": "rpc", "method": method, "args": args})
		return
	
	_execute_rpc_safely({"type": "rpc", "method": method, "args": args})

# Safe RPC to specific peer
func safe_rpc_id(peer_id: int, method: String, args: Array = []):
	if not is_multiplayer:
		return
	
	if connection_state != "ready":
		_log_info('Queueing RPC_ID: %s', [method])
		pending_rpcs.append({"type": "rpc_id", "peer_id": peer_id, "method": method, "args": args})
		return
	
	_execute_rpc_safely({"type": "rpc_id", "peer_id": peer_id, "method": method, "args": args})

# Initialize single player
func init_single_player(player_name: String = "Explorer"):
	is_multiplayer = false
	is_host = true
	local_player_id = 1
	connection_state = "ready"
	
	var stats = PlayerStats.new()
	stats.id = 1
	stats.name = player_name
	player_stats[1] = stats
	
	_log_info('Single player mode initialized with name: %s', [player_name])

# Host multiplayer game - SYNCHRONOUS to maintain compatibility
func host_game(player_name: String = "Host", port: int = DEFAULT_PORT) -> bool:
	# Always cleanup first to ensure clean state
	_log_info('Current state before cleanup: %s is_multiplayer: %s', [connection_state, is_multiplayer])
	cleanup()
	_log_info('State after cleanup: %s is_multiplayer: %s', [connection_state, is_multiplayer])
	
	# Force disconnected state - no state checking, just proceed
	connection_state = "connecting"
	_log_info('Starting host on port %s with name: %s', [port, player_name])
	
	peer = ENetMultiplayerPeer.new()
	var error = peer.create_server(port, 2)  # Max 2 players
	
	if error != OK:
		_log_error('ERROR: Failed to create server: %s', [error])
		connection_state = "disconnected"
		return false
	
	multiplayer.multiplayer_peer = peer
	is_multiplayer = true
	is_host = true
	local_player_id = 1
	connection_state = "connected"
	
	# Store host stats with proper name
	var stats = PlayerStats.new()
	stats.id = 1
	stats.name = player_name
	player_stats[1] = stats
	
	_log_info('Host stats created: ID=%s Name=%s', [stats.id, stats.name])
	
	# Use deferred call to set ready state
	call_deferred("_set_host_ready")
	
	_log_info('Hosting on port %s', [port])
	return true

func _set_host_ready():
	connection_state = "ready"
	last_connection_time = Time.get_time_dict_from_system().get("unix", 0)
	_log_info('Host ready!')

func join_game(address: String, player_name: String = "Guest", port: int = DEFAULT_PORT) -> bool:
	# Always cleanup first to ensure clean state
	_log_info('Current state before cleanup: %s is_multiplayer: %s', [connection_state, is_multiplayer])
	cleanup()
	_log_info('State after cleanup: %s is_multiplayer: %s', [connection_state, is_multiplayer])
	
	# Force disconnected state - no state checking, just proceed
	connection_state = "connecting"
	_log_info('Joining %s:%s with name: %s', [address, port, player_name])
	
	peer = ENetMultiplayerPeer.new()
	var error = peer.create_client(address, port)
	
	if error != OK:
		_log_error('ERROR: Failed to connect: %s', [error])
		connection_state = "disconnected"
		return false
	
	multiplayer.multiplayer_peer = peer
	is_multiplayer = true
	is_host = false
	
	# Store client name temporarily - will be updated with proper ID on connection
	var stats = PlayerStats.new()
	stats.name = player_name
	player_stats[-1] = stats  # Temporary ID until we get real one
	
	_log_info('Client stats created temporarily: Name=%s', [stats.name])
	_log_info('Connecting to %s:%s', [address, port])
	return true

# Enhanced connection handlers with crash prevention
func _on_peer_connected(id: int):
	var current_time = Time.get_time_dict_from_system().get("unix", 0)
	var time_since_last = current_time - last_connection_time
	
	_log_info('Peer %s connected. Time since last: %s', [id, time_since_last])
	
	# Prevent rapid connections that cause crashes
	if time_since_last < CONNECTION_COOLDOWN:
		_log_warn('WARNING: Connection too soon, delaying response...')
		# Use timer to delay instead of await to maintain sync compatibility
		var timer = get_tree().create_timer(CONNECTION_COOLDOWN - time_since_last)
		timer.timeout.connect(_handle_delayed_peer_connection.bind(id))
		return
	
	_handle_delayed_peer_connection(id)

func _handle_delayed_peer_connection(id: int):
	last_connection_time = Time.get_time_dict_from_system().get("unix", 0)
	
	# Create placeholder stats if they don't exist
	if not player_stats.has(id):
		var stats = PlayerStats.new()
		stats.id = id
		stats.name = "Player " + str(id)
		player_stats[id] = stats
	
	if is_host:
		_log_info('Host: New player connected with ID %s', [id])
		_log_info('Host: Sending our name to new player...')
		
		# Send host info immediately - don't use timer, connection should be stable now
		_send_host_info_to_peer(id)

func _send_host_info_to_peer(id: int):
	if player_stats.has(1):
		var our_stats = player_stats[1]
		_log_info("Host sending name '%s' to peer %s", [our_stats.name, id])
		safe_rpc_id(id, "player_info", [1, our_stats.name])
		
		# Also send stats after a brief delay
		var timer = get_tree().create_timer(0.3)
		timer.timeout.connect(_send_host_stats_to_peer.bind(id))

func _send_host_stats_to_peer(id: int):
	if player_stats.has(1):
		_log_info('Host sending stats to peer %s', [id])
		safe_rpc_id(id, "receive_stats", [player_stats[1].to_dict()])

func _on_peer_disconnected(id: int):
	_log_info('Player disconnected: %s', [id])
	if player_stats.has(id):
		player_stats.erase(id)
		emit_signal("player_left", id)

func _on_connected_to_server():
	_log_info('Successfully connected to server!')
	connection_state = "connected"
	
	local_player_id = multiplayer.get_unique_id()
	_log_info('My ID is: %s', [local_player_id])
	
	# Update our stats with real ID
	if player_stats.has(-1):
		var stats = player_stats[-1]
		stats.id = local_player_id
		player_stats[local_player_id] = stats
		player_stats.erase(-1)
		
		_log_info('Client stats updated: ID=%s Name=%s', [stats.id, stats.name])
		
		connection_state = "ready"
		
		# Create placeholder for host (will be updated when we receive host info)
		if not player_stats.has(1):
			var host_stats = PlayerStats.new()
			host_stats.id = 1
			host_stats.name = "Host"  # Temporary name
			player_stats[1] = host_stats
			_log_info('Created placeholder for host')
		
		# Send our info immediately - connection should be stable
		_log_info("Client sending name '%s' to host...", [stats.name])
		safe_rpc_id(1, "player_info", [local_player_id, stats.name])
		
		# Send stats after delay
		var timer = get_tree().create_timer(0.5)
		timer.timeout.connect(_send_client_stats.bind(stats))

func _send_client_stats(stats: PlayerStats):
	_log_info('Client sending stats to host...')
	safe_rpc("receive_stats", [stats.to_dict()])

func _on_connection_failed():
	_log_info('Connection failed')
	connection_state = "disconnected"
	is_multiplayer = false
	peer = null

func _on_server_disconnected():
	_log_info('Server disconnected')
	connection_state = "disconnected"
	is_multiplayer = false
	player_stats.clear()
	peer = null

# Update stats when exploring new system
func update_system_explored(system_seed: int, planet_count: int):
	if not player_stats.has(local_player_id):
		return

	var stats = player_stats[local_player_id]

	if not system_seed in stats.explored_seeds:
		stats.explored_seeds.append(system_seed)
		stats.systems_explored += 1
		stats.planets_discovered += planet_count
		
		# Emit local signal first
		emit_signal("stats_updated", local_player_id, stats.to_dict())
		
		# Then sync to others with safe RPC
		if is_multiplayer and connection_state == "ready":
			safe_rpc("receive_stats", [stats.to_dict()])

# Update when habitable planet found
func found_habitable_planet():
	if not player_stats.has(local_player_id):
		return
		
	var stats = player_stats[local_player_id]
	stats.habitable_planets_found += 1
	
	# Emit local signal first
	emit_signal("stats_updated", local_player_id, stats.to_dict())
	
	# Then sync to others with safe RPC
	if is_multiplayer and connection_state == "ready":
		safe_rpc("receive_stats", [stats.to_dict()])

# Network RPCs
@rpc("any_peer", "call_remote", "reliable")
func receive_stats(stats_dict: Dictionary):
	if not stats_dict.has("id"):
		_log_warn('WARNING: Received invalid stats')
		return
		
	var id = stats_dict["id"]
	_log_info('Receiving stats for player %s name: %s', [id, stats_dict.get("name", "Unknown")])
	
	if not player_stats.has(id):
		player_stats[id] = PlayerStats.new()
	
	var stats = player_stats[id]
	stats.id = id
	stats.name = stats_dict.get("name", "Unknown")
	stats.systems_explored = stats_dict.get("systems", 0)
	stats.planets_discovered = stats_dict.get("planets", 0)
	stats.habitable_planets_found = stats_dict.get("habitable", 0)
	stats.explored_seeds = stats_dict.get("seeds", [])
	
	emit_signal("stats_updated", id, stats_dict)

@rpc("any_peer", "call_local", "reliable")
func player_info(id: int, player_name: String):
	_log_info("Received player info: ID=%s Name='%s'", [id, player_name])
	
	if not player_stats.has(id):
		var stats = PlayerStats.new()
		stats.id = id
		stats.name = player_name
		player_stats[id] = stats
		_log_info('Created new player stats for %s', [id])
		emit_signal("player_joined", id, player_name)
	else:
		# Update name if different
		var stats = player_stats[id]
		var old_name = stats.name
		stats.name = player_name
		_log_info("Updated player name from '%s' to '%s'", [old_name, player_name])
	
	# Always emit updated signal to refresh UI
	emit_signal("stats_updated", id, player_stats[id].to_dict())

# Utility functions
func is_ready() -> bool:
	return connection_state == "ready"

func get_connection_state() -> String:
	return connection_state

func get_local_player_id() -> int:
	return local_player_id

func get_player_name(id: int) -> String:
	if player_stats.has(id):
		return player_stats[id].name
	return "Unknown"

func get_all_stats() -> Array:
	var result = []
	for id in player_stats:
		result.append(player_stats[id].to_dict())
	return result

# Cleanup function - improved to properly reset
func cleanup():
	_log_info('Cleaning up network manager')
	
	# Clear any timers or pending operations
	pending_rpcs.clear()
	
	# Close peer connection
	if peer:
		peer.close()
	peer = null
	
	# Reset multiplayer peer
	multiplayer.multiplayer_peer = null
	
	# Reset state
	connection_state = "disconnected"
	is_multiplayer = false
	is_host = false
	
	# Clear player stats completely - don't preserve anything during cleanup
	player_stats.clear()
	
	# Reset to single player defaults
	local_player_id = 1
	
	_log_info('Cleanup complete')

# Debug function
func debug_print_players():
	_log_debug('\n=== NETWORK MANAGER DEBUG ===')
	_log_info('Connection State: %s', [connection_state])
	_log_info('Is Multiplayer: %s', [is_multiplayer])
	_log_info('Is Host: %s', [is_host])
	_log_info('Local Player ID: %s', [local_player_id])
	_log_info('Connected Peers: %s', [str(multiplayer.get_peers()) if multiplayer.multiplayer_peer else "No peer"])
	_log_info('Pending RPCs: %s', [pending_rpcs.size()])
	_log_info('Players in stats:')
	for id in player_stats:
		var stats = player_stats[id]
		_log_info("  ID: %s Name: '%s' Systems: %s P: %s H: %s", [id, stats.name, stats.systems_explored, stats.planets_discovered, stats.habitable_planets_found])
	_log_debug('==============================\n')
