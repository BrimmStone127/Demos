# InputManager.gd - Simplified version that just handles input routing
class_name InputManager
extends Node

const LOG_TAG := "INPUT_MANAGER"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))

# Signals for different input actions
signal escape_pressed
signal debug_habitability_requested
signal toggle_habitable_zone_requested
signal show_probe_status_requested
signal ai_message_requested
signal transmission_requested
signal new_system_requested

# Input state
var game_started: bool = false
var dialogue_manager: DialogueManager

func _init():
	name = "InputManager"

func initialize(p_dialogue_manager: DialogueManager = null):
	dialogue_manager = p_dialogue_manager
	set_process_unhandled_key_input(true)
	_log_info('InputManager initialized')

func set_game_started(started: bool):
	game_started = started

func _unhandled_key_input(event):
	if not event.is_pressed():
		return
	
	# Handle ESC key
	if event.keycode == KEY_ESCAPE:
		emit_signal("escape_pressed")
		get_viewport().set_input_as_handled()
		return
	
	# Only handle other inputs if game has started
	if not game_started:
		return
	
	if event.keycode == KEY_SPACE:
		emit_signal("new_system_requested")
		get_viewport().set_input_as_handled()
		return
	
	# Handle debug inputs
	if event.keycode == KEY_Z:
		emit_signal("debug_habitability_requested")
		get_viewport().set_input_as_handled()
		return
	
	if event.keycode == KEY_X:
		emit_signal("toggle_habitable_zone_requested")
		get_viewport().set_input_as_handled()
		return
	
	if event.keycode == KEY_P:
		emit_signal("show_probe_status_requested")
		get_viewport().set_input_as_handled()
		return
	
	# Handle dialogue inputs
	if event.keycode == KEY_H:
		emit_signal("ai_message_requested")
		get_viewport().set_input_as_handled()
		return
	
	if event.keycode == KEY_M:
		emit_signal("transmission_requested")
		get_viewport().set_input_as_handled()
		return
	
	# Let dialogue manager handle other dialogue input if available
	if dialogue_manager and dialogue_manager.handle_dialogue_input(event):
		get_viewport().set_input_as_handled()
		return

func cleanup():
	dialogue_manager = null
	set_process_unhandled_key_input(false)
