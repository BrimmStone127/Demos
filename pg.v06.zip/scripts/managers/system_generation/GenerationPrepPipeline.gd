﻿# GenerationPrepPipeline.gd
class_name GenerationPrepPipeline
extends RefCounted

var manager: SystemGenerationManager

func _init(p_manager: SystemGenerationManager):
	manager = p_manager

func run(context: SystemGenerationManager.GenerationContext) -> void:
	var services = manager.services
	if services == null:
		return
	var transition: TransitionManager = services.transition_manager
	if context.should_show_transition and transition:
		await transition.fade_to_black(0.2)
	await manager._notify_loading_started()
	manager._log_info("SYSTEM_GEN", "Generating new system with seed: %s" % context.seed_value)
	manager.current_seed = context.seed_value
	var existing_system := context.existing_system
	var system_state: SystemStateManager = services.system_state_manager
	var probe: ProbeSystem = services.probe_system
	if manager._is_system_valid(existing_system) and system_state:
		manager._log_info("SYSTEM_GEN", "Saving current system state before regeneration")
		system_state.save_system_state(existing_system, probe)
	manager._update_background_if_needed(manager.current_seed)
	manager._request_ui_state_save()
	manager._request_info_panel_close()
	await manager.get_tree().process_frame
	var camera: CameraManager = services.camera_manager
	if camera:
		camera.stop_tracking()
		camera.reset_camera()
	if existing_system:
		await manager._clear_existing_system(existing_system)
