﻿# GenerationFinalizePipeline.gd
class_name GenerationFinalizePipeline
extends RefCounted

var manager: SystemGenerationManager

func _init(p_manager: SystemGenerationManager):
	manager = p_manager

func run(context: SystemGenerationManager.GenerationContext) -> void:
	var star_system := context.new_system
	if not manager._is_system_valid(star_system):
		return
	context.state_loaded = manager._load_system_state_if_available(star_system)
	manager.current_star_type = star_system.get_star_type_name()
	manager._show_habitability_summary(star_system)
	var services = manager.services
	manager._notify_options_info_changed(manager.current_seed, manager.current_star_type)
	manager._add_clickable_areas(star_system)
	if services and services.network_manager:
		var planet_count := manager._count_planets(star_system)
		services.network_manager.update_system_explored(manager.current_seed, planet_count)
	manager._update_orbit_visibility(star_system)
	if services and services.camera_manager:
		services.camera_manager.make_camera_current()
	manager._notify_loading_finished()
	await manager.get_tree().create_timer(0.1).timeout
	if services and services.system_history:
		var planet_count := manager._count_planets(star_system)
		services.system_history.add_system(manager.current_seed, manager.current_star_type, planet_count)
	manager._request_ui_state_restore()
	if services:
		var transition: TransitionManager = services.transition_manager
		if context.should_show_transition and transition:
			await transition.fade_from_black(0.3)
