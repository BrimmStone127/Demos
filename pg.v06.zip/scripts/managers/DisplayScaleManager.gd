# DisplayScaleManager.gd - Manages display scaling for high-DPI screens
class_name DisplayScaleManager
extends Node

const LOG_TAG := "DISPLAY_SCALE"

# The calculated display scale factor (1.0 = normal DPI, 2.0 = Retina, etc.)
var scale_factor: float = 1.0

# Standard DPI baseline (Windows default)
const BASELINE_DPI := 96.0

func _init():
	name = "DisplayScaleManager"

func initialize():
	"""Detect and calculate the display scale factor for the current screen"""
	scale_factor = _detect_display_scale()
	GameLog.info(LOG_TAG, "Display scale factor detected: %.2f" % scale_factor)

func _detect_display_scale() -> float:
	"""
	Detect the display scale factor using OS-provided information.
	Returns 1.0 for standard DPI displays (backwards compatible default).
	"""
	var screen_id := DisplayServer.window_get_current_screen()

	# Method 1: Try to use screen_get_scale() - this is the most reliable for Godot 4.x
	# This returns the OS-level scale factor (1.0, 1.5, 2.0, etc.)
	if DisplayServer.has_method("screen_get_scale"):
		var os_scale := DisplayServer.screen_get_scale(screen_id)
		if os_scale > 0.0:
			GameLog.debug(LOG_TAG, "Using OS-reported scale factor: %.2f" % os_scale)
			return os_scale

	# Method 2: Fall back to DPI-based calculation
	if DisplayServer.has_method("screen_get_dpi"):
		var dpi := DisplayServer.screen_get_dpi(screen_id)
		if dpi > 0:
			var calculated_scale := dpi / BASELINE_DPI
			GameLog.debug(LOG_TAG, "Calculated scale from DPI (%d): %.2f" % [dpi, calculated_scale])
			return calculated_scale

	# Method 3: Default to 1.0 (no scaling) for backwards compatibility
	GameLog.debug(LOG_TAG, "Using default scale factor: 1.0 (no scaling)")
	return 1.0

func get_scale_factor() -> float:
	"""Get the current display scale factor"""
	return scale_factor

func apply_scale_to_canvas_layer(canvas_layer: CanvasLayer):
	"""
	Apply the display scale factor to a CanvasLayer.
	This scales all UI elements uniformly without affecting game rendering.
	"""
	if not canvas_layer:
		GameLog.warn(LOG_TAG, "Cannot apply scale to null CanvasLayer")
		return

	if scale_factor == 1.0:
		# No scaling needed - backwards compatible behavior
		GameLog.debug(LOG_TAG, "Scale factor is 1.0, no CanvasLayer scaling applied")
		return

	# Apply scale transform to the CanvasLayer
	# This scales the UI without affecting the viewport/game world
	canvas_layer.scale = Vector2(scale_factor, scale_factor)
	GameLog.info(LOG_TAG, "Applied scale factor %.2f to CanvasLayer" % scale_factor)

func get_scaled_size(base_size: Vector2) -> Vector2:
	"""
	Helper function to get a scaled size for UI elements.
	Use this if you need to manually scale individual elements.
	"""
	return base_size * scale_factor

func get_display_info() -> Dictionary:
	"""Get detailed display information for debugging"""
	var screen_id := DisplayServer.window_get_current_screen()
	var info := {
		"scale_factor": scale_factor,
		"screen_id": screen_id,
		"screen_count": DisplayServer.get_screen_count()
	}

	if DisplayServer.has_method("screen_get_dpi"):
		info["dpi"] = DisplayServer.screen_get_dpi(screen_id)

	if DisplayServer.has_method("screen_get_scale"):
		info["os_scale"] = DisplayServer.screen_get_scale(screen_id)

	if DisplayServer.has_method("screen_get_size"):
		info["screen_size"] = DisplayServer.screen_get_size(screen_id)

	return info
