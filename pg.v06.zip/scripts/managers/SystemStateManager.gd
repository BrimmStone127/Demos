class_name SystemStateManager
extends Node

const LOG_TAG := "SYSTEM_STATE"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))

# Manages persistent state for star systems across regeneration
# Stores enhanced planet properties, probe discoveries, and other persistent data

signal system_state_saved(system_seed: int)
signal system_state_loaded(system_seed: int)

# Dictionary to store system states by seed
# Format: system_seed -> SystemState
var system_states: Dictionary = {}

# Current system being managed
var current_system_seed: int = -1

class SystemState:
	var system_seed: int
	var star_type: String
	var planet_count: int
	var timestamp: float
	var last_visited_time: float  # ADDED: When this system was last active

	# Enhanced properties for each planet
	var planet_states: Array[PlanetState] = []

	# Probe discovery data
	var probe_discoveries: Dictionary = {}  # planet_index -> discovery_data

	# Habitable zone data
	var habitable_zone_data: Dictionary = {}

	func _init(p_seed: int, p_star_type: String, p_planet_count: int):
		system_seed = p_seed
		star_type = p_star_type
		planet_count = p_planet_count
		timestamp = Time.get_unix_time_from_system()
		last_visited_time = timestamp  # ADDED: Initialize last visited time

class PlanetState:
	var index: int  # Planet index in system
	var name: String
	var enhanced_properties_generated: bool = false
	
	# ADDED: Orbital state persistence
	var orbit_angle: float
	var semi_major_axis: float
	var eccentricity: float
	var orbit_speed: float
	var planet_size: float
	
	# Enhanced properties
	var atmosphere_type: int
	var atmosphere_pressure: float
	var atmosphere_composition: Dictionary
	var magnetosphere_strength: int
	var magnetic_field_strength: float
	var geological_activity: int
	var tectonic_plates: int
	var volcanic_activity: float
	var climate_type: int
	var surface_temperature: float
	var temperature_variation: float
	var surface_liquids: Dictionary
	var surface_composition: Dictionary
	var moons: Array
	var habitability_score: float
	var habitable_zone_type: int
	
	func _init(p_index: int, p_name: String):
		index = p_index
		name = p_name

func _ready():
	# Connect to probe system if it exists
	call_deferred("_connect_to_probe_system")

func _connect_to_probe_system():
	# Find probe system in the scene tree
	var main_node = get_tree().get_first_node_in_group("main")
	if not main_node:
		main_node = Engine.get_main_loop().get_root().get_node("Node2D")
	
	if main_node and main_node.has_method("get") and "probe_system" in main_node:
		var probe_system = main_node.probe_system
		if probe_system and probe_system.has_signal("probe_arrived"):
			probe_system.probe_arrived.connect(_on_probe_data_received)
			probe_system.discovery_made.connect(_on_discovery_made)
			_log_info('SystemStateManager connected to ProbeSystem')

# Save the current system state
func save_system_state(star_system: StarSystem, probe_system: ProbeSystem = null):
	if not star_system or not is_instance_valid(star_system):
		_log_warn('Warning: Cannot save state for invalid star system')
		return
	
	var save_start_ms = Time.get_ticks_msec()
	var system_seed = star_system.current_seed
	var star_type = star_system.get_star_type_name()
	
	# Count planets
	var planets = []
	for child in star_system.get_children():
		if child is Planet:
			planets.append(child)
	
	# Create or update system state
	var state = SystemState.new(system_seed, star_type, planets.size())
	
	# ADDED: Update last visited time when saving
	state.last_visited_time = Time.get_unix_time_from_system()
	
	# Save planet states
	for i in range(planets.size()):
		var planet = planets[i]
		var planet_state = PlanetState.new(i, planet.planet_name)
		
		# Copy enhanced properties if they exist
		if planet.enhanced_properties_generated:
			planet_state.enhanced_properties_generated = true
			planet_state.atmosphere_type = planet.atmosphere_type
			planet_state.atmosphere_pressure = planet.atmosphere_pressure
			planet_state.atmosphere_composition = planet.atmosphere_composition.duplicate()
			planet_state.magnetosphere_strength = planet.magnetosphere_strength
			planet_state.magnetic_field_strength = planet.magnetic_field_strength
			planet_state.geological_activity = planet.geological_activity
			planet_state.tectonic_plates = planet.tectonic_plates
			planet_state.volcanic_activity = planet.volcanic_activity
			planet_state.climate_type = planet.climate_type
			planet_state.surface_temperature = planet.surface_temperature
			planet_state.temperature_variation = planet.temperature_variation
			planet_state.surface_liquids = planet.surface_liquids.duplicate()
			planet_state.surface_composition = planet.surface_composition.duplicate()
			planet_state.moons = planet.moons.duplicate(true)
			planet_state.habitability_score = planet.habitability_score
			planet_state.habitable_zone_type = planet.habitable_zone_type
		
		# ADDED: Always save orbital state (this is the key fix!)
		planet_state.orbit_angle = planet.orbit_angle
		planet_state.semi_major_axis = planet.semi_major_axis
		planet_state.eccentricity = planet.eccentricity
		planet_state.orbit_speed = planet.orbit_speed
		planet_state.planet_size = planet.planet_size
		
		state.planet_states.append(planet_state)
	
	# Save habitable zone data
	if star_system.habitable_zone:
		state.habitable_zone_data = star_system.habitable_zone.get_zone_info()
	
	# Save probe discoveries from probe system
	if probe_system:
		var probe_capture_start = Time.get_ticks_msec()
		state.probe_discoveries = probe_system.get_system_discovery_data(system_seed)
		var probe_duration = Time.get_ticks_msec() - probe_capture_start
		if probe_duration > 50:
			_log_info('Probe discovery capture for system %s took %sms', [system_seed, probe_duration])
	
	# Store the state
	system_states[system_seed] = state
	current_system_seed = system_seed
	
	var duration_ms = Time.get_ticks_msec() - save_start_ms
	_log_info('Saved state for system %s with %s planets at %s (took %sms)', [system_seed, planets.size(), state.last_visited_time, duration_ms])
	emit_signal("system_state_saved", system_seed)

# Load system state and apply it to a star system
func load_system_state(star_system: StarSystem, probe_system: ProbeSystem = null):
	if not star_system or not is_instance_valid(star_system):
		_log_warn('Warning: Cannot load state for invalid star system')
		return false
	
	var system_seed = star_system.current_seed
	
	if not system_states.has(system_seed):
		_log_info('No saved state found for system %s', [system_seed])
		return false
	
	var state = system_states[system_seed]
	
	# Get planets from the star system
	var planets = []
	for child in star_system.get_children():
		if child is Planet:
			planets.append(child)
	
	if planets.size() != state.planet_states.size():
		_log_warn('Warning: Planet count mismatch. Expected %s but found %s', [state.planet_states.size(), planets.size()])
		# Continue anyway, might be partially restorable
	
	# Restore planet states with time progression
	var restored_count = 0
	var current_time = Time.get_unix_time_from_system()
	var time_elapsed = current_time - state.last_visited_time
	
	_log_info('Time elapsed since last visit: %s seconds', [snapped(time_elapsed, 0.01)])
	
	for i in range(min(planets.size(), state.planet_states.size())):
		var planet = planets[i]
		var planet_state = state.planet_states[i]
		
		# Restore custom planet name if we have one saved
		if planet_state.name != "" and planet_state.name != planet.planet_name:
			planet.planet_name = planet_state.name
			if planet.has_method("_update_name_label"):
				planet._update_name_label()
		
		# Apply enhanced properties
		if planet_state.enhanced_properties_generated:
			planet.enhanced_properties_generated = true
			planet.atmosphere_type = planet_state.atmosphere_type
			planet.atmosphere_pressure = planet_state.atmosphere_pressure
			planet.atmosphere_composition = planet_state.atmosphere_composition.duplicate()
			planet.magnetosphere_strength = planet_state.magnetosphere_strength
			planet.magnetic_field_strength = planet_state.magnetic_field_strength
			planet.geological_activity = planet_state.geological_activity
			planet.tectonic_plates = planet_state.tectonic_plates
			planet.volcanic_activity = planet_state.volcanic_activity
			planet.climate_type = planet_state.climate_type
			planet.surface_temperature = planet_state.surface_temperature
			planet.temperature_variation = planet_state.temperature_variation
			planet.surface_liquids = planet_state.surface_liquids.duplicate()
			planet.surface_composition = planet_state.surface_composition.duplicate()
			planet.moons = planet_state.moons.duplicate(true)
			planet.habitability_score = planet_state.habitability_score
			planet.habitable_zone_type = planet_state.habitable_zone_type
			
			restored_count += 1
		
		# ADDED: Restore orbital state with time progression!
		planet.semi_major_axis = planet_state.semi_major_axis
		planet.eccentricity = planet_state.eccentricity
		planet.orbit_speed = planet_state.orbit_speed
		planet.planet_size = planet_state.planet_size
		
		# CRITICAL: Advance orbit based on elapsed time
		var advanced_angle = planet_state.orbit_angle + (planet_state.orbit_speed * time_elapsed)
		
		# Normalize angle to stay within 0 to 2*PI
		while advanced_angle > 2 * PI:
			advanced_angle -= 2 * PI
		while advanced_angle < 0:
			advanced_angle += 2 * PI
		
		planet.orbit_angle = advanced_angle
		
		# IMPORTANT: Update planet position immediately to match advanced angle
		planet.update_position()
		
		_log_info('Planet %s advanced %s radians', [planet.planet_name, snapped(time_elapsed * planet_state.orbit_speed, 0.01)])
	
	# Restore habitable zone data
	if state.habitable_zone_data.size() > 0 and star_system.habitable_zone:
		# Habitable zone is regenerated from star properties, so we don't need to restore it
		# But we could validate that it matches if needed
		pass
	
	# Restore probe discoveries to probe system
	if probe_system and state.probe_discoveries.size() > 0:
		_log_info('Restoring probe status on %s planets', [state.probe_discoveries.size()])
		for planet_id in state.probe_discoveries:
			var discoverer_name = "Explorer"
			var discovery_data = state.probe_discoveries[planet_id]
			if discovery_data is Dictionary:
				var normalized = probe_system.apply_saved_discovery(planet_id, discovery_data)
				state.probe_discoveries[planet_id] = normalized
				var revealed = normalized.get("revealed_data")
				if revealed is Dictionary:
					discoverer_name = revealed.get("discovered_by_name", "Explorer")
			else:
				state.probe_discoveries[planet_id] = probe_system.apply_saved_discovery(planet_id, {})
			if discoverer_name == "" or discoverer_name == "Unknown":
				discoverer_name = "Explorer"
			var planet = _find_planet_by_stable_id(star_system, planet_id)
			if planet and is_instance_valid(planet):
				planet.set_probed_by(discoverer_name)
				_log_info('Restored probe status for %s discovered by %s', [planet.planet_name, discoverer_name])

	# Update last visited time for this system
	state.last_visited_time = current_time
	
	current_system_seed = system_seed
	
	_log_info('Loaded state for system %s. Restored %s planets with enhanced properties', [system_seed, restored_count])
	_log_info('Advanced planetary orbits by %s seconds', [snapped(time_elapsed, 0.01)])
	emit_signal("system_state_loaded", system_seed)
	return true
	


func _find_planet_by_stable_id(star_system: StarSystem, stable_id: String) -> Planet:
	if not star_system or not is_instance_valid(star_system):
		return null
	
	# Extract planet index from stable_id (format: "system_seed:planet_index")
	var parts = stable_id.split(":")
	if parts.size() != 2:
		return null
	
	var planet_index = int(parts[1])
	
	# Get planets from star system
	var planets = []
	for child in star_system.get_children():
		if child is Planet:
			planets.append(child)
	
	# Return planet at the specified index
	if planet_index >= 0 and planet_index < planets.size():
		return planets[planet_index]
	
	return null
	
# Check if we have saved state for a system
func has_system_state(system_seed: int) -> bool:
	return system_states.has(system_seed)

# Get system state info
func get_system_state_info(system_seed: int) -> Dictionary:
	if not system_states.has(system_seed):
		return {}
	
	var state = system_states[system_seed]
	return {
		"seed": state.seed,
		"star_type": state.star_type,
		"planet_count": state.planet_count,
		"timestamp": state.timestamp,
		"enhanced_planets": _count_enhanced_planets(state),
		"probe_discoveries": state.probe_discoveries.size()
	}

# Get summary of all system states
func get_system_state_summary(system_seed: int) -> Dictionary:
	var info = get_system_state_info(system_seed)
	if info.is_empty():
		return {"has_state": false}
	
	info["has_state"] = true
	return info

# Count planets with enhanced properties
func _count_enhanced_planets(state: SystemState) -> int:
	var count = 0
	for planet_state in state.planet_states:
		if planet_state.enhanced_properties_generated:
			count += 1
	return count

func rename_planet(system_seed: int, planet_index: int, old_name: String, new_name: String) -> void:
	if not system_states.has(system_seed):
		return
	var state: SystemState = system_states[system_seed]
	for planet_state in state.planet_states:
		if planet_state.index == planet_index:
			planet_state.name = new_name
			break
	var stable_id = str(system_seed) + ":" + str(planet_index)
	if state.probe_discoveries.has(stable_id):
		var discovery_data = state.probe_discoveries[stable_id]
		if discovery_data is Dictionary:
			discovery_data["planet_name"] = new_name
			var revealed = discovery_data.get("revealed_data")
			if revealed is Dictionary:
				if old_name != "" and revealed.get("planet_name", old_name) == old_name:
					revealed["planet_name"] = new_name

# Handle probe data received
func _on_probe_data_received(_target, _probe_type, _data):
	# This will be automatically saved when save_system_state is called
	pass

# Handle discovery made
func _on_discovery_made(_discovery_type: String, _target, _data):
	# This will be automatically saved when save_system_state is called
	pass

# Clear old system states (keep only recent ones)
func cleanup_old_states(max_systems: int = 50):
	if system_states.size() <= max_systems:
		return
	
	# Sort by timestamp and keep only the most recent
	var systems_by_time = []
	for state_seed in system_states:
		var state = system_states[state_seed]
		systems_by_time.append({"seed": state_seed, "timestamp": state.timestamp})

	systems_by_time.sort_custom(func(a, b): return a.timestamp > b.timestamp)

	# Remove oldest systems
	var systems_to_remove = systems_by_time.slice(max_systems)
	for system_info in systems_to_remove:
		system_states.erase(system_info.seed)
		_log_info('Removed old system state: %s', [system_info.seed])

# Save all system states to file (for game save/load)
func save_to_file(file_path: String) -> bool:
	var file = FileAccess.open(file_path, FileAccess.WRITE)
	if not file:
		_log_error('Error: Could not open file for writing: %s', [file_path])
		return false

	var save_data = {
		"version": 1,
		"system_states": {},
		"current_system_seed": current_system_seed
	}

	# Serialize system states
	for state_seed in system_states:
		var state = system_states[state_seed]
		save_data.system_states[str(state_seed)] = _serialize_system_state(state)

	file.store_string(JSON.stringify(save_data))
	file.close()

	_log_info('Saved %s system states to file', [system_states.size()])
	return true
func load_from_file(file_path: String) -> bool:
	if not FileAccess.file_exists(file_path):
		_log_info('Save file not found: %s', [file_path])
		return false

	var file = FileAccess.open(file_path, FileAccess.READ)
	if not file:
		_log_error('Error: Could not open file for reading: %s', [file_path])
		return false

	var json_string = file.get_as_text()
	file.close()

	var json = JSON.new()
	var parse_result = json.parse(json_string)
	if parse_result != OK:
		_log_error('Error: Could not parse save file JSON')
		return false

	var save_data = json.data
	if not save_data.has("system_states"):
		_log_error('Error: Invalid save file format')
		return false

	# Clear current states
	system_states.clear()

	# Deserialize system states
	for seed_str in save_data.system_states:
		var state_seed = int(seed_str)
		var state_data = save_data.system_states[seed_str]
		var state = _deserialize_system_state(state_data)
		if state:
			system_states[state_seed] = state

	current_system_seed = save_data.get("current_system_seed", -1)

	_log_info('Loaded %s system states from file', [system_states.size()])
	return true
func export_state() -> Dictionary:
	var data: Dictionary = {
		"system_states": {},
		"current_system_seed": current_system_seed
	}
	for state_seed in system_states:
		var state: SystemState = system_states[state_seed]
		data["system_states"][str(state_seed)] = _serialize_system_state(state)
	return data

func import_state(data: Dictionary) -> void:
	system_states.clear()
	var states_value = data.get("system_states", {})
	if states_value is Dictionary:
		for seed_str in states_value:
			var state_data = states_value[seed_str]
			if state_data is Dictionary:
				var state = _deserialize_system_state(state_data)
				if state:
					var state_seed = int(seed_str)
					system_states[state_seed] = state
	current_system_seed = data.get("current_system_seed", -1)



# Serialize a system state to dictionary
func _serialize_system_state(state: SystemState) -> Dictionary:
	var data = {
		"seed": state.system_seed,
		"star_type": state.star_type,
		"planet_count": state.planet_count,
		"timestamp": state.timestamp,
		"last_visited_time": state.last_visited_time,  # ADDED: Include last visited time
		"planet_states": [],
		"probe_discoveries": state.probe_discoveries,
		"habitable_zone_data": state.habitable_zone_data
	}
	
	for planet_state in state.planet_states:
		data.planet_states.append(_serialize_planet_state(planet_state))
	
	return data

# Deserialize a system state from dictionary
func _deserialize_system_state(data: Dictionary) -> SystemState:
	var state = SystemState.new(data.seed, data.star_type, data.planet_count)
	state.timestamp = data.get("timestamp", 0.0)
	state.last_visited_time = data.get("last_visited_time", state.timestamp)  # ADDED: Restore last visited time
	state.probe_discoveries = data.get("probe_discoveries", {})
	state.habitable_zone_data = data.get("habitable_zone_data", {})
	
	for planet_data in data.get("planet_states", []):
		var planet_state = _deserialize_planet_state(planet_data)
		if planet_state:
			state.planet_states.append(planet_state)
	
	return state

# Serialize a planet state to dictionary
func _serialize_planet_state(planet_state: PlanetState) -> Dictionary:
	return {
		"index": planet_state.index,
		"name": planet_state.name,
		"enhanced_properties_generated": planet_state.enhanced_properties_generated,
		# ADDED: Orbital state serialization
		"orbit_angle": planet_state.orbit_angle,
		"semi_major_axis": planet_state.semi_major_axis,
		"eccentricity": planet_state.eccentricity,
		"orbit_speed": planet_state.orbit_speed,
		"planet_size": planet_state.planet_size,
		# Enhanced properties
		"atmosphere_type": planet_state.atmosphere_type,
		"atmosphere_pressure": planet_state.atmosphere_pressure,
		"atmosphere_composition": planet_state.atmosphere_composition,
		"magnetosphere_strength": planet_state.magnetosphere_strength,
		"magnetic_field_strength": planet_state.magnetic_field_strength,
		"geological_activity": planet_state.geological_activity,
		"tectonic_plates": planet_state.tectonic_plates,
		"volcanic_activity": planet_state.volcanic_activity,
		"climate_type": planet_state.climate_type,
		"surface_temperature": planet_state.surface_temperature,
		"temperature_variation": planet_state.temperature_variation,
		"surface_liquids": planet_state.surface_liquids,
		"surface_composition": planet_state.surface_composition,
		"moons": planet_state.moons,
		"habitability_score": planet_state.habitability_score,
		"habitable_zone_type": planet_state.habitable_zone_type
	}

# Deserialize a planet state from dictionary
func _deserialize_planet_state(data: Dictionary) -> PlanetState:
	var planet_state = PlanetState.new(data.get("index", 0), data.get("name", ""))
	
	planet_state.enhanced_properties_generated = data.get("enhanced_properties_generated", false)
	
	# ADDED: Orbital state deserialization
	planet_state.orbit_angle = data.get("orbit_angle", 0.0)
	planet_state.semi_major_axis = data.get("semi_major_axis", 100.0)
	planet_state.eccentricity = data.get("eccentricity", 0.0)
	planet_state.orbit_speed = data.get("orbit_speed", 0.01)
	planet_state.planet_size = data.get("planet_size", 1.0)
	
	# Enhanced properties
	planet_state.atmosphere_type = data.get("atmosphere_type", 0)
	planet_state.atmosphere_pressure = data.get("atmosphere_pressure", 0.0)
	planet_state.atmosphere_composition = data.get("atmosphere_composition", {})
	planet_state.magnetosphere_strength = data.get("magnetosphere_strength", 0)
	planet_state.magnetic_field_strength = data.get("magnetic_field_strength", 0.0)
	planet_state.geological_activity = data.get("geological_activity", 0)
	planet_state.tectonic_plates = data.get("tectonic_plates", 0)
	planet_state.volcanic_activity = data.get("volcanic_activity", 0.0)
	planet_state.climate_type = data.get("climate_type", 0)
	planet_state.surface_temperature = data.get("surface_temperature", 0.0)
	planet_state.temperature_variation = data.get("temperature_variation", 0.0)
	planet_state.surface_liquids = data.get("surface_liquids", {})
	planet_state.surface_composition = data.get("surface_composition", {})
	planet_state.moons = data.get("moons", [])
	planet_state.habitability_score = data.get("habitability_score", 0.0)
	planet_state.habitable_zone_type = data.get("habitable_zone_type", -1)
	
	return planet_state
