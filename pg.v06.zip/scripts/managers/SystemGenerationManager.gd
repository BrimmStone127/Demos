﻿# SystemGenerationManager.gd
class_name SystemGenerationManager
extends Node


class GenerationContext:
	var seed_value: int
	var existing_system: StarSystem
	var should_show_transition: bool
	var new_system: StarSystem = null
	var state_loaded: bool = false

	func _init(p_seed_value: int, p_existing_system: StarSystem, p_should_show_transition: bool):
		self.seed_value = p_seed_value
		self.existing_system = p_existing_system
		self.should_show_transition = p_should_show_transition

# Signals
signal system_generation_started(seed_value: int)
signal system_generation_complete(star_system: StarSystem)
signal system_generation_failed(error_message: String)
signal ui_loading_state_changed(is_loading: bool)
signal ui_state_save_requested()
signal ui_state_restore_requested()
signal info_panel_close_requested()
signal options_info_changed(seed_value: int, star_type: String)
signal object_clicked(object)

# Runtime collaborators
var services: GameServices
var assets: GameAssets
var prep_pipeline: GenerationPrepPipeline
var finalize_pipeline: GenerationFinalizePipeline

# Current generation state
var current_seed: int = 0
var current_star_type: String = ""
var is_generating: bool = false
var force_habitable_system: bool = false  # Set by world scenario before calling generate_star_system

func initialize(p_services: GameServices, p_assets: GameAssets):
	services = p_services
	assets = p_assets
	prep_pipeline = GenerationPrepPipeline.new(self)
	finalize_pipeline = GenerationFinalizePipeline.new(self)
	_report_missing_dependencies()

func generate_star_system(seed_value: int = randi()) -> StarSystem:
	if not _ensure_initialized():
		return null

	if is_generating:
		_log_warning("SYSTEM_GEN", "System generation already in progress")
		return null

	is_generating = true
	emit_signal("system_generation_started", seed_value)

	var network := services.network_manager if services else null
	_log_info("SYSTEM_GEN", "generate_star_system called with seed: %s" % seed_value)
	_log_info("SYSTEM_GEN", "Is Multiplayer: %s | Is Host: %s" % [network.is_multiplayer if network else false, network.is_host if network else false])

	if network and network.is_multiplayer:
		if network.is_host:
			_log_info("SYSTEM_GEN", "Host generating system...")
		else:
			_log_info("SYSTEM_GEN", "Client generating system from host command...")

	var new_star_system = await _generate_system_async(seed_value)

	is_generating = false

	if new_star_system:
		emit_signal("system_generation_complete", new_star_system)
	else:
		emit_signal("system_generation_failed", "Failed to generate valid star system")

	return new_star_system

func _generate_system_async(seed_value: int) -> StarSystem:
	var context := _build_context(seed_value)
	if prep_pipeline:
		await prep_pipeline.run(context)
	context.new_system = _create_new_system(context.seed_value)

	if context.new_system:
		if finalize_pipeline:
			await finalize_pipeline.run(context)
	else:
		await _handle_generation_failure(context)

	return context.new_system

func _build_context(seed_value: int) -> GenerationContext:
	var existing_system := _get_current_star_system()
	var main_node := services.main_node if services else null
	var should_show_transition: bool = false
	if main_node != null and existing_system != null:
		should_show_transition = bool(main_node.game_started)
	return GenerationContext.new(seed_value, existing_system, should_show_transition)

func _update_background_if_needed(seed_value: int):
	var background := services.star_background if services else null
	if not background:
		return

	var background_needs_update := false
	if not background.is_generated or abs(background.current_seed - seed_value) > 1000000:
		background_needs_update = true
		_log_info("SYSTEM_GEN", "Regenerating background with seed: %s" % seed_value)

	if background_needs_update:
		background.generate(seed_value)

func _clear_existing_system(existing_system: StarSystem):
	if not _is_system_valid(existing_system):
		return

	_log_info("SYSTEM_GEN", "Clearing existing star system")

	var children_to_remove: Array = []
	for child in existing_system.get_children():
		children_to_remove.append(child)

	for child in children_to_remove:
		existing_system.remove_child(child)
		child.queue_free()

	var scene_manager := services.scene_manager if services else null
	var main_node := services.main_node if services else null

	if scene_manager and scene_manager.get_current_scene_type() == SceneManager.SceneType.STAR_SYSTEM:
		var current_scene_node = scene_manager.get_current_scene_node()
		if current_scene_node and current_scene_node.has_method("remove_child"):
			if existing_system in current_scene_node.get_children():
				current_scene_node.remove_child(existing_system)
	elif main_node and existing_system in main_node.get_children():
		main_node.remove_child(existing_system)

	existing_system.queue_free()

	if main_node:
		main_node.star_system = null

	await get_tree().create_timer(0.1).timeout

func _create_new_system(seed_value: int) -> StarSystem:
	_log_info("SYSTEM_GEN", "Creating new star system with seed: %s" % seed_value)

	var new_star_system = StarSystem.new()
	if assets:
		new_star_system.sun_texture = assets.sun_texture
		new_star_system.planet_texture = assets.planet_texture

	new_star_system.force_habitable = force_habitable_system
	new_star_system.generate_enhanced(seed_value)

	var main_node := services.main_node if services else null
	if main_node:
		main_node.star_system = new_star_system

	_create_star_system_scene(new_star_system)

	return new_star_system

func _create_star_system_scene(star_system: StarSystem):
	var scene_manager := services.scene_manager if services else null
	var main_node := services.main_node if services else null

	if not scene_manager:
		if main_node:
			main_node.add_child(star_system)
		return

	var star_system_scene = Node2D.new()
	star_system_scene.name = "StarSystemScene"

	if star_system:
		star_system_scene.add_child(star_system)

	var scene_data = {
		"seed": current_seed,
		"star_type": current_star_type
	}

	scene_manager.change_scene(star_system_scene, SceneManager.SceneType.STAR_SYSTEM, scene_data)

func _handle_generation_failure(context: GenerationContext):
	emit_signal("ui_loading_state_changed", false)

	var transition := services.transition_manager if services else null
	if context.should_show_transition and transition:
		await transition.fade_from_black(0.3)

	_log_error("SYSTEM_GEN", "Failed to create valid star system")

	emit_signal("ui_state_restore_requested")

func _load_system_state_if_available(star_system: StarSystem) -> bool:
	var system_state := services.system_state_manager if services else null
	if not system_state or not system_state.has_system_state(current_seed):
		_log_info("SYSTEM_GEN", "No saved state found for system %s, using fresh generation" % current_seed)
		return false

	_log_info("SYSTEM_GEN", "Found saved state for system %s, attempting to restore..." % current_seed)
	var probe := services.probe_system if services else null
	var state_loaded = system_state.load_system_state(star_system, probe)

	if state_loaded:
		_log_info("SYSTEM_GEN", "Successfully restored system state")
	else:
		_log_warning("SYSTEM_GEN", "Failed to restore system state, using fresh generation")

	return state_loaded

func _show_habitability_summary(star_system: StarSystem):
	if not star_system.has_method("get_habitability_summary"):
		return

	var hab_summary = star_system.get_habitability_summary()
	if not hab_summary.has_zone:
		return

	_log_info("HABITABILITY", "=== HABITABILITY SUMMARY ===")
	_log_info("HABITABILITY", "Habitable zone eccentricity: %s" % snapped(hab_summary.zone_eccentricity, 0.01))
	_log_info("HABITABILITY", "Conservative zone: %s - %s AU" % [snapped(hab_summary.conservative_inner, 0.01), snapped(hab_summary.conservative_outer, 0.01)])
	_log_info("HABITABILITY", "Optimistic zone: %s - %s AU" % [snapped(hab_summary.optimistic_inner, 0.01), snapped(hab_summary.optimistic_outer, 0.01)])
	_log_info("HABITABILITY", "Planets spending time in zones: %s" % hab_summary.planets_in_zone)
	_log_info("HABITABILITY", "Potentially habitable planets: %s" % hab_summary.potentially_habitable_count)

	if hab_summary.zone_crossers.size() > 0:
		_log_info("HABITABILITY", "Zone-crossing planets: %s" % hab_summary.zone_crossers.size())
		for crosser in hab_summary.zone_crossers:
			_log_info("HABITABILITY", "%s (eccentricity: %s)" % [crosser.name, snapped(crosser.eccentricity, 0.01)])

	if hab_summary.best_score > 0:
		_log_info("HABITABILITY", "Best habitability candidate: %s (score: %s)" % [hab_summary.best_planet, snapped(hab_summary.best_score, 0.01)])

	_log_info("HABITABILITY", "============================")

func _add_clickable_areas(star_system: StarSystem):
	if not _is_system_valid(star_system):
		_log_warning("SYSTEM_GEN", "Cannot add clickable areas to invalid star system")
		return

	var star_radius = 50 * (520.0 / 64.0)
	var star_clickable = ClickableArea.new(star_system, star_radius)
	star_clickable.object_clicked.connect(func(clicked): emit_signal("object_clicked", clicked))
	star_system.add_child(star_clickable)

	for child in star_system.get_children():
		if child is Planet:
			var planet_radius = 30 * child.planet_size * (520.0 / 64.0)
			var planet_clickable = ClickableArea.new(child, planet_radius)
			planet_clickable.object_clicked.connect(func(clicked): emit_signal("object_clicked", clicked))
			child.add_child(planet_clickable)

func _update_orbit_visibility(star_system: StarSystem):
	if not _is_system_valid(star_system):
		return

	var main_node := services.main_node if services else null
	var show_orbits = main_node.show_orbits if main_node else true
	star_system.set_orbit_visibility(show_orbits)

func _count_planets(star_system: StarSystem) -> int:
	var count = 0
	for child in star_system.get_children():
		if child is Planet:
			count += 1
	return count

func _notify_loading_started():
	emit_signal("ui_loading_state_changed", true)
	await get_tree().process_frame

func _notify_loading_finished():
	emit_signal("ui_loading_state_changed", false)

func _request_ui_state_save():
	emit_signal("ui_state_save_requested")

func _request_ui_state_restore():
	emit_signal("ui_state_restore_requested")

func _request_info_panel_close():
	emit_signal("info_panel_close_requested")

func _notify_options_info_changed(seed_value: int, star_type: String):
	emit_signal("options_info_changed", seed_value, star_type)

func _is_system_valid(star_system) -> bool:
	return star_system != null and is_instance_valid(star_system)

func _get_current_star_system() -> StarSystem:
	var main_node := services.main_node if services else null
	if main_node and "star_system" in main_node:
		return main_node.star_system
	return null

func get_current_seed() -> int:
	return current_seed

func get_current_star_type() -> String:
	return current_star_type

func is_generating_system() -> bool:
	return is_generating

func _ensure_initialized() -> bool:
	if services:
		return true
	push_error("SystemGenerationManager.initialize must be called before use.")
	return false


func _logger() -> GameLogger:
	return services.logger if services and services.logger else null

func _log_debug(tag: String, message: String):
	var logger := _logger()
	if logger:
		logger.debug(tag, message)
	else:
		print("[DEBUG][%s] %s" % [tag, message])

func _log_info(tag: String, message: String):
	var logger := _logger()
	if logger:
		logger.info(tag, message)
	else:
		print("[INFO][%s] %s" % [tag, message])

func _log_warning(tag: String, message: String):
	var logger := _logger()
	if logger:
		logger.warn(tag, message)
	else:
		push_warning("[%s] %s" % [tag, message])

func _log_error(tag: String, message: String):
	var logger := _logger()
	if logger:
		logger.error(tag, message)
	else:
		push_error("[%s] %s" % [tag, message])

func _report_missing_dependencies():
	var missing: Array[String] = []
	if not services:
		missing.append("services")
	else:
		missing.append_array(services.missing_required())
	if not assets or assets.sun_texture == null:
		missing.append("sun_texture")
	if not assets or assets.planet_texture == null:
		missing.append("planet_texture")
	if missing.is_empty():
		return
	var message = ", ".join(PackedStringArray(missing))
	_log_warning("SYSTEM_GEN", "Missing dependencies: %s" % message)
