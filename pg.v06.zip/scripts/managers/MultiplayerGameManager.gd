# MultiplayerGameManager.gd
class_name MultiplayerGameManager
extends Node

const LOG_TAG := "MULTIPLAYER_MANAGER"

func _format_log(message: String, values: Array) -> String:
	if values.is_empty():
		return message
	return message % values

func _log_debug(message: String, values: Array = []):
	GameLog.debug(LOG_TAG, _format_log(message, values))

func _log_info(message: String, values: Array = []):
	GameLog.info(LOG_TAG, _format_log(message, values))

func _log_warn(message: String, values: Array = []):
	GameLog.warn(LOG_TAG, _format_log(message, values))

func _log_error(message: String, values: Array = []):
	GameLog.error(LOG_TAG, _format_log(message, values))

# Signals for communication with Main.gd
signal game_initialization_requested(skip_start_screen: bool)
signal star_system_generation_requested()
signal start_screen_cleanup_requested()

# References that Main.gd will provide
var network_manager: NetworkManager
var transition_manager: TransitionManager
var multiplayer_stats_ui: MultiplayerStatsUI
var canvas_layer: CanvasLayer

# Multiplayer menu reference
var current_multiplayer_menu: Control

func initialize(p_network_manager: NetworkManager, p_transition_manager: TransitionManager, p_canvas_layer: CanvasLayer):
	network_manager = p_network_manager
	transition_manager = p_transition_manager
	canvas_layer = p_canvas_layer
	_log_info('Initialized')

func show_multiplayer_menu(start_screen: Control):
	start_screen.visible = false
	
	# Load the multiplayer menu script dynamically
	var multiplayer_menu_script = load("res://scripts/ui/MultiplayerMenu.gd")
	current_multiplayer_menu = multiplayer_menu_script.new()
	current_multiplayer_menu.host_selected.connect(_on_host_game)
	current_multiplayer_menu.join_selected.connect(_on_join_game)
	current_multiplayer_menu.back_selected.connect(func():
		current_multiplayer_menu.queue_free()
		current_multiplayer_menu = null
		if start_screen:
			start_screen.visible = true
	)
	
	canvas_layer.add_child(current_multiplayer_menu)
	
	# Apply terminal theme
	var terminal_theme_script = load("res://scripts/ui/TerminalTheme.gd")
	terminal_theme_script.apply_recursive(current_multiplayer_menu)

func _on_host_game(player_name: String):
	_log_info('_on_host_game called with name: %s', [player_name])
	_log_info('Network manager exists: %s', [network_manager != null])
	
	if not network_manager:
		_log_error('ERROR: No network manager!')
		return
	
	_log_info('Network manager state before host: %s', [network_manager.get_connection_state()])
	
	var success = network_manager.host_game(player_name)
	_log_info('Host game result: %s', [success])
	
	if success:
		_log_info('Starting multiplayer game...')
		await _start_multiplayer_game()
	else:
		_log_info('Failed to host game')
		
func _on_join_game(address: String, player_name: String):
	_log_info('_on_join_game called with address: %s name: %s', [address, player_name])
	_log_info('Network manager exists: %s', [network_manager != null])
	
	if not network_manager:
		_log_error('ERROR: No network manager!')
		return
	
	_log_info('Network manager state before join: %s', [network_manager.get_connection_state()])
	
	var success = network_manager.join_game(address, player_name)
	_log_info('Join game result: %s', [success])
	
	if success:
		_log_info('Starting multiplayer game...')
		await _start_multiplayer_game()
	else:
		_log_info('Failed to join game')

func _start_multiplayer_game():
	_log_debug('=== _start_multiplayer_game() BEGIN ===')
	_log_info('Network manager state: %s', [network_manager.get_connection_state()])
	_log_info('Is multiplayer: %s', [network_manager.is_multiplayer])
	_log_info('Is host: %s', [network_manager.is_host])
	
	# Clean up start screen
	emit_signal("start_screen_cleanup_requested")
	
	# Check if transition_manager exists before using it
	if transition_manager and is_instance_valid(transition_manager):
		_log_info('Starting fade to black...')
		await transition_manager.fade_to_black(0.3)
		_log_info('Fade to black complete')
	else:
		_log_info('No transition manager available, skipping fade')
		# Small delay to replace the transition
		await get_tree().create_timer(0.3).timeout
	
	# Request game initialization from Main.gd
	_log_info('Requesting game initialization...')
	emit_signal("game_initialization_requested", false)
	
	# Create multiplayer stats UI
	_log_info('Creating multiplayer stats UI...')
	await _create_multiplayer_stats_ui()
	
	# Handle system generation based on host/client role
	if network_manager.is_host:
		_log_info('Host: Generating initial system after delay...')
		await get_tree().create_timer(0.5).timeout
		_log_info('Host: Requesting star system generation...')
		emit_signal("star_system_generation_requested")
		_log_info('Host: System generation request complete')
	else:
		_log_info('Client: Waiting for system from host...')
	
	_log_info('Starting fade from black...')
	if transition_manager and is_instance_valid(transition_manager):
		await transition_manager.fade_from_black(0.3)
		_log_info('Fade from black complete')
	else:
		_log_info('No transition manager available, skipping fade')
	
	_log_debug('=== _start_multiplayer_game() END ===')

func _create_multiplayer_stats_ui():
	var multiplayer_stats_ui_script = load("res://scripts/ui/MultiplayerStatsUI.gd")
	if multiplayer_stats_ui_script:
		multiplayer_stats_ui = multiplayer_stats_ui_script.new(network_manager)
		if multiplayer_stats_ui:
			canvas_layer.add_child(multiplayer_stats_ui)
			_log_info('Multiplayer stats UI created successfully')
		else:
			_log_error('ERROR: Failed to create multiplayer stats UI instance')
	else:
		_log_error('ERROR: MultiplayerStatsUiScript not found')

func cleanup():
	if current_multiplayer_menu and is_instance_valid(current_multiplayer_menu):
		current_multiplayer_menu.queue_free()
		current_multiplayer_menu = null
	
	if multiplayer_stats_ui and is_instance_valid(multiplayer_stats_ui):
		multiplayer_stats_ui.queue_free()
		multiplayer_stats_ui = null
	
	network_manager = null
	transition_manager = null
	canvas_layer = null
	_log_info('Cleanup complete')
