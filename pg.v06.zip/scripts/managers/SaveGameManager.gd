class_name SaveGameManager
extends Node

const LOG_TAG := "SAVE_MANAGER"
const SAVE_VERSION := 1
const SAVE_DIRECTORY := "user://saves"
const LEGACY_SLOT := "slot1.json"
const THUMBNAIL_SIZE := Vector2i(320, 180)

var services: GameServices


func initialize(p_services: GameServices):
	services = p_services
	_migrate_legacy_save()


## Returns true if any save files exist
func has_saves() -> bool:
	return list_saves().size() > 0


## List all saves sorted by timestamp descending (most recent first)
func list_saves() -> Array[Dictionary]:
	var saves: Array[Dictionary] = []
	var dir := DirAccess.open(SAVE_DIRECTORY)
	if dir == null:
		return saves

	dir.list_dir_begin()
	var file_name := dir.get_next()
	while file_name != "":
		if not dir.current_is_dir() and file_name.ends_with(".json") and file_name.begins_with("save_"):
			var summary := get_slot_summary(file_name.get_basename())
			if not summary.is_empty():
				saves.append(summary)
		file_name = dir.get_next()
	dir.list_dir_end()

	saves.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return float(a.get("timestamp", 0.0)) > float(b.get("timestamp", 0.0))
	)
	return saves


## Get the next available slot ID (e.g., "save_001", "save_002")
func get_next_slot_id() -> String:
	var existing := list_saves()
	var max_num := 0
	for save in existing:
		var slot_id: String = save.get("slot_id", "")
		var num := _slot_id_to_number(slot_id)
		if num > max_num:
			max_num = num
	return "save_%03d" % (max_num + 1)


## Generate a default save name from metadata
func generate_save_name(meta: Dictionary) -> String:
	var day := int(meta.get("game_days_elapsed", 0))
	var seed_val := int(meta.get("current_seed", 0))
	return "Day %d - Seed %d" % [day, seed_val]


## Save game to a specific slot
func save_to_slot(slot_id: String, meta: Dictionary = {}, thumbnail: Image = null) -> Dictionary:
	var path := _slot_path(slot_id)
	var result: Dictionary = {
		"success": false,
		"message": "",
		"path": path,
		"slot_id": slot_id
	}

	if services == null:
		result.message = "SaveGameManager not initialized"
		GameLog.error(LOG_TAG, result.message)
		return result

	var create_dir_error := DirAccess.make_dir_recursive_absolute(SAVE_DIRECTORY)
	if create_dir_error != OK and create_dir_error != ERR_ALREADY_EXISTS:
		result.message = "Unable to create save directory"
		GameLog.error(LOG_TAG, result.message)
		return result

	var payload: Dictionary = _build_payload(meta)
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		result.message = "Failed to open save file for writing"
		GameLog.error(LOG_TAG, result.message)
		return result

	file.store_string(JSON.stringify(payload))
	file.close()

	if thumbnail != null:
		_save_thumbnail(slot_id, thumbnail)

	result.success = true
	result.message = "Game saved"
	GameLog.info(LOG_TAG, "Game saved to %s" % path)
	return result


## Load game from a specific slot
func load_from_slot(slot_id: String) -> Dictionary:
	var path := _slot_path(slot_id)
	var result: Dictionary = {
		"success": false,
		"message": "",
		"meta": {},
		"slot_id": slot_id
	}

	if services == null:
		result.message = "SaveGameManager not initialized"
		GameLog.error(LOG_TAG, result.message)
		return result

	if not FileAccess.file_exists(path):
		result.message = "Save file not found: %s" % slot_id
		GameLog.error(LOG_TAG, result.message)
		return result

	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		result.message = "Failed to open save file"
		GameLog.error(LOG_TAG, result.message)
		return result

	var json := JSON.new()
	var parse_result := json.parse(file.get_as_text())
	file.close()
	if parse_result != OK:
		result.message = "Save file is corrupted"
		GameLog.error(LOG_TAG, result.message)
		return result

	var data: Dictionary = {}
	if json.data is Dictionary:
		data = json.data
	_apply_payload(data)

	var meta: Dictionary = {}
	if data.has("meta"):
		var meta_value = data.get("meta")
		if meta_value is Dictionary:
			meta = meta_value.duplicate(true)
	meta["timestamp"] = data.get("timestamp", 0.0)
	meta["slot_id"] = slot_id

	result.success = true
	result.meta = meta
	GameLog.info(LOG_TAG, "Loaded save from %s" % path)
	return result


## Delete a save slot (JSON + thumbnail)
func delete_slot(slot_id: String) -> Dictionary:
	var result: Dictionary = {
		"success": false,
		"message": ""
	}

	var path := _slot_path(slot_id)
	var dir := DirAccess.open(SAVE_DIRECTORY)
	if dir == null:
		if not FileAccess.file_exists(path):
			result.success = true
			result.message = "Save already missing"
			return result
		result.message = "Unable to open save directory"
		GameLog.error(LOG_TAG, result.message)
		return result

	if FileAccess.file_exists(path):
		var err := dir.remove(slot_id + ".json")
		if err != OK:
			result.message = "Could not delete save file"
			GameLog.error(LOG_TAG, result.message)
			return result

	var thumb_path := _thumbnail_path(slot_id)
	if FileAccess.file_exists(thumb_path):
		dir.remove(slot_id + ".png")

	result.success = true
	result.message = "Save deleted"
	GameLog.info(LOG_TAG, "Deleted save: %s" % slot_id)
	return result


## Rename a save slot (updates save_name inside the JSON)
func rename_slot(slot_id: String, new_name: String) -> Dictionary:
	var result: Dictionary = {
		"success": false,
		"message": ""
	}

	var path := _slot_path(slot_id)
	if not FileAccess.file_exists(path):
		result.message = "Save file not found"
		GameLog.error(LOG_TAG, result.message)
		return result

	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		result.message = "Failed to open save file"
		GameLog.error(LOG_TAG, result.message)
		return result

	var json := JSON.new()
	var parse_result := json.parse(file.get_as_text())
	file.close()
	if parse_result != OK:
		result.message = "Save file is corrupted"
		GameLog.error(LOG_TAG, result.message)
		return result

	var data: Dictionary = {}
	if json.data is Dictionary:
		data = json.data

	if data.has("meta") and data.meta is Dictionary:
		data.meta["save_name"] = new_name
	else:
		data["meta"] = {"save_name": new_name}

	var write_file := FileAccess.open(path, FileAccess.WRITE)
	if write_file == null:
		result.message = "Failed to write renamed save"
		GameLog.error(LOG_TAG, result.message)
		return result

	write_file.store_string(JSON.stringify(data))
	write_file.close()

	result.success = true
	result.message = "Save renamed"
	GameLog.info(LOG_TAG, "Renamed %s to: %s" % [slot_id, new_name])
	return result


## Get summary metadata for a slot without loading full payload
func get_slot_summary(slot_id: String) -> Dictionary:
	var path := _slot_path(slot_id)
	if not FileAccess.file_exists(path):
		return {}

	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {}

	var json := JSON.new()
	var parse_result := json.parse(file.get_as_text())
	file.close()
	if parse_result != OK:
		return {}

	var data: Dictionary = {}
	if json.data is Dictionary:
		data = json.data
	var meta: Dictionary = {}
	if data.has("meta"):
		var meta_value = data.get("meta")
		if meta_value is Dictionary:
			meta = meta_value.duplicate(true)
	meta["timestamp"] = data.get("timestamp", 0.0)
	meta["slot_id"] = slot_id
	meta["has_thumbnail"] = FileAccess.file_exists(_thumbnail_path(slot_id))
	return meta


## Load thumbnail image for a slot, returns null if not found
func load_thumbnail(slot_id: String) -> Image:
	var path := _thumbnail_path(slot_id)
	if not FileAccess.file_exists(path):
		return null
	var image := Image.new()
	var err := image.load(path)
	if err != OK:
		return null
	return image


## Capture a thumbnail from the current viewport
func capture_thumbnail(viewport: Viewport) -> Image:
	if viewport == null:
		return null
	var image := viewport.get_texture().get_image()
	if image == null:
		return null
	image.resize(THUMBNAIL_SIZE.x, THUMBNAIL_SIZE.y, Image.INTERPOLATE_BILINEAR)
	return image


# --- Backward compatibility wrappers ---

## Legacy: save to most recent or new slot
func save_game(meta: Dictionary = {}) -> Dictionary:
	var saves := list_saves()
	var slot_id: String
	if saves.size() > 0:
		slot_id = saves[0].get("slot_id", get_next_slot_id())
	else:
		slot_id = get_next_slot_id()
	return save_to_slot(slot_id, meta)

## Legacy: load most recent save
func load_game() -> Dictionary:
	var saves := list_saves()
	if saves.size() == 0:
		return {"success": false, "message": "No save file found", "meta": {}}
	return load_from_slot(saves[0].get("slot_id", ""))

## Legacy: check if any save exists
func has_save() -> bool:
	return has_saves()

## Legacy: delete most recent save
func delete_save() -> Dictionary:
	var saves := list_saves()
	if saves.size() == 0:
		return {"success": true, "message": "Save already missing"}
	return delete_slot(saves[0].get("slot_id", ""))

## Legacy: get most recent save summary
func get_save_summary() -> Dictionary:
	var saves := list_saves()
	if saves.size() == 0:
		return {}
	return saves[0]


# --- Internal ---

func _slot_path(slot_id: String) -> String:
	return SAVE_DIRECTORY.path_join(slot_id + ".json")

func _thumbnail_path(slot_id: String) -> String:
	return SAVE_DIRECTORY.path_join(slot_id + ".png")

func _slot_id_to_number(slot_id: String) -> int:
	var stripped := slot_id.replace("save_", "")
	if stripped.is_valid_int():
		return int(stripped)
	return 0

func _save_thumbnail(slot_id: String, image: Image) -> void:
	var path := _thumbnail_path(slot_id)
	var err := image.save_png(path)
	if err != OK:
		GameLog.error(LOG_TAG, "Failed to save thumbnail for %s" % slot_id)
	else:
		GameLog.info(LOG_TAG, "Saved thumbnail for %s" % slot_id)

func _migrate_legacy_save() -> void:
	var legacy_path := SAVE_DIRECTORY.path_join(LEGACY_SLOT)
	if not FileAccess.file_exists(legacy_path):
		return
	var new_path := _slot_path("save_001")
	if FileAccess.file_exists(new_path):
		GameLog.info(LOG_TAG, "Legacy save exists but save_001 already present, skipping migration")
		return
	var dir := DirAccess.open(SAVE_DIRECTORY)
	if dir == null:
		GameLog.error(LOG_TAG, "Could not open save directory for migration")
		return
	var err := dir.rename(LEGACY_SLOT, "save_001.json")
	if err == OK:
		GameLog.info(LOG_TAG, "Migrated legacy save slot1.json to save_001.json")
	else:
		GameLog.error(LOG_TAG, "Failed to migrate legacy save: error %d" % err)

func _build_payload(meta: Dictionary) -> Dictionary:
	var payload: Dictionary = {
		"version": SAVE_VERSION,
		"timestamp": Time.get_unix_time_from_system(),
		"meta": {},
		"system_state": {},
		"history": [],
		"probe": {}
	}

	var main_node := services.main_node if services else null
	var sector_info: Dictionary = main_node.get_sector_info() if main_node and main_node.has_method("get_sector_info") else {}
	var default_meta: Dictionary = {
		"current_seed": main_node.get_current_seed() if main_node and main_node.has_method("get_current_seed") else -1,
		"show_orbits": main_node.show_orbits if main_node and "show_orbits" in main_node else true,
		"game_started": main_node.game_started if main_node and "game_started" in main_node else false,
		"galaxy_seed": sector_info.get("galaxy_seed", 0),
		"sector_index": sector_info.get("sector_index", 0),
		"sector_seed": sector_info.get("sector_seed", 0),
		"sector_size": sector_info.get("sector_size", 0),
		"star_index": sector_info.get("star_index", 0),
	}

	payload.meta = default_meta.duplicate(true)
	for key in meta:
		payload.meta[key] = meta[key]
	payload.meta["timestamp"] = payload.timestamp

	if not payload.meta.has("save_name"):
		payload.meta["save_name"] = generate_save_name(payload.meta)

	var system_state_manager := services.system_state_manager if services else null
	if system_state_manager and system_state_manager.has_method("export_state"):
		payload.system_state = system_state_manager.export_state()

	var history := services.system_history if services else null
	if history and history.has_method("export_history"):
		payload.history = history.export_history()

	var probe_system := services.probe_system if services else null
	if probe_system and probe_system.has_method("export_data"):
		payload.probe = probe_system.export_data()

	var foundation := services.foundation if services else null
	if foundation and foundation.has_method("export_data"):
		payload.foundation = foundation.export_data()

	return payload

func _apply_payload(payload: Dictionary) -> void:
	if payload.is_empty():
		return

	var system_state_manager := services.system_state_manager if services else null
	if system_state_manager and payload.has("system_state"):
		system_state_manager.import_state(payload.system_state)

	var history := services.system_history if services else null
	if history and payload.has("history"):
		history.import_history(payload.history)

	var probe_system := services.probe_system if services else null
	if probe_system and payload.has("probe"):
		probe_system.import_data(payload.probe)

	var foundation := services.foundation if services else null
	if foundation and payload.has("foundation"):
		foundation.import_data(payload.foundation)
