extends Sprite2D

func _ready():
	adjust_background_scale()
	get_viewport().connect("size_changed", Callable(self, "adjust_background_scale"))

func adjust_background_scale():
	# Get the viewport size
	var viewport_size = get_viewport_rect().size
	# Get the texture size
	var texture_size = texture.get_size()

	# Calculate the scale needed to fit the background
	var scale_x = viewport_size.x / texture_size.x
	var scale_y = viewport_size.y / texture_size.y

	# Use the larger scale to ensure the background covers the entire screen
	var bg_scale = max(scale_x, scale_y)

	# Apply the scale uniformly to avoid stretching
	self.scale = Vector2(bg_scale, bg_scale)
